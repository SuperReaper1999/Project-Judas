#include "CutCondensedPressure.h"
#include <iostream>
using namespace judas::volume_grid;
int main(){
 auto sum=CutCompensated(1e15)+CutCompensated(1e-15)-CutCompensated(1e15);std::cout<<"arithmetic="<<sum.Value()<<'\n';
 for(bool eliminate:{false,true}){
 CutCondensedResult out;std::string error;
 bool ok=SolveCutCondensedPressure({1.,0.,0.},{{0,1,1e10},{1,2,1e-10}},{1.,1e-12,-1e-12},{1e-25,1e-29,1e-29},{false,eliminate,eliminate},out,error);
 std::cout<<"ok="<<ok<<" eliminate="<<eliminate<<" normalized="<<out.maximumNormalizedResidual<<" iterations="<<out.refinements<<" error="<<error<<'\n';
 }
}
