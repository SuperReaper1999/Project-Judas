#include "CutLocalPressure.h"
#include <algorithm>
#include <cmath>
#include <iostream>
namespace judas::volume_grid {
namespace {
using Real=CutCompensated;
bool Fail(std::string& error,const char* reason){error=reason;return false;}
struct Port{std::size_t i;int axis,sign;Real g,predictor;};
bool Transport(const CutSpatialField& field,const std::vector<Real>& q,const std::vector<Port>& ports,
 const std::vector<Real>& v,std::vector<Real>& water,std::vector<Real>& mass,std::string& error){
 const auto n=field.parent.size();
 struct Edge{std::size_t from;Real q;};std::vector<std::vector<Edge>> incoming(n);
 std::vector<Real> diagonal(n),wrhs(n),mrhs(n),alpha(n),gamma(n);
 for(std::size_t i=0;i<n;++i){diagonal[i]=field.geometry.startCapacity[i];wrhs[i]=field.water[i];mrhs[i]=field.gasMass[i];alpha[i]=wrhs[i]/diagonal[i];gamma[i]=mrhs[i]/diagonal[i];}
 for(std::size_t f=0;f<q.size();++f){auto face=field.geometry.faces[f];auto l=q[f].Value()>=0.?face.left:face.right,r=q[f].Value()>=0.?face.right:face.left;Real amount=q[f].Value()>=0.?q[f]:Real(0.)-q[f];diagonal[l]=diagonal[l]+amount;incoming[r].push_back({l,amount});}
 for(std::size_t j=0;j<ports.size();++j){auto i=ports[j].i;if(v[j].Value()>=0.)diagonal[i]=diagonal[i]+v[j];else mrhs[i]=mrhs[i]-v[j]*Real(1.2);}
 for(int iteration=0;iteration<20000;++iteration){
  for(std::size_t i=0;i<n;++i){Real w=wrhs[i],m=mrhs[i];for(auto& e:incoming[i]){w=w+e.q*alpha[e.from];m=m+e.q*gamma[e.from];}alpha[i]=w/diagonal[i];gamma[i]=m/diagonal[i];}
  double maximum=0.;
  for(std::size_t i=0;i<n;++i){Real w=wrhs[i]-diagonal[i]*alpha[i],m=mrhs[i]-diagonal[i]*gamma[i];for(auto& e:incoming[i]){w=w+e.q*alpha[e.from];m=m+e.q*gamma[e.from];}maximum=std::max(maximum,std::max(std::abs(w.Value()),std::abs(m.Value())/1.2)/field.geometry.startCapacity[i]);}
  if(maximum<=1e-12){water.resize(n);mass.resize(n);for(std::size_t i=0;i<n;++i){water[i]=alpha[i]*Real(field.geometry.startCapacity[i]);mass[i]=gamma[i]*Real(field.geometry.startCapacity[i]);}return true;}
 }
 return Fail(error,"compensated spatial transport exhausted");
}
}
bool AdvanceCutLocalPressure(const CutSpatialField& field,const CutDynamicSettings& settings,
 const std::vector<double>& seed,CutLocalPressureResult& output,std::string& error){
 const auto n=field.parent.size();if(n==0||(!seed.empty()&&seed.size()!=n)||!(settings.dt>0.))return Fail(error,"invalid local pressure input");
 const double c2=settings.soundSpeed*settings.soundSpeed;
 std::vector<double> gas(n);for(std::size_t i=0;i<n;++i)gas[i]=field.gasMass[i]/settings.gasDensity;
 std::vector<CutRegionWaterPlane> planes;
 if(!ReconstructCutRegionPhasePlanes(field.chart,field.geometry,1,field.water,gas,{},planes,error))return false;
 std::vector<Real> conductance(field.flux.size()),predictor(field.flux.size());
 std::vector<CutHydroacousticGraphLink> links;
 std::vector<std::size_t> active;
 for(std::size_t f=0;f<field.flux.size();++f){auto face=field.geometry.faces[f];if(face.meanArea==0.)continue;
  auto a=MeasureCutRegionFaceInertiaVolumes(face,field.geometry.motion,field.chart.regions[face.left],true,planes[face.left]);auto b=MeasureCutRegionFaceInertiaVolumes(face,field.geometry.motion,field.chart.regions[face.right],false,planes[face.right]);
  double inertia=settings.waterDensity*(a[0]+b[0])+settings.gasDensity*(a[1]+b[1]);
  double g=settings.dt*settings.dt*face.meanArea*face.meanArea/inertia;
  conductance[f]=g;predictor[f]=settings.dt*settings.dt*face.meanArea*settings.gravity[face.axis];links.push_back({face.left,face.right,g});active.push_back(f);
 }
 std::vector<Port> ports;
 for(auto& b:field.boundaries){auto r=field.chart.regions[b.fragment];double area=(r.hi[(b.axis+1)%3]-r.lo[(b.axis+1)%3])*(r.hi[(b.axis+2)%3]-r.lo[(b.axis+2)%3]);double g=settings.dt*settings.dt*area/(settings.gasDensity*.5*(r.hi[b.axis]-r.lo[b.axis]));ports.push_back({b.fragment,b.axis,b.sign,g,settings.dt*settings.dt*area*settings.gravity[b.axis]*b.sign});}
 CutLocalPressureResult next;next.pressure.resize(n);for(std::size_t i=0;i<n;++i)if(!seed.empty())next.pressure[i]=seed[i];
 std::vector<double> tolerance(n);std::vector<bool> small(n);std::vector<double> sorted=field.geometry.startCapacity;std::sort(sorted.begin(),sorted.end());double median=sorted[n/2];
 for(std::size_t i=0;i<n;++i){tolerance[i]=std::min(settings.volumeTolerance,settings.relativeVolumeTolerance*field.geometry.startCapacity[i]);small[i]=field.geometry.startCapacity[i]<.125*median;}
 for(int iteration=0;iteration<settings.iterationLimit;++iteration){
  next.flux.resize(field.flux.size());for(auto f:active){auto face=field.geometry.faces[f];next.flux[f]=predictor[f]+conductance[f]*(next.pressure[face.left]-next.pressure[face.right]);}
  std::vector<Real> v(ports.size());for(std::size_t j=0;j<ports.size();++j)v[j]=ports[j].predictor+ports[j].g*next.pressure[ports[j].i];
  if(!Transport(field,next.flux,ports,v,next.water,next.gasMass,error))return false;
  std::vector<Real> residual(n),rho(n);std::vector<double> rhs(n),storage(n);
  next.maximumVolumeResidual=next.maximumNormalizedResidual=0.;
  for(std::size_t i=0;i<n;++i){rho[i]=Real(settings.gasDensity)+next.pressure[i]/Real(c2);if(!(rho[i].Value()>0.))return Fail(error,"local EOS outside domain");residual[i]=Real(field.geometry.startCapacity[i])-next.water[i]-next.gasMass[i]/rho[i];rhs[i]=-residual[i].Value();storage[i]=(next.gasMass[i]/(rho[i]*rho[i]*Real(c2))).Value();next.maximumVolumeResidual=std::max(next.maximumVolumeResidual,std::abs(residual[i].Value()));next.maximumNormalizedResidual=std::max(next.maximumNormalizedResidual,std::abs(residual[i].Value())/tolerance[i]);}
  next.iterations=iteration+1;
  std::cout<<"LOCAL_PRESSURE iteration="<<iteration<<" normalized="<<next.maximumNormalizedResidual<<" residual="<<next.maximumVolumeResidual<<std::endl;
  if(next.maximumNormalizedResidual<=1.){for(std::size_t i=0;i<n;++i)if(next.water[i].Value()<0.||next.gasMass[i].Value()<0.||next.water[i].Value()>field.geometry.startCapacity[i])return Fail(error,"local phase admission failed");output=std::move(next);error.clear();return true;}
  for(auto& port:ports)storage[port.i]+=port.g.Value();
  CutCondensedResult correction;
  if(!SolveCutCondensedPressure(storage,links,rhs,tolerance,small,correction,error))return false;
  double line=1.;for(std::size_t i=0;i<n;++i)if(correction.pressure[i].Value()<0.)line=std::min(line,.9*(next.pressure[i].Value()+settings.gasDensity*c2)/(-correction.pressure[i].Value()));
  for(std::size_t i=0;i<n;++i)next.pressure[i]=next.pressure[i]+correction.pressure[i]*Real(line);
 }
 return Fail(error,"local pressure nonlinear closure exhausted");
}
}
