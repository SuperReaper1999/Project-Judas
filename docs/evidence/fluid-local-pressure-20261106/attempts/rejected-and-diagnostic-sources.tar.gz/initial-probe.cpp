#include "BasinFixture.h"
#include "CutOwnedProjection.h"
#include "CutLocalPressure.h"
#include <chrono>
#include <iostream>
#include <iomanip>
#include <limits>
#include <algorithm>
using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;
int main(){
 int failed=0;
 std::cout<<std::setprecision(17);
 for(bool rotated:{false,true}){
  auto fixture=Fixture::Authored(rotated);CutRegionChart chart;CutRegionGeometry geometry;std::string error;
  if(!PrepareCutRegionChart(fixture.layout,fixture.Walls(),fixture.InitialBox(),{-.005,-.015,-.005},{.005,.025,.005},chart,error)||!BuildCutRegionGeometry(chart,{},geometry,error)){std::cerr<<error;return 2;}
  CutDynamicState source;SeedImport imp;
  if(!WaterByRegion(fixture,chart,geometry,rotated,source.water,imp,error)){std::cerr<<error;return 2;}
  for(std::size_t i=0;i<source.water.size();++i)source.gasMass.push_back(1.2*(geometry.startCapacity[i]-source.water[i]));
  CutConnectedOwners owners;
  if(!BuildCutConnectedOwners(chart,geometry,.125,owners,error)){std::cerr<<error;return 2;}
  double min=std::numeric_limits<double>::infinity();std::size_t largest=0;
  for(std::size_t i=0;i<owners.members.size();++i){if(owners.capacity[i]>0.)min=std::min(min,owners.capacity[i]);largest=std::max(largest,owners.members[i].size());}
  std::cout<<"OWNERS rotated="<<rotated<<" fragments="<<chart.regions.size()<<" owners="<<owners.members.size()<<" minCapacity="<<min<<" maxMembers="<<largest<<std::endl;
  CutDynamicSettings settings;settings.dt=double(tick);settings.gravity={0.,-double(gravity),0.};
  CutOwnedProjection result;result.water={-7.};CutOwnedProjection trial; CutHydroacousticGraphFailure diagnostic;
  auto start=std::chrono::steady_clock::now();
  bool ok=ProjectCutOwnedMaterial(chart,geometry,owners,source,settings,{FullCutRegionGasVent(chart,1,1)},result,error,&diagnostic,&trial);
  failed+=!ok;
  std::cout<<"PROJECTION rotated="<<rotated<<" admitted="<<ok<<" unchanged="<<(result.water==std::vector<double>{-7.})<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" reason="<<error<<std::endl;
  if(!trial.pressure.empty()){
   std::vector<double> fragmentGas(source.water.size()),rho(owners.members.size());
   for(std::size_t i=0;i<fragmentGas.size();++i)fragmentGas[i]=source.gasMass[i]/1.2;
   std::vector<CutRegionWaterPlane> planes;
   if(!ReconstructCutRegionPhasePlanes(chart,geometry,1,source.water,fragmentGas,{},planes,error)){std::cerr<<error;return 2;}
   std::vector<double> mobility(geometry.faces.size()),predictor(mobility.size());
   for(std::size_t f=0;f<mobility.size();++f){auto& face=geometry.faces[f];if(face.meanArea==0.)continue;
    auto a=MeasureCutRegionFaceInertiaVolumes(face,geometry.motion,chart.regions[face.left],true,planes[face.left]);
    auto b=MeasureCutRegionFaceInertiaVolumes(face,geometry.motion,chart.regions[face.right],false,planes[face.right]);
    double mass=1000.*(a[0]+b[0])+1.2*(a[1]+b[1]);
    mobility[f]=face.meanArea*face.meanArea/mass;
    predictor[f]=settings.dt*face.meanArea*settings.dt*settings.gravity[face.axis];
   }
   for(std::size_t i=0;i<rho.size();++i)rho[i]=1.2+trial.pressure[i]/(343.*343.);
   std::vector<CutPhaseBoundary> boundaries;
   for(auto& v:trial.ventVolume)boundaries.push_back({v.fragment,1,1,v.volume,0.,true});
   if(!rotated){
    CutOwnedFlux field;std::string why;
    if(!ReconstructCutOwnedFlux(chart,geometry,owners,trial.faceVolume,trial.ventVolume,fragmentGas,predictor,mobility,field,why)){std::cout<<"FIELD "<<why<<std::endl;}
    else {
     const std::size_t cell=2844;const auto& r=chart.regions[cell];
     std::cout<<"FILM fragment="<<cell<<" owner="<<owners.owner[cell]<<" members="<<owners.members[owners.owner[cell]].size()<<" bounds="<<r.lo[0]<<","<<r.hi[0]<<";"<<r.lo[1]<<","<<r.hi[1]<<";"<<r.lo[2]<<","<<r.hi[2]<<" water="<<source.water[cell]<<" gas="<<fragmentGas[cell]<<std::endl;
     for(std::size_t f=0;f<geometry.faces.size();++f){auto& face=geometry.faces[f];if(face.left!=cell&&face.right!=cell)continue;
      auto phase=MeasureCutRegionFacePhase(face,geometry.motion,planes[face.left],planes[face.right]);double q=field.faceVolume[f];
      std::cout<<"FILM_FACE index="<<f<<" left="<<face.left<<" right="<<face.right<<" axis="<<face.axis<<" q="<<q<<" donorWet="<<phase.wet[q>=0.?0:1].mean/face.meanArea<<" sameOwner="<<(owners.owner[face.left]==owners.owner[face.right])<<std::endl;
     }
    }
   }
   CutSpatialField field;CutSpatialResult spatial,candidate;
   auto startSpatial=std::chrono::steady_clock::now();
   CutOwnedFlux full;bool lifted=ReconstructCutOwnedFlux(chart,geometry,owners,trial.faceVolume,trial.ventVolume,fragmentGas,predictor,mobility,full,error);
   bool built=lifted&&BuildCutSpatialField(chart,geometry,owners,source,full.faceVolume,boundaries,field,error,false);
   std::cout<<"SPATIAL_BUILD rotated="<<rotated<<" ok="<<built<<" cells="<<field.parent.size()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-startSpatial).count()<<" reason="<<error<<std::endl;
   if(built){
    std::vector<double> seed(field.parent.size());
    for(std::size_t i=0;i<seed.size();++i){auto parent=field.parent[i],owner=owners.owner[parent];auto region=field.chart.regions[i];double middle=.5*(region.lo[1]+region.hi[1]);double anchor=.5*(owners.lo[owner][1]+owners.hi[owner][1]);double mix=field.water[i]/field.geometry.startCapacity[i];seed[i]=trial.pressure[owner]+(1000.*mix+1.2*(1.-mix))*settings.gravity[1]*(middle-anchor);}

    double initialDefect=0.;std::size_t worst=0;
    for(std::size_t i=0;i<field.parent.size();++i){auto d=CutCompensated(field.geometry.startCapacity[i])-CutCompensated(field.water[i])-CutCompensated(field.gasMass[i])/CutCompensated(1.2);double ratio=std::abs(d.Value())/field.geometry.startCapacity[i];if(ratio>initialDefect){initialDefect=ratio;worst=i;}}
    std::cout<<"INITIAL_DEFECT normalized="<<initialDefect<<" cell="<<worst<<" capacity="<<field.geometry.startCapacity[worst]<<" water="<<field.water[worst]<<" gas="<<field.gasMass[worst]/1.2<<std::endl;
    CutLocalPressureResult advanced;settings.iterationLimit=1;
    auto start=std::chrono::steady_clock::now();bool good=AdvanceCutLocalPressure(field,settings,seed,advanced,error);
    std::cout<<"LOCAL_BASIN rotated="<<rotated<<" admitted="<<good<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" reason="<<error<<std::endl;
   }


  }
  if(diagnostic.tolerance>0.){
   std::cout<<"ROW rotated="<<rotated<<" iterations="<<diagnostic.iterations<<" owner="<<diagnostic.row<<" normalized="<<diagnostic.normalizedResidual<<std::hexfloat
    <<" storage="<<diagnostic.storage<<" rhs="<<diagnostic.source<<" tolerance="<<diagnostic.tolerance<<" pressure="<<diagnostic.pressure<<" residual="<<diagnostic.residual<<std::defaultfloat<<std::endl;
   for(const auto& neighbor:diagnostic.neighbors)std::cout<<"EDGE rotated="<<rotated<<std::hexfloat<<" g="<<neighbor.conductance<<" p="<<neighbor.pressure<<std::defaultfloat<<std::endl;
  }

 }
 return failed ? 1 : 0;
}
