#include "CutDirectedTransport.h"
#include <cmath>
#include <sstream>
namespace judas::volume_grid {
namespace {using R=CutCompensated;bool Fail(std::string& e,const char* s){e=s;return false;}}
bool CutDirectedTransport::Build(const std::vector<double>& capacity,const std::vector<CutDirectedEdge>& edges,const std::vector<R>& exterior,std::string& error){
 const auto n=capacity.size();if(n==0||exterior.size()!=n)return Fail(error,"invalid directed transport dimensions");
 capacity_=capacity;edges_=edges;exterior_=exterior;ground_.resize(n);in_.assign(n,{});out_.assign(n,{});removed_.assign(n,false);steps_.clear();
 for(std::size_t i=0;i<n;++i){if(!(capacity[i]>0.&&std::isfinite(capacity[i])&&exterior[i].Value()>=0.&&std::isfinite(exterior[i].Value())))return Fail(error,"invalid directed transport capacity");ground_[i]=R(capacity[i])+exterior[i];}
 for(auto& e:edges){if(e.from>=n||e.to>=n||e.from==e.to||!(e.amount.Value()>=0.&&std::isfinite(e.amount.Value())))return Fail(error,"invalid directed transport edge");if(e.amount.Value()==0.)continue;out_[e.from][e.to]=out_[e.from][e.to]+e.amount;in_[e.to][e.from]=in_[e.to][e.from]+e.amount;}
 for(std::size_t i=0;i<n;++i){R diagonal=ground_[i];for(auto& [j,q]:out_[i]){(void)j;diagonal=diagonal+q;}
  if(diagonal.Value()<4.*capacity[i]||in_[i].size()*out_[i].size()>64)continue;
  Step step{i,diagonal,{in_[i].begin(),in_[i].end()},{out_[i].begin(),out_[i].end()}};
  for(auto& [k,qki]:step.in){out_[k].erase(i);ground_[k]=ground_[k]+qki*(ground_[i]/diagonal);}
  for(auto& [j,qij]:step.out)in_[j].erase(i);
  for(auto& [k,qki]:step.in)for(auto& [j,qij]:step.out)if(k!=j){R q=qki*(qij/diagonal);out_[k][j]=out_[k][j]+q;in_[j][k]=in_[j][k]+q;}
  in_[i].clear();out_[i].clear();removed_[i]=true;steps_.push_back(std::move(step));
 }
 error.clear();return true;
}
bool CutDirectedTransport::Solve(const std::vector<R>& rhs,double budget,std::vector<R>& output,std::string& error)const{
 const auto n=capacity_.size();if(rhs.size()!=n||!(budget>0.&&std::isfinite(budget)))return Fail(error,"invalid directed transport right hand side");
 std::vector<R> result(n);
 double lastTotal=0.;
 for(int refinement=0;refinement<12;++refinement){
  std::vector<R> residual=rhs;
  for(std::size_t i=0;i<n;++i)residual[i]=residual[i]-(R(capacity_[i])+exterior_[i])*result[i];
  for(auto& e:edges_){R q=e.amount*result[e.from];residual[e.from]=residual[e.from]-q;residual[e.to]=residual[e.to]+q;}
  double total=0.;for(auto r:residual)total+=std::abs(r.Value());
  lastTotal=total;
  if(total<=budget){output=std::move(result);error.clear();return true;}
  for(auto& step:steps_)for(auto& [j,q]:step.out)residual[j]=residual[j]+(q/step.diagonal)*residual[step.node];
  std::vector<R> delta(n),diagonal=ground_;
  for(std::size_t i=0;i<n;++i)for(auto& [j,q]:out_[i]){(void)j;diagonal[i]=diagonal[i]+q;}
  bool solved=false;
  for(int sweep=0;sweep<20000;++sweep){
   for(std::size_t i=0;i<n;++i)if(!removed_[i]){R v=residual[i];for(auto& [k,q]:in_[i])v=v+q*delta[k];delta[i]=v/diagonal[i];}
   double reducedError=0.;for(std::size_t i=0;i<n;++i)if(!removed_[i]){R r=residual[i]-diagonal[i]*delta[i];for(auto& [k,q]:in_[i])r=r+q*delta[k];reducedError+=std::abs(r.Value());}
   if(reducedError<=std::max(budget*.01,total*1e-5)){solved=true;break;}
  }
  if(!solved)return Fail(error,"directed reduced transport exhausted");
  for(std::size_t j=steps_.size();j-->0;){auto& step=steps_[j];R v=residual[step.node];for(auto& [k,q]:step.in)v=v+q*delta[k];delta[step.node]=v/step.diagonal;}
  for(std::size_t i=0;i<n;++i)result[i]=result[i]+delta[i];
 }
 std::ostringstream report;report.precision(17);report<<"directed original quantity audit exhausted total="<<lastTotal<<" budget="<<budget;error=report.str();return false;
}
}
