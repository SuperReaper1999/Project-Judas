#include "CutLocalPressure.h"
#include "CutDirectedTransport.h"
#include <algorithm>
#include <cmath>
#include <iostream>
namespace judas::volume_grid {
namespace {
using Real=CutCompensated;
bool Fail(std::string& error,const char* reason){error=reason;return false;}
struct Port{std::size_t i;int axis,sign;Real g,predictor;};
bool Transport(const CutSpatialField& field,const std::vector<Real>& q,const std::vector<Port>& ports,
 const std::vector<Real>& v,std::vector<Real>& water,std::vector<Real>& mass,std::string& error){
 const auto n=field.parent.size();
 std::vector<CutDirectedEdge> edges;std::vector<Real> exterior(n),wrhs(n),mrhs(n),alpha,gamma;
 for(std::size_t i=0;i<n;++i){wrhs[i]=field.water[i];mrhs[i]=field.gasMass[i];}
 for(std::size_t f=0;f<q.size();++f){auto face=field.geometry.faces[f];if(q[f].Value()>=0.)edges.push_back({face.left,face.right,q[f]});else edges.push_back({face.right,face.left,Real(0.)-q[f]});}
 for(std::size_t j=0;j<ports.size();++j){auto i=ports[j].i;if(v[j].Value()>=0.)exterior[i]=exterior[i]+v[j];else mrhs[i]=mrhs[i]-v[j]*Real(1.2);}
 CutDirectedTransport linear;
 if(!linear.Build(field.geometry.startCapacity,edges,exterior,error))return false;
 const double budget=*std::min_element(field.geometry.startCapacity.begin(),field.geometry.startCapacity.end())*1e-12;
 if(!linear.Solve(wrhs,budget,alpha,error)||!linear.Solve(mrhs,1.2*budget,gamma,error))return false;
 water.resize(n);mass.resize(n);for(std::size_t i=0;i<n;++i){water[i]=alpha[i]*Real(field.geometry.startCapacity[i]);mass[i]=gamma[i]*Real(field.geometry.startCapacity[i]);}return true;
}
}
bool AdvanceCutLocalPressure(const CutSpatialField& field,const CutDynamicSettings& settings,
 const std::vector<double>& seed,CutLocalPressureResult& output,std::string& error){
 const auto n=field.parent.size();if(n==0||(!seed.empty()&&seed.size()!=n)||!(settings.dt>0.))return Fail(error,"invalid local pressure input");
 const double c2=settings.soundSpeed*settings.soundSpeed;
 std::vector<double> gas(n);for(std::size_t i=0;i<n;++i)gas[i]=field.gasMass[i]/settings.gasDensity;
 std::vector<CutRegionWaterPlane> planes;
 if(!ReconstructCutRegionPhasePlanes(field.chart,field.geometry,1,field.water,gas,{},planes,error))return false;
 std::vector<Real> conductance(field.flux.size()),predictor(field.flux.size());
 std::vector<CutHydroacousticGraphLink> links;
 std::vector<std::size_t> active;
 for(std::size_t f=0;f<field.flux.size();++f){auto face=field.geometry.faces[f];if(face.meanArea==0.)continue;
  auto a=MeasureCutRegionFaceInertiaVolumes(face,field.geometry.motion,field.chart.regions[face.left],true,planes[face.left]);auto b=MeasureCutRegionFaceInertiaVolumes(face,field.geometry.motion,field.chart.regions[face.right],false,planes[face.right]);
  double inertia=settings.waterDensity*(a[0]+b[0])+settings.gasDensity*(a[1]+b[1]);
  double g=settings.dt*settings.dt*face.meanArea*face.meanArea/inertia;
  conductance[f]=g;predictor[f]=settings.dt*settings.dt*face.meanArea*settings.gravity[face.axis];links.push_back({face.left,face.right,g});active.push_back(f);
 }
 std::vector<Port> ports;
 for(auto& b:field.boundaries){auto r=field.chart.regions[b.fragment];double area=(r.hi[(b.axis+1)%3]-r.lo[(b.axis+1)%3])*(r.hi[(b.axis+2)%3]-r.lo[(b.axis+2)%3]);double g=settings.dt*settings.dt*area/(settings.gasDensity*.5*(r.hi[b.axis]-r.lo[b.axis]));ports.push_back({b.fragment,b.axis,b.sign,g,settings.dt*settings.dt*area*settings.gravity[b.axis]*b.sign});}
 CutLocalPressureResult next;next.pressure.resize(n);for(std::size_t i=0;i<n;++i)if(!seed.empty())next.pressure[i]=seed[i];
 std::vector<double> tolerance(n);std::vector<bool> small(n);std::vector<double> sorted=field.geometry.startCapacity;std::sort(sorted.begin(),sorted.end());double median=sorted[n/2];
 for(std::size_t i=0;i<n;++i){tolerance[i]=std::min(settings.volumeTolerance,settings.relativeVolumeTolerance*field.geometry.startCapacity[i]);small[i]=field.geometry.startCapacity[i]<.125*median;}
 for(int iteration=0;iteration<settings.iterationLimit;++iteration){
  next.flux.resize(field.flux.size());for(auto f:active){auto face=field.geometry.faces[f];next.flux[f]=predictor[f]+conductance[f]*(next.pressure[face.left]-next.pressure[face.right]);}
  std::vector<Real> v(ports.size());for(std::size_t j=0;j<ports.size();++j)v[j]=ports[j].predictor+ports[j].g*next.pressure[ports[j].i];
  if(!Transport(field,next.flux,ports,v,next.water,next.gasMass,error))return false;
  std::vector<Real> residual(n),rho(n);std::vector<double> rhs(n),storage(n);
  next.maximumVolumeResidual=next.maximumNormalizedResidual=0.;
  for(std::size_t i=0;i<n;++i){rho[i]=Real(settings.gasDensity)+next.pressure[i]/Real(c2);if(!(rho[i].Value()>0.))return Fail(error,"local EOS outside domain");residual[i]=Real(field.geometry.startCapacity[i])-next.water[i]-next.gasMass[i]/rho[i];rhs[i]=-residual[i].Value();storage[i]=(next.gasMass[i]/(rho[i]*rho[i]*Real(c2))).Value();next.maximumVolumeResidual=std::max(next.maximumVolumeResidual,std::abs(residual[i].Value()));next.maximumNormalizedResidual=std::max(next.maximumNormalizedResidual,std::abs(residual[i].Value())/tolerance[i]);}
  next.iterations=iteration+1;
  std::cout<<"LOCAL_PRESSURE iteration="<<iteration<<" normalized="<<next.maximumNormalizedResidual<<" residual="<<next.maximumVolumeResidual<<std::endl;
  if(next.maximumNormalizedResidual<=1.){for(std::size_t i=0;i<n;++i)if(next.water[i].Value()<0.||next.gasMass[i].Value()<0.||(next.water[i]-Real(field.geometry.startCapacity[i])).Value()>tolerance[i])return Fail(error,"local phase admission failed");output=std::move(next);error.clear();return true;}
  for(auto& port:ports)storage[port.i]+=port.g.Value();
  // Right-preconditioned GMRES applies the derivative of the actual
  // implicit two-material transport, not a frozen phase pressure graph.
  auto jacobian=[&](const std::vector<double>& direction,std::vector<double>& applied)->bool{
   struct In{std::size_t donor;Real q;};std::vector<std::vector<In>> incoming(n);
   std::vector<Real> diagonal(n),dw(n),dm(n),aw(n),am(n),alpha(n),gamma(n);
   for(std::size_t i=0;i<n;++i){diagonal[i]=field.geometry.startCapacity[i];alpha[i]=next.water[i]/diagonal[i];gamma[i]=next.gasMass[i]/diagonal[i];}
   for(auto f:active){auto face=field.geometry.faces[f];Real q=next.flux[f],dq=conductance[f]*(Real(direction[face.left])-Real(direction[face.right]));
    auto from=q.Value()>=0.?face.left:face.right,to=q.Value()>=0.?face.right:face.left;
    if(q.Value()<0.){q=Real(0.)-q;dq=Real(0.)-dq;}
    diagonal[from]=diagonal[from]+q;incoming[to].push_back({from,q});
    dw[from]=dw[from]-dq*alpha[from];dw[to]=dw[to]+dq*alpha[from];dm[from]=dm[from]-dq*gamma[from];dm[to]=dm[to]+dq*gamma[from];
   }
   for(std::size_t j=0;j<ports.size();++j){auto i=ports[j].i;Real dq=ports[j].g*Real(direction[i]);
    if(v[j].Value()>=0.){diagonal[i]=diagonal[i]+v[j];dw[i]=dw[i]-dq*alpha[i];dm[i]=dm[i]-dq*gamma[i];}else dm[i]=dm[i]-dq*Real(settings.gasDensity);
   }
   std::vector<CutDirectedEdge> tangentEdges;std::vector<Real> exterior(n);
   for(std::size_t i=0;i<n;++i)for(auto& edge:incoming[i])tangentEdges.push_back({edge.donor,i,edge.q});
   for(std::size_t j=0;j<ports.size();++j)if(v[j].Value()>=0.)exterior[ports[j].i]=exterior[ports[j].i]+v[j];
   CutDirectedTransport linear;if(!linear.Build(field.geometry.startCapacity,tangentEdges,exterior,error))return false;
   double budget=*std::min_element(field.geometry.startCapacity.begin(),field.geometry.startCapacity.end())*1e-12;
   if(!linear.Solve(dw,budget,aw,error)||!linear.Solve(dm,1.2*budget,am,error))return false;
   applied.resize(n);for(std::size_t i=0;i<n;++i){Real derivative=(Real(0.)-aw[i]-am[i]/rho[i])*Real(field.geometry.startCapacity[i])+next.gasMass[i]*Real(direction[i])/(rho[i]*rho[i]*Real(c2));applied[i]=derivative.Value()/field.geometry.startCapacity[i];}return true;
  };
  auto dot=[](const std::vector<double>& a,const std::vector<double>& b){long double sum=0.;for(std::size_t i=0;i<a.size();++i)sum+=static_cast<long double>(a[i])*b[i];return double(sum);};
  std::vector<double> b(n);for(std::size_t i=0;i<n;++i)b[i]=-residual[i].Value()/field.geometry.startCapacity[i];
  const double norm=std::sqrt(dot(b,b));
  std::vector<std::vector<double>> basis(1,b),directions;for(auto& value:basis[0])value/=norm;
  constexpr int width=30;std::vector<std::vector<double>> hessenberg(width+1,std::vector<double>(width));
  std::vector<double> cosine(width),sine(width),projection(width+1);projection[0]=norm;int used=0;
  for(int k=0;k<width;++k){
   std::vector<double> preRhs(n),preTol(n);for(std::size_t i=0;i<n;++i){preRhs[i]=basis[k][i]*field.geometry.startCapacity[i];}
   for(std::size_t i=0;i<n;++i)preTol[i]=1e-5*field.geometry.startCapacity[i];
   CutCondensedResult preconditioned;if(!SolveCutCondensedPressure(storage,links,preRhs,preTol,small,preconditioned,error))return false;
   std::vector<double> direction(n),w;for(std::size_t i=0;i<n;++i)direction[i]=preconditioned.pressure[i].Value();
   if(!jacobian(direction,w))return false;
   directions.push_back(std::move(direction));
   for(int orthogonalize=0;orthogonalize<2;++orthogonalize)for(int j=0;j<=k;++j){double d=dot(w,basis[j]);hessenberg[j][k]+=d;for(std::size_t i=0;i<n;++i)w[i]-=d*basis[j][i];}
   hessenberg[k+1][k]=std::sqrt(dot(w,w));
   if(hessenberg[k+1][k]>0.){for(auto& x:w)x/=hessenberg[k+1][k];basis.push_back(std::move(w));}
   for(int j=0;j<k;++j){double a=hessenberg[j][k],bb=hessenberg[j+1][k];hessenberg[j][k]=cosine[j]*a+sine[j]*bb;hessenberg[j+1][k]=-sine[j]*a+cosine[j]*bb;}
   double length=std::hypot(hessenberg[k][k],hessenberg[k+1][k]);if(!(length>0.))return Fail(error,"singular coupled pressure Krylov direction");
   cosine[k]=hessenberg[k][k]/length;sine[k]=hessenberg[k+1][k]/length;hessenberg[k][k]=length;hessenberg[k+1][k]=0.;
   projection[k+1]=-sine[k]*projection[k];projection[k]*=cosine[k];used=k+1;
   if(std::abs(projection[k+1])<std::max(1e-12,norm*.01)||basis.size()<=std::size_t(k+1))break;
  }
  std::vector<double> weights(used);for(int k=used;k-->0;){double value=projection[k];for(int j=k+1;j<used;++j)value-=hessenberg[k][j]*weights[j];weights[k]=value/hessenberg[k][k];}
  std::vector<Real> dp(n);for(int k=0;k<used;++k)for(std::size_t i=0;i<n;++i)dp[i]=dp[i]+Real(directions[k][i])*Real(weights[k]);
  double line=1.;for(std::size_t i=0;i<n;++i)if(dp[i].Value()<0.)line=std::min(line,.9*(next.pressure[i].Value()+settings.gasDensity*c2)/(-dp[i].Value()));
  bool accepted=false;
  for(int backtrack=0;backtrack<24;++backtrack){
   std::vector<Real> trialP(n),trialQ(next.flux.size()),trialV(ports.size()),trialW,trialM;
   for(std::size_t i=0;i<n;++i)trialP[i]=next.pressure[i]+dp[i]*Real(line);
   for(auto f:active){auto face=field.geometry.faces[f];trialQ[f]=predictor[f]+conductance[f]*(trialP[face.left]-trialP[face.right]);}
   for(std::size_t j=0;j<ports.size();++j)trialV[j]=ports[j].predictor+ports[j].g*trialP[ports[j].i];
   if(!Transport(field,trialQ,ports,trialV,trialW,trialM,error))return false;
   double merit=0.;for(std::size_t i=0;i<n;++i){Real r=Real(field.geometry.startCapacity[i])-trialW[i]-trialM[i]/(Real(settings.gasDensity)+trialP[i]/Real(c2));double normalized=r.Value()/field.geometry.startCapacity[i];merit+=normalized*normalized;}
   if(std::sqrt(merit)<norm*(1.-1e-4*line)){next.pressure=std::move(trialP);accepted=true;break;}line*=.5;
  }
  std::cout<<"NEWTON_STEP krylov="<<used<<" predictedResidual="<<std::abs(projection[used])/norm<<" line="<<line<<std::endl;
  if(!accepted)return Fail(error,"coupled pressure line search exhausted");

 }
 return Fail(error,"local pressure nonlinear closure exhausted");
}
}
