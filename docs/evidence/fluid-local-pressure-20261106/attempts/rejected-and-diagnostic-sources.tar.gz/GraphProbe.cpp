#include "CutCondensedPressure.h"
#include <chrono>
#include <algorithm>
#include <iostream>
namespace judas::volume_grid {
bool SolveCutHydroacousticGraphLocalBaseline(const std::vector<double>&,const std::vector<CutHydroacousticGraphLink>&,const std::vector<double>&,const std::vector<double>&,CutHydroacousticGraphResult&,std::string&,CutHydroacousticGraphFailure*);
bool SolveCutHydroacousticGraphLocal(const std::vector<double>& s,const std::vector<CutHydroacousticGraphLink>& links,const std::vector<double>& rhs,const std::vector<double>& tol,CutHydroacousticGraphResult& out,std::string& error,CutHydroacousticGraphFailure* diagnostic){
 if(s.size()<100000)return SolveCutHydroacousticGraphLocalBaseline(s,links,rhs,tol,out,error,diagnostic);
 auto sorted=tol;std::sort(sorted.begin(),sorted.end());double median=sorted[sorted.size()/2];std::vector<bool> tiny(s.size());for(std::size_t i=0;i<s.size();++i)tiny[i]=tol[i]<median*.125;
 CutCondensedResult result;auto begin=std::chrono::steady_clock::now();bool ok=SolveCutCondensedPressure(s,links,rhs,tol,tiny,result,error);
 std::cout<<"CONDENSED_LINEAR nodes="<<s.size()<<" ok="<<ok<<" eliminated="<<result.eliminated<<" retained="<<result.reduced<<" refinements="<<result.refinements<<" normalizedResidual="<<result.maximumNormalizedResidual<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count()<<" reason="<<error<<std::endl;
 error="diagnostic pressure solve only; compensated state not cast to physical output";return false;
}
}
