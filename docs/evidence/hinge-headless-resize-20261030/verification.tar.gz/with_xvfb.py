from pathlib import Path
import os,sys,subprocess,selectors,json
r=Path.cwd();d=r/'.cache/hinge-resize-correction-20261030';xvfb=r/'.cache/prealpha-elastic-linux/ubuntu24/usr/bin/Xvfb'
with (d/'xvfb.log').open('a') as log:
 server=subprocess.Popen([str(xvfb),'-displayfd','1','-screen','0','1600x1600x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=log,text=True)
 try:
  selector=selectors.DefaultSelector();selector.register(server.stdout,selectors.EVENT_READ)
  if not selector.select(10):raise RuntimeError('Xvfb startup timed out')
  number=server.stdout.readline().strip()
  if not number.isdigit():raise RuntimeError('Xvfb did not publish a display; inspect log')
  env=dict(os.environ,DISPLAY=':'+number,SDL_VIDEODRIVER='x11',LIBGL_ALWAYS_SOFTWARE='1',GALLIUM_DRIVER='llvmpipe',SDL_AUDIODRIVER='dummy',XDG_DATA_HOME=str(d/'userdata'),JUDAS_WORLD_STATE='none')
  p=subprocess.run(sys.argv[1:],env=env,timeout=180)
  raise SystemExit(p.returncode)
 finally:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait()
