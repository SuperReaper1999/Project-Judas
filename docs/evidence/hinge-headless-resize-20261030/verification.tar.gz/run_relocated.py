from pathlib import Path
import json,subprocess,os
r=Path(__file__).resolve().parents[2];d=r/'.cache/hinge-resize-correction-20261030';p=Path(json.loads((d/'relocation.json').read_text())['path'])
# The exported runtime receives no source project argument and launches from /tmp.
# Create the harness through the same driver, but launch it with unrelated cwd.
script=d/'relocated.harness';script.write_text(f"FRAMES 8\nLOG_EVERY 0\nEXPECT_VIEWPORT 800 360 0\nRESIZE 360 800 1\nEXPECT_VIEWPORT 360 800 1\nSCREENSHOT 3 {d}/relocated-portrait.png\nRESIZE 1200 540 4\nEXPECT_VIEWPORT 1200 540 4\nSCREENSHOT 6 {d}/relocated-wide.png\n")
env=dict(os.environ,JUDAS_WINDOW_SIZE='800x360',JUDAS_TEST_SCRIPT=str(script))
command=[str(p/'judas')];result=subprocess.run(command,cwd='/tmp',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120);(d/'relocated.log').write_text(result.stdout);(d/'relocated-receipt.json').write_text(json.dumps({'command':command,'cwd':'/tmp','exit':result.returncode},indent=2)+'\n');print('Relocated exit:',result.returncode);raise SystemExit(result.returncode)
