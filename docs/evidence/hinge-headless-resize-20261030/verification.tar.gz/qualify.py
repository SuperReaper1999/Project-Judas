from pathlib import Path
import os,subprocess,json,sys,hashlib
r=Path.cwd();d=r/'.cache/hinge-resize-correction-20261030';mode=sys.argv[1];rows=[]
def run(name,cmd,expected=0):
 env=dict(os.environ,SDL_AUDIODRIVER='dummy',XDG_DATA_HOME=str(d/('userdata-'+mode)),JUDAS_WORLD_STATE='none')
 if mode=='headless':cmd=['python3',str(d/'with_xvfb.py'),*map(str,cmd)]
 p=subprocess.run(list(map(str,cmd)),env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
 (d/(name+'.log')).write_text(p.stdout);rows.append({'name':name,'command':list(map(str,cmd)),'exit':p.returncode,'expected':expected})
 (d/(mode+'-qualification.json')).write_text(json.dumps(rows,indent=2)+'\n')
 if p.returncode!=expected:raise RuntimeError(name+' unexpected exit; inspect log')
run(mode+'-pointer',[r/'build/judas_pointer_harness_tests',d/(mode+'-pointer-output')])
run(mode+'-application',[r/'build/judas_project_application_tests'])
run(mode+'-hinge',['python3',d/'run_hinge.py',r/'build/judas',mode])
if mode=='headless':run('extended-original-negative',[d/'extended-before-pointer',d/'extended-original-output'],1)
print(mode,'qualification passed')
