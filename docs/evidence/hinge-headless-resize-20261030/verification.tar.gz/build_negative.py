from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();d=r/'.cache/hinge-resize-correction-20261030';source=d/'original-Window.cpp';source.write_bytes(subprocess.check_output(['git','show','824f5661:src/Window.cpp']))
flags={}
for line in (r/'build/CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
obj=d/'original-Window.o';command=['/usr/bin/c++',*flags['CXX_DEFINES'],*flags['CXX_INCLUDES'],*flags['CXX_FLAGS'],'-c',str(source),'-o',str(obj)]
compiled=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(d/'negative-compile.log').write_text(compiled.stdout);assert compiled.returncode==0
link=shlex.split((r/'build/CMakeFiles/judas_pointer_harness_tests.dir/link.txt').read_text());link=[x for x in link if not x.startswith('-Wl,--dependency-file=')];link.insert(1,str(obj));link[link.index('-o')+1]=str(d/'extended-before-pointer')
p=subprocess.run(link,cwd=r/'build',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(d/'negative-link.log').write_text(p.stdout);assert p.returncode==0
(d/'negative-build.json').write_text(json.dumps({'compile':command,'link':link,'cwd':str(r/'build'),'source':'824f5661:src/Window.cpp','test':'unchanged final extended pointer harness'},indent=2)+'\n')
