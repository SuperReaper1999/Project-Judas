from pathlib import Path
import subprocess,os,sys,json
r=Path.cwd();d=r/'.cache/hinge-resize-correction-20261030';label=sys.argv[2];exe=Path(sys.argv[1]).resolve()
script=d/(label+'.harness');script.write_text(f'''FRAMES 18
LOG_EVERY 0
EXPECT_VIEWPORT 800 360 0
SCREENSHOT 2 {d}/{label}-landscape.png
RESIZE 360 800 4
EXPECT_VIEWPORT 360 800 4
SCREENSHOT 6 {d}/{label}-portrait.png
RESIZE 1200 540 8
EXPECT_VIEWPORT 1200 540 8
SCREENSHOT 10 {d}/{label}-wide.png
RESIZE 540 1200 12
EXPECT_VIEWPORT 540 1200 12
SCREENSHOT 14 {d}/{label}-tall.png
''')
env=dict(os.environ,JUDAS_TEST_SCRIPT=str(script),JUDAS_WINDOW_SIZE='800x360');cmd=[str(exe)]+([] if '--packaged' in sys.argv[3:] else [str(r/'.cache/hinge-feature-review-20261030/hinge/hinge.judasproj')])
p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120);(d/(label+'.log')).write_text(p.stdout)
(d/(label+'-receipt.json')).write_text(json.dumps({'command':cmd,'exit':p.returncode,'script':str(script),'videoDriver':env.get('SDL_VIDEODRIVER'),'software':env.get('LIBGL_ALWAYS_SOFTWARE')},indent=2)+'\n');print(label,'exit',p.returncode);raise SystemExit(p.returncode)
