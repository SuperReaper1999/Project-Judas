#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <SDL2/SDL_syswm.h>
#include <X11/Xlib.h>
#include <cstdio>
#include <cstdlib>
int main(int argc,char** argv){
 if(SDL_Init(SDL_INIT_VIDEO)!=0){std::fprintf(stderr,"%s\n",SDL_GetError());return 2;}
 const int selected=argc>1?std::atoi(argv[1]):-1;
 for(int mode=0;mode<=5;++mode){if(selected>=0&&mode!=selected)continue;
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,3);SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,3);SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_CORE);
  auto* w=SDL_CreateWindow("isolated resize probe",0,0,800,360,SDL_WINDOW_OPENGL|SDL_WINDOW_HIDDEN|SDL_WINDOW_RESIZABLE);if(!w){std::puts(SDL_GetError());return 2;}
  auto ctx=SDL_GL_CreateContext(w);if(!ctx){std::puts(SDL_GetError());return 2;}SDL_GL_SetSwapInterval(0);
  glClearColor(0,1,0,1);glClear(GL_COLOR_BUFFER_BIT);glFinish(); // allocate the original backbuffer
  SDL_SetWindowSize(w,360,800);SDL_PumpEvents();
  if(mode==1)SDL_GL_MakeCurrent(w,ctx);
  if(mode==2){SDL_GL_MakeCurrent(w,nullptr);SDL_GL_MakeCurrent(w,ctx);}
  if(mode==3)SDL_GL_SwapWindow(w);
  if(mode==4){SDL_ShowWindow(w);SDL_PumpEvents();SDL_HideWindow(w);SDL_PumpEvents();}
  if(mode==5){auto wait=(void(*)())SDL_GL_GetProcAddress("glXWaitX");if(wait)wait();}
  SDL_SysWMinfo wm{};SDL_VERSION(&wm.version);int nw=0,nh=0;
  if(SDL_GetWindowWMInfo(w,&wm)&&wm.subsystem==SDL_SYSWM_X11){XWindowAttributes a{};XGetWindowAttributes(wm.info.x11.display,wm.info.x11.window,&a);nw=a.width;nh=a.height;}
  int dw,dh;SDL_GL_GetDrawableSize(w,&dw,&dh);glViewport(0,0,360,800);glClear(GL_COLOR_BUFFER_BIT);unsigned char p[4]={};glReadPixels(350,790,1,1,GL_RGBA,GL_UNSIGNED_BYTE,p);
  std::printf("mode=%d driver=%s native=%dx%d reported=%dx%d far_pixel=%u,%u,%u GL=%s renderer=%s error=%x\n",mode,SDL_GetCurrentVideoDriver(),nw,nh,dw,dh,p[0],p[1],p[2],glGetString(GL_VERSION),glGetString(GL_RENDERER),glGetError());
  SDL_GL_DeleteContext(ctx);SDL_DestroyWindow(w);
 }
 SDL_Quit();return 0;
}
