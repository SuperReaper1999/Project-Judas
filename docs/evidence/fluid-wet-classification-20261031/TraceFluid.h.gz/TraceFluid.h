#pragma once
#include "FluidHydrostatics.h"
#include <iostream>
#include <iomanip>
extern std::ostream* fluidTrace;
class TraceFluidHydrostaticField {
public:
    void Build(const std::vector<FluidParticle>& particles, float restDensity,
               const std::vector<bool>* excludedParticles = nullptr);
    FluidFieldSample Query(const glm::vec3& point, const glm::vec3& up,
                           float sampleHalfHeight, float extrapolationRadius,
                           const glm::vec3& tangentAxis,
                           const FluidSolidQuery* solid = nullptr) const;
    float RestDensity() const { return m_density; }
    float MaximumParticleSpacing() const { return m_maxSpacing; }
    std::size_t ParticleCount() const { return m_particles.size(); }
private:
    struct Particle { glm::vec3 position, velocity, acceleration; float spacing, volume; };
    struct Key {
        std::int64_t x, y, z;
        bool operator==(const Key& b) const { return x == b.x && y == b.y && z == b.z; }
    };
    struct Hash { std::size_t operator()(const Key& k) const; };
    Key Cell(const glm::vec3& point) const;
    float m_density = 0, m_maxSpacing = 0, m_cellSize = 1;
    glm::vec3 m_min{0}, m_max{0};
    std::vector<Particle> m_particles;
    std::unordered_map<Key, std::vector<std::size_t>, Hash> m_cells;
    std::vector<Key> m_occupiedCells; // deterministic z/y/x traversal; no retained pointers
};
