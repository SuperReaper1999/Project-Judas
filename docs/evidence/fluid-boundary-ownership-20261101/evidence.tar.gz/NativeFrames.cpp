#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
glm::quat globalFrame{1,0,0,0};struct Uniform:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return globalFrame*glm::vec3(0,-9.81f,0);}};
double Height(int type,double x,double z){return type==0?0:type==1?.5*(x*x+z*z):type==2?-.5*(x*x+z*z):.1*std::sin(3.141592653589793*x)*std::cos(3.141592653589793*z);}
double Reference(int shape,int surface,glm::quat turn,int n){long wet=0,total=0;for(int z=0;z<n;++z)for(int y=0;y<n;++y)for(int x=0;x<n;++x){glm::dvec3 local=(glm::dvec3(2*x+1,2*y+1,2*z+1)/double(n)-1.)*.3;if(shape==1 && glm::dot(local,local)>.09)continue;auto p=glm::dquat(turn)*local;++total;wet+=p.y<Height(surface,p.x,p.z);}return double(wet)/total;}
int main(){Uniform gravity;std::cout<<std::setprecision(17)<<"shape,surface,spacing,frame,engine,reference64,reference96\n";
 for(int shape=0;shape<3;++shape)for(int surface=0;surface<4;++surface){auto turn=shape==0?glm::angleAxis(.55f,glm::normalize(glm::vec3(1,0,2))):glm::quat(1,0,0,0);double r64=Reference(shape,surface,turn,64),r96=Reference(shape,surface,turn,96);
  for(float spacing:{.25f,.125f})for(int frame=0;frame<2;++frame){globalFrame=frame?glm::angleAxis(.63f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);const glm::vec3 translation=frame?glm::vec3(1,-2,3):glm::vec3(0);std::vector<FluidParticle> particles,source;int n=int(std::round(2/spacing));for(int z=0;z<n;++z)for(int x=0;x<n;++x)for(int y=0;y<n;++y){float px=-1+(x+.5f)*spacing,pz=-1+(z+.5f)*spacing;FluidParticle p;p.position={px,float(Height(surface,px,pz))-(y+.5f)*spacing,pz};p.mass=1000*spacing*spacing*spacing;auto local=glm::conjugate(turn)*p.position;bool inside=shape==1?glm::dot(local,local)<.3f*.3f:glm::all(glm::lessThan(glm::abs(local),glm::vec3(.3f)));source.push_back(p);if(!inside)particles.push_back(p);}FluidVolumeQuadrature volume;if(shape==1)volume=MakeSphereFluidVolume(.3f);else if(shape==2)volume=MakeCompoundFluidVolume({{{-.15f,0,0},{.15f,.3f,.3f}},{{.15f,0,0},{.15f,.3f,.3f}}});else volume=MakeBoxFluidVolume(glm::vec3(.3f));BodyTransform pose;pose.rotation=globalFrame*turn;pose.position=translation;const BodyHandle owner{37,901};
 FluidSettings settings;settings.substeps=1;settings.densityIterations=0;settings.velocitySmoothing=0;
 FluidWorld fluid(settings);for(const auto& p:source)fluid.AddParticle(translation+globalFrame*p.position,p.velocity,p.mass);
 std::vector<FluidBoxCollider> boxes;std::vector<FluidSphereCollider> spheres;
 if(shape==1)spheres.push_back({owner,pose,pose,.3f});
 else for(const auto& child:volume.solidBoxes){BodyTransform p{pose.position+pose.rotation*child.localCenter,pose.rotation*child.rotation};boxes.push_back({owner,p,p,child.halfExtents});}
 struct Zero:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return glm::vec3(0);}} zero;
 fluid.Step(1.f/60,zero,boxes,spheres,std::vector<FluidTerrainCollider>{});
 FluidHydrostaticField field;field.Build(fluid.Particles(),1000);
 std::vector<FluidDisplacementMarker> cells;for(const auto& cell:fluid.DisplacementMarkers())if(cell.owner.IsValid())cells.push_back(cell);
 if(!cells.empty())field.RetainDisplacementCells(owner,volume,pose,cells);
 auto result=EvaluateFluidHydrostatics(field,volume,pose,gravity,FluidVolumeGeometry::DisplacedSolid,owner);std::cout<<shape<<','<<surface<<','<<spacing<<','<<frame<<','<<result.fraction<<','<<r64<<','<<r96<<'\n'<<std::flush;}
 }
}
