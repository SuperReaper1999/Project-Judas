#include "SceneSerialization.h"
#include "RuntimeWorld.h"
#include "Project.h"
#include "GameSession.h"
#include "Window.h"
#include "Simulation.h"
#include "ProductionFluidCoupling.h"
#include <iostream>
#include <cmath>
int main(int argc,char** argv){
 Scene scene;std::string error;if(argc!=2||!LoadSceneFromFile(argv[1],scene,error)){std::cerr<<error;return 2;}
 RuntimeWorld world;ProjectSettings settings;settings.advancedFluidDynamics=true;world.ConfigureProject(settings);
 GameSession session;Window window;window.SetTestInputMode(true);
 if(!world.Build(scene,nullptr,error)||!session.Begin(world,error)){std::cerr<<error;return 3;}
 std::cout<<"active="<<world.HasFluid()<<" initial_particles="<<world.Fluid().Particles().size()<<'\n';
 if(!world.HasFluid()||world.Fluid().Particles().empty())return 4;
 unsigned executed=0;double maxForce=0;std::vector<float> peaks(world.DynamicBodies().size());
 for(int i=0;i<1200;++i){session.HandleFrameInput(window,false,false,false,false,false);StepPlayedWorld(session,window,1.f/60);
  const auto& m=world.FluidCoupling().Measurements();executed+=m.executed;
  for(const auto& x:m.bodies)maxForce=std::max(maxForce,double(glm::length(x.buoyancyForce)));
  for(std::size_t j=0;j<peaks.size();++j){const auto h=world.DynamicBodies()[j].Handle();const auto v=world.Physics().GetLinearVelocity(h);const auto p=world.Physics().GetTransform(h).position;
   for(int k=0;k<3;++k)if(!std::isfinite(v[k])||!std::isfinite(p[k]))return 5;
   peaks[j]=std::max(peaks[j],glm::length(v));}
 }
 std::cout<<"frames=1200 executed_fluid_steps="<<executed<<" final_particles="<<world.Fluid().Particles().size()<<" max_buoyancy_force="<<maxForce<<'\n';
 for(std::size_t j=0;j<peaks.size();++j)std::cout<<"body="<<j<<" peak_speed="<<peaks[j]<<'\n';
 return executed?0:6;
}
