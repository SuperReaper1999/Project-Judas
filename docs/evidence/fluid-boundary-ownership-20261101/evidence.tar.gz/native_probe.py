from pathlib import Path
import subprocess,shlex
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build'
s=(c/'AdditionalOwned.cpp').read_text()
a=s.index('FluidHydrostaticField field;');z=s.index('auto result=EvaluateFluidHydrostatics',a)
s=s[:a]+'''BodyTransform pose;pose.rotation=turn;const BodyHandle owner{37,901};
 FluidSettings settings;settings.substeps=1;settings.densityIterations=0;settings.velocitySmoothing=0;
 FluidWorld fluid(settings);for(const auto& p:source)fluid.AddParticle(p.position,p.velocity,p.mass);
 std::vector<FluidBoxCollider> boxes;std::vector<FluidSphereCollider> spheres;
 if(shape==1)spheres.push_back({owner,pose,pose,.3f});
 else for(const auto& child:volume.solidBoxes){BodyTransform p{pose.position+turn*child.localCenter,turn*child.rotation};boxes.push_back({owner,p,p,child.halfExtents});}
 struct Zero:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return glm::vec3(0);}} zero;
 fluid.Step(1.f/60,zero,boxes,spheres,std::vector<FluidTerrainCollider>{});
 FluidHydrostaticField field;field.Build(fluid.Particles(),1000);
 std::vector<FluidDisplacementMarker> cells;for(const auto& cell:fluid.DisplacementMarkers())if(cell.owner.IsValid())cells.push_back(cell);
 if(!cells.empty())field.RetainDisplacementCells(owner,volume,pose,cells);
 '''+s[z:]
(c/'NativeCapture.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
with (c/'native-probe-build.log').open('w') as log:subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'NativeCapture.cpp'),'-o',str(c/'NativeCapture.o')],stdout=log,stderr=subprocess.STDOUT,check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'NativeCapture.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'native-capture') if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
with (c/'native-capture.csv').open('w') as log:subprocess.run([str(c/'native-capture')],stdout=log,check=True)
