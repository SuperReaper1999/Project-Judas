from pathlib import Path
import subprocess,shlex,json,hashlib,time,csv,statistics,math,os
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build'
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
s=(c/'MappedFrames.cpp').read_text().replace('#include "FluidHydrostatics.h"','#include "FluidHydrostatics.h"\n#include <fstream>',1)
s=s.replace('int main(){','int main(){std::ofstream physical("physical.bin",std::ios::binary);',1)
s=s.replace(' auto actual=fluid.Particles();auto markers=', ''' for(const auto& p:fluid.Particles()){for(const auto& v:{p.position,p.previousPosition,p.velocity,p.acceleration})for(int k=0;k<3;++k){float f=v[k];physical.write(reinterpret_cast<const char*>(&f),sizeof(f));}physical.write(reinterpret_cast<const char*>(&p.mass),sizeof(p.mass));}
 auto actual=fluid.Particles();auto markers=''')
assert 'std::ofstream physical' in s
(c/'PhysicalFrames.cpp').write_text(s)
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'PhysicalFrames.cpp'),'-o',str(c/'PhysicalFrames.o')],check=True)
def link(out,override=None):
 a=[v for v in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not v.startswith('-Wl,--dependency-file=')];a=[str(c/'PhysicalFrames.o') if v.endswith('ProductionFluidTests.cpp.o') else str(c/out) if v=='judas_production_fluid_tests' else v for v in a]
 if override:a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(override)]
 subprocess.run(a,cwd=b,check=True)
link('physical-before',c/'FluidWorld.cpp.o');link('physical-after')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();parity={}
for kind in ['before','after']:
 folder=c/('physical-'+kind+'-data');folder.mkdir(exist_ok=True)
 with (c/('physical-'+kind+'.csv')).open('w') as out,(c/('physical-'+kind+'.log')).open('w') as log:subprocess.run([str(c/('physical-'+kind))],cwd=folder,stdout=out,stderr=log,check=True)
 parity[kind]=dict(sha256=sha(folder/'physical.bin'),bytes=(folder/'physical.bin').stat().st_size,trace=(c/('physical-'+kind+'.log')).read_text())
assert parity['before']['sha256']==parity['after']['sha256'];(c/'PHYSICAL_FRAME_PARITY.json').write_text(json.dumps(parity,indent=2))
# No builds or other validation jobs overlap these matched timings.
raw=[];reference=None
for pair in range(4):
 for kind in (['before','after'] if pair%2==0 else ['after','before']):
  data=c/f'paired-{pair}-{kind}.bin';cmd=[str(c/('trajectory-'+kind)),str(data)]
  out=subprocess.check_output(cmd,text=True);(c/f'paired-{pair}-{kind}.log').write_text(out)
  digest=sha(data)
  if reference is None:reference=digest
  assert digest==reference
  raw.append(dict(pair=pair,kind=kind,command=cmd,output=out,sha256=digest))
metrics={}
for kind in ['before','after']:
 rows=[]
 for p in c.glob('paired-*-'+kind+'.bin.csv'):rows+=list(csv.DictReader(p.open()))
 metrics[kind]={}
 for field in ['wall_us','cpu_us']:
  values=sorted(float(x[field]) for x in rows);metrics[kind][field]=dict(steps=len(values),median=statistics.median(values),p95=values[math.ceil(.95*len(values))-1],worst=max(values))
(c/'COST.json').write_text(json.dumps(dict(runs=raw,metrics=metrics,note='120 steps/run, 100 real particles, identical fixed colliders and exact physical outputs; shared workstation, no concurrent builds/tests launched during pairs.'),indent=2))
print('Physical frame state parity:',parity,flush=True);print('Matched CPU/wall cost:',metrics,flush=True)
# Run the original scenes in the normal native application. Test mode hides
# the window; no authored scene, project or save is written.
(c/'long-scene.txt').write_text('FRAMES 1200\nFRAME_SECONDS 0.016666667\n')
env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':0'),XDG_RUNTIME_DIR='/run/user/1000',JUDAS_WORLD_STATE='none',JUDAS_ENGINE_ROOT=str(r),JUDAS_TEST_SCRIPT=str(c/'long-scene.txt'),JUDAS_WINDOW_SIZE='640x360')
apps=[]
for label,scene in [('original-radial','terrain.judas'),('original-flat','terrain_flat_comparison.judas')]:
 cmd=[str(b/'judas'),str(r/'assets/scenes'/scene)];start=time.monotonic()
 with (c/(label+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
  except subprocess.TimeoutExpired:code=124
 entry=dict(label=label,command=cmd,exit_code=code,seconds=time.monotonic()-start)
 text=(c/(label+'.log')).read_text();lines=text.splitlines();header=next((x for x in lines if x.startswith('step,time,')),None)
 if header:
  rows=list(csv.DictReader([header]+[x for x in lines if x.split(',')[0].isdigit()]));peaks={}
  for n in range(5):
   key=f'obj{n}';speeds=[math.sqrt(sum(float(x[key+'Vel'+a])**2 for a in 'XYZ')) for x in rows];peaks[key]=max(speeds)
   assert all(math.isfinite(float(x[key+'Pos'+a])) for x in rows for a in 'XYZ')
  entry.update(frames=len(rows),peak_body_speeds=peaks)
 apps.append(entry);(c/'APPS.json').write_text(json.dumps(apps,indent=2));print(label,entry,flush=True)
