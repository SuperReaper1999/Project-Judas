from pathlib import Path
import subprocess,json,time,os
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build';env=dict(os.environ,JUDAS_ENGINE_ROOT=str(r));results=[]
def run(name,args=[],timeout=900):
 cmd=[str(b/name),*map(str,args)];start=time.monotonic()
 with (c/('cell-'+name+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(target=name,command=cmd,exit_code=code,seconds=time.monotonic()-start));(c/'CELL_RESULTS.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
for name in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests','judas_fluid_world_tests','judas_fluid_volume_drag_tests','judas_fluid_lifecycle_qualification_tests','judas_project_fluid_policy_tests','judas_project_water_tests','judas_fluid_container_integration_tests','judas_fluid_cavity_impact_tests','judas_fluid_rigid_coupling_tests','judas_fluid_boundary_contact_tests','judas_fluid_smoothing_budget_tests']:run(name,['--supported-only','--output',c/'cell-containers'] if name=='judas_fluid_container_integration_tests' else [])
subprocess.run(['python3',str(c/'known_owned.py')],check=True)
run('judas_fluid_known_geometry_tests',['--output',c/'cell-legacy-known.csv'])
run('judas_production_fluid_tests',['--output',c/'cell-production'])
run('judas_fluid_demo_integration_tests',['--output',c/'cell-demos'])
run('judas_player_fluid_integration_tests',['--output',c/'cell-player'])
