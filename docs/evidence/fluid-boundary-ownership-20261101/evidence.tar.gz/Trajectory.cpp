#include "FluidWorld.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <ctime>
#include <algorithm>
#include <vector>
struct Uniform:GravityField{glm::vec3 g;explicit Uniform(glm::vec3 v):g(v){}glm::vec3 Sample(const glm::vec3&)const override{return g;}};
int main(int argc,char**argv){if(argc!=2)return 2;std::ofstream out(argv[1],std::ios::binary);std::size_t retained=0,markerBytes=0;double mass=0;std::vector<double> wall,cpu;
 for(int frame=0;frame<2;++frame){const auto q=frame?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);const auto t=frame?glm::vec3(2,-1,3):glm::vec3(0);auto pose=[&](glm::vec3 p){return BodyTransform{t+q*p,q};};
  FluidWorld fluid;for(int z=0;z<5;++z)for(int x=0;x<5;++x)for(int y=0;y<4;++y)fluid.AddParticle(t+q*glm::vec3(-.4f+.2f*x,-.65f+.2f*y,-.4f+.2f*z),glm::vec3(0),3.375f);
  const Uniform g(q*glm::vec3(0,-9.81f,0));const auto floor=pose({0,-.9f,0}),block=pose({0,-.2f,0}),ball=pose({.5f,-.3f,0});
  for(int step=0;step<60;++step){const auto t0=std::chrono::steady_clock::now();const auto c0=std::clock();fluid.Step(1.f/60,g,{{{11,701},floor,floor,{2,.1f,2}},{{12,701},block,block,{.25f,.25f,.25f}}},{{{13,701},ball,ball,.2f}},std::vector<FluidTerrainCollider>{});
   cpu.push_back(double(std::clock()-c0)*1e6/CLOCKS_PER_SEC);
   wall.push_back(std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-t0).count());
   markerBytes=std::max(markerBytes,fluid.DisplacementMarkers().capacity()*sizeof(FluidDisplacementMarker));
   for(const auto& p:fluid.Particles()){for(const auto& v:{p.position,p.previousPosition,p.velocity,p.acceleration})for(int k=0;k<3;++k){const float f=v[k];out.write(reinterpret_cast<const char*>(&f),sizeof(f));}out.write(reinterpret_cast<const char*>(&p.mass),sizeof(p.mass));}
   for(const auto& m:fluid.DisplacementMarkers())retained+=m.owner.IsValid();
  }
  mass+=fluid.GetDiagnostics().totalMass;
 }
 std::ofstream timings(std::string(argv[1])+".csv");timings<<"step,wall_us,cpu_us\n";for(std::size_t i=0;i<wall.size();++i)timings<<i<<','<<wall[i]<<','<<cpu[i]<<'\n';
 std::sort(wall.begin(),wall.end());std::sort(cpu.begin(),cpu.end());
 std::cout<<std::setprecision(17)<<"wall_median_us="<<(wall[59]+wall[60])*.5<<" wall_p95_us="<<wall[113]<<" wall_worst_us="<<wall.back()<<" cpu_median_us="<<(cpu[59]+cpu[60])*.5<<" marker_bytes="<<markerBytes<<" marker_size="<<sizeof(FluidDisplacementMarker)<<" "<<"retained_observations="<<retained<<" final_mass_sum="<<mass<<'\n';return out?0:1;
}
