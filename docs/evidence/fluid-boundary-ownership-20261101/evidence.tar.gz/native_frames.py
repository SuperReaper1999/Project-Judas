from pathlib import Path
import subprocess,shlex,csv,json
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build'
s=(c/'NativeCapture.cpp').read_text().replace('struct Uniform:', 'glm::quat globalFrame{1,0,0,0};struct Uniform:').replace('return {0,-9.81f,0};','return globalFrame*glm::vec3(0,-9.81f,0);')
s=s.replace('for(float spacing:{.25f,.125f}){','for(float spacing:{.25f,.125f})for(int frame=0;frame<2;++frame){globalFrame=frame?glm::angleAxis(.63f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);const glm::vec3 translation=frame?glm::vec3(1,-2,3):glm::vec3(0);')
s=s.replace('pose.rotation=turn;','pose.rotation=globalFrame*turn;pose.position=translation;')
s=s.replace('fluid.AddParticle(p.position,p.velocity,p.mass);','fluid.AddParticle(translation+globalFrame*p.position,p.velocity,p.mass);')
s=s.replace('pose.position+turn*child.localCenter,turn*child.rotation','pose.position+pose.rotation*child.localCenter,pose.rotation*child.rotation')
s=s.replace('shape,surface,spacing,engine', 'shape,surface,spacing,frame,engine').replace("<<spacing<<','<<result.fraction", "<<spacing<<','<<frame<<','<<result.fraction")
(c/'NativeFrames.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'NativeFrames.cpp'),'-o',str(c/'NativeFrames.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'NativeFrames.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'native-frames') if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
with (c/'native-frames.csv').open('w') as log:subprocess.run([str(c/'native-frames')],stdout=log,check=True)
rows=list(csv.DictReader((c/'native-frames.csv').open()));idx={(x['shape'],x['surface'],x['spacing'],x['frame']):x for x in rows}
diffs=[abs(float(x['engine'])-float(idx[(x['shape'],x['surface'],x['spacing'],'1')]['engine'])) for x in rows if x['frame']=='0']
result=dict(cases=len(rows),accuracy_failures=sum(abs(float(x['engine'])-float(x['reference96']))>.10 for x in rows),frame_failures=sum(x>.001 for x in diffs),worst_frame_difference=max(diffs))
(c/'NATIVE_FRAMES.json').write_text(json.dumps(result,indent=2));print(result)
