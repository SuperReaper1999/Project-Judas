from pathlib import Path
import subprocess,shlex
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build'
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text()
def get(k):return shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'OriginalScenes.cpp'),'-o',str(c/'OriginalScenes.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
a=[str(c/'OriginalScenes.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'original-scenes') if x=='judas_production_fluid_tests' else x for x in a]
subprocess.run(a,cwd=b,check=True)
for label,scene in [('radial','terrain.judas'),('flat','terrain_flat_comparison.judas')]:
 with (c/('verified-original-'+label+'.log')).open('w') as out:
  subprocess.run([str(c/'original-scenes'),str(r/'assets/scenes'/scene)],stdout=out,stderr=subprocess.STDOUT,timeout=240,check=True)
