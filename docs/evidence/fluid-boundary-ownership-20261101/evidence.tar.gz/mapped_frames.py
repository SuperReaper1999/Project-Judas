from pathlib import Path
import subprocess,shlex,csv,json
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build'
s=(c/'NativeFrames.cpp').read_text().replace('glm::quat globalFrame{1,0,0,0};','glm::quat globalFrame{1,0,0,0};\nstd::vector<FluidParticle> referenceParticles;std::vector<FluidDisplacementMarker> referenceCells;double physicalDifference=0;')
a=s.index(' FluidHydrostaticField field;field.Build(fluid.Particles(),1000);');z=s.index(' if(!cells.empty())',a)
s=s[:a]+''' auto actual=fluid.Particles();auto markers=fluid.DisplacementMarkers();
 if(frame==0){referenceParticles=actual;referenceCells=markers;}
 else {
   for(std::size_t i=0;i<actual.size();++i)physicalDifference=std::max(physicalDifference,double(glm::distance(actual[i].position,translation+globalFrame*referenceParticles[i].position)));
   actual=referenceParticles;markers=referenceCells;
   for(auto& p:actual){p.position=translation+globalFrame*p.position;p.previousPosition=translation+globalFrame*p.previousPosition;p.velocity=globalFrame*p.velocity;p.acceleration=globalFrame*p.acceleration;}
   for(auto& m:markers)if(m.owner.IsValid()){m.position=translation+globalFrame*m.position;m.rotation=globalFrame*m.rotation;m.materialPoint=translation+globalFrame*m.materialPoint;m.contactPoint=translation+globalFrame*m.contactPoint;}
 }
 FluidHydrostaticField field;field.Build(actual,1000);
 std::vector<FluidDisplacementMarker> cells;for(const auto& cell:markers)if(cell.owner.IsValid())cells.push_back(cell);
 '''+s[z:]
s=s.replace('\n }\n}\n','\n }\n std::cerr<<"physical_max_difference="<<physicalDifference<<"\\n";\n}\n')
(c/'MappedFrames.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'MappedFrames.cpp'),'-o',str(c/'MappedFrames.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'MappedFrames.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'mapped-frames') if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
with (c/'mapped-frames.csv').open('w') as out,(c/'mapped-physics.log').open('w') as log:subprocess.run([str(c/'mapped-frames')],stdout=out,stderr=log,check=True)
rows=list(csv.DictReader((c/'mapped-frames.csv').open()));idx={(x['shape'],x['surface'],x['spacing'],x['frame']):x for x in rows};diffs=[abs(float(x['engine'])-float(idx[(x['shape'],x['surface'],x['spacing'],'1')]['engine'])) for x in rows if x['frame']=='0']
result=dict(cases=len(rows),accuracy_failures=sum(abs(float(x['engine'])-float(x['reference96']))>.10 for x in rows),frame_failures=sum(x>.001 for x in diffs),worst_frame_difference=max(diffs),physical_trace=(c/'mapped-physics.log').read_text());(c/'MAPPED_FRAMES.json').write_text(json.dumps(result,indent=2));print(result)
