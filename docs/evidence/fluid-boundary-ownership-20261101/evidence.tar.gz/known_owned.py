from pathlib import Path
import subprocess,shlex,json,time
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build';previous=r/'.cache/fluid-curved-reconstruction-20261101'
s=(r/'tests/FluidKnownGeometryTests.cpp').read_text()
old='''    const auto hydro = EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half),pose,gravity,
        displaced ? FluidVolumeGeometry::DisplacedSolid : FluidVolumeGeometry::NonDisplacingVolume);'''
new='''    const auto volume=MakeBoxFluidVolume(half);
    const BodyHandle owner{37,901};
    if(displaced)field.RetainDisplacedBoundary(owner,volume,pose,
        MakeParticles(definition,spacing,false,localCenter,half,frame));
    const auto hydro = EvaluateFluidHydrostatics(field,volume,pose,gravity,
        displaced ? FluidVolumeGeometry::DisplacedSolid : FluidVolumeGeometry::NonDisplacingVolume,owner);'''
assert old in s;s=s.replace(old,new)
(c/'KnownOwned.cpp').write_text(s)
s=((previous/'AdditionalShapes.cpp') if (previous/'AdditionalShapes.cpp').exists() else c/'fixtures/AdditionalShapes.cpp').read_text().replace('std::vector<FluidParticle> particles;','std::vector<FluidParticle> particles,source;').replace('if(!inside)particles.push_back(p);','source.push_back(p);if(!inside)particles.push_back(p);').replace('auto result=EvaluateFluidHydrostatics(field,volume,pose,gravity);','const BodyHandle owner{37,901};field.RetainDisplacedBoundary(owner,volume,pose,source);auto result=EvaluateFluidHydrostatics(field,volume,pose,gravity,FluidVolumeGeometry::DisplacedSolid,owner);')
(c/'AdditionalOwned.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
results=[]
for name,args in [('KnownOwned',['--output',str(c/'owned-known.csv')]),('AdditionalOwned',[])]:
 with (c/(name+'-build.log')).open('w') as log:subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(r/'tests'),*get('CXX_FLAGS'),'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],stdout=log,stderr=subprocess.STDOUT,check=True)
 a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
 a=[str(c/(name+'.o')) if x.endswith('ProductionFluidTests.cpp.o') else str(c/name) if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
 cmd=[str(c/name),*args];start=time.monotonic()
 with (c/(name+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 results.append(dict(command=cmd,exit_code=code,seconds=time.monotonic()-start));print(name,code,flush=True)
(c/'OWNED_RESULTS.json').write_text(json.dumps(results,indent=2))
