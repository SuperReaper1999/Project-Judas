from pathlib import Path
import subprocess,shlex,hashlib,json
r=Path.cwd();c=r/'.cache/fluid-boundary-ownership-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')];old=c/'old-source';old.mkdir(exist_ok=True)
for file in ['FluidWorld.cpp','ProductionFluidCoupling.cpp']:
 try: original=subprocess.check_output(['git','show','7a377c8cad65cfce26dce4d4fc1d6313d3c1550e:src/'+file],stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError: original=(old/file).read_bytes()
 (old/file).write_bytes(original)
with (c/'independent-build.log').open('w') as log:
 for file in ['FluidWorld.cpp','ProductionFluidCoupling.cpp']:subprocess.run([*base,'-c',str(old/file),'-o',str(c/(file+'.o'))],stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run([*base,'-c',str(c/'Trajectory.cpp'),'-o',str(c/'trajectory.o')],stdout=log,stderr=subprocess.STDOUT,check=True)
def link(target,out,replace=None,override=None):
 a=[v for v in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not v.startswith('-Wl,--dependency-file=')]
 if replace:a=[str(replace) if v.endswith('ProductionFluidTests.cpp.o') else v for v in a]
 a=[str(c/out) if v==target else v for v in a]
 if override:a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(override)]
 subprocess.run(a,cwd=b,check=True)
link('judas_production_fluid_tests','trajectory-before',c/'trajectory.o',c/'FluidWorld.cpp.o')
link('judas_production_fluid_tests','trajectory-after',c/'trajectory.o')
results={}
for name in ['before','after']:
 cmd=[str(c/('trajectory-'+name)),str(c/(name+'-trajectory.bin'))]
 output=subprocess.check_output(cmd,text=True);(c/(name+'-trajectory.log')).write_text(output);results[name]=dict(command=cmd,output=output,sha256=hashlib.sha256((c/(name+'-trajectory.bin')).read_bytes()).hexdigest())
assert results['before']['sha256']==results['after']['sha256']
# Old coupling, rebuilt against current headers: same ABI/layout, previous
# publication mechanism. New lifecycle assertion must catch its stale field.
link('judas_fluid_lifecycle_qualification_tests','old-coupling-lifecycle',override=c/'ProductionFluidCoupling.cpp.o')
with (c/'old-coupling-lifecycle.log').open('w') as log:code=subprocess.run([str(c/'old-coupling-lifecycle')],stdout=log,stderr=subprocess.STDOUT).returncode
results['clear_negative_exit']=code
(c/'INDEPENDENT.json').write_text(json.dumps(results,indent=2));print(results)
