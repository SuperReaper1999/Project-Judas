#include "FluidHydrostatics.h"
#include "FluidBoundaryGeometry.h"
#include <stdexcept>
#include <cmath>

void FluidHydrostaticField::RetainDisplacedBoundary(
    BodyHandle owner, const FluidVolumeQuadrature& solid, const BodyTransform& pose,
    const std::vector<FluidParticle>& domainParticles) {
    const auto finite=[](auto v) {
        for(int i=0;i<static_cast<int>(v.length());++i)if(!std::isfinite(v[i]))return false;
        return true;
    };
    if (!owner.IsValid() || m_particles.empty() || !finite(pose.position) ||
        !finite(pose.rotation) || !(glm::dot(pose.rotation,pose.rotation)>0) ||
        !std::isfinite(solid.solidSphereRadius) || solid.solidSphereRadius<0 ||
        (solid.solidSphereRadius==0 && solid.solidBoxes.empty()))
        throw std::invalid_argument("retained water boundary requires water and valid owned solid geometry");
    for(const auto& box : solid.solidBoxes) {
        if(box.type!=ShapeType::Box || !finite(box.localCenter) || !finite(box.halfExtents) ||
           !finite(box.rotation) || !(glm::dot(box.rotation,box.rotation)>0) ||
           glm::any(glm::lessThanEqual(box.halfExtents,glm::vec3(0))))
            throw std::invalid_argument("invalid retained water boundary solid");
    }
    // Construct and validate before changing the previous published snapshot.
    // This is geometry, not a second material particle field or pressure solve.
    auto domain=std::make_shared<FluidHydrostaticField>();
    domain->Build(domainParticles,m_density);
    OwnedBoundary replacement{owner,pose,solid.solidBoxes,solid.solidSphereRadius,std::move(domain)};
    for(auto& boundary : m_boundaries)if(FluidBoundaryDetail::SameOwner(owner,boundary.owner)) {
        boundary=std::move(replacement);
        return;
    }
    m_boundaries.push_back(std::move(replacement));
}

std::optional<float> FluidHydrostaticField::RetainedFraction(
    const glm::vec3& point, const glm::vec3& up, float halfHeight, float radius,
    const glm::vec3& tangent, const FluidSolidQuery* solid) const {
    if(!solid || !solid->owner.IsValid())return {};
    for(const auto& boundary : m_boundaries) {
        if(!FluidBoundaryDetail::SameOwner(boundary.owner,solid->owner))continue;
        // No stale shape, foreign compound child or recycled-world ownership.
        if(boundary.sphereRadius!=solid->volume.solidSphereRadius ||
           boundary.boxes.size()!=solid->volume.solidBoxes.size())return {};
        for(std::size_t i=0;i<boundary.boxes.size();++i) {
            const auto& a=boundary.boxes[i];const auto& b=solid->volume.solidBoxes[i];
            if(a.type!=b.type || a.localCenter!=b.localCenter || a.halfExtents!=b.halfExtents ||
               a.rotation!=b.rotation)return {};
        }
        // Boundary geometry is anchored at its fluid timestamp, never dragged
        // after a moving/teleported body. Only its originally displaced region
        // may use this owner's retained domain. Other points keep real wet/dry
        // admission. Rebuild drops the complete previous snapshot.
        if(!FluidBoundaryDetail::Inside(point,boundary.pose,boundary.boxes,boundary.sphereRadius) ||
           !FluidBoundaryDetail::Inside(point,solid->pose,boundary.boxes,boundary.sphereRadius))return {};
        return boundary.domain->Query(point,up,halfHeight,radius,tangent,nullptr,true).fraction;
    }
    return {};
}
