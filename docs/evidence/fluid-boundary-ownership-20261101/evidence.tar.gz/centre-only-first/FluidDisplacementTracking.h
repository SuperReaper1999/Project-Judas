#pragma once
#include "FluidBoundaryGeometry.h"

struct FluidBoundarySolid {
    BodyHandle owner;
    BodyTransform pose;
    glm::vec3 half{0};
    float sphereRadius=0;
};

// Retain the counterfactual geometric sample removed by solid projection, not
// a second particle or a fluid impulse. A marker lives only while its actual
// material particle contacts that same solid and its virtual point remains
// inside the real solid. Multiple unrelated contacts are deliberately declined.
inline void UpdateFluidDisplacementMarker(
    FluidDisplacementMarker& marker, const glm::vec3& start,
    const glm::vec3& actual, const glm::vec3& push, BodyHandle contactOwner,
    const std::vector<FluidBoundarySolid>& solids, float clearance) {
    using namespace FluidBoundaryDetail;
    // A resting particle need not emit another collision event. Retain a
    // previously established owner only if the same geometric contact below
    // still exists. Missing/changed colliders cannot pass that test.
    if(!contactOwner.IsValid())contactOwner=marker.owner;
    if(!contactOwner.IsValid()){marker={};return;}
    const glm::vec3 candidate=SameOwner(marker.owner,contactOwner) ?
        glm::vec3(glm::dvec3(marker.position)+glm::dvec3(actual)-glm::dvec3(start)-glm::dvec3(push)) :
        glm::vec3(glm::dvec3(actual)-glm::dvec3(push));
    for(const auto& solid : solids)if(SameOwner(solid.owner,contactOwner)) {
        const double tolerance=8*std::numeric_limits<float>::epsilon()*
            (1+glm::length(glm::dvec3(actual))+glm::length(glm::dvec3(solid.pose.position)));
        bool inside=false;double distance=0;
        if(solid.sphereRadius>0) {
            inside=glm::distance(glm::dvec3(candidate),glm::dvec3(solid.pose.position))<=solid.sphereRadius;
            distance=std::max(0.,glm::distance(glm::dvec3(actual),glm::dvec3(solid.pose.position))-solid.sphereRadius);
        } else {
            const auto local=glm::inverse(glm::dquat(solid.pose.rotation)) *
                (glm::dvec3(candidate)-glm::dvec3(solid.pose.position));
            inside=glm::all(glm::lessThanEqual(glm::abs(local),glm::dvec3(solid.half)));
            distance=Distance(actual,solid.pose,solid.half);
        }
        if(inside && distance<=clearance+tolerance) {
            marker={contactOwner,candidate};
            return;
        }
    }
    marker={};
}
