#include "CutCoupledPressure.h"
#include <chrono>
#include <cmath>
#include <iostream>

namespace judas::volume_grid {
namespace {
using Real=CutCompensated;
bool Fail(std::string& e,const char* text){e=text;return false;}
bool Material(const CutSpatialField& field,const CutDynamicSettings& settings,
    const std::vector<Real>& q,const std::vector<Real>& v,const std::vector<Real>& sourceWater,
    const std::vector<Real>& sourceGas,CutSelectiveTransport& result,std::string& error){
    std::vector<CutTransportFace> faces;std::vector<CutTransportGasPort> ports;
    for(std::size_t f=0;f<q.size();++f)faces.push_back({field.geometry.faces[f].left,field.geometry.faces[f].right,q[f]});
    for(std::size_t j=0;j<v.size();++j)ports.push_back({field.boundaries[j].fragment,v[j]});
    return result.Build(field.geometry.startCapacity,faces,ports,sourceWater,sourceGas,
        settings.gasDensity,settings.volumeTolerance*1e-4,error);
}
std::vector<Real> Mass(const std::vector<Real>& w,const std::vector<Real>& gas,double density){
    std::vector<Real> result;result.reserve(w.size());for(std::size_t i=0;i<w.size();++i)result.push_back(Real(density)*w[i]+gas[i]);return result;
}
}
bool AdvanceCutCoupledPressure(const CutSpatialField& field,const CutVelocityDual& dual,
    const CutDynamicSettings& settings,const CutCoupledSettings& options,CutCoupledState& output,
    std::string& error,const CutCoupledState* previous,const std::vector<double>& seed){
    if(previous==&output||options.iterationLimit<1||!(options.momentumTolerance>0.&&
        std::isfinite(options.momentumTolerance)&&options.relaxation>0.&&options.relaxation<=1.))
        return Fail(error,"invalid coupled pressure options or output alias");
    if(previous&&previous->velocity.size()!=dual.Nodes().size())return Fail(error,"continuation lost its owned momentum state");
    if(!dual.Matches(field)||field.water.size()!=field.parent.size()||field.gasMass.size()!=field.parent.size()||
        (previous&&(previous->material.water.size()!=field.parent.size()||previous->material.gasMass.size()!=field.parent.size()||
        previous->material.flux.size()!=field.geometry.faces.size()||previous->material.portFlux.size()!=field.boundaries.size())))
        return Fail(error,"coupled source dimensions or frozen geometry mismatch");
    const auto started=std::chrono::steady_clock::now();
    const auto sourceWater=previous?previous->material.water:std::vector<Real>(field.water.begin(),field.water.end());
    const auto sourceGas=previous?previous->material.gasMass:std::vector<Real>(field.gasMass.begin(),field.gasMass.end());
    const auto sourceMass=Mass(sourceWater,sourceGas,settings.waterDensity);
    const auto sourceVelocity=previous?previous->velocity:std::vector<Real>(dual.Nodes().size());
    // Relax EXTENSIVE momentum coefficients, not volume-flow guesses fed
    // through a nonlinear material solve. Every coefficient iterate then
    // retains m_end-m_source+div(massFlux)=0 exactly up to source arithmetic.
    auto coefficientMass=sourceMass;
    std::vector<Real> coefficientFlux(field.geometry.faces.size()),coefficientPort(field.boundaries.size());
    std::vector<double> pressureSeed=seed;
    for(int iteration=0;iteration<options.iterationLimit;++iteration){
        CutDualMomentum response;
        if(!response.Build(dual,field,settings,sourceMass,coefficientMass,
            coefficientFlux,coefficientPort,sourceVelocity,error,options.momentumBackend))return false;
        CutCoupledState next;
        if(!AdvanceCutLocalPressure(field,settings,pressureSeed,next.material,error,CutLocalTransport::Fast,
            previous?&previous->material:nullptr,&response))return false;
        CutSelectiveTransport actual;
        if(!Material(field,settings,next.material.flux,next.material.portFlux,sourceWater,sourceGas,actual,error))return false;
        std::vector<Real> massFlux;
        if(!actual.InteriorMassFlux(settings.waterDensity,massFlux,error))return false;
        const auto actualMass=Mass(actual.Water(),actual.Mass(),settings.waterDensity);
        const auto actualPort=actual.GasPortMass();
        CutDualMomentum audit;
        if(!audit.Build(dual,field,settings,sourceMass,actualMass,
            massFlux,actualPort,sourceVelocity,error,options.momentumBackend)||
            !audit.Audit(next.material.pressure,next.material.flux,next.material.portFlux,next.momentum,error))return false;
        std::cout<<"COUPLED iteration="<<iteration<<" momentum="<<next.momentum.maximumNormalizedResidual
            <<" speed="<<next.momentum.maximumSpeed<<" energy="<<next.momentum.afterEnergy
            <<" workResidual="<<next.momentum.energyResidual<<std::endl;
        const double workScale=std::abs(next.momentum.beforeEnergy)+std::abs(next.momentum.afterEnergy)+
            std::abs(next.momentum.pressureWork)+std::abs(next.momentum.gravityWork)+std::abs(next.momentum.mixingLoss)+next.momentum.unsteadyLoss;
        if(next.momentum.maximumNormalizedResidual<=options.momentumTolerance&&
            std::abs(next.momentum.energyResidual)<=1e-9*std::max(1.,workScale)){
            // Store the very velocity whose pressure flux and local momentum
            // were audited, not a postprocessed replacement from another solve.
            next.velocity.resize(dual.Nodes().size());
            for(std::size_t i=0;i<dual.Nodes().size();++i){const auto& node=dual.Nodes()[i];if(node.fixed)continue;
                next.velocity[i]=(node.face!=SIZE_MAX?next.material.flux[node.face]:Real(node.sign)*next.material.portFlux[node.port])/Real(settings.dt*node.area);
            }
            next.nonlinearIterations=iteration+1;next.elapsedMilliseconds=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count();
            output=std::move(next);error.clear();return true;
        }
        for(std::size_t i=0;i<coefficientMass.size();++i)coefficientMass[i]=coefficientMass[i]+Real(options.relaxation)*(actualMass[i]-coefficientMass[i]);
        for(std::size_t f=0;f<coefficientFlux.size();++f)coefficientFlux[f]=coefficientFlux[f]+Real(options.relaxation)*(massFlux[f]-coefficientFlux[f]);
        for(std::size_t j=0;j<coefficientPort.size();++j)coefficientPort[j]=coefficientPort[j]+Real(options.relaxation)*(actualPort[j]-coefficientPort[j]);
        pressureSeed.resize(next.material.pressure.size());for(std::size_t i=0;i<pressureSeed.size();++i)pressureSeed[i]=next.material.pressure[i].Value();
    }
    return Fail(error,"coupled pressure/momentum iteration budget exhausted");
}
} // namespace judas::volume_grid
