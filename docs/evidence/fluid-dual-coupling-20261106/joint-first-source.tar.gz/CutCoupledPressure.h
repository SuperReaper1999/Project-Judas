#pragma once
#include "CutLocalPressure.h"
#include "CutDualMomentum.h"

namespace judas::volume_grid {
struct CutCoupledState {
    CutLocalPressureResult material;
    std::vector<CutCompensated> velocity;
    CutDualMomentumAudit momentum;
    int nonlinearIterations=0;
    double elapsedMilliseconds=0.;
};
struct CutCoupledSettings {
    int iterationLimit=60;
    double momentumTolerance=1e-10;
    // Nonlinear iterate relaxation only. No unconverged iterate is published.
    double relaxation=.5;
    CutMomentumBackend momentumBackend=CutMomentumBackend::Fast;
};
bool AdvanceCutCoupledPressure(const CutSpatialField&,const CutVelocityDual&,
    const CutDynamicSettings&,const CutCoupledSettings&,CutCoupledState&,std::string&,
    const CutCoupledState* previous=nullptr,const std::vector<double>& pressureSeed={});
} // namespace judas::volume_grid
