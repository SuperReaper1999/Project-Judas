from pathlib import Path
import tarfile,subprocess,json,shutil
r=Path.cwd();d=r/'.cache/hinge-feature-review-20261030/java';d.mkdir(exist_ok=True)
with tarfile.open('third_party/android/SDL2-2.32.10.tar.gz') as t:
 for item in t.getmembers():
  prefix='SDL2-2.32.10/android-project/app/src/main/java/'
  if item.isfile() and item.name.startswith(prefix):
   p=d/item.name[len(prefix):];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(item).read())
activity=r/'platform/android/java/org/projectjudas/runtime/JudasActivity.java'
classes=d/'classes';classes.mkdir(exist_ok=True)
sources=list(d.rglob('*.java'))+[activity]
a=d/'sources.txt';a.write_text(''.join('"'+str(p)+'"\n' for p in sources))
cmd=[str(r/'.cache/m88/jdk17/bin/javac'),'-encoding','UTF-8','--release','8','-classpath','/home/conner/Android/Sdk/platforms/android-36/android.jar','-d',str(classes),'@'+str(a)]
p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(d/'compile.log').write_text(p.stdout);(d/'command.json').write_text(json.dumps({'command':cmd,'exit':p.returncode},indent=2)+'\n');print(p.stdout);raise SystemExit(p.returncode)
