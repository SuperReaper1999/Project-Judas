import sys,subprocess,pathlib,json
sys.path.insert(0,str(pathlib.Path('tools').resolve()))
from build_android import parse_args,android_manifest
root=pathlib.Path('.cache/hinge-feature-review-20261030/android');root.mkdir(exist_ok=True)
sdk=pathlib.Path('/home/conner/Android/Sdk');tool=sdk/'build-tools/36.0.0/aapt2'
rows=[]
for policy in ('any','landscape','portrait','sensorLandscape','sensorPortrait'):
 d=root/policy;d.mkdir(exist_ok=True)
 a,_=parse_args(['hinge.judasproj','--output','/tmp/hinge.apk','--orientation',policy]);manifest=d/'AndroidManifest.xml';manifest.write_text(android_manifest(a,'1.0.3-alpha.1'),encoding='utf-8')
 res=d/'res/drawable';res.mkdir(parents=True,exist_ok=True);(res/'judas_icon.png').write_bytes(pathlib.Path('assets/branding/judas-icon.png').read_bytes())
 commands=[[str(tool),'compile','--dir',str(d/'res'),'-o',str(d/'res.zip')],[str(tool),'link','--manifest',str(manifest),'-I',str(sdk/'platforms/android-36/android.jar'),'-o',str(d/'manifest.apk'),str(d/'res.zip')],[str(tool),'dump','xmltree',str(d/'manifest.apk'),'--file','AndroidManifest.xml']]
 for cmd in commands:
  r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert r.returncode==0,r.stdout
 (d/'xmltree.txt').write_text(r.stdout)
 # AAPT reports the compiled integer enum, not only the uncompiled string.
 expected={'landscape':'=0','portrait':'=1','sensorLandscape':'=6','sensorPortrait':'=7'}
 lines=[l for l in r.stdout.splitlines() if 'screenOrientation' in l]
 assert (not lines) if policy=='any' else len(lines)==1 and lines[0].endswith(expected[policy]),(policy,lines)
 rows.append({'policy':policy,'commands':commands,'compiledOrientation':lines})
(root/'verification.json').write_text(json.dumps(rows,indent=2)+'\n');print('Five real Android SDK manifest compile/link/decode checks passed. Not an installable game APK or device orientation test.')
