from pathlib import Path
import os, subprocess, json, hashlib
root=Path.cwd();d=root/'.cache/hinge-feature-review-20261030'
base=dict(os.environ, XDG_DATA_HOME=str(d/'userdata-final'), SDL_AUDIODRIVER='dummy', JUDAS_WORLD_STATE='none')
base.pop('JUDAS_TEST_SCRIPT',None);base.pop('JUDAS_WINDOW_SIZE',None)
rows=[]
def run(name,cmd,env=None,expected=0,required=''):
 e=dict(base);e.update(env or {});p=subprocess.run([str(x) for x in cmd],env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (d/(name+'.log')).write_text(p.stdout)
 rows.append({'name':name,'command':[str(x) for x in cmd],'overrides':env or {},'exit':p.returncode,'expected':expected,'requiredDiagnostic':required})
 (d/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 if p.returncode!=expected or required not in p.stdout:raise RuntimeError(name+' failed; see log')
run('native-surface-probe',[d/'surface_probe'])
run('pointer-final',[root/'build/judas_pointer_harness_tests',d/'pointer-final'])
run('application-final',[root/'build/judas_project_application_tests'])
run('hinge-aspects-final',[root/'build/judas',d/'hinge/hinge.judasproj'],{'JUDAS_WINDOW_SIZE':'800x360','JUDAS_TEST_SCRIPT':str(d/'aspects.txt')})
(d/'portrait-startup.txt').write_text(f'FRAMES 4\nLOG_EVERY 0\nEXPECT_VIEWPORT 360 800 0\nSCREENSHOT 3 {d}/portrait-startup.png\n')
run('hinge-portrait-startup',[root/'build/judas',d/'hinge/hinge.judasproj'],{'JUDAS_WINDOW_SIZE':'360x800','JUDAS_TEST_SCRIPT':str(d/'portrait-startup.txt')})
run('invalid-startup',[root/'build/judas',d/'hinge/hinge.judasproj'],{'JUDAS_WINDOW_SIZE':'9000x300'},1,'JUDAS_WINDOW_SIZE must be WIDTHxHEIGHT')
run('offscreen-resize-rejection',[root/'build/judas',d/'hinge/hinge.judasproj'],{'SDL_VIDEODRIVER':'offscreen','JUDAS_TEST_SCRIPT':str(d/'baseline/resize.txt')},1,'SDL offscreen cannot resize')
print('All seven native/negative checks passed. See native-results.json.')
