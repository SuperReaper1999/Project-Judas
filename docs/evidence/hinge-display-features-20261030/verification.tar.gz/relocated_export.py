from pathlib import Path
import os,subprocess,shutil,tempfile,json
root=Path.cwd();d=root/'.cache/hinge-feature-review-20261030';parent=Path(tempfile.mkdtemp(prefix='judas-hinge-display-'));package=parent/'package';shutil.move(str(d/'export-original'),package)
script=d/'relocated.txt';script.write_text(f'''FRAMES 6
LOG_EVERY 0
EXPECT_VIEWPORT 800 360 0
RESIZE 360 800 1
EXPECT_VIEWPORT 360 800 1
SCREENSHOT 2 {d}/relocated-portrait.png
RESIZE 1200 540 3
EXPECT_VIEWPORT 1200 540 3
SCREENSHOT 5 {d}/relocated-wide.png
''')
env=dict(os.environ,XDG_DATA_HOME=str(d/'userdata-relocated'),JUDAS_WINDOW_SIZE='800x360',JUDAS_TEST_SCRIPT=str(script),JUDAS_WORLD_STATE='none',SDL_AUDIODRIVER='dummy');cmd=[str(package/'judas')];p=subprocess.run(cmd,cwd='/tmp',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
(d/'relocated.log').write_text(p.stdout);(d/'relocated.json').write_text(json.dumps({'command':cmd,'cwd':'/tmp','exit':p.returncode,'package':str(package),'script':str(script)},indent=2)+'\n');print('Relocated standalone exit:',p.returncode);raise SystemExit(p.returncode)
