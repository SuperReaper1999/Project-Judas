#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <cstdio>
#include <initializer_list>
int main(){SDL_Init(SDL_INIT_VIDEO);auto* w=SDL_CreateWindow("resize probe",0,0,800,360,SDL_WINDOW_OPENGL|SDL_WINDOW_HIDDEN|SDL_WINDOW_RESIZABLE);auto ctx=SDL_GL_CreateContext(w);SDL_GL_SetSwapInterval(0);std::printf("driver=%s\n",SDL_GetCurrentVideoDriver());for(auto mode:{0,1,2}){SDL_SetWindowSize(w,360,800);SDL_PumpEvents();if(mode==1)SDL_GL_MakeCurrent(w,ctx);if(mode==2)SDL_GL_SwapWindow(w);if(mode==3){SDL_ShowWindow(w);SDL_PumpEvents();}int x,y;SDL_GL_GetDrawableSize(w,&x,&y);glViewport(0,0,360,800);glClearColor(0,1,0,1);glClear(GL_COLOR_BUFFER_BIT);unsigned char p[4]={};glReadPixels(350,790,1,1,GL_RGBA,GL_UNSIGNED_BYTE,p);std::printf("mode=%d drawable=%dx%d pixel=%u,%u,%u error=%x\n",mode,x,y,p[0],p[1],p[2],glGetError());}SDL_GL_DeleteContext(ctx);SDL_DestroyWindow(w);SDL_Quit();}
