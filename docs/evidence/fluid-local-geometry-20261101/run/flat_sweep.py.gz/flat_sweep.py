from pathlib import Path
import csv,math,subprocess,json
c=Path(__file__).resolve().parent;out=[]
for i in range(24):
 axis=[1,2,3];ln=math.sqrt(sum(x*x for x in axis));angle=i*math.pi/12;q=[math.cos(angle/2)]+[x/ln*math.sin(angle/2) for x in axis]
 path=c/f'flat-pose-{i}.csv';path.write_text('x,y,z,qw,qx,qy,qz,hx,hy,hz,gx,gy,gz\n'+','.join(str(x) for x in [0,1.5,0,*q,.3,.3,.3,0,-9.81,0])+'\n')
 water=c/'coarse/half_025_before651_particles.csv'
 for binary in ['replay','sliced-replay']:
  proc=subprocess.run([str(c/binary),str(path),str(water)],text=True,capture_output=True,check=True)
  (c/f'{binary}-flat-{i}.csv').write_text(proc.stdout)
  rows=[r for r in csv.DictReader(proc.stdout.splitlines()) if r['kind']=='known_flat' and float(r['spacing'])==.25 and r['samples']=='4']
  assert len(rows)==1;out.append({'orientation':i,'mode':binary,'fraction':float(rows[0]['fraction']),'error':float(rows[0]['fraction'])-.5})
(c/'FLAT_ROTATION_SWEEP.json').write_text(json.dumps(out,indent=2)+'\n')
for b in ['replay','sliced-replay']:
 vals=[abs(x['error']) for x in out if x['mode']==b];print(b,'maximum error',max(vals),'mean absolute error',sum(vals)/len(vals),'over original .10 immersion tolerance',sum(x>.1 for x in vals))
