from pathlib import Path
import subprocess,shlex,json,hashlib
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build'
s=(r/'tests/ProductionFluidTests.cpp').read_text()
s=s.replace('for(int step=0;step<count;++step){StepPlayedWorld','for(int step=0;step<count;++step){if(step>=480)snapshot("before"+std::to_string(step),handle);StepPlayedWorld')
(c/'ObserveProduction.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
cmd=['/usr/bin/c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(r/'tests'),*get('CXX_FLAGS'),'-c',str(c/'ObserveProduction.cpp'),'-o',str(c/'observe.o')]
subprocess.run(cmd,check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'observe.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'observe') if x=='judas_production_fluid_tests' else x for x in a]
a.insert(a.index('libjudas_engine.a'),str(r/'.cache/fluid-settling-cause-20261101/trace.o'))
# Use the preserved instrumented coupling source, not an assumed object filename.
a=[x for x in a if not x.endswith('/trace.o')]
cmd2=['/usr/bin/c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(r/'.cache/fluid-settling-cause-20261101/TraceCoupling.cpp'),'-o',str(c/'trace.o')]
subprocess.run(cmd2,check=True);a.insert(a.index('libjudas_engine.a'),str(c/'trace.o'));subprocess.run(a,cwd=b,check=True)
(c/'BUILD_COMMANDS.json').write_text(json.dumps([cmd,cmd2,{'cwd':str(b),'link':a}],indent=2)+'\n')
