#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
int main(){std::cout<<std::setprecision(17)<<"angle,halfHeight,before,after,jump\n";
std::vector<FluidParticle> particles;for(int z=-4;z<=4;++z)for(int x=-4;x<=4;++x)for(int y=-4;y<=3;++y){bool far=x==3&&z==0;float h=(y+.5f)*.25f;float top=x<0?.25f:0.f;if(far ? std::abs(h)<.5f : h>=top)continue;FluidParticle p;p.position={x*.25f,h,z*.25f};p.mass=15.625f;particles.push_back(p);}
FluidHydrostaticField field;field.Build(particles,1000);auto volume=MakeBoxFluidVolume(glm::vec3(.3f));
for(int i=1;i<=8;++i)for(float half:{.10f,.15f,.20f,.25f}) {BodyTransform pose;pose.rotation=glm::angleAxis(i*.1f,glm::vec3(0,0,1));FluidSolidQuery solid{volume,pose};float a=field.Query({}, {0,1,0},half,.25f-.00001f,{1,0,0},&solid,true).fraction;float b=field.Query({}, {0,1,0},half,.25f+.00001f,{1,0,0},&solid,true).fraction;std::cout<<i*.1<<','<<half<<','<<a<<','<<b<<','<<b-a<<'\n';}
}
