from pathlib import Path
import csv,json,math,statistics
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def norm(a):return math.sqrt(dot(a,a))
def vec(a):return list(a)
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
r=Path.cwd();s=r/'.cache/fluid-window-contract-20261101/qualification/window-full';out=[]
def rotate(q,v):
 w=q[0];u=q[1:];c=cross(u,v);return [(2*w*w-1)*v[i]+2*dot(u,v)*u[i]+2*w*c[i] for i in range(3)]
for name,spacing in [('half_020',.2),('half_025',.25),('rotated_half',.2),('light_80kg',.2)]:
 for step in [240,720]:
  b=next(csv.DictReader((s/f'{name}_step{step}_body.csv').open()));p=list(csv.DictReader((s/f'{name}_step{step}_particles.csv').open()))
  g=vec([float(b[k]) for k in ['gx','gy','gz']]);up=[-x/norm(g) for x in g]
  if name=='rotated_half':
   a=vec([1.,-2,3]);a=[x/norm(a) for x in a];q=[math.cos(.83/2)]+[x*math.sin(.83/2) for x in a]
  else:q=vec([1,0,0,0])
  qi=q.copy();qi[1:]=[-x for x in qi[1:]]
  center=rotate(qi,vec([float(b[k]) for k in ['x','y','z']]));half=vec([float(b[k]) for k in ['hx','hy','hz']]);cols={}
  for x in p:
   pos=rotate(qi,vec([float(x[k]) for k in ['x','y','z']]));key=tuple(math.floor((pos[k]+1)/spacing) for k in [0,2])
   if all(0<=v<round(2/spacing) for v in key):cols[key]=max(cols.get(key,-1e30),pos[1]+spacing/2)
  outer=[h for (i,j),h in cols.items() if abs((i+.5)*spacing-1-center[0])>=half[0]+spacing and abs((j+.5)*spacing-1-center[2])>=half[2]+spacing]
  near=sorted([(math.hypot((i+.5)*spacing-1-center[0],(j+.5)*spacing-1-center[2]),h) for (i,j),h in cols.items()])
  out.append(dict(case=name,step=step,center=center,old_exterior_count=len(outer),old_surface_median=statistics.median(outer),surface_min=min(cols.values()),surface_max=max(cols.values()),nearest8=near[:8]))
print(json.dumps(out,indent=2));(r/'.cache/fluid-local-geometry-20261101/SNAPSHOT_SURFACES.json').write_text(json.dumps(out,indent=2)+'\n')
