from pathlib import Path
import subprocess,shlex,json,hashlib
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';out=c/'negative-controls';out.mkdir(exist_ok=True)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));results=[]
for source,target in [('BeforeOwnershipFix.cpp','judas_fluid_vertical_support_tests'),('BeforeActualDonors.cpp','judas_fluid_hydrostatics_tests'),('AlwaysSliced.cpp','judas_fluid_hydrostatics_tests')]:
 obj=out/(source+'.o');cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/source),'-o',str(obj)];subprocess.run(cmd,check=True)
 a=shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text());binary=out/(source+'-test');a=[str(binary) if x==target else x for x in a];a.insert(a.index('libjudas_engine.a'),str(obj));subprocess.run(a,cwd=b,check=True)
 with (out/(source+'.log')).open('w') as log:code=subprocess.run([str(binary)],stdout=log,stderr=subprocess.STDOUT).returncode
 assert code!=0,(source,'negative control unexpectedly passed')
 results.append({'source':source,'source_sha256':hashlib.sha256((c/source).read_bytes()).hexdigest(),'compile':cmd,'link':a,'link_cwd':str(b),'exit_code':code,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()});print(source,code,flush=True)
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
