from pathlib import Path
import subprocess,json,shlex,time
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';o=[]
for name in ['judas_fluid_vertical_support_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests']:
 cmd=shlex.split((b/f'CMakeFiles/{name}.dir/link.txt').read_text());cmd=[str(c/('sliced-'+name)) if x==name else x for x in cmd];cmd.insert(cmd.index('libjudas_engine.a'),str(c/'sliced.o'));subprocess.run(cmd,cwd=b,check=True)
 start=time.monotonic()
 with (c/(name+'-sliced.log')).open('w') as log:code=subprocess.run([str(c/('sliced-'+name))],stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 o.append({'target':name,'link':cmd,'cwd':str(b),'exit_code':code,'seconds':time.monotonic()-start});print(name,code,flush=True)
(c/'SLICE_REGRESSIONS.json').write_text(json.dumps(o,indent=2))
