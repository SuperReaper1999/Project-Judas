"""Independent manufactured-geometry controls for the unchanged flat-plane observer.
This does not call the engine hydrostatic sampler or alter any acceptance gate.
"""
import math,json,statistics
from pathlib import Path
c=Path(__file__).resolve().parent
spacing=.2;nx=10;center=(.5,1.5,0);half=(.3,.3,.3)
def observed(particles):
 tops=[-1e30]*(nx*nx)
 for x,y,z in particles:
  # Exact predicate and binning used by ProductionFluidTests::ObservedSurface.
  if abs(x-center[0])<half[0]+spacing or abs(z-center[2])<half[2]+spacing:continue
  ix=math.floor((x+1)/spacing);iz=math.floor((z+1)/spacing)
  if 0<=ix<nx and 0<=iz<nx:tops[iz*nx+ix]=max(tops[iz*nx+ix],y+.5*spacing)
 tops=sorted(x for x in tops if x>=-1e20)
 return tops[len(tops)//2],len(tops) # production uses upper median
out=[]
for slope in [0,-.2,-.4,.4]:
 particles=[]
 for ix in range(nx):
  for iz in range(nx):
   x=(ix+.5)*spacing-1;z=(iz+.5)*spacing-1;surface=center[1]+slope*(x-center[0])
   for j in range(8):particles.append((x,surface-(j+.5)*spacing,z))
 H,n=observed(particles)
 # A plane through the center of a centrally symmetric box bisects its volume.
 # Quadrature checks both actual sloped geometry and the inferred flat plane.
 def fraction(local_surface):
  count=0;N=64
  for ix in range(N):
   for iy in range(N):
    for iz in range(N):
     x=center[0]+half[0]*(2*(ix+.5)/N-1);y=center[1]+half[1]*(2*(iy+.5)/N-1)
     count+=y<local_surface(x)
  return count/N**3
 true=fraction(lambda x:center[1]+slope*(x-center[0]));flat=fraction(lambda x:H)
 assert abs(true-.5)<.002
 if slope==0:assert flat==.5
 else:assert abs(flat-true)>.1
 out.append({'slope':slope,'surface_at_body_center':center[1],'exact_true_immersion':.5,'independent_dense_volume':true,'original_observer_surface':H,'original_observer_immersion':flat,'exterior_column_count':n,'old_observer_disagrees_with_known_geometry':abs(flat-true)>.1})
print(json.dumps(out,indent=2));(c/'MANUFACTURED_ORACLE_CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n')
