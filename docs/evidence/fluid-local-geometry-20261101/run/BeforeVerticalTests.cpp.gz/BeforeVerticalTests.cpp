#include "FluidHydrostatics.h"
#include "FluidColumnLayers.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <string>

namespace {
unsigned checks = 0, failures = 0;
void Near(double actual, double expected, double tolerance, const std::string& name) {
    ++checks;
    if (std::isfinite(actual) && std::abs(actual - expected) <= tolerance) return;
    ++failures;
    std::cout << "FAIL " << name << " actual=" << actual << " expected=" << expected << '\n';
}
struct Uniform final : GravityField {
    glm::vec3 gravity;
    explicit Uniform(glm::vec3 value) : gravity(value) {}
    glm::vec3 Sample(const glm::vec3&) const override { return gravity; }
};
struct Frame {
    glm::quat rotation{1, 0, 0, 0};
    glm::vec3 offset{0};
    glm::vec3 Point(glm::vec3 p) const { return offset + rotation * p; }
    glm::vec3 Vector(glm::vec3 p) const { return rotation * p; }
};
std::vector<FluidParticle> Layers(const Frame& frame, bool enclosed = false) {
    std::vector<FluidParticle> particles;
    for (int x = -8; x <= 8; ++x) for (int z = -8; z <= 8; ++z) {
        for (int y = -4; y <= 3; ++y) {
            const float height = .25f * (y + .5f);
            if (std::abs(height) < .5f && !(enclosed && (std::abs(x) >= 3 || std::abs(z) >= 3))) continue;
            const auto position = frame.Point({.25f * x, height, .25f * z});
            const auto velocity = frame.Vector({height < 0 ? .4f : -.6f, 0, 0});
            particles.push_back({position, position, velocity, 15.625f, glm::vec3(0)});
        }
    }
    return particles;
}
void LayerQueries(const Frame& frame) {
    FluidHydrostaticField field;
    field.Build(Layers(frame), 1000);
    const auto up = frame.Vector({0, 1, 0}), tangent = frame.Vector({1, 0, 0});
    // Deliberately large donor radius: both strata enter the search. A search
    // radius must not become occupied water between their actual surfaces.
    for (bool connected : {false, true}) {
        for (float height : {-.25f, 0.f, .25f}) {
            const auto query = field.Query(frame.Point({0, height, 0}), up, .1f, 1, tangent, nullptr, connected);
            Near(query.fraction, 0, 0, "resolved vertical air stays dry");
            Near(glm::length(query.velocity), 0, 0, "dry query publishes no borrowed layer velocity");
        }
        const auto partial = field.Query(frame.Point({0, 0, 0}), up, .75f, 1, tangent, nullptr, connected);
        // [-.75,.75] intersects [-1,-.5] and [.5,1]: .5 / 1.5.
        Near(partial.fraction, 1. / 3., .002, "two layers add occupied lengths without filling gap");
        const auto bottom = field.Query(frame.Point({0, -.75f, 0}), up, .1f, .1f, tangent, nullptr, connected);
        Near(bottom.fraction, 1, .002, "lower layer remains wet");
        Near(glm::length(bottom.velocity - frame.Vector({.4f, 0, 0})), 0, .0001,
             "resolved layer keeps its own motion");
    }
    for (int step = -24; step <= 24; ++step) {
        const double y = step * .05;
        double expected = 0;
        for (const auto& span : {std::pair<double, double>{-1, -.5}, {.5, 1}})
            expected += std::max(0.0, std::min(y + .1, span.second) - std::max(y - .1, span.first)) / .2;
        const auto query = field.Query(frame.Point({0, float(y), 0}), up, .1f, 1, tangent, nullptr, true);
        Near(query.fraction, expected, .003, "vertical sweep follows both actual free surfaces");
    }
    const Uniform gravity(frame.Vector({0, -9.81f, 0}));
    BodyTransform pose; pose.position = frame.offset; pose.rotation = frame.rotation;
    for (const auto& volume : {MakeBoxFluidVolume(glm::vec3(.1f)), MakeSphereFluidVolume(.1f),
                              MakeCompoundFluidVolume({{{-.2f, 0, 0}, {.1f, .1f, .1f}},
                                                       {{.2f, 0, 0}, {.1f, .1f, .1f}}})}) {
        for (const auto geometry : {FluidVolumeGeometry::DisplacedSolid, FluidVolumeGeometry::NonDisplacingVolume}) {
            const auto result = EvaluateFluidHydrostatics(field, volume, pose, gravity, geometry);
            Near(result.fraction, 0, 0, "body/player in vertical gap stays dry");
            Near(glm::length(result.buoyancyForce), 0, 0, "dry body receives no buoyancy");
        }
    }
    const auto tall = MakeBoxFluidVolume({.1f, .75f, .1f}, 12);
    const auto result = EvaluateFluidHydrostatics(field, tall, pose, gravity);
    Near(result.fraction, 1. / 3., .003, "solid spanning both layers retains partial volume");
    Near(glm::length(result.buoyancyForce), 1000 * 9.81 * tall.totalVolume / 3., 2,
         "partial displaced weight agrees independently");
    // Connecting the strata around a cavity must not make its centre wet.
    field.Build(Layers(frame, true), 1000);
    const auto cavity = EvaluateFluidHydrostatics(field, MakeBoxFluidVolume(glm::vec3(.1f)), pose, gravity);
    Near(cavity.fraction, 0, 0, "enclosed 3D pocket is not filled by connected outer water");
    const auto player = field.Query(frame.offset, up, .1f, 1, tangent, nullptr, true);
    Near(player.fraction, 0, 0, "enclosed pocket does not trigger swimming");
    const auto tallCavity=EvaluateFluidHydrostatics(field,tall,pose,gravity);
    Near(tallCavity.fraction,1./3.,.003,"solid crossing connected cavity does not displace its air");

}
void IntervalControls() {
    using Span = std::pair<double, double>;
    const auto measure = [](std::vector<Span> spans, double height) {
        return FluidHydrostaticDetail::ColumnOccupiedHeight(spans, height, .25, 0);
    };
    Near(measure({}, 1), 0, 0, "empty column");
    Near(measure({{-.5, -.25}, {.25, .5}}, 1), .5, 0, "resolved gap remains empty");
    Near(measure({{.25, .5}, {-.5, -.25}}, 1), .5, 0, "interval ordering independent");
    Near(measure({{-.5, .1}, {-.1, .5}, {-.5, .1}}, 1), 1, 0, "overlapping particles never double volume");
    Near(measure({{-.5, -.1}, {.1, .5}}, 1), 1, 0, "sub-resolution disorder remains reconstructed");
    Near(measure({{-.5, -.25}, {.25, .5}}, .1), 0, 0, "query wholly inside resolved gap");
    Near(measure({{-.5, -.25}, {.25, .5}}, 0), 0, 0, "zero-height query inside gap");
    Near(measure({{-.5, .5}}, 0), 1, 0, "zero-height query inside water");
    Near(measure({{-.5, -.25}, {0, .25}}, 1), .75, 0, "one-column resolution closes internal gaps only");
}
} // namespace
int main() {
    IntervalControls();
    const auto rotation = glm::angleAxis(.83f, glm::normalize(glm::vec3(1, -2, 3)));
    for (const Frame& frame : {Frame{}, Frame{rotation, {3, -2, 4}}, Frame{rotation, {4096, 0, 0}}}) LayerQueries(frame);
    std::cout << "Fluid vertical support: " << checks << " checks, " << failures << " failures\n";
    return failures ? 1 : 0;
}
