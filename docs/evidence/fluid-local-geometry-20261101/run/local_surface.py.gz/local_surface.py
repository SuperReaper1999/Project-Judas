from pathlib import Path
import csv,math,json,statistics
c=Path('.cache/fluid-local-geometry-20261101');src=Path('.cache/fluid-window-contract-20261101/qualification/window-full')
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross3(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def rot(q,v):
 w=q[0];u=q[1:];k=cross3(u,v);return [(2*w*w-1)*v[i]+2*dot(u,v)*u[i]+2*w*k[i] for i in range(3)]
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def hull(ps):
 ps=sorted(set(ps));h=[]
 for p in ps:
  while len(h)>1 and cross(h[-2],h[-1],p)<=0:h.pop()
  h.append(p)
 lower=len(h)
 for p in ps[-2::-1]:
  while len(h)>lower and cross(h[-2],h[-1],p)<=0:h.pop()
  h.append(p)
 return h[:-1]
def distance(p,a,b):
 d=[b[i]-a[i] for i in [0,1]];u=max(0,min(1,dot([p[i]-a[i] for i in [0,1]],d)/dot(d,d)));return math.hypot(*[p[i]-a[i]-u*d[i] for i in [0,1]])
o=[]
for name,spacing in [('half_020',.2),('half_025',.25),('rotated_half',.2),('light_80kg',.2)]:
 b=next(csv.DictReader((src/f'{name}_step720_body.csv').open()));p=list(csv.DictReader((src/f'{name}_step720_particles.csv').open()));q=[float(b[k]) for k in ['qw','qx','qy','qz']];center=[float(b[k]) for k in ['x','y','z']];half=[float(b[k]) for k in ['hx','hy','hz']]
 if name=='rotated_half':
  ax=[1,-2,3];ln=math.sqrt(dot(ax,ax));frame=[math.cos(.83/2)]+[-x/ln*math.sin(.83/2) for x in ax]
 else:frame=[1,0,0,0]
 corners=[]
 for x in [-1,1]:
  for y in [-1,1]:
   for z in [-1,1]:
    v=rot(q,[x*half[0],y*half[1],z*half[2]]);v=rot(frame,[v[i]+center[i] for i in range(3)]);corners.append((v[0],v[2]))
 h=hull(corners);columns={}
 for a in p:
  v=rot(frame,[float(a[k]) for k in ['x','y','z']]);key=(math.floor((v[0]+1)/spacing),math.floor((v[2]+1)/spacing));columns[key]=max(columns.get(key,-1e30),v[1]+spacing*.5)
 outside=[]
 for (x,z),top in columns.items():
  point=((x+.5)*spacing-1,(z+.5)*spacing-1)
  if all(cross(a,bb,point)>=0 for a,bb in zip(h,h[1:]+h[:1])):continue
  d=min(distance(point,a,bb) for a,bb in zip(h,h[1:]+h[:1]));outside.append([d,top])
 bins=[]
 for lo,hi in [(0,.5*spacing),(.5*spacing,spacing),(spacing,2*spacing),(2*spacing,10)]:
  vals=[top for d,top in outside if lo<=d<hi];bins.append({'distance':[lo,hi],'n':len(vals),'median_top':statistics.median(vals) if vals else None,'min_top':min(vals) if vals else None,'max_top':max(vals) if vals else None})
 o.append({'case':name,'outside_actual_rotated_footprint':bins})
print(json.dumps(o,indent=2));(c/'LOCAL_EXTERIOR_SURFACES.json').write_text(json.dumps(o,indent=2))
