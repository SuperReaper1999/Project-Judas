from pathlib import Path
import subprocess,shlex,json,os
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
s=(r/'src/FluidHydrostatics.cpp').read_text();needle='out.acceleration=glm::vec3(bulkAcceleration/bulkWeight)';assert needle in s;s=s.replace(needle,'out.acceleration=glm::vec3(0)');s=s.replace('out.acceleration=glm::vec3(extensionAcceleration/extensionWeight)','out.acceleration=glm::vec3(0)');(c/'NoAcceleration.cpp').write_text(s)
cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'NoAcceleration.cpp'),'-o',str(c/'noaccel.o')];subprocess.run(cmd,check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'observe.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'noaccel') if x=='judas_production_fluid_tests' else x for x in a];i=a.index('libjudas_engine.a');a[i:i]=[str(c/'noaccel.o'),str(c/'trace.o')];subprocess.run(a,cwd=b,check=True)
env=os.environ.copy();env['JUDAS_FLUID_FORCE_TRACE']=str(c/'noaccel-forces.csv');command=[str(c/'noaccel'),'--case','half_025','--output',str(c/'noaccel-output')]
with (c/'noaccel.log').open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(c/'ABLATION_COMMANDS.json').write_text(json.dumps({'compile':cmd,'link':a,'link_cwd':str(b),'run':command,'exit_code':code,'scope':'Diagnostic removal of fluid acceleration; not a candidate fix and not a passing qualification.'},indent=2)+'\n');print('No-acceleration diagnostic exit',code)
