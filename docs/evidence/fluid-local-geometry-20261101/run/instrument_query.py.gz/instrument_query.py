from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';s=(r/'src/FluidHydrostatics.cpp').read_text();s='#include <iostream>\n#include <iomanip>\n'+s
needle='if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport))return 0.0;';assert needle in s;s=s.replace(needle,'if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport)){std::cerr<<"hull_reject ";return 0.0;}')
needle='if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact))return 0.0;';assert needle in s;s=s.replace(needle,'if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact)){std::cerr<<"support_reject ";return 0.0;}')
needle='const double v=static_cast<double>(sample.volume)*fluid.fraction;';assert needle in s;s=s.replace(needle,'std::cerr<<std::setprecision(17)<<"sample "<<sample.localPosition.x<<","<<sample.localPosition.y<<","<<sample.localPosition.z<<" fraction "<<fluid.fraction<<"\\n";\n        '+needle)
(c/'QueryTrace.cpp').write_text(s);f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'QueryTrace.cpp'),'-o',str(c/'query-trace.o')];subprocess.run(cmd,check=True)
a=json.loads((c/'REPLAY_BUILD.json').read_text())[1]['command'];a=[str(c/'query-trace') if x==str(c/'replay') else x for x in a];a.insert(a.index('libjudas_engine.a'),str(c/'query-trace.o'));subprocess.run(a,cwd=b,check=True)
for step in [651,652]:
 with (c/f'query{step}.log').open('w') as log:subprocess.run([str(c/'query-trace'),str(c/f'coarse/half_025_before{step}_body.csv'),str(c/f'coarse/half_025_before651_particles.csv')],stdout=subprocess.DEVNULL,stderr=log,check=True)
