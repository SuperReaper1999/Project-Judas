#define main replay_main
#include "Replay.cpp"
#undef main
int main(int argc,char**argv){if(argc<3)return 2;auto body=Read(argv[1]).at(0);auto raw=Read(argv[2]);BodyTransform pose;pose.position={body[0],body[1],body[2]};pose.rotation=glm::quat(float(body[3]),float(body[4]),float(body[5]),float(body[6]));glm::vec3 half(body[7],body[8],body[9]);std::vector<FluidParticle> p;for(auto&v:raw){FluidParticle a;a.position={v[0],v[1],v[2]};a.velocity={v[3],v[4],v[5]};a.acceleration={v[6],v[7],v[8]};a.mass=v[9];p.push_back(a);}FluidHydrostaticField field;field.Build(p,1000);auto volume=MakeBoxFluidVolume(half);FluidSolidQuery solid{volume,pose};glm::vec3 up(0,1,0),tangent(0);float best=-1;
for(int axis=0;axis<3;++axis){glm::vec3 a(0);a[axis]=1;auto v=pose.rotation*a;v-=up*glm::dot(v,up);if(glm::dot(v,v)>best){best=glm::dot(v,v);tangent=v;}}
std::cout<<std::setprecision(17)<<"sample,full,midpoint128,midpoint512\n";int index=0;
for(const auto& sample:volume.samples){auto point=pose.position+pose.rotation*sample.localPosition;float h=glm::dot(glm::abs(glm::conjugate(pose.rotation)*up),sample.localHalfExtents);auto query=field.Query(point,up,h,volume.boundRadius,tangent,&solid,true);std::cout<<index++<<','<<query.fraction;
for(int n:{128,512}){double sum=0;for(int i=0;i<n;++i){const auto p=point+up*(h*(2*(i+.5f)/n-1));sum+=field.Query(p,up,0,volume.boundRadius,tangent,&solid,true).fraction;}std::cout<<','<<sum/n;}std::cout<<'\n';}
}
