from pathlib import Path
import subprocess,shlex,json,os
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';s=(r/'src/FluidHydrostatics.cpp').read_text();needle='    if(splitHeights)for(auto& profile:profiles)';assert needle in s;s=s.replace(needle,'    splitHeights=splitHeights || solid; // diagnostic: consistent displaced-solid height ownership\n'+needle);(c/'SolidSliced.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'SolidSliced.cpp'),'-o',str(c/'sliced.o')];subprocess.run(cmd,check=True)
a=json.loads((c/'REPLAY_BUILD.json').read_text())[1]['command'];a=[str(c/'sliced-replay') if x==str(c/'replay') else x for x in a];a.insert(a.index('libjudas_engine.a'),str(c/'sliced.o'));subprocess.run(a,cwd=b,check=True)
for step in [651,652]:
 p=subprocess.run([str(c/'sliced-replay'),str(c/f'coarse/half_025_before{step}_body.csv'),str(c/'coarse/half_025_before651_particles.csv')],capture_output=True,text=True,check=True);(c/f'sliced-pose{step}.csv').write_text(p.stdout)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'observe.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'sliced') if x=='judas_production_fluid_tests' else x for x in a];i=a.index('libjudas_engine.a');a[i:i]=[str(c/'sliced.o'),str(c/'trace.o')];subprocess.run(a,cwd=b,check=True)
env=os.environ.copy();env['JUDAS_FLUID_FORCE_TRACE']=str(c/'sliced-forces.csv');command=[str(c/'sliced'),'--case','half_025','--output',str(c/'sliced-output')]
with (c/'sliced.log').open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(c/'SLICE_COMMANDS.json').write_text(json.dumps({'compile':cmd,'run':command,'exit_code':code,'scope':'Isolated consistent height ownership prototype; not integrated.'},indent=2)+'\n');print('Slice prototype exit',code)
