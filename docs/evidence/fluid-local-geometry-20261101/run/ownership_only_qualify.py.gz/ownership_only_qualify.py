from pathlib import Path
import subprocess,time,json,hashlib
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';d=c/'final';d.mkdir(exist_ok=True);results=[]
names=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/ProductionFluidCoupling.cpp','tests/FluidVerticalSupportTests.cpp','tests/ProductionFluidTests.cpp'];hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names};(d/'SOURCE_BEFORE.json').write_text(json.dumps(hashes,indent=2))
checks=[('vertical','judas_fluid_vertical_support_tests',[]),('hydrostatics','judas_fluid_hydrostatics_tests',[]),('lateral','judas_fluid_wet_support_tests',[]),('contract','judas_fluid_settling_contract_tests',[]),('reference','judas_fluid_settling_reference_tests',[]),('production','judas_production_fluid_tests',['--output',str(d/'production')]),('legacy','judas_production_fluid_tests',['--legacy-four-second','--output',str(d/'legacy')])]
for name,target,args in checks:
 cmd=[str(b/target),*args];start=time.monotonic()
 with (d/(name+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':cmd,'exit_code':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((b/target).read_bytes()).hexdigest()});(d/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True)
for n,h in hashes.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
(d/'SOURCE_UNCHANGED.json').write_text(json.dumps(hashes,indent=2))
