from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build'
s=(r/'src/FluidHydrostatics.cpp').read_text();needle='const glm::dvec3 projectedTangent=glm::dvec3(tangentAxis)-up*glm::dot(up,glm::dvec3(tangentAxis));';assert needle in s
s=s.replace(needle,'''glm::dvec3 projectedTangent=glm::dvec3(tangentAxis)-up*glm::dot(up,glm::dvec3(tangentAxis));
    // Disposable diagnostic only: field-owned lattice instead of body axes.
    for(std::size_t i=1;i<m_particles.size();++i) {
        const auto edge=glm::dvec3(m_particles[i].position)-glm::dvec3(m_particles.front().position);
        const auto horizontal=edge-up*glm::dot(up,edge);
        if(glm::dot(horizontal,horizontal)>.25*glm::dot(edge,edge)) {projectedTangent=horizontal;break;}
    }''');(c/'FieldBasis.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'FieldBasis.cpp'),'-o',str(c/'field-basis.o')];subprocess.run(cmd,check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'field-basis') if x=='judas_production_fluid_tests' else x for x in a];a.insert(a.index('libjudas_engine.a'),str(c/'field-basis.o'));subprocess.run(a,cwd=b,check=True)
results=[]
for case in ['half_020','rotated_half']:
 command=[str(c/'field-basis'),'--case',case,'--output',str(c/('field-basis-'+case))]
 with (c/('field-basis-'+case+'.log')).open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 results.append({'case':case,'command':command,'exit_code':code});print(case,code,flush=True)
(c/'FIELD_BASIS_COMMANDS.json').write_text(json.dumps({'compile':cmd,'link':a,'cwd':str(b),'runs':results,'status':'Disposable diagnostic, not integrated and not a public Query API change.'},indent=2))
