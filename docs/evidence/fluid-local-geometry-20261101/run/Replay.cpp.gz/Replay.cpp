#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <string>
#include <cmath>
struct Uniform:GravityField {glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};}};
std::vector<std::vector<double>> Read(const std::string& path){std::ifstream f(path);std::string line;std::getline(f,line);std::vector<std::vector<double>> rows;while(std::getline(f,line)){std::istringstream s(line);std::string v;std::vector<double> row;while(std::getline(s,v,','))row.push_back(std::stod(v));rows.push_back(row);}if(rows.empty())throw std::runtime_error("empty input "+path);return rows;}
int main(int argc,char**argv){if(argc<3)return 2;auto body=Read(argv[1]).at(0);auto raw=Read(argv[2]);BodyTransform pose;pose.position={body[0],body[1],body[2]};pose.rotation={body[3],body[4],body[5],body[6]};glm::vec3 half(body[7],body[8],body[9]);std::vector<FluidParticle> p;
for(auto&v:raw){FluidParticle a;a.position={v[0],v[1],v[2]};a.velocity={v[3],v[4],v[5]};a.acceleration={v[6],v[7],v[8]};a.mass=v[9];p.push_back(a);}Uniform gravity;FluidHydrostaticField field;field.Build(p,1000);std::cout<<std::setprecision(17);
if(argc>3 && std::string(argv[3])=="sweep"){
 std::cout<<"dy,fraction,fx,fy,fz,tx,ty,tz\n";auto v=MakeBoxFluidVolume(half);for(int i=-100;i<=100;++i){auto b=pose;b.position.y+=i*.0001f;auto h=EvaluateFluidHydrostatics(field,v,b,gravity);std::cout<<i*.0001<<','<<h.fraction<<','<<h.buoyancyForce.x<<','<<h.buoyancyForce.y<<','<<h.buoyancyForce.z<<','<<h.buoyancyTorque.x<<','<<h.buoyancyTorque.y<<','<<h.buoyancyTorque.z<<'\n';}return 0;}
if(argc>3 && std::string(argv[3])=="cycle") {
 std::cout<<"mode,quadrature,angles,net_rotational_work,max_torque\n";
 const auto axis=glm::normalize(glm::vec3(1,2,3));
 for(auto geom:{FluidVolumeGeometry::DisplacedSolid,FluidVolumeGeometry::NonDisplacingVolume})for(unsigned n:{4u,8u})for(int steps:{256,512}) {
  auto volume=MakeBoxFluidVolume(half,n);double work=0,maxT=0,first=0,previous=0;const double delta=2*3.14159265358979323846/steps;
  for(int i=0;i<=steps;++i){auto b=pose;b.rotation=glm::angleAxis(float(i*delta),axis)*pose.rotation;const auto h=EvaluateFluidHydrostatics(field,volume,b,gravity,geom);double t=glm::dot(h.buoyancyTorque,axis);maxT=std::max(maxT,std::abs(t));if(i==0)first=t;else work+=.5*delta*(previous+t);previous=t;}
  std::cout<<(geom==FluidVolumeGeometry::DisplacedSolid?"displaced":"nondisplacing")<<','<<n<<','<<steps<<','<<work<<','<<maxT<<'\n';
 }
 return 0;
}
std::cout<<"kind,spacing,samples,fraction,expected,fx,fy,fz\n";
for(unsigned n:{4u,8u}){auto h=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half,n),pose,gravity);std::cout<<"snapshot,0,"<<n<<','<<h.fraction<<",nan,"<<h.buoyancyForce.x<<','<<h.buoyancyForce.y<<','<<h.buoyancyForce.z<<'\n';}
// A flat free surface at the body's center has exactly half its volume wet,
// for every orientation of a centrally symmetric box. It is not fitted to the
// recorded waterline. Excluding centers inside the solid mimics displaced water.
const float surface=pose.position.y;
for(float spacing:{.25f,.125f,.0625f}){
 std::vector<FluidParticle> water;int rows=std::ceil(surface/spacing);
 for(int z=-16;z<16;++z)for(int x=-16;x<16;++x)for(int y=0;y<rows;++y){glm::vec3 pos(pose.position.x+(x+.5f)*spacing,surface-(y+.5f)*spacing,pose.position.z+(z+.5f)*spacing);glm::vec3 local=glm::inverse(pose.rotation)*(pos-pose.position);if(glm::all(glm::lessThan(glm::abs(local),half)))continue;FluidParticle a;a.position=pos;a.mass=1000*spacing*spacing*spacing;water.push_back(a);}
 FluidHydrostaticField flat;flat.Build(water,1000);for(unsigned n:{4u,8u}){auto h=EvaluateFluidHydrostatics(flat,MakeBoxFluidVolume(half,n),pose,gravity);std::cout<<"known_flat,"<<spacing<<','<<n<<','<<h.fraction<<",0.5,"<<h.buoyancyForce.x<<','<<h.buoyancyForce.y<<','<<h.buoyancyForce.z<<'\n';}
}
}
