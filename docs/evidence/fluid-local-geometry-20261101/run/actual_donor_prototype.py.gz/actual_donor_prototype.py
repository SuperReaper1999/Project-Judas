from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';b=r/'.cache/2d-stage1-build';s=(r/'src/FluidHydrostatics.cpp').read_text();needle='        if(displaced)continue;\n        // Bulk motion retains';assert needle in s;s=s.replace(needle,'        // Bulk motion retains')
needle='''            const auto& p=m_particles[interval.particle];
            const glm::dvec3 d=glm::dvec3(p.position)-glm::dvec3(point);''';assert s.count(needle)==1
s=s.replace(needle,'''            const auto& p=m_particles[interval.particle];
            const auto donorCenter=glm::dvec3(point)+tangent*columns[k].actualX+bitangent*columns[k].actualZ;
            if(occlusion && occlusion->Occluded(donorCenter))continue;
            const glm::dvec3 d=glm::dvec3(p.position)-glm::dvec3(point);''');(c/'ActualDonors.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'ActualDonors.cpp'),'-o',str(c/'actual-donors.o')];subprocess.run(cmd,check=True)
results=[]
for target in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests']:
 a=shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text());a=[str(c/('actual-'+target)) if x==target else x for x in a];a.insert(a.index('libjudas_engine.a'),str(c/'actual-donors.o'));subprocess.run(a,cwd=b,check=True)
 with (c/('actual-'+target+'.log')).open('w') as log:code=subprocess.run([str(c/('actual-'+target))],stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'target':target,'code':code});print(target,code,flush=True)
(c/'ACTUAL_DONOR_RESULTS.json').write_text(json.dumps(results,indent=2))
