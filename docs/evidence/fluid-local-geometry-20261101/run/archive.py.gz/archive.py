from pathlib import Path
import hashlib,gzip,json,shutil,subprocess,datetime,difflib
r=Path.cwd();c=r/'.cache/fluid-local-geometry-20261101';e=r/'docs/evidence/fluid-local-geometry-20261101';e.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,d):
 d.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.json':shutil.copyfile(p,d)
 else:d.with_name(d.name+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
# Preserve all final and intermediate qualification results; omit build binaries/objects.
for folder in ['final','ownership-only-final','field-basis-only-final','negative-controls','inflated-gap-control','always-sliced-preserved']:
 for p in (c/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.log','.csv','.judas','.cpp','.txt'}:copy(p,e/'run'/p.relative_to(c))
for p in c.iterdir():
 if p.is_file() and p.suffix in {'.py','.cpp','.h','.json','.log','.csv'}:copy(p,e/'run'/p.name)
# Only causal late captures are needed in the portable evidence, not every temporary snapshot.
for p in (c/'coarse').glob('*'):
 if p.is_file() and (p.name=='half_025.csv' or any(f'before{x}_' in p.name for x in [541,542,543,622,623,624,650,651,652,653,686,687])):copy(p,e/'run/coarse'/p.name)
files=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidColumnLayers.h','src/FluidWetFootprint.h','src/FluidSolidSupport.h','src/ProductionFluidCoupling.cpp','tests/FluidVerticalSupportTests.cpp','tests/FluidHydrostaticsTests.cpp','tests/ProductionFluidTests.cpp','tests/FluidSettlingContract.h','tests/FluidSettlingContractTests.cpp','tests/FluidSettlingReferenceTests.cpp','CMakeLists.txt','tools/validation/suites.json','docs/FLUID_LOCAL_GEOMETRY_SETTLING.md']
for f in files:copy(r/f,e/'source'/f)
patch=''
for old,new in [(c/'BeforeOwnershipFix.cpp',r/'src/FluidHydrostatics.cpp'),(c/'BeforeVerticalTests.cpp',r/'tests/FluidVerticalSupportTests.cpp')]:patch+=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old.relative_to(r)),tofile=str(new.relative_to(r))))
(e/'TASK_PATCH.diff.gz').write_bytes(gzip.compress(patch.encode(),mtime=0))
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
source=json.loads((c/'final/SOURCE_UNCHANGED.json').read_text())
for n,h in source.items():assert sha(r/n)==h,n
prior=json.loads((r/'.cache/fluid-window-contract-20261101/PRE_RUN_SOURCE_HASHES.json').read_text());assert sha(r/'src/ProductionFluidCoupling.cpp')==prior['src/ProductionFluidCoupling.cpp'];assert sha(r/'tests/ProductionFluidTests.cpp')==prior['tests/ProductionFluidTests.cpp']
prov={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'main':git('rev-parse','main'),'origin_main':git('rev-parse','origin/main'),'branch':git('branch','--show-current'),'index_empty':not bool(git('diff','--cached','--name-only')),'status':'Uncommitted, Alpha lock retained. Read final failed results; not an unlock qualification.','source_sha256':{n:sha(r/n) for n in files},'unchanged_coupling_sha256':sha(r/'src/ProductionFluidCoupling.cpp'),'unchanged_acceptance_driver_sha256':sha(r/'tests/ProductionFluidTests.cpp'),'binary_sha256':{name:sha(r/'.cache/2d-stage1-build'/name) for name in ['judas_production_fluid_tests','judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests','judas_player_swimming_tests','judas_project_fluid_policy_tests','judas_fluid_lifecycle_qualification_tests']}}
assert prov['index_empty'];(e/'FINAL_PROVENANCE.json').write_text(json.dumps(prov,indent=2)+'\n')
(e/'README.txt').write_text('Local wet geometry and settling — 2026-11-01\n\nRead ../../FLUID_LOCAL_GEOMETRY_SETTLING.md and FINAL_RESULTS.md.\nrun/final is the combined final-source qualification.\nrun/ownership-only-final and run/field-basis-only-final preserve the intermediate failures.\nrun/negative-controls links pre-fix or rejected reconstruction objects against final regression fixtures.\nrun/coarse contains exact captured inputs around the largest original jumps.\nrun/coarse-forces.csv.gz and COARSE_TRACE_ANALYSIS retain the original 720-step force replay.\nrun/MANUFACTURED_ORACLE_CONTROLS.json demonstrates flat-plane observation failure.\nrun/inflated-gap-control preserves the invalid manufactured-flat expectation; do not cite it as a physics failure.\nrun/always-sliced-preserved explains the first exploratory output reuse and retained console metrics. The rejected all-query method is also rerun under negative-controls with fresh raw output.\nsource contains final implementation/tests and registration snapshots.\nCompressed text uses deterministic gzip (mtime=0); JSON is uncompressed.\nNo binaries or unrelated research are bundled. Hashes identify tested binaries.\nTASK_PATCH.diff.gz isolates implementation/test changes from the prior dirty candidate.\nSHA256SUMS.json covers all files except itself.\nNo commit, push, main promotion, release or fluid unlock occurred.\n')
manifest={str(p.relative_to(e)):sha(p) for p in sorted(e.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};(e/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n,h in manifest.items():assert sha(e/n)==h,n
print(len(manifest),'verified files;',sum(p.stat().st_size for p in e.rglob('*') if p.is_file()),'bytes')
