#include "Interval.h"
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <random>
#include <cstdio>
using Big=boost::multiprecision::number<boost::multiprecision::cpp_bin_float<100>>;
unsigned checks=0;
void Check(bool pass,const char* why){++checks;if(!pass)throw std::runtime_error(why);}
template<class F>void Run(){using I=filtered::Interval<F>;std::mt19937_64 random(0x24681357);unsigned accepted=0,rejected=0;for(unsigned k=0;k<3000;++k){const int exponent=int(random()%1200)-600;const long double x=std::ldexp((static_cast<long double>(int(random()%20001)-10000))/8192,exponent),y=std::ldexp((static_cast<long double>(int(random()%20001)-10000))/8192,int(random()%1200)-600);try{const I a=I::FromReal(x),b=I::FromReal(y);const Big ax=x,by=y;Check(Big(a.lo)<=ax&&ax<=Big(a.hi),"input interval missed actual source");auto enclosed=[&](I out,Big exact){Check(Big(out.lo)<=exact&&exact<=Big(out.hi),"ordinary interval missed independent100digit arithmetic");++accepted;};enclosed(a+b,ax+by);enclosed(a-b,ax-by);enclosed(a*b,ax*by);if(by!=0)enclosed(a/b,ax/by);}catch(const filtered::NeedPrecision&){++rejected;}}
 const I third=I(F(1))/I(F(3));const Big truth=Big(1)/3;Check(Big(third.lo)<=truth&&truth<=Big(third.hi),"division enclosure failed");Check(!(Big(third.value)<=truth&&truth<=Big(third.value)),"oracle must reject a fake zero-width rounded third");Check(accepted>5000,"interval test cannot pass by rejecting all operations");const I zero(F(0));Check((zero*I(F(12))).Zero(),"exact zero identity should remain exact");printf("INTERVAL_ARITHMETIC digits=%d accepted=%u inconclusive=%u checks=%u\n",std::numeric_limits<F>::digits,accepted,rejected,checks);}
int main(){try{Run<double>();Run<long double>();printf("ARITHMETIC_SUMMARY checks=%u failures=0 independent_decimal_digits=100\n",checks);return 0;}catch(const std::exception& e){fprintf(stderr,"FAIL after%uchecks %s\n",checks,e.what());return 1;}}
