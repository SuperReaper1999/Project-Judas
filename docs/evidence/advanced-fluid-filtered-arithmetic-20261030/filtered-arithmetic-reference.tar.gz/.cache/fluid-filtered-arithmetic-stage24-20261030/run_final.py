from pathlib import Path
import os,subprocess,time,json,hashlib
root=Path(__file__).resolve().parent
boost=os.environ.get('BOOST_INCLUDE_DIR','.cache/fluid-reference-headers/boost/usr/include')
eigen=os.environ.get('EIGEN_INCLUDE_DIR','.cache/fluid-reference-headers/eigen/usr/include/eigen3')
rows=[]
for name in ('Qualification','Controls','ArithmeticTests','Oracle','RangeControl'):
 src=root/(name+'.cpp');exe=root/(name+'.final')
 command=['g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc','-I'+boost,'-I'+eigen,str(src),'-o',str(exe)]
 start=time.time()
 with (root/(name+'-final-compile.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 row={'name':name,'command':command,'compileReturncode':code,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest()}
 if code==0:
  with (root/(name+'-final.log')).open('w') as f:row['returncode']=subprocess.run([str(exe)],stdout=f,stderr=subprocess.STDOUT).returncode
  row['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
 row['elapsedSeconds']=time.time()-start;rows.append(row);(root/'final-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code or row.get('returncode'):raise SystemExit(1)
