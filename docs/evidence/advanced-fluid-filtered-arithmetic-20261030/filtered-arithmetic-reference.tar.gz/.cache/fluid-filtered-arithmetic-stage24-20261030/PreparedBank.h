#pragma once
#include "Interval.h"
#include "../fluid-cost-precision-stage23-20261030/OptimizedTransport.h"
namespace filtered {
using namespace optimized_affine;
template<class F>struct Bank {
    using I=Interval<F>;
    struct Cell {unsigned dimension=0;std::vector<I> projection,map;std::array<I,16> gram;std::array<I,3> center;I density,volume;};
    struct Triangle {std::array<unsigned,3> vertices;I area;std::array<std::array<I,3>,3> x;};
    struct Face {std::vector<std::array<I,3>> vertexMap;std::vector<Triangle> triangles;std::array<std::array<I,3>,2> offsets;};
    std::vector<Cell> cells;std::vector<Face> faces;bool valid=false;
    explicit Bank(const optimized_affine::Transport& reference){try{
        for(unsigned c=0;c<reference.world.cells.size();++c){const auto& source=*reference.world.cells[c];const auto& op=source.op;Cell out;out.dimension=op.dimension;out.density=I::FromReal(op.geometry.density);out.volume=I::Exact(source.cell.exactVolume);for(unsigned a=0;a<3;++a)out.center[a]=I::Exact(source.cell.center[a]);for(unsigned a=0;a<12;++a)for(unsigned j=0;j<out.dimension;++j)out.projection.push_back(I::FromReal(op.projection(a,j)));for(unsigned j=0;j<out.dimension;++j)for(unsigned a=0;a<12;++a)out.map.push_back(I::Exact(reference.riesz[c].solve.map(j,a)));for(unsigned a=0;a<4;++a)for(unsigned b=0;b<4;++b)out.gram[4*a+b]=I::FromReal(op.geometry.volume[vm::ProductIndex(a,b)]);cells.push_back(std::move(out));}
        for(unsigned index=0;index<reference.faces.ports.size();++index){const auto& source=reference.faces.ports[index];const auto& cached=reference.prepared[index];Face out;for(const auto& row:cached.valuesFromMoments){std::array<I,3> value;for(unsigned a=0;a<3;++a)value[a]=I::Exact(row[a]);out.vertexMap.push_back(value);}for(const auto& triangle:cached.triangles){Triangle t;t.vertices=triangle.vertex;t.area=I::Exact(triangle.area);out.triangles.push_back(t);}for(unsigned t=0;t<out.triangles.size();++t)for(unsigned v=0;v<3;++v)for(unsigned a=0;a<3;++a)out.triangles[t].x[v][a]=I::Exact(R(source.triangles[t].points[v][a]-cached.anchor[a]));for(unsigned side=0;side<2;++side)for(unsigned a=0;a<3;++a)out.offsets[side][a]=I::Exact(R(cached.anchor[a]-reference.world.cells[side?source.b:source.a]->cell.center[a]));faces.push_back(std::move(out));}
        valid=true;
    }catch(const NeedPrecision&){valid=false;}}
};
} // namespace filtered
