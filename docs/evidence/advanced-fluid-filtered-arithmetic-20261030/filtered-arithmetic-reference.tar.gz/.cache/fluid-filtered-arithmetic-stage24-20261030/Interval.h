#pragma once
#if defined(__FAST_MATH__)
#error "Filtered fluid arithmetic requires IEEE semantics; do not use -ffast-math."
#endif
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
namespace filtered {
template<class F>bool GradualUnderflow(){volatile F normal=std::numeric_limits<F>::min();volatile F subnormal=normal/F(2);volatile F retained=subnormal*F(1.25);return subnormal>0&&retained>0;}
struct NeedPrecision:std::runtime_error {using std::runtime_error::runtime_error;};
template<class F> struct Interval {
    F value=0,lo=0,hi=0;
    Interval()=default;
    explicit Interval(F x):value(x),lo(x),hi(x){if(!std::isfinite(x))throw NeedPrecision("nonfinite ordinary input");}
    static F Down(F x){if(!std::isfinite(x))throw NeedPrecision("ordinary overflow");return std::nextafter(x,-std::numeric_limits<F>::infinity());}
    static F Up(F x){if(!std::isfinite(x))throw NeedPrecision("ordinary overflow");return std::nextafter(x,std::numeric_limits<F>::infinity());}
    static Interval Bounds(F v,F a,F b){Interval r;r.value=v;r.lo=a;r.hi=b;if(!std::isfinite(v)||!std::isfinite(a)||!std::isfinite(b))throw NeedPrecision("ordinary interval not finite");return r;}
    bool Zero()const{return lo==0&&hi==0;}
    static Interval FromReal(long double x){F v=static_cast<F>(x);Interval r(v);if(static_cast<long double>(v)>x)r.lo=Down(v);if(static_cast<long double>(v)<x)r.hi=Up(v);return r;}
    template<class R>static Interval Exact(const R& x){F v=x.template convert_to<F>();Interval r(v);for(unsigned k=0;k<3&&R(r.lo)>x;++k)r.lo=Down(r.lo);for(unsigned k=0;k<3&&R(r.hi)<x;++k)r.hi=Up(r.hi);if(R(r.lo)>x||R(r.hi)<x)throw NeedPrecision("source conversion not enclosed");return r;}
    friend Interval operator-(const Interval& a){return Bounds(-a.value,-a.hi,-a.lo);}
    friend Interval operator+(const Interval& a,const Interval& b){if(a.Zero())return b;if(b.Zero())return a;return Bounds(a.value+b.value,Down(a.lo+b.lo),Up(a.hi+b.hi));}
    friend Interval operator-(const Interval& a,const Interval& b){return a+(-b);}
    friend Interval operator*(const Interval& a,const Interval& b){if(a.Zero()||b.Zero())return Interval();const F aa=a.lo*b.lo,ab=a.lo*b.hi,ba=a.hi*b.lo,bb=a.hi*b.hi;return Bounds(a.value*b.value,Down(std::min({aa,ab,ba,bb})),Up(std::max({aa,ab,ba,bb})));}
    friend Interval operator/(const Interval& a,const Interval& b){if(b.lo<=0&&b.hi>=0)throw NeedPrecision("uncertain ordinary divisor");if(a.Zero())return Interval();const F aa=a.lo/b.lo,ab=a.lo/b.hi,ba=a.hi/b.lo,bb=a.hi/b.hi;return Bounds(a.value/b.value,Down(std::min({aa,ab,ba,bb})),Up(std::max({aa,ab,ba,bb})));}
    Interval& operator+=(const Interval& b){return *this=*this+b;}
    Interval& operator-=(const Interval& b){return *this=*this-b;}
    Interval& operator*=(const Interval& b){return *this=*this*b;}
    Interval Abs()const{if(lo>=0)return *this;if(hi<=0)return -*this;return Bounds(std::abs(value),0,std::max(-lo,hi));}
    F Magnitude()const{return std::max(std::abs(lo),std::abs(hi));}
    bool Within(F bound)const{return lo>=-bound&&hi<=bound;}
};
} // namespace filtered
