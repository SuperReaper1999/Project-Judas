#include "GameWaterLabScene.h"
#include <iostream>
int main(){WaterLab::Scene scene(2,false,true);for(int k=0;k<2400;++k)scene.Advance();
auto& g=scene.water;std::cout<<"pockets "<<g.Air().size()<<"\n";
for(int a=0;a<int(g.Air().size());++a){auto air=g.Air()[a];glm::vec3 lo(1e6),hi(-1e6);unsigned count=0;for(int i=0;i<int(g.Cells().size());++i)if(g.Cells()[i].air==a){lo=glm::min(lo,g.Center(i));hi=glm::max(hi,g.Center(i));++count;}if(!air.atmosphere)std::cout<<a<<" p "<<air.pressure<<" volume "<<air.volume<<" mass "<<air.mass<<" cells "<<count<<" low "<<lo.x<<","<<lo.y<<","<<lo.z<<" high "<<hi.x<<","<<hi.y<<","<<hi.z<<"\n";}
for(int z=9;z<=10;++z)for(int x=19;x<=20;++x)for(int y=5;y<=8;++y){int i=g.Index(x,y,z);auto c=g.Cells()[i];std::cout<<"vent "<<x<<","<<y<<","<<z<<" water "<<c.water<<" cap "<<c.capacity<<" air "<<c.air<<" p "<<c.pressure<<"\n";}
}
