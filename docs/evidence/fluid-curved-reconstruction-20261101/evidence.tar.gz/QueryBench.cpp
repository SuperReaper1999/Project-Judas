#include "FluidHydrostatics.h"
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
int main(){std::cout<<std::setprecision(17)<<"case,batch,queries,microseconds_per_query,checksum\n";
 for(int shape:{0,1,2}){std::vector<FluidParticle> ps;for(int z=0;z<8;++z)for(int x=0;x<8;++x)for(int y=0;y<8;++y){float px=-1+(x+.5f)*.25f,pz=-1+(z+.5f)*.25f;float h=shape==0?0:shape==1? .5f*(px*px+pz*pz):-.5f*(px*px+pz*pz);FluidParticle p;p.position={px,h-(y+.5f)*.25f,pz};p.mass=15.625f;ps.push_back(p);}FluidHydrostaticField f;f.Build(ps,1000);
  for(int batch=0;batch<5;++batch){double sum=0;auto start=std::chrono::steady_clock::now();for(int i=0;i<200;++i){auto a=f.Query({.01f*(i%9),.005f*(i%11),-.01f*(i%7)},{0,1,0},.1f,.5f,{1,0,0},nullptr,true);sum+=a.fraction;}double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/200;std::cout<<shape<<','<<batch<<",200,"<<us<<','<<sum<<'\n';}
 }
}
