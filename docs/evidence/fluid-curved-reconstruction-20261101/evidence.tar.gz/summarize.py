from pathlib import Path
import csv,json,math,re,statistics,hashlib,subprocess,platform,datetime
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101'
known=list(csv.DictReader((c/'qualified-known.csv').open()));groups={}
for row in known:
 if row['spacing']=='0.25' and row['height_case']=='0' and row['displaced']=='1' and row['frame']=='0':groups[row['case']]={k:float(row[k]) for k in ['expected','engine','observer']}
failures=[row for row in known if abs(float(row['engine'])-float(row['expected']))>.10]
summary=dict(start_commit='03fbd812963d6190f18a881cf68ec44339c4f326',known=dict(cases=len(known),engine_failures=len(failures),failure_classes=sorted(set((x['spacing'],x['height_case'],x['displaced']) for x in failures)),coarse_half=groups))
if (c/'additional-final.csv').exists():
 summary['additional']=[{**x,'absolute_error':abs(float(x['engine'])-float(x['reference96'])),'reference_disagreement':abs(float(x['reference64'])-float(x['reference96']))} for x in csv.DictReader((c/'additional-final.csv').open())]
measurements={}
for kind in ['before','after']:
 for shape in ['0','1','2']:
  rows=[]
  for file in c.glob('query-[0-9]-'+kind+'.csv'):rows += [float(x['microseconds_per_query']) for x in csv.DictReader(file.open()) if x['case']==shape]
  if rows:
   a=sorted(rows);measurements[kind+'-'+shape]=dict(batches=len(a),queries_per_batch=200,median_us=statistics.median(a),p95_us=a[math.ceil(.95*len(a))-1],worst_us=max(a))
summary['query_cost']=measurements
logs={}
for f in sorted(c.glob('qualified-judas*.log')):
 lines=f.read_text().splitlines();logs[f.name]=[x for x in lines if 'SUMMARY' in x or ('checks' in x and ('failures' in x or 'failed' in x))][-3:]
summary['log_summaries']=logs
(c/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
files=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidSolidSupport.h','src/FluidWetFootprint.h','src/FluidSurfaceReconstruction.h','tests/FluidHydrostaticsTests.cpp','tests/FluidSurfaceReconstructionChecks.h']
files += [str(x.relative_to(r)) for x in (r/'.cache/2d-stage1-build').glob('judas*') if x.is_file() and (x.name in [v['target'] for v in json.loads((c/'QUALIFIED_RESULTS.json').read_text())])]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(c/'FINGERPRINTS.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),platform=platform.platform(),base_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={f:sha(r/f) for f in files},policy='Final source candidate; no main promotion or Alpha unlock.'),indent=2))
print(json.dumps(summary,indent=2))
