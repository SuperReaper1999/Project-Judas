from pathlib import Path
import subprocess,shlex,json,time,hashlib
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';b=r/'.cache/2d-stage1-build';source=(r/'src/FluidHydrostatics.cpp').read_text();s=source.replace('#include "GravityField.h"','#include "GravityField.h"\n#include "CurvedPatch.h"')
needle='    const auto occupiedLength=[]'
insert='''    std::optional<FluidHydrostaticDetail::CurvedSurfacePatch> surface;
    if(connectedWetSupport && profiles.size()>=12) {
        std::optional<FluidHydrostaticDetail::PreparedSolidQuery> projection;
        if(solid) {
            const double fullHeight=solid->volume.boundRadius+glm::length(glm::dvec3(solid->pose.position)-glm::dvec3(point))+columnWidth;
            projection.emplace(tangent,up,bitangent,columnWidth,fullHeight,*solid);
        }
        std::vector<FluidHydrostaticDetail::SurfaceDatum> data;
        std::vector<glm::dvec2> hull;
        bool singleLayer=true;
        for(const auto& profile:profiles) {
            std::size_t top=profile.begin;
            for(std::size_t k=profile.begin+1;k<profile.end;++k)
                if(columns[k].interval.hi>columns[top].interval.hi)top=k;
            const auto& column=columns[top];
            const auto location=glm::dvec3(point)+tangent*column.actualX+bitangent*column.actualZ;
            if(projection && projection->Occluded(location))continue;
            if(profile.high>=verticalReach-columnWidth || profile.low>=-halfHeight)continue;
            std::vector<HeightSpan> spans;
            for(std::size_t k=profile.begin;k<profile.end;++k)spans.emplace_back(columns[k].interval.lo,columns[k].interval.hi);
            FluidHydrostaticDetail::CloseColumnLayers(spans,columnWidth,rounding);
            if(spans.size()!=1){singleLayer=false;break;}
            data.push_back({column.actualX,column.actualZ,profile.high,profile.weight});
            hull.emplace_back(column.actualX,column.actualZ);
        }
        if(singleLayer && data.size()>=12 && FluidWetFootprintContainsOrigin(hull))
            surface=FluidHydrostaticDetail::FitCurvedSurface(data,reach,columnWidth);
    }
'''
assert needle in s;s=s.replace(needle,insert+needle)
needle='        return total>0 ? weighted/total : 0.0;'
s=s.replace(needle,'''        const double original=total>0 ? weighted/total : 0.0;
        if(surface && layered) {
            const double reconstructed=middle<=surface->height ? 1.0 : 0.0;
            return original+surface->confidence*(reconstructed-original);
        }
        return original;''')
needle='            if(total>0)out.fraction=static_cast<float>(occupied/(total*(halfHeight>0 ? 2*halfHeight : 1)));'
s=s.replace(needle,'''            if(total>0) {
                double fraction=occupied/(total*(halfHeight>0 ? 2*halfHeight : 1));
                if(surface) {
                    const double cap=surface->height;
                    double represented=0;
                    const auto add=[&](double lo,double hi) {
                        if(halfHeight==0)return lo<=0 && hi>=0 && cap>=0 ? 1.0 : 0.0;
                        return std::max(0.0,std::min({hi,cap,double(halfHeight)})-std::max(lo,-double(halfHeight)));
                    };
                    if(root->continuous)represented=add(root->low,root->high);
                    else for(const auto& span:root->layers)represented+=add(span.first,span.second);
                    if(halfHeight>0)represented/=2*halfHeight;
                    fraction+=surface->confidence*(represented-fraction);
                }
                out.fraction=static_cast<float>(fraction);
            }''')
needle='        std::sort(cuts.begin(),cuts.end());'
s=s.replace(needle,'''        if(surface && surface->height>-halfHeight && surface->height<halfHeight)cuts.push_back(surface->height);
'''+needle)
(c/'CurvedHydrostatics.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(c),*get('CXX_FLAGS'),'-c',str(c/'CurvedHydrostatics.cpp'),'-o',str(c/'curved.o')]
with (c/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'known-curved') if x=='judas_fluid_known_geometry_tests' else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'curved.o')];subprocess.run(a,cwd=b,check=True)
cmd=[str(c/'known-curved'),'--output',str(c/'known-curved.csv')];t=time.monotonic()
with (c/'known-curved.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
(c/'PROTOTYPE.json').write_text(json.dumps({'command':cmd,'exit_code':code,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256((c/'CurvedHydrostatics.cpp').read_bytes()).hexdigest()},indent=2));print((c/'known-curved.log').read_text(),flush=True)
