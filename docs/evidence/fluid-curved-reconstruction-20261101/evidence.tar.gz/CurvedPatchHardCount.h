#pragma once
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
#include <limits>
#include <optional>
namespace FluidHydrostaticDetail {
struct SurfaceDatum { double x,z,height,weight; };
struct CurvedSurfacePatch { double height=0,confidence=0,residual=0; };
inline std::optional<CurvedSurfacePatch> FitCurvedSurface(
    const std::vector<SurfaceDatum>& data,double scale,double spacing) {
    if(data.size()<12 || !(scale>0) || !(spacing>0))return {};
    std::vector<std::array<double,7>> a;
    a.reserve(data.size());
    for(const auto& d:data) {
        const double x=d.x/scale,z=d.z/scale,w=std::sqrt(d.weight);
        a.push_back({w,w*x,w*z,w*x*x,w*x*z,w*z*z,w*d.height});
    }
    // Householder QR on the six-dimensional polynomial basis. Coordinates
    // are relative to the query, normalized by the represented search scale.
    double largest=0,smallest=std::numeric_limits<double>::infinity();
    for(std::size_t k=0;k<6;++k) {
        double norm=0;for(std::size_t i=k;i<a.size();++i)norm=std::hypot(norm,a[i][k]);
        if(!(norm>0) || !std::isfinite(norm))return {};
        const double diagonal=-std::copysign(norm,a[k][k]);
        largest=std::max(largest,norm);smallest=std::min(smallest,norm);
        if(norm<=128*std::numeric_limits<double>::epsilon()*largest)return {};
        std::vector<double> v(a.size()-k);
        for(std::size_t i=k;i<a.size();++i)v[i-k]=a[i][k];
        v[0]-=diagonal;
        double vv=0;for(double value:v)vv+=value*value;
        for(std::size_t j=k;j<7;++j) {
            double product=0;for(std::size_t i=k;i<a.size();++i)product+=v[i-k]*a[i][j];
            const double factor=2*product/vv;
            for(std::size_t i=k;i<a.size();++i)a[i][j]-=factor*v[i-k];
        }
        a[k][k]=diagonal;
    }
    std::array<double,6> c{};
    for(int k=5;k>=0;--k) {
        double value=a[static_cast<std::size_t>(k)][6];
        for(int j=k+1;j<6;++j)value-=a[static_cast<std::size_t>(k)][static_cast<std::size_t>(j)]*c[static_cast<std::size_t>(j)];
        c[static_cast<std::size_t>(k)]=value/a[static_cast<std::size_t>(k)][static_cast<std::size_t>(k)];
        if(!std::isfinite(c[static_cast<std::size_t>(k)]))return {};
    }
    double residual=0;
    for(const auto& d:data) {
        const double x=d.x/scale,z=d.z/scale;
        residual=std::max(residual,std::abs(c[0]+c[1]*x+c[2]*z+c[3]*x*x+c[4]*x*z+c[5]*z*z-d.height));
    }
    const auto smooth=[](double x){x=std::clamp(x,0.,1.);return x*x*(3-2*x);};
    const double rankThreshold=std::sqrt(std::numeric_limits<double>::epsilon());
    const double condition=smooth((smallest/largest-rankThreshold)/rankThreshold);
    const double confidence=condition*smooth(1-residual/(spacing*.25));
    return CurvedSurfacePatch{c[0],confidence,residual};
}
}
