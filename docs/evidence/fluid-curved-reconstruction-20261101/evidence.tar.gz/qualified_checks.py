from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();cache=root/'.cache/fluid-curved-reconstruction-20261101';build=root/'.cache/2d-stage1-build'
env=dict(os.environ,JUDAS_ENGINE_ROOT=str(root));results=[]
def run(name,args,timeout=600):
 cmd=[str(build/name),*map(str,args)];start=time.monotonic()
 with (cache/('qualified-'+name+'.log')).open('w') as log:
  try: code=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(target=name,command=cmd,exit_code=code,seconds=time.monotonic()-start))
 (cache/'QUALIFIED_RESULTS.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
for name in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests','judas_fluid_volume_drag_tests','judas_fluid_boundary_contact_tests','judas_fluid_lifecycle_qualification_tests','judas_project_fluid_policy_tests','judas_project_water_tests']:
 run(name,[])
run('judas_fluid_known_geometry_tests',['--output',cache/'qualified-known.csv'])
run('judas_production_fluid_tests',['--output',cache/'qualified-production'],900)
run('judas_fluid_demo_integration_tests',['--output',cache/'qualified-demos'],600)
run('judas_player_fluid_integration_tests',['--output',cache/'qualified-player'],900)
