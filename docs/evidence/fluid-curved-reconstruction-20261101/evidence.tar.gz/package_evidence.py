from pathlib import Path
import hashlib,json,tarfile,shutil,subprocess
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';e=r/'docs/evidence/fluid-curved-reconstruction-20261101';e.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Preserve the exact final sources, since the experimental directories contain
# deliberately rejected copies with the same include names.
snapshot=c/'final-source'
for f in ['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidSolidSupport.h','src/FluidWetFootprint.h','src/FluidSurfaceReconstruction.h','tests/FluidHydrostaticsTests.cpp','tests/FluidSurfaceReconstructionChecks.h']:
 dest=snapshot/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/f,dest)
for f in ['flags.make','link.txt']:
 shutil.copy2(r/'.cache/2d-stage1-build/CMakeFiles/judas_production_fluid_tests.dir'/f,c/('build-'+f))
binaries={str(p.relative_to(c)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in c.iterdir() if p.is_file() and (p.suffix=='.o' or p.read_bytes()[:4]==b'\x7fELF')}
(c/'LOCAL_BINARY_FINGERPRINTS.json').write_text(json.dumps(binaries,indent=2))
subprocess.run(['git','diff','--check'],check=True)
files=sorted(p for p in c.rglob('*') if p.is_file() and p.suffix in {'.cpp','.h','.py','.txt','.json','.csv','.log','.make'} and p.name!='EVIDENCE_MANIFEST.json')
manifest={str(p.relative_to(c)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
(c/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
files.append(c/'EVIDENCE_MANIFEST.json')
archive=e/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(c)),recursive=False)
# Verify the archive against exact uncompressed source bytes before recording.
with tarfile.open(archive,'r:gz') as tar:
 for name,entry in manifest.items():
  assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==entry['sha256'],name
for name in ['SUMMARY.json','FINGERPRINTS.json','QUALIFIED_RESULTS.json','COMPARISON.json']:
 shutil.copy2(c/name,e/name)
(e/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(e.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
print('archive_bytes',archive.stat().st_size,'entries',len(files))
