#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
struct Uniform:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};}};
double Height(int type,double x,double z){return type==0?0:type==1?.5*(x*x+z*z):type==2?-.5*(x*x+z*z):.1*std::sin(3.141592653589793*x)*std::cos(3.141592653589793*z);}
double Reference(int shape,int surface,glm::quat turn,int n){long wet=0,total=0;for(int z=0;z<n;++z)for(int y=0;y<n;++y)for(int x=0;x<n;++x){glm::dvec3 local=(glm::dvec3(2*x+1,2*y+1,2*z+1)/double(n)-1.)*.3;if(shape==1 && glm::dot(local,local)>.09)continue;auto p=glm::dquat(turn)*local;++total;wet+=p.y<Height(surface,p.x,p.z);}return double(wet)/total;}
int main(){Uniform gravity;std::cout<<std::setprecision(17)<<"shape,surface,spacing,engine,reference64,reference96\n";
 for(int shape=0;shape<3;++shape)for(int surface=0;surface<4;++surface){auto turn=shape==0?glm::angleAxis(.55f,glm::normalize(glm::vec3(1,0,2))):glm::quat(1,0,0,0);double r64=Reference(shape,surface,turn,64),r96=Reference(shape,surface,turn,96);
  for(float spacing:{.25f,.125f}){std::vector<FluidParticle> particles;int n=int(std::round(2/spacing));for(int z=0;z<n;++z)for(int x=0;x<n;++x)for(int y=0;y<n;++y){float px=-1+(x+.5f)*spacing,pz=-1+(z+.5f)*spacing;FluidParticle p;p.position={px,float(Height(surface,px,pz))-(y+.5f)*spacing,pz};p.mass=1000*spacing*spacing*spacing;auto local=glm::conjugate(turn)*p.position;bool inside=shape==1?glm::dot(local,local)<.3f*.3f:glm::all(glm::lessThan(glm::abs(local),glm::vec3(.3f)));if(!inside)particles.push_back(p);}FluidVolumeQuadrature volume;if(shape==1)volume=MakeSphereFluidVolume(.3f);else if(shape==2)volume=MakeCompoundFluidVolume({{{-.15f,0,0},{.15f,.3f,.3f}},{{.15f,0,0},{.15f,.3f,.3f}}});else volume=MakeBoxFluidVolume(glm::vec3(.3f));FluidHydrostaticField field;field.Build(particles,1000);BodyTransform pose;pose.rotation=turn;auto result=EvaluateFluidHydrostatics(field,volume,pose,gravity);std::cout<<shape<<','<<surface<<','<<spacing<<','<<result.fraction<<','<<r64<<','<<r96<<'\n'<<std::flush;}
 }
}
