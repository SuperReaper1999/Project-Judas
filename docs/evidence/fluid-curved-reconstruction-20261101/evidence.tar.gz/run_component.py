from pathlib import Path
import subprocess,shlex,json,time,sys
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';b=r/'.cache/2d-stage1-build';label=sys.argv[1];f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(c),*get('CXX_FLAGS')]
with (c/(label+'-build.log')).open('w') as log:subprocess.run([*base,'-c',str(c/'CurvedHydrostatics.cpp'),'-o',str(c/'curved.o')],stdout=log,stderr=subprocess.STDOUT,check=True)
results=[]
for target,args in [('judas_fluid_known_geometry_tests',['--output',str(c/(label+'-known.csv'))]),('judas_fluid_vertical_support_tests',[]),('judas_fluid_wet_support_tests',[]),('judas_fluid_hydrostatics_tests',[])]:
 a=[x for x in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/(label+'-'+target)) if x==target else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'curved.o')];subprocess.run(a,cwd=b,check=True)
 cmd=[str(c/(label+'-'+target)),*args];t=time.monotonic()
 with (c/(label+'-'+target+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
 results.append({'target':target,'command':cmd,'exit_code':code,'seconds':time.monotonic()-t});print(target,code,flush=True)
(c/(label+'-RESULTS.json')).write_text(json.dumps(results,indent=2))
