from pathlib import Path
import subprocess,shlex
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/'AdditionalShapes.cpp'),'-o',str(c/'additional.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'additional.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'additional') if x=='judas_production_fluid_tests' else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'curved.o')];subprocess.run(a,cwd=b,check=True)
with (c/'additional.csv').open('w') as log:subprocess.run([str(c/'additional')],stdout=log,check=True,timeout=180)
