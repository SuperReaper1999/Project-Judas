from pathlib import Path
import subprocess,shlex,json,time
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';b=r/'.cache/2d-stage1-build';old=r/'.cache/fluid-known-geometry-20261101'
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text()
get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
base=c/'baseline-source';base.mkdir(exist_ok=True)
(base/'FluidHydrostatics.cpp').write_bytes(subprocess.check_output(['git','show','03fbd812963d6190f18a881cf68ec44339c4f326:src/FluidHydrostatics.cpp']))
with (c/'comparison-build.log').open('w') as log:
 subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(base/'FluidHydrostatics.cpp'),'-o',str(c/'baseline03.o')],stdout=log,stderr=subprocess.STDOUT,check=True)
def link(target,out,mainobj=None,alternate=None):
 a=[x for x in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
 if mainobj:a=[str(mainobj) if x.endswith('ProductionFluidTests.cpp.o') else x for x in a]
 a=[str(out) if x==target else x for x in a]
 if alternate:a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(alternate)]
 subprocess.run(a,cwd=b,check=True)
# New physical assertions must actually reject the old sampling mechanism.
link('judas_fluid_hydrostatics_tests',c/'negative-baseline-hydro',alternate=c/'baseline03.o')
with (c/'negative-baseline-hydro.log').open('w') as log:negative=subprocess.run([str(c/'negative-baseline-hydro')],stdout=log,stderr=subprocess.STDOUT).returncode
link('judas_production_fluid_tests',c/'query-before',old/'QueryBench.o',c/'baseline03.o')
link('judas_production_fluid_tests',c/'query-after',old/'QueryBench.o')
rows=[]
for pair in range(4):
 for kind in (['before','after'] if pair%2==0 else ['after','before']):
  cmd=[str(c/('query-'+kind))];start=time.monotonic();out=subprocess.check_output(cmd,text=True)
  (c/f'query-{pair}-{kind}.csv').write_text(out);rows.append(dict(pair=pair,kind=kind,command=cmd,seconds=time.monotonic()-start))
# Additional shape data use the actual final library, not the prototype object.
link('judas_production_fluid_tests',c/'additional-final',c/'additional.o')
with (c/'additional-final.csv').open('w') as log:subprocess.run([str(c/'additional-final')],stdout=log,check=True)
(c/'COMPARISON.json').write_text(json.dumps(dict(negative_control_exit=negative,runs=rows),indent=2))
print('baseline negative control:',negative,flush=True)
