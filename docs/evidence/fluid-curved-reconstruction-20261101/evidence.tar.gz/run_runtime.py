from pathlib import Path
import subprocess,shlex,json,time
r=Path.cwd();c=r/'.cache/fluid-curved-reconstruction-20261101';b=r/'.cache/2d-stage1-build';results=[]
for target,args in [('judas_production_fluid_tests',['--case','half_025','--output',str(c/'runtime-coarse-data')]),('judas_fluid_demo_integration_tests',['--scene','pool','--output',str(c/'runtime-pool-data')]),('judas_fluid_demo_integration_tests',['--scene','planet','--output',str(c/'runtime-planet-data')])]:
 name='coarse' if target=='judas_production_fluid_tests' else args[1]
 binary=c/('runtime-'+name)
 a=[x for x in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(binary) if x==target else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'curved.o')];subprocess.run(a,cwd=b,check=True)
 cmd=[str(binary),*args];t=time.monotonic()
 with (c/('runtime-'+name+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':cmd,'exit_code':code,'seconds':time.monotonic()-t});(c/'RUNTIME.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
