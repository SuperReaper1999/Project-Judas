from pathlib import Path
import subprocess,shlex,json,hashlib,time
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
src=(r/'src/FluidHydrostatics.cpp').read_text();(c/'BaselineHydrostatics.cpp').write_text(src)
variants={
'no-admission':src.replace('if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport))return 0.0;','(void)outerWidth; // Causal ablation only; NOT a candidate repair.').replace('if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact))return 0.0;','(void)covered; (void)notEmpty; (void)wetContact; // NOT a candidate repair.'),
'local-radius':src.replace('field.Query(point,up,height,volume.boundRadius,tangent,','field.Query(point,up,height,glm::length(sample.localHalfExtents)+sample.localRadius,tangent,')}
results=[]
for name,source in variants.items():
 assert source!=src
 path=c/(name+'.cpp');path.write_text(source)
 with (c/(name+'-build.log')).open('w') as log:subprocess.run([*base,'-c',str(path),'-o',str(c/(name+'.o'))],stdout=log,stderr=subprocess.STDOUT,check=True)
 a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'known.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/name) if x=='judas_production_fluid_tests' else x for x in a];i=a.index('libjudas_engine.a');a[i:i]=[str(c/(name+'.o'))];subprocess.run(a,cwd=b,check=True)
 t=time.monotonic()
 with (c/(name+'.csv')).open('w') as log:code=subprocess.run([str(c/name)],stdout=log,check=True,timeout=180).returncode
 results.append({'name':name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'exit_code':code,'seconds':time.monotonic()-t,'scope':'Causal ablation, not an engine correction'})
(c/'ABLATIONS.json').write_text(json.dumps(results,indent=2))
