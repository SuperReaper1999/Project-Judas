#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iomanip>
#include <iostream>
#include <random>
#include <cmath>
int main(){std::cout<<std::setprecision(17)<<"shape,frame,index,fraction,vx,vy,vz,ax,ay,az\n";
 for(int shape=0;shape<6;++shape)for(int frame=0;frame<2;++frame){const auto q=frame?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);const glm::vec3 shift=frame?glm::vec3(2,-1,3):glm::vec3(0);std::vector<FluidParticle> ps;
  for(int z=-5;z<=5;++z)for(int x=-5;x<=5;++x)for(int y=-5;y<=3;++y){float px=x*.25f,pz=z*.25f,py=(y+.5f)*.25f;float h=shape==1?.3f*(px*px+pz*pz):shape==2?(x||z?.25f:0):0;
   bool present=py<h;if(shape==3)present=std::abs(py)>.4f;if(shape==4)present=present&&std::abs(px)>.4f;if(shape==5)present=present&&((x*x+z*z+y*y)%7!=0);if(!present)continue;FluidParticle p;p.position=shift+q*glm::vec3(px,py,pz);p.mass=15.625f;p.velocity=q*glm::vec3(px*.2f,py*.3f,-pz*.1f);p.acceleration=q*glm::vec3(.1f*px*px,py*.4f,pz*.3f);ps.push_back(p);}
  FluidHydrostaticField f;f.Build(ps,1000);std::mt19937 random(72831+shape);std::uniform_real_distribution<float> d(-1,1);
  for(int i=0;i<60;++i){glm::vec3 local(d(random),d(random),d(random));if(i<4)local={0,i==0?0.f:i==1?.1f:i==2?.5f:-.5f,0};float half=i%3==0?0:i%3==1?.1f:.6f;float radius=i%4==0?.05f:i%4==1?.3f:i%4==2?.7f:1.2f;auto a=f.Query(shift+q*local,q*glm::vec3(0,1,0),half,radius,q*glm::vec3(1,0,0),nullptr,true);std::cout<<shape<<','<<frame<<','<<i<<','<<a.fraction<<','<<a.velocity.x<<','<<a.velocity.y<<','<<a.velocity.z<<','<<a.acceleration.x<<','<<a.acceleration.y<<','<<a.acceleration.z<<'\n';}
 }
}
