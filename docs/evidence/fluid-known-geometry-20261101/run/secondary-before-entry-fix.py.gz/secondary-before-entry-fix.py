from pathlib import Path
import subprocess,shlex,json,time
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
subprocess.run([*base,'-c',str(c/'BoundaryPhase.cpp'),'-o',str(c/'BoundaryPhase.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'BoundaryPhase.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'boundary-phase') if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
with (c/'boundary-phase.csv').open('w') as log:subprocess.run([str(c/'boundary-phase')],stdout=log,check=True)
# Fault injection into a disposable test copy. A sampler always reporting .5
# must fail the known dry/full/30%/70% controls rather than pass by construction.
s=(r/'tests/FluidKnownGeometryTests.cpp').read_text().replace('return {hydro.fraction, observed ?','(void)hydro; return {.5, observed ?');assert s!=(r/'tests/FluidKnownGeometryTests.cpp').read_text();(c/'ConstantHalfFault.cpp').write_text(s)
subprocess.run([*base,'-I'+str(r/'tests'),'-c',str(c/'ConstantHalfFault.cpp'),'-o',str(c/'ConstantHalfFault.o')],check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')];a=[str(c/'ConstantHalfFault.o') if x.endswith('FluidKnownGeometryTests.cpp.o') else str(c/'constant-half-fault') if x=='judas_fluid_known_geometry_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
cmd=[str(c/'constant-half-fault'),'--case','flat','--output',str(c/'constant-half-fault.csv')]
with (c/'constant-half-fault.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
assert code==1
# Native argument/path failure paths must exit deliberately, never abort.
negative=[]
for args in [['--case','not-a-surface'],['--output','/dev/null/not-a-directory.csv']]:
 p=subprocess.run([str(b/'judas_fluid_known_geometry_tests'),*args],text=True,capture_output=True,timeout=20);assert p.returncode==2,(args,p.returncode,p.stderr);negative.append({'args':args,'exit_code':p.returncode,'stderr':p.stderr})
(c/'NEGATIVE_CONTROLS.json').write_text(json.dumps({'constant_half_exit_code':code,'command':cmd,'cli':negative},indent=2));print((c/'boundary-phase.csv').read_text());print((c/'constant-half-fault.log').read_text())
