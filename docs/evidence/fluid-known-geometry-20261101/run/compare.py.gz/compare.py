from pathlib import Path
import subprocess,shlex,json,time,hashlib
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
for name in ('BaselineHydrostatics','QueryBench'):subprocess.run([*base,'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],check=True)
results=[]
for name,target in [('baseline-known','judas_fluid_known_geometry_tests'),('baseline-vertical','judas_fluid_vertical_support_tests')]:
 a=shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text());a=[str(c/name) if x==target else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'BaselineHydrostatics.o')];subprocess.run(a,cwd=b,check=True)
 args=['--output',str(c/'baseline-qualified.csv')] if name=='baseline-known' else [];cmd=[str(c/name),*args];t=time.monotonic()
 with (c/(name+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
 results.append({'name':name,'command':cmd,'exit_code':code,'seconds':time.monotonic()-t});print(name,code,flush=True)
original=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text())
for name in ('baseline','height-sliced'):
 a=[str(c/'QueryBench.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/('query-'+name)) if x=='judas_production_fluid_tests' else x for x in original]
 if name=='baseline':a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'BaselineHydrostatics.o')]
 subprocess.run(a,cwd=b,check=True)
 with (c/('query-'+name+'.csv')).open('w') as log:subprocess.run([str(c/('query-'+name))],stdout=log,check=True)
(c/'BASELINE_COMPARISON.json').write_text(json.dumps(results,indent=2))
