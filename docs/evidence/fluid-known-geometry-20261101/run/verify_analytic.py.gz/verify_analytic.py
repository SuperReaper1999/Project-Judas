from pathlib import Path
import subprocess,shlex,csv,json,statistics
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
for name in ('HeightSlicedReference','QueryEquivalence'):
 subprocess.run([*base,'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],check=True)
original=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
for name in ('height-reference','analytic'):
 a=[str(c/'QueryEquivalence.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/('equivalence-'+name)) if x=='judas_production_fluid_tests' else x for x in original]
 if name=='height-reference':a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'HeightSlicedReference.o')]
 subprocess.run(a,cwd=b,check=True)
 with (c/('equivalence-'+name+'.csv')).open('w') as log:subprocess.run([str(c/('equivalence-'+name))],stdout=log,check=True,timeout=240)
rows=[list(csv.DictReader((c/('equivalence-'+n+'.csv')).open())) for n in ('height-reference','analytic')];assert len(rows[0])==len(rows[1])==720
maximum=0
for before,after in zip(*rows):
 for key in before:
  if key=='fraction':
   assert (float(before[key])==0)==(float(after[key])==0),(before,after)
   delta=abs(float(before[key])-float(after[key]));maximum=max(maximum,delta);assert delta<1e-6,(before,after)
  else:assert before[key]==after[key],(key,before,after)
report={'queries':720,'fraction_max_difference':maximum,'dry_wet_classification_identical':True,'motion_vectors_and_input_keys_identical':True}
# Matched deterministic query workload. Values agree with the height reference;
# baseline's incorrect field is retained only as a historical cost reference.
for name,extra in [('analytic',None),('height-reference','HeightSlicedReference.o')]:
 a=[str(c/'QueryBench.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/('query-'+name)) if x=='judas_production_fluid_tests' else x for x in original]
 if extra:a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/extra)]
 subprocess.run(a,cwd=b,check=True)
 with (c/('query-'+name+'.csv')).open('w') as log:subprocess.run([str(c/('query-'+name))],stdout=log,check=True)
report['query_cost_us']={}
for name in ('baseline','height-reference','analytic'):
 rs=list(csv.DictReader((c/('query-'+name+'.csv')).open()));report['query_cost_us'][name]={str(k):{'median':statistics.median(float(x['microseconds_per_query']) for x in rs if x['case']==str(k)),'worst_batch_mean':max(float(x['microseconds_per_query']) for x in rs if x['case']==str(k))} for k in range(3)}
(c/'ANALYTIC_EQUIVALENCE.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
