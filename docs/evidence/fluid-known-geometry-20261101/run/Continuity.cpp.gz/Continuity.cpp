#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
int main(){std::cout<<std::setprecision(17)<<"frame,connected,epsilon,below,above,jump\n";
 for(int frame:{0,1}){auto q=frame?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);glm::vec3 shift=frame?glm::vec3(2,-1,3):glm::vec3(0);std::vector<FluidParticle> ps;
  for(int z=-4;z<=4;++z)for(int x=-4;x<=4;++x)for(int y=-4;y<(x||z?1:0);++y){FluidParticle p;p.position=shift+q*glm::vec3(x*.25f,(y+.5f)*.25f,z*.25f);p.mass=15.625f;ps.push_back(p);}FluidHydrostaticField f;f.Build(ps,1000);
  for(bool connected:{false,true})for(float epsilon:{.001f,.00001f}){auto a=f.Query(shift+q*glm::vec3(0,.1f-epsilon,0),q*glm::vec3(0,1,0),.1f,.3f,q*glm::vec3(1,0,0),nullptr,connected);auto b=f.Query(shift+q*glm::vec3(0,.1f+epsilon,0),q*glm::vec3(0,1,0),.1f,.3f,q*glm::vec3(1,0,0),nullptr,connected);std::cout<<frame<<','<<connected<<','<<epsilon<<','<<a.fraction<<','<<b.fraction<<','<<std::abs(a.fraction-b.fraction)<<'\n';}
 }
}
