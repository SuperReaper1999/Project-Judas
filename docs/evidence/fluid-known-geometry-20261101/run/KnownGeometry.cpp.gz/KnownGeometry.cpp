#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>

namespace {
struct Uniform final : GravityField {
    glm::vec3 value{0, -9.81f, 0};
    glm::vec3 Sample(const glm::vec3&) const override { return value; }
};
double Height(int kind, double x, double z) {
    constexpr double pi = 3.14159265358979323846;
    switch (kind) {
    case 0: return 0;
    case 1: return .2*x+.1*z;
    case 2: return .5*(x*x+z*z);
    case 3: return -.5*(x*x+z*z);
    case 4: return .5*(x*x-z*z);
    default: return .1*std::sin(pi*x)*std::cos(pi*z);
    }
}
double OldObserver(const std::vector<FluidParticle>& particles, float y, float spacing) {
    const int n=static_cast<int>(std::round(2/spacing));
    std::vector<double> tops(static_cast<std::size_t>(n*n), -1e30);
    for(const auto& p:particles) {
        if(std::abs(p.position.x)<.3f+spacing || std::abs(p.position.z)<.3f+spacing)continue;
        const int x=static_cast<int>(std::floor((p.position.x+1)/spacing));
        const int z=static_cast<int>(std::floor((p.position.z+1)/spacing));
        if(x>=0 && x<n && z>=0 && z<n) {
            auto& top=tops[static_cast<std::size_t>(z*n+x)];
            top=std::max(top,static_cast<double>(p.position.y)+.5*spacing);
        }
    }
    tops.erase(std::remove_if(tops.begin(),tops.end(),[](double v){return v< -1e20;}),tops.end());
    if(tops.empty())return -1;
    std::sort(tops.begin(),tops.end());
    // Analytic horizontal plane/axis-aligned box clipping. This avoids changing
    // the surface estimate while adding a second 32^3 quadrature error.
    return std::clamp((tops[tops.size()/2]-y+.3)/.6,0.,1.);
}
}
int main() {
    constexpr const char* names[]{"flat","affine","bowl","dome","saddle","wave"};
    constexpr double means[]{0,0,.03,-.03,0,0};
    Uniform gravity;
    std::cout<<std::setprecision(17)<<"case,spacing,offset,displaced,expected,engine,observer,particles\n";
    for(float spacing:{.25f,.125f})for(int kind=0;kind<6;++kind)
    for(float offset:{0.f,.12f,-.12f})for(int displaced:{0,1}) {
        BodyTransform pose;pose.position.y=static_cast<float>(means[kind])+offset;
        const glm::vec3 half(.3f);
        std::vector<FluidParticle> particles;
        const int n=static_cast<int>(std::round(2/spacing));
        for(int z=0;z<n;++z)for(int x=0;x<n;++x)for(int y=0;y<n;++y) {
            FluidParticle particle;
            const float px=-1+(x+.5f)*spacing,pz=-1+(z+.5f)*spacing;
            particle.position={px,static_cast<float>(Height(kind,px,pz))-(y+.5f)*spacing,pz};
            particle.mass=1000*spacing*spacing*spacing;
            if(displaced && glm::all(glm::lessThan(glm::abs(particle.position-pose.position),half)))continue;
            particles.push_back(particle);
        }
        FluidHydrostaticField field;field.Build(particles,1000);
        const auto hydro=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half),pose,gravity,
            displaced?FluidVolumeGeometry::DisplacedSolid:FluidVolumeGeometry::NonDisplacingVolume);
        std::cout<<names[kind]<<','<<spacing<<','<<offset<<','<<displaced<<','<<(.5-double(offset)/.6)
                 <<','<<hydro.fraction<<','<<OldObserver(particles,pose.position.y,spacing)<<','<<particles.size()<<'\n'<<std::flush;
    }
}
