from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
for name in ('Continuity','slice-connected'):subprocess.run([*base,'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],check=True)
original=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text())
for variant in ('baseline','slice-connected'):
 a=[str(c/'Continuity.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/('continuity-'+variant)) if x=='judas_production_fluid_tests' else x for x in original]
 if variant!='baseline':a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'slice-connected.o')]
 subprocess.run(a,cwd=b,check=True)
 with (c/('continuity-'+variant+'.csv')).open('w') as log:subprocess.run([str(c/('continuity-'+variant))],stdout=log,check=True)
a=shlex.split((b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/link.txt').read_text());a=[str(c/'known-slice') if x=='judas_fluid_known_geometry_tests' else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'slice-connected.o')];subprocess.run(a,cwd=b,check=True)
with (c/'known-slice.log').open('w') as log:code=subprocess.run([str(c/'known-slice'),'--output',str(c/'known-slice.csv')],stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
print('slice known diagnostic exit',code)
