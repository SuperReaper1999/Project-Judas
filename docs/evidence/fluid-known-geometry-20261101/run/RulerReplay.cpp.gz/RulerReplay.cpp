#include "FluidImmersionObservation.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>
std::vector<double> Row(const std::string& s){std::vector<double> out;std::istringstream in(s);std::string v;while(std::getline(in,v,','))out.push_back(std::stod(v));return out;}
int main(int argc,char**argv){if(argc!=2)return 2;const std::string dir=argv[1];std::ifstream observed(dir+"/half_025_observations.csv");std::string line;std::getline(observed,line);std::cout<<std::setprecision(17)<<"step,fraction,surface\n";
 while(std::getline(observed,line)){const int step=std::stoi(line.substr(0,line.find(',')));const auto prefix=dir+"/half_025_observe"+std::to_string(step);std::ifstream b(prefix+"_body.csv");std::string s;std::getline(b,s);std::getline(b,s);auto values=Row(s);BodyTransform pose;pose.position={values[0],values[1],values[2]};pose.rotation=glm::quat(float(values[3]),float(values[4]),float(values[5]),float(values[6]));glm::vec3 half(values[7],values[8],values[9]);std::ifstream p(prefix+"_particles.csv");std::getline(p,s);std::vector<FluidParticle> ps;
  while(std::getline(p,s)){auto v=Row(s);FluidParticle particle;particle.position={v[0],v[1],v[2]};ps.push_back(particle);}auto surface=FluidTest::ObservedSurface(ps,glm::quat(1,0,0,0),pose.position,half,.25f,8);if(!surface)return 3;std::cout<<step<<','<<FluidTest::BoxBelowObservedPlane(pose,half,glm::quat(1,0,0,0),*surface)<<','<<*surface<<'\n';
 }
}
