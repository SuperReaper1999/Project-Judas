#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <iostream>
#include <iomanip>
#include <limits>
struct Uniform:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};}};
int main(){Uniform g;std::cout<<std::setprecision(17)<<"half_extent,spacing,minimum_particle_cube_gap,engine_fraction\n";
 for(float half:{.3f,.25f}){std::vector<FluidParticle> ps;float gap=std::numeric_limits<float>::max();constexpr float s=.0625f;for(int z=0;z<32;++z)for(int x=0;x<32;++x)for(int y=0;y<32;++y){FluidParticle p;p.position={-1+(x+.5f)*s,-(y+.5f)*s,-1+(z+.5f)*s};if(glm::all(glm::lessThan(glm::abs(p.position),glm::vec3(half))))continue;p.mass=1000*s*s*s;ps.push_back(p);gap=std::min(gap,glm::length(glm::max(glm::abs(p.position)-glm::vec3(half+s*.5f),glm::vec3(0))));}FluidHydrostaticField field;field.Build(ps,1000);auto result=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(glm::vec3(half)),BodyTransform{},g);std::cout<<half<<','<<s<<','<<gap<<','<<result.fraction<<'\n';}
}
