from pathlib import Path
import subprocess,time,json,csv,hashlib
r=Path.cwd();c=r/'.cache/fluid-known-geometry-20261101';b=r/'.cache/2d-stage1-build';results=[]
checks=[('known','judas_fluid_known_geometry_tests',['--output',str(c/'final-known.csv')],1),('vertical','judas_fluid_vertical_support_tests',[],0),('hydro','judas_fluid_hydrostatics_tests',[],0),('lateral','judas_fluid_wet_support_tests',[],0),('drag','judas_fluid_volume_drag_tests',[],0),('swimming','judas_player_swimming_tests',[],0),('policy','judas_project_fluid_policy_tests',[],0),('lifecycle','judas_fluid_lifecycle_qualification_tests',[],0),('basic-preview','judas_basic_water_preview_tests',[str(c/'basic-preview')],0),('production','judas_production_fluid_tests',['--case','half_025','--output',str(c/'final-production')],1),('pool','judas_fluid_demo_integration_tests',['--scene','pool','--output',str(c/'pool')],0),('planet','judas_fluid_demo_integration_tests',['--scene','planet','--output',str(c/'planet')],0)]
for name,target,args,expected in checks:
 command=[str(b/target),*args];start=time.monotonic()
 with (c/('final-'+name+'.log')).open('w') as log:
  try:code=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':command,'exit_code':code,'expected_code':expected,'known_failure_is_not_a_pass':expected==1,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((b/target).read_bytes()).hexdigest()});(c/'FINAL_RESULTS.json').write_text(json.dumps(results,indent=2));print(name,code,'expected',expected,flush=True)
 if code!=expected:break
paths=[r/'.cache/fluid-immersion-20261101/native-capture/half_025.csv',c/'final-production/half_025.csv']
if paths[1].exists():
 rows=[list(csv.DictReader(p.open())) for p in paths];keys=[k for k in rows[0][0] if k not in ('fluid_step_ms','total_coupling_ms')];differences=[]
 if [len(x) for x in rows]!=[720,720]:differences.append({'row_counts':[len(x) for x in rows]})
 else:
  for i in range(720):
   for k in keys:
    if rows[0][i][k]!=rows[1][i][k]:differences.append({'step':i,'field':k,'before':rows[0][i][k],'after':rows[1][i][k]})
 (c/'PRODUCTION_REPLAY.json').write_text(json.dumps({'rows':len(rows[1]),'fields':keys,'differences':differences,'all_physical_rows_equal':not differences},indent=2))
 print('physical differences',len(differences),flush=True)
