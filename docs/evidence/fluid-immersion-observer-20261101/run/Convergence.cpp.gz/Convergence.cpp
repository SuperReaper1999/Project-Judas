#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <string>
struct Uniform : GravityField {glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};}};
std::vector<double> Row(std::string s){std::vector<double> out;std::istringstream in(s);std::string v;while(std::getline(in,v,','))out.push_back(std::stod(v));return out;}
int main(int argc,char**argv){if(argc!=2)return 2;std::string dir=argv[1];Uniform gravity;std::cout<<std::setprecision(17)<<"stage,n,fraction,forceY,torqueX,torqueZ\n";
 for(std::string stage:{"release","step240","step720"}){
  std::ifstream in(dir+"/half_025_"+stage+"_particles.csv");std::string line;std::getline(in,line);std::vector<FluidParticle> ps;while(std::getline(in,line)){auto v=Row(line);FluidParticle p;p.position={v[0],v[1],v[2]};p.velocity={v[3],v[4],v[5]};p.acceleration={v[6],v[7],v[8]};p.mass=v[9];ps.push_back(p);}FluidHydrostaticField field;field.Build(ps,1000);
  std::ifstream body(dir+"/half_025_"+stage+"_body.csv");std::getline(body,line);std::getline(body,line);auto b=Row(line);BodyTransform pose;pose.position={b[0],b[1],b[2]};pose.rotation={b[3],b[4],b[5],b[6]};glm::vec3 half(b[7],b[8],b[9]);
  for(unsigned n:{2,4,8,16}){auto h=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half,n),pose,gravity);std::cout<<stage<<','<<n<<','<<h.fraction<<','<<h.buoyancyForce.y<<','<<h.buoyancyTorque.x<<','<<h.buoyancyTorque.z<<'\n'<<std::flush;}
 }
}
