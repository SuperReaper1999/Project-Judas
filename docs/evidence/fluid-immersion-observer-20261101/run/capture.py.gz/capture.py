from pathlib import Path
import subprocess,shlex,json,hashlib,time
r=Path.cwd(); c=r/'.cache/fluid-immersion-20261101'; b=r/'.cache/2d-stage1-build'
s=(r/'tests/ProductionFluidTests.cpp').read_text(); needle='  if(originalMean){mean+='
assert needle in s
s=s.replace(needle,'''  if(originalMean || lateSample) snapshot("observe"+std::to_string(step+1),handle);
'''+needle)
(c/'CaptureProduction.cpp').write_text(s)
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text()
get=lambda k: shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
cmd=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(r/'tests'),*get('CXX_FLAGS'),'-c',str(c/'CaptureProduction.cpp'),'-o',str(c/'capture.o')]
subprocess.run(cmd,check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text())
a=[str(c/'capture.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'capture') if x=='judas_production_fluid_tests' else x for x in a]
subprocess.run(a,cwd=b,check=True)
cmd=[str(c/'capture'),'--case','half_025','--output',str(c/'coarse')]
t=time.monotonic()
with (c/'coarse.log').open('w') as log: code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
(c/'CAPTURE.json').write_text(json.dumps({'command':cmd,'exit_code':code,'seconds':time.monotonic()-t,'source_sha256':hashlib.sha256((r/'tests/ProductionFluidTests.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((c/'capture').read_bytes()).hexdigest(),'library_sha256':hashlib.sha256((b/'libjudas_engine.a').read_bytes()).hexdigest()},indent=2))
print('capture finished',code,flush=True)
