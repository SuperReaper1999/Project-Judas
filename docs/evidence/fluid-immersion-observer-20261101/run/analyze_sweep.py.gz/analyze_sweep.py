import csv,math,itertools,json
from pathlib import Path
from nonplanar import axes

def plane_fraction(center,ax,half,normal=(0.,1.,0.),height=0.):
 dot=lambda a,b:sum(x*y for x,y in zip(a,b))
 weights=[2*abs(dot(normal,v))*h for v,h in zip(ax,half) if abs(dot(normal,v))*h>1e-12]
 t=height-dot(center,normal)+sum(weights)*.5
 if t<=0:return 0.
 if t>=sum(weights):return 1.
 d=len(weights)
 if not d:return float(t>=0)
 # Symmetry avoids cancellation close to the fully wet end.
 if t>sum(weights)*.5:return 1-plane_fraction(tuple(-x for x in center),ax,half,normal,-height)
 terms=[]
 for subset in itertools.product((0,1),repeat=d):terms.append((-1)**sum(subset)*max(0.,t-sum(w*s for w,s in zip(weights,subset)))**d)
 return math.fsum(terms)/(math.factorial(d)*math.prod(weights))
if __name__=='__main__':
 rows=[]
 for r in csv.DictReader(Path('.cache/fluid-immersion-20261101/PlaneSweep.csv').open()):
  q=tuple(float(r[k]) for k in ('qw','qx','qy','qz'));expected=plane_fraction((0,float(r['y']),0),axes(q),(.3,.3,.3));r.update(expected=expected,error=float(r['fraction'])-expected);rows.append(r)
 Path('.cache/fluid-immersion-20261101/plane-analysis.json').write_text(json.dumps(rows,indent=2))
 for s in ('.25','.125'):
  for mode in ('0','1'):
   rs=[r for r in rows if abs(float(r['spacing'])-float(s))<1e-8 and r['mode']==mode];worst=max(rs,key=lambda r:abs(r['error']));print(s,mode,'max',worst)
