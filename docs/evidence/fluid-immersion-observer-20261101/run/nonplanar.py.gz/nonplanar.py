"""Diagnostic exterior-grid continuation; never calls Judas's wet sampler.

Scope: one connected heightfield, uniform fixture spacing and reservoir frame.
Excluded body columns are continued harmonically. This is a modelling assumption,
not measured water inside a solid. It is NOT an acceptance replacement.
"""
import csv,json,math,statistics,time
from pathlib import Path

def axes(q):
 w,x,y,z=q
 return ((1-2*(y*y+z*z),2*(x*y+w*z),2*(x*z-w*y)),(2*(x*y-w*z),1-2*(x*x+z*z),2*(y*z+w*x)),(2*(x*z+w*y),2*(y*z-w*x),1-2*(x*x+y*y)))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def corners(center,ax,half):
 return [tuple(center[j]+sum(sign[k]*half[k]*ax[k][j] for k in range(3)) for j in range(3)) for sign in ((x,y,z) for x in (-1,1) for y in (-1,1) for z in (-1,1))]
def hull(points):
 pts=sorted(set(points))
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 def build(ps):
  out=[]
  for p in ps:
   while len(out)>1 and cross(out[-2],out[-1],p)<=0:out.pop()
   out.append(p)
  return out
 return build(pts)[:-1]+build(pts[::-1])[:-1]
def excluded(x,z,poly,h):
 # Separating axes of convex polygon and axis-aligned cell. Touches count as
 # excluded: top particles in body-cut cells cannot be treated as free surface.
 for a,b in zip(poly,poly[1:]+poly[:1]):
  nx,nz=-(b[1]-a[1]),b[0]-a[0]
  if nx*(x-a[0])+nz*(z-a[1]) < -h*(abs(nx)+abs(nz)):return False
 if x+h<min(p[0] for p in poly) or x-h>max(p[0] for p in poly):return False
 if z+h<min(p[1] for p in poly) or z-h>max(p[1] for p in poly):return False
 return True

def solve(a):
 n=len(a)
 for k in range(n):
  p=max(range(k,n),key=lambda i:abs(a[i][k]));a[k],a[p]=a[p],a[k]
  if abs(a[k][k])<1e-12:raise ValueError('unanchored exterior reconstruction')
  d=a[k][k]
  for j in range(k,n+1):a[k][j]/=d
  for i in range(n):
   if i==k:continue
   d=a[i][k]
   for j in range(k,n+1):a[i][j]-=d*a[k][j]
 return [row[-1] for row in a]

def surface(particles,center,ax,half,spacing,span=2.):
 n=round(span/spacing);h=spacing*.5;lo=-span*.5
 poly=hull([(p[0],p[2]) for p in corners(center,ax,half)])
 masked={(x,z) for z in range(n) for x in range(n) if excluded(lo+(x+.5)*spacing,lo+(z+.5)*spacing,poly,h)}
 tops={}
 for px,py,pz in particles:
  if not all(math.isfinite(v) for v in (px,py,pz)):raise ValueError('nonfinite particle')
  x,z=math.floor((px-lo)/spacing),math.floor((pz-lo)/spacing)
  if 0<=x<n and 0<=z<n and (x,z) not in masked:tops[x,z]=max(tops.get((x,z),-math.inf),py+h)
 if not tops:raise ValueError('no exterior observations')
 unknown=[(x,z) for z in range(n) for x in range(n) if (x,z) not in tops]; index={p:i for i,p in enumerate(unknown)}
 a=[[0.]*(len(unknown)+1) for _ in unknown]
 for p,i in index.items():
  x,z=p
  for q in ((x-1,z),(x+1,z),(x,z-1),(x,z+1)):
   if not (0<=q[0]<n and 0<=q[1]<n):continue
   a[i][i]+=1
   if q in tops:a[i][-1]+=tops[q]
   else:a[i][index[q]]-=1
 for p,y in zip(unknown,solve(a)):tops[p]=y
 def sample(x,z):
  u=max(0.,min(n-1.,(x-lo)/spacing-.5));v=max(0.,min(n-1.,(z-lo)/spacing-.5));i=min(n-2,int(u));j=min(n-2,int(v));u-=i;v-=j
  return (1-u)*(1-v)*tops[i,j]+u*(1-v)*tops[i+1,j]+(1-u)*v*tops[i,j+1]+u*v*tops[i+1,j+1]
 return sample,{'exterior_columns':n*n-len(unknown),'excluded_columns':len(masked),'filled_columns':len(unknown),'exterior_min':min(tops[p] for p in tops if p not in index),'exterior_max':max(tops[p] for p in tops if p not in index)}

def fraction(center,ax,half,height,n=64):
 cs=corners(center,ax,half);xlo,xhi=min(p[0] for p in cs),max(p[0] for p in cs);zlo,zhi=min(p[2] for p in cs),max(p[2] for p in cs)
 dx,dz=(xhi-xlo)/n,(zhi-zlo)/n;wet=volume=0.
 for iz in range(n):
  z=zlo+(iz+.5)*dz
  for ix in range(n):
   x=xlo+(ix+.5)*dx;low,high=-math.inf,math.inf
   for v,h in zip(ax,half):
    b=v[0]*(x-center[0])+v[2]*(z-center[2])-v[1]*center[1]
    if abs(v[1])<1e-12:
     if abs(b)>h:low,high=1.,0.;break
    else:
     a,c=(-h-b)/v[1],(h-b)/v[1];low=max(low,min(a,c));high=min(high,max(a,c))
   if low<high:
    volume+=high-low;wet+=max(0.,min(high,height(x,z))-low)
 return wet*dx*dz/(8*math.prod(half)),volume*dx*dz/(8*math.prod(half))

def read(directory,stage):
 with (directory/f'half_025_{stage}_body.csv').open() as f:b=next(csv.DictReader(f))
 center=tuple(float(b[k]) for k in ('x','y','z'));q=tuple(float(b[k]) for k in ('qw','qx','qy','qz'));half=tuple(float(b[k]) for k in ('hx','hy','hz'))
 with (directory/f'half_025_{stage}_particles.csv').open() as f:ps=[tuple(float(r[k]) for k in ('x','y','z')) for r in csv.DictReader(f)]
 return ps,center,axes(q),half
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--all',action='store_true');p.add_argument('--resolution',type=int,default=64);a=p.parse_args();results=[];t=time.monotonic()
 files=sorted(a.directory.glob('half_025_observe*_body.csv')) if a.all else [a.directory/f'half_025_{s}_body.csv' for s in ('release','step240','step720')]
 for f in files:
  st=f.name[len('half_025_'):-len('_body.csv')];ps,c,ax,h=read(a.directory,st);sf,meta=surface(ps,c,ax,h,.25);fr,vol=fraction(c,ax,h,sf,a.resolution)
  row={'stage':st,'fraction':fr,'quadrature_volume_ratio':vol,**meta};results.append(row)
 print(json.dumps({'scope':'diagnostic harmonic continuation, not qualified acceptance','seconds':time.monotonic()-t,'results':results},indent=2))
