from pathlib import Path
import subprocess,time,json,csv,hashlib
r=Path.cwd();c=r/'.cache/fluid-immersion-20261101';b=r/'.cache/2d-stage1-build';results=[]
for name,args in [('default',['--case','half_025']),('native-capture',['--case','half_025','--capture-immersion'])]:
 cmd=[str(b/'judas_production_fluid_tests'),*args,'--output',str(c/name)]
 start=time.monotonic()
 with (c/(name+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 results.append({'name':name,'command':cmd,'exit_code':code,'expected_existing_failure_exit_code':1,'seconds':time.monotonic()-start});(c/'QUALIFICATION.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
cmd=['python3',str(r/'tools/validation/audit_fluid_immersion.py'),str(c/'native-capture'),'--case','half_025','--spacing','0.25']
with (c/'plane-replay.json').open('w') as log:subprocess.run(cmd,stdout=log,check=True)
paths=[c/'coarse/half_025.csv',c/'default/half_025.csv',c/'native-capture/half_025.csv']
rs=[list(csv.DictReader(p.open())) for p in paths];keys=[k for k in rs[0][0] if k not in ('fluid_step_ms','total_coupling_ms')]
assert all(len(x)==720 for x in rs)
for i in range(720):
 for k in keys:assert rs[0][i][k]==rs[1][i][k]==rs[2][i][k],(i,k)
(c/'PHYSICAL_REPLAY.json').write_text(json.dumps({'rows_per_run':720,'fields':keys,'all_equal':True,'compared':[str(x) for x in paths]},indent=2));print('720 physical rows identical: original, final default, final capture',flush=True)
print(json.dumps(json.loads((c/'plane-replay.json').read_text())['windows'],indent=2),flush=True)
