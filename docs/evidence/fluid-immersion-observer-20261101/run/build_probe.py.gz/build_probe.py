from pathlib import Path
import subprocess,shlex,sys
r=Path.cwd();c=r/'.cache/fluid-immersion-20261101';b=r/'.cache/2d-stage1-build';name=sys.argv[1];f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
subprocess.run(['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS'),'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/(name+'.o')) if x.endswith('ProductionFluidTests.cpp.o') else str(c/name) if x=='judas_production_fluid_tests' else x for x in a];subprocess.run(a,cwd=b,check=True)
with (c/(name+'.csv')).open('w') as log:subprocess.run([str(c/name),*sys.argv[2:]],stdout=log,check=True,timeout=180)
