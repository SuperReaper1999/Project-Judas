import nonplanar as o
import math,json
ax=o.axes((1.,0.,0.,0.));half=(.3,.3,.3)
results=[]
def manufactured(name,spacing,height,cy=0.):
 n=round(2/spacing);ps=[]
 for z in range(n):
  for x in range(n):
   px,pz=-1+(x+.5)*spacing,-1+(z+.5)*spacing
   ps.append((px,height(px,pz)-spacing*.5,pz))
 sf,meta=o.surface(ps,(0.,cy,0.),ax,half,spacing)
 actual,vol=o.fraction((0.,cy,0.),ax,half,height,128)
 estimated,_=o.fraction((0.,cy,0.),ax,half,sf,128)
 return {'name':name,'spacing':spacing,'analytic_or_dense_fraction':actual,'harmonic_fraction':estimated,'error':estimated-actual,**meta}
for sp in [.25,.125,.0625]:
 results.append(manufactured('flat_half',sp,lambda x,z:0.))
 results.append(manufactured('affine_half',sp,lambda x,z:.2*x-.1*z))
 results.append(manufactured('harmonic_saddle_half',sp,lambda x,z:.5*(x*x-z*z)))
 # The surface mean over [-h,h]^2 is 2*A*h^2/3 = .03.
 # All heights remain inside the box's vertical extent, so exact fraction=.5.
 results.append(manufactured('curved_bowl_half',sp,lambda x,z:.5*(x*x+z*z),.03))
 results.append(manufactured('curved_bowl_wrong_height',sp,lambda x,z:.5*(x*x+z*z),.18))
print(json.dumps(results,indent=2))
