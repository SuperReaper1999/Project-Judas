#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
struct Uniform:GravityField{glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};}};
int main(){Uniform g;std::cout<<std::setprecision(17)<<"spacing,angle,y,qw,qx,qy,qz,mode,fraction\n";
 for(float spacing:{.25f,.125f})for(float angle:{0.f,.37f,.83f})for(float y:{-.3f,-.2f,-.1f,0.f,.1f,.2f,.3f})for(int mode:{0,1}){
  BodyTransform pose;pose.position={0,y,0};pose.rotation=glm::angleAxis(angle,glm::normalize(glm::vec3(1,-2,3)));glm::vec3 half(.3f);std::vector<FluidParticle> ps;
  int n=int(std::lround(2/spacing));
  for(int iy=0;iy<n;++iy)for(int iz=0;iz<n;++iz)for(int ix=0;ix<n;++ix){FluidParticle p;p.position={-1+(ix+.5f)*spacing,-(iy+.5f)*spacing,-1+(iz+.5f)*spacing};p.mass=1000*spacing*spacing*spacing;if(mode && glm::all(glm::lessThan(glm::abs(glm::conjugate(pose.rotation)*(p.position-pose.position)),half)))continue;ps.push_back(p);}
  FluidHydrostaticField field;field.Build(ps,1000);auto h=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half),pose,g,mode?FluidVolumeGeometry::DisplacedSolid:FluidVolumeGeometry::NonDisplacingVolume);
  std::cout<<spacing<<','<<angle<<','<<y<<','<<pose.rotation.w<<','<<pose.rotation.x<<','<<pose.rotation.y<<','<<pose.rotation.z<<','<<mode<<','<<h.fraction<<'\n'<<std::flush;
 }
}
