#pragma once

#include "Contacts.h"
#include "RigidMotion.h"
#include <utility>

// Event geometry owns a precise step-local frame. The impulse solver continues
// to own its published float COM/orientation and unchanged physical mass tensor.
// Rebase the common world contact point into that actual solver frame ONCE,
// after event-time physical pose publication and before observations/cache rows.
inline Contact RebaseContactForPublishedBodies(const Contact &source,
                                               const RigidMotionGeometry &geometryA,
                                               const RigidBody &physicalA,
                                               const RigidMotionGeometry &geometryB,
                                               const RigidBody &physicalB) {
    Contact result = source;
    if (!source.hasLocalAnchors)
        return result; // legacy world-point contacts already use physical COMs
    auto rebase = [](const RigidMotionGeometry &geometry, const RigidBody &physical,
                     glm::dvec3 anchor, glm::dvec3 witness, bool worldFrame) {
        const auto same = geometry.position == glm::dvec3(physical.position) &&
                          geometry.orientation == glm::dquat(physical.orientation);
        if (same && !worldFrame)
            return std::pair{anchor, witness};
        const auto preciseRotation = ContactRotation(geometry.orientation);
        const auto physicalInverse = glm::transpose(ContactRotation(physical.orientation));
        const auto centerDifference = geometry.position - glm::dvec3(physical.position);
        const auto offset = [&](glm::dvec3 value) {
            return physicalInverse * ((worldFrame ? value : preciseRotation * value) +
                                      centerDifference);
        };
        return std::pair{offset(anchor), offset(witness)};
    };
    const auto first = rebase(geometryA, physicalA, source.localAnchorA, source.localWitnessA,
                              source.anchorAInWorldFrame);
    const auto second = rebase(geometryB, physicalB, source.localAnchorB, source.localWitnessB,
                               source.anchorBInWorldFrame);
    result.localAnchorA = first.first;
    result.localWitnessA = first.second;
    result.localAnchorB = second.first;
    result.localWitnessB = second.second;
    result.anchorAInWorldFrame = result.anchorBInWorldFrame = false;
    return result;
}
