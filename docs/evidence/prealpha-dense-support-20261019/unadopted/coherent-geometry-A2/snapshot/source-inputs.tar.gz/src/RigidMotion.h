#pragma once
#include "RigidBody.h"
#include <algorithm>
#include <cstring>
#include <vector>
#include <stdexcept>
#include <optional>

// Geometry observations intentionally omit transported physical angular
// velocity. Collision sampling needs the exact represented pose and linear
// drift; only solver/event publication needs the inertia-dependent transport.
struct RigidMotionGeometry {
    glm::dvec3 position{0};
    glm::vec3 linearVelocity{0};
    glm::dquat orientation{1,0,0,0};
    // The compatibility view is produced once alongside the precise pose.
    // Legacy dispatch and physical publication must not normalize it again.
    glm::quat publishedOrientation{1,0,0,0};
    RigidMotionGeometry() = default;
    explicit RigidMotionGeometry(const RigidBody &body)
        : position(body.position),linearVelocity(body.linearVelocity),orientation(body.orientation),
          publishedOrientation(body.orientation) {}
};

// Step-local authoritative motion. Observations never restart the integrator.
// The owner is the full slot/generation handle, not a pointer into body storage.
struct RigidMotionSegment {
    unsigned int owner = 0;
    double begin = 0, end = 0;
    float inverseMass = 0;
    glm::mat3 inverseInertiaLocal{0};
    glm::dvec3 position{0};
    glm::vec3 linearVelocity{0}, angularVelocity{0}, driftAngularVelocity{0};
    glm::dquat orientation{1,0,0,0};
    glm::dvec3 endPosition{0};
    glm::dquat endOrientation{1,0,0,0};
    // This is the physical Float frame at the anchor, not geometry truth.
    // Direct callers constructing a segment may omit it: the old represented
    // anchor orientation then remains the physical frame.
    std::optional<glm::quat> physicalOrientation;
    bool prescribed=false;
    glm::quat PublishedOrientation(const glm::dquat &raw) const {
        const glm::quat anchor=physicalOrientation.value_or(glm::quat(orientation));
        const double observed[]={raw.w,raw.x,raw.y,raw.z};
        const double anchored[]={orientation.w,orientation.x,orientation.y,orientation.z};
        if(std::memcmp(observed,anchored,sizeof observed)==0)return anchor;
        const glm::quat represented(raw);
        // The prescribed sampler already performed the legacy normalization.
        if(prescribed)return represented;
        const auto same=[](float a,float b){return std::memcmp(&a,&b,sizeof(float))==0;};
        if(same(represented.w,anchor.w)&&same(represented.x,anchor.x)&&
           same(represented.y,anchor.y)&&same(represented.z,anchor.z))return anchor;
        return glm::normalize(represented);
    }
    RigidMotionGeometry EvaluateGeometry(double time) const {
        if(time<begin||time>end)throw std::out_of_range("motion segment time");
        RigidMotionGeometry result;
        result.position=position;result.orientation=orientation;result.linearVelocity=linearVelocity;
        if(prescribed) {
            // Prescribed exponential motion deliberately retains the established
            // Float kinematic contract in this experiment. No continuous proof
            // or precise-kinematic claim is made for that separate integrator.
            const float elapsed=static_cast<float>(time-begin);
            result.position=glm::dvec3(glm::vec3(position)+linearVelocity*elapsed);
            const float speed=glm::length(driftAngularVelocity);
            const glm::quat anchor(orientation);
            const glm::quat advanced=speed>0&&elapsed!=0
                ?glm::angleAxis(speed*elapsed,driftAngularVelocity/speed)*anchor:anchor;
            const auto same=[](float a,float b){return std::memcmp(&a,&b,sizeof(float))==0;};
            if(!same(advanced.w,anchor.w)||!same(advanced.x,anchor.x)||
               !same(advanced.y,anchor.y)||!same(advanced.z,anchor.z))
                result.orientation=glm::dquat(glm::normalize(advanced));
        } else if(inverseMass>0) {
            const double elapsed=time-begin;
            result.position+=glm::dvec3(linearVelocity)*elapsed;
            // The raw projective quaternion is the single geometric source.
            // R(q)/dot(q,q) normalizes only inside the common contact kernel.
            // Neither observation nor an event split rounds this anchor to Float.
            if(elapsed!=0) {
                const glm::dquat omega(0.0,double(driftAngularVelocity.x),
                    double(driftAngularVelocity.y),double(driftAngularVelocity.z));
                result.orientation=orientation+(omega*orientation)*(.5*elapsed);
            }
        }
        result.publishedOrientation=PublishedOrientation(result.orientation);
        return result;
    }
    RigidBody Evaluate(double time) const {
        const auto geometry=EvaluateGeometry(time);
        RigidBody result;
        result.inverseMass=inverseMass;result.inverseInertiaLocal=inverseInertiaLocal;
        result.position=glm::vec3(geometry.position);result.orientation=geometry.publishedOrientation;
        result.linearVelocity=geometry.linearVelocity;result.angularVelocity=angularVelocity;
        if(!prescribed&&!result.IsStatic())
            result.angularVelocity=TransportAngularVelocity(inverseInertiaLocal,physicalOrientation.value_or(glm::quat(orientation)),result.orientation,angularVelocity);
        return result;
    }

};
class RigidMotion {
public:
    void Begin(unsigned int owner, const RigidBody& body, double duration) {
        segments.clear(); Append(owner, body, 0, duration);
    }
    void BeginPrescribed(unsigned int owner,const RigidBody& body,double duration,double activeDuration) {
        segments.clear();
        Append(owner,body,0,activeDuration,true);
        if(activeDuration<duration){auto rest=segments.back().Evaluate(activeDuration);
            rest.linearVelocity=rest.angularVelocity=glm::vec3(0);
            Append(owner,rest,activeDuration,duration,true);}
    }
    RigidBody Evaluate(double time) const {
        // ChangeVelocity only splits the last segment, so end times stay
        // ordered. Find the earliest segment whose end includes the query:
        // at a shared boundary this preserves the original ledger's choice
        // of the pre-change velocity, including zero-length segments.
        const auto segment = std::lower_bound(segments.begin(), segments.end(), time,
            [](const RigidMotionSegment& value, double query) { return value.end < query; });
        if (segment != segments.end() && time >= segment->begin && time <= segment->end)
            return segment->Evaluate(time);
        throw std::out_of_range("motion ledger time");
    }
    // Physical solver state is the right limit after impulses at a shared time.
    RigidBody EvaluateAfterEvents(double time) const {
        auto it=std::upper_bound(segments.begin(),segments.end(),time,
            [](double query,const RigidMotionSegment& s){return query<s.begin;});
        if(it==segments.begin())throw std::out_of_range("motion ledger time");
        --it;
        if(time>=it->begin && time<=it->end)return it->Evaluate(time);
        throw std::out_of_range("motion ledger time");
    }
    // The same right-limit segment selection as EvaluateAfterEvents, without
    // computing a physical angular velocity that geometry callers never read.
    RigidMotionGeometry EvaluateGeometryAfterEvents(double time) const {
        auto it=std::upper_bound(segments.begin(),segments.end(),time,
            [](double query,const RigidMotionSegment& segment){return query<segment.begin;});
        if(it==segments.begin())throw std::out_of_range("motion ledger time");
        --it;
        if(time>=it->begin&&time<=it->end)return it->EvaluateGeometry(time);
        throw std::out_of_range("motion ledger time");
    }
    void ChangeVelocity(const RigidBody& body, double time) {
        if (segments.empty()) throw std::logic_error("motion ledger not started");
        auto& previous = segments.back();
        const double finish = previous.end;
        const auto pose = previous.EvaluateGeometry(time);
        previous.end = time; previous.endPosition = pose.position; previous.endOrientation = pose.orientation;
        RigidBody next = body; next.position = glm::vec3(pose.position); next.orientation = pose.publishedOrientation;
        const auto owner = previous.owner;
        Append(owner, next, time, finish, false, &pose);
    }
    void Clear() { segments.clear(); }
    void ShiftOrigin(glm::dvec3 delta) { for(auto& s:segments){s.position-=delta;s.endPosition-=delta;} }
    // Concatenate already resolved coupled intervals without restarting their
    // angular integrators. The same generation owner must span every segment.
    void SetRecorded(std::vector<RigidMotionSegment> values) { segments=std::move(values); }
    std::size_t StorageBytes() const { return segments.capacity()*sizeof(RigidMotionSegment); }
    const std::vector<RigidMotionSegment>& Segments() const { return segments; }
private:
    void Append(unsigned int owner, const RigidBody& body, double begin, double end,bool prescribed=false,
                const RigidMotionGeometry* geometricAnchor=nullptr) {
        RigidMotionSegment s;
        s.inverseMass=body.inverseMass;s.inverseInertiaLocal=body.inverseInertiaLocal; s.prescribed=prescribed; s.owner=owner; s.begin=begin; s.end=end; s.position=body.position;
        s.orientation=body.orientation; s.physicalOrientation=body.orientation;
        if(geometricAnchor){s.position=geometricAnchor->position;s.orientation=geometricAnchor->orientation;}
        s.linearVelocity=body.linearVelocity; s.angularVelocity=body.angularVelocity;
        s.driftAngularVelocity=prescribed?body.angularVelocity:AngularDriftGenerator(body.inverseInertiaLocal,body.orientation,body.angularVelocity,static_cast<float>(end-begin));
        const auto pose=s.EvaluateGeometry(end); s.endPosition=pose.position; s.endOrientation=pose.orientation;
        segments.push_back(s);
    }
    std::vector<RigidMotionSegment> segments;
};
