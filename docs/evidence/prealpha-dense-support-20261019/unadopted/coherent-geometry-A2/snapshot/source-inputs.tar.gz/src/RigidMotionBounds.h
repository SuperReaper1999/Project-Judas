#pragma once
// Step-local conservative enclosures for the SAME precise motion used by
// contact geometry. Bounds never supply contact truth or response impulses.
#include "Narrowphase.h"
#include "RigidMotion.h"
#include "ContactGeometryInternal.h"
#include <optional>
#include <limits>
#include <cmath>
#include <cstring>

namespace rigid_motion_bounds {
using contact_geometry::Iv;
template<class V> inline bool Finite3(const V &x) {
    return std::isfinite(x.x) && std::isfinite(x.y) && std::isfinite(x.z);
}
template<class Q> inline bool Finite4(const Q &q) {
    return std::isfinite(q.w) && std::isfinite(q.x) && std::isfinite(q.y) && std::isfinite(q.z);
}
template<class A, class B> inline bool SameQuat(const A &a, const B &b) {
    for (unsigned k = 0; k < 4; ++k)
        if (double(a[k]) != double(b[k])) return false;
    return true;
}
inline bool Finite(Iv x) { return std::isfinite(x.lo) && std::isfinite(x.hi) && x.lo <= x.hi; }
inline bool FiniteBound(const Aabb &b) {
    return Finite3(b.min) && Finite3(b.max) && b.min.x <= b.max.x && b.min.y <= b.max.y && b.min.z <= b.max.z;
}
inline float LoFloat(double x) {
    const float f = float(x);
    return double(f) > x ? std::nextafter(f, -std::numeric_limits<float>::infinity()) : f;
}
inline float HiFloat(double x) {
    const float f = float(x);
    return double(f) < x ? std::nextafter(f, std::numeric_limits<float>::infinity()) : f;
}
inline Iv Square(Iv x) { const auto a = contact_geometry::Abs(x); return a * a; }
inline Aabb IntersectConservativeBounds(const Aabb &sphere, const Aabb &tight) {
    const Aabb both{glm::max(sphere.min, tight.min), glm::min(sphere.max, tight.max)};
    return FiniteBound(both) ? both : sphere;
}
// Optional proof arithmetic domain, never a physical coordinate/contact limit.
// Larger values keep the outer radius enclosure and ordinary CCD. This bounds
// polynomial intermediates far below binary64 overflow and fails closed.
inline bool ProofScalar(double x) { return std::isfinite(x) && std::abs(x) <= 0x1p64; }
template<class V> inline bool Proof3(const V &x) { return ProofScalar(x.x) && ProofScalar(x.y) && ProofScalar(x.z); }
template<class Q> inline bool Proof4(const Q &q) { return ProofScalar(q.w) && ProofScalar(q.x) && ProofScalar(q.y) && ProofScalar(q.z); }
inline bool Domain(const RigidMotionSegment &s, double start, double finish) {
    const auto &q=s.orientation;
    const double norm=q.w*q.w+q.x*q.x+q.y*q.y+q.z*q.z;
    return norm>0 && std::isfinite(norm) && ProofScalar(start) && ProofScalar(finish) && start <= finish && start >= s.begin &&
           finish <= s.end && ProofScalar(s.begin) && ProofScalar(s.end) && Proof3(s.position) &&
           Proof3(s.linearVelocity) && Proof3(s.driftAngularVelocity) && Proof4(s.orientation);
}
inline Iv Centre(const RigidMotionSegment &s, unsigned k, double start, double finish) {
    if (!s.prescribed && !(s.inverseMass > 0)) return Iv(s.position[k]);
    if (s.prescribed) {
        // This experimental domain retains the legacy monotone float center.
        const auto a=s.EvaluateGeometry(start).position[k], b=s.EvaluateGeometry(finish).position[k];
        return Iv(std::min(a,b),std::max(a,b));
    }
    const auto first = Iv(start) - Iv(s.begin), last = Iv(finish) - Iv(s.begin);
    return Iv(s.position[k]) + Iv(double(s.linearVelocity[k])) * Iv(first.lo, last.hi);
}

// Raw dynamic Cayley quaternion components are monotone affine functions of
// represented double elapsed time. Endpoint component hulls therefore enclose
// every native double observation. R(q)/dot(q,q), NOT a float normalization
// envelope, then encloses the exact geometry used by the narrowphase.
inline std::optional<contact_geometry::M<Iv>> TryDynamicRotationInterval(
    const RigidMotionSegment &s, double start, double finish) {
    if (s.prescribed || !Domain(s, start, finish)) return std::nullopt;
    try {
        const auto first = s.EvaluateGeometry(start).orientation, last = s.EvaluateGeometry(finish).orientation;
        if (!Proof4(first) || !Proof4(last)) return std::nullopt;
        std::array<Iv, 4> q;
        const std::array<double, 4> a{first.w, first.x, first.y, first.z}, b{last.w, last.x, last.y, last.z};
        for (unsigned k = 0; k < 4; ++k) q[k] = Iv(std::min(a[k], b[k]), std::max(a[k], b[k]));
        const auto w=q[0], x=q[1], y=q[2], z=q[3], two=Iv(2);
        const auto ww=Square(w), xx=Square(x), yy=Square(y), zz=Square(z), d=ww+xx+yy+zz;
        if (!Finite(d) || !(d.lo > 0)) return std::nullopt;
        const contact_geometry::M<Iv> n{
            contact_geometry::V<Iv>{ww+xx-yy-zz, two*(x*y+w*z), two*(x*z-w*y)},
            contact_geometry::V<Iv>{two*(x*y-w*z), ww-xx+yy-zz, two*(y*z+w*x)},
            contact_geometry::V<Iv>{two*(x*z+w*y), two*(y*z-w*x), ww-xx-yy+zz}};
        contact_geometry::M<Iv> rotation;
        for (unsigned j=0;j<3;++j) for (unsigned k=0;k<3;++k) {
            rotation[j][k]=n[j][k]/d;
            if (!Finite(rotation[j][k])) return std::nullopt;
        }
        return rotation;
    } catch (const contact_geometry::ArithmeticFailure &) { return std::nullopt; }
}

template<class Pose> inline std::optional<Aabb> TryTranslationSweepBound(
    const Shape &shape, const RigidMotionSegment &s, const Pose &, const Pose &, double start, double finish) {
    if (!Domain(s,start,finish) || shape.pivotOffset != glm::vec3(0)) return std::nullopt;
    if (shape.type == ShapeType::Sphere) {
        if (!(shape.radius>0) || !std::isfinite(shape.radius)) return std::nullopt;
    } else if (shape.type == ShapeType::Box) {
        if (s.driftAngularVelocity != glm::vec3(0) || !Proof3(shape.halfExtents) ||
            glm::any(glm::lessThanEqual(shape.halfExtents,glm::vec3(0)))) return std::nullopt;
    } else return std::nullopt;
    const auto a=s.EvaluateGeometry(start), b=s.EvaluateGeometry(finish);
    const auto bound=ShapeAabb(shape,a.position,a.orientation).Union(ShapeAabb(shape,b.position,b.orientation));
    return FiniteBound(bound) ? std::optional<Aabb>(bound) : std::nullopt;
}

template<class Pose> inline std::optional<Aabb> TryDynamicBoxSweepBound(
    const Shape &shape, const RigidMotionSegment &s, const Pose &, const Pose &, double start, double finish) {
    if (shape.type != ShapeType::Box || shape.pivotOffset != glm::vec3(0) ||
        !Proof3(shape.halfExtents) || glm::any(glm::lessThanEqual(shape.halfExtents,glm::vec3(0)))) return std::nullopt;
    const auto rotation=TryDynamicRotationInterval(s,start,finish);
    if (!rotation) return std::nullopt;
    try {
        Aabb bound;
        for (unsigned k=0;k<3;++k) {
            Iv extent(0);
            for (unsigned j=0;j<3;++j) extent=extent+contact_geometry::Abs((*rotation)[j][k])*Iv(double(shape.halfExtents[j]));
            const auto center=Centre(s,k,start,finish), lo=center-extent, hi=center+extent;
            if (!Finite(lo) || !Finite(hi)) return std::nullopt;
            bound.min[k]=LoFloat(lo.lo); bound.max[k]=HiFloat(hi.hi);
        }
        return FiniteBound(bound) ? std::optional<Aabb>(bound) : std::nullopt;
    } catch (const contact_geometry::ArithmeticFailure &) { return std::nullopt; }
}

// Rotation-only support projection. The caller adds correlated center motion
// exactly once. No world-center input is accepted, making accidental double
// counting impossible even when the same segment also carries translation.
inline std::optional<Iv> TryPrimitiveRotationProjection(
    const Shape &shape, const RigidMotionSegment *s, double start, double finish,
    const glm::dvec3 &axis, const ContactPreparedOrientation &orientation) {
    if (!ProofScalar(start) || !ProofScalar(finish) || start > finish || !Proof3(axis) ||
        shape.pivotOffset != glm::vec3(0) ||
        (shape.type != ShapeType::Box && shape.type != ShapeType::Sphere)) return std::nullopt;
    if (s && !Domain(*s, start, finish)) return std::nullopt;
    try {
        Iv extent(0);
        if (shape.type == ShapeType::Sphere) {
            if (!(shape.radius > 0) || !ProofScalar(shape.radius)) return std::nullopt;
            Iv length(0);
            for (unsigned k = 0; k < 3; ++k) length = length + Iv(axis[k]) * Iv(axis[k]);
            extent = contact_geometry::Sqrt(length) * Iv(double(shape.radius));
        } else {
            if (!Proof3(shape.halfExtents) ||
                glm::any(glm::lessThanEqual(shape.halfExtents, glm::vec3(0)))) return std::nullopt;
            auto rotation = orientation.normalizedInterval;
            if (s) {
                if (s->prescribed) {
                    if (s->driftAngularVelocity != glm::vec3(0)) return std::nullopt;
                } else {
                    const auto swept = TryDynamicRotationInterval(*s, start, finish);
                    if (!swept) return std::nullopt;
                    rotation = *swept;
                }
            }
            for (unsigned j = 0; j < 3; ++j) {
                Iv projected(0);
                for (unsigned k = 0; k < 3; ++k) projected = projected + rotation[j][k] * Iv(axis[k]);
                extent = extent + contact_geometry::Abs(projected) * Iv(double(shape.halfExtents[j]));
            }
        }
        if (!Finite(extent)) return std::nullopt;
        return Iv(-extent.hi, extent.hi);
    } catch (const contact_geometry::ArithmeticFailure &) { return std::nullopt; }
}

// Full world projection is deliberately separate from the rotation-only
// support helper. This includes each center exactly once using its actual
// precise trajectory; static callers supply one unchanging pose.
template<class Pose> inline std::optional<Iv> TryPrimitiveSweepProjection(
    const Shape &shape, const RigidMotionSegment *s, const Pose &from, const Pose &to,
    double start, double finish, const glm::dvec3 &axis, const glm::dvec3 &origin,
    const ContactPreparedOrientation &orientation) {
    if (!Proof3(origin) || !Proof3(from.position) || !Proof3(to.position) ||
        (!s && (from.position != to.position || !SameQuat(from.orientation, to.orientation))))
        return std::nullopt;
    const auto radial = TryPrimitiveRotationProjection(shape, s, start, finish, axis, orientation);
    if (!radial) return std::nullopt;
    try {
        Iv center(0);
        for (unsigned k = 0; k < 3; ++k) {
            const auto position = s ? Centre(*s, k, start, finish) : Iv(double(from.position[k]));
            center = center + (position - Iv(origin[k])) * Iv(axis[k]);
        }
        const auto projected = center + *radial;
        return Finite(projected) ? std::optional<Iv>(projected) : std::nullopt;
    } catch (const contact_geometry::ArithmeticFailure &) { return std::nullopt; }
}
// Float conversion remains necessary for public AABB/tree storage only.
inline double FloatRoundingBound(double magnitude) {
    const float value=std::nextafter(float(magnitude),std::numeric_limits<float>::infinity());
    return double(std::nextafter(value,std::numeric_limits<float>::infinity()))-double(value);
}
inline double DoubleRoundingBound(double magnitude) {
    return std::nextafter(magnitude,std::numeric_limits<double>::infinity())-magnitude;
}
// Correlated affine motion plus explicit BINARY64 observation error. This is
// a new source proof; no binary32 pose normalization/elapsed claim is reused.
template<class Pose> inline std::optional<Iv> TryRelativeCentreProjection(
    const RigidMotionSegment *a,const RigidMotionSegment *b,const Pose &fromA,const Pose &fromB,
    double start,double finish,const glm::dvec3 &axis) {
    if(!ProofScalar(start)||!ProofScalar(finish)||start>finish||!Proof3(axis))return std::nullopt;
    // Prescribed motion intentionally retains its separate float integrator;
    // do not apply the new dynamic binary64 rounding proof to that path.
    for(const auto *s:{a,b})if(s&&(s->prescribed||!Domain(*s,start,finish)))return std::nullopt;
    try {
        const Iv span=Iv(finish)-Iv(start);Iv projected(0);
        for(unsigned k=0;k<3;++k) {
            struct Drift {Iv base,velocity,error;};
            auto drift=[&](const RigidMotionSegment *s,const Pose &from) {
                if(!s)return Drift{Iv(double(from.position[k])),Iv(0),Iv(0)};
                const double velocity=(!s->prescribed&&!(s->inverseMass>0))?0:double(s->linearVelocity[k]);
                const auto elapsed=Iv(start)-Iv(s->begin);
                const double maximumElapsed=std::max(std::abs(start-s->begin),std::abs(finish-s->begin));
                const double magnitude=std::max({std::abs(start),std::abs(finish),std::abs(s->begin)});
                const double timeError=DoubleRoundingBound(magnitude);
                const auto product=Iv(std::abs(velocity))*Iv(contact_geometry::Up(maximumElapsed+timeError));
                const auto error=Iv(std::abs(velocity))*Iv(timeError)+Iv(DoubleRoundingBound(product.hi))+
                    Iv(DoubleRoundingBound(std::abs(s->position[k])+product.hi));
                return Drift{Iv(s->position[k])+Iv(velocity)*elapsed,Iv(velocity),error};
            };
            const auto first=drift(a,fromA),second=drift(b,fromB);
            const auto error=first.error+second.error;
            const auto delta=first.base-second.base+(first.velocity-second.velocity)*Iv(0,span.hi)+Iv(-error.hi,error.hi);
            projected=projected+delta*Iv(axis[k]);
        }
        return Finite(projected)?std::optional<Iv>(projected):std::nullopt;
    }catch(const contact_geometry::ArithmeticFailure &){return std::nullopt;}
}
} // namespace rigid_motion_bounds
