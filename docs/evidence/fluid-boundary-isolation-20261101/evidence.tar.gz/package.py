from pathlib import Path
import hashlib,tarfile,json,shutil,subprocess,platform,datetime
r=Path.cwd();c=r/'.cache/fluid-boundary-isolation-20261101';e=r/'docs/evidence/fluid-boundary-isolation-20261101';e.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Preserve the preceding native results used for the bit-identical comparison.
shutil.copy2(r/'.cache/fluid-curved-reconstruction-20261101/additional-final.csv',c/'prior-native.csv')
b=r/'.cache/2d-stage1-build'
for name in ['flags.make','link.txt']:shutil.copy2(b/'CMakeFiles/judas_production_fluid_tests.dir'/name,c/('build-'+name))
for target in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests']:
 assert (c/('native-'+dict(judas_fluid_hydrostatics_tests='hydro',judas_fluid_vertical_support_tests='vertical',judas_fluid_wet_support_tests='wet')[target]+'.log')).exists()
(c/'ENVIRONMENT.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),platform=platform.platform(),compiler=subprocess.check_output(['c++','--version'],text=True).splitlines()[0],configuration='Release -O3 -DNDEBUG; native Linux; isolated diagnostic; no production changes',native_binaries={t:sha(b/t) for t in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests']}),indent=2))
files=sorted(p for p in c.rglob('*') if p.is_file() and p.suffix in {'.cpp','.h','.py','.txt','.json','.log','.csv','.make'} and p.name!='MANIFEST.json')
manifest={str(p.relative_to(c)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files};(c/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(c/'MANIFEST.json')
archive=e/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(c)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,item in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==item['sha256']
for name in ['ANALYSIS.json','TWINS.json','RUN.json','FINGERPRINTS.json']:shutil.copy2(c/name,e/name)
(e/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(e.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
print('Verified archive:',len(files),'entries',archive.stat().st_size,'bytes')
