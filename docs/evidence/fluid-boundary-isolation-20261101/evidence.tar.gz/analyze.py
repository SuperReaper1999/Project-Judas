from pathlib import Path
import csv,json,hashlib,subprocess
c=Path(__file__).resolve().parent;r=list(csv.DictReader((c/'results/cases.csv').open()))
key=lambda x:(x['shape'],x['surface'],x['spacing'],x['frame'])
idx={(key(x),x['mode']):x for x in r}
prior=c/'prior-native.csv'
if not prior.exists():prior=c.parent/'fluid-curved-reconstruction-20261101/additional-final.csv'
old=list(csv.DictReader(prior.open()))
comparison=[]
for row in old:
 actual=idx[((row['shape'],row['surface'],row['spacing'],'0'),'0')]
 comparison.append(float(row['engine'])==float(actual['engine']))
assert len(comparison)==24 and all(comparison)
frames={}
for mode in range(8):
 differences=[abs(float(x['engine'])-float(idx[((x['shape'],x['surface'],x['spacing'],'1'),str(mode))]['engine'])) for x in r if x['frame']=='0' and x['mode']==str(mode)]
 frames[str(mode)]=max(differences)
assert frames['0']<.001 and frames['1']<.001
oracle_agreement=max(abs(float(x['engine'])-float(idx[(key(x),'7')]['engine'])) for x in r if x['mode']=='1')
assert oracle_agreement==0
selected=[]
for shape in ['0','1','2','3','4']:
 surface='2' if int(shape)<3 else '0';spacing='0.25' if int(shape)<3 else '0.0625'
 row=idx[((shape,surface,spacing,'0'),'0')]
 selected.append(dict(shape=shape,surface=surface,spacing=spacing,reference160=float(row['reference160']),analytic=float(row['analytic']),modes={str(m):float(idx[((shape,surface,spacing,'0'),str(m))]['engine']) for m in range(8)}))
result=dict(cases=len(r),native_original_bit_identical=sum(comparison),native_original_comparisons=len(comparison),frame_max_differences=frames,oracle_all_bypasses_max_difference=oracle_agreement,selected=selected,note='Unsafe diagnostic modes are not accepted production changes. Modes 2 and 4 exceed original .001 frame tolerance in this diagnostic; native and boundary oracle pass it.')
(c/'ANALYSIS.json').write_text(json.dumps(result,indent=2))
files=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidSolidSupport.h','src/FluidSurfaceReconstruction.h','src/FluidWetFootprint.h','tests/FluidKnownGeometryTests.cpp','tests/FluidImmersionObservation.h','tests/ProductionFluidTests.cpp']
root=c.parent.parent
unchanged={f:subprocess.check_output(['git','show','db90a17bee89a97dde17a07c6fcafc2cbd753297:'+f])==(root/f).read_bytes() for f in files}
assert all(unchanged.values())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(c/'FINGERPRINTS.json').write_text(json.dumps(dict(base='db90a17bee89a97dde17a07c6fcafc2cbd753297',production_unchanged=unchanged,sources={f:sha(root/f) for f in files},diagnostic={str(p.relative_to(c)):sha(p) for p in c.iterdir() if p.is_file() and p.suffix in {'.cpp','.h','.py'}},binary=sha(c/'boundary-isolation')),indent=2))
print(json.dumps(result,indent=2))
