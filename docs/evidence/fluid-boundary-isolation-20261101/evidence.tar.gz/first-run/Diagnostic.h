#pragma once
#include "FluidHydrostatics.h"
#include <optional>
struct DiagnosticRecord {
    glm::vec3 point;
    float halfHeight = 0, result = 0;
    double exactCap = 0, fittedCap = 0, confidence = 0;
    bool fit = false;
    unsigned originalBands = 0, modelBands = 0, hullRejects = 0, contactRejects = 0;
};
extern int diagnosticMode, diagnosticSurface;
extern glm::quat diagnosticFrame;
extern glm::vec3 diagnosticOrigin;
extern std::vector<DiagnosticRecord> diagnosticRecords;
double DiagnosticHeight(const glm::vec3& point);
struct DiagnosticTrace {
    FluidFieldSample& result;
    DiagnosticRecord& record;
    DiagnosticTrace(FluidFieldSample& out, const glm::vec3& point, float halfHeight)
        : result(out), record(diagnosticRecords.emplace_back()) {
        record.point = point; record.halfHeight = halfHeight; record.exactCap = DiagnosticHeight(point);
    }
    ~DiagnosticTrace() { record.result = result.fraction; }
};
