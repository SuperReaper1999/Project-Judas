from pathlib import Path
r=Path.cwd();c=r/'.cache/fluid-boundary-isolation-20261101'
s=(r/'src/FluidHydrostatics.cpp').read_text().replace('#include "FluidHydrostatics.h"','#include "FluidHydrostatics.h"\n#include "Diagnostic.h"',1)
s=s.replace('    FluidFieldSample out; out.density=m_density;','''    FluidFieldSample out; out.density=m_density;
    DiagnosticTrace trace(out, point, halfHeight);
    if(diagnosticMode==1) {
        out.fraction=halfHeight>0 ? static_cast<float>(std::clamp((trace.record.exactCap+halfHeight)/(2*halfHeight),0.,1.)) : (trace.record.exactCap>=0?1.f:0.f);
        return out;
    }''',1)
s=s.replace('    const auto occupiedLength=', '''    if(surface) {
        trace.record.fit=true;trace.record.fittedCap=surface->height;trace.record.confidence=surface->confidence;
    }
    if(diagnosticMode==2)surface=FluidHydrostaticDetail::CurvedSurfacePatch{trace.record.exactCap,1,0};
    const auto occupiedLength=''',1)
s=s.replace('        const double middle=(lo+hi)*.5,bandHalf=(hi-lo)*.5;', '        if(reconstruction)++trace.record.modelBands;else ++trace.record.originalBands;\n        const double middle=(lo+hi)*.5,bandHalf=(hi-lo)*.5;',1)
s=s.replace('if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport))return 0.0;', 'if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport)){if(reconstruction)++trace.record.hullRejects;return 0.0;}',1)
s=s.replace('if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact,!reconstruction))return 0.0;', 'if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact,!reconstruction)){if(reconstruction)++trace.record.contactRejects;return 0.0;}',1)
(c/'HydroDiagnostic.cpp').write_text(s)
