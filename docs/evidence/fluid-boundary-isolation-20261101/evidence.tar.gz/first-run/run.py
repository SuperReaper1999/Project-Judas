from pathlib import Path
import subprocess,shlex,json,hashlib,time
r=Path.cwd();c=r/'.cache/fluid-boundary-isolation-20261101';b=r/'.cache/2d-stage1-build'
f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')))
base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(c),*get('CXX_FLAGS')]
with (c/'build.log').open('w') as log:
 for name in ['BoundaryIsolation','HydroDiagnostic']:
  subprocess.run([*base,'-c',str(c/(name+'.cpp')),'-o',str(c/(name+'.o'))],stdout=log,stderr=subprocess.STDOUT,check=True)
a=[x for x in shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
a=[str(c/'BoundaryIsolation.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'boundary-isolation') if x=='judas_production_fluid_tests' else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'HydroDiagnostic.o')]
subprocess.run(a,cwd=b,check=True)
cmd=[str(c/'boundary-isolation'),str(c/'results')];start=time.monotonic()
with (c/'run.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
(c/'RUN.json').write_text(json.dumps(dict(command=cmd,exit_code=code,seconds=time.monotonic()-start,base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()),indent=2))
print(code)
