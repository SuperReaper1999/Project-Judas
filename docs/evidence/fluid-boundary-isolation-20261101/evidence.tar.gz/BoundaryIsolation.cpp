#include "Diagnostic.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <filesystem>

int diagnosticMode=0,diagnosticSurface=0;
glm::quat diagnosticFrame{1,0,0,0};
glm::vec3 diagnosticOrigin{0};
std::vector<DiagnosticRecord> diagnosticRecords;
constexpr double pi=3.14159265358979323846;
double Height(int surface,double x,double z) {
    return surface==0?0:surface==1?.5*(x*x+z*z):surface==2?-.5*(x*x+z*z):.1*std::sin(pi*x)*std::cos(pi*z);
}
double DiagnosticHeight(const glm::vec3& point) {
    const auto local=glm::inverse(glm::dquat(diagnosticFrame))*(glm::dvec3(point)-glm::dvec3(diagnosticOrigin));
    return Height(diagnosticSurface,local.x,local.z)-local.y;
}
struct Uniform:GravityField {
    glm::vec3 Sample(const glm::vec3&)const override{return diagnosticFrame*glm::vec3(0,-9.81f,0);}
};
double Reference(int shape,int surface,const glm::quat& turn,int n,float half) {
    std::uint64_t wet=0,total=0;
    for(int z=0;z<n;++z)for(int y=0;y<n;++y)for(int x=0;x<n;++x) {
        const glm::dvec3 local=(glm::dvec3(2*x+1,2*y+1,2*z+1)/double(n)-1.)*double(half);
        if(shape==1&&glm::dot(local,local)>double(half)*half)continue;
        const auto p=glm::dquat(turn)*local;++total;wet+=p.y<Height(surface,p.x,p.z);
    }
    return double(wet)/double(total);
}
double SphereDome(float radius) {
    const double r=radius,s=2*r*r/(std::sqrt(1+r*r)+1);
    const double volume=2*pi*((r*r*r-std::pow(r*r-s,1.5))/3-s*s/8);
    return volume/(4*pi*r*r*r/3);
}
int main(int argc,char**argv) {
    if(argc!=2)return 2;
    std::filesystem::create_directories(argv[1]);
    const auto directory=std::filesystem::path(argv[1]);
    std::ofstream rows(directory/"cases.csv"),samples(directory/"samples.csv");
    rows<<std::setprecision(17)<<"shape,surface,half,spacing,frame,mode,reference64,reference96,reference160,analytic,engine,samples,fit_samples,model_bands,hull_rejects,contact_rejects\n";
    samples<<std::setprecision(17)<<"shape,surface,half,spacing,frame,mode,index,local_x,local_y,local_z,half_height,result,exact_cap,fit,fit_cap,confidence,model_bands,hull_rejects,contact_rejects,early_reason\n";
    int checks=0,failures=0;
    for(int shape=0;shape<5;++shape)for(int surface=0;surface<(shape>=3?1:4);++surface) {
        const float half=shape==3?.25f:.3f;
        const auto turn=shape==0?glm::angleAxis(.55f,glm::normalize(glm::vec3(1,0,2))):glm::quat(1,0,0,0);
        const double ref64=Reference(shape,surface,turn,64,half),ref96=Reference(shape,surface,turn,96,half),ref160=Reference(shape,surface,turn,160,half);
        const double analytic=shape==1?(surface==0||surface==3?.5:surface==2?SphereDome(half):1-SphereDome(half)):-1;
        if(analytic>=0){++checks;if(std::abs(ref160-analytic)>.0005)++failures;}
        for(float spacing : shape>=3?std::vector<float>{.0625f}:std::vector<float>{.25f,.125f})for(int frame=0;frame<2;++frame) {
            diagnosticSurface=surface;
            diagnosticFrame=frame?glm::angleAxis(.63f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);
            diagnosticOrigin=frame?glm::vec3(1,-2,3):glm::vec3(0);
            std::vector<FluidParticle> particles;
            const int n=int(std::round(2/spacing));
            for(int z=0;z<n;++z)for(int x=0;x<n;++x)for(int y=0;y<n;++y) {
                const float px=-1+(x+.5f)*spacing,pz=-1+(z+.5f)*spacing;
                const glm::vec3 p(px,float(Height(surface,px,pz))-(y+.5f)*spacing,pz);
                const auto local=glm::conjugate(turn)*p;
                const bool inside=shape==1?glm::dot(local,local)<half*half:glm::all(glm::lessThan(glm::abs(local),glm::vec3(half)));
                if(inside)continue;
                const auto world=diagnosticOrigin+diagnosticFrame*p;
                particles.push_back({world,world,glm::vec3(0),1000*spacing*spacing*spacing,glm::vec3(0)});
            }
            FluidVolumeQuadrature volume;
            if(shape==1)volume=MakeSphereFluidVolume(half);
            else if(shape==2)volume=MakeCompoundFluidVolume({{{-.15f,0,0},{.15f,half,half}},{{.15f,0,0},{.15f,half,half}}});
            else volume=MakeBoxFluidVolume(glm::vec3(half));
            FluidHydrostaticField field;field.Build(particles,1000);
            BodyTransform pose;pose.position=diagnosticOrigin;pose.rotation=diagnosticFrame*turn;
            Uniform gravity;
            for(diagnosticMode=0;diagnosticMode<8;++diagnosticMode) {
                diagnosticRecords.clear();
                const auto result=EvaluateFluidHydrostatics(field,volume,pose,gravity);
                unsigned fits=0,bands=0,hulls=0,contacts=0,index=0;
                for(const auto& d:diagnosticRecords) {
                    fits+=d.fit;bands+=d.modelBands;hulls+=d.hullRejects;contacts+=d.contactRejects;
                    const auto p=glm::inverse(diagnosticFrame)*(d.point-diagnosticOrigin);
                    samples<<shape<<','<<surface<<','<<half<<','<<spacing<<','<<frame<<','<<diagnosticMode<<','<<index++<<','<<p.x<<','<<p.y<<','<<p.z<<','<<d.halfHeight<<','<<d.result<<','<<d.exactCap<<','<<d.fit<<','<<d.fittedCap<<','<<d.confidence<<','<<d.modelBands<<','<<d.hullRejects<<','<<d.contactRejects<<','<<d.earlyReason<<'\n';
                }
                rows<<shape<<','<<surface<<','<<half<<','<<spacing<<','<<frame<<','<<diagnosticMode<<','<<ref64<<','<<ref96<<','<<ref160<<','<<analytic<<','<<result.fraction<<','<<diagnosticRecords.size()<<','<<fits<<','<<bands<<','<<hulls<<','<<contacts<<'\n'<<std::flush;
                if(diagnosticMode==1 && surface==0){++checks;if(std::abs(result.fraction-.5)>.001)++failures;}
            }
        }
    }
    // Oracle controls use the actual Evaluate path with no fluid particles needed.
    diagnosticMode=1;diagnosticSurface=0;diagnosticFrame={1,0,0,0};diagnosticOrigin={0,0,0};
    FluidHydrostaticField field;field.Build({},1000);Uniform gravity;
    for(float y : {-2.f,2.f}) {
        BodyTransform pose;pose.position.y=y;
        diagnosticRecords.clear();
        const auto result=EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(glm::vec3(.3f)),pose,gravity);
        ++checks;if(std::abs(result.fraction-(y<0?1.f:0.f))>1e-6)++failures;
    }
    // Negative control: this domain has an explicitly authored dry hole. A
    // flat height cap alone does not describe it. The all-admission bypass must
    // demonstrate false wetness, not be promoted as a usable replacement.
    std::ofstream negative(directory/"dry-hole-negative.csv");
    negative<<"frame,mode,expected,observed\n";
    for(int frame=0;frame<2;++frame) {
        diagnosticFrame=frame?glm::angleAxis(.63f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);
        diagnosticOrigin=frame?glm::vec3(1,-2,3):glm::vec3(0);
        std::vector<FluidParticle> particles;
        const float spacing=.125f;
        for(int z=0;z<16;++z)for(int x=0;x<16;++x)for(int y=0;y<16;++y) {
            const float px=-1+(x+.5f)*spacing,pz=-1+(z+.5f)*spacing;
            if(std::abs(px)<.375f&&std::abs(pz)<.375f)continue;
            const auto point=diagnosticOrigin+diagnosticFrame*glm::vec3(px,-(y+.5f)*spacing,pz);
            particles.push_back({point,point,glm::vec3(0),1000*spacing*spacing*spacing,glm::vec3(0)});
        }
        FluidHydrostaticField ring;ring.Build(particles,1000);
        BodyTransform pose;pose.position=diagnosticOrigin;pose.rotation=diagnosticFrame;
        for(int mode : {0,7}) {
            diagnosticMode=mode;diagnosticRecords.clear();
            const auto result=EvaluateFluidHydrostatics(ring,MakeBoxFluidVolume(glm::vec3(.3f)),pose,gravity);
            negative<<frame<<','<<mode<<",0,"<<result.fraction<<'\n';
            ++checks;
            if(mode==0?result.fraction!=0:result.fraction<.4f)++failures;
        }
    }
    std::cout<<"Oracle controls: "<<checks<<" checks, "<<failures<<" failures\n";
    return failures?1:0;
}
