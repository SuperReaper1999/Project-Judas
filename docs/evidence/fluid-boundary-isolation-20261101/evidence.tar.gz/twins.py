from pathlib import Path
import struct,hashlib,json
c=Path(__file__).resolve().parent
f32=lambda v:struct.unpack('<f',struct.pack('<f',v))[0]
half=f32(.3);spacing=.0625
states=[bytearray(),bytearray()];counts=[0,0]
for z in range(32):
 for x in range(32):
  for y in range(32):
   p=(-1+(x+.5)*spacing,-(y+.5)*spacing,-1+(z+.5)*spacing)
   for i,excluded_half in enumerate([half,.3125]):
    if all(abs(v)<excluded_half for v in p):continue
    # Explicit relevant particle state; both fields also have zero velocity,
    # acceleration and identical previous positions, density and body geometry.
    states[i]+=struct.pack('<4f',*p,1000*spacing**3);counts[i]+=1
assert states[0]==states[1]
result=dict(half=half,spacing=spacing,clearance=.34375-spacing/2-half,
 byte_identical=True,particles=counts,sha256=[hashlib.sha256(s).hexdigest() for s in states],
 specifications=[dict(name='body_displaces_intended_continuous_water',excluded_half=half,continuum_body_fraction=.5),dict(name='explicit_dry_cavity_around_same_body',excluded_half=.3125,continuum_body_fraction=0)],
 conclusion='Particle states plus body geometry do not identify these distinct intended water domains. Additional boundary/ownership information is required for an unambiguous answer.')
(c/'TWINS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
