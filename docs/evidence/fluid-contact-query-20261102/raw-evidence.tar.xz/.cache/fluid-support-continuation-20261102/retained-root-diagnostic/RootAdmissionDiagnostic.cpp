#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <cmath>
namespace {
int checks=0,failures=0;
void Check(bool ok,const char* name){++checks;if(!ok){++failures;std::cout<<"FAIL "<<name<<'\n';}}
void Near(double v,double e,double t,const char* name){Check(std::abs(v-e)<=t,name);if(std::abs(v-e)>t)std::cout<<"observed="<<v<<" expected="<<e<<" tolerance="<<t<<'\n';}
void VectorNear(glm::vec3 v,glm::vec3 e,float t,const char* name){Check(glm::length(v-e)<=t,name);}
struct Uniform:GravityField{glm::vec3 value;explicit Uniform(glm::vec3 g):value(g){}glm::vec3 Sample(const glm::vec3&)const override{return value;}};
}
#include "../rejected-global-halo-ban/source/tests/FluidFiniteBoundaryChecks.h"
int main(){FluidFiniteBoundaryTest::FineFullyImmersedSourceTwins();FluidFiniteBoundaryTest::ConnectedRootAirControls();std::cout<<"checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;}
