from pathlib import Path
import subprocess,json,shlex
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/profile';b=r/'.cache/2d-stage1-build'
h=(r/'src/FluidWetFootprint.h').read_text().replace('#include <algorithm>','#include <algorithm>\n#include <chrono>\n#include <cstdint>')
pos=h.index('// The local hydrostatic approximation')
h=h[:pos]+'''namespace FluidProbe {
using Clock=std::chrono::steady_clock;
inline std::uint64_t hull=0,footprint=0,route=0,topology=0,hullCalls=0,footprintCalls=0,routeCalls=0;
struct Timer { std::uint64_t& total; Clock::time_point start=Clock::now();
 Timer(std::uint64_t& ns,std::uint64_t& calls):total(ns){++calls;}
 ~Timer(){total+=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count();}
};
}
'''+h[pos:]
h=h.replace('''    if (points.empty()) return false;''','''    FluidProbe::Timer probe(FluidProbe::hull,FluidProbe::hullCalls);
    if (points.empty()) return false;''')
h=h.replace('''    if (columns.empty()) return false;''','''    FluidProbe::Timer probe(FluidProbe::footprint,FluidProbe::footprintCalls);
    if (columns.empty()) return false;
    const auto topologyStart=FluidProbe::Clock::now();''')
h=h.replace('''    std::vector<std::vector<glm::dvec2>> patches''','''    FluidProbe::topology+=std::chrono::duration_cast<std::chrono::nanoseconds>(FluidProbe::Clock::now()-topologyStart).count();
    std::vector<std::vector<glm::dvec2>> patches''')
h=h.replace('''    using Cell = std::pair<std::int64_t, std::int64_t>;''','''    FluidProbe::Timer probe(FluidProbe::route,FluidProbe::routeCalls);
    using Cell = std::pair<std::int64_t, std::int64_t>;''')
(o/'FluidWetFootprint.h').write_text(h)
s=(r/'src/FluidHydrostatics.cpp').read_text()+'\n#include <iostream>\nvoid PrintFluidProbeStats(){std::cerr<<"{\\"hull_ns\\":"<<FluidProbe::hull<<",\\"footprint_including_hull_ns\\":"<<FluidProbe::footprint<<",\\"topology_ns\\":"<<FluidProbe::topology<<",\\"route_ns\\":"<<FluidProbe::route<<",\\"hull_calls\\":"<<FluidProbe::hullCalls<<",\\"footprint_calls\\":"<<FluidProbe::footprintCalls<<",\\"route_calls\\":"<<FluidProbe::routeCalls<<"}\\n";}\n'
(o/'FluidHydrostatics.cpp').write_text(s)
d=(r/'.cache/fluid-support-continuation-20261102/replay/FrozenBench.cpp').read_text().replace('using Json=nlohmann::json;','using Json=nlohmann::json;\nvoid PrintFluidProbeStats();').replace('int main(int argc,char**argv){','int main(int argc,char**argv){std::atexit(PrintFluidProbeStats);')
(o/'Driver.cpp').write_text(d)
flags={}
for line in (b/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
cmds=[]
for name in ['Driver','FluidHydrostatics']:
 cmd=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-I'+str(r),'-c',str(o/(name+'.cpp')),'-o',str(o/(name+'.o'))];cmds.append(cmd);subprocess.run(cmd,check=True)
link=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());link=[a for a in link if not a.startswith('-Wl,--dependency-file=')];link[link.index('CMakeFiles/judas_production_fluid_tests.dir/tests/ProductionFluidTests.cpp.o')]=str(o/'Driver.o');link[link.index('-o')+1]=str(o/'probe');link.insert(link.index('libjudas_engine.a'),str(o/'FluidHydrostatics.o'));cmds.append(link);(o/'BUILD.json').write_text(json.dumps(cmds,indent=2)+'\n');subprocess.run(link,cwd=b,check=True)
