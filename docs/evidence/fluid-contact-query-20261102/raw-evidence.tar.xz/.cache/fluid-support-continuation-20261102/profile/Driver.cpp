#include "FluidHydrostatics.h"
#include "third_party/nlohmann/json.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <chrono>
using Json=nlohmann::json;
void PrintFluidProbeStats();
static glm::vec3 Vec(const Json& j){return {j.at(0).get<float>(),j.at(1).get<float>(),j.at(2).get<float>()};}
static glm::quat Quat(const Json& j){return {j.at(0).get<float>(),j.at(1).get<float>(),j.at(2).get<float>(),j.at(3).get<float>()};}
static BodyTransform Pose(const Json& j){BodyTransform p;p.position=Vec(j.at("position"));p.rotation=Quat(j.at("rotation"));return p;}
static BodyHandle Owner(const Json& j){BodyHandle h;h.id=j.at(0).get<unsigned>();h.world=j.at(1).get<decltype(h.world)>();return h;}
int main(int argc,char**argv){std::atexit(PrintFluidProbeStats);
 try{
  if(argc!=2)return 2;
  std::ifstream f(argv[1]);Json j;f>>j;
  std::vector<FluidParticle> particles;float maxSpacingError=0;
  for(const auto& p:j.at("particles")){FluidParticle q;q.position=Vec(p.at("position"));q.previousPosition=q.position;q.velocity=Vec(p.at("velocity"));q.acceleration=Vec(p.at("acceleration"));q.mass=p.at("mass").get<float>();maxSpacingError=std::max(maxSpacingError,std::abs(std::cbrt(q.mass/j.at("density").get<float>())-p.at("spacing").get<float>()));particles.push_back(q);}
  if(maxSpacingError!=0){std::cerr<<"mass conversion changes spacing\n";return 2;}
  std::vector<CompoundBox> boxes;
  for(const auto& b:j.at("solidBoxes")){CompoundBox q;q.localCenter=Vec(b.at("center"));q.halfExtents=Vec(b.at("half"));q.rotation=Quat(b.at("rotation"));boxes.push_back(q);}
  const auto volume=MakeCompoundFluidVolume(boxes);const auto base=Pose(j.at("solidPose"));const auto owner=Owner(j.at("solidOwner"));
  FluidHydrostaticField field;field.Build(particles,j.at("density").get<float>());
  for(const auto& b:j.at("boundaries")){
   if(b.at("domainAvailable").get<bool>())return 2;
   if(Owner(b.at("owner")).id!=owner.id||Owner(b.at("owner")).world!=owner.world)return 2;
   std::vector<FluidDisplacementMarker> markers;
   for(const auto& c:b.at("cells")){FluidDisplacementMarker q;q.owner=Owner(c.at("owner"));q.position=Vec(c.at("position"));q.rotation=Quat(c.at("rotation"));q.halfWidth=c.at("halfWidth").get<float>();q.materialPoint=Vec(c.at("materialPoint"));q.contactPoint=Vec(c.at("contactPoint"));markers.push_back(q);}
   field.RetainDisplacementCells(owner,volume,Pose(b.at("pose")),markers);
  }
  const auto point=Vec(j.at("point")),up=Vec(j.at("up")),tangent=Vec(j.at("tangent"));
  if(const char* raw=std::getenv("JUDAS_REFERENCE_SLICES")) {
   const int n=std::atoi(raw);if(n<=0||n>8192)return 2;
   const float half=j.at("halfHeight").get<float>();double integrated=0;
   const FluidSolidQuery solid{volume,base,owner};
   for(int i=0;i<n;++i){const auto p=point+up*float(-half+(i+.5)*2*half/n);integrated+=field.Query(p,up,0,j.at("radius").get<float>(),tangent,&solid,true).fraction;}
   std::cerr<<std::setprecision(17)<<"POINT_INTEGRAL "<<n<<' '<<integrated/n<<'\n';
  }
  if(const char* raw=std::getenv("JUDAS_BENCH_LOOPS")) {
   const int n=std::atoi(raw);if(n<=0||n>100000)return 2;
   double checksum=0;
   const auto started=std::chrono::steady_clock::now();
   for(int i=0;i<n;++i){
    const auto offset=up*(i%3==0?-.0001f:i%3==1?0.f:.0001f);
    auto pose=base;pose.position+=offset;
    const FluidSolidQuery solid{volume,pose,owner};
    checksum+=field.Query(point+offset,up,j.at("halfHeight").get<float>(),j.at("radius").get<float>(),tangent,&solid,true).fraction;
   }
   const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
   std::cout<<std::setprecision(17)<<"{\"queries\":"<<n<<",\"seconds\":"<<seconds<<",\"checksum\":"<<checksum<<"}\n";return 0;
  }
  std::cout<<std::setprecision(17)<<"delta,point_y,body_y,fraction\n";
  for(float delta:{-.001f,-.0001f,-.00001f,-.000001f,0.f,.000001f,.00001f,.0001f,.001f}){
   auto pose=base;pose.position+=delta*up;const auto where=point+delta*up;const FluidSolidQuery solid{volume,pose,owner};
   const auto sample=field.Query(where,up,j.at("halfHeight").get<float>(),j.at("radius").get<float>(),tangent,&solid,true);
   std::cout<<delta<<','<<where.y<<','<<pose.position.y<<','<<sample.fraction<<'\n';
  }
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}
}
