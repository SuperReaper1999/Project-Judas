#include "FluidHydrostatics.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::ifstream file(argv[1]);std::string line;std::getline(file,line);
 std::vector<FluidParticle> particles;glm::dvec3 sum(0);double mass=0;
 while(std::getline(file,line)){
  std::stringstream row(line);std::vector<std::string> cells;std::string cell;while(std::getline(row,cell,','))cells.push_back(cell);
  FluidParticle p;p.mass=std::stof(cells.at(1));p.position={std::stof(cells.at(2)),std::stof(cells.at(3)),std::stof(cells.at(4))};p.previousPosition=p.position;p.velocity={std::stof(cells.at(5)),std::stof(cells.at(6)),std::stof(cells.at(7))};p.acceleration={std::stof(cells.at(8)),std::stof(cells.at(9)),std::stof(cells.at(10))};
  sum+=glm::dvec3(p.position)*double(p.mass);mass+=p.mass;particles.push_back(p);
 }
 const glm::vec3 center(sum/mass),up(0,1,0);FluidHydrostaticField field;field.Build(particles,1000);
 const auto volume=MakeBoxFluidVolume(glm::vec3(.3f,.6f+.3f,.3f));const auto tangent=field.ReconstructionTangent(up,{1,0,0});
 std::cout<<std::setprecision(17)<<"sample,px,py,pz,half,fraction,volume\n";double wet=0;
 for(std::size_t i=0;i<volume.samples.size();++i){const auto& sample=volume.samples[i];const auto point=center+sample.localPosition;const float half=sample.localHalfExtents.y;const auto result=field.Query(point,up,half,volume.boundRadius,tangent,nullptr,true);wet+=double(sample.volume)*result.fraction;
  std::cout<<i<<','<<point.x<<','<<point.y<<','<<point.z<<','<<half<<','<<result.fraction<<','<<sample.volume<<'\n';
 }
 std::cerr<<std::setprecision(17)<<"SUMMARY particles="<<particles.size()<<" centroid="<<center.x<<','<<center.y<<','<<center.z<<" fraction="<<wet/volume.totalVolume<<'\n';
}
