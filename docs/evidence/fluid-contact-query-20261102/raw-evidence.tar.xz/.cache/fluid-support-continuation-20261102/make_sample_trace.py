from pathlib import Path
import shlex,subprocess,json,hashlib,datetime
root=Path.cwd();out=root/'.cache/fluid-support-continuation-20261102';build=root/'.cache/2d-stage1-build'
s=(root/'src/ProductionFluidCoupling.cpp').read_text().replace('#include <stdexcept>', '#include <stdexcept>\n#include <fstream>\n#include <iomanip>\n#include <cstdlib>\nint JudasProbeRow=-1,JudasProbeSample=-1,JudasProbeVariant=-1;')
needle='''        auto& diagnostic=s.measured.bodies[i];diagnostic.fraction=hydro.fraction;'''
insert=r'''        if(const char* path=std::getenv("JUDAS_FLUID_SAMPLE_TRACE")) {
            static std::uint64_t row=0;
            if(row==589 || row==386 || row==622) {
                static std::ofstream trace(path);
                static bool header=false;
                if(!header){trace<<"row,sample,fraction,minus_fraction,plus_fraction,px,py,pz,halfheight\n"<<std::setprecision(17);header=true;}
                const auto g=world.Gravity().Sample(pose.position);
                const auto up=glm::dot(g,g)>0 ? -glm::normalize(g) : glm::vec3(0,1,0);
                auto minus=pose,plus=pose;minus.position-=up*1e-4f;plus.position+=up*1e-4f;
                auto one=body.volume;
                JudasProbeRow=int(row);
                for(std::size_t j=0;j<body.volume.samples.size();++j) {
                    const auto sample=body.volume.samples[j];one.samples.assign(1,sample);one.totalVolume=sample.volume;
                    JudasProbeSample=int(j);JudasProbeVariant=0;
                    const auto center=EvaluateFluidHydrostatics(*field,one,pose,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle);
                    JudasProbeVariant=-1;
                    const auto low=EvaluateFluidHydrostatics(*field,one,minus,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle);
                    JudasProbeVariant=1;
                    const auto high=EvaluateFluidHydrostatics(*field,one,plus,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle);
                    const auto p=pose.position+pose.rotation*sample.localPosition;
                    const auto localUp=glm::conjugate(pose.rotation)*up;
                    const auto half=glm::dot(glm::abs(glm::conjugate(sample.localRotation)*localUp),sample.localHalfExtents)+sample.localRadius;
                    trace<<row<<','<<j<<','<<center.fraction<<','<<low.fraction<<','<<high.fraction<<','<<p.x<<','<<p.y<<','<<p.z<<','<<half<<'\n';
                }
                JudasProbeRow=JudasProbeSample=JudasProbeVariant=-1;
            }
            ++row;
        }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle);(out/'SampleCoupling.cpp').write_text(s)
h=(root/'src/FluidHydrostatics.cpp').read_text().replace('#include "FluidHydrostatics.h"','#include "FluidHydrostatics.h"\n#include <fstream>\n#include <iomanip>\n#include <cstdlib>\nextern int JudasProbeRow,JudasProbeSample,JudasProbeVariant;')
needle='''    const auto occupiedLength=[]'''
insert=r'''    auto probe=[&](const char* kind,double lo=0,double hi=0,double value=0) {
        if(JudasProbeRow<0)return;
        const char* path=std::getenv("JUDAS_FLUID_QUERY_TRACE");if(!path)return;
        static std::ofstream trace(path);static bool header=false;
        if(!header){trace<<"row,sample,variant,kind,lo,hi,value,owned,surface_height,confidence,point_y\n"<<std::setprecision(17);header=true;}
        trace<<JudasProbeRow<<','<<JudasProbeSample<<','<<JudasProbeVariant<<','<<kind<<','<<lo<<','<<hi<<','<<value<<','<<owned.size()<<','<<(surface?surface->height:999)<<','<<(surface?surface->confidence:0)<<','<<point.y<<'\n';
    };
    probe("entry");
'''
assert h.count(needle)==1;h=h.replace(needle,insert+needle)
h=h.replace('''if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport))return 0.0;''','''if(!FluidWetColumnsContainOrigin(wet,outerWidth,connectedWetSupport)){probe(reconstruction?"hull_model_dry":"hull_original_dry",lo,hi,0);return 0.0;}''')
h=h.replace('''if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact,!reconstruction))return 0.0;''','''if(!FluidWetSupportThroughSolid(wet,columnWidth,{originX,originZ},covered,notEmpty,wetContact,!reconstruction)){probe(reconstruction?"route_model_dry":"route_original_dry",lo,hi,0);return 0.0;}''')
h=h.replace('''if(reconstruction && surface)return middle<=surface->height ? 1.0 : 0.0;''','''if(reconstruction && surface){const double value=middle<=surface->height?1.0:0.0;probe("model",lo,hi,value);return value;}''')
h=h.replace('''return total>0 ? weighted/total : 0.0;''','''const double value=total>0 ? weighted/total : 0.0;probe("original",lo,hi,value);return value;''')
(out/'SampleHydro.cpp').write_text(h)
flags={}
for line in (build/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
commands=[]
for stem in ['SampleCoupling','SampleHydro']:
 cmd=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-c',str(out/(stem+'.cpp')),'-o',str(out/(stem+'.o'))];commands.append(cmd);subprocess.run(cmd,check=True)
link=shlex.split((build/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());link=[a for a in link if not a.startswith('-Wl,--dependency-file=')];link[link.index('-o')+1]=str(out/'samples');i=link.index('libjudas_engine.a');link[i:i]=[str(out/'SampleCoupling.o'),str(out/'SampleHydro.o')];commands.append(link)
(out/'SAMPLES_BUILD.json').write_text(json.dumps({'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commands':commands,'linkWorkingDirectory':str(build)},indent=2)+'\n');subprocess.run(link,cwd=build,check=True)
