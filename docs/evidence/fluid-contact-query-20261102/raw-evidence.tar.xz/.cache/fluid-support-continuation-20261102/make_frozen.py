from pathlib import Path
import shlex,subprocess,json
root=Path.cwd();out=root/'.cache/fluid-support-continuation-20261102';build=root/'.cache/2d-stage1-build'
h=(out/'SampleHydro.cpp').read_text().replace('#include <fstream>', '#include <fstream>\n#include "'+str(root/'third_party/nlohmann/json.hpp')+'"')
needle='''    probe("entry");'''
insert=r'''    if(JudasProbeRow==589 && JudasProbeSample==0 && JudasProbeVariant==0 && solid) {
        if(const char* path=std::getenv("JUDAS_FLUID_FROZEN_INPUT")) {
            using Json=nlohmann::json;
            const auto vec=[](auto p){return Json::array({p.x,p.y,p.z});};
            const auto quat=[](auto p){return Json::array({p.w,p.x,p.y,p.z});};
            const auto pose=[&](const BodyTransform& p){return Json{{"position",vec(p.position)},{"rotation",quat(p.rotation)}};};
            Json j={{"point",vec(point)},{"up",vec(direction)},{"halfHeight",halfHeight},{"radius",radius},{"tangent",vec(tangentAxis)},
                    {"density",m_density},{"solidPose",pose(solid->pose)},{"solidOwner",{solid->owner.id,solid->owner.world}},
                    {"solidBoxes",Json::array()},{"particles",Json::array()},{"boundaries",Json::array()}};
            for(const auto& b:solid->volume.solidBoxes)j["solidBoxes"].push_back({{"center",vec(b.localCenter)},{"half",vec(b.halfExtents)},{"rotation",quat(b.rotation)}});
            for(const auto& p:m_particles)j["particles"].push_back({{"position",vec(p.position)},{"velocity",vec(p.velocity)},{"acceleration",vec(p.acceleration)},{"volume",p.volume},{"spacing",p.spacing},{"mass",p.volume*m_density}});
            for(const auto& b:m_boundaries) {
                Json boundary={{"owner",{b.owner.id,b.owner.world}},{"pose",pose(b.pose)},{"domainAvailable",bool(b.domain)},{"cells",Json::array()}};
                for(const auto& c:b.cells)boundary["cells"].push_back({{"owner",{c.owner.id,c.owner.world}},{"position",vec(c.position)},{"rotation",quat(c.rotation)},{"halfWidth",c.halfWidth},{"materialPoint",vec(c.materialPoint)},{"contactPoint",vec(c.contactPoint)}});
                j["boundaries"].push_back(boundary);
            }
            std::ofstream file(path);file<<j.dump(2)<<'\n';
        }
    }
'''
h=h.replace(needle,needle+'\n'+insert);(out/'FrozenHydro.cpp').write_text(h)
w=(root/'src/FluidWetFootprint.h').read_text()
w=w.replace('#include <algorithm>','#include <algorithm>\n#include <fstream>\n#include <cstdlib>\nextern int JudasProbeRow,JudasProbeSample,JudasProbeVariant;')
needle='''    using Cell = std::pair<std::int64_t, std::int64_t>;'''
w=w.replace(needle,'''    const auto trace=[&](const char* reason, double a=0,double b=0) {
        if(JudasProbeRow!=589)return;
        const char* path=std::getenv("JUDAS_FLUID_ROUTE_TRACE");if(!path)return;
        static std::ofstream file(path);file<<JudasProbeSample<<','<<JudasProbeVariant<<','<<reason<<','<<a<<','<<b<<'\\n';
    };
'''+needle)
w=w.replace('''if (allowDirectRoot && initial && initial->wet) return true;''','''if (allowDirectRoot && initial && initial->wet){trace("direct_root");return true;}''')
w=w.replace('''if (!covered(root.first, root.second)) return false;''','''if (!covered(root.first, root.second)){trace("uncovered_root",root.first,root.second);return false;}''')
w=w.replace('''if (initial && initial->observedWet && wetContact(root.first, root.second)) return true;''','''if (initial && initial->observedWet && wetContact(root.first, root.second)){trace("contact_root");return true;}''')
w=w.replace('''if ((!present || present->resolvedAir) && !notEmpty(air.first, air.second)) return false;''','''if ((!present || present->resolvedAir) && !notEmpty(air.first, air.second)){trace("closer_air",air.first,air.second);return false;}''')
w=w.replace('''if (observed && observed->observedWet && wetContact(next.first, next.second)) return true;''','''if (observed && observed->observedWet && wetContact(next.first, next.second)){trace("contact_neighbor",next.first,next.second);return true;}''')
w=w.replace('''    return false;\n}\n''','''    trace("no_route");return false;\n}\n''') if False else w
# Only the final return belongs to the traversal template.
i=w.rfind('    return false;');w=w[:i]+w[i:].replace('    return false;','    trace("no_route");return false;',1)
(out/'FluidWetFootprint.h').write_text(w)
flags={}
for line in (build/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
cmd=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-c',str(out/'FrozenHydro.cpp'),'-o',str(out/'FrozenHydro.o')];subprocess.run(cmd,check=True)
link=shlex.split((build/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());link=[a for a in link if not a.startswith('-Wl,--dependency-file=')];link[link.index('-o')+1]=str(out/'frozen-capture');i=link.index('libjudas_engine.a');link[i:i]=[str(out/'SampleCoupling.o'),str(out/'FrozenHydro.o')];(out/'FROZEN_BUILD.json').write_text(json.dumps({'compile':cmd,'link':link,'linkWorkingDirectory':str(build)},indent=2)+'\n');subprocess.run(link,cwd=build,check=True)
