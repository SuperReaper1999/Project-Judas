#include "FluidWorld.h"
#include "GravityField.h"
#include <nlohmann/json.hpp>
#include <glm/gtc/quaternion.hpp>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using Json = nlohmann::ordered_json;

struct ZeroGravity final : GravityField {
    glm::vec3 Sample(const glm::vec3&) const override { return {}; }
};

Json Vector(const glm::vec3& v) { return Json::array({v.x,v.y,v.z}); }
Json Particle(const FluidParticle& p) {
    return {{"position",Vector(p.position)}, {"previousPosition",Vector(p.previousPosition)},
            {"velocity",Vector(p.velocity)}, {"mass",p.mass}, {"acceleration",Vector(p.acceleration)}};
}
Json State(const FluidWorld& fluid) {
    Json result=Json::array();
    for(const auto& particle:fluid.Particles())result.push_back(Particle(particle));
    return result;
}
Json Markers(const FluidWorld& fluid) {
    Json result=Json::array();
    for(const auto& marker:fluid.DisplacementMarkers()) {
        result.push_back({{"ownerId",marker.owner.id}, {"ownerWorld",marker.owner.world},
            {"position",Vector(marker.position)}, {"halfWidth",marker.halfWidth},
            {"rotation",Json::array({marker.rotation.w,marker.rotation.x,marker.rotation.y,marker.rotation.z})},
            {"materialPoint",Vector(marker.materialPoint)}, {"contactPoint",Vector(marker.contactPoint)}});
    }
    return result;
}

int main() {
    constexpr float dt=1.f/60;
    const ZeroGravity gravity;
    struct Case { const char* name; glm::vec3 point,velocity; bool expectThrow; };
    const float skin=.3f+.018f;
    const std::vector<Case> cases{
        {"exact_center_stationary",{0,0,0},{0,0,0},false},
        {"near_center_below_normal_threshold",{1e-8f,0,0},{0,0,0},false},
        {"near_center_axis",{1e-4f,0,0},{0,0,0},false},
        {"near_center_diagonal",{1e-3f,1e-3f,1e-3f},{0,0,0},false},
        {"center_directional_departure_x",{0,0,0},{.1f,0,0},false},
        {"center_directional_departure_y",{0,0,0},{0,.1f,0},false},
        {"center_directional_departure_diagonal",{0,0,0},{-.1f,.2f,-.3f},false},
        {"surface_departure",{skin,0,0},{.1f,0,0},false},
        {"surface_tangent",{skin,0,0},{0,.1f,0},false}
    };
    Json rows=Json::array();
    unsigned mismatches=0,throws=0;
    for(const bool defaults:{false,true})for(int frame=0;frame<2;++frame)for(const auto& test:cases) {
        const glm::quat rotation=frame?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);
        const glm::vec3 translation=frame?glm::vec3(2,-1,3):glm::vec3(0);
        FluidSettings settings;
        if(!defaults){settings.substeps=1;settings.densityIterations=0;settings.velocitySmoothing=0;}
        FluidWorld fluid(settings);
        const glm::vec3 initial=translation+rotation*test.point;
        fluid.AddParticle(initial,rotation*test.velocity,1.953125f);
        FluidSphereCollider sphere;
        sphere.owner={73,401};sphere.radius=.3f;
        sphere.previousPose={translation,rotation};sphere.currentPose=sphere.previousPose;
        const auto before=State(fluid),beforeMarkers=Markers(fluid);
        const auto beforeRevision=fluid.Revision();
        bool threw=false;std::string error;
        std::vector<FluidContactImpulse> impulses;
        try { fluid.Step(dt,gravity,{}, {sphere},&impulses); }
        catch(const std::exception& exception) { threw=true;error=exception.what(); }
        throws+=threw;
        const auto after=State(fluid);
        const auto diagnostics=fluid.GetDiagnostics();
        bool finite=true,outside=true;
        for(const auto& particle:fluid.Particles()) {
            for(const auto v:{particle.position,particle.previousPosition,particle.velocity,particle.acceleration})
                finite=finite&&std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);
            const glm::dvec3 delta=glm::dvec3(particle.position)-glm::dvec3(translation);
            outside=outside&&glm::dot(delta,delta)>=double(sphere.radius)*sphere.radius;
        }
        const bool expected=threw==test.expectThrow&&finite&&(!threw?outside:true);
        mismatches+=!expected;
        rows.push_back({{"case",test.name}, {"settings",defaults?"production_defaults":"isolated_contact"},
            {"frame",frame}, {"authoredLocalPoint",Vector(test.point)},
            {"representedLocalPoint",Vector(glm::conjugate(rotation)*(initial-translation))},
            {"authoredLocalVelocity",Vector(test.velocity)}, {"expectThrow",test.expectThrow},
            {"threw",threw}, {"error",error}, {"matchedReproductionExpectation",expected},
            {"physicalStateExactEqual",before==after}, {"markerStateExactEqual",beforeMarkers==Markers(fluid)},
            {"revisionBefore",beforeRevision}, {"revisionAfter",fluid.Revision()},
            {"finite",finite}, {"outsideRealSphere",outside}, {"contactImpulses",impulses.size()},
            {"unresolvedGeometry",diagnostics.unresolvedGeometryCount},
            {"before",before}, {"after",after}, {"markersAfter",Markers(fluid)}});
    }
    Json output{{"purpose","candidate initialization controls; original failure records preserved separately"},
        {"sourceCommit","d71af6e007b5c39a822f0f563f4dd108040cea4b"},
        {"dt",dt}, {"sphereRadius",.3f}, {"caseMeasurements",rows.size()},
        {"observedThrows",throws}, {"reproductionExpectationMismatches",mismatches}, {"rows",rows}};
    std::cout<<output.dump(2)<<'\n';
    return mismatches?2:0;
}
