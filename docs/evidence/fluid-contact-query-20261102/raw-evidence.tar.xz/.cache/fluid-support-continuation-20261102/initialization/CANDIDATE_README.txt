Qualified sphere initial-overlap correction, 2 November 2026

Base: d71af6e007b5c39a822f0f563f4dd108040cea4b, Experimental.
No CMake changes, main promotion, fluid unlock, tuning or performance claim.

Targeted implementation:
- src/FluidWorld.cpp, CollideSphere startInside branch only.
- Normalize every represented nonzero start-relative radial direction in double;
  otherwise use the nonzero end-relative direction. This preserves valid normals
  below the old absolute 1e-7 threshold, including subnormal float components.
- Only a truly directionless centre selects the sphere body's local +X. This
  is an explicit initial-overlap exit policy, follows global body rotation, and
  is identical for quaternion q and -q. It is not an invented world direction.
- Geometric projected positions still pass the existing real-solid validation.
  Swept quadratic, ordinary tangency/departure and box face selection unchanged.

Durable tests:
- tests/FluidSphereInitializationChecks.h, included by FluidWorldTests.cpp.
  64 stationary input/settings/frame measurements cover exact centre, subnormal
  1e-40 and nonzero rays below/around/above 1e-7, identity/rotated/translated
  frames, real-solid exclusion, radial direction, mass, zero velocity/kinetic
  energy/contact impulse. Explicit q/-q equivalence adds six assertions.
- tests/FluidLifecycleQualificationTests.cpp adds 14 checks across two actual
  serialized authored scenes. Each creates 27 real particles in an odd 3x3x3
  lattice, including the exact-centre particle, and executes production coupling.
  They preserve mass/count and zero kinetic energy with every particle finite
  and outside the real sphere.

Final exact-source evidence (FINAL_BUILD.json commands and source hashes):
- final-tests.log: 355 checks, 0 failures, entire FluidWorld driver.
- final-lifecycle.log: 38 checks, 0 failures, entire lifecycle driver.
- final-old-negative-control.log: same new driver linked to original library,
  exit 1 with 46 assertion failures. These repeated measurements are not 46
  independent engine defects. Prior ordinary checks still complete.
- final-build.log: empty; standalone compile/link emitted no warning/error.

Separate original 36-measurement reproduction (results.json) retains eight
throws with the old implementation. candidate-results.json has zero exceptions
and all 36 declared control expectations pass. Stationary initial states gain
no velocity. candidate-tests.log qualifies the disposable full-source override
before tracked production changes were applied.

Runtime comparison, same SphereAuthoredRuntimeProbe.cpp:
- runtime-old-results.json: both scene frames build and instantiate one exact
  centre particle, then throw at particle 13 before executing a liquid step.
- runtime-candidate-results.json: both execute one liquid step; 27 finite exterior
  particles, exact 52.734375 kg total mass, zero kinetic energy.
- These are bounded headless one-step scenes, not full fluid acceptance.

Original README.txt and BUILD.json describe the earlier unmodified reproduction.
CANDIDATE_BUILD.json and ADDITIONAL_BUILD.json describe intermediate overrides.
A missing Project.h include caused the first authored-probe compile failure;
runtime-incomplete-project.log preserves it. Adding the proper header fixed the
harness; no physical assertion or runtime setting was weakened.

No source changes were made to the pressure solver, reconstruction, drag, gravity,
fluid cadence, authored settings, gate thresholds, persistence or origin ownership.
Existing unsupported continuation combinations and unrelated diagnostics remain.
Root agent owns the combined integration/build/commit decision; this subtask has
not staged, committed or pushed any changes.
