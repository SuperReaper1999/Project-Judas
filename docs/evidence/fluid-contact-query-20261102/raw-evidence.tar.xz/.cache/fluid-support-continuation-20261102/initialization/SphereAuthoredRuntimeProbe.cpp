#include "RuntimeWorld.h"
#include "Project.h"
#include "ProductionFluidCoupling.h"
#include "SceneSerialization.h"
#include <nlohmann/json.hpp>
#include <glm/gtc/quaternion.hpp>
#include <cmath>
#include <iostream>

int main() {
    using Json=nlohmann::ordered_json;
    Json rows=Json::array();unsigned failures=0;
    for(int frame=0;frame<2;++frame) {
        const glm::quat q=frame?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);
        const glm::vec3 center=frame?glm::vec3(2,-1,3):glm::vec3(0);
        Scene scene;scene.Settings().fluidScale=2.5f;
        auto& gravity=scene.CreateObject("Zero gravity");gravity.gravity=SceneGravityComponent{};
        gravity.gravity->kind=SceneGravityKind::Uniform;gravity.gravity->magnitude=0;
        gravity.gravity->regionShape=SceneRegionShape::Box;gravity.gravity->regionHalfExtents=glm::vec3(10);
        gravity.transform.position=center;gravity.transform.rotation=q;
        auto& water=scene.CreateObject("Odd authored lattice");water.fluidVolume=SceneFluidVolumeComponent{};
        water.fluidVolume->countX=water.fluidVolume->countY=water.fluidVolume->countZ=3;
        water.fluidVolume->spacing=.125f;water.transform.position=center-q*glm::vec3(0,.125f,0);
        water.transform.rotation=q;
        auto& solid=scene.CreateObject("Ordinary static sphere");solid.body=SceneBodyComponent{};
        solid.body->shape=SceneShape::Sphere;solid.body->radius=.3f;solid.body->motion=SceneBodyMotion::Static;
        solid.transform.position=center;solid.transform.rotation=q;
        std::string serialized,error;SaveSceneToString(scene,serialized);Scene loaded;
        const bool loadedOk=LoadSceneFromString(serialized,loaded,error);
        RuntimeWorld world;ProjectSettings settings;settings.advancedFluidDynamics=true;world.ConfigureProject(settings);
        const bool built=loadedOk&&world.Build(loaded,nullptr,error);
        Json row{{"frame",frame},{"loaded",loadedOk},{"built",built},{"buildError",error}};
        if(!built){++failures;rows.push_back(row);continue;}
        unsigned exactCenter=0;for(const auto& particle:world.Fluid().Particles())exactCenter+=particle.position==center;
        const auto before=world.Fluid().GetDiagnostics();bool completed=true;std::string stepError;
        try{world.FluidCoupling().AdvanceResolvedLiquid(world,1.f/60);}
        catch(const std::exception& exception){completed=false;stepError=exception.what();}
        const auto after=world.Fluid().GetDiagnostics();bool finite=true,outside=true;
        for(const auto& particle:world.Fluid().Particles()) {
            for(const auto value:{particle.position,particle.velocity,particle.acceleration})
                finite=finite&&std::isfinite(value.x)&&std::isfinite(value.y)&&std::isfinite(value.z);
            const glm::dvec3 radial=glm::dvec3(particle.position)-glm::dvec3(center);
            outside=outside&&glm::dot(radial,radial)>=double(.3f)*.3f;
        }
        const bool pass=exactCenter>0&&before.particleCount==27&&completed&&finite&&outside&&
            before.totalMass==after.totalMass&&after.particleCount==before.particleCount;
        failures+=!pass;
        row["exactCenterParticlesBefore"]=exactCenter;row["particlesBefore"]=before.particleCount;
        row["completed"]=completed;row["stepError"]=stepError;row["finite"]=finite;row["outsideRealSphere"]=outside;
        row["massBefore"]=before.totalMass;row["massAfter"]=after.totalMass;
        row["particlesAfter"]=after.particleCount;row["kineticEnergyAfter"]=after.kineticEnergy;
        row["executedLiquidSteps"]=world.FluidCoupling().Measurements().executedSteps;row["pass"]=pass;
        rows.push_back(row);
    }
    std::cout<<Json{{"failures",failures},{"rows",rows}}.dump(2)<<'\n';
    return failures?1:0;
}
