Sphere initialization failure reproduction, 2 November 2026

Source checkpoint: d71af6e007b5c39a822f0f563f4dd108040cea4b.
Standalone disposable public-API probe, linked against the current verified
.cache/2d-stage1-build/libjudas_engine.a. No production source, CMake, solver or
tracked fixture was changed. BUILD.json records exact commands, source/library
hashes and compile/link/run exits. build.log is empty (no compiler/linker output).

36 measurements = nine input cases x two settings x two coordinate frames.
Settings: production defaults, and one substep/no density iterations/no smoothing
to isolate geometric contact. Both use zero gravity, dt=1/60, a stationary radius
0.3 m sphere with full BodyHandle identity, and one actual 1.953125 kg particle.
Frames: identity, and rotation .83 rad about normalized (1,-2,3), translated by
(2,-1,3). Source JSON records authored AND represented local particle points.

Eight engine failures reproduced:
- Exact stationary sphere centre throws for both settings and both frames.
- A 1e-8 m offset, below the current normal threshold, also throws in both
  settings/frames. The translated input rounds to the exact centre; do not call
  it an exactly preserved nonzero local point.
- Error: FluidWorld hard solid union has no verified safe projection for particle 0
- All eight leave particle position/previousPosition/velocity/mass/acceleration
  and displacement markers exactly equal to their before states. The real solid
  still contains the particle. Revision advances 1 -> 2; unresolvedGeometry=1.
  Thus these PARTICULAR zero-gravity single-particle failures preserve physical
  arrays, but this is not a general exception-atomicity claim for FluidWorld.

28 positive/control completions:
- 1e-4 m axial and 1e-3 m diagonal nonzero initial positions.
- Three directional departures from the exact centre.
- Outward and tangential departures at the preferred sphere surface.
- All complete with finite physical state outside the real sphere. These are
  bounded one-step controls; no long-run/platform/energy/performance claim.

Cause identified in unchanged source:
src/FluidWorld.cpp:435-440 declines the centred contact because it has no normal.
The remaining hard-overlap repair enumerates encountered box planes only, so a
sphere-only centred input has no fallback candidate. Native PopulateFluid inserts
whole authored lattices and does not reject interior-sphere/centre authoring.
An exact centre has no unique geometric outward direction: any repair needs an
explicit initialization contract and suitable equivariance/negative controls.

results.json preserves every input/output and error. The probe exits 0 when it
reproduces its declared behavior; observedThrows=8 remains an engine failure
count, not a qualification pass. No original diagnostic or acceptance changed.

Re-run the existing binary from the repository root:
  .cache/fluid-support-continuation-20261102/initialization/sphere-initialization
