from pathlib import Path
import subprocess,json,time,shlex,hashlib
r=Path.cwd();p=r/'.cache/fluid-support-continuation-20261102';o=p/'qualified';b=r/'.cache/2d-stage1-build';rows=[]
def run(cmd,cwd,log):
 started=time.monotonic()
 with log.open('w') as f: result=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 row={'command':cmd,'cwd':str(cwd),'exit':result.returncode,'seconds':time.monotonic()-started,'log':str(log)};rows.append(row);(o/'EXTRA_RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 return result.returncode
assert run(['cmake','--build',str(b),'--target','judas_fluid_root_admission_diagnostics','-j2'],r,o/'root-exact-build.log')==0
assert run([str(b/'judas_fluid_root_admission_diagnostics')],r,o/'root-exact-tolerances.log')==1
assert run([str(b/'judas_production_fluid_tests'),'--case','half_025','--legacy-four-second','--output',str(o/'legacy-four-second')],r,o/'legacy-four-second.log')==1
make={}
for line in (b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/flags.make').read_text().splitlines():
 if ' = ' in line:
  k,v=line.split(' = ',1);make[k]=shlex.split(v)
obj=o/'known-owned-final.o';src=p/'prepared-reuse/owned-controls/KnownGeometryOwned.cpp'
assert run(['/usr/bin/c++']+make['CXX_DEFINES']+make['CXX_INCLUDES']+make['CXX_FLAGS']+['-c',str(src),'-o',str(obj)],r,o/'known-owned-compile.log')==0
cmd=shlex.split((b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/link.txt').read_text());cmd=[c for c in cmd if not c.startswith('-Wl,--dependency-file=')];cmd=[str(obj) if c.endswith('/tests/FluidKnownGeometryTests.cpp.o') else c for c in cmd];cmd[cmd.index('-o')+1]=str(o/'known-owned-final')
assert run(cmd,b,o/'known-owned-link.log')==0
assert run([str(o/'known-owned-final'),'--output',str(o/'known-owned.csv')],r,o/'known-owned.log')==1
assert run(['python3','-m','unittest','discover','-s','tests','-p','test_validation_registration.py'],r,o/'registration.log')==0
