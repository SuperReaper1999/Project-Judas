from pathlib import Path
import subprocess,shlex,json,hashlib
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/bounded-halo';o.mkdir(exist_ok=True);b=r/'.cache/2d-stage1-build';src=(r/'src/FluidHydrostatics.cpp').read_text()
old='''        // Connected sampling volumes preserve resolved root-column air gaps.
        // Legacy column means and displaced-solid reconstruction retain the halo.
        if(layers.size()>1 && (!connectedWetSupport || solid)) {'''
assert src.count(old)==1
oldHalo=src.replace(old,'        if(layers.size()>1) {')
needle='''        if(layers.size()>1) {
            // Fill internal sampling disorder'''
new='''        std::vector<HeightSpan> repairableGaps;
        if(connectedWetSupport && !solid) {
            for(std::size_t i=1;i<layers.size();++i) {
                const double lo=layers[i-1].second,hi=layers[i].first;
                if(hi-lo<=2*columnWidth+rounding)repairableGaps.emplace_back(lo,hi);
            }
        }
        if(layers.size()>1) {
            // Fill internal sampling disorder'''
bounded=oldHalo.replace(needle,new)
target='''                    if(lo<hi)layers.emplace_back(lo,hi);'''
newTarget='''                    if(lo<hi) {
                        if(connectedWetSupport && !solid) {
                            for(const auto& gap:repairableGaps) {
                                const double a=std::max(lo,gap.first),z=std::min(hi,gap.second);
                                if(a<z)layers.emplace_back(a,z);
                            }
                        } else layers.emplace_back(lo,hi);
                    }'''
assert bounded.count(target)==1;bounded=bounded.replace(target,newTarget)
def flags(target):
 data={}
 for line in (b/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);data[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((data[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def link(driver,obj,module,output):
 c=[a for a in shlex.split((b/f'CMakeFiles/{driver}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=') and not a.endswith('.cpp.o')]
 c.insert(c.index('-o'),str(obj));c[c.index('-o')+1]=str(output);c.insert(c.index('libjudas_engine.a'),str(module));subprocess.run(c,cwd=b,check=True);return c
commands=[]
c=flags('judas_engine')+['-c',str(r/'.cache/fluid-support-continuation-20261102/PlayerWarmupProbe.cpp'),'-o',str(o/'probe.o')];subprocess.run(c,check=True);commands.append(c)
for name,source in [('ban',src),('old_halo',oldHalo),('bounded',bounded)]:
 (o/(name+'.cpp')).write_text(source)
 # A separate instrumented object only observes the pre-halo root gaps.
 trace=source.replace('#include <algorithm>','#include <algorithm>\n#include <fstream>\n#include <iomanip>\n#include <cstdlib>')
 trace=trace.replace('''    const auto prepareLayers=[&](ColumnProfile& profile) {''','''    static std::uint64_t queryNumber=0;
    const auto queryIndex=queryNumber++;
    const auto prepareLayers=[&](ColumnProfile& profile) {''')
 before='''        FluidHydrostaticDetail::CloseColumnLayers(layers,columnWidth,rounding);'''
 observe='''
        if(const char* path=std::getenv("JUDAS_GAP_TRACE")) {
            const auto rootX=static_cast<std::int64_t>(std::floor(-originX/columnWidth+.5));
            const auto rootZ=static_cast<std::int64_t>(std::floor(-originZ/columnWidth+.5));
            if(profile.x==rootX && profile.z==rootZ) {
                static std::ofstream log(path);
                log<<std::setprecision(17);
                for(std::size_t i=1;i<layers.size();++i)
                    if(layers[i-1].second<halfHeight && layers[i].first> -halfHeight)
                        log<<queryIndex<<','<<point.x<<','<<point.y<<','<<point.z<<','<<halfHeight<<','<<columnWidth<<','<<layers[i-1].second<<','<<layers[i].first<<','<<(layers[i].first-layers[i-1].second)/columnWidth<<'\\n';
            }
        }
'''
 assert trace.count(before)==2;trace=trace.replace(before,before+observe,1)
 (o/(name+'-trace.cpp')).write_text(trace)
 c=flags('judas_engine')+['-c',str(o/(name+'-trace.cpp')),'-o',str(o/(name+'-trace.o'))];subprocess.run(c,check=True);commands.append(c)
 commands.append(link('judas_fluid_known_geometry_tests',o/'probe.o',o/(name+'-trace.o'),o/(name+'-probe')))
 for spacing in ['20','25']:
  env=dict(__import__('os').environ);env['JUDAS_GAP_TRACE']=str(o/f'{name}-{spacing}-gaps.csv')
  with (o/f'{name}-{spacing}-samples.csv').open('w') as output,(o/f'{name}-{spacing}-summary.log').open('w') as log:
   subprocess.run([str(o/(name+'-probe')),str(r/f'.cache/fluid-support-continuation-20261102/final/player/density-{spacing}-1000-warmup-particles.csv')],stdout=output,stderr=log,env=env,check=True)
 print(name,'finished',flush=True)
(o/'BUILD.json').write_text(json.dumps({'sourceHashes':{name:hashlib.sha256((o/(name+'.cpp')).read_bytes()).hexdigest() for name in ['ban','old_halo','bounded']},'commands':commands},indent=2)+'\n')
