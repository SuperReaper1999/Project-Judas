from pathlib import Path
import shlex, subprocess, json, hashlib, datetime
root=Path.cwd(); out=root/'.cache/fluid-support-continuation-20261102'; build=root/'.cache/2d-stage1-build'
s=(root/'src/ProductionFluidCoupling.cpp').read_text().replace('#include <stdexcept>', '#include <stdexcept>\n#include <fstream>\n#include <iomanip>\n#include <cstdlib>')
needle='''        auto& diagnostic=s.measured.bodies[i];diagnostic.fraction=hydro.fraction;'''
insert=r'''        if(const char* path=std::getenv("JUDAS_FLUID_CONTINUITY_TRACE")) {
            static std::ofstream trace(path);
            static std::uint64_t row=0;
            if(row==0)trace<<"row,body,pending,py,qw,qx,qy,qz,fraction,minus_fraction,plus_fraction,minus_distance,plus_distance,bfy,field_revision\n"<<std::setprecision(17);
            const auto g=world.Gravity().Sample(pose.position);
            const auto up=glm::dot(g,g)>0 ? -glm::normalize(g) : glm::vec3(0,1,0);
            auto minus=pose,plus=pose;minus.position-=up*1e-4f;plus.position+=up*1e-4f;
            const auto low=EvaluateFluidHydrostatics(*field,body.volume,minus,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle);
            const auto high=EvaluateFluidHydrostatics(*field,body.volume,plus,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle);
            trace<<row++<<','<<body.handle.id<<','<<s.pending<<','<<pose.position.y<<','<<pose.rotation.w<<','<<pose.rotation.x<<','<<pose.rotation.y<<','<<pose.rotation.z
                 <<','<<hydro.fraction<<','<<low.fraction<<','<<high.fraction<<','<<glm::distance(glm::dvec3(minus.position),glm::dvec3(pose.position))
                 <<','<<glm::distance(glm::dvec3(plus.position),glm::dvec3(pose.position))<<','<<hydro.buoyancyForce.y<<','<<s.fieldRevision<<'\n';
        }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
source=out/'ContinuityCoupling.cpp';source.write_text(s)
flags={}
for line in (build/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
compile=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-c',str(source),'-o',str(out/'continuity.o')]
link=shlex.split((build/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());link=[a for a in link if not a.startswith('-Wl,--dependency-file=')];link[link.index('-o')+1]=str(out/'continuity');link.insert(link.index('libjudas_engine.a'),str(out/'continuity.o'))
(out/'BUILD.json').write_text(json.dumps({'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'compile':compile,'link':link,'linkWorkingDirectory':str(build),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
subprocess.run(compile,check=True);subprocess.run(link,cwd=build,check=True)
