Query-local wet-column topology prototype, 2 November 2026

Disposable baseline/prepared full FluidHydrostatics.cpp overrides. NO tracked
source change, CMake change or timing trial was made by this subtask.

SOURCES.json pins the current raw-contact-height candidate at task start:
- FluidHydrostatics.cpp SHA256
  78b7f59b1fa4ba2ed746b24e879f3288b0fb044818a11a05f9ee61b1ecc407d4
- FluidWetFootprint.h SHA256
  8a282bc2d82f06d6ad2e84bc6c3fe1ca327a1b61cea46ebf895936ea7f48bf68

Proposed behavior:
- FluidWetColumnTopology computes the original sorted-key DSU once. Connectivity
  still includes DRY keys. Neighbor order, union root selection, patch order,
  corner insertion order and hull operations are retained.
- Each ContainsOrigin call checks that size and ordered x/z keys match, then
  classifies the incoming wet states and builds the original hull per component.
  Centres and width remain live inputs. No wet-state or centre result is cached.
- The original free function remains as a one-use constructing wrapper.
- FluidHydrostaticField::Query owns an optional topology, constructed lazily
  at the first measureBand. Repeated bands reuse the same component roots.
- State is query-local; no save, lifecycle, public API or numerical model change.

Parity evidence, QUALIFICATION.json:
- TopologyParity.cpp: 16,387 comparisons with the original implementation,
  zero differences; 762 changed-size/key/order misuse cases rejected. Random
  incoming centres and wet states, varying widths, empty fields, disconnected
  reservoirs and the existing dry-key connectivity behavior are exercised.
- Frozen replay: nine production-input queries with eight FluidFieldSample
  floats serialized as uint32 bits. Entire baseline/prepared CSV byte-identical.
- Hydrostatics: 346 checks, zero failures in both variants. All output except
  the summary's non-acceptance wall-time field is exactly equal.
- Wet support: 142 checks, zero failures; output exactly equal.
- Vertical support: 335 checks, zero failures; output exactly equal.
- Original known geometry: 360-case CSV byte-identical. BOTH CURRENT raw-height
  variants report 48 engine / 80 observer failures, zero frame failures, exit 1.
  This preserves the task-start source, not the older checkpoint's 36 engine
  failures. It is not a passing known-geometry qualification.

BUILD.json: 19 standalone compile/link commands, all exit zero; build.log empty.
Compile and non-timing gate jobs are complete. No timing conclusion is inferred
from validation wall times. Parent agent owns performance/integration decisions.

Useful binaries:
  wet-topology/baseline/frozen
  wet-topology/prepared/frozen
  wet-topology/{baseline,prepared}/{hydrostatics,wet-support,vertical-support,known-geometry}

Run frozen parity from the repository root:
  .cache/fluid-support-continuation-20261102/wet-topology/prepared/frozen \
    .cache/fluid-support-continuation-20261102/frozen.json

The existing replay's opt-in JUDAS_BENCH_LOOPS mode is preserved for parent-run
timing after all competing builds/tests are idle. This subtask did not enable it.
prototype.patch contains only the proposed header/Hydro source changes.
