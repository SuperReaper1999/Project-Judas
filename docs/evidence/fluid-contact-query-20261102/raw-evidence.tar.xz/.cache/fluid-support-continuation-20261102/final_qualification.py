from pathlib import Path
import subprocess,time,json,hashlib,datetime
r=Path.cwd();p=r/'.cache/fluid-support-continuation-20261102';o=p/'final';o.mkdir(exist_ok=True);b=r/'.cache/2d-stage1-build'
for f,sha in json.loads((p/'FINAL_RUNTIME_SOURCES.json').read_text())['files'].items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==sha,f
commands=[[str(b/t)]for t in ['judas_fluid_world_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests','judas_fluid_vertical_support_tests','judas_fluid_volume_drag_tests','judas_fluid_lifecycle_qualification_tests','judas_project_fluid_policy_tests','judas_project_water_tests','judas_fluid_boundary_contact_tests','judas_fluid_cavity_impact_tests','judas_fluid_rigid_coupling_tests']]
commands += [[str(b/'judas_fluid_container_integration_tests'),'--supported-only','--output',str(o/'containers')],[str(b/'judas_production_fluid_tests'),'--output',str(o/'production')],[str(b/'judas_fluid_known_geometry_tests'),'--output',str(o/'known.csv')],[str(b/'judas_fluid_demo_integration_tests'),'--output',str(o/'demos')],[str(b/'judas_player_fluid_integration_tests'),'--output',str(o/'player')]]
rows=[]
for cmd in commands:
 log=o/(Path(cmd[0]).name+'.log');start=time.monotonic()
 with log.open('w')as f:p1=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 row={'command':cmd,'cwd':str(r),'exit':p1.returncode,'seconds':time.monotonic()-start,'log':str(log),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};rows.append(row);(o/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
