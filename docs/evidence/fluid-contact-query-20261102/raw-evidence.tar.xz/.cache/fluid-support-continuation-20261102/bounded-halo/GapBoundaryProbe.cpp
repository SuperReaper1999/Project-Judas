#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
int main(){
 constexpr float width=.0625f;int checks=0,failures=0,frameIndex=0;
 const auto turn=glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3)));
 for(const auto rotation:{glm::quat(1,0,0,0),turn}){
  const glm::vec3 shift=frameIndex?glm::vec3(2,-1,3):glm::vec3(0);
  const auto p=[&](glm::vec3 v){return shift+rotation*v;};
  for(float center:{.046875f,.09f,.09375f,.1f,.125f})for(float half:{0.f,.01f}){
   std::vector<FluidParticle> cloud;for(const auto local:{glm::vec3(0,-center,0),glm::vec3(0,center,0),glm::vec3(width,0,0)}){auto pos=p(local);cloud.push_back({pos,pos,{},1000*width*width*width,{}});}
   FluidHydrostaticField field;field.Build(cloud,1000);auto fraction=field.Query(p({0,0,0}),rotation*glm::vec3(0,1,0),half,.2f,rotation*glm::vec3(1,0,0),nullptr,true).fraction;
   const float expected=center<=.09375f?1:0;++checks;if(fraction!=expected)++failures;
   std::cout<<std::setprecision(17)<<"frame="<<frameIndex<<" gap_ratio="<<(2*center-width)/width<<" half="<<half<<" fraction="<<fraction<<" expected="<<expected<<'\n';
  }
  std::vector<FluidParticle> mixed;
  for(const auto local:{glm::vec3(0,-.25f,0),glm::vec3(0,-.09375f,0),glm::vec3(0,.09375f,0),glm::vec3(0,.5f,0),glm::vec3(width,-.17f,0),glm::vec3(width,0,0),glm::vec3(width,.3f,0)}){auto pos=p(local);mixed.push_back({pos,pos,{},1000*width*width*width,{}});}
  FluidHydrostaticField field;field.Build(mixed,1000);const auto fraction=field.Query(p({0,.3f,0}),rotation*glm::vec3(0,1,0),.01f,.2f,rotation*glm::vec3(1,0,0),nullptr,true).fraction;++checks;if(fraction!=0)++failures;std::cout<<"frame="<<frameIndex<<" mixed_protected_gap="<<fraction<<" expected=0\n";
  ++frameIndex;
 }
 std::cout<<"checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
