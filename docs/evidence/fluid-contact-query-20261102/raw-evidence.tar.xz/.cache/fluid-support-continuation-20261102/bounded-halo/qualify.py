from pathlib import Path
import subprocess,json,shlex,time
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/bounded-halo';b=r/'.cache/2d-stage1-build';commands=[];results={}
def run(c,cwd=None):commands.append({'cmd':c,'cwd':str(cwd or r)});subprocess.run(c,cwd=cwd,check=True)
def flags(target):
 d={}
 for line in (b/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((d[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def link(target,obj,output,validation=False):
 c=[a for a in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=') and (not a.endswith('.cpp.o') or validation and a.endswith('/ValidationMain.cpp.o'))]
 c.insert(c.index('-o'),str(obj));c[c.index('-o')+1]=str(output);c.insert(c.index('libjudas_engine.a'),str(o/'bounded.o'));run(c,b)
def execute(name,c):
 start=time.monotonic()
 with (o/(name+'.log')).open('w') as log:p=subprocess.run(c,cwd=r,stdout=log,stderr=subprocess.STDOUT)
 results[name]={'command':c,'exit':p.returncode,'elapsed':time.monotonic()-start};(o/'QUALIFICATION.json').write_text(json.dumps({'build':commands,'results':results},indent=2)+'\n');print(name,p.returncode,flush=True)
run(flags('judas_engine')+['-c',str(o/'bounded.cpp'),'-o',str(o/'bounded.o')])
target='judas_player_fluid_integration_tests';link(target,b/f'CMakeFiles/{target}.dir/tests/PlayerFluidIntegrationTests.cpp.o',o/'player')
execute('neutral25',[str(o/'player'),'--smoke','--smoke-spacing','.25','--output',str(o/'neutral25')])
execute('neutral20',[str(o/'player'),'--smoke','--smoke-spacing','.2','--output',str(o/'neutral20')])
source=(r/'tests/PlayerFluidIntegrationTests.cpp').read_text()
lines=source.splitlines();lines=[line for line in lines if not line.startswith('if(!fallOnly)for(float spacing:smoke?')]
old=next(line for line in lines if line.startswith('if(!smoke){if(!fallOnly)results.push_back'))
new='for(float spacing:{.2f,.25f})results.push_back(Run(output,"swim-through",identity,spacing,950,false,0,{0,1.5f,4},300,true));'
source='\n'.join(lines).replace(old,new)+'\n';(o/'SwimOnly.cpp').write_text(source)
run(flags(target)+['-I'+str(r/'tests'),'-c',str(o/'SwimOnly.cpp'),'-o',str(o/'swim.o')]);link(target,o/'swim.o',o/'swim')
execute('swim',[str(o/'swim'),'--output',str(o/'swim-run')])
run(flags('judas_engine')+['-c',str(o/'GapBoundaryProbe.cpp'),'-o',str(o/'gap.o')]);link('judas_fluid_known_geometry_tests',o/'gap.o',o/'gap')
execute('gaps',[str(o/'gap')])
for short,sourceName in [('hydrostatics','FluidHydrostaticsTests'),('wet_support','FluidWetSupportTests'),('vertical_support','FluidVerticalSupportTests')]:
 target=f'judas_fluid_{short}_tests';link(target,b/f'CMakeFiles/{target}.dir/tests/{sourceName}.cpp.o',o/short,True);execute(short,[str(o/short)])
