from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/bounded-halo';b=r/'.cache/2d-stage1-build'
source=(o/'bounded-trace.cpp').read_text()
needle='''    const double columnWidth=m_maxSpacing, verticalReach=reach+halfHeight;'''
capture='''
    if(const char* path=std::getenv("JUDAS_GAP_TRACE")) {
        static float lastSpacing=-1;
        if(lastSpacing!=m_maxSpacing) {
            lastSpacing=m_maxSpacing;
            std::ofstream raw(std::string(path)+".particles-"+std::to_string(m_maxSpacing)+".csv");
            raw<<std::setprecision(17)<<"id,mass,x,y,z,vx,vy,vz,ax,ay,az,spacing\\n";
            std::size_t i=0;
            for(const auto& p:m_particles)raw<<i++<<','<<p.volume*m_density<<','<<p.position.x<<','<<p.position.y<<','<<p.position.z<<','<<p.velocity.x<<','<<p.velocity.y<<','<<p.velocity.z<<','<<p.acceleration.x<<','<<p.acceleration.y<<','<<p.acceleration.z<<','<<p.spacing<<'\\n';
        }
    }
'''
assert source.count(needle)==1;source=source.replace(needle,needle+capture)
(o/'swim-trace.cpp').write_text(source)
driver=(o/'SwimOnly.cpp').read_text().replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>')
needle='''}p.Step();const auto&player'''
new='''}if(i==120)setenv("JUDAS_GAP_TRACE",(out/"swim-jump-gaps.csv").string().c_str(),1);p.Step();if(i==120)unsetenv("JUDAS_GAP_TRACE");const auto&player'''
assert driver.count(needle)==1;driver=driver.replace(needle,new)
(o/'SwimTraceDriver.cpp').write_text(driver)
def flags(target):
 d={}
 for line in (b/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((d[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
c1=flags('judas_engine')+['-c',str(o/'swim-trace.cpp'),'-o',str(o/'swim-trace.o')];subprocess.run(c1,check=True)
c2=flags('judas_player_fluid_integration_tests')+['-I'+str(r/'tests'),'-c',str(o/'SwimTraceDriver.cpp'),'-o',str(o/'swim-driver.o')];subprocess.run(c2,check=True)
link=[a for a in shlex.split((b/'CMakeFiles/judas_player_fluid_integration_tests.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=') and not a.endswith('.cpp.o')];link.insert(link.index('-o'),str(o/'swim-driver.o'));link[link.index('-o')+1]=str(o/'swim-trace');link.insert(link.index('libjudas_engine.a'),str(o/'swim-trace.o'));subprocess.run(link,cwd=b,check=True)
with (o/'swim-trace.log').open('w') as log:p=subprocess.run([str(o/'swim-trace'),'--output',str(o/'swim-trace-run')],stdout=log,stderr=subprocess.STDOUT,cwd=r)
(o/'SWIM_TRACE_BUILD.json').write_text(json.dumps({'compile':[c1,c2],'link':link,'exitCode':p.returncode},indent=2)+'\n')
