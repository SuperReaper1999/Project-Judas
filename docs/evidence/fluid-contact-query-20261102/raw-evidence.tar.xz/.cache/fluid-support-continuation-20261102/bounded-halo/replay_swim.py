from pathlib import Path
import subprocess,shlex,csv,json,os,collections,statistics
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/bounded-halo';b=r/'.cache/2d-stage1-build'
driver=(r/'.cache/fluid-support-continuation-20261102/PlayerWarmupProbe.cpp').read_text().replace('if(argc!=2)return 2;','if(argc!=2 && argc!=5)return 2;').replace('const glm::vec3 center(sum/mass),up(0,1,0);','const glm::vec3 center=argc==5?glm::vec3(std::stof(argv[2]),std::stof(argv[3]),std::stof(argv[4])):glm::vec3(sum/mass);const glm::vec3 up(0,1,0);')
(o/'SwimReplay.cpp').write_text(driver)
flags={}
for line in (b/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);flags[k]=shlex.split(v)
args=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
commands=[]
def run(c,cwd=None):commands.append({'cmd':c,'cwd':str(cwd or r)});subprocess.run(c,cwd=cwd,check=True)
run(args+['-c',str(o/'SwimReplay.cpp'),'-o',str(o/'swim-replay.o')])
for name in ['old_halo','bounded']:
 source=(o/(name+'-trace.cpp')).read_text();source=source.replace('if(profile.x==rootX && profile.z==rootZ) {','if(true) {')
 needle="<<(layers[i].first-layers[i-1].second)/columnWidth<<'\\n';"
 replacement="<<(layers[i].first-layers[i-1].second)/columnWidth<<','<<(profile.x==rootX && profile.z==rootZ)<<'\\n';"
 assert source.count(needle)==1;source=source.replace(needle,replacement)
 (o/(name+'-all.cpp')).write_text(source);run(args+['-c',str(o/(name+'-all.cpp')),'-o',str(o/(name+'-all.o'))])
 c=[a for a in shlex.split((b/'CMakeFiles/judas_fluid_known_geometry_tests.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=') and not a.endswith('.cpp.o')];c.insert(c.index('-o'),str(o/'swim-replay.o'));c[c.index('-o')+1]=str(o/(name+'-swim-replay'));c.insert(c.index('libjudas_engine.a'),str(o/(name+'-all.o')));run(c,b)
 for spacing in ['20','25']:
  previous=list(csv.DictReader((o/f'swim-trace-run/swim-through-{spacing}-950.csv').open()))[119]
  env=os.environ.copy();env['JUDAS_GAP_TRACE']=str(o/f'swim-{name}-{spacing}-all-gaps.csv')
  command=[str(o/(name+'-swim-replay')),str(o/f'swim-trace-run/swim-jump-gaps.csv.particles-0.{spacing}0000.csv')]+[previous[key] for key in ['x','y','z']]
  with (o/f'swim-{name}-{spacing}-samples.csv').open('w') as output,(o/f'swim-{name}-{spacing}-summary.log').open('w') as log:p=subprocess.run(command,stdout=output,stderr=log,env=env,check=True)
  rows=list(csv.reader((o/f'swim-{name}-{spacing}-all-gaps.csv').open()));ratios=[float(row[8]) for row in rows]
  print(name,spacing,(o/f'swim-{name}-{spacing}-summary.log').read_text().strip(),'gaps',len(rows),'min/median/max',min(ratios),statistics.median(ratios),max(ratios),'over2',sum(a>2.001 for a in ratios),flush=True)
(o/'SWIM_REPLAY_BUILD.json').write_text(json.dumps({'commands':commands},indent=2)+'\n')
