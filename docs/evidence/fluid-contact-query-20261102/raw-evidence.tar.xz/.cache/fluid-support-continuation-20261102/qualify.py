from pathlib import Path
import subprocess,json,time
r=Path.cwd();o=r/'.cache/fluid-support-continuation-20261102/combined';o.mkdir(exist_ok=True);b=r/'.cache/2d-stage1-build'
commands=[[str(b/t)] for t in ['judas_fluid_world_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests','judas_fluid_vertical_support_tests','judas_fluid_volume_drag_tests','judas_fluid_lifecycle_qualification_tests','judas_project_fluid_policy_tests','judas_project_water_tests']]
commands.append([str(b/'judas_production_fluid_tests'),'--case','half_025','--output',str(o/'half025')]);results=[]
for cmd in commands:
 name=Path(cmd[0]).name;log=o/(name+'.log');start=time.monotonic()
 with log.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=r)
 row={'command':cmd,'cwd':str(r),'exit':p.returncode,'seconds':time.monotonic()-start,'log':str(log)};results.append(row);(o/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
