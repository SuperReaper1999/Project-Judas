#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
#include <string>

struct Frame {
    glm::quat q{1,0,0,0};
    glm::vec3 t{0};
    glm::vec3 point(glm::vec3 p) const { return t+q*p; }
    glm::vec3 vector(glm::vec3 p) const { return q*p; }
};

int main() {
    std::cout << std::setprecision(17);
    const Frame frames[] = {Frame{}, Frame{glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))),{3,-2,4}}};
    const auto volume=MakeBoxFluidVolume(glm::vec3(.1f),1);
    for(int frameIndex=0;frameIndex<2;++frameIndex) {
        const auto& frame=frames[frameIndex];
        const BodyTransform pose{frame.point({0,0,0}),frame.q};
        const FluidSolidQuery solid{volume,pose};
        for(const auto label:{std::string("low_only_dry_gap"),std::string("remote_contact_witness"),std::string("local_contact_positive"),std::string("high_only_dry")}) {
            std::vector<FluidParticle> particles;
            const auto append=[&](glm::vec3 p) {
                p=frame.point(p);particles.push_back({p,p,{},15.625f,{}});
            };
            // Remote anchor sets bin centres at x=n*.25 without contributing.
            append({-2,0,0});
            if(label!="high_only_dry")append({.28f,0,0});
            if(label=="remote_contact_witness" || label=="high_only_dry")append({.22f,.55f,0});
            if(label=="local_contact_positive")append({.22f,0,0});
            FluidHydrostaticField field;field.Build(particles,1000);
            for(float half:{0.f,.025f}) {
                const auto result=field.Query(pose.position,frame.vector({0,1,0}),half,volume.boundRadius,frame.vector({1,0,0}),&solid,true);
                std::cout << "frame=" << frameIndex << " case=" << label << " half=" << half << " fraction=" << result.fraction << '\n';
            }
        }
    }
    // Analytic local coordinates, independent of the reconstructed admission:
    // low square x=[.155,.405], solid x=[-.1,.1]: .055m lateral air.
    // remote high cube y=[.425,.675], solid y=[-.1,.1]: .325m air.
    // positive local square x=[.095,.345]: .005m solid contact overlap.
    std::cout << "geometry low_lateral_gap=.055 remote_vertical_gap=.325 local_contact_overlap=.005\n";
}
