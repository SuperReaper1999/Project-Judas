from pathlib import Path
import shlex,subprocess,json,hashlib
root=Path.cwd();out=root/'.cache/fluid-support-continuation-20261102/vertical-witness';build=root/'.cache/2d-stage1-build'
source=(root/'src/FluidHydrostatics.cpp').read_text()
needle='''        if(solid) {
            // A connected support component can end inside a water band.'''
replacement='''        if(solid && connectedWetSupport) {
            // Actual particle footprints may change water/solid contact inside
            // a profile whose closed layers hide the raw particle endpoints.
            const double localRounding=8*std::numeric_limits<float>::epsilon()*
                (1+glm::length(glm::dvec3(point))+glm::length(glm::dvec3(solid->pose.position))+
                 solid->volume.boundRadius);
            for(const auto& column:columns)for(const double end:{column.interval.lo,column.interval.hi}) {
                if(end<=-halfHeight || end>=halfHeight)continue;
                const auto same=[&](double cut){return std::abs(cut-end)<=localRounding;};
                if(std::none_of(cuts.begin(),cuts.end(),same))cuts.push_back(end);
            }
        }
        if(solid) {
            // A connected support component can end inside a water band.'''
assert source.count(needle)==1
source=source.replace(needle,replacement)
(out/'FluidHydrostaticsRawEvents.cpp').write_text(source)
spec=json.loads((out/'BUILD.json').read_text())
compile=spec['compile'];compile[compile.index('-c')+1]=str(out/'FluidHydrostaticsRawEvents.cpp');compile[compile.index('-o')+1]=str(out/'raw-events.o')
subprocess.run(compile,check=True)
results={}
for short in ['wet_support','hydrostatics','vertical_support']:
    target=f'judas_fluid_{short}_tests'
    link=shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text())
    link=[a for a in link if not a.startswith('-Wl,--dependency-file=')]
    link[link.index('-o')+1]=str(out/('raw-events-'+target))
    if short=='wet_support':link=[str(out/'wet-support-tests.o') if a.endswith('/tests/FluidWetSupportTests.cpp.o') else a for a in link]
    link.insert(link.index('libjudas_engine.a'),str(out/'raw-events.o'))
    subprocess.run(link,cwd=build,check=True)
    with (out/('raw-events-'+short+'.log')).open('w') as log:
        p=subprocess.run([str(out/('raw-events-'+target))],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    results[short]={'exitCode':p.returncode,'link':link}
    print(short,p.returncode,flush=True)
for name in ['probe','raw-endpoint-probe']:
    link=spec['link'].copy()
    link=[str(out/(name+'.o')) if a.endswith('/probe.o') else a for a in link]
    link[link.index('-o')+1]=str(out/('raw-events-'+name))
    link.insert(link.index('libjudas_engine.a'),str(out/'raw-events.o'))
    subprocess.run(link,cwd=build,check=True)
    with (out/('raw-events-'+name+'.log')).open('w') as log:
        p=subprocess.run([str(out/('raw-events-'+name))],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    results[name]={'exitCode':p.returncode,'link':link}
(out/'RAW_EVENTS_QUALIFICATION.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(source.encode()).hexdigest(),'compile':compile,'results':results},indent=2)+'\n')
