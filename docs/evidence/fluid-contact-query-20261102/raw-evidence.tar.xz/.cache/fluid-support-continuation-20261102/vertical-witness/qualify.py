from pathlib import Path
import shlex,subprocess,json,hashlib
root=Path.cwd();out=root/'.cache/fluid-support-continuation-20261102/vertical-witness';build=root/'.cache/2d-stage1-build'
assert (root/'src/FluidHydrostatics.cpp').read_bytes()==(out/'FluidHydrostatics.cpp').read_bytes()
target='judas_fluid_wet_support_tests'
flags={}
for line in (build/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
    if line.startswith('CXX_') and ' = ' in line:
        k,v=line.split(' = ',1);flags[k]=shlex.split(v)
compile=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-c',str(root/'tests/FluidWetSupportTests.cpp'),'-o',str(out/'wet-support-tests.o')]
subprocess.run(compile,check=True)
results={}
for short in ['wet_support','hydrostatics','vertical_support']:
    target=f'judas_fluid_{short}_tests'
    link=shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text())
    link=[a for a in link if not a.startswith('-Wl,--dependency-file=')]
    link[link.index('-o')+1]=str(out/target)
    if short=='wet_support':
        link=[str(out/'wet-support-tests.o') if a.endswith('/tests/FluidWetSupportTests.cpp.o') else a for a in link]
    link.insert(link.index('libjudas_engine.a'),str(out/'candidate.o'))
    subprocess.run(link,cwd=build,check=True)
    with (out/(short+'.log')).open('w') as log:
        p=subprocess.run([str(out/target)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    results[short]={'exitCode':p.returncode,'link':link}
    print(short,p.returncode,flush=True)
(out/'QUALIFICATION.json').write_text(json.dumps({'hydrostaticsSHA256':hashlib.sha256((root/'src/FluidHydrostatics.cpp').read_bytes()).hexdigest(),'wetTestsSHA256':hashlib.sha256((root/'tests/FluidWetSupportTests.cpp').read_bytes()).hexdigest(),'compile':compile,'results':results},indent=2)+'\n')
