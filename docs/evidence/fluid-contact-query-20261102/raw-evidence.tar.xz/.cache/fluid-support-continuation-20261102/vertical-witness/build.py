from pathlib import Path
import shlex,subprocess,json,hashlib
root=Path.cwd()
out=root/'.cache/fluid-support-continuation-20261102/vertical-witness'
build=root/'.cache/2d-stage1-build'
flags={}
for line in (build/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
    if line.startswith('CXX_') and ' = ' in line:
        k,v=line.split(' = ',1);flags[k]=shlex.split(v)
compile=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-c',str(out/'probe.cpp'),'-o',str(out/'probe.o')]
link=shlex.split((build/'CMakeFiles/judas_fluid_hydrostatics_tests.dir/link.txt').read_text())
link=[a for a in link if not a.startswith('-Wl,--dependency-file=') and not a.endswith('.cpp.o')]
link[link.index('-o')+1]=str(out/'baseline')
link.insert(link.index('-o'),str(out/'probe.o'))
(out/'BUILD.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceSHA256':hashlib.sha256((out/'probe.cpp').read_bytes()).hexdigest(),'compile':compile,'link':link,'cwd':str(build)},indent=2)+'\n')
subprocess.run(compile,check=True)
subprocess.run(link,cwd=build,check=True)
source=(root/'src/FluidHydrostatics.cpp').read_text()
needle='''            const auto wetContact=[&](std::int64_t x,std::int64_t z) {
                if(!geometry)return false;
                const auto key=std::make_pair(x,z);
                auto it=std::lower_bound(columns.begin(),columns.end(),key,
                    [](const auto& c,const auto& k){return c.x<k.first||(c.x==k.first&&c.z<k.second);});
                for(;it!=columns.end()&&it->x==x&&it->z==z;++it) {
'''
assert source.count(needle)==1
source=source.replace(needle,needle+'                    if(layered && (it->interval.lo>middle || it->interval.hi<middle))continue;\n')
(out/'FluidHydrostatics.cpp').write_text(source)
compileCandidate=compile[:-4]+['-c',str(out/'FluidHydrostatics.cpp'),'-o',str(out/'candidate.o')]
linkCandidate=link.copy()
linkCandidate[linkCandidate.index('-o')+1]=str(out/'candidate')
linkCandidate.insert(linkCandidate.index('libjudas_engine.a'),str(out/'candidate.o'))
subprocess.run(compileCandidate,check=True)
subprocess.run(linkCandidate,cwd=build,check=True)
(out/'CANDIDATE_BUILD.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(source.encode()).hexdigest(),'compile':compileCandidate,'link':linkCandidate},indent=2)+'\n')
