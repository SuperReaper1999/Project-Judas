#include "FluidHydrostatics.h"
#include <iostream>
#include <iomanip>
int main() {
    std::vector<FluidParticle> particles;
    const auto append=[&](glm::vec3 p){particles.push_back({p,p,{},15.625f,{}});};
    append({-2,0,0});
    append({.28f,-.1f,0});
    append({.22f,.2f,0});
    const auto volume=MakeBoxFluidVolume(glm::vec3(.1f),1);
    const BodyTransform pose;
    const FluidSolidQuery solid{volume,pose};
    FluidHydrostaticField field;field.Build(particles,1000);
    const float half=.1f;
    const auto query=[&](float y,float h){return field.Query({0,y,0},{0,1,0},h,volume.boundRadius,{1,0,0},&solid,true).fraction;};
    double integrated=0;
    constexpr int count=4096;
    for(int i=0;i<count;++i)integrated+=query(-half+float(i+.5f)*2*half/count,0);
    integrated/=count;
    std::cout<<std::setprecision(17)<<"finite="<<query(0,half)<<" zeroheight_mean="<<integrated<<" analytic_contact_height_fraction=.125\n";
}
