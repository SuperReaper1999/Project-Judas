Evidence inventory for this continuation (review snapshot, NOT final qualification)

Base Experimental checkpoint: d71af6e007b5c39a822f0f563f4dd108040cea4b.
All relative paths resolve below .cache/fluid-support-continuation-20261102/.
EVIDENCE_INVENTORY.json records exact run commands, compiler/link command-manifest
pointers, source/evidence hashes, counts and limits. Existing evidence is untouched.

Sphere centre — SCOPED CORRECTION QUALIFIED
- 36-case original probe: eight exceptions; corrected probe: zero.
- Final FluidWorld driver 355 checks / 0 failures; lifecycle 38 / 0.
- Same new unit driver against original library: 46 assertion failures.
- Two authored frames create 27 actual particles with exact centre particle13;
  old runtime throws, correction executes with exact mass52.734375kg and zero KE.
- Commands/hashes: initialization/FINAL_BUILD.json; raw results and interpretation
  in initialization/{results.json,runtime-*-results.json,CANDIDATE_README.txt}.
- Exact centre local+X is an explicit initial-overlap policy; no global energy,
  exception atomicity, human or platform qualification is inferred.

Remote vertical wet witness — SCOPED MECHANISM; ROOT CONTRACT UNRESOLVED
- .055m lateral dry gap plus .325m vertically remote witness falsely gives1;
  active-height guard gives0 and keeps the .005m local contact positive.
- Guard-only loses a real finite sliver (0 vs analytic.125); raw endpoints recover
  .12499999255. Identity/rotated and point/finite-height controls are preserved.
- Wet142 / hydro346 / vertical335 checks pass at this scoped stage. Raw metadata-
  free known geometry remains FAILED:48 engine/80 observer failures, zero frame
  failures. The 12 added failures are finest fully immersed displaced cases;
  supplied pre-cut ownership gives0 engine/360 while observer80 still fail.
- Exact commands and logs: vertical-witness/{QUALIFICATION.json,
  RAW_EVENTS_QUALIFICATION.json,INTEGRATED_WET_BUILD.json,baseline.log,candidate.log,
  raw-endpoint.log,raw-events-raw-endpoint-probe.log}.

Topology cache — PARITY QUALIFIED; MEASURED COMPONENT OPTIMIZATION
- 16,387 comparisons match;762 invalid reuse cases reject. Nine frozen queries
  match all eight float fields bitwise;360 known rows byte-identical.
- Profile1000 queries: total.211257s;42,000 footprint calls; topology85.066495ms,
  hull25.680428ms, route32.859026ms. Instrumented diagnostic includes timer overhead.
- Seven alternating3000-query pairs: median batch mean196.136us→117.407us/query.
  Exact720-row coupled trace: executed median42.111394→31.480666ms (22 physical
  columns exact). These scoped observations are not general frame-rate claims.
- Commands/raw data: wet-topology/{BUILD.json,QUALIFICATION.json,TIMING_RAW.json,
  TIMINGS.json}; COUPLED_PARITY_AND_TIMING.json; profile/{cost.json,phase.json}.

Prepared-solid reuse — REJECTED PERFORMANCE EXPERIMENT, NOT A CORRECTNESS FAILURE
- 8,505,000 kernel checks/0 differences; gates and two frozen fixture sets match.
- Paired frozen medians195.548us vs194.892us (~.3% delta/noise). Root rejected
  extra preparation/coupling complexity without demonstrated material benefit.
- Exact commands/parity: prepared-reuse/{BUILD*.json,VERIFICATION.json,TIMINGS.json,
  timing-report.json,kernel-parity.log,verify.py,time_pair.py}.

STOP: global halo ban is REJECTED (four ORIGINAL player acceptance regressions).
The directory named final/ and final/RESULTS.json hold that rejected snapshot,
not final qualified evidence. See rejected-global-halo-ban/STATUS.txt and
final/judas_player_fluid_integration_tests.log (5661 checks,4 mandatory failures).
Root stopped halo experiments and restored the legacy non-solid halo policy.
Actual-root/halo alternatives remain UNRESOLVED/rejected, not discarded:
- Nominal-root+halo selected native passes do not fix nominal-bin false admission
  or the missing-bin actual-water positive, so that variant is rejected.
- Strong actual-only union passes12 footprint controls but has2 hydro roundoff/
  covariance-sensitive failures and neutral.25 drift -.30277m fails.
- Sources: bounded-halo/{actual-only.cpp,actual-root.cpp,ActualRootControls.cpp};
  build/output: ACTUAL_ONLY_BUILD.json,actual-controls.log,actual-only-hydro.log,
  actual-only-neutral25.log in the same directory.
- New22 original root expectations remain separately callable without edits in
  retained-root-diagnostic/RootAdmissionDiagnostic.cpp; see its STATUS.txt and
  rejected-global-halo-ban/source/tests/FluidFiniteBoundaryChecks.h.
Root final-source rebuilding is in progress; no final-source pass is claimed here.

Advanced Fluids stay locked; main/human acceptance/platform expansion are not
claimed. Active PBF persistence/suspension/live-origin limitations remain.
Inventory creation ran no builds, tests, benchmarks or commits.
