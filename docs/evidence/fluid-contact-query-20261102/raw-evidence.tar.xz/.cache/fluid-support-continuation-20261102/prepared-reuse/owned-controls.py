from pathlib import Path
import subprocess,shlex,json,hashlib
r=Path.cwd();out=r/'.cache/fluid-support-continuation-20261102/prepared-reuse';build=r/'.cache/2d-stage1-build';dest=out/'owned-controls';dest.mkdir(exist_ok=True)
commands=[]
def run(c,cwd=None):
 commands.append({'cmd':c,'cwd':str(cwd or r)});subprocess.run(c,cwd=cwd,check=True)
def flags(target):
 d={}
 for line in (build/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++','-I'+str(out/'reuse'),'-I'+str(r/'tests')]+sum((d[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def link(target,source,obj,binary):
 c=[a for a in shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=')]
 c=[str(obj) if a.endswith('/tests/'+source+'.cpp.o') else a for a in c];c[c.index('-o')+1]=str(binary)
 k=c.index('libjudas_engine.a');c[k:k]=[str(out/'reuse'/name) for name in ['FluidHydrostatics.o','FluidBoundaryOwnership.o']]
 run(c,build)
source=(r/'tests/FluidKnownGeometryTests.cpp').read_text()
needle='''    const auto hydro = EvaluateFluidHydrostatics(field,MakeBoxFluidVolume(half),pose,gravity,
        displaced ? FluidVolumeGeometry::DisplacedSolid : FluidVolumeGeometry::NonDisplacingVolume);'''
replacement='''    const auto volume = MakeBoxFluidVolume(half);
    const BodyHandle owner{37,901};
    if (displaced) {
        const auto originalSource = MakeParticles(definition,spacing,false,localCenter,half,frame);
        field.RetainDisplacedBoundary(owner,volume,pose,originalSource);
    }
    const auto hydro = EvaluateFluidHydrostatics(field,volume,pose,gravity,
        displaced ? FluidVolumeGeometry::DisplacedSolid : FluidVolumeGeometry::NonDisplacingVolume,
        displaced ? owner : BodyHandle{});'''
assert source.count(needle)==1
source=source.replace(needle,replacement);(dest/'KnownGeometryOwned.cpp').write_text(source)
run(flags('judas_fluid_known_geometry_tests')+['-c',str(dest/'KnownGeometryOwned.cpp'),'-o',str(dest/'KnownGeometryOwned.o')])
link('judas_fluid_known_geometry_tests','FluidKnownGeometryTests',dest/'KnownGeometryOwned.o',dest/'known-owned')
run(flags('judas_fluid_hydrostatics_tests')+['-c',str(r/'tests/FluidHydrostaticsTests.cpp'),'-o',str(dest/'HydroUpdated.o')])
link('judas_fluid_hydrostatics_tests','FluidHydrostaticsTests',dest/'HydroUpdated.o',dest/'hydro-updated')
with (dest/'hydro-updated.log').open('w') as log:p=subprocess.run([str(dest/'hydro-updated')],stdout=log,stderr=subprocess.STDOUT,cwd=r)
hydroCode=p.returncode;print('updated hydro exit',hydroCode,flush=True)
with (dest/'known-owned.log').open('w') as log:p=subprocess.run([str(dest/'known-owned'),'--output',str(dest/'known-owned.csv')],stdout=log,stderr=subprocess.STDOUT,cwd=r)
print('owned known exit',p.returncode,flush=True)
(dest/'BUILD.json').write_text(json.dumps({'knownSourceSHA256':hashlib.sha256(source.encode()).hexdigest(),'finiteControlsSHA256':hashlib.sha256((r/'tests/FluidFiniteBoundaryChecks.h').read_bytes()).hexdigest(),'commands':commands,'hydroExit':hydroCode,'knownExit':p.returncode},indent=2)+'\n')
