from pathlib import Path
import subprocess,shlex,json,hashlib,re,sys
r=Path.cwd();out=r/'.cache/fluid-support-continuation-20261102/prepared-reuse';build=r/'.cache/2d-stage1-build'
commands=[]
def run(c,cwd=None):
    commands.append({'cmd':c,'cwd':str(cwd or r)});subprocess.run(c,cwd=cwd,check=True)
def flags(target):
    data={}
    for line in (build/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
        if line.startswith('CXX_') and ' = ' in line:
            k,v=line.split(' = ',1);data[k]=shlex.split(v)
    return ['/usr/bin/c++']+sum((data[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def original_link(target):
    return [a for a in shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=')]
header=(r/'src/FluidSolidSupport.h').read_text();hydro=(r/'src/FluidHydrostatics.cpp').read_text();boundary=(r/'src/FluidBoundaryOwnership.cpp').read_text()
newHeader=header.replace('    std::vector<std::size_t> m_supportBoxes;','    std::vector<std::size_t> m_supportBoxes;\n    std::vector<bool> m_selected;')
reach='''            for (int k = 0; k < 15; ++k) {
                double reach = 0;
                const glm::dvec3 bodyHalf(box.halfExtents);
                for (int i = 0; i < 3; ++i) {
                    reach += m_half[i] * std::abs(glm::dot(m_axes[i], prepared.axes[k])) +
                             bodyHalf[i] * std::abs(glm::dot(bodyAxes[i], prepared.axes[k]));
                }
                prepared.reach[k] = reach;
            }
'''
assert newHeader.count(reach)==1
end='''            m_boxes.push_back(prepared);
        }
    }

    bool Occluded'''
newEnd='''            m_boxes.push_back(prepared);
        }
        m_supportBoxes.reserve(m_boxes.size());
        m_selected.resize(m_boxes.size(), false);
    }

    void SetHalfHeight(double halfHeight) {
        m_half.y = halfHeight;
        if (m_radius > 0) return;
        for (auto& box : m_boxes) {
            for (int k = 0; k < 15; ++k) {
                double reach = 0;
                const glm::dvec3 bodyHalf(box.half);
                for (int i = 0; i < 3; ++i) {
                    reach += m_half[i] * std::abs(glm::dot(m_axes[i], box.axes[k])) +
                             bodyHalf[i] * std::abs(glm::dot(box.bodyAxes[i], box.axes[k]));
                }
                box.reach[k] = reach;
            }
        }
    }

    bool Occluded'''
assert newHeader.count(end)==1
newHeader=newHeader.replace(end,newEnd)
newHeader=newHeader.replace('        std::vector<bool> selected(m_boxes.size(), false);','        std::fill(m_selected.begin(), m_selected.end(), false);').replace('selected[','m_selected[')
needle='''    const auto measureBand=[&](double lo,double hi,bool layered,bool reconstruction=false) {'''
assert hydro.count(needle)==1
newHydro=hydro.replace(needle,'''    std::optional<FluidHydrostaticDetail::PreparedSolidQuery> bandSolid;
    if(solid)bandSolid.emplace(tangent,up,bitangent,columnWidth,halfHeight,*solid);
'''+needle)
old='''        std::optional<FluidHydrostaticDetail::PreparedSolidQuery> bandSolid;
        if(solid && layered)bandSolid.emplace(tangent,up,bitangent,columnWidth,bandHalf,*solid);'''
assert newHydro.count(old)==1
newHydro=newHydro.replace(old,'''        if(layered && bandSolid)bandSolid->SetHalfHeight(bandHalf);''')
for variant in (['reuse'] if '--reuse-only' in sys.argv else ['baseline','reuse']):
    path=out/variant;path.mkdir(exist_ok=True)
    (path/'FluidSolidSupport.h').write_text(header if variant=='baseline' else newHeader)
    (path/'FluidHydrostatics.cpp').write_text(hydro if variant=='baseline' else newHydro)
    (path/'FluidBoundaryOwnership.cpp').write_text(boundary)
    for name in ['FluidHydrostatics','FluidBoundaryOwnership']:
        cmd=flags('judas_engine');cmd.insert(1,'-I'+str(path))
        run(cmd+['-c',str(path/(name+'.cpp')),'-o',str(path/(name+'.o'))])
    for short,source in [('hydrostatics','FluidHydrostaticsTests'),('wet_support','FluidWetSupportTests'),('vertical_support','FluidVerticalSupportTests'),('known_geometry','FluidKnownGeometryTests')]:
        target=f'judas_fluid_{short}_tests';cmd=flags(target);cmd.insert(1,'-I'+str(path))
        run(cmd+['-c',str(r/'tests'/f'{source}.cpp'),'-o',str(path/(source+'.o'))])
        link=original_link(target)
        link=[str(path/(source+'.o')) if a.endswith('/tests/'+source+'.cpp.o') else a for a in link]
        link[link.index('-o')+1]=str(path/short)
        k=link.index('libjudas_engine.a');link[k:k]=[str(path/(name+'.o')) for name in ['FluidHydrostatics','FluidBoundaryOwnership']]
        run(link,build)
    driver=(r/'.cache/fluid-support-continuation-20261102/replay/FrozenBench.cpp').read_text()
    driver=driver.replace('#include <chrono>','#include <chrono>\n#include <cstring>\n#include <cstdint>')
    driver=driver.replace('static glm::vec3 Vec', 'static std::uint32_t Bits(float f){std::uint32_t b;std::memcpy(&b,&f,sizeof(b));return b;}\nstatic glm::vec3 Vec')
    oldPrint='''   std::cout<<delta<<','<<where.y<<','<<pose.position.y<<','<<sample.fraction<<'\\n';'''
    newPrint='''   std::cout<<delta<<','<<where.y<<','<<pose.position.y<<','<<sample.fraction;
   for(float value:{sample.fraction,sample.density,sample.velocity.x,sample.velocity.y,sample.velocity.z,sample.acceleration.x,sample.acceleration.y,sample.acceleration.z})std::cout<<','<<Bits(value);
   std::cout<<'\\n';'''
    assert driver.count(oldPrint)==1
    driver=driver.replace(oldPrint,newPrint)
    (path/'FrozenReplay.cpp').write_text(driver)
    cmd=flags('judas_engine');cmd.insert(1,'-I'+str(path));cmd+=['-I'+str(r)]
    run(cmd+['-c',str(path/'FrozenReplay.cpp'),'-o',str(path/'FrozenReplay.o')])
    link=original_link('judas_fluid_known_geometry_tests')
    link=[a for a in link if not a.endswith('.cpp.o')]
    link.insert(link.index('-o'),str(path/'FrozenReplay.o'));link[link.index('-o')+1]=str(path/'frozen')
    k=link.index('libjudas_engine.a');link[k:k]=[str(path/(name+'.o')) for name in ['FluidHydrostatics','FluidBoundaryOwnership']]
    run(link,build)
(out/('BUILD_REUSE.json' if '--reuse-only' in sys.argv else 'BUILD.json')).write_text(json.dumps({'sourceHashes':{name:hashlib.sha256((r/'src'/name).read_bytes()).hexdigest() for name in ['FluidSolidSupport.h','FluidHydrostatics.cpp','FluidBoundaryOwnership.cpp']},'commands':commands},indent=2)+'\n')
