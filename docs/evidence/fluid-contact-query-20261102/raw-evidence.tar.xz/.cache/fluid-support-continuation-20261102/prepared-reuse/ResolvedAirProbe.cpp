#include "FluidHydrostatics.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <iomanip>
int main(){
    const auto volume=MakeBoxFluidVolume(glm::vec3(.3f));
    const auto turn=glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3)));
    int frameIndex=0;
    std::cout<<std::setprecision(17);
    for(const auto rotation:{glm::quat(1,0,0,0),turn}){
        const glm::vec3 shift=frameIndex?glm::vec3(2,-1,3):glm::vec3(0);
        const auto point=[&](glm::vec3 p){return shift+rotation*p;};
        std::vector<FluidParticle> material,source;
        for(int z=0;z<32;++z)for(int x=0;x<32;++x)for(int y=0;y<32;++y){
            const glm::vec3 local(-1+(x+.5f)*.0625f,-(y+.5f)*.0625f,-1+(z+.5f)*.0625f);
            const auto p=point(local);const FluidParticle particle{p,p,{},1000*.0625f*.0625f*.0625f,{}};
            source.push_back(particle);
            if(!glm::all(glm::lessThan(glm::abs(local-glm::vec3(0,-.75f,0)),glm::vec3(.3f))))material.push_back(particle);
        }
        FluidHydrostaticField dry,wet;dry.Build(material,1000);wet.Build(source,1000);
        for(float x:{.225f,.2625f,.3375f})for(float half:{0.f,.0375f})for(bool connected:{false,true}){
            const auto p=point({x,-.75f,0});const auto up=rotation*glm::vec3(0,1,0),tangent=rotation*glm::vec3(1,0,0);
            std::cout<<"frame="<<frameIndex<<" x="<<x<<" half="<<half<<" connected="<<connected
                <<" dry="<<dry.Query(p,up,half,volume.boundRadius,tangent,nullptr,connected).fraction
                <<" wet="<<wet.Query(p,up,half,volume.boundRadius,tangent,nullptr,connected).fraction<<'\n';
        }
        // Root gaps smaller/larger than the unchanged .0625 m resolution.
        for(float center:{.046875f,.125f}){
            std::vector<FluidParticle> cloud;
            for(int z=-2;z<=2;++z)for(int x=-2;x<=2;++x)for(float sign:{-1.f,1.f}){
                auto p=point({x*.0625f,sign*center,z*.0625f});cloud.push_back({p,p,{},1000*.0625f*.0625f*.0625f,{}});
            }
            FluidHydrostaticField field;field.Build(cloud,1000);
            std::cout<<"frame="<<frameIndex<<" root_gap="<<2*center-.0625f
                <<" fraction="<<field.Query(point({0,0,0}),rotation*glm::vec3(0,1,0),.01f,.2f,rotation*glm::vec3(1,0,0),nullptr,true).fraction<<'\n';
        }
        ++frameIndex;
    }
}
