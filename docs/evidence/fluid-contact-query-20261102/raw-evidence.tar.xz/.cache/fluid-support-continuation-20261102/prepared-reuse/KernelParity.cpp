#include "FluidSolidSupport.h"
#include "ReferenceSolidSupport.h"
#include <iostream>
#include <cstring>
#include <cstdint>
#include <limits>

static std::uint64_t Bits(double f){std::uint64_t b;std::memcpy(&b,&f,sizeof(b));return b;}
int main(){
    using FluidHydrostaticDetail::PreparedSolidQuery;
    using FluidHydrostaticDetail::PreparedSolidQueryReference;
    std::vector<FluidVolumeQuadrature> volumes(5);
    volumes[0].solidBoxes={{{0,0,0},{.3f,.2f,.4f}}};
    volumes[1].solidSphereRadius=.35f;
    volumes[2].solidBoxes={{{-.45f,0,0},{.2f,.2f,.2f}},{{.45f,0,0},{.2f,.2f,.2f}}};
    volumes[3].solidBoxes={{{-.2f,0,0},{.2f,.2f,.2f}},{{.2f,0,0},{.2f,.2f,.2f}}};
    CompoundBox child{{0,0,0},{.3f,.1f,.2f}};
    child.rotation=glm::angleAxis(.4f,glm::normalize(glm::vec3(1,2,3)));volumes[4].solidBoxes={child};
    const auto turn=glm::angleAxis(.73f,glm::normalize(glm::vec3(1,-2,3)));
    const BodyTransform poses[]={BodyTransform{},BodyTransform{{3,-2,4},turn},BodyTransform{{4096,0,0},turn}};
    const double heights[]={0,.2,.001,.75,.02,0,.1};
    std::uint64_t checks=0,failures=0;
    const auto check=[&](bool value){++checks;if(!value)++failures;};
    for(const auto& volume:volumes)for(const auto& pose:poses)for(bool oblique:{false,true})for(double width:{0.,.25,1.}){
        const FluidSolidQuery solid{volume,pose};
        const glm::dvec3 up=glm::normalize(glm::dvec3(pose.rotation*(oblique?glm::normalize(glm::vec3(1,3,-2)):glm::vec3(0,1,0))));
        auto tangent=glm::dvec3(pose.rotation*glm::vec3(1,0,0));tangent=glm::normalize(tangent-up*glm::dot(up,tangent));
        const auto bitangent=glm::cross(up,tangent);
        PreparedSolidQuery reusable(tangent,up,bitangent,width,.13,solid);
        for(double height:heights){
            reusable.SetHalfHeight(height);
            for(const auto local:{glm::vec3(0),glm::vec3(-.45f,0,0),glm::vec3(3),glm::vec3(.45f,0,0),glm::vec3(.3f,.2f,.4f),glm::vec3(0)}){
                const auto support=glm::dvec3(pose.position)+glm::dquat(pose.rotation)*glm::dvec3(local);
                PreparedSolidQueryReference fresh(tangent,up,bitangent,width,height,solid);
                fresh.SelectSupport(support);reusable.SelectSupport(support);
                for(int x=-2;x<=2;++x)for(int y=-2;y<=2;++y)for(int z=-2;z<=2;++z){
                    auto point=glm::dvec3(pose.position)+tangent*(x*.2)+up*(y*.2)+bitangent*(z*.2);
                    for(double nudge:{0.,std::numeric_limits<double>::epsilon(),-std::numeric_limits<double>::epsilon()}){
                        point+=up*nudge;
                        check(fresh.Occluded(point)==reusable.Occluded(point));
                        for(double halfWidth:{-1.,0.,.0625,.25})check(fresh.Touches(point,halfWidth)==reusable.Touches(point,halfWidth));
                        check(Bits(fresh.ExteriorFraction(point))==Bits(reusable.ExteriorFraction(point)));
                    }
                }
            }
        }
    }
    std::cout<<"kernel_checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
