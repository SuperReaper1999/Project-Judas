from pathlib import Path
import argparse,subprocess,os,json,statistics,platform,datetime
parser=argparse.ArgumentParser()
parser.add_argument('--loops',type=int,default=30)
parser.add_argument('--rounds',type=int,default=4)
parser.add_argument('--fixture',default='.cache/fluid-support-continuation-20261102/query10.json')
args=parser.parse_args()
root=Path.cwd();out=root/'.cache/fluid-support-continuation-20261102/prepared-reuse'
records=[]
def sample(variant,loops,warmup=False):
    env=os.environ.copy();env['JUDAS_BENCH_LOOPS']=str(loops);env.pop('JUDAS_REFERENCE_SLICES',None)
    command=[str(out/variant/'frozen'),str((root/args.fixture).resolve())]
    p=subprocess.run(command,env=env,capture_output=True,text=True,check=True)
    result=json.loads(p.stdout);result.update({'variant':variant,'warmup':warmup,'command':command})
    records.append(result)
for variant in ['baseline','reuse']:sample(variant,3,True)
for i in range(args.rounds):
    for variant in (['baseline','reuse'] if i%2==0 else ['reuse','baseline']):sample(variant,args.loops)
values={variant:[r['seconds']/r['queries'] for r in records if r['variant']==variant and not r['warmup']] for variant in ['baseline','reuse']}
checksums={r['checksum'] for r in records if not r['warmup']}
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'fixture':str((root/args.fixture).resolve()),'records':records,'medianSecondsPerQuery':{variant:statistics.median(times) for variant,times in values.items()},'checksumsEqual':len(checksums)==1,'scope':'Paired frozen-query measurements only; no full production speed claim.'}
(out/'TIMINGS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['records']},indent=2))
if not result['checksumsEqual']:raise SystemExit(1)
