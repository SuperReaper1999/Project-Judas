from pathlib import Path
import subprocess,json,re,hashlib,os,sys
r=Path.cwd();out=r/'.cache/fluid-support-continuation-20261102/prepared-reuse'
results=json.loads((out/'VERIFICATION.json').read_text())['results'] if '--reuse-only' in sys.argv else {}
for variant in (['reuse'] if '--reuse-only' in sys.argv else ['baseline','reuse']):
    path=out/variant;results[variant]={}
    for short in ['wet_support','hydrostatics','vertical_support','known_geometry']:
        args=[str(path/short)]
        if short=='known_geometry':args+=['--output',str(path/'known_geometry.csv')]
        with (path/(short+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,cwd=r)
        results[variant][short]=p.returncode
        print(variant,short,p.returncode,flush=True)
    for name,fixture in [('support334',r/'tests/fixtures/fluid/support-band-334.json'),('row589sample10',r/'.cache/fluid-support-continuation-20261102/query10.json')]:
        with (path/(name+'.csv')).open('w') as log:p=subprocess.run([str(path/'frozen'),str(fixture)],stdout=log,stderr=subprocess.STDOUT,cwd=r)
        results[variant][name]=p.returncode
        print(variant,name,p.returncode,flush=True)
parity={}
for name in ['wet_support.log','hydrostatics.log','vertical_support.log','known_geometry.log','known_geometry.csv','support334.csv','row589sample10.csv']:
    a=(out/'baseline'/name).read_text();b=(out/'reuse'/name).read_text()
    if name=='hydrostatics.log':
        a=re.sub(r' seconds=[0-9.]+','',a);b=re.sub(r' seconds=[0-9.]+','',b)
    parity[name]=a==b
    print('parity',name,a==b,flush=True)
manifest={'results':results,'exactParityExceptHydroTiming':parity,'allParity':all(parity.values()),'reuseHeaderSHA256':hashlib.sha256((out/'reuse/FluidSolidSupport.h').read_bytes()).hexdigest(),'reuseHydroSHA256':hashlib.sha256((out/'reuse/FluidHydrostatics.cpp').read_bytes()).hexdigest()}
(out/'VERIFICATION.json').write_text(json.dumps(manifest,indent=2)+'\n')
if not manifest['allParity']:raise SystemExit(1)
