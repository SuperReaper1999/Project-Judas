from pathlib import Path
import subprocess,json,shlex
r=Path.cwd();out=r/'.cache/fluid-support-continuation-20261102/prepared-reuse';dest=out/'protected-air';dest.mkdir(exist_ok=True);build=r/'.cache/2d-stage1-build'
source=(r/'src/FluidHydrostatics.cpp').read_text();needle='''        if(layers.size()>1) {
            // Fill internal sampling disorder'''
replacement='''        // Connected sampling volumes retain the root's resolved air gaps.
        // Only displaced solids may reconstruct missing rows from the halo.
        if(layers.size()>1 && (!connectedWetSupport || solid)) {
            // Fill internal sampling disorder'''
assert source.count(needle)==1;source=source.replace(needle,replacement);(dest/'FluidHydrostatics.cpp').write_text(source)
commands=[]
def run(c,cwd=None):commands.append({'cmd':c,'cwd':str(cwd or r)});subprocess.run(c,cwd=cwd,check=True)
def flags(target):
 d={}
 for line in (build/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_') and ' = ' in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((d[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def link(target,source,obj,binary,module):
 c=[a for a in shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=')]
 c=[a for a in c if not a.endswith('.cpp.o')]
 c.insert(c.index('-o'),str(obj));c[c.index('-o')+1]=str(binary)
 k=c.index('libjudas_engine.a');c[k:k]=[str(module),str(out/'baseline/FluidBoundaryOwnership.o')]
 run(c,build)
run(flags('judas_engine')+['-c',str(dest/'FluidHydrostatics.cpp'),'-o',str(dest/'protected.o')])
run(flags('judas_engine')+['-c',str(out/'ResolvedAirProbe.cpp'),'-o',str(dest/'probe.o')])
for variant,module in [('baseline',out/'baseline/FluidHydrostatics.o'),('protected',dest/'protected.o')]:
 link('judas_fluid_known_geometry_tests','',dest/'probe.o',dest/variant,module)
 with (dest/(variant+'.log')).open('w') as log:p=subprocess.run([str(dest/variant)],stdout=log,stderr=subprocess.STDOUT,cwd=r)
 print(variant,p.returncode,flush=True)
results={}
for short,sourceName in [('hydrostatics','FluidHydrostaticsTests'),('wet_support','FluidWetSupportTests'),('vertical_support','FluidVerticalSupportTests')]:
 target='judas_fluid_'+short+'_tests';cmd=flags(target);cmd=[a for a in cmd if a!='-Dmain=JudasValidationMain']
 run(cmd+['-c',str(r/'tests'/f'{sourceName}.cpp'),'-o',str(dest/(short+'.o'))])
 link(target,'',dest/(short+'.o'),dest/short,dest/'protected.o')
 with (dest/(short+'.log')).open('w') as log:p=subprocess.run([str(dest/short)],stdout=log,stderr=subprocess.STDOUT,cwd=r)
 results[short]=p.returncode;print(short,p.returncode,flush=True)
# This object uses the validation entrypoint name; supply its unchanged wrapper.
# Relink with the original wrapper object explicitly.
target='judas_fluid_known_geometry_tests';c=[a for a in shlex.split((build/f'CMakeFiles/{target}.dir/link.txt').read_text()) if not a.startswith('-Wl,--dependency-file=')]
c=[str(out/'owned-controls/KnownGeometryOwned.o') if a.endswith('/tests/FluidKnownGeometryTests.cpp.o') else a for a in c];c[c.index('-o')+1]=str(dest/'known-owned');k=c.index('libjudas_engine.a');c[k:k]=[str(dest/'protected.o'),str(out/'baseline/FluidBoundaryOwnership.o')];run(c,build)
with (dest/'known-owned.log').open('w') as log:p=subprocess.run([str(dest/'known-owned'),'--output',str(dest/'known-owned.csv')],stdout=log,stderr=subprocess.STDOUT,cwd=r)
results['known-owned']=p.returncode;print('known-owned',p.returncode,flush=True)
(dest/'BUILD.json').write_text(json.dumps({'commands':commands,'results':results},indent=2)+'\n')
