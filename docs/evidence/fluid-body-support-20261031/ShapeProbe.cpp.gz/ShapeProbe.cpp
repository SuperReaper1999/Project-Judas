#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <cmath>
struct Uniform:GravityField {glm::vec3 g;explicit Uniform(glm::vec3 v):g(v){}glm::vec3 Sample(const glm::vec3&)const override{return g;}};
int main(){int failures=0;
 for(bool rotated:{false,true})for(bool ring:{false,true}){
  const auto q=rotated?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);
  const glm::vec3 shift=rotated?glm::vec3(3,-2,4):glm::vec3(0);
  std::vector<FluidParticle> particles;
  for(int x=-8;x<=8;++x)for(int z=-8;z<=8;++z)for(int y=-4;y<=-1;++y){
   if(ring&&std::abs(x)<3&&std::abs(z)<3)continue;
   const auto p=shift+q*glm::vec3(.25f*x,.25f*y,.25f*z);particles.push_back({p,p,glm::vec3(0),15.625f,glm::vec3(0)});
  }
  FluidHydrostaticField field;field.Build(particles,1000);BodyTransform pose;pose.position=shift+q*glm::vec3(0,-.5f,0);pose.rotation=q;
  for(int shape=0;shape<3;++shape){
   FluidVolumeQuadrature volume;
   if(shape==0)volume=MakeSphereFluidVolume(.1f);
   if(shape==1)volume=MakeCompoundFluidVolume({{{-.3f,0,0},{.1f,.1f,.1f}},{{.3f,0,0},{.1f,.1f,.1f}}});
   if(shape==2){CompoundBox child{{0,0,0},{.2f,.1f,.1f}};child.rotation=glm::angleAxis(.4f,glm::vec3(0,1,0));volume=MakeCompoundFluidVolume({child});}
   const auto result=EvaluateFluidHydrostatics(field,volume,pose,Uniform(q*glm::vec3(0,-9.81f,0)));
   const auto expected=ring?0.f:1.f;bool pass=std::abs(result.fraction-expected)<2e-5;failures+=!pass;
   std::cout<<"shape="<<shape<<" ring="<<ring<<" rotated="<<rotated<<" fraction="<<result.fraction<<" expected="<<expected<<" pass="<<pass<<'\n';
  }
 }
 // A remote wet child cannot make a separated dry child wet.
 std::vector<FluidParticle> particles;
 for(int x=-8;x<=8;++x)for(int z=-8;z<=8;++z)for(int y=-4;y<=-1;++y){if(std::abs(x)<2&&std::abs(z)<2)continue;glm::vec3 p(.25f*x,.25f*y,.25f*z);particles.push_back({p,p,glm::vec3(0),15.625f,glm::vec3(0)});}
 FluidHydrostaticField field;field.Build(particles,1000);
 const auto volume=MakeCompoundFluidVolume({{{0,0,0},{.1f,.1f,.1f}},{{.4f,0,0},{.1f,.1f,.1f}}});
 BodyTransform pose;pose.position={0,-.5f,0};const FluidSolidQuery solid{volume,pose};
 const auto result=field.Query(pose.position,{0,1,0},.025f,volume.boundRadius,{1,0,0},&solid,true);
 const bool pass=result.fraction==0;failures+=!pass;
 std::cout<<"disconnected-child expected=0 actual="<<result.fraction<<" pass="<<pass<<'\n';
 std::cout<<"failures="<<failures<<'\n';return failures?1:0;
}
