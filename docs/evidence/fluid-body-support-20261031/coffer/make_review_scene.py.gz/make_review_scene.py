from pathlib import Path
blocks=[]
def obj(name,position,half=None,mass=None,color='.4 .45 .5',extra='',alpha=1):
 ident=len(blocks)+1
 text=f'object {ident} "{name}"\n  position '+' '.join(map(str,position))+'\n  rotation 1 0 0 0\n  scale 1 1 1\n'
 if half is not None:
  h=' '.join(map(str,half));text+=f'  render box\n  render.half-extents {h}\n  render.radius 0.5\n  render.color {color}\n  render.alpha {alpha}\n  render.secondary-color .8 .8 .8\n  render.secondary-alpha 1\n  render.mesh-asset \"\"\n  render.texture-asset \"\"\n  body '+('dynamic' if mass else 'static')+f' box\n  body.half-extents {h}\n  body.radius 0.5\n  body.terrain \"\"\n  body.initial-velocity 0 0 0\n  body.managed false\n  body.compound-count 0\n  body.mass {mass or 1}\n  body.friction 0.8\n  body.restitution 0.05\n  body.pickable '+('true' if mass else 'false')+'\n'
 text+=extra+'end\n';blocks.append(text)
obj('Ground and uniform gravity',(0,-.25,0),(4.5,.25,4.5),color='.28 .31 .33',extra='  gravity uniform 9.81\n  gravity.region box 100 100 100\n')
obj('Observation deck',(0,.6,-2.8),(2,.6,.7),color='.4 .43 .46')
for sign in (-1,1):
 obj('Outer X wall '+str(sign),(sign*1.6,.6,0),(.1,.6,1.7))
 obj('Outer Z wall '+str(sign),(0,.6,sign*1.6),(1.5,.6,.1))
 obj('Dry coffer X wall '+str(sign),(sign*.4,.6,0),(.05,.6,.45),color='.7 .64 .4')
 obj('Dry coffer Z wall '+str(sign),(0,.6,sign*.4),(.35,.6,.05),color='.7 .64 .4')
obj('Dry orange cube inside coffer',(0,.14,0),(.13,.13,.13),8.788,color='.95 .42 .1')
obj('Floating green cube',(.98,.45,0),(.3,.3,.3),108,color='.2 .8 .4')
obj('Sinking gray cube',(-.98,.45,0),(.25,.25,.25),250,color='.45 .48 .55')
for name,position,count in [('North water',(0,.125,1),(12,4,4)),('South water',(0,.125,-1),(12,4,4)),('West water',(-1,.125,0),(4,4,4)),('East water',(1,.125,0),(4,4,4))]:
 obj(name,position,extra='  fluid-volume\n  fluid-volume.spacing 0.25\n  fluid-volume.count '+' '.join(map(str,count))+'\n  fluid-volume.emitter false\n  fluid-volume.emitter-offset 0 0 0\n  fluid-volume.max-particles 2000\n')
obj('Player observer',(0,2.1,-2.8),extra='  player-start first-person\n  player-start.yaw 180\n')
head='JudasScene 3\nsettings\n  name "Wet support review - dry coffer, floating and sinking props"\n  world-origin 0 0 0\n  sun-direction .4 .7 .35\n  sun-color 1 .98 .92\n  ambient .22 .23 .25\n  fluid-scale 5\n  fidelity-policy none\n  next-id '+str(len(blocks)+1)+'\nend\n\n'
Path('assets/scenes/fluid_wet_support_review.judas').write_text(head+'\n'.join(blocks))
p=Path('.cache/fluid-body-support-integration-20261031/coffer-tour.txt').resolve();shot=p.parent/'coffer-after.png';p.write_text(f'FRAMES 600\nFRAME_SECONDS 0.016666667\nLOOK 0 120 0\nSCREENSHOT 599 {shot}\n')
