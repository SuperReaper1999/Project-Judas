#include "Project.h"
#include "RuntimeWorld.h"
#include "GameSession.h"
#include "Window.h"
#include "Simulation.h"
#include "ProductionFluidCoupling.h"
#include "SceneSerialization.h"
#include "SceneFingerprint.h"
#include "SaveArchive.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
int main(int argc,char**argv){
 if(argc<3)return 2;Scene scene;std::string error;if(!LoadSceneFromFile(argv[1],scene,error)){std::cerr<<error;return 2;}
 if(argc>3)for(auto& o:scene.Objects())if(o.body&&o.body->motion==SceneBodyMotion::Dynamic)o.body.reset();
 RuntimeWorld world;ProjectSettings settings;settings.advancedFluidDynamics=true;world.ConfigureProject(settings);GameSession session;Window window;window.SetTestInputMode(true);
 if(!world.Build(scene,nullptr,error)||!session.Begin(world,error)){std::cerr<<error;return 2;}
 for(const auto& p:world.Fluid().Particles()) {
  if((std::abs(p.position.x)<.35f&&std::abs(p.position.z)<.35f)||std::abs(p.position.x)>1.5f||std::abs(p.position.z)>1.5f){std::cerr<<"Invalid initial coffer authoring\n";return 3;}
 }
 std::vector<float> maxHeight(world.Fluid().Particles().size(),-10000);std::ofstream out(argv[2]);out<<std::setprecision(17)<<"step,inside_coffer,outside_outer,inner_without_recorded_rim_height,max_height,geometry_escapes,unresolved,dry_fraction,dry_force,dry_y\n";
 for(int step=0;step<600;++step){StepPlayedWorld(session,window,1.f/60);int inner=0,outer=0,below=0;float height=0;std::size_t i=0;
  for(const auto& p:world.Fluid().Particles()){
   maxHeight[i]=std::max(maxHeight[i],std::max(p.position.y,p.previousPosition.y));height=std::max(height,p.position.y);
   if(std::abs(p.position.x)<.35f&&std::abs(p.position.z)<.35f&&p.position.y<1.2f){++inner;if(maxHeight[i]<1.2f)++below;}
   if(std::abs(p.position.x)>1.8f||std::abs(p.position.z)>1.8f)++outer;
   ++i;
  }
  float fraction=0,force=0,y=0;
  if(!world.DynamicBodies().empty()){
   auto h=world.DynamicBodies().front().Handle();y=world.Physics().GetTransform(h).position.y;
   for(const auto& b:world.FluidCoupling().Measurements().bodies)if(b.body.id==h.id){fraction=b.fraction;force=glm::length(b.buoyancyForce);}
  }
  auto d=world.Fluid().GetDiagnostics();out<<step<<','<<inner<<','<<outer<<','<<below<<','<<height<<','<<d.geometryEscapeCount<<','<<d.unresolvedGeometryCount<<','<<fraction<<','<<force<<','<<y<<'\n';
 }
 SaveArchive state;for(const auto& p:world.Fluid().Particles()){auto x=p;state(x.position,x.previousPosition,x.velocity,x.acceleration,x.mass);}
 std::cout<<"particles="<<world.Fluid().Particles().size()<<" final_particle_sha256="<<SceneFingerprintSha256(state.bytes)<<'\n';
}
