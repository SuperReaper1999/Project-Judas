BOUNDED 3D VOLUME GRID PROTOTYPE — 2 NOVEMBER 2026

STATUS / DECISION
This is an isolated CPU numerical prototype, not production Judas water. It
establishes useful grid building blocks but does NOT justify replacing PBF yet.
The pressure implementation still dominates cost, particularly at refinement,
even after the verified cached-edge optimization described below.
It has not been integrated, unlocked, committed or published by this subtask.
No production, existing test, project, protected evidence or research was edited.

Delivered source: volume_grid.cpp, standalone C++17, binary64.
PROVENANCE.json identifies its source/binary hashes and validation. The timed
cached source/binary/provenance are preserved separately as timed-cached-source.cpp,
timed-cached-binary and TIMED_CACHED_PROVENANCE.json. The delivered source adds
ONLY CLI input bounds (CLI_ONLY_CHANGE.patch); physics equations are unchanged.
The 57 gates were rerun, byte-identical to the timed cached variant; the existing
60-sample timings are not relabelled as measurements of the CLI-guard binary.
Original first sources, failures and logs are preserved beside the final source.

WHAT ACTUALLY EXECUTES
- A regular 3D MAC grid stores one water volume fraction per cell and face
  velocity components. Air occupies the complementary fraction, densities
  1 and 1000 kg/m3. This is an incompressible two-phase bounded-box model,
  not a prescribed surface, particle system or 2D heightfield.
- Each update applies gravity and projects velocity with variable-density
  pressure. Fluid/air pressure unknowns span all non-solid cells. Solid masks
  and outer walls have zero normal velocity. Coefficients are positive face
  inverse densities; disconnected components have separate pressure gauges.
- Pressure uses matrix-free Jacobi-preconditioned CG, relative infinity
  residual 1e-11 with an absolute 1e-11 floor, budget 2000. Actual resulting
  divergence must be at most 1e-7 or the update fails without publication.
- Donor-cell volume transport computes one paired debit/credit per face.
  No quantity rescaling or clamping hides loss. A volume CFL above one fails.
- Mixture-mass flux uses the SAME advected water fraction. Staggered momentum
  uses averaged primal mass fluxes on dual cells and first-order upwind values.
  The evolved dual mass is independently compared to averaged updated cell
  density. Dual CFL and mass disagreement reject before publication.
- A second pressure projection restores incompressibility after nonlinear
  momentum transport. The two pressure increments are retained for the static
  hydrostatic traction control. All primary fields publish together at the end.
- Queries sample authoritative volume fractions. Marching tetrahedra extracts
  a 0.5 isosurface for display: this mesh does not own or alter water quantity.

The first pressure/quantity-only version omitted nonlinear momentum transport.
That source is retained as pressure-volume-only.cpp. The final source does
transport momentum; the marker known-answer and frozen-velocity negative
control distinguish it from the initial reduced model.

CORRECTNESS
final-gates.log: naive 57 checks, 0 failures. cached-edge-gates.log: final
cached operator 57/57, byte-identical to naive-digest-gates.log including
terminal hashes of all fractions, pressures and face velocities in the pool,
dam-release and variable-density scenarios.
- Vertical and oblique gravity: static fully wet aligned box has no appreciable
  velocity; hydrostatic pressure-integrated force and off-centre torque agree
  with displaced-volume calculations. Largest force error about 1.8e-8 N;
  largest torque error about 6.3e-8 N m. Force-only 500/1000/2000 kg cases rise,
  balance or sink as expected; these are NOT moving-body trajectories.
- An algebraic output-frame check rotates the already solved force and gravity
  together and compares them. This is NOT independent rotated geometry or a
  second cross-chart runtime execution. The separate oblique-gravity case does
  actually rerun the grid solve with a different gravity vector. Affine pressure
  interpolation and quadrature over an oblique face match affine answers.
  This is NOT an oblique cut-cell operator test. Rotated and subcell solids
  explicitly reject, rather than disappearing into a coarse mask.
- A skew-centroid two-point negative control returns the incorrect 0.5 normal
  flux for a known zero-normal-gradient field. It confirms why that operator
  cannot simply be substituted for actual oblique cut geometry.
- A known paired volume transfer changes 0.5 into 0.45 and 0.05 with no loss.
- Variable-density transport preserves constant interior velocity exactly;
  dual/primal mass discrepancy is 1.14e-13 kg/m3. A tangential momentum marker
  becomes 0.196 as independently expected, error 2.78e-17. A frozen update
  would leave 0.2 and fails that oracle by 0.004.
- Closed zero-work projection/update tests reduce kinetic energy. The upwind
  method has numerical dissipation; this is not an energy-conserving scheme,
  and angular-momentum transport has not been qualified.
- The 12 x 8 x 3 m diagnostic basin starts with exactly 180 m3 of water. After
  90 updates at 1/90 s, water volume is 180.00000000000017 m3. Fractions remain
  bounded without clamping; maximum pressure divergence is 4.46e-12 /s.
- A real gravity-driven dam-release test, 60 updates at 1/240 s, shifts the
  water centre by 0.110289 m in 0.25 s; peak face speed is 4.45197 m/s. Water
  volume changes by -3.02e-14 m3. Flow and quantity change through the pressure/
  momentum/transport update, not a frozen prescribed flow field.
- A disturbed chamber separated by a real whole-cell barrier does not move
  the disconnected chamber at all. Pressure gauges are handled per component.
- Forced solve failure, NaN gravity and CFL/late transport failures preserve
  published fields. No partial new quantity or pressure leaks from a failure.

PRESERVED EARLY FAILURE
momentum-failed.cpp / momentum-failed-line.log / momentum-diagnosis.log retain
an important control-design error. Uniform positive velocity was set inside a
CLOSED box but forced to zero at its ends, so that field was divergent. Water
advection alone does not carry complementary air-volume compression; mixture
mass and dual transport correctly disagreed by 0.01 kg/m3 and rejected the step.
The test harness then indexed a rejected, empty output and segfaulted. This was
an isolated numerical test executable, not a desktop/renderer/engine crash.
The final harness guards rejected outputs and uses a genuinely divergence-free
streamfunction fixture for the constant-velocity interior test. The mass check
and tolerances were retained. This does not establish support for divergent
advection inputs; pressure projection is a required prior stage.

TIMING (DIAGNOSTIC ONLY — NOT SAME-FIDELITY PBF COMPARISON)
Ryzen 5 5600 Linux host, GNU 15.2, -O3, 60 consecutive updates per resolution.
All samples, including the first, are retained. No renderer or GPU was involved.
No compiler work ran during the timing interval. Timings were sequenced with
root so the engine build was paused; no OS scheduler isolation was imposed.
Raw rows: bench-r1.csv and bench-r2.csv; /usr/bin/time outputs retained.

spacing/cells     step p50 / p95 / worst (ms)    pressure p50   transport p50
0.50 m /  2304       9.505 /   9.824 /   9.871        9.122          0.386
0.25 m / 18432     156.931 / 159.771 / 162.119      153.782          3.127

spacing     surface mesh p50    1000 queries p50   owned arrays   process RSS peak
0.50 m          0.316 ms          0.0172 ms          99,456 B        5,212 KiB
0.25 m          1.906 ms          0.0187 ms         775,680 B        9,068 KiB

Step includes both pressure assemblies/projections, component discovery, matrix
applications, temporary allocation/copies, transport validation and publication.
Meshing and queries are separate and are NOT included in the step column.
Owned-array memory excludes scratch; process RSS includes it and runtime code.
This is not memory use of a complete Judas game or the renderer.
Final benchmark water volumes are 180.00000000000009 / 180.00000000000136 m3.
The last steps required 279 / 590 total pressure iterations across two solves.
These first timings are the preserved NAIVE implementation. A subsequent
bounded correction assembles each weighted pressure edge ONCE per Project,
in the same face visitation order. Krylov iterations then use that owned list
instead of rebuilding indices, masks, densities and divisions on every multiply.
The coefficients are rebuilt whenever a Project begins: no stale cross-update
reuse is introduced. The equations, PCG budget and tolerances are unchanged.

FINAL CACHED-EDGE COMPARISON (same 60-update inputs and scope):
spacing/cells     step p50 / p95 / worst (ms)    pressure p50   transport p50
0.50 m /  2304       3.981 /   4.130 /   4.289        3.594          0.389
0.25 m / 18432      65.627 /  67.247 /  68.754       62.463          3.090

Cached surface/query p50: 0.318/0.0172 ms coarse; 1.929/0.0186 ms fine.
Owned arrays remain 99,456 / 775,680 B; scratch/operator storage is included in
process peaks of 5,196 / 9,640 KiB. The coarse RSS difference from the naive run
is measurement noise/layout, not a memory-saving claim.

Raw cached-bench-r1/r2.csv and COMPARISON.json preserve the measured correction.
Each sample's pressure iteration count, maximum divergence, water volume and
triangle count is identical between naive and cached runs; final query sums
also match. The separate full gate logs including terminal state digests are
byte-identical. Normal floating-point differences for other spacings/platforms
were not qualified here. This is about 2.4x cheaper for this implementation,
NOT a 2.4x speedup over production water. The fine grid remains impractical for
a 90 Hz fluid budget. The weak preconditioner and pressure iteration scaling
remain clear costs; this does not establish that grids in general are slow.

CRITICAL SCOPE LIMITS
- Production pool stairs have 0.18 m half-widths and thrown rotating boxes.
  The prototype supports neither moving nor cut geometry and excludes them.
  These are NOT matched workload speedups or a qualified squeeze-jet repair.
- Static whole-cell solids only. No moving-solid swept volume, finite-mass
  pressure reaction, rotating cups, real pours between containers, changing
  topology, subcell dry gaps or disconnected fluid ownership within one cell.
- Donor-cell VOF diffuses interfaces; no geometric PLIC or interface accuracy/
  convergence qualification. Air is an incompressible phase inside a closed
  top, rather than an open atmospheric pressure boundary.
- Static affine hydrostatic traction reconstructs half-cell pressure from
  gravity. It is NOT a general pressure traction rule for dynamic bodies.
- Surface extraction omits domain caps and has no engine material/renderer
  integration or visual-quality acceptance. It is used only to measure an
  actual quantity-derived extraction operation.
- No qualified whole-system angular momentum, moving-body work/added mass,
  cold persistence, streaming, origin shifts, Linux game integration, Windows,
  Android, browser or GPU evidence. Those cannot be inferred from these gates.

RECOMMENDED NEXT DECISION
Do not replace production particles or unlock fluids based on this prototype.
The grid layout is viable for volume/pressure/momentum, but this basic pressure
implementation is not practical at the fine test resolution. The bounded cached-edge correction has already removed one repeated-work
mechanism. A next experiment would need a better variable-coefficient pressure
preconditioner, retaining these exact physical gates. Then moving cut-solid ownership and genuine reaction work must
be established before comparing the real pool/cup workload. Do not retain the
old PBF geometry/reconstruction work underneath and call it a cheaper grid.

REPRODUCTION FROM REPOSITORY ROOT
  c++ -std=c++17 -O3 -Wall -Wextra -pedantic \
    .cache/fluid-volume-grid-20261102/volume_grid.cpp \
    -o .cache/fluid-volume-grid-20261102/volume_grid
  .cache/fluid-volume-grid-20261102/volume_grid
  .cache/fluid-volume-grid-20261102/volume_grid bench 1 60
  .cache/fluid-volume-grid-20261102/volume_grid bench 2 60
Only refinement 1 or 2 and 1..1000 samples are admitted. Invalid, negative,
zero, overflowing and malformed arguments reject before allocating the grid.
No Judas build, GL context or external research implementation is required.
