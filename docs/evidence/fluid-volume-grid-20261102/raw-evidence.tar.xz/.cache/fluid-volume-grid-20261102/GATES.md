# Predeclared initial prototype gates

Scope: disposable regular 3D staggered MAC pressure / conservative volume-fraction
building blocks, not an engine replacement or matched game benchmark. Binary64.
Two-phase water/air (densities 1000/1) fills a closed bounded grid. All cells own
one volume fraction; velocities live on faces. Static solid masks admit only
aligned whole-cell boundaries. No cut-cell/moving-solid topology is claimed.

Before first compilation:
- Hydrostatic zero velocity with vertical and oblique gravity, pressure-integrated
  force and off-centre torque against displaced-volume formula, light/neutral/heavy
  force signs, and chart-rotation covariance.
- Affine interpolation and oblique-face pressure quadrature. This is an affine
  query patch, not proof of an oblique cut-cell pressure operator.
- Negative skew-centroid two-point operator must exhibit its false normal flux.
- Reject rotated/subcell geometry instead of voxelizing away the feature.
- Paired donor/receiver volume transfer with known answers, exact mass accounting,
  CFL rejection, and no publication on pressure failure/NaN input.
- Actual pressure projection must reduce divergence and never increase kinetic
  energy in a closed zero-force fixed-density experiment.
- 90 actual 1/90 s grid pressure/quantity updates on the same 12×8×3 m outer
  dimensions and 180 m³ water quantity: bounded fractions, mass conservation,
  pressure divergence; a surface extracted from authoritative fractions.

Known omissions, hence not passing claims: nonlinear momentum advection,
consistent variable-density momentum transport, free-surface geometric PLIC,
rotating or moving cut solids/cups, production contact/coupling, real rigid-body
trajectories, dry gaps/thin walls, cold persistence/origin shifting/streaming,
GPU rendering and integration. Hydrostatic traction's half-cell reconstruction
is valid for static affine tests only, not arbitrary dynamic pressure.

Benchmark includes pressure assembly/components/Jacobi PCG/validation, copying,
volume transport, separate scalar-field meshing and 1000 occupancy queries.
Not a same-fidelity speedup over PBF: the production stair/throw geometry is
outside initial admission. No backend replacement or unlock on these gates.
