from pathlib import Path
p=Path('src/physics/WorldMk2Solver.cpp');s=p.read_text()
a=s.index('    // A struck dynamic body continues',s.index('void PhysicsWorld::Impl::Mk2Continuous'))
b=s.index('    for (const auto slot : aliveSlots) {',a)
# Keep old kinematic loop for now, but publish struck paths without sweeping until the pair is whole.
s=s[:a]+s[b:]
s=s.replace('                struck(other, earliest);','''                {
                    retime(other, earliest, false);
                    auto* m = moverOf(other);
                    if (!m) { movers.push_back({other, earliest, false, arrivalCounts ? (*arrivalCounts)[other] : 0u}); m = &movers.back(); }
                    m->from = earliest; m->firstSweep = false;
                    sweep(*m);
                }''')
a=s.index('        if (!resolved || next->arrivals',s.index('void PhysicsWorld::Impl::Mk2Continuous'))
b=s.index('    }\n    // Arrivals left',a)
s=s[:a]+'''        // Publish the entire response before querying either participant. A
        // sequential sweep could otherwise read the other body's old trajectory.
        for (const auto changed : {slot, other}) {
            if (!movable(changed)) continue;
            if (bodies[changed].sleeping) Wake(changed);
            auto* m = moverOf(changed);
            if (!m) {
                movers.push_back({changed, at, false, arrivalCounts ? (*arrivalCounts)[changed] : 0u});
                m = &movers.back();
            }
            const bool hold = !resolved || m->arrivals >= kMk2ArrivalsPerBody;
            if (hold) {
                ++stats.impactSafetyFallback;
                if (!resolved) ++stats.impactResponseHolds;
                else {
                    ++stats.impactEventCapFallback;
                    ++stats.impactBodyCapHolds;
                }
            } else {
                ++m->arrivals;
                if (arrivalCounts) (*arrivalCounts)[changed] = m->arrivals;
            }
            retime(changed, at, hold, resolved);
            m->from = at;
            m->firstSweep = false;
            m->found = false;
        }
        for (auto& m : movers) {
            if (m.slot == slot || m.slot == other || (m.found && (m.other == slot || m.other == other))) {
                // Never revisit history preceding the event just committed.
                m.from = std::max(m.from, at);
                m.firstSweep = false;
                if (!arrivalCounts || (*arrivalCounts)[m.slot] <= kMk2ArrivalsPerBody)
                    sweep(m);
            }
        }
''' +s[b:]
# Tail must not leave the other body at a TOI pose.
s=s.replace('            retime(m.slot, m.hit, true, resolved);','''            if (movable(m.slot)) retime(m.slot, m.hit, true, resolved);
            if (movable(m.other)) retime(m.other, m.hit, true, resolved);''')
p.write_text(s)
p=Path('src/physics/WorldCCDSearch.cpp');s=p.read_text();s=s.replace('''        const double elapsed =
            body.isDynamic && segment != segments.begin() ? time - (--segment)->begin : 0;
        const glm::dvec3 instantaneous =
            body.isKinematic ? omega : omega / (1 + .25 * w2 * elapsed * elapsed);''','''        const RigidMotionSegment* leaf = segment == segments.begin() ? nullptr : &*--segment;
        const double elapsed = leaf ? time - leaf->begin : 0;
        const glm::dvec3 instantaneous = !leaf || leaf->prescribed || leaf->exactRotation
            ? omega : omega / (1 + .25 * w2 * elapsed * elapsed);''');p.write_text(s)
