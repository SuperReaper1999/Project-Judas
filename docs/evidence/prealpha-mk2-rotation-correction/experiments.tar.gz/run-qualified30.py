from pathlib import Path
import subprocess,time,json,hashlib,datetime
root=Path.cwd();out=root/'.cache/mk2-rotation-repair/qualified30';out.mkdir(exist_ok=False)
targets=['mk2_rotation','mk2_physics','physics_continuation','mk2_diagnostics','joint','ragdoll','physical_animation','physical_balance_controller','kinematic','character_motor','collision_geometry','impact_robustness','impact_timing','collision_continuity','rigid_motion','rigid_motion_geometry','rigid_motion_bounds','contact_lifecycle','origin_physics','origin_assembly']
cases=[(x,[str(root/'build'/f'judas_{x}_tests')]) for x in targets]
cases += [('rotation-cold',[str(root/'build/judas_mk2_rotation_cold_tests'),str(out/'rotation-cold')]),('mesh-continuation',[str(root/'build/judas_impact_mesh_cost_tests'),'60','','1.2'])]
results=[]
for name,command in cases:
 start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as f:
  try: code=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired: code='timeout'
 results.append(dict(name=name,command=command,returncode=code,seconds=time.monotonic()-start,started_utc=utc,binary_sha256=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()))
 (out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,code,flush=True)
