from pathlib import Path
p=Path('tests/Mk2RotationTests.cpp');s=p.read_text();where=s.index('void MotionView()')
s=s[:where]+'''void FreePairMomentum() {
    for (int frame:{0,1}) {
        PhysicsWorld world;world.Init();
        const auto q=glm::angleAxis(.79f*frame,glm::normalize(glm::vec3(1,2,-3)));
        const auto a=world.CreateShape(Shape::Box(kHalf),{q*glm::vec3(-.3f,.1f,0),q},true,1,0,1);
        const auto b=world.CreateShape(Shape::Box(kHalf),{q*glm::vec3(.3f,0,0),q},true,1,0,1);
        world.SetLinearVelocity(a,q*glm::vec3(20,0,0));world.SetLinearVelocity(b,q*glm::vec3(-5,0,0));
        world.SetAngularVelocity(a,q*glm::vec3(3,7,20));world.SetAngularVelocity(b,q*glm::vec3(-5,3,10));
        const auto momentum=[&] {
            glm::dvec3 linear(0),angular(0);
            for(auto h:{a,b}) {
                const auto t=world.GetTransform(h);
                const auto r=glm::normalize(glm::dquat(t.rotation));
                const glm::dvec3 v(world.GetLinearVelocity(h)),w(world.GetAngularVelocity(h));
                linear+=v;angular+=glm::cross(glm::dvec3(t.position),v)+r*(Inertia(kHalf,1)*(glm::conjugate(r)*w));
            }
            return std::pair<glm::dvec3,glm::dvec3>{linear,angular};
        };
        const auto before=momentum();const double incoming=Energy(world,a)+Energy(world,b);
        double peak=incoming,linearError=0,angularError=0;std::size_t impacts=0;
        for(int step=0;step<30;++step) {
            world.Step(kDt);const auto now=momentum();
            peak=std::max(peak,Energy(world,a)+Energy(world,b));
            linearError=std::max(linearError,glm::length(now.first-before.first));
            angularError=std::max(angularError,glm::length(now.second-before.second));
            impacts+=world.LastStepStats().impactEvents;
        }
        std::printf("PAIR frame=%d energy_ratio=%.9g linear_error=%.9g angular_error=%.9g impacts=%zu\\n",
            frame,peak/incoming,linearError,angularError,impacts);
        Check(impacts>0,"free spinning-pair fixture actually impacts");
        Check(peak<=incoming*1.0001 && linearError<1e-4 && angularError<1e-4,
            "elastic rotating bodies independently conserve energy and both momenta");
    }
}

void BoundedContactContinuation() {
    for(bool blocker:{false,true}) {
        PhysicsWorld world;world.Init();
        for(float sign:{-1.f,1.f})world.CreateStaticBox({sign*.6f,0,0},{.05f,4,4},0,1);
        if(blocker)world.CreateStaticBox({0,0,.13f},{4,4,.01f},0,1);
        const auto body=world.CreateDynamicSphere({0,0,0},.05f,1,0,1);
        world.SetLinearVelocity(body,{100,0,1});world.Step(.2f);
        Check(world.LastStepStats().impactBodyCapHolds>0,"fallback fixture actually exhausts normal arrival work");
        if(!blocker)Check(std::abs(world.GetTransform(body).position.z-.2f)<2e-6,
            "a bounded normal hold preserves certified tangential travel");
        else for(const auto& leaf:world.GetBodyMotionSegments(body))
            Check(leaf.start.position.z<=.070002f && leaf.endPose.position.z<=.070002f,
                "tangential continuation stops at a real secondary obstacle");
        Check(glm::length(world.GetLinearVelocity(body))<=glm::length(glm::vec3(100,0,1))*1.0001f,
            "bounded geometry continuation never changes physical energy");
    }
}

void ReactionObservations() {
    PhysicsWorld world;world.Init();
    for(float sign:{-1.f,1.f})world.CreateStaticBox({sign*.6f,0,0},{.05f,1,1},0,1);
    const auto body=world.CreateDynamicBox({0,0,0},kHalf,1,0,1);
    world.SetLinearVelocity(body,{5,0,0});world.SetAngularVelocity(body,{0,0,20});
    double maximum=0;std::size_t observed=0;
    for(int step=0;step<120;++step) {
        const glm::dvec3 before(world.GetLinearVelocity(body));world.Step(kDt);
        std::vector<PhysicsWorld::BodyContactSample> contacts;
        Check(world.ReadBodyContactSample(body,contacts),"repeated response patches fit the unchanged contact query budget");
        glm::dvec3 reaction(0);
        for(const auto& contact:contacts) {reaction+=glm::dvec3(contact.normal)*double(contact.normalImpulse);++observed;}
        const auto change=glm::dvec3(world.GetLinearVelocity(body))-before;
        maximum=std::max(maximum,glm::length(change-reaction));
    }
    std::printf("OBSERVATION samples=%zu maximum_impulse_error=%.9g\\n",observed,maximum);
    Check(observed>0 && maximum<1e-4,"coalesced observations retain actual complete physical reaction");
}

'''+s[where:]
s=s.replace('FreeRotation(); ElasticEnvelope(); ArrivalTiming(); MotionView();','FreeRotation(); ElasticEnvelope(); ArrivalTiming(); FreePairMomentum(); BoundedContactContinuation(); ReactionObservations(); MotionView();')
p.write_text(s)
