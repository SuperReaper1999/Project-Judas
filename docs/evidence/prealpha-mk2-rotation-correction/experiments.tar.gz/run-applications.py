from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,datetime
r=Path.cwd();out=r/'.cache/mk2-rotation-repair/application30';out.mkdir(exist_ok=False)
env=dict(os.environ,SDL_VIDEODRIVER='x11',SDL_AUDIODRIVER='dummy',JUDAS_WORLD_STATE='none');results=[]
def run(name,cmd,extra=None,cwd=None):
 local=env.copy();local.update(extra or {});start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  try:code=subprocess.run([str(x) for x in cmd],cwd=cwd or r,env=local,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired:code='timeout'
 results.append(dict(name=name,command=[str(x) for x in cmd],working_directory=str(cwd or r),returncode=code,seconds=time.monotonic()-start,explicit_environment={'SDL_VIDEODRIVER':'x11','SDL_AUDIODRIVER':'dummy','JUDAS_WORLD_STATE':'none',**(extra or {})},binary_sha256=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()))
 (out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True);return code==0
balance=r/'build/judas_balance_lab_tests';game=r/'build/judas_hearthworld_application_tests';project=r/'.cache/mk2-rotation-repair/hearthworld24/hearthworld.judasproj'
if run('m77-cold-write',[balance,out/'m77-cold','cold-write']):run('m77-cold-read',[balance,out/'m77-cold','cold-read'])
run('m77-preserved-failure-snapshot-read',[balance,r/'.cache/mk2-rotation-repair/combined22/m77-cold-desktop','cold-read'])
if run('hearthworld-write',[game,project,'write',out/'hearthworld']):run('hearthworld-cold-read',[game,project,'read',out/'hearthworld'])
probe=r/'.cache/mk2-rotation-repair/js-original24'
run('original-js-probe',[r/'build/judas',probe/'game.judasproj'],{'JUDAS_TEST_SCRIPT':str(probe/'probe.test')})
package=out/'exported-probe'
if run('export-probe',[r/'build/judas_export',probe/'game.judasproj',package,r/'build/judas']):
 moved=Path('/tmp')/('judas-mk2-rotation-'+str(os.getpid()));shutil.move(str(package),moved)
 timer=out/'relocated-input.test';timer.write_text('STEPS 1\nLOG_EVERY 0\n')
 run('relocated-export',[moved/'judas'],{'JUDAS_TEST_SCRIPT':str(timer)},Path('/tmp'))
 (out/'RELOCATED.json').write_text(json.dumps({'package':str(moved),'runtime_sha256':hashlib.sha256((moved/'judas').read_bytes()).hexdigest(),'note':'External input script is a two-line test driver, not game content. Launched from unrelated /tmp working directory; same host runtime libraries.'},indent=2)+'\n')
