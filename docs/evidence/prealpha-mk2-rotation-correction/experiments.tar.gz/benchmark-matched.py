from pathlib import Path
import subprocess,json,time,datetime,hashlib,platform
r=Path.cwd();out=r/'.cache/mk2-rotation-repair/performance28';out.mkdir(exist_ok=False)
binaries={'baseline':r/'.cache/mk2-rotation-repair/scaling-baseline','candidate':r/'build/judas_physics_scaling_benchmarks'}
(out/'ENVIRONMENT.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),platform=platform.platform(),compiler=subprocess.check_output(['c++','--version'],text=True).splitlines()[0],hardware=subprocess.check_output(['lscpu'],text=True),memory=Path('/proc/meminfo').read_text(),load=Path('/proc/loadavg').read_text(),input_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),binaries={k:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for k,p in binaries.items()},note='Serial fresh-process ABBA per case. Same accepted M87 driver/options/quality; profile enabled in both. Shared development desktop; not an isolated performance appliance. No rendering workload.'),indent=2)+'\n')
results=[]
for workload,count in [('pile',128),('pile',1024),('machines_active',128),('mesh',64)]:
 for index,version in enumerate(['baseline','candidate','candidate','baseline']):
  dest=out/f'{workload}-{count}-{index+1}-{version}';cmd=[str(binaries[version]),'--workload',workload,'--count',str(count),'--warm','30','--steps','180','--profile','1','--output',str(dest)];start=time.monotonic()
  with (out/(dest.name+'.log')).open('w') as f:
   try:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
   except subprocess.TimeoutExpired:code='timeout'
  record=dict(case=f'{workload}-{count}',version=version,order=index+1,command=cmd,returncode=code,wall_seconds=time.monotonic()-start)
  if (dest/'summary.json').exists(): record['summary']=json.loads((dest/'summary.json').read_text())
  results.append(record);(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(record['case'],version,code,flush=True)
