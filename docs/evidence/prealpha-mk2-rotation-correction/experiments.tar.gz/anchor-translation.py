from pathlib import Path
p=Path('src/RigidMotion.h');s=p.read_text().replace('    bool prescribed=false;','''    bool prescribed=false;
    // Rotation leaves and solver intervals need not restart unchanged linear
    // flight. This anchor belongs to a velocity episode, in the ledger clock.
    bool anchoredTranslation = false;
    glm::vec3 translationOrigin{0};
    double translationTime = 0;''',1)
s=s.replace('            result.position += result.linearVelocity * elapsed;','''            result.position = anchoredTranslation
                ? translationOrigin + result.linearVelocity * float(time - translationTime)
                : position + result.linearVelocity * elapsed;''')
s=s.replace('s.endPosition=glm::vec3(glm::dvec3(s.endPosition)-delta);','s.endPosition=glm::vec3(glm::dvec3(s.endPosition)-delta);if(s.anchoredTranslation)s.translationOrigin=glm::vec3(glm::dvec3(s.translationOrigin)-delta);')
p.write_text(s)
p=Path('src/PhysicsWorld.h');s=p.read_text().replace('        bool exactRotation = false; // analytic principal-axis leaf, otherwise Cayley midpoint','''        bool exactRotation = false; // analytic principal-axis leaf, otherwise Cayley midpoint
        bool anchoredTranslation = false;
        glm::vec3 translationOrigin{0}; // center-of-mass origin of the velocity episode
        double translationTime = 0;''');p.write_text(s)
p=Path('src/physics/WorldBodies.cpp');s=p.read_text().replace('             source.exactRotation});','''             source.exactRotation,
             source.anchoredTranslation,
             source.translationOrigin,
             source.translationTime});''').replace('    source.exactRotation = segment.exactRotation;','''    source.exactRotation = segment.exactRotation;
    source.anchoredTranslation = segment.anchoredTranslation;
    source.translationOrigin = segment.translationOrigin;
    source.translationTime = segment.translationTime;''');p.write_text(s)
p=Path('src/RigidMotionBounds.h');s=p.read_text().replace('''                const Iv elapsed=Iv(start)-Iv(segment->begin);
                const double maximumElapsed=std::max(std::abs(start-segment->begin),std::abs(finish-segment->begin));
                const double doubleMagnitude=std::max({std::abs(start),std::abs(finish),std::abs(segment->begin)});''','''                const auto origin = segment->anchoredTranslation ? segment->translationOrigin : segment->position;
                const double anchor = segment->anchoredTranslation ? segment->translationTime : segment->begin;
                const Iv elapsed=Iv(start)-Iv(anchor);
                const double maximumElapsed=std::max(std::abs(start-anchor),std::abs(finish-anchor));
                const double doubleMagnitude=std::max({std::abs(start),std::abs(finish),std::abs(anchor)});''').replace('Iv(FloatRoundingBound(std::abs(double(segment->position[k]))+product))','Iv(FloatRoundingBound(std::abs(double(origin[k]))+product))').replace('return Drift{Iv(double(segment->position[k]))+Iv(velocity)*elapsed','return Drift{Iv(double(origin[k]))+Iv(velocity)*elapsed');p.write_text(s)
p=Path('src/RigidRotation.cpp');s=p.read_text().replace('constexpr double kAngleError = 1e-5;','constexpr double kAngleError = 1e-6;');s=s.replace('''    unsigned leaves = 0;
    Append(result, owner, body, begin, end, leaves, 0);''','''    unsigned leaves = 0;
    const auto first = result.size();
    Append(result, owner, body, begin, end, leaves, 0);
    for (auto i = first; i < result.size(); ++i) {
        auto& leaf = result[i];
        leaf.anchoredTranslation = true;
        leaf.translationOrigin = body.position;
        leaf.translationTime = begin;
        leaf.position = body.position + body.linearVelocity * float(leaf.begin - begin);
        leaf.endPosition = body.position + body.linearVelocity * float(leaf.end - begin);
    }''');p.write_text(s)
p=Path('src/physics/WorldMk2Solver.cpp');s=p.read_text().replace('''    std::vector<std::vector<RigidMotionSegment>> segments(state.size());''','''    struct LinearAnchor {
        glm::vec3 origin{0}, velocity{0};
        double time = 0;
        bool valid = false;
    };
    std::vector<LinearAnchor> linearAnchors(state.size());
    std::vector<std::vector<RigidMotionSegment>> segments(state.size());''');s=s.replace('            segments.resize(state.size());','            segments.resize(state.size());\n            linearAnchors.resize(state.size());')
s=s.replace('''                const auto next = interval[i].back().Evaluate(h);''','''                auto& anchor = linearAnchors[i];
                if (!anchor.valid || anchor.velocity != drift.linearVelocity ||
                    anchor.origin + anchor.velocity * float(begin-anchor.time) != drift.position) {
                    anchor = {drift.position, drift.linearVelocity, begin, true};
                }
                for (auto& leaf : interval[i]) {
                    leaf.anchoredTranslation = true;
                    leaf.translationOrigin = anchor.origin;
                    leaf.translationTime = anchor.time-begin;
                    leaf.position = leaf.EvaluateGeometry(leaf.begin).position;
                    leaf.endPosition = leaf.EvaluateGeometry(leaf.end).position;
                }
                const auto next = interval[i].back().Evaluate(h);''')
s=s.replace('''        Mk2Continuous(h, &requiredContinuous, &continuousArrivals, &continuousEvents);
''','''        Mk2Continuous(h, &requiredContinuous, &continuousArrivals, &continuousEvents);
        stepDuration = dt;
''');s=s.replace('''                segment.begin += begin; segment.end += begin;
                segments[i].push_back(segment);''','''                segment.begin += begin; segment.end += begin;
                if (segment.anchoredTranslation) segment.translationTime += begin;
                segments[i].push_back(segment);''');s=s.replace('''            next.linearVelocity = next.angularVelocity = next.driftAngularVelocity = glm::vec3(0);''','''            next.anchoredTranslation = false;
            next.linearVelocity = next.angularVelocity = next.driftAngularVelocity = glm::vec3(0);''');p.write_text(s)
