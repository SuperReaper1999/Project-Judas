from pathlib import Path
import subprocess,shlex,sys
root=Path.cwd();build=root/'build';source=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve();obj=output.with_suffix('.o')
subprocess.run(['c++','-O3','-DNDEBUG','-std=gnu++17','-I'+str(root/'src'),'-c',str(source),'-o',str(obj)],check=True)
args=shlex.split((build/'CMakeFiles/judas_mk2_diagnostics_tests.dir/link.txt').read_text());args=[a for a in args if not a.startswith('-Wl,--dependency-file=') and '/tests/ValidationMain.cpp.o' not in a];args[next(i for i,a in enumerate(args) if '/tests/Mk2DiagnosticsTests.cpp.o' in a)]=str(obj);args[args.index('-o')+1]=str(output)
subprocess.run(args,cwd=build,check=True)
