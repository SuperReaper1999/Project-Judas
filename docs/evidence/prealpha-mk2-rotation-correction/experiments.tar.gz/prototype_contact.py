from pathlib import Path
p=Path('src/physics/WorldMk2Solver.cpp');s=p.read_text()
s=s.replace('bool arriving = false, arrivesNext = false;', 'bool arriving = false, arrivesNext = false, deferredImpact = false;')
s=s.replace('    if (impact)\n        return', '    if (!impact && row.deferredImpact) return -kMk2FreeSpeed;\n    if (impact)\n        return',1)
# All moving physical bodies participate in the same four chronological intervals.
s=s.replace('    if (coupling)\n        for (auto &s : state)\n            s.constrained |= s.dynamic;', '    for (auto &s : state) s.constrained |= s.dynamic;')
s=s.replace('    std::vector<glm::vec3> pseudoLinear(state.size()), pseudoAngular(state.size());', '''    std::vector<glm::vec3> pseudoLinear(state.size()), pseudoAngular(state.size());
    std::vector<glm::vec3> contactProjectionLinear, contactProjectionAngular;
    std::vector<char> requiredContinuous(bodies.size());
    std::vector<unsigned> continuousArrivals(bodies.size(), 0);
    unsigned continuousEvents = 0;
    std::vector<RigidMotion> kinematicPaths(bodies.size());
    for (auto slot : aliveSlots) if (bodies[slot].isKinematic) kinematicPaths[slot] = bodies[slot].motion;''')
needle='        // Impacts at their arrival instant.'
s=s.replace(needle,'''        std::fill(requiredContinuous.begin(), requiredContinuous.end(), char(0));
        for (auto& row : rows) {
            const float gap = glm::dot(AnchorGap(state[row.a], state[row.b], row), row.n) + row.separation;
            const float speed = RowNormalSpeed(state, row);
            row.deferredImpact = gap > kMk2Slop && speed < 0 && gap <= -speed * h + kMk2Slop;
            if (row.deferredImpact) {
                requiredContinuous[state[row.a].slot] = 1;
                requiredContinuous[state[row.b].slot] = 1;
            }
        }
'''+needle,1)
s=s.replace('if (!(v < -kMk2RestitutionThreshold) || !(std::max(gap, 0.0f) <= -v * h + kMk2Slop))', 'if (!(v < -kMk2RestitutionThreshold) || gap > kMk2Slop)')
# Real velocities are relaxed at the same configuration as the accumulated impulse.
start=s.index('        // Relax removes every positional bias velocity')
end=s.index('        if (haveJoints)\n            collectJoints();', start)
relax=s[start:end]
s=s[:start]+s[end:]
needle='        // The joints\' position correction for this substep'
replacement='''        contactProjectionLinear.resize(state.size());
        contactProjectionAngular.resize(state.size());
        for (std::size_t i=0; i<state.size(); ++i) {
            contactProjectionLinear[i] = state[i].rb->linearVelocity;
            contactProjectionAngular[i] = state[i].rb->angularVelocity;
        }
'''+relax+'''        for (std::size_t i=0; i<state.size(); ++i) {
            contactProjectionLinear[i] -= state[i].rb->linearVelocity;
            contactProjectionAngular[i] -= state[i].rb->angularVelocity;
        }
'''+needle
s=s.replace(needle,replacement,1)
# Replace pose integration, including the invalid future-impact velocity subtraction.
start=s.index('        for (std::size_t i = 0; i < state.size(); ++i) {\n            auto &s = state[i];\n            auto &body = bodies[s.slot];\n            if (s.dynamic && s.constrained)')
end=s.index('        // Poses moved: relax',start)
s=s[:start]+'''        std::vector<std::vector<RigidMotionSegment>> interval(state.size());
        for (std::size_t i = 0; i < state.size(); ++i) {
            auto& s = state[i];
            auto& body = bodies[s.slot];
            if (s.dynamic) {
                const auto oldOrientation = body.rigidBody.orientation;
                const auto realSpin = body.rigidBody.angularVelocity;
                RigidBody drift = body.rigidBody;
                drift.linearVelocity += pseudoLinear[i] + contactProjectionLinear[i];
                drift.angularVelocity += pseudoAngular[i] + contactProjectionAngular[i];
                AppendDynamicRigidMotion(interval[i], MakeHandle(s.slot).id, drift, 0, h);
                const auto next = interval[i].back().Evaluate(h);
                body.rigidBody.position = next.position;
                body.rigidBody.orientation = next.orientation;
                body.rigidBody.angularVelocity = TransportAngularVelocity(body.rigidBody.inverseInertiaLocal,
                    oldOrientation, next.orientation, realSpin);
                body.motion.SetRecorded(interval[i]);
            } else if (s.kinematic && !kinematicPaths[s.slot].Segments().empty()) {
                std::vector<RigidMotionSegment> local;
                for (const auto& original : kinematicPaths[s.slot].Segments()) {
                    const double first = std::max(begin, original.begin), last = std::min(end, original.end);
                    if (first >= last) continue;
                    auto segment = original;
                    const auto pose = original.Evaluate(first);
                    segment.begin = first-begin; segment.end = last-begin;
                    segment.position = pose.position; segment.orientation = pose.orientation;
                    const auto finish = original.EvaluateGeometry(last);
                    segment.endPosition = finish.position; segment.endOrientation = finish.orientation;
                    local.push_back(segment);
                }
                body.motion.SetRecorded(std::move(local));
                const auto pose = body.motion.EvaluateGeometryAfterEvents(h);
                body.rigidBody.position = pose.position; body.rigidBody.orientation = pose.orientation;
            }
            s.dp = glm::vec3(glm::dvec3(body.rigidBody.position)-glm::dvec3(s.x0));
            s.dq = glm::mat3_cast(body.rigidBody.orientation*glm::conjugate(s.q0));
            InvalidateImpactPose(s.slot);
        }
        mk2RowPairs.clear(); mk2RowEndSeparation.clear();
        for (std::size_t i=0; i<rows.size() && i<pendingCache.size(); ++i) {
            if (rows[i].deferredImpact) continue;
            const auto& key = pendingCache[i].key;
            const std::array<unsigned,4> pair{key.slotA,key.slotB,unsigned(key.partA),unsigned(key.partB)};
            const float gap = glm::dot(AnchorGap(state[rows[i].a],state[rows[i].b],rows[i]), rows[i].n)+rows[i].separation;
            if (mk2RowPairs.empty() || mk2RowPairs.back()!=pair) {mk2RowPairs.push_back(pair);mk2RowEndSeparation.push_back(gap);}
            else mk2RowEndSeparation.back() = std::min(mk2RowEndSeparation.back(),gap);
        }
        Mk2Continuous(h, &requiredContinuous, &continuousArrivals, &continuousEvents);
        for (std::size_t i=0; i<state.size(); ++i) {
            auto& s = state[i]; auto& body = bodies[s.slot];
            if (s.dynamic) for (auto segment : body.motion.Segments()) {
                segment.begin += begin; segment.end += begin;
                segments[i].push_back(segment);
            }
            s.dp = glm::vec3(glm::dvec3(body.rigidBody.position)-glm::dvec3(s.x0));
            s.dq = glm::mat3_cast(body.rigidBody.orientation*glm::conjugate(s.q0));
            if (s.kinematic) body.motion = kinematicPaths[s.slot];
        }
'''+s[end:]
# Continuous handling has already completed each authoritative interval.
s=s.replace('    Mk2Continuous(dt);','')
s=s.replace('void PhysicsWorld::Impl::Mk2Continuous(float dt) {', '''void PhysicsWorld::Impl::Mk2Continuous(float dt, const std::vector<char>* required,
    std::vector<unsigned>* arrivalCounts, unsigned* eventCount) {''')
s=s.replace('    const auto fastReach = [&](unsigned slot) {\n', '    const auto fastReach = [&](unsigned slot) {\n        if (required && slot<required->size() && (*required)[slot]) return true;\n',1)
# Publish response states at the event, not endpoint velocities with event inertia.
s=s.replace('    RigidBody bodyA = bodies[a].rigidBody, bodyB = bodies[b].rigidBody;', '    RigidBody bodyA = PoseAt(a, hit), bodyB = PoseAt(b, hit);')
s=s.replace('            bodies[slot].rigidBody.linearVelocity = copy->linearVelocity;\n            bodies[slot].rigidBody.angularVelocity = copy->angularVelocity;', '            bodies[slot].rigidBody.position = copy->position;\n            bodies[slot].rigidBody.orientation = copy->orientation;\n            bodies[slot].rigidBody.linearVelocity = copy->linearVelocity;\n            bodies[slot].rigidBody.angularVelocity = copy->angularVelocity;')
# Retime uses the post-response event state. An unresolved hold samples its own path.
s=s.replace('const auto retime = [&](unsigned slot, double at, bool hold)', 'const auto retime = [&](unsigned slot, double at, bool hold, bool resolved = true)')
s=s.replace('        auto &body = bodies[slot];\n        std::vector<RigidMotionSegment> kept;', '        auto &body = bodies[slot];\n        if (!resolved) body.rigidBody = body.motion.EvaluateAfterEvents(at);\n        std::vector<RigidMotionSegment> kept;',1)
# Use a full consistent rotation trajectory for continuation after the event.
start=s.index('        if (hold) {\n            next.linearVelocity')
end=s.index('        InvalidateImpactPose(slot);',start)
s=s[:start]+'''        if (hold) {
            next.linearVelocity = next.angularVelocity = next.driftAngularVelocity = glm::vec3(0);
            next.endPosition = next.position; next.endOrientation = next.orientation;
            kept.push_back(next);
            body.rigidBody.position = next.position; body.rigidBody.orientation = next.orientation;
        } else {
            std::vector<RigidMotionSegment> tail;
            AppendDynamicRigidMotion(tail, next.owner, body.rigidBody, at, dt);
            const auto endpoint = tail.back().Evaluate(dt);
            kept.insert(kept.end(),tail.begin(),tail.end());
            body.rigidBody.position = endpoint.position; body.rigidBody.orientation = endpoint.orientation;
            body.rigidBody.angularVelocity = endpoint.angularVelocity;
        }
        body.motion.SetRecorded(std::move(kept));
'''+s[end:]
s=s.replace('        int arrivals = 0;', '        unsigned arrivals = 0;')
s=s.replace('movers.push_back({other, at, false});','movers.push_back({other, at, false, arrivalCounts ? (*arrivalCounts)[other] : 0u});')
s=s.replace('movers.push_back({slot, 0, true});','movers.push_back({slot, 0, true, arrivalCounts ? (*arrivalCounts)[slot] : 0u});')
s=s.replace('        ++m->arrivals;','        ++m->arrivals;\n        if (arrivalCounts) (*arrivalCounts)[other] = m->arrivals;')
s=s.replace('            ++next->arrivals;','            ++next->arrivals;\n            if (arrivalCounts) (*arrivalCounts)[slot] = next->arrivals;')
s=s.replace('for (int events = 0; events < kMk2ArrivalsPerStep; ++events)', 'for (unsigned events = eventCount ? *eventCount : 0; events < kMk2ArrivalsPerStep; ++events)')
s=s.replace('        const unsigned slot = next->slot, other = next->other;', '        if (eventCount) ++*eventCount;\n        const unsigned slot = next->slot, other = next->other;')
s=s.replace('            retime(slot, at, true);','            retime(slot, at, true, resolved);')
s=s.replace('            Mk2ResolveArrival(m.slot, m.other, m.partA, m.partB, m.hit);\n            retime(m.slot, m.hit, true);','            const bool resolved = Mk2ResolveArrival(m.slot, m.other, m.partA, m.partB, m.hit);\n            retime(m.slot, m.hit, true, resolved);')
p.write_text(s)
p=Path('src/physics/WorldInternal.h');s=p.read_text().replace('void Mk2Continuous(float dt);','void Mk2Continuous(float dt, const std::vector<char>* required = nullptr,\n        std::vector<unsigned>* arrivalCounts = nullptr, unsigned* eventCount = nullptr);');p.write_text(s)
