from pathlib import Path
import subprocess,time,json,hashlib
root=Path.cwd();out=root/'.cache/mk2-rotation-repair/combined21';out.mkdir(exist_ok=False)
tests=[('rotation',['judas_mk2_rotation_tests']),('physical-continuation',['judas_physics_continuation_tests']),('diagnostics',['judas_mk2_diagnostics_tests']),('kinematic',['judas_kinematic_tests']),('rigid-motion',['judas_rigid_motion_tests']),('motion-bounds',['judas_rigid_motion_bounds_tests']),('ragdoll',['judas_ragdoll_tests']),('collision-geometry',['judas_collision_geometry_tests']),('curved-mesh',['judas_impact_mesh_cost_tests','60','','1.2'])]
results=[]
for name,args in tests:
 command=[str(root/'build'/args[0])]+args[1:];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  try: code=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
  except subprocess.TimeoutExpired: code='timeout'
 results.append(dict(name=name,command=command,returncode=code,seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(Path(command[0]).read_bytes()).hexdigest()))
 (out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,code,flush=True)
