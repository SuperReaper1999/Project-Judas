#include "RigidMotion.h"
#include <cstdio>
#include <chrono>
int main(){setvbuf(stdout,nullptr,_IONBF,0);for(float rate:{1.f,5.f,20.f,100.f,1000.f}){
 RigidBody b;b.inverseMass=1;b.inverseInertiaLocal=SolidBoxInverseInertia(1,{.08f,.2f,.05f});b.angularVelocity={rate,.7f*rate,.3f*rate};
 auto energy=[](const RigidBody& x){glm::dvec3 w(x.angularVelocity);return .5*glm::dot(w,glm::inverse(glm::dmat3(x.InverseInertiaWorld()))*w);};
 auto start=std::chrono::steady_clock::now();RigidMotion path;path.Begin(1,b,1./60,true);auto next=path.EvaluateAfterEvents(1./60);
 std::printf("rate %g leaves %zu E %.12g -> %.12g ratio %.12g us %.3f\n",rate,path.Segments().size(),energy(b),energy(next),energy(next)/energy(b),std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count());
}}
