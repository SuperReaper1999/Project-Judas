from pathlib import Path
import subprocess,shlex,sys
r=Path.cwd();build=r/'build';args=shlex.split((build/'CMakeFiles/judas_mk2_physics_tests.dir/link.txt').read_text());source=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve();obj=output.with_suffix('.o');subprocess.run(['c++','-O3','-DNDEBUG','-DM87_ALLOCATION_DIAGNOSTICS','-std=gnu++17','-I'+str(r/'src'),'-c',str(source),'-o',str(obj)],check=True)
args=[x for x in args if not x.startswith('-Wl,--dependency-file=') and '/tests/ValidationMain.cpp.o' not in x];first=next(i for i,x in enumerate(args) if '/tests/Mk2PhysicsTests.cpp.o' in x);args[first]=str(obj);args[args.index('-o')+1]=str(output);args += [str(r/'.cache/mk2-rotation-repair/baseline-libs/libjudas_engine.a')]; subprocess.run(args,cwd=build,check=True)
