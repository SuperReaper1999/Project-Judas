from pathlib import Path
import subprocess,shlex,hashlib,json
r=Path.cwd();b=r/'build';base=r/'.cache/mk2-rotation-repair/baseline-source';out=r/'.cache/mk2-rotation-repair/scaling-baseline-production';old=base/'tests/PhysicsScalingBenchmarks.cpp';new=r/'tests/PhysicsScalingBenchmarks.cpp'
assert old.read_bytes()==new.read_bytes(),'benchmark driver changed'
flags={}
for line in (b/'CMakeFiles/judas_physics_scaling_benchmarks.dir/flags.make').read_text().splitlines():
 if line.startswith(('CXX_DEFINES =','CXX_INCLUDES =','CXX_FLAGS =')):
  k,v=line.split('=',1);flags[k.strip()]=shlex.split(v.replace(str(r/'src'),str(base/'src')))
cmd=['c++']+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-c',str(old),'-o',str(out)+'.o'];subprocess.run(cmd,check=True)
args=shlex.split((b/'CMakeFiles/judas_physics_scaling_benchmarks.dir/link.txt').read_text());args=[x for x in args if not x.startswith('-Wl,--dependency-file=')];args[next(i for i,x in enumerate(args) if 'PhysicsScalingBenchmarks.cpp.o' in x)]=str(out)+'.o';args[args.index('-o')+1]=str(out);args[args.index('libjudas_engine.a')]=str(r/'.cache/mk2-rotation-repair/baseline-libs/libjudas_engine.a');subprocess.run(args,cwd=b,check=True)
Path(str(out)+'.json').write_text(json.dumps(dict(input_commit='bded63dfdaefdeec6484d66b3211712c200c2941',driver_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),library_sha256=hashlib.sha256((r/'.cache/mk2-rotation-repair/baseline-libs/libjudas_engine.a').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),compile=cmd,link=args,allocation_diagnostics=False,note='Same current production benchmark target flags; archived input-revision headers/driver and frozen input-revision physics engine archive. Shared unchanged supporting libraries from current build. BuildIdentity alone is not this baseline provenance.'),indent=2)+'\n')
p=r/'.cache/mk2-rotation-repair/benchmark-final30.py';s=p.read_text().replace('/performance30\'','/performance-matched30\'').replace("/scaling-baseline'","/scaling-baseline-production'");(r/'.cache/mk2-rotation-repair/benchmark-production30.py').write_text(s)
