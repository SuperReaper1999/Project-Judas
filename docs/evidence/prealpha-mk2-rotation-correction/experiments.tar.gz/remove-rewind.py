from pathlib import Path
p=Path('src/physics/WorldMk2Solver.cpp');s=p.read_text()
a=s.index('        // Impacts at their arrival instant.');b=s.index('        std::vector<char> impacting',a)
s=s[:a]+'''        // Resolve contacts already present at this configuration. Open gaps
        // belong to the chronological CCD pass, never to a future trial pose
        // followed by a rewind. Poisson restitution uses one material factor
        // for each manifold's compression impulse.
'''+s[b:]
s=s.replace('        std::vector<float> arrival(state.size(), 2.0f), impactNormal;\n        std::vector<glm::vec3> impactLinear, impactAngular;','        std::vector<float> impactNormal;')
a=s.index('                for (const unsigned body : {row.a, row.b})\n                    if (state[body].dynamic)\n                        arrival[body]');b=s.index('            }\n        if (anyImpact)',a);s=s[:a]+s[b:]
a=s.index('            // One instant per coupled set:');b=s.index('            std::vector<std::size_t> impactingList',a);s=s[:a]+s[b:]
a=s.index('            impactLinear.resize');b=s.index('            // At the arrival configuration each arriving pair',a)
s=s[:a]+'''            const std::vector<char> unchanged(state.size(), 0);
            std::vector<char> recollided(blocks.size(), 0);
'''+s[b:]
s=s.replace('            refreshChanged(moved, recollided);','            refreshChanged(unchanged, recollided);')
a=s.index('            for (std::size_t i = 0; i < state.size(); ++i) {\n                state[i].rb->position = startPose');b=s.index('            each([&](std::size_t i) {\n                rows[i].normalImpulse = warmNormal',a);s=s[:a]+s[b:]
a=s.index('            for (std::size_t i = 0; i < state.size(); ++i) {\n                impactLinear[i] =');b=s.index('        }\n        // Warm start',a);s=s[:a]+s[b:]
s=s.replace('''            arrival.resize(state.size(), 2.0f);
            if (!impactLinear.empty()) {
                impactLinear.resize(state.size());
                impactAngular.resize(state.size());
            }
''','')
p.write_text(s)
