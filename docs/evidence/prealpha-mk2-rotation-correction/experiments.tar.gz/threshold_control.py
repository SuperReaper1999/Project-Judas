from pathlib import Path
import subprocess,shlex,hashlib,json
r=Path.cwd();out=r/'.cache/mk2-rotation-repair/threshold-control';out.mkdir(exist_ok=False)
source=r/'src/physics/WorldMk2Solver.cpp';modified=source.read_text().replace('constexpr float kMk2RestitutionThreshold = 0.5f;','constexpr float kMk2RestitutionThreshold = 0.0f;');(out/'WorldMk2Solver.cpp').write_text(modified)
flags={}
for line in (r/'build/CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith(('CXX_FLAGS =','CXX_DEFINES =','CXX_INCLUDES =')):
  k,v=line.split('=',1);flags[k.strip()]=shlex.split(v)
cmd=['c++']+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-I'+str(r/'src/physics'),'-c',str(out/'WorldMk2Solver.cpp'),'-o',str(out/'WorldMk2Solver.o')]
with (out/'build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
args=shlex.split((r/'build/CMakeFiles/judas_mk2_diagnostics_tests.dir/link.txt').read_text());args=[a for a in args if not a.startswith('-Wl,--dependency-file=') and '/tests/ValidationMain.cpp.o' not in a];args[next(i for i,a in enumerate(args) if '/tests/Mk2DiagnosticsTests.cpp.o' in a)]=str(r/'.cache/mk2-rotation-repair/energy-trace28.o');args.insert(args.index('libjudas_engine.a'),str(out/'WorldMk2Solver.o'));args[args.index('-o')+1]=str(out/'trace');subprocess.run(args,cwd=r/'build',check=True)
(out/'PROVENANCE.json').write_text(json.dumps(dict(purpose='Diagnostic counterfactual ONLY. Production cutoff remains 0.5 m/s; no acceptance threshold is changed.',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),modified_sha256=hashlib.sha256(modified.encode()).hexdigest(),compile=cmd,link=args),indent=2)+'\n')
for mixed in ['0','1']:
 with (out/('spin-'+mixed+'.csv')).open('w') as f,(out/('spin-'+mixed+'-summary.log')).open('w') as e:subprocess.run([str(out/'trace'),'5','20','3600',mixed],stdout=f,stderr=e,check=True,timeout=60)
