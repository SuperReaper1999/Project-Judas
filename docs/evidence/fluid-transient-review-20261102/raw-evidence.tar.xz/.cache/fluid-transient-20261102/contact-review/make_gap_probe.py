from pathlib import Path
import json
p=Path(__file__).resolve().parent
rows=json.loads((p/'captured-rows.json').read_text())
def f(v):
 s=format(v,'.10g')
 if '.' not in s and 'e' not in s:s+='.0'
 return s+'f'
def vec(v):return '{'+','.join(map(f,v))+'}'
fixtures=[]
for r in rows:
 cs=','.join('{'+','.join([vec(c['point']),vec(c['normal']),vec(c['wall']),f(c['gap'])])+'}' for c in r['contacts'])
 fixtures.append('{"236/'+str(r['sub'])+'/'+str(r['particle'])+'",'+vec(r['position'])+','+vec(r['velocity'])+',{'+cs+'}}')
s=r'''#include "ContactSolver.h"
#include "RigidBody.h"
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
struct Row {glm::vec3 point,normal,wall;float gap;};
struct Fixture {const char* name;glm::vec3 point,velocity;std::vector<Row> rows;};
int failures=0;
void Run(const Fixture& fixture,bool gaps,float h){
 RigidBody particle;particle.position=fixture.point;particle.linearVelocity=fixture.velocity;particle.inverseMass=1.f/125;
 std::vector<RigidBody> walls(fixture.rows.size());ContactSolver solver;
 for(size_t k=0;k<walls.size();++k){const auto& row=fixture.rows[k];auto& wall=walls[k];wall.position=row.point;wall.linearVelocity=row.wall;
  Contact c;c.hit=true;c.point=row.point;c.normal=row.normal;c.preciseNormal=glm::dvec3(row.normal);c.hasLocalAnchors=true;c.localAnchorA=glm::dvec3(row.point)-glm::dvec3(particle.position);c.localAnchorB={0,0,0};c.signedSeparation=gaps?row.gap:0;
  solver.AddContact(particle,wall,c,0,0);
 }
 solver.Prepare(h);solver.SolveVelocities(64);
 const auto v=particle.linearVelocity;float minimumPredictedGap=1e9,impulse=0;
 for(size_t k=0;k<walls.size();++k){const auto& row=fixture.rows[k];const auto& solved=solver.Constraints()[k];
  const float prediction=row.gap+h*glm::dot(row.normal,v-row.wall);minimumPredictedGap=std::min(minimumPredictedGap,prediction);impulse+=solved.normalImpulse;
  std::printf("ROW %s gaps=%d k=%zu actualGap=%.9g normalTarget=%.9g predictedEndGap=%.9g impulse=%.9g\n",fixture.name,gaps,k,row.gap,solved.restitutionBias,prediction,solved.normalImpulse);
 }
 std::printf("RESULT %s gaps=%d before=(%.9g,%.9g,%.9g) after=(%.9g,%.9g,%.9g) delta=%.9g minimumLinearGap=%.9g\n",fixture.name,gaps,fixture.velocity.x,fixture.velocity.y,fixture.velocity.z,v.x,v.y,v.z,glm::length(v-fixture.velocity),minimumPredictedGap);
 if(gaps&&minimumPredictedGap< -1e-6)++failures;
 if(gaps&&std::string(fixture.name).find("236/")==0 && glm::length(v-fixture.velocity)>1e-6)++failures;
}
int main(){const float h=(1.f/30)/3;
 std::vector<Fixture> fixtures={FIXTURES};
 for(const auto& fixture:fixtures){Run(fixture,false,h);Run(fixture,true,h);}
 auto one=fixtures.front();one.name="captured-no-floor";one.rows.erase(one.rows.begin());Run(one,false,h);Run(one,true,h);
 auto stationary=fixtures.front();stationary.name="captured-stationary";for(auto& row:stationary.rows)row.wall={0,0,0};Run(stationary,false,h);Run(stationary,true,h);
 for(const auto& fixture:std::vector<Fixture>{
  {"separated-safe",{0,.1f,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},.1f}}},
  {"true-crossing",{0,.005f,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},.005f}}},
  {"actual-touch",{0,0,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},0}}},
  {"moving-wall-crossing",{0,.005f,0},{0,0,0},{{{0,0,0},{0,1,0},{0,1,0},.005f}}}
 })Run(fixture,true,h);
 std::printf("FAILURES %d\n",failures);return failures?1:0;
}
'''
s=s.replace('FIXTURES',','.join(fixtures))
(p/'gap_probe.cpp').write_text(s)
