#include "ContactSolver.h"
#include "RigidBody.h"
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
struct Row {glm::vec3 point,normal,wall;float gap;};
struct Fixture {const char* name;glm::vec3 point,velocity;std::vector<Row> rows;};
int failures=0;
void Run(const Fixture& fixture,bool gaps,float h){
 RigidBody particle;particle.position=fixture.point;particle.linearVelocity=fixture.velocity;particle.inverseMass=1.f/125;
 std::vector<RigidBody> walls(fixture.rows.size());ContactSolver solver;
 for(size_t k=0;k<walls.size();++k){const auto& row=fixture.rows[k];auto& wall=walls[k];wall.position=row.point;wall.linearVelocity=row.wall;
  Contact c;c.hit=true;c.point=row.point;c.normal=row.normal;c.preciseNormal=glm::dvec3(row.normal);c.hasLocalAnchors=true;c.localAnchorA=glm::dvec3(row.point)-glm::dvec3(particle.position);c.localAnchorB={0,0,0};c.signedSeparation=gaps?row.gap:0;
  solver.AddContact(particle,wall,c,0,0);
 }
 solver.Prepare(h);solver.SolveVelocities(64);
 const auto v=particle.linearVelocity;float minimumPredictedGap=1e9,impulse=0;
 for(size_t k=0;k<walls.size();++k){const auto& row=fixture.rows[k];const auto& solved=solver.Constraints()[k];
  const float prediction=row.gap+h*glm::dot(row.normal,v-row.wall);minimumPredictedGap=std::min(minimumPredictedGap,prediction);impulse+=solved.normalImpulse;
  std::printf("ROW %s gaps=%d k=%zu actualGap=%.9g normalTarget=%.9g predictedEndGap=%.9g impulse=%.9g\n",fixture.name,gaps,k,row.gap,solved.restitutionBias,prediction,solved.normalImpulse);
 }
 std::printf("RESULT %s gaps=%d before=(%.9g,%.9g,%.9g) after=(%.9g,%.9g,%.9g) delta=%.9g minimumLinearGap=%.9g\n",fixture.name,gaps,fixture.velocity.x,fixture.velocity.y,fixture.velocity.z,v.x,v.y,v.z,glm::length(v-fixture.velocity),minimumPredictedGap);
 if(gaps&&minimumPredictedGap< -1e-6)++failures;
 if(gaps&&std::string(fixture.name).find("236/")==0 && glm::length(v-fixture.velocity)>1e-6)++failures;
}
int main(){const float h=(1.f/30)/3;
 std::vector<Fixture> fixtures={{"236/0/217",{-5.27450609f,0.125327468f,-3.07384658f},{-0.263729572f,-0.226283818f,-0.252897322f},{{{-5.27477217f,0.0f,-3.07752466f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.125327468f},{{-5.27431536f,0.311240971f,-2.9920404f},{0.00485873409f,-0.997732878f,0.0671230927f},{0.0629138947f,-6.1229682f,-5.90452909f},0.180000007f}}},{"236/0/242",{-4.7592659f,0.135448575f,-2.9606998f},{1.29506147f,-0.275553763f,-0.733124495f},{{{-4.75948286f,0.0f,-2.96369696f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.135448575f},{{-4.76014042f,0.315040529f,-2.9727819f},{0.00485873409f,-0.997732878f,0.0671230927f},{0.0664758682f,-6.05304813f,-6.00855589f},0.180000022f}}},{"236/1/217",{-5.26242256f,0.080542922f,-2.81909704f},{0.676239371f,-4.35574961f,17.6923599f},{{{-5.26305437f,0.0f,-2.82643199f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.080542922f},{{-5.26356316f,0.260051847f,-2.83233571f},{0.00633741496f,-0.997271538f,0.0735484213f},{0.102782249f,-5.97129965f,-5.84290266f},0.180000052f}}},{"236/1/242",{-4.73157501f,0.0889443159f,-2.75092077f},{2.20892859f,-4.70229912f,14.8577623f},{{{-4.73215389f,0.0f,-2.75763607f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.0889443159f},{{-4.73271608f,0.268453181f,-2.76415944f},{0.00633741496f,-0.997271538f,0.0735484213f},{0.116429329f,-5.86845303f,-5.96012592f},0.179999992f}}},{"236/2/217",{-5.22701168f,0.0525422692f,-2.41045046f},{2.4040494f,-3.38514543f,29.741251f},{{{-5.22802162f,0.0f,-2.42066264f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.0525422692f},{{-5.22843361f,0.231961668f,-2.42482591f},{0.00789960381f,-0.996774435f,0.0798644051f},{0.202045441f,-5.67945671f,-5.7993865f},0.179999992f}}},{"236/2/242",{-4.69575977f,0.0594537854f,-2.3767364f},{2.84158254f,-3.6464932f,27.6755047f},{{{-4.69671535f,0.0f,-2.38639498f},{0.0f,1.0f,0.0f},{0.0f,0.0f,0.0f},0.0594537854f},{{-4.6971817f,0.238873184f,-2.39111209f},{0.00789960381f,-0.996774435f,0.0798644051f},{0.209040642f,-5.59412241f,-5.92324018f},0.180000007f}}}};
 for(const auto& fixture:fixtures){Run(fixture,false,h);Run(fixture,true,h);}
 auto one=fixtures.front();one.name="captured-no-floor";one.rows.erase(one.rows.begin());Run(one,false,h);Run(one,true,h);
 auto stationary=fixtures.front();stationary.name="captured-stationary";for(auto& row:stationary.rows)row.wall={0,0,0};Run(stationary,false,h);Run(stationary,true,h);
 for(const auto& fixture:std::vector<Fixture>{
  {"separated-safe",{0,.1f,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},.1f}}},
  {"true-crossing",{0,.005f,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},.005f}}},
  {"actual-touch",{0,0,0},{0,-1,0},{{{0,0,0},{0,1,0},{0,0,0},0}}},
  {"moving-wall-crossing",{0,.005f,0},{0,0,0},{{{0,0,0},{0,1,0},{0,1,0},.005f}}}
 })Run(fixture,true,h);
 std::printf("FAILURES %d\n",failures);return failures?1:0;
}
