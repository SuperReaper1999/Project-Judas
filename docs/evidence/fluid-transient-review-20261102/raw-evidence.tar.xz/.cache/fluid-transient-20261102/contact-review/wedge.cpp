#include "PhysicsWorld.h"
#include <cmath>
#include <cstdio>
#include <vector>
void Run(float degrees,float speed,bool floor,bool finite) {
    PhysicsWorld world;world.Init();
    const float theta=degrees*3.14159265358979323846f/180;
    const glm::vec3 n(0,-std::cos(theta),std::sin(theta));
    const glm::vec3 point(100,100,100);
    auto body=finite?world.CreateDynamicBox(point,glm::vec3(.1f),2000,0,0):BodyHandle{};
    if(finite)world.SetLinearVelocity(body,{0,-speed,0});
    std::vector<PhysicsWorld::ContactParticle> particles{{point,{0,0,0},125}};
    std::vector<PhysicsWorld::ParticleBoundaryContact> rows;
    if(floor)rows.push_back({0,{},point,{0,1,0},{0,0,0},false});
    rows.push_back({0,body,point,n,{0,-speed,0},finite});
    std::vector<glm::vec3> impulse;world.SolveParticleContacts(particles,rows,impulse);
    const auto stats=world.GetParticleContactStats();const auto v=particles[0].velocity;
    double energy=.5*125*glm::dot(v,v);
    if(finite){auto u=world.GetLinearVelocity(body);energy+=.5*2000*glm::dot(u,u);}
    std::printf("theta=%g U=%g floor=%d finite=%d v=(%.9g,%.9g,%.9g) speed=%.9g exact_prescribed_wedge_z=%.9g residual=%.9g cap=%d iterations=%d boundaryDeclines=%d KE=%.9g finite_initial_KE=%.9g\n",degrees,speed,floor,finite,v.x,v.y,v.z,glm::length(v),speed/std::tan(theta),stats.maximumClosingSpeed,stats.iterationCapReached,stats.iterations,stats.normalAccelerationBoundaryDeclines,energy,.5*2000*speed*speed);
}
int main(){Run(45,8,true,false);Run(11,8,true,false);Run(2,8,true,false);Run(11,8,false,false);Run(11,0,true,false);Run(11,8,true,true);}
