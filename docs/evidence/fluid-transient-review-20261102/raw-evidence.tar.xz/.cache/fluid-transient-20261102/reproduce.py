#!/usr/bin/env python3
"""Rebuild disposable probes using an existing matching Unix Makefiles build.
No production source edits. Optional full pool instrumentation is CPU-only.
Run from the repository root: python3 PATH/reproduce.py BUILD [--full-pool]
"""
import argparse
from pathlib import Path
import shlex
import subprocess
p=argparse.ArgumentParser()
p.add_argument("build",type=Path)
p.add_argument("--full-pool",action="store_true")
a=p.parse_args(); build=a.build.resolve(); here=Path(__file__).resolve().parent
out=here/"reproduction"; out.mkdir(exist_ok=True)
target=build/"CMakeFiles/judas_rendering_architecture_tests.dir"
flags=(target/"flags.make").read_text()
def values(key):
    return shlex.split(next(line.split(" = ",1)[1] for line in flags.splitlines() if line.startswith(key+" = ")))
link=shlex.split((target/"link.txt").read_text())
libs=link[link.index("libjudas_engine.a"):]
compile_args=["c++",*values("CXX_DEFINES"),*values("CXX_INCLUDES"),*values("CXX_FLAGS")]
def command(args):
    print(shlex.join(map(str,args)),flush=True)
    subprocess.run(list(map(str,args)),cwd=build,check=True)
def probe(source,name,extra=()):
    binary=out/name
    command([*compile_args,source,*extra,"-o",binary,*libs])
    with (out/(name+".log")).open("w") as log:
        subprocess.run([str(binary)],cwd=Path.cwd(),stdout=log,stderr=subprocess.STDOUT,check=True)
probe(here/"contact-review/wedge.cpp","wedge")
probe(here/"contact-review/gap_probe.cpp","gap_probe")
if a.full_pool:
    obj=out/"FluidWorld-feature.o"
    command([*compile_args,"-c",here/"FluidWorld-feature.cpp","-o",obj])
    probe(here/"pool_probe.cpp","feature_probe",[obj])
print("Results:",out)
