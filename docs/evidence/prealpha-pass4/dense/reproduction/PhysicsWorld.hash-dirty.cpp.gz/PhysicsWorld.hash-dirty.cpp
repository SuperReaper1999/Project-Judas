#include "PerformanceProfiler.h"
#include "JobSystem.h"
#include <exception>
#include "PhysicsWorld.h"
#include "CollisionAsset.h"
#include "CollisionGeometry.h"
#include "SaveArchive.h"
#include "PhysicsCastGeometry.h"
#include "OriginLimits.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <limits>
#include <map>
#include <optional>
#include <set>
#include <stdexcept>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <tuple>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "Broadphase.h"
#include "CollisionShapes.h"
#include "ContactSolver.h"
#include "Contacts.h"
#include "Narrowphase.h"
#include "RadialTerrain.h"
#include "RigidBody.h"
#include "RigidMotion.h"
#include "RigidMotionBounds.h"
#include "ImpactSolver.h"
#include "ImpactPairVisitSet.h"
#include "JointSolver.h"
#include <atomic>

// Judas's own rigid-body physics — no middleware. Collision detection,
// contact generation, contact resolution, and integration are all owned
// here, built from RigidBody (state/integration), Contacts (narrowphase),
// and ContactSolver (impulse resolution). See docs/ARCHITECTURE.md,
// "Physics ownership" for the migration this replaces (Jolt Physics,
// used through the first Milestone 7-Final attempt) and why: no subsystem here — broadphase,
// narrowphase, contact resolution, the player's sweep query — assumes a
// world-space up axis; every one of them is expressed purely in terms of
// the shapes' and bodies' own positions/orientations. Judas already owned
// gravity, reference frames, and world coordinates before this milestone;
// this closes the remaining gap (collision/contact/rigid-body solving)
// that used to belong to Jolt.
namespace {

using Clock = std::chrono::steady_clock;
double MillisecondsBetween(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::milli>(b - a).count();
}

// Per-step aggregate diagnostics keep CCD searches bounded in M56: recording a
// scope for every predicate would overflow a frame's event lane. Nested work in
// the same category is counted once; categories are inclusive, not additive.
struct PhysicsWorkSample {std::uint64_t nanoseconds=0,calls=0;unsigned depth=0;};
class PhysicsWorkTimer {
public:
    PhysicsWorkTimer(PhysicsWorkSample& value,bool enabled):sample(enabled?&value:nullptr){
        if(sample){outer=sample->depth++==0;++sample->calls;if(outer)start=Clock::now();}
    }
    ~PhysicsWorkTimer(){if(sample&&--sample->depth==0&&outer)
        sample->nanoseconds+=std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count());}
    PhysicsWorkTimer(const PhysicsWorkTimer&)=delete;
private:PhysicsWorkSample* sample;bool outer=false;Clock::time_point start{};
};

bool FiniteVector(glm::vec3 v) {return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);}
bool UsableVelocity(glm::vec3 v) {return FiniteVector(v)&&std::isfinite(glm::length(v));}
bool UsableKinematicPose(const BodyTransform& pose) {
    const double norm=glm::dot(glm::dquat(pose.rotation),glm::dquat(pose.rotation));
    return FiniteVector(pose.position)&&std::isfinite(norm)&&norm>1e-12&&norm<1e12;
}
bool KinematicShape(const Shape& shape) {
    if(shape.type==ShapeType::Box||shape.type==ShapeType::Sphere||shape.type==ShapeType::ConvexHull)return true;
    if(shape.type!=ShapeType::CompoundBoxes||shape.boxes.empty())return false;
    return std::all_of(shape.boxes.begin(),shape.boxes.end(),[](const auto& c){
        return c.type==ShapeType::Box||c.type==ShapeType::Sphere||c.type==ShapeType::ConvexHull;});
}

// Milestone 32: how far a proxy's fat bound extends past its tight bound.
// A body that moves less than this within its fat box costs the tree
// nothing; one that escapes is reinserted. Static bodies use the same
// margin (only kinematically-driven static bodies such as doors move).
constexpr float kBroadphaseMargin = 0.1f;
// Continuous-impact stall cutoff: this many consecutive conservative advances,
// each covering less than this fraction of the interval still to search. Chosen
// from a sweep of 2-12 advances and 0.5-5% (docs/evidence/ccd-mesh-contacts):
// fewer advances also cut off ordinary short stalls on flat meshes, slower there.
constexpr int kImpactStallAdvances=8;
constexpr double kImpactStallFraction=.05;
// Tolerance added to the player sweep's query box.
constexpr float kSweepQueryEpsilon = 1.0e-3f;
// Warm starting: a new contact inherits last step's converged impulses from
// the same body pair/primitive pair when its anchor (in body A's frame) is
// within this distance of a cached one and the normals agree.
constexpr float kWarmStartAnchorDistance = 0.05f;
constexpr float kWarmStartNormalDot = 0.9f;

struct ContactKey {
    unsigned int slotA = 0, slotB = 0;
    unsigned int generationA = 0, generationB = 0;
    int partA = 0, partB = 0;
    bool operator<(const ContactKey& o) const {
        return std::tie(slotA, slotB, partA, partB) < std::tie(o.slotA, o.slotB, o.partA, o.partB);
    }
    bool SameBodies(const ContactKey& o) const {
        return slotA == o.slotA && slotB == o.slotB && partA == o.partA && partB == o.partB &&
               generationA == o.generationA && generationB == o.generationB;
    }
};
struct CachedContact {
    ContactKey key;
    glm::dvec3 localAnchorA{0.0};
    glm::vec3 normal{0.0f};
    float normalImpulse = 0.0f;
    glm::vec3 tangentImpulse{0.0f};
    float separation=0;
    uint64_t observationRevisionA=0,observationRevisionB=0;
};

std::vector<BodyBox> BoxesAt(const Shape& shape, const glm::vec3& position,
                              const glm::quat& orientation) {
    std::vector<BodyBox> boxes;
    if (shape.type == ShapeType::Box) {
        boxes.push_back({position, orientation, shape.halfExtents});
    } else if (shape.type == ShapeType::CompoundBoxes) {
        boxes.reserve(shape.boxes.size());
        for (const CompoundBox& child : shape.boxes) {
            if(child.type!=ShapeType::Box)continue;
            boxes.push_back({position + orientation * (child.localCenter-shape.pivotOffset),
                             glm::normalize(orientation*child.rotation), child.halfExtents});
        }
    }
    return boxes;
}

glm::mat3 CompoundInverseInertia(float mass, const std::vector<CompoundBox>& boxes) {
    float totalVolume = 0.0f;
    for (const CompoundBox& box : boxes) {
        totalVolume += 8.0f * box.halfExtents.x * box.halfExtents.y * box.halfExtents.z;
    }
    if (mass <= 0.0f || totalVolume <= 0.0f) return glm::mat3(0.0f);

    // Uniform density, with the parallel-axis theorem for each child. The
    // resulting full tensor includes products of inertia when the geometry
    // is asymmetric; RigidBody rotates it to world space as usual.
    glm::mat3 inertia(0.0f);
    for (const CompoundBox& box : boxes) {
        const float childMass = mass *
            (8.0f * box.halfExtents.x * box.halfExtents.y * box.halfExtents.z / totalVolume);
        const glm::vec3 h = box.halfExtents;
        glm::mat3 tensor(0);tensor[0][0]=childMass*(h.y*h.y+h.z*h.z)/3;
        tensor[1][1]=childMass*(h.x*h.x+h.z*h.z)/3;tensor[2][2]=childMass*(h.x*h.x+h.y*h.y)/3;
        const glm::mat3 rotation(ContactRotation(box.rotation));inertia+=rotation*tensor*glm::transpose(rotation);
        const glm::vec3& r = box.localCenter;
        inertia += childMass * (glm::dot(r, r) * glm::mat3(1.0f) - glm::outerProduct(r, r));
    }
    return glm::determinant(inertia) > 1.0e-12f ? glm::inverse(inertia) : glm::mat3(0.0f);
}

}  // namespace

// Distance (and separating normal/owning body index) from the player's
// capsule, placed at a given segment, to the closest world body — used by
// SweepPlayerShape's substep march. `bodyIndex == -1` means no body was
// found closer than `distance`'s initial +infinity (never happens once any
// world geometry exists, but keeps the result total).
struct ClosestBodyResult {
    float distance = std::numeric_limits<float>::max();
    glm::vec3 normal{0.0f};
    int bodyIndex = -1;
    glm::vec3 point{0};
};

struct PhysicsWorld::Impl {
    const uint64_t worldToken=[](){static std::atomic<uint64_t> next{1};return next.fetch_add(1);}();
    struct PoseBound {
        glm::vec3 position{0};
        glm::quat orientation{1,0,0,0};
        Aabb bound;
        bool valid = false;
    };
    struct Body {
        RigidBody rigidBody;
        // Previous fixed-step pose for player movement sweeps against
        // dynamic targets; initialized together with the current pose and
        // refreshed immediately before every physics integration.
        glm::vec3 previousPosition{0.0f};
        RigidMotion motion;
        glm::quat previousOrientation{1.0f, 0.0f, 0.0f, 0.0f};
        Shape shape;
        // AddBody replaces the entire cache on slot reuse. Explicit static
        // geometry replacement invalidates shape-derived bounds in place.
        float boundingRadius = 0;
        std::optional<ContactPreparedOrientation> orientationCache;
        std::optional<PreparedShapeBounds> boundPreparation;
        bool boundPreparationValid = false;
        PoseBound currentBound, previousBound;
        unsigned collisionLayer=0;
        CategoryMask collisionMask=kAllCategories, tags=0;
        std::string physicalMaterial;
        float friction = 0.5f;
        float restitution = 0.0f;
        bool sensor = false, enabled = true, queryOnly=false, queriesEnabled=true, simulationSuspended=false;
        bool isDynamic = false, isKinematic=false;
        KinematicMotionState kinematic;
        double kinematicActiveDuration=0;
        bool HasMotion() const {return !simulationSuspended&&(isDynamic||isKinematic);}
        bool sleeping=false,deferredAcceleration=false;
        float quietSeconds=0;
        glm::vec3 lastAcceleration{0};
        bool alive = false;
        // Milestone 29: a slot is reused after DestroyBody; the generation
        // in the handle's upper bits makes a handle from a previous
        // occupant of the same slot invalid instead of aliasing the new one.
        unsigned int generation = 0;
        uint64_t contactObservationRevision=0; // invalidates only native observations, not solver warm starts
        // Milestone 32: this body's leaf in the broadphase tree.
        int proxy = DynamicAabbTree::kNull;
    };

    static constexpr unsigned int kSlotBits = 20;
    static constexpr unsigned int kSlotMask = (1u << kSlotBits) - 1u;

    std::vector<Body> bodies;
    // Slots of destroyed bodies awaiting reuse, and the sorted slots of
    // every live body — the loops below iterate this so a world whose
    // entities were unloaded pays for the bodies that exist, not for the
    // slots they once occupied.
    std::vector<unsigned int> freeSlots;
    std::vector<unsigned int> aliveSlots;
    std::vector<PhysicsWorld::DebugContact> lastStepContacts;
    using TouchKey=std::pair<unsigned,unsigned>;
    std::map<TouchKey,PhysicsWorld::TouchEvent> previousTouches,stepTouches,preStepQueryTouches;
    bool queryTouchesPending=false,collectingPreStepQueries=false,coupledStep=false,stepping=false;
    std::vector<PhysicsWorld::TouchEvent> touchEvents;
    void Observe(unsigned a,unsigned b,const Contact& c,float impulse=0,bool preStep=false) {
        auto ha=MakeHandle(a),hb=MakeHandle(b);
        bool flip=ha.id>hb.id;if(flip)std::swap(ha,hb);
        auto key=std::make_pair(ha.id,hb.id);
        auto& e=(preStep?preStepQueryTouches:stepTouches)[key];
        e.a=ha;e.b=hb;e.sensor=bodies[a].sensor||bodies[b].sensor;
        e.point=c.point;e.normal=flip?-c.normal:c.normal;
        const auto va=bodies[a].rigidBody.linearVelocity+glm::cross(bodies[a].rigidBody.angularVelocity,c.point-bodies[a].rigidBody.position);
        const auto vb=bodies[b].rigidBody.linearVelocity+glm::cross(bodies[b].rigidBody.angularVelocity,c.point-bodies[b].rigidBody.position);
        e.relativeVelocity=flip?va-vb:vb-va;e.normalImpulse+=impulse;
    }
    void FinishTouches() {
        touchEvents.clear();
        // Sensor overlap is discrete endpoint geometry, never speculative skin
        // or TOI response. Reuse the same tree, layer policy and narrowphase.
        if(std::any_of(aliveSlots.begin(),aliveSlots.end(),[&](unsigned i){return (bodies[i].sensor||bodies[i].isKinematic)&&bodies[i].enabled;})) {
            GenerateCandidatePairs();
            for(auto [a,b]:candidatePairs) if(bodies[a].sensor||bodies[b].sensor||
                ((bodies[a].isKinematic||bodies[b].isKinematic)&&bodies[a].rigidBody.IsStatic()&&bodies[b].rigidBody.IsStatic())) {
                const auto& oa=Orientation(bodies[a]);const auto& ob=Orientation(bodies[b]);
                for(int pa=0;pa<PrimitiveCount(bodies[a].shape);++pa)
                    for(int pb=0;pb<PrimitiveCount(bodies[b].shape);++pb) {
                        auto m=ComputeContacts(PrimitiveAt(bodies[a].shape,bodies[a].rigidBody,pa,&oa),PrimitiveAt(bodies[b].shape,bodies[b].rigidBody,pb,&ob),0,&oa,&ob);
                        if(m.count)Observe(a,b,m.points[0]);
                    }
            }
        }
        for(auto& [key,e]:stepTouches) {
            const auto old=previousTouches.find(key);
            if(old!=previousTouches.end()&&old->second.sensor!=e.sensor){auto exit=old->second;exit.phase=PhysicsWorld::TouchPhase::Exit;touchEvents.push_back(exit);}
            e.phase=old!=previousTouches.end()&&old->second.sensor==e.sensor?PhysicsWorld::TouchPhase::Stay:PhysicsWorld::TouchPhase::Enter;touchEvents.push_back(e);
        }
        for(auto& [key,e]:previousTouches)if(!stepTouches.count(key)){auto exit=e;exit.phase=PhysicsWorld::TouchPhase::Exit;touchEvents.push_back(exit);}
        std::stable_sort(touchEvents.begin(),touchEvents.end(),[](const auto& a,const auto& b){return std::tie(a.a.id,a.b.id)<std::tie(b.a.id,b.b.id);});
        previousTouches=stepTouches;
    }

    // Milestone 32: broadphase, the per-step candidate list, the solver
    // (reused so its storage is not reallocated every step) and statistics.
    DynamicAabbTree tree;
    std::vector<std::pair<unsigned int, unsigned int>> candidatePairs;
    mutable std::vector<unsigned int> queryScratch;
    struct JointRecord {
        JointHandle handle;JointState state;std::array<float,12> warm{};
        float previousCoordinate=0,restoredContinuationDt=0;
    };
    void InvalidateRestoredContinuation(unsigned slot) {
        // Live-world cache policy remains unchanged. Newly restored seeds may
        // only continue the exact reconstructed physical context.
        bool physicalContext=!bodies[slot].queryOnly;
        for(auto& joint:joints)if(
            (joint.state.settings.bodyA.id&kSlotMask)==slot||
            (joint.state.settings.bodyB.IsValid()&&(joint.state.settings.bodyB.id&kSlotMask)==slot)){
            physicalContext=true;
            if(joint.restoredContinuationDt>0){
                joint.warm.fill(0);joint.state.angularDrive.impulses={0,0,0};
                joint.restoredContinuationDt=0;
            }
        }
        // Independent query proxies cannot own completed physical contact rows.
        // Their ordinary pre-step refresh must not erase another articulation's
        // restored publication. A mechanically connected proxy still invalidates.
        if(physicalContext)restoredCompletedObservations=false;
    }
    std::string ContinuationBodyContext(const Body& body) const {
        SaveArchive a;auto field=[&](auto value){a(value);};
        field(body.rigidBody.position);field(body.rigidBody.orientation);
        field(body.rigidBody.linearVelocity);field(body.rigidBody.angularVelocity);
        field(body.rigidBody.inverseMass);field(body.rigidBody.inverseInertiaLocal);
        field(body.isDynamic);field(body.isKinematic);field(body.enabled);
        field(body.sensor);field(body.queryOnly);field(body.collisionLayer);
        field(body.collisionMask);field(body.friction);field(body.restitution);
        auto material=body.physicalMaterial;a(material);
        const auto& shape=body.shape;
        field(shape.type);field(shape.radius);field(shape.halfHeight);
        field(shape.halfExtents);field(shape.pivotOffset);
        auto assetId=shape.assetId;a(assetId);
        auto fingerprint=[&](const auto& asset){
            std::string source=asset?asset->sourceFingerprint:std::string{},
                        settings=asset?asset->settingsFingerprint:std::string{};
            a(source,settings);
        };
        fingerprint(shape.asset);
        float terrainBound=shape.terrain?shape.terrain->BoundRadius():0;a(terrainBound);
        uint32_t count=uint32_t(shape.boxes.size());a(count);
        a.Require(count<=65536,"continuation compound-shape limit");
        for(const auto& child:shape.boxes){
            field(child.type);field(child.localCenter);field(child.halfExtents);
            field(child.rotation);field(child.radius);field(child.key);
            auto id=child.assetId;a(id);fingerprint(child.asset);
        }
        return a.bytes;
    }
    std::string ContinuationJointContext(const JointRecord& joint) const {
        SaveArchive a;auto s=joint.state.settings;
        // Handles are validated/remapped by the world owner; never archive slots.
        a(s.type,s.anchorA,s.anchorB,s.frameA,s.frameB,s.enabled,s.limits,s.motor,
          s.spring,s.lower,s.upper,s.speed,s.maxForce,s.rest,s.stiffness,s.damping,
          s.rotationalResistance);
        const auto* bodyA=Get(s.bodyA);const auto* bodyB=Get(s.bodyB);
        a.Require(bodyA&&(!s.bodyB.IsValid()||bodyB),"stale joint continuation body");
        auto first=ContinuationBodyContext(*bodyA),second=bodyB?ContinuationBodyContext(*bodyB):std::string{};
        a(first,second);return a.bytes;
    }
    std::vector<JointRecord> joints;
    std::set<std::pair<unsigned,unsigned>> suppressedPairs;
    JointSolver jointSolver,eventJointSolver;
    RigidBody worldAnchor;
    bool JointActive(const JointRecord& joint) const {
        const auto* a=Get(joint.state.settings.bodyA);const auto* b=Get(joint.state.settings.bodyB);
        return joint.state.settings.enabled&&a&&a->enabled&&(!joint.state.settings.bodyB.IsValid()||(b&&b->enabled));
    }
    std::vector<JointInput> JointInputs(const std::vector<unsigned char>* included=nullptr) {
        std::vector<JointInput> result;
        for(auto& joint:joints){joint.state.active=JointActive(joint);if(!joint.state.active){joint.warm.fill(0);continue;}
            auto* a=Get(joint.state.settings.bodyA);auto* b=Get(joint.state.settings.bodyB);
            if((a->sleeping||a->rigidBody.IsStatic())&&(!b||b->sleeping||b->rigidBody.IsStatic()))continue;
            if(included&&!(*included)[joint.state.settings.bodyA.id&kSlotMask]&&
               (!b||!(*included)[joint.state.settings.bodyB.id&kSlotMask]))continue;
            result.push_back({&a->rigidBody,b?&b->rigidBody:&worldAnchor,&joint.state,&joint.warm,a->shape.pivotOffset,b?b->shape.pivotOffset:glm::vec3(0)});
        }
        return result;
    }
    bool sleepingEnabled=true;
    void Wake(unsigned slot){
        if(slot>=bodies.size()||!bodies[slot].alive)return;
        std::set<unsigned> visited;std::vector<unsigned> queue{slot};
        for(size_t i=0;i<queue.size();++i){auto n=queue[i];if(!visited.insert(n).second)continue;
            auto& b=bodies[n];b.sleeping=false;b.quietSeconds=0;
            if(n!=slot&&b.rigidBody.IsStatic())continue;
            for(const auto& j:joints)if(j.state.settings.enabled){const auto a=j.state.settings.bodyA,c=j.state.settings.bodyB;if(!Get(a))continue;if((a.id&kSlotMask)==n&&Get(c))queue.push_back(c.id&kSlotMask);else if(Get(c)&&(c.id&kSlotMask)==n)queue.push_back(a.id&kSlotMask);}
            for(const auto& [_,e]:previousTouches)if(!e.sensor&&Get(e.a)&&Get(e.b)){
                auto a=e.a.id&kSlotMask,c=e.b.id&kSlotMask;if(a==n&&!bodies[c].rigidBody.IsStatic())queue.push_back(c);if(c==n&&!bodies[a].rigidBody.IsStatic())queue.push_back(a);
            }
            // Speculative resting rows may have a positive gap and therefore
            // no touch callback. They still connect the sleeping contact island.
            for(const auto& c:contactCache)if(c.normalImpulse>0){
                const auto a=c.key.slotA,b=c.key.slotB;
                if(a>=bodies.size()||b>=bodies.size()||!bodies[a].alive||!bodies[b].alive||bodies[a].generation!=c.key.generationA||bodies[b].generation!=c.key.generationB)continue;
                if(a==n&&!bodies[b].rigidBody.IsStatic())queue.push_back(b);
                if(b==n&&!bodies[a].rigidBody.IsStatic())queue.push_back(a);
            }
        }
    }
    uint64_t sleepTraceStep=0;
    static constexpr unsigned kNoSleepMember=std::numeric_limits<unsigned>::max();
    struct SleepIsland {
        unsigned first=kNoSleepMember,last=kNoSleepMember,count=0;
        bool quiet=true,anchored=false;
        float seconds=1000;
    };
    // Derived, step-local graph data. Capacities survive, but every logical
    // member/edge is rebuilt from current generation-validated physical state.
    std::vector<unsigned> sleepParents,sleepNext,sleepRoots;
    std::vector<SleepIsland> sleepIslands;
    std::size_t sleepGraphEdges=0,sleepIslandCount=0,sleepScratchBytes=0;
    void Settle(float dt){
        ++sleepTraceStep;
        sleepGraphEdges=sleepIslandCount=0;
        if(!sleepingEnabled){for(auto i:aliveSlots)if(bodies[i].isDynamic)++stats.awakeBodies;return;}
        sleepParents.resize(bodies.size());
        for(unsigned i=0;i<sleepParents.size();++i)sleepParents[i]=i;
        sleepNext.assign(bodies.size(),kNoSleepMember);
        sleepIslands.assign(bodies.size(),SleepIsland{});
        sleepRoots.clear();
        auto root=[&](unsigned i){while(sleepParents[i]!=i){sleepParents[i]=sleepParents[sleepParents[i]];i=sleepParents[i];}return i;};
        auto unite=[&](unsigned a,unsigned b){++sleepGraphEdges;if(bodies[a].isDynamic&&bodies[b].isDynamic)sleepParents[root(b)]=root(a);};
        // Preserve the original union and row order: changing roots or solver
        // order is unnecessary for eliminating the per-island global rescans.
        auto validSupport=[&](const CachedContact& c){return c.normalImpulse>0&&c.key.slotA<bodies.size()&&c.key.slotB<bodies.size()&&bodies[c.key.slotA].alive&&bodies[c.key.slotB].alive&&bodies[c.key.slotA].generation==c.key.generationA&&bodies[c.key.slotB].generation==c.key.generationB;};
        for(const auto& c:contactCache)if(validSupport(c))unite(c.key.slotA,c.key.slotB);
        for(const auto& [_,e]:stepTouches)if(!e.sensor&&Get(e.a)&&Get(e.b))unite(e.a.id&kSlotMask,e.b.id&kSlotMask);
        for(const auto& j:joints)if(JointActive(j)&&Get(j.state.settings.bodyB))unite(j.state.settings.bodyA.id&kSlotMask,j.state.settings.bodyB.id&kSlotMask);
        for(auto i:aliveSlots)if(bodies[i].isDynamic&&bodies[i].enabled&&!bodies[i].sensor){
            const auto r=root(i);auto& island=sleepIslands[r];
            if(island.first==kNoSleepMember){island.first=i;sleepRoots.push_back(r);}
            else sleepNext[island.last]=i;
            island.last=i;++island.count;
        }
        // std::map previously visited roots in ascending order and members in
        // alive-slot order. Keep both orders, without allocating a map/vector
        // for every independent machine on every fixed step.
        std::sort(sleepRoots.begin(),sleepRoots.end());
        sleepIslandCount=sleepRoots.size();
        sleepScratchBytes=(sleepParents.capacity()+sleepNext.capacity()+sleepRoots.capacity())*sizeof(unsigned)+sleepIslands.capacity()*sizeof(SleepIsland);
        auto anchorPair=[&](unsigned a,unsigned b){
            if(bodies[b].rigidBody.IsStatic())sleepIslands[root(a)].anchored=true;
            if(bodies[a].rigidBody.IsStatic())sleepIslands[root(b)].anchored=true;
        };
        for(const auto& c:contactCache)if(validSupport(c))anchorPair(c.key.slotA,c.key.slotB);
        for(const auto& [_,e]:stepTouches)if(!e.sensor&&Get(e.a)&&Get(e.b))anchorPair(e.a.id&kSlotMask,e.b.id&kSlotMask);
        for(const auto& j:joints)if(JointActive(j)){
            const auto& s=j.state.settings;auto* a=Get(s.bodyA);auto* b=Get(s.bodyB);
            auto& island=sleepIslands[root(s.bodyA.id&kSlotMask)];
            // This deliberately retains the established body-A anchor policy;
            // a performance pass must not silently change sleep semantics.
            island.anchored|=!b||b->rigidBody.IsStatic();
            if(island.first==kNoSleepMember)continue;
            auto pa=a->rigidBody.position+a->rigidBody.orientation*(s.anchorA-a->shape.pivotOffset);auto pb=b?b->rigidBody.position+b->rigidBody.orientation*(s.anchorB-b->shape.pivotOffset):s.anchorB;
            auto error=pb-pa;if(s.type==JointType::Slider){auto axis=a->rigidBody.orientation*s.frameA*glm::vec3(1,0,0);error-=axis*glm::dot(error,axis);}island.quiet&=glm::length(error)<.02f;island.quiet&=!s.motor||s.speed==0;
            auto qa=glm::normalize(a->rigidBody.orientation*s.frameA),qb=b?glm::normalize(b->rigidBody.orientation*s.frameB):glm::normalize(s.frameB);
            if(s.type==JointType::Fixed||s.type==JointType::Slider)island.quiet&=2*std::acos(std::clamp(glm::abs(glm::dot(qa,qb)),0.f,1.f))<.01f;
            if(s.type==JointType::Hinge)island.quiet&=glm::length(qa*glm::vec3(1,0,0)-qb*glm::vec3(1,0,0))<.01f;
            if(s.spring)island.quiet&=std::abs(j.state.coordinate-j.previousCoordinate)<.002f;
            if(s.limits)island.quiet&=j.state.coordinate>=s.lower-.01f&&j.state.coordinate<=s.upper+.01f;
        }
        for(auto i:aliveSlots)if(bodies[i].isDynamic&&bodies[i].enabled&&!bodies[i].sensor){
            auto& b=bodies[i];auto& island=sleepIslands[root(i)];
            island.quiet&=glm::length(b.rigidBody.linearVelocity)<.03f&&glm::length(b.rigidBody.angularVelocity)<.03f&&glm::length(b.rigidBody.position-b.previousPosition)<.002f&&glm::abs(glm::dot(b.rigidBody.orientation,b.previousOrientation))>.999999f;
            island.seconds=std::min(island.seconds,b.quietSeconds);
        }
        // Retain the existing geometric neighbourhood test exactly. Debug
        // contacts do not carry body identity; proximity must not be replaced
        // with guessed ownership. Only genuinely deep rows take this path.
        for(const auto& c:lastStepContacts)if(c.penetration>.02f){
            for(auto i:aliveSlots)if(bodies[i].isDynamic&&bodies[i].enabled&&!bodies[i].sensor&&glm::length(c.point-bodies[i].rigidBody.position)<bodies[i].boundingRadius+.1f)sleepIslands[root(i)].quiet=false;
        }
        const bool trace=std::getenv("JUDAS_SLEEP_TRACE")&&sleepTraceStep%60==0;
        for(auto r:sleepRoots){auto& island=sleepIslands[r];
            if(trace){
                float linear=0,angular=0,travel=0,anchorError=0,angularError=0,penetration=0;bool drive=false,limit=true;
                for(auto i=island.first;i!=kNoSleepMember;i=sleepNext[i]){const auto& b=bodies[i];linear=std::max(linear,glm::length(b.rigidBody.linearVelocity));angular=std::max(angular,glm::length(b.rigidBody.angularVelocity));travel=std::max(travel,glm::length(b.rigidBody.position-b.previousPosition));}
                for(const auto& j:joints)if(JointActive(j)&&root(j.state.settings.bodyA.id&kSlotMask)==r){const auto& x=j.state.settings;auto* a=Get(x.bodyA);auto* b=Get(x.bodyB);auto pa=a->rigidBody.position+a->rigidBody.orientation*(x.anchorA-a->shape.pivotOffset),pb=b?b->rigidBody.position+b->rigidBody.orientation*(x.anchorB-b->shape.pivotOffset):x.anchorB;anchorError=std::max(anchorError,glm::length(pa-pb));drive|=x.motor&&x.speed!=0;limit&=!x.limits||(j.state.coordinate>=x.lower-.01f&&j.state.coordinate<=x.upper+.01f);auto qa=glm::normalize(a->rigidBody.orientation*x.frameA),qb=b?glm::normalize(b->rigidBody.orientation*x.frameB):glm::normalize(x.frameB);if(x.type==JointType::Hinge)angularError=std::max(angularError,glm::length(qa*glm::vec3(1,0,0)-qb*glm::vec3(1,0,0)));}
                for(const auto& c:lastStepContacts)for(auto i=island.first;i!=kNoSleepMember;i=sleepNext[i])if(glm::length(c.point-bodies[i].rigidBody.position)<bodies[i].boundingRadius+.1f)penetration=std::max(penetration,c.penetration);
                std::fprintf(stderr,"SLEEP step=%llu root=%u members=%zu v=%g w=%g travel=%g anchor=%g axis=%g penetration=%g drive=%d limits=%d quiet=%d time=%g supported=%d\n",(unsigned long long)sleepTraceStep,island.first,std::size_t(island.count),linear,angular,travel,anchorError,angularError,penetration,drive,limit,island.quiet,island.seconds,island.anchored);
            }
            island.seconds=island.quiet?island.seconds+dt:0;
            bool freeAtRest=true;
            if(island.quiet&&island.seconds>=.75f&&!island.anchored){
                for(auto i=island.first;i!=kNoSleepMember;i=sleepNext[i])if(!(glm::length(bodies[i].lastAcceleration)<1e-6f&&glm::length(bodies[i].rigidBody.linearVelocity)<1e-6f&&glm::length(bodies[i].rigidBody.angularVelocity)<1e-6f)){freeAtRest=false;break;}
            }
            const bool asleep=island.quiet&&island.seconds>=.75f&&(island.anchored||freeAtRest);
            for(auto i=island.first;i!=kNoSleepMember;i=sleepNext[i]){auto& b=bodies[i];b.quietSeconds=island.seconds;b.sleeping=asleep;if(asleep){b.rigidBody.linearVelocity={0,0,0};b.rigidBody.angularVelocity={0,0,0};}}
            stats.sleepingIslands+=asleep;
        }
        for(auto& j:joints)j.previousCoordinate=j.state.coordinate;
        for(auto i:aliveSlots)if(bodies[i].isDynamic){stats.sleepingBodies+=bodies[i].sleeping;stats.awakeBodies+=!bodies[i].sleeping;}
    }
    ContactSolver solver;
    ContactSolver particleSolver; // independent storage; never replays the rigid warm cache
    PhysicsWorld::ParticleContactStats particleContactStats;
    ImpactSolver impactSolver;
    struct StartContact {
        unsigned a,b;
        std::size_t constraint;
        float friction, warmNormal;
        glm::vec3 warmTangent;
        bool newImpact;
    };
    std::vector<StartContact> startContacts;
    std::vector<std::array<unsigned,4>> separatedPairs;
    std::vector<std::array<unsigned,4>> supportPairs;
    std::vector<std::array<unsigned,4>> spinningPairs; // sorted; continuous search with a penetration target
    struct ScheduledImpact { std::array<unsigned,4> key; double time; };
    std::vector<ScheduledImpact> scheduledImpacts;
    std::vector<unsigned> impactCounts;
    std::vector<unsigned char> impactCapped;
    double stepDuration = 0;

    // A derived CCD sample, never an integration anchor. Many incident pairs
    // ask for the same body's pose at the same event time. Keep its exact
    // represented pose/orientation preparation once until that trajectory
    // changes. Time and generation are part of the key; every step and every
    // Begin/ChangeVelocity invalidates samples explicitly.
    struct ImpactPoseSample {
        RigidBody pose;
        std::optional<ContactPreparedOrientation> orientation;
        double time=std::numeric_limits<double>::quiet_NaN();
        unsigned generation=0;
        glm::vec3 tightPosition{0};
        glm::quat tightOrientation{1,0,0,0};
        Aabb tightBound;
        bool tightValid=false;
        Aabb remainingBound;
        double boundStart=std::numeric_limits<double>::quiet_NaN(),boundFinish=0;
        unsigned boundGeneration=0;
    };
    std::vector<ImpactPoseSample> impactPoseSamples,impactAnchorSamples;
    double impactQueryAnchorTime=0;
    std::size_t impactPoseEvaluations=0,impactPoseReuses=0,impactOrientationBuilds=0,impactTruthRequests=0,impactTruthReuses=0,impactBoundsRejected=0;
    std::size_t impactActualBoundsRejected=0;
    struct WorkDiagnostics {
        bool active=false;
        PhysicsWorkSample toi,geometry,impactIslands,impactSolve,jointPreparation,impactObservations,continuationProof,continuationCache;
        std::size_t continuationAttempts=0,continuationAccepted=0,continuationPartitions=0,continuationOverBudget=0;
        std::size_t coupledFallbackEvents=0,elasticFallbackEvents=0,geometryFallbackEvents=0,peakImpactBodies=0,peakImpactRows=0;
        std::size_t candidatePasses=0,candidateQueries=0,candidateLeaves=0;
    } work;
    // Indexed output only: workers never mutate physics bodies, geometry
    // caches, solver rows, touches, warm starts or event scheduling.
    struct InitialContactGeometry {
        unsigned a=0,b=0;float margin=0;
        const ContactPreparedOrientation* orientationA=nullptr;
        const ContactPreparedOrientation* orientationB=nullptr;
        ContactManifold manifold;bool touching=false,ready=false;
    };
    struct InitialGeometryDiagnostics {ContactGeometryDiagnostics contacts;CollisionGeometryStats cooked;std::size_t manifolds=0;};
    // Optional borrowed process service; no physical state or worker ownership.
    JobSystem* contactJobs=nullptr;unsigned contactJobLanes=4;
    static constexpr std::size_t kMaxInitialContactPairs=16384;
    std::vector<InitialContactGeometry> initialContactGeometry;
    ContactGeometryDiagnostics parallelContactDiagnostics;
    CollisionGeometryStats parallelCookedDiagnostics;
    static void AddContactDiagnostics(ContactGeometryDiagnostics& into,const ContactGeometryDiagnostics& after,const ContactGeometryDiagnostics& before={}){
#define ADD_DIAG(name) into.name+=after.name-before.name
        ADD_DIAG(predicates);ADD_DIAG(intervalResolved);ADD_DIAG(exactFallbacks);ADD_DIAG(unresolved);ADD_DIAG(invalidInputs);ADD_DIAG(numericGapFallbacks);ADD_DIAG(preparedOrientationMisses);
#undef ADD_DIAG
    }
    static void AddCookedDiagnostics(CollisionGeometryStats& into,const CollisionGeometryStats& after,const CollisionGeometryStats& before={}){
        into.nodes+=after.nodes-before.nodes;into.triangles+=after.triangles-before.triangles;into.convexTests+=after.convexTests-before.convexTests;
    }
    void PrepareInitialContactGeometry(float dt){
        initialContactGeometry.clear();JobSystem* jobs=contactJobs;
        JUDAS_PROFILE_COUNTER("Physics initial geometry worker lanes",0,ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics parallel initial manifolds",0,ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics initial worker completed manifolds",0,ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics initial geometry scratch bytes",initialContactGeometry.capacity()*sizeof(InitialContactGeometry),ProfileCounterMode::Latest);
        if(!jobs||jobs->IsShutDown()||contactJobLanes<=1||candidatePairs.size()<256)return;
        const auto eligible=[&](const std::pair<unsigned,unsigned>& pair){
            const auto& a=bodies[pair.first];const auto& b=bodies[pair.second];
            const auto simple=[](const Shape& shape){return !shape.asset&&(shape.type==ShapeType::Box||shape.type==ShapeType::Sphere);};
            return !a.sensor&&!b.sensor&&!a.queryOnly&&!b.queryOnly&&simple(a.shape)&&simple(b.shape)&&
                !((a.sleeping||a.rigidBody.IsStatic())&&(b.sleeping||b.rigidBody.IsStatic()));
        };
        std::size_t count=0;
        for(const auto& pair:candidatePairs)if(eligible(pair)&&++count>kMaxInitialContactPairs)return;
        if(count<256)return;
        const auto capacity=initialContactGeometry.capacity();initialContactGeometry.reserve(std::size_t(count));
        if(initialContactGeometry.capacity()!=capacity){++cacheCounters.allocations;cacheCounters.allocatedBytes+=initialContactGeometry.capacity()*sizeof(InitialContactGeometry);}
        for(const auto& pair:candidatePairs)if(eligible(pair)){
            auto& a=bodies[pair.first];auto& b=bodies[pair.second];
            const float margin=(glm::length(a.rigidBody.linearVelocity-b.rigidBody.linearVelocity)+
                glm::length(a.rigidBody.angularVelocity)*a.boundingRadius+
                glm::length(b.rigidBody.angularVelocity)*b.boundingRadius)*dt;
            InitialContactGeometry output;output.a=pair.first;output.b=pair.second;output.margin=margin;
            output.orientationA=&Orientation(a);output.orientationB=&Orientation(b);
            initialContactGeometry.push_back(std::move(output));
        }
        // Do not inspect the pool's worker vector while Shutdown may join and
        // clear it. The borrowed pool bounds execution; unused queued jobs are
        // cancelled below after the owner exhausts the range cursor.
        const unsigned lanes=unsigned(std::min(std::size_t(contactJobLanes),initialContactGeometry.size()/64));
        std::array<InitialGeometryDiagnostics,JobSystem::kMaxWorkers+1> diagnostics{};
        std::atomic<std::size_t> next{0};
        const auto compute=[&](InitialContactGeometry& output){
            const auto& a=bodies[output.a];const auto& b=bodies[output.b];
            const auto childA=PrimitiveAt(a.shape,a.rigidBody,0,output.orientationA);
            const auto childB=PrimitiveAt(b.shape,b.rigidBody,0,output.orientationB);
            output.manifold=ComputeContacts(childA,childB,output.margin,output.orientationA,output.orientationB);
            output.touching=false;
            for(int p=0;p<output.manifold.count;++p){const auto& c=output.manifold.points[p];output.touching=output.touching||(c.hasLocalAnchors?c.signedSeparation<=0:c.penetration>=0);}
            if(!output.touching&&output.manifold.count)output.touching=ComputeContacts(childA,childB,0,output.orientationA,output.orientationB).count>0;
            output.ready=true;
        };
        auto run=[&](unsigned lane){
            const auto contactsBefore=GetContactGeometryDiagnostics();const auto cookedBefore=GetCollisionGeometryStats();
            JUDAS_PROFILE_SCOPE("Physics initial geometry worker batch");
            try {
                for(;;){const auto first=next.fetch_add(8,std::memory_order_relaxed);if(first>=initialContactGeometry.size())break;
                    for(auto i=first;i<std::min(first+8,initialContactGeometry.size());++i){compute(initialContactGeometry[i]);++diagnostics[lane].manifolds;}
                }
            }catch(...){AddContactDiagnostics(diagnostics[lane].contacts,GetContactGeometryDiagnostics(),contactsBefore);AddCookedDiagnostics(diagnostics[lane].cooked,GetCollisionGeometryStats(),cookedBefore);throw;}
            AddContactDiagnostics(diagnostics[lane].contacts,GetContactGeometryDiagnostics(),contactsBefore);AddCookedDiagnostics(diagnostics[lane].cooked,GetCollisionGeometryStats(),cookedBefore);
        };
        std::array<JobHandle,JobSystem::kMaxWorkers> handles{};unsigned handleCount=0;std::exception_ptr submitError;
        try{for(unsigned lane=1;lane<lanes;++lane){auto handle=jobs->Submit([&,lane](JobContext&){run(lane);},JobPriority::High,"Physics initial contact geometry");if(handle.IsValid())handles[handleCount++]=handle;}}
        catch(...){submitError=std::current_exception();}
        std::exception_ptr mainError;try{run(0);}catch(...){mainError=std::current_exception();}
        // The owner has exhausted the shared range cursor. A job still queued
        // behind unrelated resource work can no longer claim useful ranges.
        // Cancel only these jobs; running jobs retain their claimed outputs.
        for(unsigned i=0;i<handleCount;++i)if(jobs->StateOf(handles[i])==JobState::Queued)jobs->Cancel(handles[i]);
        JobHandle failed;
        for(unsigned i=0;i<handleCount;++i)if(jobs->Wait(handles[i])==JobState::Failed&&!failed.IsValid())failed=handles[i];
        std::string workerError=failed.IsValid()?jobs->ErrorOf(failed):std::string{};
        if(failed.IsValid()&&workerError.empty())workerError="initial geometry job did not complete";
        for(unsigned i=0;i<handleCount;++i)jobs->Forget(handles[i]);
        // Lane zero executes on the owner; its TLS counters are already included
        // in the native Step's before/after snapshots.
        for(unsigned lane=1;lane<lanes;++lane){AddContactDiagnostics(parallelContactDiagnostics,diagnostics[lane].contacts);AddCookedDiagnostics(parallelCookedDiagnostics,diagnostics[lane].cooked);}
        if(submitError)std::rethrow_exception(submitError);
        if(mainError)std::rethrow_exception(mainError);
        if(!workerError.empty())throw std::runtime_error(workerError);
        // Shutdown may cancel jobs before they start; incomplete outputs then
        // run through the unchanged owner-thread geometry path after all joins.
        // Never fall back concurrently with a worker writing an output slot.
        for(auto& output:initialContactGeometry)if(!output.ready)compute(output);
        std::size_t workerManifolds=0;
        for(unsigned lane=1;lane<lanes;++lane)workerManifolds+=diagnostics[lane].manifolds;
        JUDAS_PROFILE_COUNTER("Physics initial worker completed manifolds",workerManifolds,ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics initial geometry worker lanes",lanes,ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics parallel initial manifolds",initialContactGeometry.size(),ProfileCounterMode::Latest);
        JUDAS_PROFILE_COUNTER("Physics initial geometry scratch bytes",initialContactGeometry.capacity()*sizeof(InitialContactGeometry),ProfileCounterMode::Latest);
    }
    void PrepareJoints(JointSolver& target,const std::vector<JointInput>& inputs,float dt,
                       bool warm=true,bool impact=false,bool append=false){
        PhysicsWorkTimer timer(work.jointPreparation,work.active);
        target.Prepare(inputs,dt,warm,impact,append);
    }
    void InvalidateImpactPose(unsigned slot){
        if(slot<impactPoseSamples.size()){
            impactPoseSamples[slot].time=std::numeric_limits<double>::quiet_NaN();
            impactAnchorSamples[slot].time=std::numeric_limits<double>::quiet_NaN();
            impactPoseSamples[slot].boundStart=std::numeric_limits<double>::quiet_NaN();
        }
    }

    RigidBody PoseAt(unsigned slot, double time) const {
        const Body& b=bodies[slot];
        RigidBody pose=b.rigidBody;
        if (b.HasMotion() && !b.motion.Segments().empty()) {
            const auto sampled=b.motion.EvaluateAfterEvents(time);
            pose.position=sampled.position; pose.orientation=sampled.orientation;
            pose.linearVelocity=sampled.linearVelocity;pose.angularVelocity=sampled.angularVelocity;
        }
        return pose;
    }
    static double NormalSpeed(const Contact& c,const RigidBody& a,const RigidBody& b) {
        const glm::dvec3 ra=c.hasLocalAnchors ? (c.anchorAInWorldFrame ? c.localAnchorA : ContactRotation(a.orientation)*c.localAnchorA) :
            glm::dvec3(c.point)-glm::dvec3(a.position);
        const glm::dvec3 rb=c.hasLocalAnchors ? (c.anchorBInWorldFrame ? c.localAnchorB : ContactRotation(b.orientation)*c.localAnchorB) :
            glm::dvec3(c.point)-glm::dvec3(b.position);
        return glm::dot(glm::dvec3(c.normal),glm::dvec3(a.linearVelocity-b.linearVelocity)+
            glm::cross(glm::dvec3(a.angularVelocity),ra)-glm::cross(glm::dvec3(b.angularVelocity),rb));
    }
    // This RigidBody-shaped adapter serves the existing geometric primitive
    // APIs only. It deliberately does not transport angular velocity; physical
    // event/solver publication must continue to use PoseAt above.
    RigidBody GeometryPoseAt(unsigned slot,double time) const {
        const auto& body=bodies[slot];
        RigidBody pose=body.rigidBody;
        if(body.HasMotion()&&!body.motion.Segments().empty()){
            const auto geometry=body.motion.EvaluateGeometryAfterEvents(time);
            pose.position=geometry.position;pose.orientation=geometry.orientation;
            pose.linearVelocity=geometry.linearVelocity;
        }
        return pose;
    }
    const ImpactPoseSample& ImpactPoseAt(unsigned slot,double time){
        EnsureImpactPoseStorage();
        // Independent pair queries share the current event's start pose.
        // Bisection samples must not evict that immutable geometric sample.
        auto& sample=time==impactQueryAnchorTime?impactAnchorSamples[slot]:impactPoseSamples[slot];
        if(sample.time==time&&sample.generation==bodies[slot].generation){++impactPoseReuses;return sample;}
        sample.pose=GeometryPoseAt(slot,time);sample.time=time;sample.generation=bodies[slot].generation;++impactPoseEvaluations;
        if(!sample.orientation||!sample.orientation->Matches(sample.pose.orientation)){
            sample.orientation.emplace(sample.pose.orientation);++impactOrientationBuilds;
        }
        return sample;
    }
    const Aabb& RemainingImpactBound(unsigned slot,double start,double finish){
        EnsureImpactPoseStorage();
        auto& sample=impactPoseSamples[slot];const auto& body=bodies[slot];
        // An unchanged anchored trajectory's earlier enclosure also contains
        // every later subinterval. Velocity changes invalidate this cache.
        // Reusing the superset is conservative; it never supplies contact truth.
        if(sample.boundStart<=start&&sample.boundFinish>=finish&&sample.boundGeneration==body.generation)return sample.remainingBound;
        if(!body.HasMotion())sample.remainingBound=CurrentBound(bodies[slot]);
        else {
            // The remaining motion is one anchored segment. Each represented
            // center component stays between its sampled endpoints. An outward
            // enclosing sphere at both endpoints therefore bounds every shape
            // orientation, including a full turn with equal endpoint rotations.
            // Only centers are needed: do not evict the prepared start pose or
            // prepare an unused endpoint orientation for this sphere enclosure.
            const auto fromPose=GeometryPoseAt(slot,start),toPose=GeometryPoseAt(slot,finish);
            const auto from=fromPose.position,to=toPose.position;
            const auto sphere=Shape::Sphere(body.boundingRadius);const glm::quat identity(1,0,0,0);
            sample.remainingBound=ShapeAabb(sphere,from,identity).Union(ShapeAabb(sphere,to,identity));
            const auto& segments=body.motion.Segments();
            auto segment=std::upper_bound(segments.begin(),segments.end(),start,
                [](double time,const auto& value){return time<value.begin;});
            if(segment!=segments.begin()){
                --segment;
                auto tighter=rigid_motion_bounds::TryTranslationSweepBound(body.shape,*segment,fromPose,toPose,start,finish);
                if(!tighter)tighter=rigid_motion_bounds::TryDynamicBoxSweepBound(body.shape,*segment,fromPose,toPose,start,finish);
                if(tighter)
                    sample.remainingBound=rigid_motion_bounds::IntersectConservativeBounds(sample.remainingBound,*tighter);
            }
        }
        sample.boundStart=start;sample.boundFinish=finish;sample.boundGeneration=body.generation;return sample.remainingBound;
    }
    const Aabb& ActualImpactBound(unsigned slot,const ImpactPoseSample& pose){
        auto& sample=impactPoseSamples[slot];
        if(!sample.tightValid||!SamePosition(sample.tightPosition,pose.pose.position)||
           !SameRotation(sample.tightOrientation,pose.pose.orientation)){
            const auto& shape=bodies[slot].shape;
            if(shape.type==ShapeType::Box||shape.type==ShapeType::Sphere){
                PreparedShapeBounds prepared;
                PrepareShapeBounds(shape,*pose.orientation,prepared);
                sample.tightBound=ShapeAabb(prepared,pose.pose.position);
            }else sample.tightBound=ShapeAabb(shape,pose.pose.position,pose.pose.orientation);
            sample.tightPosition=pose.pose.position;sample.tightOrientation=pose.pose.orientation;
            sample.tightValid=true;
        }
        return sample.tightBound;
    }
    bool SimpleImpactBoundsSeparated(unsigned a,unsigned b,const ImpactPoseSample& aa,const ImpactPoseSample& bb){
        const auto simple=[](const Shape& shape){return (shape.type==ShapeType::Box||shape.type==ShapeType::Sphere)&&shape.pivotOffset==glm::vec3(0);};
        if(!simple(bodies[a].shape)||!simple(bodies[b].shape))return false;
        const auto& first=ActualImpactBound(a,aa);const auto& second=ActualImpactBound(b,bb);
        if(!rigid_motion_bounds::FiniteBound(first)||!rigid_motion_bounds::FiniteBound(second)||first.Overlaps(second))return false;
        ++impactActualBoundsRejected;return true;
    }
    ContactManifold PairAt(unsigned a,unsigned b,int pa,int pb,double time,float margin) {
        PhysicsWorkTimer timer(work.geometry,work.active);
        const auto& aa=ImpactPoseAt(a,time);const auto& bb=ImpactPoseAt(b,time);
        if(margin==0&&SimpleImpactBoundsSeparated(a,b,aa,bb))return {};
        return ComputeContacts(PrimitiveAt(bodies[a].shape,aa.pose,pa,&*aa.orientation),
            PrimitiveAt(bodies[b].shape,bb.pose,pb,&*bb.orientation),margin,&*aa.orientation,&*bb.orientation);
    }
    // Deepest actual (zero-margin) penetration of the pair at `time`, metres.
    double PairPenetration(unsigned a,unsigned b,int pa,int pb,double time) {
        const auto manifold=PairAt(a,b,pa,pb,time,0);double deepest=0;
        for(int k=0;k<manifold.count;++k){const auto& c=manifold.points[k];
            deepest=std::max(deepest,c.hasLocalAnchors?-c.signedSeparation:double(c.penetration));}
        return deepest;
    }
    bool PairPenetrationExceeds(unsigned a,unsigned b,int pa,int pb,double time,double target) {
        PhysicsWorkTimer timer(work.geometry,work.active);
        const auto& aa=ImpactPoseAt(a,time);const auto& bb=ImpactPoseAt(b,time);
        const auto posa=PrimitiveAt(bodies[a].shape,aa.pose,pa,&*aa.orientation);
        const auto posb=PrimitiveAt(bodies[b].shape,bb.pose,pb,&*bb.orientation);
        if(posa.shape.asset||posb.shape.asset)return CookedHasPenetrationBeyond(posa,posb,target);
        return PairPenetration(a,b,pa,pb,time)>target;
    }
    bool PairTouches(unsigned a,unsigned b,int pa,int pb,double time) {
        PhysicsWorkTimer timer(work.geometry,work.active);
        const auto& aa=ImpactPoseAt(a,time);const auto& bb=ImpactPoseAt(b,time);
        if(SimpleImpactBoundsSeparated(a,b,aa,bb))return false;
        const auto posa=PrimitiveAt(bodies[a].shape,aa.pose,pa,&*aa.orientation);
        const auto posb=PrimitiveAt(bodies[b].shape,bb.pose,pb,&*bb.orientation);
        if(posa.shape.asset||posb.shape.asset)return CookedHasContacts(posa,posb,0);
        if(posa.childRotation==glm::quat(1,0,0,0)&&posb.childRotation==glm::quat(1,0,0,0))
            return PrimitiveHasContacts(posa.shape,{posa.parentPosition,posa.parentOrientation,posa.parentLocalCenter},
                posb.shape,{posb.parentPosition,posb.parentOrientation,posb.parentLocalCenter},0,&*aa.orientation,&*bb.orientation);
        return ComputeContacts(posa,posb,0,&*aa.orientation,&*bb.orientation).count>0;
    }
    // CCD bounds use the geometric drift generator, not the transported
    // physical endpoint angular velocity of an anisotropic body.
    glm::vec3 DriftGenerator(unsigned slot,double time) const {
        const auto& body=bodies[slot];if(!body.HasMotion())return glm::vec3(0);
        const auto& segments=body.motion.Segments();
        auto it=std::upper_bound(segments.begin(),segments.end(),time,[](double t,const auto& segment){return t<segment.begin;});
        return it==segments.begin()?body.rigidBody.angularVelocity:(--it)->driftAngularVelocity;
    }
    // Lower bound on a fixed separating-plane gap along the anchored drift.
    // For q(t)=normalize(q0+t*Omega*q0/2), instantaneous angular speed is
    // |omega|/(1+(|omega|t/2)^2). Every rotated vertex has |r''|<=|omega|^2|r_perp|.
    // Evaluate ALL support vertices, including those not currently extremal.
    double PlaneDrift(unsigned a,unsigned b,int pa,int pb,double time,const glm::dvec3& n) {
        struct Vertex {glm::dvec3 r,velocity;double curvature;};
        struct Support {std::array<Vertex,128> vertices;int count=0;double radius=0;};
        auto support=[&](unsigned slot,int part) {
            Support result;const auto& body=bodies[slot];const auto& sample=ImpactPoseAt(slot,time);const auto& pose=sample.pose;
            const auto child=PrimitiveAt(body.shape,pose,part,&*sample.orientation);
            if(child.shape.type!=ShapeType::Box && child.shape.type!=ShapeType::Sphere&&child.shape.type!=ShapeType::ConvexHull&&child.shape.type!=ShapeType::TriangleMesh) return result;
            const auto& rotation=sample.orientation->rotation;
            const glm::dvec3 omega(DriftGenerator(slot,time));
            const double w2=glm::dot(omega,omega);
            const auto& segments=body.motion.Segments();
            auto segment=std::upper_bound(segments.begin(),segments.end(),time,[](double t,const auto& s){return t<s.begin;});
            const double elapsed=body.isDynamic && segment!=segments.begin() ? time-(--segment)->begin : 0;
            const glm::dvec3 instantaneous=body.isKinematic?omega:omega/(1+.25*w2*elapsed*elapsed);
            auto vertex=[&](glm::dvec3 local) {
                const glm::dvec3 r=rotation*local;
                const glm::dvec3 perpendicular=w2>0 ? r-omega*(glm::dot(omega,r)/w2) : glm::dvec3(0);
                result.vertices[result.count++]={r,glm::dvec3(body.HasMotion()?pose.linearVelocity:glm::vec3(0))+glm::cross(instantaneous,r),
                                                  w2*glm::length(perpendicular)};
            };
            if(child.shape.type==ShapeType::Sphere) {vertex(glm::dvec3(child.parentLocalCenter));result.radius=child.shape.radius;}
            else if(child.shape.type==ShapeType::ConvexHull){const auto r=ContactRotation(child.childRotation);for(auto p:child.shape.asset->vertices)vertex(glm::dvec3(child.parentLocalCenter)+r*p);}
            else if(child.shape.type==ShapeType::TriangleMesh){
                // The asset-space AABB encloses every mesh vertex. Its eight
                // transformed corners therefore certify a separating plane for
                // the entire mesh, including faces outside the current query.
                // This is only an advancement bound, never contact geometry.
                // If this larger enclosure crosses the plane we return zero
                // below and retain the original conservative/sampling search.
                const auto r=ContactRotation(child.childRotation);
                const auto lo=child.shape.asset->minimum,hi=child.shape.asset->maximum;
                for(int k=0;k<8;++k)vertex(glm::dvec3(child.parentLocalCenter)+r*glm::dvec3(k&1?hi.x:lo.x,k&2?hi.y:lo.y,k&4?hi.z:lo.z));
            }
            else {const auto childRotation=ContactRotation(child.childRotation);for(int k=0;k<8;++k) vertex(glm::dvec3(child.parentLocalCenter)+childRotation*glm::dvec3(child.shape.halfExtents)*
                glm::dvec3(k&1?1:-1,k&2?1:-1,k&4?1:-1));}
            return result;
        };
        const auto sa=support(a,pa),sb=support(b,pb);
        if(!sa.count || !sb.count) return 0;
        const glm::dvec3 delta=glm::dvec3(ImpactPoseAt(a,time).pose.position)-glm::dvec3(ImpactPoseAt(b,time).pose.position);
        double advance=std::numeric_limits<double>::infinity();
        for(int i=0;i<sa.count;++i) for(int j=0;j<sb.count;++j) {
            const auto& va=sa.vertices[i];const auto& vb=sb.vertices[j];
            const double gap=glm::dot(n,delta+va.r-vb.r)-sa.radius-sb.radius;
            if(!(gap>0)) return 0; // This sampled normal cannot certify a separating plane.
            const double rate=glm::dot(n,va.velocity-vb.velocity),curvature=va.curvature+vb.curvature;
            double root=std::numeric_limits<double>::infinity();
            if(curvature>0) {
                const double discriminant=std::sqrt(rate*rate+2*curvature*gap);
                root=rate<0 ? 2*gap/(discriminant-rate) : (rate+discriminant)/curvature;
            } else if(rate<0) root=-gap/rate;
            advance=std::min(advance,root);
        }
        return advance;
    }

    // Conservative advancement along a separating plane. Translation projected
    // onto that plane plus |omega|*radius bounds its possible closing speed.
    // Anchored quaternion interpolation turns no faster than |omega|.
    // Half the thinnest dimension of a primitive (sphere radius); infinite for
    // terrain and meshes, which use the other primitive's size.
    double PrimitiveFeature(unsigned slot,int part) const {
        const Shape& shape=bodies[slot].shape;
        auto primitive=PrimitiveAt(shape,bodies[slot].rigidBody,part);
        if(primitive.shape.type==ShapeType::Sphere) return double(primitive.shape.radius);
        if(primitive.shape.type==ShapeType::ConvexHull){auto extent=primitive.shape.asset->maximum-primitive.shape.asset->minimum;return std::min({extent.x,extent.y,extent.z})*.5;}
        const glm::vec3 half=shape.type==ShapeType::CompoundBoxes
            ? shape.boxes[std::size_t(part)].halfExtents : shape.halfExtents;
        if(shape.type==ShapeType::Box || shape.type==ShapeType::CompoundBoxes)
            return double(std::min({half.x,half.y,half.z}));
        // Terrain uses the other, finite rigid primitive's feature size.
        return std::numeric_limits<double>::infinity();
    }
    // A touching pair is normally left to the contact solver (support pair).
    // That holds while rotation cannot carry other features of a non-round
    // primitive through the support within the interval; a light body spun up
    // by an off-centre impact can turn several radians in one step. When the
    // rotation can sweep a point further than half the thinnest primitive's
    // thickness, the pair stays under continuous search with a penetration
    // target instead. (A lower bound also catches ragdoll limbs knocked about
    // on the ground, and changes how they come to rest.)
    bool SpinsThroughSupport(const std::array<unsigned,4>& key,double remaining,
                             double time=0,bool changedVelocity=false) {
        const auto convex=[](ShapeType type){return type==ShapeType::Box||type==ShapeType::Sphere||type==ShapeType::ConvexHull;};
        const auto typeA=PrimitiveAt(bodies[key[0]].shape,bodies[key[0]].rigidBody,int(key[2])).shape.type;
        const auto typeB=PrimitiveAt(bodies[key[1]].shape,bodies[key[1]].rigidBody,int(key[3])).shape.type;
        // A mesh/terrain contact normal is only a LOCAL triangle plane, not a
        // separating plane for the whole concave primitive. Keep its old rule.
        if(!convex(typeA)||!convex(typeB)){
            double oldSweep=0;
            for(int side=0;side<2;++side){const auto& body=bodies[key[side]];
                if(body.HasMotion()&&(side?typeB:typeA)!=ShapeType::Sphere)
                    oldSweep+=double(glm::length(body.rigidBody.angularVelocity))*body.boundingRadius*remaining;
            }
            const double feature=std::min(PrimitiveFeature(key[0],int(key[2])),PrimitiveFeature(key[1],int(key[3])));
            return std::isfinite(feature)&&oldSweep>feature;
        }
        std::array<glm::dvec3,2> omega{};
        double sweep=0;
        for(int side=0;side<2;++side){
            const unsigned slot=key[std::size_t(side)];const auto& body=bodies[slot];
            if(!body.HasMotion()||PrimitiveAt(body.shape,body.rigidBody,int(key[std::size_t(2+side)])).shape.type==ShapeType::Sphere)continue;
            // Use the same anchored geometric generator as the trajectory.
            // Immediately after an impulse the replacement segment has not
            // been published yet; predict exactly what Append will retain.
            omega[side]=glm::dvec3(changedVelocity
                ? body.isKinematic?body.rigidBody.angularVelocity:
                    AngularDriftGenerator(body.rigidBody.inverseInertiaLocal,body.rigidBody.orientation,
                                          body.rigidBody.angularVelocity,float(remaining))
                : DriftGenerator(slot,time));
            sweep+=double(glm::length(body.rigidBody.angularVelocity))*body.boundingRadius*remaining;
        }
        const double feature=std::min(PrimitiveFeature(key[0],int(key[2])),PrimitiveFeature(key[1],int(key[3])));
        if(!std::isfinite(feature)||sweep<=feature)return false;
        // A fixed support plane also bounds penetration after rotation. For
        // anchored drift about omega, projected vertex speed is bounded by
        // |n x omega|*R. In particular, rotation ABOUT n cannot penetrate that
        // plane. The old all-direction bound sent flat yaw-spinning bodies
        // through thousands of samples despite invariant support geometry.
        // Proximity supplies a separating plane only; no impulse is introduced.
        const auto manifold=PairAt(key[0],key[1],int(key[2]),int(key[3]),time,float(feature));
        if(!manifold.count)return true; // retain the conservative old decision
        const auto& contact=manifold.points[0];
        auto normal=contact.hasLocalAnchors?contact.preciseNormal:glm::dvec3(contact.normal);
        const double magnitude=glm::length(normal);
        if(!(magnitude>0)||!std::isfinite(magnitude))return true;
        normal/=magnitude;
        double projected=0;
        for(int side=0;side<2;++side)
            projected+=glm::length(glm::cross(normal,omega[side]))*bodies[key[side]].boundingRadius*remaining;
        return projected>feature;
    }
    static bool ContinuationPrimitive(const Body& body){
        return !body.shape.asset&&body.shape.pivotOffset==glm::vec3(0)&&
            (body.shape.type==ShapeType::Box||body.shape.type==ShapeType::Sphere);
    }
    bool SupportContinuationSafe(const std::array<unsigned,4>& key,double start,double finish){
        PhysicsWorkTimer timer(work.continuationProof,work.active);
        ++work.continuationAttempts;
        const auto& a=bodies[key[0]];const auto& b=bodies[key[1]];
        if(!ContinuationPrimitive(a)||!ContinuationPrimitive(b))return false;
        const auto& aa=ImpactPoseAt(key[0],start);const auto& bb=ImpactPoseAt(key[1],start);
        const float clearance=std::min(ContactSolver::kPenetrationSlop,float(.25*std::min(PrimitiveFeature(key[0],key[2]),PrimitiveFeature(key[1],key[3]))));
        const auto m=PairAt(key[0],key[1],key[2],key[3],start,clearance);
        if(!m.count||m.uncertain)return false;
        const glm::dvec3 normal=m.points[0].preciseNormal;
        // Preserve the original fallback for penetration already beyond the
        // ordinary position solver's allowance; do not enlarge that allowance.
        for(int i=0;i<m.count;++i)if(m.points[i].signedSeparation < -clearance){++work.continuationOverBudget;return false;}
        std::array<const RigidMotionSegment*,2> segments{};
        for(unsigned side=0;side<2;++side){
            const auto& body=bodies[key[side]];
            if(!body.HasMotion())continue;
            const auto& path=body.motion.Segments();
            auto it=std::upper_bound(path.begin(),path.end(),start,[](double t,const auto& s){return t<s.begin;});
            if(it==path.begin())return false;
            segments[side]=&*--it;
            if(finish>segments[side]->end)return false;
        }
        using contact_geometry::Iv;
        Iv norm(0);for(int k=0;k<3;++k)norm=norm+Iv(normal[k])*Iv(normal[k]);
        const Iv allowance=Iv(double(clearance))*contact_geometry::Sqrt(norm);
        auto gap=[&](double lo,double hi)->std::optional<Iv>{
            auto extent=[&](unsigned side,const ImpactPoseSample& sample){
                auto pose=sample.pose;pose.position=glm::vec3(0);
                return rigid_motion_bounds::TryPrimitiveSweepProjection(bodies[key[side]].shape,segments[side],pose,pose,lo,hi,normal,glm::dvec3(0),*sample.orientation);
            };
            const auto first=extent(0,aa),second=extent(1,bb);
            const auto relative=rigid_motion_bounds::TryRelativeCentreProjection(segments[0],segments[1],aa.pose,bb.pose,lo,hi,normal);
            if(!first||!second||!relative)return std::nullopt;
            return *relative+Iv(first->lo)-Iv(second->hi)+allowance;
        };
        const auto entire=gap(start,finish);if(!entire)return false;
        if(entire->lo>0){++work.continuationAccepted;return true;}
        const auto end=gap(finish,finish);if(!end||end->hi<=0)return false;
        // Subdivision tightens a conservative rotation enclosure; it is not
        // temporal collision sampling. Every accepted leaf covers ALL times.
        auto certify=[&](auto&& self,double lo,double hi,unsigned depth)->bool{
            ++work.continuationPartitions;
            const auto bound=gap(lo,hi);if(!bound)return false;
            if(bound->lo>0)return true;
            if(!depth||bound->hi<=0)return false;
            const double mid=(lo+hi)*.5;
            return self(self,lo,mid,depth-1)&&self(self,mid,hi,depth-1);
        };
        if(certify(certify,start,finish,3)){++work.continuationAccepted;return true;}
        return false;
    }
    // A quarter of the existing half-dimension feature (one eighth of the
    // full thickness for boxes), measured relative to the current overlap.
    double SpinPenetrationTarget(const std::array<unsigned,4>& key) const {
        return .25*std::min(PrimitiveFeature(key[0],int(key[2])),PrimitiveFeature(key[1],int(key[3])));
    }
    // target>0: find the first time the pair's deepest penetration exceeds
    // its depth at `start` by target (a pair already touching, e.g. pivoting
    // on one corner), rather than the first touch. Measuring from the start
    // depth lets the search continue after an event that ended at the target.
    double ImpactTime(unsigned a, unsigned b, int pa, int pb, double start, double finish,
                      double target = 0) {
        PhysicsWorkTimer timer(work.toi, work.active);
        // A target can finish inside the step. Never certify a plane across
        // its velocity discontinuity; search the two real ledger intervals.
        for (auto slot : {a, b})
            if (bodies[slot].isKinematic)
                for (const auto &s : bodies[slot].motion.Segments())
                    if (s.end > start && s.end < finish) {
                        auto first = ImpactTime(a, b, pa, pb, start, s.end, target);
                        return first <= s.end ? first
                                              : ImpactTime(a, b, pa, pb, s.end, finish, target);
                    }
        ++stats.impactQueries;
        if (target > 0)
            target += PairPenetration(a, b, pa, pb, start);
        const auto &ba = bodies[a];
        const auto &bb = bodies[b];
        const auto simpleRadius = [](const Body &body) {
            return (body.shape.type == ShapeType::Box || body.shape.type == ShapeType::Sphere) &&
                   body.shape.pivotOffset == glm::vec3(0) && std::isfinite(body.boundingRadius) &&
                   body.boundingRadius > 0;
        };
        // Restrict this rejection to the existing outward-proven primitive
        // radius/bounds. Compound, cooked and terrain shapes retain the full
        // old query until their radius enclosure is independently established.
        if (simpleRadius(ba) && simpleRadius(bb)) {
            const auto &boundA = RemainingImpactBound(a, start, finish);
            const auto &boundB = RemainingImpactBound(b, start, finish);
            const auto finite = [](const Aabb &bound) {
                for (int k = 0; k < 3; ++k)
                    if (!std::isfinite(bound.min[k]) || !std::isfinite(bound.max[k]))
                        return false;
                return true;
            };
            // An arithmetic-range failure is not a geometric rejection. Keep
            // the established query path whenever the enclosure is uncertain.
            if (finite(boundA) && finite(boundB) && !boundA.Overlaps(boundB)) {
                ++impactBoundsRejected;
                return finish + 1;
            }
        }
        const auto posa = ImpactPoseAt(a, start).pose, posb = ImpactPoseAt(b, start).pose;
        const auto firstPrimitive = PrimitiveAt(ba.shape, posa, pa),
                   secondPrimitive = PrimitiveAt(bb.shape, posb, pb);
        const bool firstMesh =
            firstPrimitive.shape.type == ShapeType::TriangleMesh && !ba.HasMotion();
        const bool secondMesh =
            secondPrimitive.shape.type == ShapeType::TriangleMesh && !bb.HasMotion();
        const auto convexPoly = [](ShapeType type) {
            return type == ShapeType::Box || type == ShapeType::ConvexHull;
        };
        const bool meshAdvance = (firstMesh && convexPoly(secondPrimitive.shape.type)) ||
                                 (secondMesh && convexPoly(firstPrimitive.shape.type));
        const glm::dvec3 relative =
            glm::dvec3(ba.HasMotion() ? posa.linearVelocity : glm::vec3(0)) -
            glm::dvec3(bb.HasMotion() ? posb.linearVelocity : glm::vec3(0));
        const double angular =
            (ba.HasMotion() ? glm::length(glm::dvec3(DriftGenerator(a, start))) * ba.boundingRadius
                            : 0) +
            (bb.HasMotion() ? glm::length(glm::dvec3(DriftGenerator(b, start))) * bb.boundingRadius
                            : 0);
        const double speed = glm::length(relative) + angular;
        if (!(speed > 0))
            return finish + 1;
        // Bisection still performs all 32 represented-time bracket updates.
        // Binary32 pose integration can map several of those times to exactly
        // the same pair of poses. Contact truth for that identical geometry is
        // reusable; no margin contact, tolerance or earlier stopping is used.
        struct ActualTruth {
            std::array<float, 14> pose{};
            bool valid = false, touching = false;
        };
        std::array<ActualTruth, 3> actualTruth{};
        std::size_t nextTruth = 0;
        auto touchingAt = [&](double at) {
            ++impactTruthRequests;
            const auto &aa = ImpactPoseAt(a, at).pose;
            const auto &bb = ImpactPoseAt(b, at).pose;
            const std::array<float, 14> represented = {
                aa.position.x,    aa.position.y,    aa.position.z,    aa.orientation.w,
                aa.orientation.x, aa.orientation.y, aa.orientation.z, bb.position.x,
                bb.position.y,    bb.position.z,    bb.orientation.w, bb.orientation.x,
                bb.orientation.y, bb.orientation.z};
            for (const auto &old : actualTruth)
                if (old.valid &&
                    std::memcmp(old.pose.data(), represented.data(), sizeof(represented)) == 0) {
                    ++impactTruthReuses;
                    return old.touching;
                }
            const bool touching = target > 0 ? PairPenetrationExceeds(a, b, pa, pb, at, target)
                                             : PairTouches(a, b, pa, pb, at);
            actualTruth[nextTruth] = {represented, true, touching};
            nextTruth = (nextTruth + 1) % actualTruth.size();
            return touching;
        };
        double time = start, previous = start;
        bool uncertifiedAdvance = false, stalled = false;
        // A grazing feature on a concave surface (a limb sliding in a curved
        // mesh ramp) keeps the gap tiny while the surface keeps closing ahead,
        // so each advance covers a sliver of the interval. After several such
        // consecutive advances, stop paying full proximity queries and finish
        // with the bounded sampling below, as the 64-iteration limit already does.
        int stalledAdvances = 0;
        // Conservative advancement needs a separating plane. A pair searched
        // to a penetration target is already in contact, where no single
        // contact normal bounds the approach of every feature; go straight to
        // the bounded sampling below.
        const int advanceIterations = target > 0 ? 0 : 64;
        for (int iteration = 0; iteration < advanceIterations; ++iteration) {
            ++stats.impactSearchIterations;
            stats.impactPeakIterations =
                std::max(stats.impactPeakIterations, std::size_t(iteration + 1));
            const float reach = std::nextafter(static_cast<float>(speed * (finish - time)),
                                               std::numeric_limits<float>::infinity());
            // Margin manifolds contain proximity features, not necessarily the
            // zero-margin contact set. Contact truth must use the latter.
            if (touchingAt(time)) {
                // A pair touching at the start is left to the contact solver,
                // unless its spin can turn another feature through the support
                // before the interval ends: then search to a penetration target.
                if (time == start)
                    return target == 0 && SpinsThroughSupport({a, b, unsigned(pa), unsigned(pb)},
                                                              finish - start, start)
                               ? ImpactTime(
                                     a, b, pa, pb, start, finish,
                                     SpinPenetrationTarget({a, b, unsigned(pa), unsigned(pb)}))
                               : finish + 1;
                double lo = previous, hi = time;
                for (int k = 0; k < 32; ++k) {
                    const double mid = (lo + hi) * .5;
                    if (touchingAt(mid))
                        hi = mid;
                    else
                        lo = mid;
                }
                return hi;
            }
            // The exact endpoint has already been checked. There is no future
            // interval left from which a proximity reach could reveal a hit.
            if (time == finish)
                return finish + 1;
            double increment;
            if (meshAdvance) {
                PhysicsWorkTimer geometryTimer(work.geometry, work.active);
                const auto &aa = ImpactPoseAt(a, time);
                const auto &bb = ImpactPoseAt(b, time);
                const auto query =
                    firstMesh ? PrimitiveAt(bodies[b].shape, bb.pose, pb, &*bb.orientation)
                              : PrimitiveAt(bodies[a].shape, aa.pose, pa, &*aa.orientation);
                const auto mesh = firstMesh
                                      ? PrimitiveAt(bodies[a].shape, aa.pose, pa, &*aa.orientation)
                                      : PrimitiveAt(bodies[b].shape, bb.pose, pb, &*bb.orientation);
                const unsigned moving = firstMesh ? b : a;
                increment = MeshSeparationAdvance(
                    query, mesh,
                    glm::dvec3(firstMesh ? bb.pose.linearVelocity : aa.pose.linearVelocity),
                    glm::dvec3(DriftGenerator(moving, time)), bodies[moving].boundingRadius,
                    finish - time);
                if (!std::isfinite(increment))
                    return finish + 1;
                if (!(increment > 0)) {
                    ++stats.impactUncertifiedAdvances;
                    uncertifiedAdvance = true;
                    break;
                }
            } else {
                const auto manifold = PairAt(a, b, pa, pb, time, reach);
                if (!manifold.count)
                    return finish + 1;
                const Contact *nearest = &manifold.points[0];
                for (int k = 1; k < manifold.count; ++k)
                    if (manifold.points[k].signedSeparation < nearest->signedSeparation)
                        nearest = &manifold.points[k];
                const double gap = nearest->hasLocalAnchors ? nearest->signedSeparation
                                                            : -double(nearest->penetration);
                if (gap <= 0) {
                    ++stats.impactUncertifiedAdvances;
                    uncertifiedAdvance = true;
                    break;
                }
                const auto normal =
                    nearest->hasLocalAnchors ? nearest->preciseNormal : glm::dvec3(nearest->normal);
                const double closing = -glm::dot(relative, normal) + angular;
                if (!(closing > 0))
                    return finish + 1;
                increment = gap / closing;
                if (angular > 0)
                    increment = std::max(increment, PlaneDrift(a, b, pa, pb, time, normal));
            }
            // Progress in represented time only. A large coordinate orthogonal
            // to motion must not enlarge the step and skip a thin obstacle.
            increment = std::max(increment, std::nextafter(time, finish) - time);
            previous = time;
            time = std::min(finish, time + increment);
            if (time <= previous)
                return finish + 1;
            stalledAdvances = time - previous < kImpactStallFraction * (finish - previous)
                                  ? stalledAdvances + 1
                                  : 0;
            if (stalledAdvances >= kImpactStallAdvances) {
                stalled = true;
                break;
            }
        }
        if (stalled)
            ++stats.impactSearchStalls;
        else if (!uncertifiedAdvance && target == 0)
            ++stats.impactSearchLimit;
        ++stats.impactSamplingFallbacks;
        // Rotating grazing features can keep a fixed separating-plane bound
        // arbitrarily short. Finish this PAIR query with a bounded temporal
        // sampling approximation, never by applying an impulse across a gap.
        // Intersections shorter than the reported sampling interval can be
        // missed; this is deliberately not a complete continuous-CCD proof.
        auto firstContact = [&](double lo, double hi) {
            for (int k = 0; k < 32; ++k) {
                const double mid = (lo + hi) * .5;
                if (touchingAt(mid))
                    hi = mid;
                else
                    lo = mid;
            }
            return hi;
        };
        ++stats.impactSamplingTests;
        if (touchingAt(time))
            return firstContact(previous, time);
        const double remaining = finish - time;
        if (!(remaining > 0))
            return finish + 1;
        const double feature = std::min(PrimitiveFeature(a, pa), PrimitiveFeature(b, pb));
        if (!(feature > 0))
            throw std::runtime_error("invalid primitive feature in impact sampling");
        const double angularSpeed =
            (ba.HasMotion() ? glm::length(glm::dvec3(DriftGenerator(a, start))) : 0) +
            (bb.HasMotion() ? glm::length(glm::dvec3(DriftGenerator(b, start))) : 0);
        const double requested = std::max({16.0, std::ceil(16.0 * speed * remaining / feature),
                                           std::ceil(256.0 * angularSpeed * remaining)});
        constexpr unsigned kMaxSamples = 65536;
        if (requested > double(kMaxSamples))
            ++stats.impactSamplingResolutionCaps;
        const unsigned samples = static_cast<unsigned>(std::min(double(kMaxSamples), requested));
        const double interval = remaining / double(samples);
        stats.impactSamplingMaxInterval = std::max(stats.impactSamplingMaxInterval, interval);
        double lo = time;
        for (unsigned sample = 1; sample <= samples; ++sample) {
            const double hi =
                sample == samples ? finish : time + remaining * (double(sample) / double(samples));
            ++stats.impactSamplingTests;
            if (touchingAt(hi))
                return firstContact(lo, hi);
            lo = hi;
        }
        return finish + 1;
    }

    void ResolveInitialImpacts(float dt) {
        if (std::none_of(startContacts.begin(),startContacts.end(),[](const auto& c){return c.newImpact;})) return;
        std::vector<Contact> geometry;
        geometry.reserve(solver.Constraints().size());
        for(const auto& c:solver.Constraints()) {
            Contact g;g.hit=true;g.point=c.point;g.normal=c.normal;g.preciseNormal=c.preciseNormal;
            g.penetration=c.penetration;g.signedSeparation=c.signedSeparation;
            g.localAnchorA=c.localAnchorA;g.localAnchorB=c.localAnchorB;g.hasLocalAnchors=c.hasLocalAnchors;
            g.anchorAInWorldFrame=c.anchorAInWorldFrame;g.anchorBInWorldFrame=c.anchorBInWorldFrame;
            geometry.push_back(g);
        }
        std::vector<unsigned> parent(bodies.size());
        for (unsigned i=0;i<parent.size();++i) parent[i]=i;
        auto root=[&](unsigned i){while(parent[i]!=i) {parent[i]=parent[parent[i]];i=parent[i];}return i;};
        for (const auto& c:startContacts) if (!bodies[c.a].rigidBody.IsStatic() && !bodies[c.b].rigidBody.IsStatic())
            parent[root(c.b)]=root(c.a);
        for(const auto& joint:joints)if(JointActive(joint)&&joint.state.settings.bodyB.IsValid()){
            const auto a=joint.state.settings.bodyA.id&kSlotMask,b=joint.state.settings.bodyB.id&kSlotMask;
            if(!bodies[a].rigidBody.IsStatic()&&!bodies[b].rigidBody.IsStatic())parent[root(b)]=root(a);
        }
        std::vector<std::pair<unsigned,std::size_t>> order;
        for (std::size_t i=0;i<startContacts.size();++i) {
            const auto& c=startContacts[i];
            order.emplace_back(root(bodies[c.a].rigidBody.IsStatic()?c.b:c.a),i);
        }
        std::sort(order.begin(),order.end());
        for (std::size_t begin=0;begin<order.size();) {
            std::size_t end=begin+1; bool impact=startContacts[order[begin].second].newImpact;
            while(end<order.size() && order[end].first==order[begin].first) {
                impact=impact||startContacts[order[end].second].newImpact;++end;
            }
            if (impact) {
                std::vector<ImpactContact> rows;
                for (auto k=begin;k<end;++k) {
                    auto& c=startContacts[order[k].second];
                    const bool persistent=c.warmNormal>0;
                    c.warmNormal=0;c.warmTangent=glm::vec3(0);
                    if (geometry[c.constraint].signedSeparation>0) continue;
                    auto& a=bodies[c.a];auto& b=bodies[c.b];
                    rows.push_back({&a.rigidBody,&b.rigidBody,geometry[c.constraint],c.friction,
                                    std::max(a.restitution,b.restitution),persistent});
                }
                std::vector<unsigned char> included(bodies.size(),0);
                for(unsigned slot:aliveSlots)if(root(slot)==order[begin].first)included[slot]=1;
                PrepareJoints(eventJointSolver,JointInputs(&included),dt,false,true);
                const auto result=[&]{PhysicsWorkTimer timer(work.impactSolve,work.active);
                    return impactSolver.Solve(rows,dt,false,eventJointSolver.Empty()?nullptr:&eventJointSolver);}();
                if(!result.energyBudgetSatisfied) throw std::runtime_error("inelastic impact energy guard failed");
                if(result.effectiveRestitution==0) for(auto k=begin;k<end;++k) startContacts[order[k].second].newImpact=false;
                ++stats.impactEvents; stats.impactSafetyFallback+=result.safetyFallback;
            }
            begin=end;
        }
        // Only the rare time-zero impact path needs rebuilt warm-start inputs.
        // Persistent contact solver arithmetic and APIs remain unchanged.
        solver.Clear();
        for(const auto& c:startContacts) {
            auto& a=bodies[c.a];auto& b=bodies[c.b];
            const auto& oa=Orientation(a);const auto& ob=Orientation(b);
            solver.AddContact(a.rigidBody,b.rigidBody,geometry[c.constraint],c.friction,0,
                c.warmNormal,c.warmTangent,&oa.rotation,&ob.rotation);
        }
    }

    void AdvanceImpacts(float dt, bool coupledVelocityChanged = false) {
        // Keep published contact storage ordered even if a later physical
        // query throws. Successful steps sort once; failure observers retain
        // the same lower_bound invariant as the former per-event publication.
        struct ObservationPublication {
            std::vector<CachedContact> &rows;
            PhysicsWorkSample &work;
            bool active, dirty = false;
            void Publish() {
                if (!dirty)
                    return;
                PhysicsWorkTimer timer(work, active);
                std::stable_sort(
                    rows.begin(), rows.end(),
                    [](const CachedContact &a, const CachedContact &b) { return a.key < b.key; });
                dirty = false;
            }
            ~ObservationPublication() {
                Publish();
            }
        } observationPublication{completedContactObservations, work.impactObservations,
                                 work.active};
        // The incoming cache is already ordered. Only newly appended TOI
        // identities require publication; erasure and impulse changes preserve
        // order. Keep that invariant on failure as well as successful return.
        ObservationPublication cachePublication{contactCache, work.continuationCache, work.active};
        stepDuration = dt;
        impactQueryAnchorTime = 0;
        impactPoseEvaluations = impactPoseReuses = impactOrientationBuilds = impactTruthRequests =
            impactTruthReuses = impactBoundsRejected = 0;
        impactActualBoundsRejected = 0;
        for (auto slot : aliveSlots) {
            InvalidateImpactPose(slot);
            if (slot < impactPoseSamples.size())
                impactPoseSamples[slot].tightValid = false;
        }
        impactCounts.assign(bodies.size(), 0);
        impactCapped.assign(bodies.size(), 0);
        // A sleeping body still needs its stationary pre-impact trajectory.
        // An actual TOI may wake it and append a new segment during this step.
        for (const auto slot : aliveSlots)
            if (bodies[slot].isDynamic) {
                bodies[slot].motion.Begin(MakeHandle(slot).id, bodies[slot].rigidBody, dt);
                InvalidateImpactPose(slot);
            }
        // Initial touching impacts can launch a previously stationary body.
        // Refresh those trajectories before searching for a separated event.
        if (stats.impactEvents || coupledVelocityChanged) {
            for (auto slot : aliveSlots)
                if (bodies[slot].isDynamic)
                    CoverStepReach(bodies[slot], dt);
            GenerateCandidatePairs();
            separatedPairs.clear();
            for (const auto &pair : candidatePairs)
                for (int pa = 0; pa < PrimitiveCount(bodies[pair.first].shape); ++pa)
                    for (int pb = 0; pb < PrimitiveCount(bodies[pair.second].shape); ++pb)
                        separatedPairs.push_back(
                            {pair.first, pair.second, unsigned(pa), unsigned(pb)});
        }
        // Support pairs whose rotation over the step could carry a feature
        // through the support remain under continuous search.
        spinningPairs.clear();
        for (const auto &key : supportPairs)
            if (SpinsThroughSupport(key, dt))
                spinningPairs.push_back(key);
        if (!spinningPairs.empty())
            supportPairs.erase(std::remove_if(supportPairs.begin(), supportPairs.end(),
                                              [&](const auto &key) {
                                                  return std::binary_search(spinningPairs.begin(),
                                                                            spinningPairs.end(),
                                                                            key);
                                              }),
                               supportPairs.end());
        // Preserve joint encounter order, but visit only incident joints while
        // growing an impact island. Scanning every unrelated joint for every
        // reached body makes independent machinery multiply dense-pile cost.
        // Allocate/build only once an actual event needs island discovery.
        // Free flight and fully quiet worlds must not pay this scratch cost.
        std::vector<std::vector<unsigned>> impactJointNeighbours;
        bool jointNeighboursReady = false;
        double now = 0;
        scheduledImpacts.clear();
        struct ScheduledKeyHash {
            std::size_t operator()(const std::array<unsigned, 4>& key) const noexcept {
                // Lookup only. Scheduled vector and final sorted dirty keys own order.
                std::uint64_t value = (std::uint64_t(key[0]) << 32) | key[1];
                value ^= (std::uint64_t(key[2]) << 32) | key[3];
                value ^= value >> 30;
                value *= 0xbf58476d1ce4e5b9ULL;
                value ^= value >> 27;
                value *= 0x94d049bb133111ebULL;
                return std::size_t(value ^ (value >> 31));
            }
        };
        std::unordered_map<std::array<unsigned, 4>, std::size_t, ScheduledKeyHash> scheduledIndex;
        auto schedule = [&](const std::array<unsigned, 4> &key) {
            if (!CanRespond(key[0], key[1]))
                return;
            const double time =
                std::binary_search(supportPairs.begin(), supportPairs.end(), key) ? double(dt) + 1
                : std::binary_search(spinningPairs.begin(), spinningPairs.end(), key)
                    ? ImpactTime(key[0], key[1], int(key[2]), int(key[3]), now, dt,
                                 SpinPenetrationTarget(key))
                    : ImpactTime(key[0], key[1], int(key[2]), int(key[3]), now, dt);
            const auto found = scheduledIndex.find(key);
            if (found != scheduledIndex.end())
                scheduledImpacts[found->second].time = time;
            else {
                scheduledIndex.emplace(key, scheduledImpacts.size());
                scheduledImpacts.push_back({key, time});
            }
        };
        for (const auto &key : separatedPairs)
            schedule(key);
        for (const auto &key : spinningPairs)
            schedule(key);
        // Capacities live through this event pass; values and membership are
        // rebuilt for each event. No cross-time contact truth is cached.
        ImpactPairVisitSet visitedPairs;
        struct DiscoveredManifold {
            std::size_t touchingIndex;
            int partA, partB;
            ContactManifold geometry;
        };
        std::vector<unsigned> island;
        std::vector<unsigned char> included;
        std::vector<std::pair<unsigned, unsigned>> touching;
        std::vector<DiscoveredManifold> discoveredManifolds;
        std::vector<std::pair<glm::vec3, glm::vec3>> oldVelocities;
        std::vector<ImpactContact> rows;
        std::vector<ContactKey> observationKeys;
        std::vector<std::array<unsigned, 4>> eventPairs;
        std::vector<std::array<unsigned, 4>> eventPairMembership;
        ImpactPairVisitSet dirtyBodyPairs;
        std::vector<unsigned char> dirtyScheduled;
        std::vector<std::array<unsigned, 4>> dirty;
        for (;;) {
            double earliest = double(dt) + 1;
            unsigned seedA = 0, seedB = 0;
            std::array<unsigned, 4> selected{};
            for (const auto &event : scheduledImpacts) {
                if (event.time < earliest || (event.time == earliest && event.key < selected)) {
                    earliest = event.time;
                    selected = event.key;
                    seedA = event.key[0];
                    seedB = event.key[1];
                }
            }
            if (earliest > dt)
                break;
            if (!jointNeighboursReady) {
                impactJointNeighbours.resize(bodies.size());
                for (const auto &joint : joints)
                    if (JointActive(joint) && joint.state.settings.bodyB.IsValid()) {
                        const auto a = joint.state.settings.bodyA.id & kSlotMask,
                                   b = joint.state.settings.bodyB.id & kSlotMask;
                        impactJointNeighbours[a].push_back(b);
                        if (a != b)
                            impactJointNeighbours[b].push_back(a);
                    }
                jointNeighboursReady = true;
            }
            now = earliest;
            impactQueryAnchorTime = now;
            // Infinite-mass boundaries do not join the velocity-changing
            // island, but solver lever arms and observed point velocities
            // must use their actual event-time COM/orientation.
            for (auto slot : aliveSlots)
                if (bodies[slot].isKinematic) {
                    auto &b = bodies[slot];
                    auto p = PoseAt(slot, now);
                    b.rigidBody.position = p.position;
                    b.rigidBody.orientation = p.orientation;
                    b.rigidBody.linearVelocity = p.linearVelocity;
                    b.rigidBody.angularVelocity = p.angularVelocity;
                }
            island.clear();
            included.assign(bodies.size(), 0);
            auto include = [&](unsigned slot) {
                if (!included[slot] && !bodies[slot].rigidBody.IsStatic()) {
                    if (bodies[slot].sleeping)
                        Wake(slot);
                    included[slot] = 1;
                    island.push_back(slot);
                }
            };
            include(seedA);
            include(seedB);
            touching.clear();
            discoveredManifolds.clear();
            visitedPairs.Begin(bodies.size());
            // Membership removes only previously resolved identical queries;
            // encounter order and uncertainty handling remain unchanged.
            const auto simplePart = [&](unsigned slot, int part) {
                const auto &shape = bodies[slot].shape;
                const auto type = shape.type == ShapeType::CompoundBoxes
                                      ? shape.boxes[std::size_t(part)].type
                                      : shape.type;
                return type == ShapeType::Box || type == ShapeType::Sphere;
            };
            {
                PhysicsWorkTimer timer(work.impactIslands, work.active);
                for (std::size_t next = 0; next < island.size(); ++next) {
                    const unsigned a = island[next];
                    for (unsigned neighbour : impactJointNeighbours[a])
                        include(neighbour);
                    const auto &candidates = QuerySlots(ActualImpactBound(a, ImpactPoseAt(a, now)));
                    for (unsigned b : candidates) {
                        if (a == b || !CanRespond(a, b))
                            continue;
                        const auto pair = std::minmax(a, b);
                        const uint64_t pairKey = (uint64_t(pair.first) << 32) | pair.second;
                        if (visitedPairs.Contains(pairKey))
                            continue;
                        bool hit = false, reliableMiss = true;
                        std::optional<DiscoveredManifold> discovered;
                        for (int pa = 0; pa < PrimitiveCount(bodies[a].shape); ++pa)
                            for (int pb = 0; pb < PrimitiveCount(bodies[b].shape); ++pb) {
                                if (hit)
                                    continue; // Preserve the existing first-hit short circuit.
                                if (simplePart(a, pa) && simplePart(b, pb)) {
                                    auto geometry = PairAt(a, b, pa, pb, now, 0);
                                    hit = geometry.count > 0;
                                    reliableMiss &= !geometry.uncertain;
                                    // Response is always in ascending body order.
                                    // A reversed discovery must retain the original
                                    // canonical response query, not flip its rows.
                                    if (hit && a == pair.first)
                                        discovered = DiscoveredManifold{touching.size(), pa, pb,
                                                                        std::move(geometry)};
                                } else {
                                    hit = PairTouches(a, b, pa, pb, now);
                                    // Specialized Boolean paths stay unchanged;
                                    // a miss carries no public uncertainty proof.
                                    reliableMiss = false;
                                }
                            }
                        if (hit) {
                            visitedPairs.Insert(pairKey);
                            if (discovered)
                                discoveredManifolds.push_back(std::move(*discovered));
                            touching.emplace_back(pair);
                            include(b);
                        } else if (reliableMiss) {
                            // Only a resolved primitive separation may suppress
                            // the reverse traversal's identical existence query.
                            visitedPairs.Insert(pairKey);
                        }
                    }
                }
            }
            // A supported body's incoming impact is mechanically coupled even
            // when a cached support point currently has a small positive gap.
            // This only chooses restitution zero: separated support geometry
            // is never inserted into the actual-contact impulse rows below.
            // Spinning support pairs are still supports.
            const auto supports = [&](const auto &pair) {
                return included[pair[0]] || included[pair[1]];
            };
            const bool supportedIsland =
                std::any_of(supportPairs.begin(), supportPairs.end(), supports) ||
                std::any_of(spinningPairs.begin(), spinningPairs.end(), supports);
            bool capture = supportedIsland;
            oldVelocities.clear();
            oldVelocities.reserve(island.size());
            for (unsigned slot : island) {
                auto &body = bodies[slot];
                const auto pose = PoseAt(slot, now);
                body.rigidBody.angularVelocity = pose.angularVelocity;
                oldVelocities.emplace_back(body.rigidBody.linearVelocity,
                                           body.rigidBody.angularVelocity);
                body.rigidBody.position = pose.position;
                body.rigidBody.orientation = pose.orientation;
                // Gravity was deferred while stationary. Integrate only the
                // remaining interval; never drift the frozen pre-impact pose.
                if (body.deferredAcceleration) {
                    body.rigidBody.linearVelocity +=
                        body.lastAcceleration * static_cast<float>(dt - now);
                    body.deferredAcceleration = false;
                }
                if (++impactCounts[slot] > 16) {
                    if (!impactCapped[slot]) {
                        impactCapped[slot] = 1;
                        ++stats.impactEventCapFallback;
                    }
                    capture = true;
                }
            }
            rows.clear();
            observationKeys.clear();
            eventPairs.clear();
            std::size_t discoveredIndex = 0;
            for (std::size_t touchingIndex = 0; touchingIndex < touching.size(); ++touchingIndex) {
                const auto &pair = touching[touchingIndex];
                const DiscoveredManifold *discovered =
                    discoveredIndex < discoveredManifolds.size() &&
                            discoveredManifolds[discoveredIndex].touchingIndex == touchingIndex
                        ? &discoveredManifolds[discoveredIndex++]
                        : nullptr;
                auto &a = bodies[pair.first];
                auto &b = bodies[pair.second];
                for (int pa = 0; pa < PrimitiveCount(a.shape); ++pa)
                    for (int pb = 0; pb < PrimitiveCount(b.shape); ++pb) {
                        const auto m =
                            discovered && discovered->partA == pa && discovered->partB == pb
                                ? discovered->geometry
                                : PairAt(pair.first, pair.second, pa, pb, now, 0);
                        if (m.count)
                            eventPairs.push_back(
                                {pair.first, pair.second, unsigned(pa), unsigned(pb)});
                        for (int k = 0; k < m.count; ++k) {
                            Observe(pair.first, pair.second, m.points[k]);
                            observationKeys.push_back(
                                {pair.first, pair.second, a.generation, b.generation, pa, pb});
                            rows.push_back(
                                {&a.rigidBody, &b.rigidBody, m.points[k],
                                 std::sqrt(std::max(0.f, a.friction) * std::max(0.f, b.friction)),
                                 std::max(a.restitution, b.restitution), false});
                            lastStepContacts.push_back(
                                {m.points[k].point, m.points[k].normal, m.points[k].penetration});
                        }
                    }
            }
            if (rows.empty())
                throw std::runtime_error("impact bracket lost contact geometry");
            if (work.active) {
                work.peakImpactBodies = std::max(work.peakImpactBodies, island.size());
                work.peakImpactRows = std::max(work.peakImpactRows, rows.size());
            }
            PrepareJoints(eventJointSolver, JointInputs(&included), dt, false, true);
            const auto result = [&] {
                PhysicsWorkTimer timer(work.impactSolve, work.active);
                return impactSolver.Solve(rows, dt, capture,
                                          eventJointSolver.Empty() ? nullptr : &eventJointSolver);
            }();
            if (!result.energyBudgetSatisfied)
                throw std::runtime_error("inelastic impact energy guard failed");
            // Replace only primitive groups for which actual TOI geometry
            // was solved. Never replay warm impulses or duplicate repeated
            // TOI loads. Unaffected stance groups retain their completed rows.
            {
                PhysicsWorkTimer timer(work.impactObservations, work.active);
                auto replacedGroups = observationKeys;
                const auto groupLess = [](const ContactKey &a, const ContactKey &b) {
                    return std::tie(a.slotA, a.slotB, a.partA, a.partB, a.generationA,
                                    a.generationB) < std::tie(b.slotA, b.slotB, b.partA, b.partB,
                                                              b.generationA, b.generationB);
                };
                std::sort(replacedGroups.begin(), replacedGroups.end(), groupLess);
                replacedGroups.erase(std::unique(replacedGroups.begin(), replacedGroups.end(),
                                                 [](const ContactKey &a, const ContactKey &b) {
                                                     return a.SameBodies(b);
                                                 }),
                                     replacedGroups.end());
                observationPublication.dirty = true;
                completedContactObservations.erase(
                    std::remove_if(
                        completedContactObservations.begin(), completedContactObservations.end(),
                        [&](const CachedContact &cached) {
                            return std::binary_search(replacedGroups.begin(), replacedGroups.end(),
                                                      cached.key, groupLess);
                        }),
                    completedContactObservations.end());
                const auto &observed = impactSolver.Constraints();
                if (observed.size() != observationKeys.size())
                    throw std::runtime_error("impact observation mapping mismatch");
                for (std::size_t i = 0; i < observed.size(); ++i) {
                    const auto &row = observed[i];
                    const auto &key = observationKeys[i];
                    if (row.normalImpulse <= 0)
                        continue;
                    completedContactObservations.push_back(
                        {key, row.localAnchorA, row.normal, row.normalImpulse, row.tangentImpulse,
                         float(row.signedSeparation), bodies[key.slotA].contactObservationRevision,
                         bodies[key.slotB].contactObservationRevision});
                }
            }
            if (result.effectiveRestitution == 0) {
                // An inelastic event leaves the pair touching. It becomes a
                // support pair unless its new spin can still turn a feature
                // through the support before the step ends.
                for (const auto &key : eventPairs) {
                    const bool spinning = SpinsThroughSupport(key, double(dt) - now, now, true);
                    auto &into = spinning ? spinningPairs : supportPairs;
                    auto &from = spinning ? supportPairs : spinningPairs;
                    from.erase(std::remove(from.begin(), from.end(), key), from.end());
                    into.insert(std::upper_bound(into.begin(), into.end(), key), key);
                    into.erase(std::unique(into.begin(), into.end()), into.end());
                }
            }
            ++stats.impactEvents;
            stats.impactSafetyFallback += result.safetyFallback;
            // A geometric overlap enclosure alone does not certify the reaction
            // history of a coupled mechanical system. Keep the original event
            // and cache policy for hard joints, external couplers and elastic
            // flights. The fast continuation is for free inelastic primitives.
            const bool continuationEligible =
                result.effectiveRestitution == 0 && eventJointSolver.Empty() &&
                !coupledVelocityChanged &&
                std::all_of(eventPairs.begin(), eventPairs.end(), [&](const auto &pair) {
                    return ContinuationPrimitive(bodies[pair[0]]) &&
                           ContinuationPrimitive(bodies[pair[1]]);
                });
            if (work.active) {
                if (!eventJointSolver.Empty() || coupledVelocityChanged)
                    ++work.coupledFallbackEvents;
                else if (result.effectiveRestitution != 0)
                    ++work.elasticFallbackEvents;
                else if (!continuationEligible)
                    ++work.geometryFallbackEvents;
            }
            {
                PhysicsWorkTimer timer(work.continuationCache, work.active);
                if (continuationEligible) {
                    cachePublication.dirty = true;
                    // A velocity-changing island invalidates its old load guesses,
                    // not contact identity. New actual TOI features also need zero-load
                    // identity for next step's ordinary geometric support matching.
                    // Neither old warm impulses nor impact impulses are replayed here.
                    for (auto &cached : contactCache)
                        if (included[cached.key.slotA] || included[cached.key.slotB]) {
                            cached.normalImpulse = 0;
                            cached.tangentImpulse = glm::vec3(0);
                        }
                    auto replaced = observationKeys;
                    std::sort(replaced.begin(), replaced.end());
                    replaced.erase(std::unique(replaced.begin(), replaced.end(),
                                               [](const ContactKey &a, const ContactKey &b) {
                                                   return a.SameBodies(b);
                                               }),
                                   replaced.end());
                    contactCache.erase(std::remove_if(contactCache.begin(), contactCache.end(),
                                                      [&](const CachedContact &c) {
                                                          return std::binary_search(
                                                              replaced.begin(), replaced.end(),
                                                              c.key);
                                                      }),
                                       contactCache.end());
                    // An elastic departure is a new flight, not support. In particular,
                    // a short ballistic return must still receive its own restitution.
                    if (result.effectiveRestitution == 0) {
                        const auto &contactRows = impactSolver.Constraints();
                        for (std::size_t i = 0; i < contactRows.size(); ++i) {
                            const auto &row = contactRows[i];
                            const auto &key = observationKeys[i];
                            contactCache.push_back({key, row.localAnchorA, row.normal, 0,
                                                    glm::vec3(0), float(row.signedSeparation),
                                                    bodies[key.slotA].contactObservationRevision,
                                                    bodies[key.slotB].contactObservationRevision});
                        }
                    }
                } else {
                    contactCache.erase(std::remove_if(contactCache.begin(), contactCache.end(),
                                                      [&](const CachedContact &c) {
                                                          return included[c.key.slotA] ||
                                                                 included[c.key.slotB];
                                                      }),
                                       contactCache.end());
                }
            }
            std::vector<unsigned> changed;
            for (std::size_t i = 0; i < island.size(); ++i) {
                const auto slot = island[i];
                auto &b = bodies[slot];
                if (SamePosition(oldVelocities[i].first, b.rigidBody.linearVelocity) &&
                    SamePosition(oldVelocities[i].second, b.rigidBody.angularVelocity))
                    continue;
                changed.push_back(slot);
                // Membership remains nonzero; value two also marks the
                // changed subset without scanning it for every scheduled pair.
                included[slot] = 2;
                b.motion.ChangeVelocity(b.rigidBody, now);
                InvalidateImpactPose(slot);
                CoverStepReach(b, static_cast<float>(dt - now));
            }
            // Solver rows and event pairs retain discovery order. Membership
            // needs no such order: avoid rescanning every actual event pair
            // for every incident support in a large connected assembly.
            eventPairMembership.assign(eventPairs.begin(), eventPairs.end());
            std::sort(eventPairMembership.begin(), eventPairMembership.end());
            supportPairs.erase(
                std::remove_if(supportPairs.begin(), supportPairs.end(),
                               [&](const auto &pair) {
                                   return (included[pair[0]] == 2 || included[pair[1]] == 2) &&
                                          !std::binary_search(eventPairMembership.begin(),
                                                              eventPairMembership.end(), pair) &&
                                          (!continuationEligible ||
                                           !SupportContinuationSafe(pair, now, dt));
                               }),
                supportPairs.end());
            // Cached event times depend only on the two anchored trajectories.
            // Recompute incident queries after an actual velocity change; retain
            // every unaffected event (including disjoint simultaneous events).
            dirty.clear();
            dirtyScheduled.assign(scheduledImpacts.size(), 0);
            auto markDirty = [&](const std::array<unsigned, 4>& key) {
                const auto found = scheduledIndex.find(key);
                if (found != scheduledIndex.end()) {
                    auto& marked = dirtyScheduled[found->second];
                    if (marked) return;
                    marked = 1;
                }
                dirty.push_back(key);
            };
            markDirty(selected); // retire the event even if its impulse is zero
            for (const auto &event : scheduledImpacts)
                if (included[event.key[0]] == 2 || included[event.key[1]] == 2)
                    markDirty(event.key);
            dirtyBodyPairs.Begin(bodies.size());
            for (unsigned slot : changed) {
                const auto &candidates = QuerySlots(tree.FatAabb(bodies[slot].proxy));
                for (unsigned other : candidates)
                    if (other != slot && CanRespond(slot, other)) {
                        const auto a = std::min(slot, other), b = std::max(slot, other);
                        const std::uint64_t pairKey = (std::uint64_t(a) << 32) | b;
                        if (dirtyBodyPairs.Contains(pairKey)) continue;
                        dirtyBodyPairs.Insert(pairKey);
                        for (int pa = 0; pa < PrimitiveCount(bodies[a].shape); ++pa)
                            for (int pb = 0; pb < PrimitiveCount(bodies[b].shape); ++pb)
                                markDirty({a, b, unsigned(pa), unsigned(pb)});
                    }
            }
            std::sort(dirty.begin(), dirty.end());
            for (const auto &key : dirty)
                schedule(key);
            if (now >= dt)
                break;
        }
        // No solver reads completed observations during this event pass. Each
        // event still replaces exactly its actual primitive groups and keeps
        // row insertion order. One stable publication sort has the same final
        // key/row order as sorting the entire history after every impact.
        observationPublication.Publish();
        cachePublication.Publish();
        for (const auto slot : aliveSlots)
            if (bodies[slot].HasMotion() && !bodies[slot].sleeping) {
                auto &body = bodies[slot];
                const auto pose = body.motion.EvaluateAfterEvents(dt);
                stats.motionSegments += body.motion.Segments().size();
                stats.motionStorageBytes += body.motion.StorageBytes();
                body.rigidBody.position = pose.position;
                body.rigidBody.orientation = pose.orientation;
                if (body.isDynamic)
                    body.rigidBody.angularVelocity = pose.angularVelocity;
                if (body.isKinematic) {
                    body.rigidBody.linearVelocity = pose.linearVelocity;
                    body.rigidBody.angularVelocity = pose.angularVelocity;
                    if (body.kinematic.control == KinematicControl::Target) {
                        body.kinematic.remainingSeconds =
                            std::max(0.f, body.kinematic.remainingSeconds -
                                              float(body.kinematicActiveDuration));
                        if (body.kinematic.remainingSeconds == 0)
                            body.kinematic.control = KinematicControl::Stopped;
                    }
                }
            }
    }

    static void KinematicVelocity(const Body& body,float dt,glm::vec3& linear,glm::vec3& angular,double& duration) {
        linear=angular=glm::vec3(0);duration=0;
        const auto& rigid=body.rigidBody;const auto& command=body.kinematic;
        if(!body.enabled||!(dt>0))return;
        if(command.control==KinematicControl::Velocity){
            linear=command.linearVelocity;angular=command.angularVelocity;duration=dt;
        }else if(command.control==KinematicControl::Target){
            const float remaining=command.targetNextStep?dt:command.remainingSeconds;
            if(remaining>0){
                const auto targetCenter=command.target.position+command.target.rotation*body.shape.pivotOffset;
                linear=(targetCenter-rigid.position)/remaining;
                glm::quat delta=command.target.rotation*glm::conjugate(rigid.orientation);
                if(delta.w<0)delta=-delta;
                const double sine=glm::length(glm::dvec3(delta.x,delta.y,delta.z));
                if(sine>0&&!SameRotation(command.target.rotation,rigid.orientation)){
                    const double angle=2*std::atan2(sine,double(delta.w));
                    angular=glm::vec3(glm::dvec3(delta.x,delta.y,delta.z)*(angle/(sine*remaining)));
                }
                duration=std::min(double(dt),double(remaining));
            }
        }
    }
    void PublishKinematics(float dt) {
        for(auto slot:aliveSlots){auto& body=bodies[slot];if(!body.isKinematic||body.simulationSuspended)continue;
            auto& rigid=body.rigidBody;auto& command=body.kinematic;
            body.previousPosition=rigid.position;body.previousOrientation=rigid.orientation;
            CurrentBound(body);body.previousBound=body.currentBound;
            KinematicVelocity(body,dt,rigid.linearVelocity,rigid.angularVelocity,body.kinematicActiveDuration);
            if(body.enabled&&command.control==KinematicControl::Target&&command.targetNextStep){command.remainingSeconds=dt;command.targetNextStep=false;}
            rigid.ClearAccumulators();body.deferredAcceleration=false;
            body.motion.BeginPrescribed(MakeHandle(slot).id,rigid,dt,body.kinematicActiveDuration);
            InvalidateImpactPose(slot);
        }
    }

    // Milestone 32 warm-start state: last step's converged impulses, sorted
    // by key, and the keys/anchors of this step's constraints in solver order.
    std::vector<CachedContact> contactCache;
    // Completed solver observations are not warm-start storage.
    // Island velocity changes may invalidate warm starts without erasing
    // untouched load-bearing contacts from the completed physical step.
    std::vector<CachedContact> completedContactObservations;
    uint64_t completedObservationEpoch=0;
    float completedObservationDt=0,completedSolverDt=0;
    bool completedObservationsReady=false,restoredCompletedObservations=false;

    std::vector<CachedContact> pendingCache;
    std::vector<char> cacheUsed;
    PhysicsWorld::StepStats stats;
    std::size_t reinsertionsSinceStep = 0;
    struct CacheCounters {
        std::size_t orientationHits=0, orientationRebuilds=0;
        std::size_t boundHits=0, boundRebuilds=0, shapeRebuilds=0, allocations=0, allocatedBytes=0;
    } cacheCounters;

    static bool SameFloat(float a, float b) {
        return std::memcmp(&a,&b,sizeof(float))==0;
    }
    static bool SamePosition(const glm::vec3& a,const glm::vec3& b) {
        return SameFloat(a.x,b.x) && SameFloat(a.y,b.y) && SameFloat(a.z,b.z);
    }
    static bool SameRotation(const glm::quat& a,const glm::quat& b) {
        return SameFloat(a.w,b.w) && SameFloat(a.x,b.x) && SameFloat(a.y,b.y) && SameFloat(a.z,b.z);
    }
    static bool Matches(const PoseBound& bound,const glm::vec3& p,const glm::quat& q) {
        return bound.valid && SamePosition(bound.position,p) && SameRotation(bound.orientation,q);
    }
    const ContactPreparedOrientation& Orientation(Body& body) {
        if (body.orientationCache && body.orientationCache->Matches(body.rigidBody.orientation)) {
            ++cacheCounters.orientationHits;
        } else {
            body.orientationCache.emplace(body.rigidBody.orientation);
            body.boundPreparationValid = false;
            ++cacheCounters.orientationRebuilds;
        }
        return *body.orientationCache;
    }
    const Aabb& CurrentBound(Body& body) {
        const auto& p=body.rigidBody.position;
        const auto& q=body.rigidBody.orientation;
        if (Matches(body.currentBound,p,q)) {
            ++cacheCounters.boundHits;
            return body.currentBound.bound;
        }
        const auto& orientation=Orientation(body);
        if (!body.boundPreparationValid) {
            if (!body.boundPreparation) body.boundPreparation.emplace();
            const auto capacity=body.boundPreparation->children.capacity();
            PrepareShapeBounds(body.shape,orientation,*body.boundPreparation);
            if (body.boundPreparation->children.capacity()!=capacity) {
                ++cacheCounters.allocations;
                cacheCounters.allocatedBytes+=body.boundPreparation->children.capacity()*sizeof(PreparedBoxBound);
            }
            body.boundPreparationValid=true;
        }
        body.currentBound={p,q,ShapeAabb(*body.boundPreparation,p),true};
        ++cacheCounters.boundRebuilds;
        return body.currentBound.bound;
    }
    const Aabb& PreviousBound(Body& body) {
        const auto& p=body.previousPosition;
        const auto& q=body.previousOrientation;
        if (Matches(body.previousBound,p,q)) {
            ++cacheCounters.boundHits;
        } else if (Matches(body.currentBound,p,q)) {
            body.previousBound=body.currentBound;
            ++cacheCounters.boundHits;
        } else {
            // Normally captured before integration. This independent fallback
            // preserves the old pose if a caller introduces another transition.
            body.previousBound={p,q,ShapeAabb(body.shape,p,q),true};
            ++cacheCounters.boundRebuilds;
        }
        return body.previousBound.bound;
    }
    std::size_t CacheBytes() const {
        std::size_t bytes=bodies.capacity()*(sizeof(float)+sizeof(std::optional<ContactPreparedOrientation>)+
            sizeof(std::optional<PreparedShapeBounds>)+sizeof(bool)+2*sizeof(PoseBound));
        for (const Body& body:bodies) if (body.boundPreparation)
            bytes+=body.boundPreparation->children.capacity()*sizeof(PreparedBoxBound);
        bytes+=initialContactGeometry.capacity()*sizeof(InitialContactGeometry);
        return bytes+(impactPoseSamples.capacity()+impactAnchorSamples.capacity())*sizeof(ImpactPoseSample)+solver.FrameStorageBytes();
    }
    void EnsureImpactPoseStorage(){
        if(impactPoseSamples.size()>=bodies.size())return;
        const auto capacity=impactPoseSamples.capacity();impactPoseSamples.resize(bodies.size());
        const auto anchorCapacity=impactAnchorSamples.capacity();impactAnchorSamples.resize(bodies.size());
        if(impactAnchorSamples.capacity()!=anchorCapacity){++cacheCounters.allocations;cacheCounters.allocatedBytes+=impactAnchorSamples.capacity()*sizeof(ImpactPoseSample);}
        if(impactPoseSamples.capacity()!=capacity){++cacheCounters.allocations;cacheCounters.allocatedBytes+=impactPoseSamples.capacity()*sizeof(ImpactPoseSample);}
    }

    // The tight broadphase bound a body must stay inside. For a dynamic
    // body it covers both the previous and the current fixed-step pose —
    // player sweeps interpolate between the two — and, if the body turned
    // during the step, the orientation-independent bounding sphere at both
    // positions (an interpolated orientation can poke outside both
    // endpoint boxes; it can never leave the swept sphere).
    Aabb TightBound(Body& body) {
        const Aabb current = CurrentBound(body);
        if (!body.HasMotion()) { body.previousBound=body.currentBound; return current; }
        Aabb bound = current.Union(PreviousBound(body));
        const float turn = std::abs(glm::dot(body.previousOrientation, body.rigidBody.orientation));
        if (turn < 1.0f - 1.0e-7f) {
            const float r = body.boundingRadius;
            bound = bound.Union(Aabb{body.previousPosition - glm::vec3(r), body.previousPosition + glm::vec3(r)});
            bound = bound.Union(Aabb{body.rigidBody.position - glm::vec3(r), body.rigidBody.position + glm::vec3(r)});
        }
        if (body.motion.Segments().size()>1) for(const auto& segment:body.motion.Segments()) {
            const float r=body.boundingRadius;
            bound=bound.Union(Aabb{glm::min(segment.position,segment.endPosition)-glm::vec3(r),
                                  glm::max(segment.position,segment.endPosition)+glm::vec3(r)});
        }
        return bound;
    }

    // Milestone 32: how far this body's surface can move within the current
    // step at its post-force velocities — the most any of its contacts can
    // close before the next detection.
    float StepReach(const Body& body, float fixedDeltaTime) const {
        return (glm::length(body.rigidBody.linearVelocity) +
                glm::length(body.rigidBody.angularVelocity) * body.boundingRadius) *
               fixedDeltaTime;
    }

    // Before candidate generation: a dynamic proxy's fat bound covers the
    // body grown by its reach, so every pair that can come into contact
    // within this step is a candidate (speculative contacts).
    void CoverStepReach(Body& body, float fixedDeltaTime) {
        const Aabb reach = TightBound(body).Expanded(StepReach(body, fixedDeltaTime));
        if (tree.FatAabb(body.proxy).Contains(reach)) return;
        tree.MoveProxy(body.proxy, reach.Expanded(kBroadphaseMargin));
        ++reinsertionsSinceStep;
    }

    void RefreshProxy(Body& body) {
        const Aabb tight = TightBound(body);
        if (tree.FatAabb(body.proxy).Contains(tight)) return;
        tree.MoveProxy(body.proxy, tight.Expanded(kBroadphaseMargin));
        ++reinsertionsSinceStep;
    }

    // Live slots whose fat bounds overlap `box`, ascending.
    const std::vector<unsigned int>& QuerySlots(const Aabb& box) const {
        queryScratch.clear();
        tree.Query(box, [&](int proxy) { queryScratch.push_back(tree.UserData(proxy)); });
        std::sort(queryScratch.begin(), queryScratch.end());
        return queryScratch;
    }

    // Candidate pairs (lo, hi) for every pair with at least one movable
    // body, in ascending lexicographic slot order — the same order the
    // pre-M32 all-pairs loop visited them in, restricted to candidates.
    bool CanCollide(unsigned a,unsigned b) const {
        auto ha=MakeHandle(a).id,hb=MakeHandle(b).id;
        if(!suppressedPairs.empty()&&suppressedPairs.count(std::minmax(ha,hb)))return false;
        return bodies[a].enabled&&bodies[b].enabled&&CollisionPermitted(bodies[a].collisionLayer,bodies[a].collisionMask,bodies[b].collisionLayer,bodies[b].collisionMask);
    }
    bool CanRespond(unsigned a,unsigned b) const {return CanCollide(a,b)&&!bodies[a].sensor&&!bodies[b].sensor&&!bodies[a].queryOnly&&!bodies[b].queryOnly&&!( (bodies[a].sleeping||bodies[a].rigidBody.IsStatic())&&(bodies[b].sleeping||bodies[b].rigidBody.IsStatic()) );}
    bool MatchesQuery(unsigned slot,const PhysicsQueryFilter& filter) const {
        const auto& b=bodies[slot]; if(!b.enabled||!b.queriesEnabled||(b.sensor&&!filter.includeSensors))return false; const auto bit=CategoryBit(b.collisionLayer);
        if(!(filter.includeLayers&bit)||(filter.excludeLayers&bit)||
           (b.tags&filter.requiredTags)!=filter.requiredTags||(b.tags&filter.excludedTags))return false;
        for(const auto handle:filter.ignoredBodies)if(Get(handle)&&handle.id==MakeHandle(slot).id)return false;
        return true;
    }
    void GenerateCandidatePairs() {
        JUDAS_PROFILE_SCOPE("Physics candidate generation");
        if(work.active)++work.candidatePasses;
        candidatePairs.clear();
        for (const unsigned int slot : aliveSlots) {
            const Body& a = bodies[slot];
            if (!a.enabled || (!a.HasMotion()&&!a.sensor&&!a.queryOnly)) continue;
            if(work.active)++work.candidateQueries;
            tree.Query(tree.FatAabb(a.proxy), [&](int proxy) {
                if(work.active)++work.candidateLeaves;
                const unsigned int other = tree.UserData(proxy);
                if (other == slot) return;
                const Body& b = bodies[other];
                // A pair of two movable bodies is found by both queries;
                // keep it from the lower slot's query only.
                if ((b.HasMotion()||b.sensor||b.queryOnly) && other < slot) return;
                if(!CanCollide(slot,other)){++stats.layerRejectedPairs;return;}
                candidatePairs.emplace_back(std::min(slot, other), std::max(slot, other));
            });
        }
        std::sort(candidatePairs.begin(), candidatePairs.end());
    }

    BodyHandle MakeHandle(unsigned int slot) const {
        BodyHandle handle;
        handle.id = slot | (bodies[slot].generation << kSlotBits);handle.world=worldToken;
        return handle;
    }

    unsigned playerCollisionLayer=0;
    CategoryMask playerCollisionMask=kAllCategories;
    bool hasPlayerShape = false;
    Shape playerShape;

    // A member of Impl (rather than a free function taking a body list)
    // specifically so it can name `Body` without exposing this private
    // nested type outside PhysicsWorld.cpp.
    // Milestone 32: evaluates only `candidates` (the broadphase's answer for
    // the whole sweep). Any body not among them has a positive distance, so
    // it could never be the reported closest body of a hit.
    ClosestBodyResult ClosestBodyToCapsule(const std::vector<unsigned int>& candidates,
                                            const glm::vec3& segA, const glm::vec3& segB,
                                            float capsuleRadius,
                                            float bodyMotionAlpha,
                                            bool interpolateDynamicBodyMotion) const {
        ClosestBodyResult result;
        for (const unsigned int i : candidates) {
            const Body& body = bodies[i];
            if(!body.enabled||body.sensor||body.queryOnly)continue;
            const bool interpolateBody = interpolateDynamicBodyMotion && body.HasMotion();
            const bool ledger=interpolateBody && bodyMotionAlpha<1.0f && !body.motion.Segments().empty();
            const auto observed=ledger ? body.motion.Evaluate(std::clamp(double(bodyMotionAlpha),0.0,1.0)*stepDuration) : body.rigidBody;
            const glm::vec3 bodyPosition = ledger ? observed.position : interpolateBody
                ? glm::mix(body.previousPosition, body.rigidBody.position, bodyMotionAlpha)
                : body.rigidBody.position;
            const glm::quat bodyOrientation = ledger ? observed.orientation : interpolateBody
                ? glm::normalize(glm::slerp(body.previousOrientation, body.rigidBody.orientation,
                                            bodyMotionAlpha))
                : body.rigidBody.orientation;
            RigidBody sampledBody = body.rigidBody;
            sampledBody.position = bodyPosition;
            sampledBody.orientation = bodyOrientation;
            if (body.shape.type == ShapeType::Terrain) {
                if (!body.shape.terrain) continue;
                const float segmentLength = glm::length(segB - segA);
                const float minimumEndRadius = std::min(glm::length(segA - bodyPosition),
                                                        glm::length(segB - bodyPosition));
                if (minimumEndRadius - segmentLength >
                    body.shape.terrain->BoundRadius() + capsuleRadius) continue;
                // Sampling the whole capsule core, rather than just its
                // lower endpoint, also handles arbitrary capsule attitude
                // and terrain slopes without a universal up axis.
                constexpr int kSegmentSamples = 9;
                for (int sampleIndex = 0; sampleIndex < kSegmentSamples; ++sampleIndex) {
                    const float t = static_cast<float>(sampleIndex) /
                                    static_cast<float>(kSegmentSamples - 1);
                    const TerrainSample sample = SampleTerrainAtWorld(
                        *body.shape.terrain, sampledBody, glm::mix(segA, segB, t));
                    const float distance = sample.signedDistance - capsuleRadius;
                    if (distance < result.distance) {
                        result.distance = distance;
                        result.normal = sample.outwardNormal;
                        result.point=glm::mix(segA,segB,t)-sample.outwardNormal*sample.signedDistance;
                        result.bodyIndex = static_cast<int>(i);
                    }
                }
                continue;
            }
            for (int part = 0; part < PrimitiveCount(body.shape); ++part) {
                const PrimitivePose primitive = PrimitiveAt(body.shape, sampledBody, part);
                CapsuleDistance capsuleDistance;
                if (primitive.shape.type == ShapeType::Sphere) {
                    capsuleDistance = CapsuleDistanceToSphere(segA, segB, capsuleRadius,
                                                               primitive.body.position,
                                                               primitive.shape.radius);
                } else if (primitive.shape.type == ShapeType::Box) {
                    capsuleDistance = CapsuleDistanceToBox(segA, segB, capsuleRadius,
                                                            primitive.body.position,
                                                            primitive.body.orientation,
                                                            primitive.shape.halfExtents);
                } else if(primitive.shape.asset) {
                    // This sampler only uses distance <= 0 to bracket overlap. A
                    // triangle outside the capsule AABB cannot overlap it; use
                    // the cooked BVH instead of scanning the entire mesh at
                    // every one of the 24 sweep/20 refinement samples. Convex
                    // containment still takes the evaluator's full inside path.
                    const auto d=SegmentGeometry(glm::dvec3(segA),glm::dvec3(segB),capsuleRadius,primitive,0);
                    if(!d.valid)continue;
                    capsuleDistance={float(d.gap),glm::vec3(d.normal),glm::vec3(d.point)};
                } else {continue;}
                if (capsuleDistance.distance < result.distance) {
                    result.distance = capsuleDistance.distance;
                    result.normal = capsuleDistance.normal;
                    result.point=capsuleDistance.otherPoint;
                    result.bodyIndex = static_cast<int>(i);
                }
            }
        }
        return result;
    }

    Body* Get(BodyHandle handle) {
        if (!handle.IsValid()||(handle.world&&handle.world!=worldToken)) return nullptr;
        const unsigned int slot = handle.id & kSlotMask;
        if (slot >= bodies.size() || !bodies[slot].alive ||
            bodies[slot].generation != (handle.id >> kSlotBits)) {
            return nullptr;
        }
        return &bodies[slot];
    }
    const Body* Get(BodyHandle handle) const {
        if (!handle.IsValid()||(handle.world&&handle.world!=worldToken)) return nullptr;
        const unsigned int slot = handle.id & kSlotMask;
        if (slot >= bodies.size() || !bodies[slot].alive ||
            bodies[slot].generation != (handle.id >> kSlotBits)) {
            return nullptr;
        }
        return &bodies[slot];
    }

    BodyHandle AddBody(const Shape& shape, const glm::vec3& position, const glm::quat& rotation,
                        bool isDynamic, float mass, float friction, float restitution) {
        Body body;
        body.shape = shape;
        body.boundingRadius = ShapeBoundingRadius(shape);
        ++cacheCounters.shapeRebuilds;
        body.friction = friction;
        body.restitution = restitution;
        body.isDynamic = isDynamic;
        body.alive = true;
        body.rigidBody.position = position;
        body.rigidBody.orientation = rotation;
        body.previousPosition = position;
        body.previousOrientation = rotation;
        if (isDynamic) {
            body.rigidBody.inverseMass = mass > 0.0f ? 1.0f / mass : 0.0f;
            if (shape.type == ShapeType::Sphere) {
                body.rigidBody.inverseInertiaLocal = SolidSphereInverseInertia(mass, shape.radius);
            } else if (shape.type == ShapeType::Box) {
                body.rigidBody.inverseInertiaLocal = SolidBoxInverseInertia(mass, shape.halfExtents);
            } else if (shape.type == ShapeType::CompoundBoxes) {
                body.rigidBody.inverseInertiaLocal = CompoundInverseInertia(mass, shape.boxes);
            }
        }
        // Static bodies keep inverseMass=0 / zero inverse inertia (RigidBody's own defaults),
        // which is exactly what "never moved by force or impulse" means throughout this engine.
        unsigned int slot;
        if (!freeSlots.empty()) {
            slot = freeSlots.back();
            freeSlots.pop_back();
            body.generation = (bodies[slot].generation + 1u) & ((1u << (32u - kSlotBits)) - 1u);
            bodies[slot] = body;
        } else {
            slot = static_cast<unsigned int>(bodies.size());
            bodies.push_back(body);
        }
        aliveSlots.insert(std::lower_bound(aliveSlots.begin(), aliveSlots.end(), slot), slot);
        bodies[slot].proxy = tree.CreateProxy(TightBound(bodies[slot]).Expanded(kBroadphaseMargin), slot);
        return MakeHandle(slot);
    }

    void Remove(BodyHandle handle) {
        Body* body = Get(handle);
        if (!body) return;
        const unsigned int slot = handle.id & kSlotMask;
        body->alive = false;
        tree.DestroyProxy(body->proxy);
        body->proxy = DynamicAabbTree::kNull;
        freeSlots.push_back(slot);
        const auto it = std::lower_bound(aliveSlots.begin(), aliveSlots.end(), slot);
        if (it != aliveSlots.end() && *it == slot) aliveSlots.erase(it);
    }
};

bool PhysicsWorld::Init() {
    m_impl = new Impl();
    return true;
}

PhysicsWorld::~PhysicsWorld() { Shutdown(); }

void PhysicsWorld::Shutdown() {
    delete m_impl;
    m_impl = nullptr;
}

void PhysicsWorld::SetJobSystem(JobSystem* jobs,unsigned maxLanes) {
    if(!m_impl)throw std::logic_error("physics job service requires initialized world");
    if(m_impl->stepping||m_impl->coupledStep)throw std::logic_error("physics job service requires completed step boundary");
    m_impl->contactJobs=jobs;
    m_impl->contactJobLanes=std::min(maxLanes,JobSystem::kMaxWorkers+1);
    m_impl->initialContactGeometry.clear();
}

bool PhysicsWorld::SetBodySimulationSuspended(BodyHandle handle,bool suspended){
    auto* body=m_impl->Get(handle);if(!body||(suspended&&body->enabled))return false;
    body->simulationSuspended=suspended;body->motion.Clear();
    body->previousPosition=body->rigidBody.position;body->previousOrientation=body->rigidBody.orientation;
    return true;
}

bool PhysicsWorld::ReplaceStaticCollision(BodyHandle handle,std::shared_ptr<const CollisionAsset> asset){
    auto* body=m_impl->Get(handle);
    if(!body||body->isDynamic||body->isKinematic||!asset||asset->convex||asset->faces.empty())return false;
    const auto old=m_impl->CurrentBound(*body);
    for(auto slot:m_impl->QuerySlots(old))if(m_impl->bodies[slot].sleeping)m_impl->Wake(slot);
    body->shape=Shape::Cooked(std::move(asset),"");body->boundingRadius=ShapeBoundingRadius(body->shape);
    body->currentBound.valid=body->previousBound.valid=false;body->boundPreparationValid=false;
    const auto slot=handle.id&Impl::kSlotMask;m_impl->InvalidateRestoredContinuation(slot);
    auto uses=[&](const auto& entry){return entry.key.slotA==slot||entry.key.slotB==slot;};
    auto& cache=m_impl->contactCache;cache.erase(std::remove_if(cache.begin(),cache.end(),uses),cache.end());
    auto& observations=m_impl->completedContactObservations;observations.erase(std::remove_if(observations.begin(),observations.end(),uses),observations.end());
    m_impl->InvalidateImpactPose(slot);m_impl->RefreshProxy(*body);
    for(auto other:m_impl->QuerySlots(m_impl->CurrentBound(*body)))if(m_impl->bodies[other].sleeping)m_impl->Wake(other);
    return true;
}

BodyHandle PhysicsWorld::CreateShape(const Shape& input,const BodyTransform& pose,bool dynamic,float mass,float friction,float restitution) {
    Shape shape=input;
    auto positive=[](glm::vec3 h){return std::isfinite(h.x)&&std::isfinite(h.y)&&std::isfinite(h.z)&&h.x>0&&h.y>0&&h.z>0;};
    auto valid=[&](const Shape& s){if(s.type==ShapeType::Box&&!positive(s.halfExtents))throw std::invalid_argument("box dimensions must be finite positive");if(s.type==ShapeType::Sphere&&(!std::isfinite(s.radius)||s.radius<=0))throw std::invalid_argument("sphere radius must be finite positive");if((s.type==ShapeType::ConvexHull||s.type==ShapeType::TriangleMesh)&&(!s.asset||s.asset->convex!=(s.type==ShapeType::ConvexHull)))throw std::invalid_argument("cooked shape kind/asset mismatch");};valid(shape);
    if(!std::isfinite(pose.position.x)||!std::isfinite(pose.position.y)||!std::isfinite(pose.position.z)||!std::isfinite(friction)||friction<0||!std::isfinite(restitution)||restitution<0||restitution>1)throw std::invalid_argument("invalid body pose/material");
    if(shape.type==ShapeType::TriangleMesh&&dynamic)throw std::invalid_argument("concave triangle collision is static-only; use convex/compound");
    if(shape.type==ShapeType::TriangleMesh&&!shape.asset)throw std::invalid_argument("missing cooked mesh");
    if(shape.type==ShapeType::CompoundBoxes){if(shape.boxes.empty()||shape.boxes.size()>64)throw std::invalid_argument("compound limit: 1..64 children");std::set<uint32_t> keys;for(auto& c:shape.boxes){if(!c.key)c.key=uint32_t(&c-shape.boxes.data()+1);if(!keys.insert(c.key).second)throw std::invalid_argument("duplicate compound child key");if(c.type!=ShapeType::Box&&c.type!=ShapeType::Sphere&&c.type!=ShapeType::ConvexHull)throw std::invalid_argument("unsupported compound child shape");ContactRotation(c.rotation);if(!std::isfinite(c.localCenter.x)||!std::isfinite(c.localCenter.y)||!std::isfinite(c.localCenter.z))throw std::invalid_argument("nonfinite child position");valid(c.type==ShapeType::Box?Shape::Box(c.halfExtents):c.type==ShapeType::Sphere?Shape::Sphere(c.radius):Shape::Cooked(c.asset,c.assetId));}}
    ContactRotation(pose.rotation);
    CollisionMassProperties properties;
    if(dynamic){if(!(mass>0)||!std::isfinite(mass))throw std::invalid_argument("dynamic mass must be positive");properties=ShapeMassProperties(shape);shape.pivotOffset=glm::vec3(properties.center);}
    const auto center=pose.position+pose.rotation*shape.pivotOffset;
    auto handle=m_impl->AddBody(shape,center,pose.rotation,dynamic,mass,friction,restitution);
    if(dynamic)m_impl->Get(handle)->rigidBody.inverseInertiaLocal=glm::mat3(glm::inverse(properties.inertia*(double(mass)/properties.volume)));
    return handle;
}

BodyHandle PhysicsWorld::CreateStaticBox(const glm::vec3& position, const glm::vec3& halfExtents,
                                          float friction, float restitution) {
    return CreateStaticBox(position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f), halfExtents, friction,
                            restitution);
}

BodyHandle PhysicsWorld::CreateStaticBox(const glm::vec3& position, const glm::quat& rotation,
                                          const glm::vec3& halfExtents, float friction,
                                          float restitution) {
    return m_impl->AddBody(Shape::Box(halfExtents), position, rotation, false, 0.0f, friction,
                            restitution);
}

BodyHandle PhysicsWorld::CreateStaticSphere(const glm::vec3& position, float radius,
                                             float friction, float restitution) {
    return m_impl->AddBody(Shape::Sphere(radius), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f),
                            false, 0.0f, friction, restitution);
}

BodyHandle PhysicsWorld::CreateStaticTerrain(const glm::vec3& position,
                                              const glm::quat& rotation,
                                              std::shared_ptr<const RadialTerrain> terrain,
                                              float friction, float restitution) {
    if (!terrain) return BodyHandle{};
    return m_impl->AddBody(Shape::Terrain(std::move(terrain)), position, rotation,
                           false, 0.0f, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicBox(const glm::vec3& position, const glm::vec3& halfExtents,
                                           float mass, float friction, float restitution) {
    return m_impl->AddBody(Shape::Box(halfExtents), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f),
                            true, mass, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicSphere(const glm::vec3& position, float radius, float mass,
                                              float friction, float restitution) {
    return m_impl->AddBody(Shape::Sphere(radius), position, glm::quat(1.0f, 0.0f, 0.0f, 0.0f), true,
                            mass, friction, restitution);
}

BodyHandle PhysicsWorld::CreateDynamicCompoundBoxes(const glm::vec3& position,
                                                     const std::vector<CompoundBox>& boxes,
                                                     float mass, float friction, float restitution) {
    if (boxes.empty() || mass <= 0.0f) return BodyHandle{};
    for (const CompoundBox& box : boxes) {
        if (box.halfExtents.x <= 0.0f || box.halfExtents.y <= 0.0f || box.halfExtents.z <= 0.0f) {
            return BodyHandle{};
        }
    }
    return m_impl->AddBody(Shape::Compound(boxes), position,
                            glm::quat(1.0f, 0.0f, 0.0f, 0.0f), true,
                            mass, friction, restitution);
}

void PhysicsWorld::DestroyBody(BodyHandle handle) {
    if(m_impl&&m_impl->Get(handle))m_impl->InvalidateRestoredContinuation(handle.id&Impl::kSlotMask);
    Wake(handle);
    if(m_impl){for(auto it=m_impl->suppressedPairs.begin();it!=m_impl->suppressedPairs.end();){if(it->first==handle.id||it->second==handle.id)it=m_impl->suppressedPairs.erase(it);else ++it;}}
    if(m_impl){auto& joints=m_impl->joints;joints.erase(std::remove_if(joints.begin(),joints.end(),[&](const auto& j){return j.state.settings.bodyA.id==handle.id||j.state.settings.bodyB.id==handle.id;}),joints.end());}
    m_impl->Remove(handle);
}

std::size_t PhysicsWorld::AliveBodyCount() const {
    return m_impl->aliveSlots.size();
}

const std::vector<PhysicsWorld::DebugContact>& PhysicsWorld::LastStepContacts() const {
    return m_impl->lastStepContacts;
}

std::size_t PhysicsWorld::DynamicBodyCount() const {
    std::size_t count = 0;
    for (const unsigned int slot : m_impl->aliveSlots) {
        if (m_impl->bodies[slot].isDynamic) ++count;
    }
    return count;
}

void PhysicsWorld::ApplyLinearAcceleration(BodyHandle handle, const glm::vec3& acceleration,
                                            float fixedDeltaTime) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || body->rigidBody.IsStatic()) return;
    if(body->sleeping&&glm::length(acceleration-body->lastAcceleration)>1e-5f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->lastAcceleration=acceleration;
    if(body->sleeping){body->deferredAcceleration=true;return;}
    body->deferredAcceleration=false;body->rigidBody.linearVelocity += acceleration * fixedDeltaTime;
}

void PhysicsWorld::ApplyForce(BodyHandle handle, const glm::vec3& force) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || body->rigidBody.IsStatic()) return;
    if(glm::length(force)>1e-8f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->rigidBody.ApplyForce(force);
}

void PhysicsWorld::ApplyTorque(BodyHandle handle, const glm::vec3& torque,bool wake) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || body->rigidBody.IsStatic()) return;
    // Unchanged pose drives retain the normal quiet-time clock at equilibrium.
    // Existing callers keep their normal explicit wake behaviour.
    if(wake&&glm::length(torque)>1e-8f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->rigidBody.ApplyTorque(torque);
}

bool PhysicsWorld::IsDynamicBody(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body && body->isDynamic;
}

bool PhysicsWorld::IsKinematicBody(BodyHandle handle) const {
    const auto* body=m_impl->Get(handle);return body&&body->isKinematic;
}
BodyMotionType PhysicsWorld::GetMotionType(BodyHandle handle) const {
    const auto* body=m_impl->Get(handle);
    return body&&body->isKinematic?BodyMotionType::Kinematic:body&&body->isDynamic?BodyMotionType::Dynamic:BodyMotionType::Static;
}
bool PhysicsWorld::SetMotionType(BodyHandle handle,BodyMotionType mode,float mass,bool preserveVelocity) {
    auto* body=m_impl->Get(handle);
    if(!body||body->queryOnly||(mode!=BodyMotionType::Static&&mode!=BodyMotionType::Dynamic&&mode!=BodyMotionType::Kinematic))return false;
    if(GetMotionType(handle)==mode)return true;
    if(mode!=BodyMotionType::Static&&(!KinematicShape(body->shape)||!std::isfinite(mass)||mass<=0))return false;
    // A joint's anchors are COM-local. Changing mass authority/COM while it
    // participates would silently reinterpret the connection; reject atomically.
    for(const auto& j:m_impl->joints)if(j.state.settings.bodyA.id==handle.id||j.state.settings.bodyB.id==handle.id)return false;
    Shape shape=body->shape;glm::mat3 inverseInertia(0);float inverseMass=0;
    try{
        if(mode!=BodyMotionType::Static){const auto properties=ShapeMassProperties(shape);
            shape.pivotOffset=glm::vec3(properties.center);
            if(mode==BodyMotionType::Dynamic){inverseMass=1/mass;
                inverseInertia=glm::mat3(glm::inverse(properties.inertia*(double(mass)/properties.volume)));}
        }
    }catch(const std::exception&){return false;}
    if(!std::isfinite(inverseMass)||!FiniteVector(shape.pivotOffset))return false;
    for(int column=0;column<3;++column)if(!FiniteVector(inverseInertia[column]))return false;
    const auto pivot=GetTransform(handle);const auto oldLinear=body->rigidBody.linearVelocity;
    const auto oldAngular=body->rigidBody.angularVelocity;
    if(!FiniteVector(pivot.position+pivot.rotation*shape.pivotOffset)||
       (preserveVelocity&&(!UsableVelocity(oldLinear)||!UsableVelocity(oldAngular))))return false;
    m_impl->Wake(handle.id&Impl::kSlotMask);
    for(auto i:m_impl->QuerySlots(m_impl->CurrentBound(*body)))if(m_impl->bodies[i].sleeping)m_impl->Wake(i);
    body->shape=std::move(shape);body->boundingRadius=ShapeBoundingRadius(body->shape);
    body->isDynamic=mode==BodyMotionType::Dynamic;body->isKinematic=mode==BodyMotionType::Kinematic;
    body->rigidBody.inverseMass=inverseMass;body->rigidBody.inverseInertiaLocal=inverseInertia;
    body->rigidBody.position=pivot.position+pivot.rotation*body->shape.pivotOffset;
    body->rigidBody.linearVelocity=preserveVelocity&&mode!=BodyMotionType::Static?oldLinear:glm::vec3(0);
    body->rigidBody.angularVelocity=preserveVelocity&&mode!=BodyMotionType::Static?oldAngular:glm::vec3(0);
    body->rigidBody.ClearAccumulators();body->lastAcceleration=glm::vec3(0);body->deferredAcceleration=false;
    body->kinematic={};body->kinematicActiveDuration=0;
    if(body->isKinematic&&preserveVelocity){body->kinematic.control=KinematicControl::Velocity;
        body->kinematic.linearVelocity=oldLinear;body->kinematic.angularVelocity=oldAngular;}
    body->motion.Clear();body->previousPosition=body->rigidBody.position;body->previousOrientation=body->rigidBody.orientation;
    body->currentBound.valid=body->previousBound.valid=false;body->boundPreparationValid=false;
    m_impl->InvalidateRestoredContinuation(handle.id&Impl::kSlotMask);
    // Disposable solver history belongs to the old authority, never the handle
    // itself. Contact-event identity remains continuous across a safe handoff.
    const auto slot=handle.id&Impl::kSlotMask;
    auto uses=[&](const auto& entry){return entry.key.slotA==slot||entry.key.slotB==slot;};
    auto& cache=m_impl->contactCache;cache.erase(std::remove_if(cache.begin(),cache.end(),uses),cache.end());
    auto& observations=m_impl->completedContactObservations;observations.erase(std::remove_if(observations.begin(),observations.end(),uses),observations.end());
    m_impl->InvalidateImpactPose(slot);m_impl->RefreshProxy(*body);
    return true;
}
bool PhysicsWorld::MoveKinematic(BodyHandle handle,const BodyTransform& target,float seconds) {
    auto* body=m_impl->Get(handle);
    if(!body||!body->enabled||!body->isKinematic||!KinematicShape(body->shape)||!UsableKinematicPose(target)||
       !std::isfinite(seconds)||seconds<0||seconds>60)return false;
    auto normalized=target;
    const auto anchor=body->rigidBody.orientation;
    normalized.rotation=Impl::SameRotation(target.rotation,anchor)||Impl::SameRotation(-target.rotation,anchor)?anchor:glm::normalize(target.rotation);
    const auto center=normalized.position+normalized.rotation*body->shape.pivotOffset;
    if(!FiniteVector(center)||!FiniteVector(center-body->rigidBody.position)||
       !std::isfinite(glm::length(center-body->rigidBody.position))||
       (seconds>0&&(!UsableVelocity((center-body->rigidBody.position)/seconds)||!std::isfinite(glm::pi<float>()/seconds))))return false;
    KinematicMotionState command;command.control=KinematicControl::Target;command.target=normalized;
    command.remainingSeconds=seconds;command.targetNextStep=seconds==0;
    body->kinematic=command;return true;
}
bool PhysicsWorld::SetKinematicVelocity(BodyHandle handle,const glm::vec3& linear,const glm::vec3& angular) {
    auto* body=m_impl->Get(handle);
    if(!body||!body->enabled||!body->isKinematic||!KinematicShape(body->shape)||!UsableVelocity(linear)||!UsableVelocity(angular))return false;
    KinematicMotionState command;command.control=KinematicControl::Velocity;
    command.linearVelocity=linear;command.angularVelocity=angular;body->kinematic=command;return true;
}
bool PhysicsWorld::StopKinematic(BodyHandle handle) {
    auto* body=m_impl->Get(handle);if(!body||!body->isKinematic)return false;
    body->kinematic={};return true;
}
bool PhysicsWorld::GetKinematicMotion(BodyHandle handle,KinematicMotionState& state) const {
    const auto* body=m_impl->Get(handle);if(!body||!body->isKinematic)return false;
    state=body->kinematic;return true;
}
glm::vec3 PhysicsWorld::GetPointVelocity(BodyHandle handle,const glm::vec3& point) const {
    const auto* body=m_impl->Get(handle);if(!body||!body->enabled||!FiniteVector(point))return glm::vec3(0);
    return body->rigidBody.linearVelocity+glm::cross(body->rigidBody.angularVelocity,point-body->rigidBody.position);
}
glm::vec3 PhysicsWorld::GetStepPointVelocity(BodyHandle handle,const glm::vec3& point,float dt) const {
    const auto* body=m_impl->Get(handle);
    if(!body||!body->enabled||!FiniteVector(point)||!std::isfinite(dt)||dt<=0)return glm::vec3(0);
    if(!body->isKinematic)return GetPointVelocity(handle,point);
    glm::vec3 linear,angular;double duration=0;
    Impl::KinematicVelocity(*body,dt,linear,angular,duration);
    return linear+glm::cross(angular,point-body->rigidBody.position);
}
glm::vec3 PhysicsWorld::GetPreviousPointVelocity(BodyHandle handle,const glm::vec3& point) const {
    const auto* body=m_impl->Get(handle);if(!body||!body->enabled||!FiniteVector(point))return glm::vec3(0);
    return body->rigidBody.linearVelocity+glm::cross(body->rigidBody.angularVelocity,point-(body->HasMotion()?body->previousPosition:body->rigidBody.position));
}

float PhysicsWorld::GetMass(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body && body->isDynamic && body->rigidBody.inverseMass > 0.0f
               ? 1.0f / body->rigidBody.inverseMass
               : 0.0f;
}
glm::vec3 PhysicsWorld::GetCenterOfMass(BodyHandle handle) const {
    if(!m_impl)return glm::vec3(0);
    const auto* body=m_impl->Get(handle);
    return body?body->rigidBody.position:glm::vec3(0);
}

void PhysicsWorld::ApplyLinearImpulse(BodyHandle handle, const glm::vec3& impulse,bool wake) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || !body->isDynamic) return;
    if(wake&&glm::length(impulse)>1e-8f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->rigidBody.ApplyLinearImpulse(impulse);
}

void PhysicsWorld::ApplyAngularImpulse(BodyHandle handle, const glm::vec3& impulse,bool wake) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || !body->isDynamic || !FiniteVector(impulse)) return;
    if(wake&&glm::length(impulse)>1e-8f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->rigidBody.ApplyAngularImpulse(impulse);
}

void PhysicsWorld::ApplyImpulseAtPoint(BodyHandle handle, const glm::vec3& impulse,
                                       const glm::vec3& worldPoint) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body || body->simulationSuspended || !body->isDynamic) return;
    if(glm::length(impulse)>1e-8f)m_impl->Wake(handle.id&Impl::kSlotMask);
    body->rigidBody.ApplyImpulseAtPoint(impulse, worldPoint);
}

namespace {
// Algebraic preconditioner for the auxiliary normal constraints only. The
// existing solver still owns their target, nonnegative impulse and friction.
// A = J M^-1 J^T is applied from prepared lever arms/inertias, without a
// dense contact matrix or any body-mass classification.
bool AccelerateParticleNormals(const std::vector<ContactConstraint>& rows,
                               PhysicsWorld::ParticleContactStats& stats,
                               std::vector<float>& normal,
                               std::vector<glm::vec3>& tangent) {
    struct Frame { const RigidBody* body=nullptr; glm::dmat3 inverseInertia{0}; };
    struct Row { std::size_t original,a,b; glm::dvec3 n,angularA,angularB; double diagonal; };
    struct Wrench { glm::dvec3 linear{0},angular{0}; };
    std::size_t frameCount=0;
    for(const auto& c:rows) frameCount=std::max(frameCount,std::max(c.frameA,c.frameB)+1);
    std::vector<Frame> frames(frameCount);
    std::vector<Row> active;
    std::vector<double> residual;
    normal.reserve(rows.size());tangent.reserve(rows.size());
    for(std::size_t i=0;i<rows.size();++i) {
        const auto& c=rows[i];normal.push_back(c.normalImpulse);tangent.push_back(c.tangentImpulse);
        frames[c.frameA]={c.bodyA,glm::dmat3(c.inverseInertiaA)};
        frames[c.frameB]={c.bodyB,glm::dmat3(c.inverseInertiaB)};
        const glm::dvec3 n(c.normal),ra(c.velocityOffsetA),rb(c.velocityOffsetB);
        const glm::dvec3 angularA=glm::cross(ra,n),angularB=glm::cross(rb,n);
        const double speed=glm::dot(n,glm::dvec3(c.bodyA->linearVelocity)-glm::dvec3(c.bodyB->linearVelocity))+
            glm::dot(angularA,glm::dvec3(c.bodyA->angularVelocity))-
            glm::dot(angularB,glm::dvec3(c.bodyB->angularVelocity));
        const double r=double(c.restitutionBias)-speed;
        if (!(c.normalImpulse>0 || r>0)) continue;
        // Optional PCG is restricted to homogeneous prescribed normal motion.
        // A moving infinite-mass boundary can supply unbounded constraint work
        // when nearly opposing coarse particle rows form a narrow wedge. The
        // ordinary bounded PGS still processes every such row unchanged.
        const double prescribedA=glm::dot(n,glm::dvec3(c.bodyA->linearVelocity))+
            glm::dot(angularA,glm::dvec3(c.bodyA->angularVelocity));
        const double prescribedB=glm::dot(n,glm::dvec3(c.bodyB->linearVelocity))+
            glm::dot(angularB,glm::dvec3(c.bodyB->angularVelocity));
        if((c.bodyA->IsStatic() && prescribedA!=0) ||
           (c.bodyB->IsStatic() && prescribedB!=0)) {
            ++stats.normalAccelerationBoundaryDeclines;return false;
        }
        const double diagonal=(double(c.bodyA->inverseMass)+c.bodyB->inverseMass)*glm::dot(n,n)+
            glm::dot(angularA,frames[c.frameA].inverseInertia*angularA)+
            glm::dot(angularB,frames[c.frameB].inverseInertia*angularB);
        if (!(diagonal>0) || !std::isfinite(diagonal)) {
            ++stats.normalAccelerationBreakdowns;return false;
        }
        active.push_back({i,c.frameA,c.frameB,n,angularA,angularB,diagonal});residual.push_back(r);
    }
    if(active.empty()) return false;
    std::vector<Wrench> velocity(frames.size());
    const auto multiply=[&](const std::vector<double>& x,std::vector<double>& output) {
        std::fill(velocity.begin(),velocity.end(),Wrench{});
        for(std::size_t i=0;i<active.size();++i) {
            const auto& c=active[i];
            velocity[c.a].linear+=c.n*x[i];velocity[c.a].angular+=c.angularA*x[i];
            velocity[c.b].linear-=c.n*x[i];velocity[c.b].angular-=c.angularB*x[i];
        }
        for(std::size_t i=0;i<frames.size();++i) if(frames[i].body) {
            velocity[i].linear*=double(frames[i].body->inverseMass);
            velocity[i].angular=frames[i].inverseInertia*velocity[i].angular;
        }
        for(std::size_t i=0;i<active.size();++i) {
            const auto& c=active[i];
            output[i]=glm::dot(c.n,velocity[c.a].linear-velocity[c.b].linear)+
                glm::dot(c.angularA,velocity[c.a].angular)-glm::dot(c.angularB,velocity[c.b].angular);
        }
        ++stats.normalMatrixProducts;
    };
    const auto dot=[](const std::vector<double>& a,const std::vector<double>& b) {
        double value=0;for(std::size_t i=0;i<a.size();++i)value+=a[i]*b[i];return value;
    };
    const auto initialResidual=residual;
    std::vector<double> correction(active.size(),0),z(active.size()),direction(active.size()),product(active.size());
    for(std::size_t i=0;i<active.size();++i) z[i]=residual[i]/active[i].diagonal;
    direction=z;double rz=dot(residual,z);
    const double tolerance=1.0e-10*stats.speedScale;
    // Exact CG terminates in at most the active operator's rank. Redundant
    // manifold rows make it positive semidefinite; zero/nonfinite curvature
    // stops this optional acceleration, never inserts artificial stiffness.
    for(std::size_t iteration=0;iteration<active.size();++iteration) {
        double largest=0;for(double r:residual)largest=std::max(largest,std::abs(r));
        if(largest<=tolerance)break;
        multiply(direction,product);const double curvature=dot(direction,product);
        if(!(curvature>0) || !std::isfinite(curvature) || !std::isfinite(rz)) {
            ++stats.normalAccelerationBreakdowns;return false;
        }
        const double step=rz/curvature;
        for(std::size_t i=0;i<active.size();++i) {correction[i]+=step*direction[i];residual[i]-=step*product[i];}
        for(std::size_t i=0;i<active.size();++i)z[i]=residual[i]/active[i].diagonal;
        const double next=dot(residual,z);
        if(rz==0)break;
        for(std::size_t i=0;i<active.size();++i)direction[i]=z[i]+(next/rz)*direction[i];
        rz=next;
    }
    // A line search preserves the same accumulated-normal-impulse cone.
    // Also require strict descent of the frozen-tangent normal quadratic.
    double fraction=1;
    for(std::size_t i=0;i<active.size();++i) {
        if(!std::isfinite(correction[i])) {++stats.normalAccelerationBreakdowns;return false;}
        if(correction[i]<0) {
            const auto row=active[i].original;
            // Tangential impulse is frozen during the normal acceleration.
            // Its already-satisfied Coulomb load must remain available.
            const double minimum=rows[row].friction>0 ?
                glm::length(glm::dvec3(tangent[row]))/rows[row].friction : 0;
            fraction=std::min(fraction,std::max(0.0,double(normal[row])-minimum)/-correction[i]);
        }
    }
    if(!(fraction>0))return false;
    multiply(correction,product);
    const double decrease=fraction*dot(initialResidual,correction)-.5*fraction*fraction*dot(correction,product);
    if(!(decrease>0) || !std::isfinite(decrease))return false;
    bool changed=false;
    for(std::size_t i=0;i<active.size();++i) {
        const auto row=active[i].original;
        // Nonnegative accumulated impulse is the existing contact law, not
        // a velocity repair. The line search reaches its boundary exactly.
        const float value=static_cast<float>(std::max(0.0,double(normal[row])+fraction*correction[i]));
        if(!std::isfinite(value)) {++stats.normalAccelerationBreakdowns;return false;}
        changed=changed || value!=normal[row];normal[row]=value;
    }
    return changed;
}
} // namespace

void PhysicsWorld::SolveParticleContacts(std::vector<ContactParticle>& particles,
                                         const std::vector<ParticleBoundaryContact>& contacts,
                                         std::vector<glm::vec3>& particleImpulses,
                                         glm::vec3* staticSupportImpulse,
                                         float remainingRigidDt) {
    for(const auto& contact:contacts)if(contact.twoWay)Wake(contact.body);
    m_impl->particleContactStats={};
    particleImpulses.assign(contacts.size(), glm::vec3(0));
    if (staticSupportImpulse) *staticSupportImpulse = glm::vec3(0);
    if (!std::isfinite(remainingRigidDt) || remainingRigidDt<0)
        throw std::invalid_argument("invalid remaining rigid contact interval");
    if (contacts.empty()) return;
    Impl& w = *m_impl;
    const auto finite = [](const glm::vec3& v) {
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
    };
    std::set<unsigned> islandSlots;
    std::vector<unsigned> pending;
    for (const auto& c : contacts) {
        if (c.particleIndex >= particles.size() || !finite(c.point) || !finite(c.normal) ||
            !finite(c.wallVelocity) || std::abs(glm::dot(c.normal,c.normal)-1.0f)>1.0e-3f)
            throw std::invalid_argument("invalid particle boundary contact");
        const auto& particle = particles[c.particleIndex];
        if (!(particle.mass>0) || !std::isfinite(particle.mass) || !std::isfinite(1.0f/particle.mass) ||
            !finite(particle.position) || !finite(particle.velocity))
            throw std::invalid_argument("invalid finite particle state");
        if (c.twoWay) {
            auto* body = w.Get(c.body);
            if (!body) throw std::invalid_argument("stale particle boundary owner");
            const unsigned slot = c.body.id & Impl::kSlotMask;
            if (islandSlots.insert(slot).second && !body->rigidBody.IsStatic()) pending.push_back(slot);
        }
    }
    float maximumParticleSpeed=0, maximumBodySpeed=0;
    for (const auto& p:particles) maximumParticleSpeed=std::max(maximumParticleSpeed,glm::length(p.velocity));
    const auto surfaceSpeed=[](const Impl::Body& body) {
        return glm::length(body.rigidBody.linearVelocity)+
            glm::length(body.rigidBody.angularVelocity)*body.boundingRadius;
    };
    if (remainingRigidDt>0) for (const auto slot:w.aliveSlots)
        maximumBodySpeed=std::max(maximumBodySpeed,surfaceSpeed(w.bodies[slot]));
    struct RigidRow { unsigned a,b; Contact contact; };
    std::vector<RigidRow> rigidRows;
    std::set<std::pair<unsigned,unsigned>> inspected;
    std::vector<char> supportCacheUsed(w.contactCache.size(),0);
    // Expand only through dynamic bodies. A static floor is an external
    // boundary, not a connection to every otherwise unrelated body on it.
    for (std::size_t cursor=0; cursor<pending.size(); ++cursor) {
        const unsigned slot = pending[cursor];
        const float queryMargin=(surfaceSpeed(w.bodies[slot])+maximumBodySpeed+maximumParticleSpeed)*remainingRigidDt;
        const auto neighbors = w.QuerySlots(w.CurrentBound(w.bodies[slot]).Expanded(queryMargin));
        for (const unsigned other : neighbors) {
            if (other==slot || !w.CanRespond(slot,other)) continue;
            const auto pair = std::minmax(slot,other);
            if (!inspected.emplace(pair.first,pair.second).second) continue;
            auto& a = w.bodies[pair.first]; auto& b = w.bodies[pair.second];
            const auto& oa = w.Orientation(a); const auto& ob = w.Orientation(b);
            bool touching = false;
            const float margin=(surfaceSpeed(a)+surfaceSpeed(b)+maximumParticleSpeed)*remainingRigidDt;
            for (int pa=0; pa<PrimitiveCount(a.shape); ++pa) {
                const auto childA = PrimitiveAt(a.shape,a.rigidBody,pa,&oa);
                for (int pb=0; pb<PrimitiveCount(b.shape); ++pb) {
                    const auto childB = PrimitiveAt(b.shape,b.rigidBody,pb,&ob);
                    const auto manifold = ComputeContacts(childA,childB,margin,&oa,&ob);
                    for (int k=0; k<manifold.count; ++k) {
                        const auto& c = manifold.points[k];
                        if (!c.hit) continue;
                        const double separation = c.hasLocalAnchors ? c.signedSeparation : -double(c.penetration);
                        if (separation>0) {
                            // Reuse only the ordinary solver's existing support
                            // identity/anchor/normal contract. New separated pairs
                            // still belong to normal impact timing, not this batch.
                            if (!(remainingRigidDt>0)) continue;
                            const ContactKey key{pair.first,pair.second,a.generation,b.generation,pa,pb};
                            const auto range=std::equal_range(w.contactCache.begin(),w.contactCache.end(),
                                CachedContact{key,{},{},0,{}},[](const auto& x,const auto& y){return x.key<y.key;});
                            const glm::dvec3 anchor=c.hasLocalAnchors ? c.localAnchorA :
                                glm::transpose(oa.rotation)*(glm::dvec3(c.point)-glm::dvec3(a.rigidBody.position));
                            std::ptrdiff_t best=-1;
                            double bestDistance=kWarmStartAnchorDistance;
                            for (auto old=range.first;old!=range.second;++old) {
                                const auto oldIndex=old-w.contactCache.begin();
                                if (supportCacheUsed[std::size_t(oldIndex)] || !old->key.SameBodies(key) ||
                                    glm::dot(old->normal,c.normal)<kWarmStartNormalDot) continue;
                                const double distance=glm::distance(old->localAnchorA,anchor);
                                if (distance<bestDistance) {best=oldIndex;bestDistance=distance;}
                            }
                            if (best<0) continue;
                            supportCacheUsed[std::size_t(best)]=1;
                            ++w.particleContactStats.persistentGapRows;
                        }
                        touching = true;
                        rigidRows.push_back({pair.first,pair.second,c});
                    }
                }
            }
            if (touching && islandSlots.insert(other).second && !w.bodies[other].rigidBody.IsStatic())
                pending.push_back(other);
        }
    }
    std::stable_sort(rigidRows.begin(),rigidRows.end(),[](const auto& a,const auto& b) {
        return std::tie(a.a,a.b) < std::tie(b.a,b.b);
    });
    // Finish allocation before any solver stores pointers into these arrays.
    std::vector<RigidBody> particleBodies(particles.size());
    for (std::size_t i=0; i<particles.size(); ++i) {
        particleBodies[i].position=particles[i].position;
        particleBodies[i].linearVelocity=particles[i].velocity;
        particleBodies[i].inverseMass=particles[i].mass>0 ? 1.0f/particles[i].mass : 0;
    }
    std::vector<RigidBody> rigidBodies;
    rigidBodies.reserve(islandSlots.size()+contacts.size());
    std::map<unsigned,std::size_t> index;
    for (const unsigned slot : islandSlots) {
        index.emplace(slot,rigidBodies.size()); rigidBodies.push_back(w.bodies[slot].rigidBody);
    }
    std::vector<std::size_t> boundaryIndex;
    boundaryIndex.reserve(contacts.size());
    for (const auto& c : contacts) {
        if (c.twoWay) boundaryIndex.push_back(index.at(c.body.id & Impl::kSlotMask));
        else {
            boundaryIndex.push_back(rigidBodies.size());
            RigidBody wall; wall.position=c.point; wall.linearVelocity=c.wallVelocity;
            rigidBodies.push_back(wall);
        }
    }
    auto& solver = w.particleSolver;
    solver.Clear();
    struct ClearOnExit { ContactSolver& solver; ~ClearOnExit() { solver.Clear(); } } clear{solver};
    struct BatchRow { RigidBody* a; RigidBody* b; Contact geometry; float friction; };
    std::vector<BatchRow> batchRows;batchRows.reserve(rigidRows.size()+contacts.size());
    for (const auto& row : rigidRows) {
        const auto& a = w.bodies[row.a]; const auto& b = w.bodies[row.b];
        const float friction=std::sqrt(std::max(a.friction,0.0f)*std::max(b.friction,0.0f));
        batchRows.push_back({&rigidBodies[index.at(row.a)],&rigidBodies[index.at(row.b)],row.contact,friction});
    }
    const std::size_t particleRowStart=batchRows.size();
    w.particleContactStats.rigidContactRows=particleRowStart;
    for (std::size_t i=0; i<contacts.size(); ++i) {
        const auto& c = contacts[i];
        Contact geometry; geometry.hit=true; geometry.point=c.point; geometry.normal=c.normal;
        geometry.preciseNormal=glm::dvec3(c.normal); geometry.signedSeparation=0;
        geometry.hasLocalAnchors=true;
        const auto& particle=particleBodies[c.particleIndex];const auto& body=rigidBodies[boundaryIndex[i]];
        geometry.localAnchorA=glm::dvec3(c.point)-glm::dvec3(particle.position);
        geometry.localAnchorB=glm::transpose(ContactRotation(body.orientation))*(glm::dvec3(c.point)-glm::dvec3(body.position));
        batchRows.push_back({&particleBodies[c.particleIndex],&rigidBodies[boundaryIndex[i]],geometry,0});
    }
    struct OriginalVelocity { RigidBody* body; glm::vec3 linear,angular; };
    std::vector<OriginalVelocity> original;original.reserve(particleBodies.size()+rigidBodies.size());
    for(auto& body:particleBodies)original.push_back({&body,body.linearVelocity,body.angularVelocity});
    for(auto& body:rigidBodies)original.push_back({&body,body.linearVelocity,body.angularVelocity});
    const auto prepare=[&](const std::vector<float>* normal=nullptr,const std::vector<glm::vec3>* tangent=nullptr) {
        solver.Clear();
        for(const auto& v:original) {v.body->linearVelocity=v.linear;v.body->angularVelocity=v.angular;}
        for(std::size_t i=0;i<batchRows.size();++i) {
            const auto& row=batchRows[i];
            solver.AddContact(*row.a,*row.b,row.geometry,row.friction,0,
                normal?(*normal)[i]:0,tangent?(*tangent)[i]:glm::vec3(0));
        }
        solver.Prepare(remainingRigidDt);
    };
    prepare();
    const auto& solved=solver.Constraints();
    const auto pointVelocity=[](const RigidBody& b,const glm::vec3& r) {
        return b.linearVelocity+glm::cross(b.angularVelocity,r);
    };
    auto& convergence=w.particleContactStats;
    for (const auto& c:solved) {
        convergence.speedScale=std::max(convergence.speedScale,
            glm::length(pointVelocity(*c.bodyA,c.velocityOffsetA)));
        convergence.speedScale=std::max(convergence.speedScale,
            glm::length(pointVelocity(*c.bodyB,c.velocityOffsetB)));
    }
    // Fluid contacts include finite particles and their actual rigid support
    // island. Refine this auxiliary solve to a declared velocity residual;
    // ordinary rigid step iteration counts and warm starts remain unchanged.
    do {
        const int count=std::min(10,64-convergence.iterations);
        solver.SolveVelocities(count);
        convergence.iterations+=count;
        const auto closingResidual=[&]() {
            float largest=0;
            for (const auto& c:solved) {
                const float normalSpeed=glm::dot(pointVelocity(*c.bodyA,c.velocityOffsetA)-
                    pointVelocity(*c.bodyB,c.velocityOffsetB),c.normal);
                if(!std::isfinite(normalSpeed)) return std::numeric_limits<float>::infinity();
                largest=std::max(largest,c.restitutionBias-normalSpeed);
            }
            return largest;
        };
        convergence.maximumClosingSpeed=closingResidual();
        if(convergence.maximumClosingSpeed>1.0e-5f*convergence.speedScale && convergence.iterations<64) {
            std::vector<float> normal;std::vector<glm::vec3> tangent;
            if(AccelerateParticleNormals(solved,convergence,normal,tangent)) {
                // This is an optional linear-solver proposal. Its double-
                // precision model is not permission to commit a worse actual
                // float constraint state, particularly for inconsistent PSD
                // rows generated by intersecting prescribed boundaries.
                const auto previousRows=solved;
                std::vector<OriginalVelocity> previous;previous.reserve(original.size());
                for(const auto& v:original)
                    previous.push_back({v.body,v.body->linearVelocity,v.body->angularVelocity});
                const float baseline=convergence.maximumClosingSpeed;
                prepare(&normal,&tangent);
                const float candidate=closingResidual();
                bool admissible=std::isfinite(candidate);
                const float rounding=32*std::numeric_limits<float>::epsilon();
                for(const auto& v:original)
                    admissible=admissible && finite(v.body->linearVelocity) && finite(v.body->angularVelocity);
                for(const auto& c:solved) {
                    const float limit=c.friction*c.normalImpulse;
                    admissible=admissible && std::isfinite(c.normalImpulse) && c.normalImpulse>=0 &&
                        finite(c.tangentImpulse) && glm::length(c.tangentImpulse)<=
                            limit+rounding*std::max(1.0f,limit);
                }
                admissible=admissible && candidate<=baseline+rounding*std::max(convergence.speedScale,baseline);
                if(admissible) {
                    convergence.maximumClosingSpeed=candidate;
                    ++convergence.normalAccelerations;
                } else {
                    // Roll back bit-for-bit, including the impulses. Replaying
                    // them would repeat float rounding and tangent projection.
                    // Only this private auxiliary solver's freshly prepared
                    // rows are restored; ordinary rigid cache/state is absent.
                    auto& writable=const_cast<std::vector<ContactConstraint>&>(solver.Constraints());
                    std::copy(previousRows.begin(),previousRows.end(),writable.begin());
                    for(const auto& v:previous) {
                        v.body->linearVelocity=v.linear;v.body->angularVelocity=v.angular;
                    }
                    convergence.maximumClosingSpeed=baseline;
                    ++convergence.normalAccelerationRejections;
                }
            }
        }
    } while (convergence.maximumClosingSpeed>1.0e-5f*convergence.speedScale && convergence.iterations<64);
    convergence.iterationCapReached=convergence.maximumClosingSpeed>1.0e-5f*convergence.speedScale;
    for (std::size_t i=0; i<contacts.size(); ++i) {
        const auto& c=solved[particleRowStart+i];
        particleImpulses[i]=c.normal*c.normalImpulse+c.tangentImpulse;
    }
    if (staticSupportImpulse) for (std::size_t i=0; i<particleRowStart; ++i) {
        const auto& c=solved[i];const glm::vec3 impulse=c.normal*c.normalImpulse+c.tangentImpulse;
        if (c.bodyA->IsStatic()) *staticSupportImpulse-=impulse;
        if (c.bodyB->IsStatic()) *staticSupportImpulse+=impulse;
    }
    for (std::size_t i=0; i<particles.size(); ++i) particles[i].velocity=particleBodies[i].linearVelocity;
    for (const auto& [slot,copy] : index) if (!w.bodies[slot].rigidBody.IsStatic()) {
        w.bodies[slot].rigidBody.linearVelocity=rigidBodies[copy].linearVelocity;
        w.bodies[slot].rigidBody.angularVelocity=rigidBodies[copy].angularVelocity;
    }
}

PhysicsWorld::ParticleContactStats PhysicsWorld::GetParticleContactStats() const {
    return m_impl ? m_impl->particleContactStats : ParticleContactStats{};
}

glm::vec3 PhysicsWorld::GetLinearVelocity(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body ? body->rigidBody.linearVelocity : glm::vec3(0.0f);
}

void PhysicsWorld::SetLinearVelocity(BodyHandle handle, const glm::vec3& velocity) {
    Impl::Body* body = m_impl->Get(handle);
    if (body) {if(velocity!=body->rigidBody.linearVelocity)m_impl->Wake(handle.id&Impl::kSlotMask);body->rigidBody.linearVelocity = velocity;}
}

glm::vec3 PhysicsWorld::GetAngularVelocity(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    return body ? body->rigidBody.angularVelocity : glm::vec3(0.0f);
}

glm::mat3 PhysicsWorld::GetInertiaWorld(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body || !body->isDynamic) return glm::mat3(0.0f);
    return glm::inverse(body->rigidBody.InverseInertiaWorld());
}

float PhysicsWorld::GetBodySupportDistance(BodyHandle handle, const glm::vec3& worldDirection) const {
    const Impl::Body* body = m_impl->Get(handle);
    const float directionLength = glm::length(worldDirection);
    if (!body || directionLength < 1.0e-6f) return 0.0f;

    const glm::vec3 direction = worldDirection / directionLength;
    float maximum = 0.0f;
    for (int part = 0; part < PrimitiveCount(body->shape); ++part) {
        const PrimitivePose primitive = PrimitiveAt(body->shape, body->rigidBody, part);
        float extent = 0.0f;
        if (primitive.shape.type == ShapeType::Sphere) {
            extent = primitive.shape.radius;
        } else if (primitive.shape.type == ShapeType::Box) {
            const glm::vec3 localDirection =
                glm::conjugate(glm::normalize(primitive.body.orientation)) * direction;
            extent = glm::dot(glm::abs(localDirection), primitive.shape.halfExtents);
        } else if (primitive.shape.asset) {
            // Directional support uses the physical vertices about the body's COM.
            // Child offsets and rotations have already been composed in PrimitiveAt.
            const auto r = PrimitiveRotation(primitive);
            const auto c = PrimitiveCenter(primitive);
            for (const auto& vertex : primitive.shape.asset->vertices)
                maximum = std::max(maximum, static_cast<float>(glm::dot(
                    c + r * vertex - glm::dvec3(body->rigidBody.position), glm::dvec3(direction))));
            continue;
        } else if (primitive.shape.type == ShapeType::Terrain && primitive.shape.terrain) {
            // Exact directional support of an arbitrary radial height
            // function would require global optimization. Its immutable
            // radius bound is conservative for this separation query.
            extent = primitive.shape.terrain->BoundRadius();
        }
        maximum = std::max(maximum,
                            glm::dot(primitive.body.position - body->rigidBody.position,
                                     direction) + extent);
    }
    return maximum;
}

float PhysicsWorld::GetPlayerShapeMaxSupportDistance() const {
    if (!m_impl->hasPlayerShape) return 0.0f;
    return m_impl->playerShape.radius + m_impl->playerShape.halfHeight;
}

void PhysicsWorld::SetAngularVelocity(BodyHandle handle, const glm::vec3& angularVelocity) {
    Impl::Body* body = m_impl->Get(handle);
    if (body) {if(angularVelocity!=body->rigidBody.angularVelocity)m_impl->Wake(handle.id&Impl::kSlotMask);body->rigidBody.angularVelocity = angularVelocity;}
}

void PhysicsWorld::Step(float fixedDeltaTime) {
    Step(fixedDeltaTime,nullptr);
}
void PhysicsWorld::Step(float fixedDeltaTime,const VelocityCoupling* coupling) {
    if(coupling&&(!coupling->iterations||coupling->iterations>64))throw std::invalid_argument("invalid velocity coupling quality");
    JUDAS_PROFILE_SCOPE("Rigid physics");
    Impl& w = *m_impl;
    if(w.stepping)throw std::logic_error("recursive physics step");
    struct StepGuard {bool& flag;explicit StepGuard(bool& f):flag(f){flag=true;}~StepGuard(){flag=false;}} guard(w.stepping);
    const Clock::time_point stepStart = Clock::now();
    w.completedObservationsReady=false;w.restoredCompletedObservations=false;
    for(auto& joint:w.joints)if(joint.restoredContinuationDt>0){
        if(joint.restoredContinuationDt!=fixedDeltaTime){
            joint.warm.fill(0);joint.state.angularDrive.impulses={0,0,0};
        }
        joint.restoredContinuationDt=0;
    }

    w.parallelContactDiagnostics={};w.parallelCookedDiagnostics={};
    w.stats = StepStats{};
    w.work={};w.work.active=PerformanceProfiler::Get().Active();
    if(w.collectingPreStepQueries){
        w.stepTouches=std::move(w.preStepQueryTouches);w.preStepQueryTouches.clear();w.collectingPreStepQueries=false;
        // A safe authority handoff may disable an observer after its motor move.
        for(auto it=w.stepTouches.begin();it!=w.stepTouches.end();){auto* a=w.Get(it->second.a);auto* b=w.Get(it->second.b);
            if(!a||!b||!a->enabled||!b->enabled)it=w.stepTouches.erase(it);else ++it;}
    }else if(!w.coupledStep)w.stepTouches.clear();
    const auto cachesBefore = w.cacheCounters;
    const ContactGeometryDiagnostics geometryBefore = GetContactGeometryDiagnostics();
    const auto collisionBefore=GetCollisionGeometryStats();

    {JUDAS_PROFILE_SCOPE("Physics kinematic publication");w.PublishKinematics(fixedDeltaTime);}

    // Awaken connected state before velocity integration for predicted impacts.
    static ProfileLabel predictionLabel("Physics prediction and wake"),integrationLabel("Physics velocity integration");
    ProfileScope predictionScope(predictionLabel);
    for(auto i:w.aliveSlots)if(w.bodies[i].HasMotion()&&!w.bodies[i].sleeping)w.CoverStepReach(w.bodies[i],fixedDeltaTime);
    w.GenerateCandidatePairs();
    for(auto [a,b]:w.candidatePairs){auto& aa=w.bodies[a];auto& bb=w.bodies[b];if(aa.sensor||bb.sensor||aa.queryOnly||bb.queryOnly)continue;
        auto moving=[&](const auto& body){return body.isKinematic
            ? body.rigidBody.linearVelocity!=glm::vec3(0)||body.rigidBody.angularVelocity!=glm::vec3(0)
            : !body.sleeping&&!body.rigidBody.IsStatic()&&(glm::length(body.rigidBody.linearVelocity-body.lastAcceleration*fixedDeltaTime)>.03f||glm::length(body.rigidBody.angularVelocity)>.03f);};
        if(aa.sleeping&&moving(bb))w.Wake(a);
        if(bb.sleeping&&moving(aa))w.Wake(b);
    }
    predictionScope.End();ProfileScope integrationScope(integrationLabel);
    // 1) Velocity from this step's force/torque accumulators (M12). Gravity
    // is already in linearVelocity via the caller's ApplyLinearAcceleration.
    // The start-of-step pose is kept for player sweeps and presentation.
    std::size_t movable = 0;
    for (const unsigned int slot : w.aliveSlots) {
        Impl::Body& body = w.bodies[slot];
        if (!body.rigidBody.IsStatic()) ++movable;
        if (!body.isDynamic||body.simulationSuspended) continue;
        body.motion.Clear();
        body.previousPosition = body.rigidBody.position;
        body.previousOrientation = body.rigidBody.orientation;
        // Capture the old endpoint before integration. CurrentBound itself is
        // keyed by represented pose, so a later correction cannot reuse it.
        w.CurrentBound(body);
        body.previousBound = body.currentBound;
        if(body.sleeping)continue;
        if(body.deferredAcceleration){body.rigidBody.linearVelocity+=body.lastAcceleration*fixedDeltaTime;body.deferredAcceleration=false;}
        IntegrateRigidBodyVelocity(body.rigidBody, fixedDeltaTime);
        w.CoverStepReach(body, fixedDeltaTime);
    }
    w.stats.bodies = w.aliveSlots.size();
    w.stats.dynamicBodies = movable;
    w.stats.possiblePairs = movable * (movable - (movable > 0 ? 1 : 0)) / 2 +
                            movable * (w.aliveSlots.size() - movable);
    integrationScope.End();

    // 2) Broadphase: every fat bound contains its body's current pose
    // (refreshed at the end of the previous Step and by ResetBody), so every
    // touching pair is among the candidates. Static-static pairs never are.
    static ProfileLabel broadLabel("Physics broadphase"), narrowLabel("Physics contacts"), solverLabel("Physics contact and joint solver"), proxiesLabel("Physics proxy refresh");
    ProfileScope broadScope(broadLabel);
    const Clock::time_point broadphaseStart = Clock::now();
    w.GenerateCandidatePairs();
    w.stats.candidatePairs = w.candidatePairs.size();
    broadScope.End(); ProfileScope narrowScope(narrowLabel);
    const Clock::time_point narrowphaseStart = Clock::now();

    // 3) Narrowphase at the current poses — the sole authority on contact.
    w.solver.Clear();
    w.lastStepContacts.clear();
    w.pendingCache.clear();
    w.startContacts.clear();
    w.separatedPairs.clear();
    w.cacheUsed.assign(w.contactCache.size(), 0);
    w.PrepareInitialContactGeometry(fixedDeltaTime);
    std::size_t initialGeometryIndex=0;
    for (const auto& [slotA, slotB] : w.candidatePairs) {
        Impl::Body& a = w.bodies[slotA];
        Impl::Body& b = w.bodies[slotB];
        if(a.sensor||b.sensor||a.queryOnly||b.queryOnly)continue;
        if((a.sleeping||a.rigidBody.IsStatic())&&(b.sleeping||b.rigidBody.IsStatic())){
            const auto ha=w.MakeHandle(slotA).id,hb=w.MakeHandle(slotB).id;auto key=std::minmax(ha,hb);auto old=w.previousTouches.find(key);
            if(old!=w.previousTouches.end()){auto observation=old->second;observation.normalImpulse=0;observation.impulseAvailable=false;observation.relativeVelocity={0,0,0};w.stepTouches[key]=observation;}
            continue;
        }
        const Impl::InitialContactGeometry* prepared=nullptr;
        if(initialGeometryIndex<w.initialContactGeometry.size()){
            const auto& candidate=w.initialContactGeometry[initialGeometryIndex];
            if(candidate.a==slotA&&candidate.b==slotB){prepared=&candidate;++initialGeometryIndex;}
        }
        const float friction = std::sqrt(std::max(a.friction, 0.0f) * std::max(b.friction, 0.0f));
        // Speculative margin: the distance this pair's surfaces can close
        // within the step at their post-force velocities (relative linear
        // motion plus each body's rotation at its bounding radius). Any
        // contact within it is generated now, before it can penetrate; at
        // rest on a support that is g*dt^2 (2.7 mm at 60 Hz, 9.81 m/s^2).
        const float margin = prepared?prepared->margin:
            (glm::length(a.rigidBody.linearVelocity - b.rigidBody.linearVelocity) +
             glm::length(a.rigidBody.angularVelocity) * a.boundingRadius +
             glm::length(b.rigidBody.angularVelocity) * b.boundingRadius) *
            fixedDeltaTime;
        int pairPoints = 0;
        const auto& orientationA = prepared?*prepared->orientationA:w.Orientation(a);
        const auto& orientationB = prepared?*prepared->orientationB:w.Orientation(b);
        const glm::dmat3 inverseA = glm::transpose(orientationA.rotation);
        for (int partA = 0; partA < PrimitiveCount(a.shape); ++partA) {
            const PrimitivePose childA = PrimitiveAt(a.shape, a.rigidBody, partA, &orientationA);
            for (int partB = 0; partB < PrimitiveCount(b.shape); ++partB) {
                const PrimitivePose childB = PrimitiveAt(b.shape, b.rigidBody, partB, &orientationB);
                const ContactManifold manifold =
                    prepared?prepared->manifold:ComputeContacts(childA, childB, margin, &orientationA, &orientationB);
                const ContactKey key{slotA, slotB, a.generation, b.generation, partA, partB};
                const auto range = std::equal_range(
                    w.contactCache.begin(), w.contactCache.end(), CachedContact{key, {}, {}, 0.0f, {}},
                    [](const CachedContact& x, const CachedContact& y) { return x.key < y.key; });
                bool touchingManifold=prepared?prepared->touching:false;
                if(!prepared){
                    for (int p=0;p<manifold.count;++p) {
                        const auto& c=manifold.points[p];
                        touchingManifold=touchingManifold || (c.hasLocalAnchors ? c.signedSeparation<=0 : c.penetration>=0);
                    }
                    if(!touchingManifold && manifold.count)
                        touchingManifold=ComputeContacts(childA,childB,0,&orientationA,&orientationB).count>0;
                }
                for (int p = 0; p < manifold.count; ++p) {
                    Contact contact = manifold.points[p];
                    if (!contact.hit) continue;
                    if((contact.hasLocalAnchors?contact.signedSeparation<=0:contact.penetration>=0)||touchingManifold) w.Observe(slotA,slotB,contact);
                    // Warm start from the nearest unused cached point of the
                    // same bodies/primitives (same generations: a reused slot
                    // never inherits a previous occupant's impulses).
                    const glm::dvec3 anchor = contact.hasLocalAnchors ? contact.localAnchorA :
                        inverseA * (glm::dvec3(contact.point) - glm::dvec3(a.rigidBody.position));
                    float warmNormal = 0.0f;
                    glm::vec3 warmTangent(0.0f);
                    std::ptrdiff_t best = -1;
                    double bestDistance = kWarmStartAnchorDistance;
                    for (auto it = range.first; it != range.second; ++it) {
                        const std::ptrdiff_t index = it - w.contactCache.begin();
                        if (w.cacheUsed[static_cast<std::size_t>(index)] || !it->key.SameBodies(key) ||
                            glm::dot(it->normal, contact.normal) < kWarmStartNormalDot) continue;
                        const double distance = glm::distance(it->localAnchorA, anchor);
                        if (distance < bestDistance) {
                            bestDistance = distance;
                            best = index;
                        }
                    }
                    if (best >= 0) {
                        w.cacheUsed[static_cast<std::size_t>(best)] = 1;
                        warmNormal = w.contactCache[static_cast<std::size_t>(best)].normalImpulse;
                        warmTangent = w.contactCache[static_cast<std::size_t>(best)].tangentImpulse;
                    }
                    // A separated, newly encountered pair is handled at TOI.
                    // Existing cached support retains its gap-closing constraint.
                    const double gap=contact.hasLocalAnchors ? contact.signedSeparation : -double(contact.penetration);
                    if (gap>0 && best<0 && !touchingManifold) {
                        const std::array<unsigned,4> pair{slotA,slotB,unsigned(partA),unsigned(partB)};
                        if(w.separatedPairs.empty() || w.separatedPairs.back()!=pair) w.separatedPairs.push_back(pair);
                        continue;
                    }
                    const auto constraint=w.solver.Constraints().size();
                    w.solver.AddContact(a.rigidBody,b.rigidBody,contact,friction,0,
                        warmNormal,warmTangent,&orientationA.rotation,&orientationB.rotation);
                    if(w.solver.Constraints().size()>constraint) {
                        w.pendingCache.push_back({key,anchor,contact.normal,0,glm::vec3(0),float(gap),a.contactObservationRevision,b.contactObservationRevision});
                        w.startContacts.push_back({slotA,slotB,constraint,friction,warmNormal,warmTangent,
                            best<0 && gap<=0 && Impl::NormalSpeed(contact,a.rigidBody,b.rigidBody)<-0.5});
                    }
                    w.lastStepContacts.push_back({contact.point, contact.normal, contact.penetration});
                    ++pairPoints;
                }
            }
        }
        if (pairPoints > 0) ++w.stats.collidingPairs;
    }
    w.stats.contactPoints = w.lastStepContacts.size();
    narrowScope.End(); ProfileScope solverScope(solverLabel);
    const Clock::time_point solverStart = Clock::now();

    // 4) Accumulated-impulse velocity solve (src/ContactSolver.h), then
    // positions from the solved velocities, then direct penetration removal.
    // A newly gravity-driven neighbour can reach an asleep body without any
    // prior velocity. Actual start contacts, not the early prediction alone,
    // must wake participating state before the velocity solver changes it.
    for(const auto& c:w.startContacts)for(auto slot:{c.a,c.b})
        if(w.bodies[slot].sleeping)w.Wake(slot);
    for(auto slot:w.aliveSlots){auto& body=w.bodies[slot];
        if(body.isDynamic&&!body.sleeping&&body.deferredAcceleration){
            body.rigidBody.linearVelocity+=body.lastAcceleration*fixedDeltaTime;
            body.deferredAcceleration=false;
        }
    }
    static ProfileLabel initialImpactsLabel("Physics initial impacts"), velocityLabel("Physics velocity constraints"), continuousImpactsLabel("Physics continuous impacts"), positionsLabel("Physics position constraints"), settleLabel("Physics sleeping assessment");
    ProfileScope initialImpactsScope(initialImpactsLabel);
    w.ResolveInitialImpacts(fixedDeltaTime);
    initialImpactsScope.End();
    ProfileScope velocityScope(velocityLabel);
    w.supportPairs.clear();
    for(const auto& c:w.startContacts) if(!c.newImpact) {
        const auto& key=w.pendingCache[c.constraint].key;
        w.supportPairs.push_back({c.a,c.b,unsigned(key.partA),unsigned(key.partB)});
    }
    std::sort(w.supportPairs.begin(),w.supportPairs.end());
    w.supportPairs.erase(std::unique(w.supportPairs.begin(),w.supportPairs.end()),w.supportPairs.end());
    {JUDAS_PROFILE_SCOPE("Physics contact row preparation");w.solver.Prepare(fixedDeltaTime);}
    if(coupling){
        if(coupling->begin)coupling->begin(fixedDeltaTime);
        // Material participants may have awakened their connected island.
        // Consume deferred gravity and include those joints at THIS boundary.
        for(auto slot:w.aliveSlots){auto& body=w.bodies[slot];if(body.isDynamic&&!body.sleeping&&body.deferredAcceleration){body.rigidBody.linearVelocity+=body.lastAcceleration*fixedDeltaTime;body.deferredAcceleration=false;}}
        if(!w.joints.empty())w.PrepareJoints(w.jointSolver,w.JointInputs(),fixedDeltaTime);
        const unsigned rounds=std::max(unsigned(ContactSolver::kVelocityIterations),coupling->iterations);
        std::vector<unsigned char> awake(w.bodies.size(),0);
        for(auto slot:w.aliveSlots)awake[slot]=!w.bodies[slot].sleeping;
        for(unsigned iteration=0;iteration<rounds;++iteration){
            w.solver.SolveVelocities(1);
            if(!w.joints.empty())w.jointSolver.SolveIteration();
            if(coupling->solve)coupling->solve(fixedDeltaTime,iteration);
            // A real material contact may wake a previously unmapped island.
            // Include that island's native joints without warm-starting the
            // already solved rows twice, and consume only deferred gravity.
            bool newlyAwake=false;
            for(auto slot:w.aliveSlots){auto& body=w.bodies[slot];
                if(!awake[slot]&&!body.sleeping){awake[slot]=1;newlyAwake=true;}
                if(body.isDynamic&&!body.sleeping&&body.deferredAcceleration){body.rigidBody.linearVelocity+=body.lastAcceleration*fixedDeltaTime;body.deferredAcceleration=false;}
            }
            if(newlyAwake&&!w.joints.empty()){
                const auto oldRows=w.jointSolver.RowCount();
                w.PrepareJoints(w.jointSolver,w.JointInputs(),fixedDeltaTime,true,false,true);
                w.jointSolver.SolveIteration(oldRows);
            }
        }
    }else if(w.joints.empty())w.solver.SolveVelocities();
    else {w.PrepareJoints(w.jointSolver,w.JointInputs(),fixedDeltaTime);for(int i=0;i<ContactSolver::kVelocityIterations;++i){w.solver.SolveVelocities(1);w.jointSolver.SolveIteration();}}
    // Remember this step's converged impulses for the next step's warm start.
    static ProfileLabel historyLabel("Physics contact history publication");
    ProfileScope historyScope(historyLabel);
    const std::vector<ContactConstraint>& solved = w.solver.Constraints();
    for (std::size_t i = 0; i < solved.size() && i < w.pendingCache.size(); ++i) {
        const auto& key=w.pendingCache[i].key;
        const unsigned ha=w.MakeHandle(key.slotA).id,hb=w.MakeHandle(key.slotB).id;
        const auto pair=std::minmax(ha,hb);
        if(auto it=w.stepTouches.find({pair.first,pair.second});it!=w.stepTouches.end()){it->second.normalImpulse+=solved[i].normalImpulse;it->second.impulseAvailable=true;}
        w.pendingCache[i].normalImpulse = solved[i].normalImpulse;
        w.pendingCache[i].tangentImpulse = solved[i].tangentImpulse;
    }
    for(const auto& cached:w.contactCache)if(cached.key.slotA<w.bodies.size()&&cached.key.slotB<w.bodies.size()&&w.bodies[cached.key.slotA].alive&&w.bodies[cached.key.slotB].alive&&w.bodies[cached.key.slotA].generation==cached.key.generationA&&w.bodies[cached.key.slotB].generation==cached.key.generationB&&(w.bodies[cached.key.slotA].sleeping||w.bodies[cached.key.slotA].rigidBody.IsStatic())&&(w.bodies[cached.key.slotB].sleeping||w.bodies[cached.key.slotB].rigidBody.IsStatic()))w.pendingCache.push_back(cached);
    std::stable_sort(w.pendingCache.begin(), w.pendingCache.end(),
                     [](const CachedContact& x, const CachedContact& y) { return x.key < y.key; });
    std::swap(w.contactCache, w.pendingCache);
    w.completedContactObservations=w.contactCache;
    historyScope.End();
    velocityScope.End();
    ProfileScope continuousImpactsScope(continuousImpactsLabel);
    w.AdvanceImpacts(fixedDeltaTime,coupling!=nullptr);
    continuousImpactsScope.End();
    ProfileScope positionsScope(positionsLabel);
    for (const unsigned int slot:w.aliveSlots) {
        auto& body=w.bodies[slot];
        if(body.HasMotion()) w.solver.UpdatePreparedRotation(body.rigidBody,w.Orientation(body).rotation);
    }
    w.solver.SolvePositions();
    if(coupling&&coupling->finish)coupling->finish(fixedDeltaTime);
    positionsScope.End();
    ProfileScope settleScope(settleLabel);
    w.Settle(fixedDeltaTime);
    settleScope.End();
    solverScope.End(); ProfileScope proxyScope(proxiesLabel);
    const Clock::time_point solverEnd = Clock::now();

    // 5) Keep every dynamic proxy's fat bound around its previous-to-current
    // motion for the player's sweeps and the next step's candidates.
    for (const unsigned int slot : w.aliveSlots) {
        Impl::Body& body = w.bodies[slot];
        if (body.HasMotion()) w.RefreshProxy(body);
    }
    static ProfileLabel touchesLabel("Physics endpoint contact publication");
    ProfileScope touchesScope(touchesLabel);
    w.queryTouchesPending=std::any_of(w.aliveSlots.begin(),w.aliveSlots.end(),[&](unsigned i){return w.bodies[i].queryOnly;});
    if(!w.queryTouchesPending&&!w.coupledStep)w.FinishTouches();
    touchesScope.End();
    w.stats.proxyReinsertions = w.reinsertionsSinceStep;
    w.reinsertionsSinceStep = 0;
    w.stats.treeHeight = w.tree.Height();
    w.stats.orientationCacheHits = w.cacheCounters.orientationHits-cachesBefore.orientationHits;
    w.stats.orientationCacheRebuilds = w.cacheCounters.orientationRebuilds-cachesBefore.orientationRebuilds;
    w.stats.boundCacheHits = w.cacheCounters.boundHits-cachesBefore.boundHits;
    w.stats.boundCacheRebuilds = w.cacheCounters.boundRebuilds-cachesBefore.boundRebuilds;
    w.stats.shapeCacheRebuilds = w.cacheCounters.shapeRebuilds-cachesBefore.shapeRebuilds;
    w.stats.solverFrameBuilds = w.solver.FrameBuilds();
    w.stats.geometryCacheAllocations = w.cacheCounters.allocations-cachesBefore.allocations+w.solver.FrameAllocations();
    w.stats.geometryCacheAllocatedBytes = w.cacheCounters.allocatedBytes-cachesBefore.allocatedBytes+w.solver.FrameAllocatedBytes();
    w.stats.solverFrameNodeRequests = w.solver.FrameNodeRequests();
    w.stats.geometryCacheBytes = w.CacheBytes();
    const Clock::time_point stepEnd = Clock::now();
    w.stats.broadphaseMilliseconds = MillisecondsBetween(broadphaseStart, narrowphaseStart) +
                                     MillisecondsBetween(solverEnd, stepEnd);
    w.stats.narrowphaseMilliseconds = MillisecondsBetween(narrowphaseStart, solverStart);
    JUDAS_PROFILE_COUNTER("Sleeping physics bodies",double(w.stats.sleepingBodies),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Awake physics bodies",double(w.stats.awakeBodies),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics bodies last step",double(w.stats.bodies),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics candidate pairs last step",double(w.stats.candidatePairs),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics contacts last step",double(w.stats.contactPoints),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics joints",double(w.joints.size()),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact events",double(w.stats.impactEvents),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact queries",double(w.stats.impactQueries),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact search iterations",double(w.stats.impactSearchIterations),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact sampling fallbacks",double(w.stats.impactSamplingFallbacks),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact sampling tests",double(w.stats.impactSamplingTests),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact search limits",double(w.stats.impactSearchLimit),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact search stalls",double(w.stats.impactSearchStalls),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact sampling resolution caps",double(w.stats.impactSamplingResolutionCaps),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact pose evaluations",double(w.impactPoseEvaluations),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact pose reuses",double(w.impactPoseReuses),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact orientation preparations",double(w.impactOrientationBuilds),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact actual-contact requests",double(w.impactTruthRequests),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact actual-contact reuses",double(w.impactTruthReuses),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact remaining-bound rejections",double(w.impactBoundsRejected),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact actual-bound rejections",double(w.impactActualBoundsRejected),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics broadphase passes",double(w.work.candidatePasses),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics broadphase root queries",double(w.work.candidateQueries),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics broadphase overlapping leaves",double(w.work.candidateLeaves),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics sleep graph edges",double(w.sleepGraphEdges),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics sleep islands",double(w.sleepIslandCount),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics sleep scratch bytes",double(w.sleepScratchBytes),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics persistent contact rows",double(w.solver.Constraints().size()),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics joint rows",double(w.joints.empty()?0:w.jointSolver.RowCount()),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics continuation coupled fallback events",double(w.work.coupledFallbackEvents),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics continuation elastic fallback events",double(w.work.elasticFallbackEvents),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics continuation geometry fallback events",double(w.work.geometryFallbackEvents),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics peak impact island bodies",double(w.work.peakImpactBodies),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics peak impact contact rows",double(w.work.peakImpactRows),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics impact continuation cache ms",double(w.work.continuationCache.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics support continuation attempts",double(w.work.continuationAttempts),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics support continuation accepted",double(w.work.continuationAccepted),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics support continuation partitions",double(w.work.continuationPartitions),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics support continuation over-budget fallback",double(w.work.continuationOverBudget),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics support continuation proof ms",double(w.work.continuationProof.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics CCD search inclusive ms",double(w.work.toi.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics CCD geometry inclusive ms",double(w.work.geometry.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics CCD geometry calls",double(w.work.geometry.calls),ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics impact island discovery ms",double(w.work.impactIslands.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics impact solve ms",double(w.work.impactSolve.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics impact observation publication ms",double(w.work.impactObservations.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics joint preparation ms",double(w.work.jointPreparation.nanoseconds)*1e-6,ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics joint preparation calls",double(w.work.jointPreparation.calls),ProfileCounterMode::Sum);
    const auto collisionAfter=GetCollisionGeometryStats();
    JUDAS_PROFILE_COUNTER("Physics cooked BVH nodes",double(collisionAfter.nodes-collisionBefore.nodes+w.parallelCookedDiagnostics.nodes),ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics cooked triangles",double(collisionAfter.triangles-collisionBefore.triangles+w.parallelCookedDiagnostics.triangles),ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Physics cooked convex tests",double(collisionAfter.convexTests-collisionBefore.convexTests+w.parallelCookedDiagnostics.convexTests),ProfileCounterMode::Sum);
    w.stats.solverMilliseconds = MillisecondsBetween(solverStart, solverEnd);
    w.stats.totalMilliseconds = MillisecondsBetween(stepStart, stepEnd);
    const ContactGeometryDiagnostics geometryAfter = GetContactGeometryDiagnostics();
    w.stats.geometryPredicates = geometryAfter.predicates - geometryBefore.predicates + w.parallelContactDiagnostics.predicates;
    w.stats.geometryExactFallbacks = geometryAfter.exactFallbacks - geometryBefore.exactFallbacks + w.parallelContactDiagnostics.exactFallbacks;
    w.stats.geometryUnresolved = geometryAfter.unresolved - geometryBefore.unresolved + w.parallelContactDiagnostics.unresolved;
    w.stats.geometryNumericGapFallbacks = geometryAfter.numericGapFallbacks - geometryBefore.numericGapFallbacks + w.parallelContactDiagnostics.numericGapFallbacks;
    JUDAS_PROFILE_COUNTER("Physics geometry predicates",double(w.stats.geometryPredicates),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics geometry exact fallbacks",double(w.stats.geometryExactFallbacks),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics geometry unresolved",double(w.stats.geometryUnresolved),ProfileCounterMode::Latest);
    JUDAS_PROFILE_COUNTER("Physics geometry numeric gap fallbacks",double(w.stats.geometryNumericGapFallbacks),ProfileCounterMode::Latest);
    ++w.completedObservationEpoch;w.completedObservationDt=w.completedSolverDt=fixedDeltaTime;
    w.completedObservationsReady=true;

}

void PhysicsWorld::StepCoupled(float dt,unsigned intervals,
    const std::function<void(float,unsigned)>& before,
    const std::function<void(float,unsigned)>& after,
    const VelocityCoupling* coupling) {
    if(!std::isfinite(dt)||dt<=0||!intervals||intervals>32)
        throw std::invalid_argument("invalid coupled physics interval");
    if(coupling&&(!coupling->iterations||coupling->iterations>64))throw std::invalid_argument("invalid velocity coupling quality");
    if(intervals==1){if(before)before(dt,0);Step(dt,coupling);if(after)after(dt,0);return;}
    Impl& w=*m_impl;
    if(w.coupledStep)throw std::logic_error("nested coupled physics step");
    struct Snapshot {BodyHandle handle;glm::vec3 position{0},force{0},torque{0};glm::quat rotation{1,0,0,0};std::vector<RigidMotionSegment> motion;};
    std::map<unsigned,Snapshot> saved;
    for(auto slot:w.aliveSlots){auto& b=w.bodies[slot];if(!b.HasMotion())continue;
        const auto handle=w.MakeHandle(slot);
        saved.emplace(handle.id,Snapshot{handle,b.rigidBody.position,b.rigidBody.forceAccumulator,b.rigidBody.torqueAccumulator,b.rigidBody.orientation,{}});
        // A next-fixed-step target still finishes at the original macro end.
        if(b.isKinematic&&b.kinematic.targetNextStep){b.kinematic.remainingSeconds=dt;b.kinematic.targetNextStep=false;}
    }
    const auto epoch=w.completedObservationEpoch;
    const float h=dt/float(intervals);
    std::vector<DebugContact> contacts;
    struct Reaction {glm::vec3 linear{0},angular{0};float motor=0;};
    std::map<uint64_t,Reaction> jointReactions;
    std::vector<CachedContact> observations;
    StepStats totals{};
    w.coupledStep=true;
    if(!w.collectingPreStepQueries)w.stepTouches.clear();
    try{
        for(unsigned interval=0;interval<intervals;++interval){
            // Force producers run once per fixed update. Retain their force
            // (not their impulse) over all subintervals; interval producers such
            // as wheel contact add only their own current-geometry reactions.
            if(interval)for(auto& [_,s]:saved)if(auto* b=w.Get(s.handle)){
                b->rigidBody.forceAccumulator+=s.force;b->rigidBody.torqueAccumulator+=s.torque;
            }
            if(before)before(h,interval);
            // These are completed-interval observations, not warm-start
            // inputs. JointInputs deliberately skips sleeping/inactive rows;
            // without clearing them here a prior macro publication would be
            // counted once per interval and grow on every sleeping macro.
            // Keep joint.warm and angularDrive.impulses in their last-h units.
            for(auto& joint:w.joints){joint.state.reactionImpulse={0,0,0};joint.state.reactionAngularImpulse={0,0,0};joint.state.motorImpulse=0;}
            Step(h,coupling);
            for(const auto& joint:w.joints){auto& reaction=jointReactions[joint.handle.id];reaction.linear+=joint.state.reactionImpulse;reaction.angular+=joint.state.reactionAngularImpulse;reaction.motor+=joint.state.motorImpulse;}
            const auto& a=w.stats;
#define SUM(field) totals.field+=a.field
            SUM(possiblePairs);SUM(candidatePairs);SUM(layerRejectedPairs);SUM(collidingPairs);SUM(contactPoints);SUM(proxyReinsertions);
            SUM(geometryPredicates);SUM(geometryExactFallbacks);SUM(geometryUnresolved);SUM(geometryNumericGapFallbacks);
            SUM(orientationCacheHits);SUM(orientationCacheRebuilds);SUM(boundCacheHits);SUM(boundCacheRebuilds);SUM(shapeCacheRebuilds);SUM(solverFrameBuilds);
            SUM(geometryCacheAllocations);SUM(geometryCacheAllocatedBytes);SUM(solverFrameNodeRequests);
            SUM(impactEvents);SUM(impactSafetyFallback);SUM(impactEventCapFallback);SUM(impactQueries);SUM(impactSearchIterations);SUM(impactSearchLimit);
            SUM(impactUncertifiedAdvances);SUM(impactSearchStalls);SUM(impactSamplingFallbacks);SUM(impactSamplingTests);SUM(impactSamplingResolutionCaps);
            SUM(broadphaseMilliseconds);SUM(narrowphaseMilliseconds);SUM(solverMilliseconds);SUM(totalMilliseconds);
#undef SUM
            totals.bodies=a.bodies;totals.dynamicBodies=a.dynamicBodies;totals.sleepingBodies=a.sleepingBodies;totals.sleepingIslands=a.sleepingIslands;totals.awakeBodies=a.awakeBodies;
            totals.treeHeight=std::max(totals.treeHeight,a.treeHeight);totals.geometryCacheBytes=a.geometryCacheBytes;
            totals.impactPeakIterations=std::max(totals.impactPeakIterations,a.impactPeakIterations);totals.impactSamplingMaxInterval=std::max(totals.impactSamplingMaxInterval,a.impactSamplingMaxInterval);
            contacts.insert(contacts.end(),w.lastStepContacts.begin(),w.lastStepContacts.end());
            const size_t oldRows=observations.size();std::vector<bool> matched(oldRows,false);
            for(const auto& c:w.completedContactObservations){size_t best=oldRows;double distance=kWarmStartAnchorDistance;
                for(size_t i=0;i<oldRows;++i){const auto& prior=observations[i];if(matched[i]||!prior.key.SameBodies(c.key)||glm::dot(prior.normal,c.normal)<kWarmStartNormalDot)continue;const double gap=glm::length(prior.localAnchorA-c.localAnchorA);if(gap<distance){distance=gap;best=i;}}
                if(best==oldRows)observations.push_back(c);
                else{matched[best]=true;auto& prior=observations[best];const auto normal=prior.normalImpulse+c.normalImpulse;const auto tangent=prior.tangentImpulse+c.tangentImpulse;prior=c;prior.normalImpulse=normal;prior.tangentImpulse=tangent;}}
            for(auto& [_,s]:saved)if(auto* b=w.Get(s.handle))for(auto segment:b->motion.Segments()){
                segment.begin+=double(interval)*h;segment.end+=double(interval)*h;s.motion.push_back(segment);
            }
            if(after)after(h,interval);
        }
    }catch(...){w.coupledStep=false;throw;}
    w.coupledStep=false;
    w.lastStepContacts=std::move(contacts);
    std::stable_sort(observations.begin(),observations.end(),[](const auto& a,const auto& b){return a.key<b.key;});w.completedContactObservations=std::move(observations);
    w.completedObservationEpoch=epoch+1;w.completedObservationDt=dt;w.stepDuration=double(h)*intervals;
    for(auto& [_,s]:saved)if(auto* b=w.Get(s.handle)){
        b->previousPosition=s.position;b->previousOrientation=s.rotation;b->previousBound.valid=false;
        b->motion.SetRecorded(std::move(s.motion));w.RefreshProxy(*b);
        totals.motionSegments+=b->motion.Segments().size();totals.motionStorageBytes+=b->motion.StorageBytes();
    }
    for(auto& joint:w.joints)if(auto it=jointReactions.find(joint.handle.id);it!=jointReactions.end()){joint.state.reactionImpulse=it->second.linear;joint.state.reactionAngularImpulse=it->second.angular;joint.state.motorImpulse=it->second.motor;}
    w.stats=totals;
    if(!w.queryTouchesPending)w.FinishTouches();
}

const PhysicsWorld::StepStats& PhysicsWorld::LastStepStats() const { return m_impl->stats; }

void PhysicsWorld::QueryBodiesInAabbInto(const glm::vec3& min,const glm::vec3& max,std::vector<BodyHandle>& output,const PhysicsQueryFilter& filter)const{output.clear();for(auto slot:m_impl->QuerySlots(Aabb{glm::min(min,max),glm::max(min,max)}))if(m_impl->MatchesQuery(slot,filter))output.push_back(m_impl->MakeHandle(slot));}
std::vector<BodyHandle> PhysicsWorld::QueryBodiesInAabb(const glm::vec3& min, const glm::vec3& max, const PhysicsQueryFilter& filter) const {
    std::vector<BodyHandle> result;
    for (const unsigned int slot : m_impl->QuerySlots(Aabb{glm::min(min, max), glm::max(min, max)})) {
        if(m_impl->MatchesQuery(slot,filter))result.push_back(m_impl->MakeHandle(slot));
    }
    return result;
}

bool PhysicsWorld::GetBodyBroadphaseBounds(BodyHandle handle, glm::vec3& outMin, glm::vec3& outMax) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    const Aabb& fat = m_impl->tree.FatAabb(body->proxy);
    outMin = fat.min;
    outMax = fat.max;
    return true;
}

bool PhysicsWorld::GetBodyGeometryCacheState(BodyHandle handle, GeometryCacheState& state) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    const auto& current = body->currentBound;
    const auto& previous = body->previousBound;
    state.currentPose = {current.position,current.orientation};
    state.previousPose = {previous.position,previous.orientation};
    state.currentMin = current.bound.min; state.currentMax = current.bound.max;
    state.previousMin = previous.bound.min; state.previousMax = previous.bound.max;
    state.currentValid = current.valid; state.previousValid = previous.valid;
    state.boundingRadius = body->boundingRadius;
    return true;
}

std::vector<PhysicsWorld::CollidingPair> PhysicsWorld::FindCollidingPairs() const {
    Impl& w = *m_impl;
    // Same candidate generation and narrowphase as Step, without solving.
    w.GenerateCandidatePairs();
    std::vector<CollidingPair> result;
    for (const auto& [slotA, slotB] : w.candidatePairs) {
        Impl::Body& a = w.bodies[slotA];
        Impl::Body& b = w.bodies[slotB];
        const auto& orientationA = w.Orientation(a);
        const auto& orientationB = w.Orientation(b);
        int points = 0;
        for (int partA = 0; partA < PrimitiveCount(a.shape); ++partA) {
            const PrimitivePose childA = PrimitiveAt(a.shape, a.rigidBody, partA, &orientationA);
            for (int partB = 0; partB < PrimitiveCount(b.shape); ++partB) {
                const PrimitivePose childB = PrimitiveAt(b.shape, b.rigidBody, partB, &orientationB);
                const ContactManifold manifold =
                    ComputeContacts(childA, childB, 0.0f, &orientationA, &orientationB);
                for (int p = 0; p < manifold.count; ++p) {
                    if (manifold.points[p].hit) ++points;
                }
            }
        }
        if (points > 0) result.push_back({w.MakeHandle(slotA), w.MakeHandle(slotB), points});
    }
    return result;
}

std::vector<BodyHandle> PhysicsWorld::AliveBodies() const {
    std::vector<BodyHandle> result;
    result.reserve(m_impl->aliveSlots.size());
    for (const unsigned int slot : m_impl->aliveSlots) result.push_back(m_impl->MakeHandle(slot));
    return result;
}

bool PhysicsWorld::GetBodyShape(BodyHandle handle, Shape& outShape, BodyTransform& outPose) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return false;
    outShape = body->shape;
    outPose.position = body->rigidBody.position;
    outPose.rotation = body->rigidBody.orientation;
    return true;
}

BodyTransform PhysicsWorld::GetTransform(BodyHandle handle) const {
    BodyTransform result;
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return result;
    result.position = body->rigidBody.position-body->rigidBody.orientation*body->shape.pivotOffset;
    result.rotation = body->rigidBody.orientation;
    return result;
}
BodyTransform PhysicsWorld::GetPreviousTransform(BodyHandle handle) const {
    BodyTransform result;
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return result;
    if (body->HasMotion()) {
        result.position = body->previousPosition-body->previousOrientation*body->shape.pivotOffset;
        result.rotation = body->previousOrientation;
    } else {
        result.position = body->rigidBody.position-body->rigidBody.orientation*body->shape.pivotOffset;
        result.rotation = body->rigidBody.orientation;
    }
    return result;
}

std::vector<PhysicsWorld::BodyMotionSegment> PhysicsWorld::GetBodyMotionSegments(BodyHandle handle) const {
    std::vector<BodyMotionSegment> result;
    const Impl::Body* body = m_impl->Get(handle);
    if (!body || !body->HasMotion()) return result;
    result.reserve(body->motion.Segments().size());
    for (const auto& source : body->motion.Segments()) {
        if (source.owner != handle.id) return {};
        result.push_back({source.begin, source.end,
            {source.position-source.orientation*body->shape.pivotOffset, source.orientation}, {source.endPosition-source.endOrientation*body->shape.pivotOffset, source.endOrientation},
            source.linearVelocity, source.driftAngularVelocity, source.inverseMass > 0||source.prescribed,body->shape.pivotOffset,source.prescribed});
    }
    if (!result.empty()) result.back().endPose = {body->rigidBody.position-body->rigidBody.orientation*body->shape.pivotOffset, body->rigidBody.orientation};
    return result;
}

BodyTransform PhysicsWorld::EvaluateBodyMotionSegment(const BodyMotionSegment& segment, double time) {
    if (!std::isfinite(time) || time < segment.begin || time > segment.end)
        throw std::out_of_range("body motion segment time");
    RigidMotionSegment source;
    source.begin=segment.begin;source.end=segment.end;source.position=segment.start.position+segment.start.rotation*segment.pivotOffset;
    source.orientation=segment.start.rotation;source.linearVelocity=segment.linearVelocity;source.angularVelocity=segment.angularVelocity;source.driftAngularVelocity=segment.angularVelocity;
    source.inverseMass=segment.movable&&!segment.prescribed?1.f:0.f;source.prescribed=segment.prescribed;
    const auto body=source.Evaluate(time);
    return {body.position-body.orientation*segment.pivotOffset, body.orientation};
}

std::vector<BodyBox> PhysicsWorld::GetBodyBoxes(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return {};
    return BoxesAt(body->shape, body->rigidBody.position, body->rigidBody.orientation);
}

std::vector<BodyBox> PhysicsWorld::GetPreviousBodyBoxes(BodyHandle handle) const {
    const Impl::Body* body = m_impl->Get(handle);
    if (!body) return {};
    return BoxesAt(body->shape,
                   body->HasMotion() ? body->previousPosition : body->rigidBody.position,
                   body->HasMotion() ? body->previousOrientation : body->rigidBody.orientation);
}

void PhysicsWorld::ResetBody(BodyHandle handle, const glm::vec3& position,
                              const glm::quat& rotation) {
    Impl::Body* body = m_impl->Get(handle);
    if (!body) return;
    if(body->rigidBody.position!=position+rotation*body->shape.pivotOffset||body->rigidBody.orientation!=rotation){
        m_impl->Wake(handle.id&Impl::kSlotMask);
        const auto bounds=m_impl->CurrentBound(*body);auto slots=m_impl->QuerySlots(bounds);for(auto i:slots)if(m_impl->bodies[i].sleeping)m_impl->Wake(i);
    }
    for(auto& j:m_impl->joints)if(j.state.settings.bodyA.id==handle.id||j.state.settings.bodyB.id==handle.id)j.warm.fill(0);
    m_impl->InvalidateRestoredContinuation(handle.id&Impl::kSlotMask);
    ++body->contactObservationRevision;
    body->rigidBody.position = position+rotation*body->shape.pivotOffset;
    body->rigidBody.orientation = rotation;
    body->previousPosition = body->rigidBody.position;
    body->motion.Clear();
    body->kinematic={};body->kinematicActiveDuration=0;
    body->previousOrientation = rotation;
    body->rigidBody.linearVelocity = glm::vec3(0.0f);
    body->rigidBody.angularVelocity = glm::vec3(0.0f);
    body->rigidBody.ClearAccumulators();
    m_impl->RefreshProxy(*body);
    if(!body->isDynamic&&!body->queryOnly){auto slots=m_impl->QuerySlots(m_impl->CurrentBound(*body));for(auto i:slots)if(m_impl->bodies[i].sleeping)m_impl->Wake(i);}
}

bool PhysicsWorld::CreatePlayerShape(float radius, float halfHeight) {
    m_impl->playerShape = Shape::Capsule(radius, halfHeight);
    m_impl->hasPlayerShape = true;
    return true;
}

void PhysicsWorld::DestroyPlayerShape() { m_impl->hasPlayerShape = false; }

ShapeSweepHit PhysicsWorld::SweepPlayerShape(const glm::vec3& fromCenter, const glm::quat& rotation,
                                              const glm::vec3& displacement,
                                              bool interpolateDynamicBodyMotion,
                                              float bodyMotionStart,
                                              float bodyMotionEnd, const PhysicsQueryFilter* filter) const {
    ShapeSweepHit result;
    if (!m_impl->hasPlayerShape) return result;

    return SweepCapsuleMotion(m_impl->playerShape.radius,m_impl->playerShape.halfHeight,
        fromCenter,rotation,displacement,interpolateDynamicBodyMotion,bodyMotionStart,
        bodyMotionEnd,filter,m_impl->playerCollisionLayer,m_impl->playerCollisionMask,filter==nullptr);
}
ShapeSweepHit PhysicsWorld::SweepCapsuleMotion(float radius,float halfHeight,
    const glm::vec3& fromCenter,const glm::quat& rotation,const glm::vec3& displacement,
    bool interpolateDynamicBodyMotion,float bodyMotionStart,float bodyMotionEnd,
    const PhysicsQueryFilter* filter,unsigned collisionLayer,CategoryMask collisionMask,bool bilateralFilter) const {
    ShapeSweepHit result;
    if(!(radius>0)||halfHeight<0)return result;
    const float displacementLength = glm::length(displacement);
    if (displacementLength < 1.0e-6f && !interpolateDynamicBodyMotion) return result;

    const glm::vec3 localSegA(0.0f, -halfHeight, 0.0f);
    const glm::vec3 localSegB(0.0f, halfHeight, 0.0f);
    const float capsuleRadius = radius;

    auto worldSegmentAt = [&](const glm::vec3& center) {
        return std::make_pair(center + rotation * localSegA, center + rotation * localSegB);
    };
    // Milestone 32: one broadphase query for the whole swept capsule; every
    // evaluation below then tests only those bodies. Dynamic bodies' fat
    // bounds already cover their previous-to-current motion.
    Aabb sweptBound;
    {
        const auto [a0, b0] = worldSegmentAt(fromCenter);
        const auto [a1, b1] = worldSegmentAt(fromCenter + displacement);
        sweptBound.min = glm::min(glm::min(a0, b0), glm::min(a1, b1));
        sweptBound.max = glm::max(glm::max(a0, b0), glm::max(a1, b1));
        sweptBound = sweptBound.Expanded(capsuleRadius + kSweepQueryEpsilon);
    }
    std::vector<unsigned int> candidates = m_impl->QuerySlots(sweptBound);
    candidates.erase(std::remove_if(candidates.begin(),candidates.end(),[&](unsigned slot){
        if(filter && !m_impl->MatchesQuery(slot,*filter))return true;
        if(!m_impl->bodies[slot].enabled||(m_impl->bodies[slot].sensor&&(!filter||bilateralFilter)))return true;
        const auto& b=m_impl->bodies[slot];
        return bilateralFilter && !CollisionPermitted(collisionLayer,collisionMask,b.collisionLayer,b.collisionMask);
    }),candidates.end());
    auto evaluateAt = [&](float t) {
        const glm::vec3 center = fromCenter + displacement * t;
        const auto [segA, segB] = worldSegmentAt(center);
        const float bodyMotionAlpha = glm::mix(bodyMotionStart, bodyMotionEnd, t);
        return m_impl->ClosestBodyToCapsule(candidates, segA, segB, capsuleRadius, bodyMotionAlpha,
                                            interpolateDynamicBodyMotion);
    };

    // Already touching/overlapping at the very start of the sweep — report
    // an immediate zero-distance hit rather than marching forward, mirroring
    // the "already touching" case a grounded move-and-slide step produces
    // routinely (see docs/ARCHITECTURE.md, "Contact normal correctness and
    // the 'already touching' case," law #13 — this normal is likewise
    // unconditional, never derived from travel direction).
    const ClosestBodyResult startResult = evaluateAt(0.0f);
    if (startResult.bodyIndex >= 0 && startResult.distance <= 0.0f) {
        result.hit = true;
        result.distance = 0.0f;
        result.penetration = -startResult.distance;
        result.normal = startResult.normal;
        result.point=startResult.point;
        result.hitBody = m_impl->MakeHandle(static_cast<unsigned int>(startResult.bodyIndex));
        return result;
    }

    // March forward in substeps looking for the first t where the capsule
    // starts overlapping something, then refine that bracket by bisection.
    // Per-step displacements in this engine are always small (a fraction
    // of a meter — see docs/ARCHITECTURE.md's move-and-slide/ground-probe
    // distances), so a modest fixed substep count plus a short bisection
    // pass gives ample precision without needing closed-form continuous
    // collision detection for every shape pair.
    constexpr int kSubsteps = 24;
    constexpr int kBisectionIterations = 20;
    std::vector<float> divisions{0,1};
    if(interpolateDynamicBodyMotion && bodyMotionEnd>bodyMotionStart && m_impl->stepDuration>0)
        for(auto slot:candidates) for(const auto& segment:m_impl->bodies[slot].motion.Segments()) {
            const float t=(float(segment.end/m_impl->stepDuration)-bodyMotionStart)/(bodyMotionEnd-bodyMotionStart);
            if(t>0 && t<1) divisions.push_back(t);
        }
    std::sort(divisions.begin(),divisions.end());
    divisions.erase(std::unique(divisions.begin(),divisions.end()),divisions.end());
    float previousT = 0.0f;
    for(std::size_t interval=1;interval<divisions.size();++interval)
    for (int step = 1; step <= kSubsteps; ++step) {
        const float t=glm::mix(divisions[interval-1],divisions[interval],float(step)/kSubsteps);
        const ClosestBodyResult stepResult = evaluateAt(t);
        if (stepResult.bodyIndex >= 0 && stepResult.distance <= 0.0f) {
            float lo = previousT;
            float hi = t;
            ClosestBodyResult refined = stepResult;
            for (int iteration = 0; iteration < kBisectionIterations; ++iteration) {
                const float mid = (lo + hi) * 0.5f;
                const ClosestBodyResult midResult = evaluateAt(mid);
                if (midResult.bodyIndex >= 0 && midResult.distance <= 0.0f) {
                    hi = mid;
                    refined = midResult;
                } else {
                    lo = mid;
                }
            }
            result.hit = true;
            result.distance = lo * displacementLength;
            result.normal = refined.normal;
            result.point=refined.point;
            result.hitBody = m_impl->MakeHandle(static_cast<unsigned int>(refined.bodyIndex));
            return result;
        }
        previousT = t;
    }

    return result;  // no hit across the entire displacement
}

bool PhysicsWorld::SetCollisionFilter(BodyHandle handle,unsigned layer,CategoryMask mask){
    auto* b=m_impl->Get(handle);if(!b||layer>=64)return false;
    if(b->collisionLayer==layer&&b->collisionMask==mask)return true;
    m_impl->InvalidateRestoredContinuation(handle.id&Impl::kSlotMask);m_impl->Wake(handle.id&Impl::kSlotMask);
    b->collisionLayer=layer;b->collisionMask=mask;
    const unsigned slot=handle.id&Impl::kSlotMask;
    auto remove=[&](auto& cache){cache.erase(std::remove_if(cache.begin(),cache.end(),[&](const auto& c){return c.key.slotA==slot||c.key.slotB==slot;}),cache.end());};
    remove(m_impl->contactCache);remove(m_impl->pendingCache);remove(m_impl->completedContactObservations);return true;
}
bool PhysicsWorld::GetCollisionFilter(BodyHandle handle,unsigned& layer,CategoryMask& mask)const{
    const auto* b=m_impl->Get(handle);if(!b)return false;layer=b->collisionLayer;mask=b->collisionMask;return true;
}
bool PhysicsWorld::SetBodyTags(BodyHandle handle,CategoryMask tags){auto* b=m_impl->Get(handle);if(!b)return false;b->tags=tags;return true;}
void PhysicsWorld::SetPlayerCollisionFilter(unsigned layer,CategoryMask mask){if(layer<64){m_impl->playerCollisionLayer=layer;m_impl->playerCollisionMask=mask;}}

bool PhysicsWorld::ReadBodyContactSample(BodyHandle handle,std::vector<BodyContactSample>& output,unsigned maximumContacts,unsigned maximumCandidates) const {
    output.clear();auto* body=m_impl?m_impl->Get(handle):nullptr;
    if(!body||!body->enabled||body->sensor||body->queryOnly||maximumContacts==0||maximumContacts>64||maximumCandidates==0||maximumCandidates>128)return false;
    const auto slot=handle.id&Impl::kSlotMask;unsigned count=0;bool overflow=false;
    // Existing broadphase only selects the cache ranges to inspect. A nearby
    // candidate without an authoritative cached solver row is NOT a contact.
    m_impl->tree.Query(m_impl->tree.FatAabb(body->proxy),[&](int proxy){
        const auto other=m_impl->tree.UserData(proxy);if(other==slot)return;
        if(++count>maximumCandidates){overflow=true;return;}
        auto& support=m_impl->bodies[other];if(!support.alive||!m_impl->CanCollide(slot,other)||support.sensor||support.queryOnly)return;
        const auto first=std::min(slot,other),second=std::max(slot,other);
        ContactKey key{first,second,m_impl->bodies[first].generation,m_impl->bodies[second].generation,-1,-1};
        const auto begin=std::lower_bound(m_impl->completedContactObservations.begin(),m_impl->completedContactObservations.end(),key,[](const auto& cached,const auto& target){return cached.key<target;});
        for(auto it=begin;it!=m_impl->completedContactObservations.end()&&it->key.slotA==first&&it->key.slotB==second;++it){
            const auto& cached=*it;if(!cached.key.SameBodies(ContactKey{first,second,key.generationA,key.generationB,cached.key.partA,cached.key.partB})||cached.normalImpulse<=0||cached.observationRevisionA!=m_impl->bodies[first].contactObservationRevision||cached.observationRevisionB!=m_impl->bodies[second].contactObservationRevision)continue;
            if(output.size()>=maximumContacts){overflow=true;break;}
            const auto& a=m_impl->bodies[first];auto point=glm::vec3(glm::dvec3(a.rigidBody.position)+glm::mat3_cast(glm::dquat(a.rigidBody.orientation))*cached.localAnchorA);
            BodyContactSample sample;sample.other=m_impl->MakeHandle(other);sample.point=point;
            sample.normal=slot==first?cached.normal:-cached.normal;sample.normalImpulse=cached.normalImpulse;sample.separation=cached.separation;
            sample.supportVelocity=support.rigidBody.linearVelocity+glm::cross(support.rigidBody.angularVelocity,point-support.rigidBody.position);
            sample.sleeping=body->sleeping&&(support.sleeping||support.rigidBody.IsStatic());output.push_back(sample);
        }
    });
    if(overflow){output.clear();return false;}
    std::stable_sort(output.begin(),output.end(),[](const auto& a,const auto& b){return std::tie(a.other.id,a.point.x,a.point.y,a.point.z)<std::tie(b.other.id,b.point.x,b.point.y,b.point.z);});
    return true;
}
const std::vector<PhysicsWorld::TouchEvent>& PhysicsWorld::LastStepTouchEvents() const {return m_impl->touchEvents;}
bool PhysicsWorld::SetBodySensor(BodyHandle h,bool value){auto* b=m_impl->Get(h);if(!b|| (value&&b->shape.type==ShapeType::TriangleMesh))return false;if(b->sensor!=value)m_impl->Wake(h.id&Impl::kSlotMask);if(b->sensor!=value)m_impl->InvalidateRestoredContinuation(h.id&Impl::kSlotMask);if(b->sensor!=value)++b->contactObservationRevision;b->sensor=value;return true;}
bool PhysicsWorld::IsBodySensor(BodyHandle h) const {auto* b=m_impl->Get(h);return b&&b->sensor;}
bool PhysicsWorld::SetBodyQueriesEnabled(BodyHandle h,bool enabled){auto* body=m_impl->Get(h);if(!body)return false;body->queriesEnabled=enabled;return true;}

bool PhysicsWorld::SetBodyEnabled(BodyHandle h,bool value){auto* b=m_impl->Get(h);if(!b)return false;if(b->enabled==value)return true;m_impl->Wake(h.id&Impl::kSlotMask);m_impl->InvalidateRestoredContinuation(h.id&Impl::kSlotMask);++b->contactObservationRevision;b->enabled=value;
 if(!value&&b->isKinematic){b->kinematic={};b->kinematicActiveDuration=0;b->motion.Clear();b->rigidBody.linearVelocity=b->rigidBody.angularVelocity=glm::vec3(0);b->previousPosition=b->rigidBody.position;b->previousOrientation=b->rigidBody.orientation;}
 for(auto& j:m_impl->joints)if(j.state.settings.bodyA.id==h.id||j.state.settings.bodyB.id==h.id)j.warm.fill(0);
 return true;}
bool PhysicsWorld::IsBodyEnabled(BodyHandle h) const {auto* b=m_impl->Get(h);return b&&b->enabled;}

void PhysicsWorld::ClearTouchHistory(){m_impl->previousTouches.clear();m_impl->stepTouches.clear();m_impl->preStepQueryTouches.clear();m_impl->collectingPreStepQueries=false;m_impl->queryTouchesPending=false;m_impl->touchEvents.clear();}

PhysicsCastHit PhysicsWorld::Cast(const Shape& shape,const BodyTransform& pose,const glm::vec3& direction,float maximum,
    const PhysicsQueryFilter& filter,PhysicsCastStats* stats) const {
    JUDAS_PROFILE_SCOPE("Physics shape query");
    if(stats)*stats={};
    auto finite=[](glm::vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);};
    double q2=glm::dot(glm::dvec4(pose.rotation.x,pose.rotation.y,pose.rotation.z,pose.rotation.w),
                        glm::dvec4(pose.rotation.x,pose.rotation.y,pose.rotation.z,pose.rotation.w));
    double d2=glm::dot(glm::dvec3(direction),glm::dvec3(direction));
    if(!finite(pose.position)||!finite(direction)||!std::isfinite(maximum)||maximum<0||d2<=0||!std::isfinite(q2)||q2<=0)
        throw std::invalid_argument("cast requires finite pose, nonzero orientation/direction and nonnegative distance");
    if(!finite(shape.halfExtents)||!std::isfinite(shape.radius)||!std::isfinite(shape.halfHeight)||shape.radius<0||shape.halfHeight<0||
       (shape.type==ShapeType::Box&&(shape.halfExtents.x<=0||shape.halfExtents.y<=0||shape.halfExtents.z<=0)))
        throw std::invalid_argument("invalid cast dimensions");
    PhysicsCastHit result;if(!m_impl)return result;
    const glm::vec3 unit=glm::vec3(glm::dvec3(direction)/std::sqrt(d2));
    auto bound=ShapeAabb(shape,pose.position,pose.rotation);
    auto end=ShapeAabb(shape,pose.position+unit*maximum,pose.rotation);
    Aabb swept{glm::min(bound.min,end.min),glm::max(bound.max,end.max)};
    auto candidates=m_impl->QuerySlots(swept.Expanded(kSweepQueryEpsilon));
    if(stats)stats->broadphaseCandidates=static_cast<unsigned>(candidates.size());
    double nearest=maximum;
    for(auto slot:candidates){if(!m_impl->MatchesQuery(slot,filter))continue;if(stats)++stats->filteredCandidates;
        const auto& body=m_impl->bodies[slot];
        for(int part=0;part<PrimitiveCount(body.shape);++part){if(stats)++stats->primitivesTested;
            const auto primitive=PrimitiveAt(body.shape,body.rigidBody,part);
            const auto hit=CastAgainstPrimitive(shape,pose,unit,nearest,primitive);
            const auto handle=m_impl->MakeHandle(slot);
            if(hit.hit&&(!result.hit||hit.distance<nearest||(hit.distance==nearest&&handle.id<result.body.id))){
                nearest=hit.distance;result.hit=true;result.initialOverlap=hit.initialOverlap;result.body=handle;
                result.point=hit.point;result.normal=hit.normal;result.distance=static_cast<float>(hit.distance);
                result.fraction=maximum>0?result.distance/maximum:0;result.primitiveIndex=part;result.shape=primitive.shape.type;result.childKey=primitive.childKey;result.feature=hit.feature;
            }
        }
    }
    return result;
}
PhysicsClosestPoint PhysicsWorld::ClosestPoint(const glm::vec3& point,float maximum,const PhysicsQueryFilter& filter) const {
    for(int k=0;k<3;++k)if(!std::isfinite(point[k]))throw std::invalid_argument("closestPoint requires finite point");
    if(!std::isfinite(maximum)||maximum<0)throw std::invalid_argument("closestPoint requires finite nonnegative maximum radius");
    PhysicsClosestPoint out;if(!m_impl)return out;double nearest=maximum;
    for(auto slot:m_impl->QuerySlots({point-glm::vec3(maximum),point+glm::vec3(maximum)})){
        if(!m_impl->MatchesQuery(slot,filter))continue;
        const auto& body=m_impl->bodies[slot];
        for(int part=0;part<PrimitiveCount(body.shape);++part){auto primitive=PrimitiveAt(body.shape,body.rigidBody,part);auto result=PointGeometry(glm::dvec3(point),primitive,nearest);if(!result.valid)continue;
            auto handle=m_impl->MakeHandle(slot);if(!out.hit||result.gap<nearest||(result.gap==nearest&&std::tie(handle.id,part)<std::tie(out.body.id,out.primitiveIndex))){nearest=result.gap;out.hit=true;out.body=handle;out.point=glm::vec3(result.point);out.normal=glm::vec3(result.normal);out.distance=nearest;out.contains=result.contains;out.normalUnique=result.normalUnique;out.containmentKnown=primitive.shape.type!=ShapeType::TriangleMesh;out.primitiveIndex=part;out.childKey=primitive.childKey;out.feature=result.feature;out.shape=primitive.shape.type;}
        }
    }return out;
}
PhysicsCastHit PhysicsWorld::Raycast(const glm::vec3& o,const glm::vec3& d,float m,const PhysicsQueryFilter& f,PhysicsCastStats* s)const{return Cast(Shape::Sphere(0),{o,{1,0,0,0}},d,m,f,s);}
PhysicsCastHit PhysicsWorld::SphereCast(const glm::vec3& o,float r,const glm::vec3& d,float m,const PhysicsQueryFilter& f,PhysicsCastStats* s)const{return Cast(Shape::Sphere(r),{o,{1,0,0,0}},d,m,f,s);}
PhysicsCastHit PhysicsWorld::CapsuleCast(const BodyTransform& p,float r,float h,const glm::vec3& d,float m,const PhysicsQueryFilter& f,PhysicsCastStats* s)const{return Cast(Shape::Capsule(r,h),p,d,m,f,s);}
PhysicsCastHit PhysicsWorld::BoxCast(const BodyTransform& p,const glm::vec3& h,const glm::vec3& d,float m,const PhysicsQueryFilter& f,PhysicsCastStats* s)const{return Cast(Shape::Box(h),p,d,m,f,s);}

JointHandle PhysicsWorld::CreateJoint(const JointSettings& settings) {
    if(!m_impl||!ValidJointSettings(settings))return {};
    auto* a=m_impl->Get(settings.bodyA);auto* b=m_impl->Get(settings.bodyB);
    if(!a||(settings.bodyB.IsValid()&&!b)||(b&&a==b)||(a->rigidBody.IsStatic()&&(!b||b->rigidBody.IsStatic())))return {};
    static std::atomic<std::uint64_t> next{1};JointHandle handle{next.fetch_add(1)};
    Wake(settings.bodyA);Wake(settings.bodyB);
    JointState state;state.settings=settings;
    m_impl->joints.push_back({handle,state,{}});return handle;
}
bool PhysicsWorld::DestroyJoint(JointHandle handle){JointState old;if(GetJoint(handle,old)){Wake(old.settings.bodyA);Wake(old.settings.bodyB);}if(!m_impl)return false;auto& joints=m_impl->joints;auto it=std::find_if(joints.begin(),joints.end(),[&](const auto& j){return j.handle.id==handle.id;});if(it==joints.end())return false;joints.erase(it);return true;}
bool PhysicsWorld::GetJoint(JointHandle handle,JointState& state)const{if(!m_impl)return false;for(auto& joint:m_impl->joints)if(joint.handle.id==handle.id){if(!m_impl->Get(joint.state.settings.bodyA)||(joint.state.settings.bodyB.IsValid()&&!m_impl->Get(joint.state.settings.bodyB)))return false;state=joint.state;state.active=m_impl->JointActive(joint);return true;}return false;}
bool PhysicsWorld::SetJointAngularDrive(JointHandle handle,const JointAngularDrive& request) {
    if(!m_impl)return false;
    if(!std::isfinite(glm::dot(request.relativeAngularVelocity,request.relativeAngularVelocity))||glm::length(request.relativeAngularVelocity)>1000||!std::isfinite(glm::dot(request.target,request.target))||glm::dot(request.target,request.target)<1e-12f||
       !std::isfinite(request.stiffness)||request.stiffness<0||request.stiffness>10000||
       !std::isfinite(request.damping)||request.damping<0||request.damping>1000||
       !std::isfinite(request.maxTorque)||request.maxTorque<0||request.maxTorque>10000)return false;
    for(auto& joint:m_impl->joints)if(joint.handle.id==handle.id){
        const auto& settings=joint.state.settings;
        if(request.enabled&&(!m_impl->Get(settings.bodyB)||(settings.type!=JointType::Ball&&settings.type!=JointType::Hinge)||settings.motor||settings.spring))return false;
        auto target=glm::normalize(request.target);auto& previous=joint.state.angularDrive;
        bool changed=previous.enabled!=request.enabled||std::abs(glm::dot(previous.target,target))<1-1e-7f||
            previous.relativeAngularVelocity!=request.relativeAngularVelocity||previous.stiffness!=request.stiffness||previous.damping!=request.damping||previous.maxTorque!=request.maxTorque;
        if(!changed)return true;
        auto candidate=request;candidate.target=target;candidate.impulses=previous.impulses;
        if(previous.enabled!=request.enabled)candidate.impulses={0,0,0};
        previous=candidate;
        m_impl->Wake(settings.bodyA.id&Impl::kSlotMask);if(m_impl->Get(settings.bodyB))m_impl->Wake(settings.bodyB.id&Impl::kSlotMask);
        return true;
    }return false;
}
bool PhysicsWorld::SetJoint(JointHandle handle,const JointSettings& settings){JointState previous;if(!GetJoint(handle,previous)||!ValidJointSettings(settings)||settings.bodyA.id!=previous.settings.bodyA.id||settings.bodyB.id!=previous.settings.bodyB.id)return false;for(auto& joint:m_impl->joints)if(joint.handle.id==handle.id){if(JointSettingsEqual(joint.state.settings,settings))return true;m_impl->Wake(settings.bodyA.id&Impl::kSlotMask);if(m_impl->Get(settings.bodyB))m_impl->Wake(settings.bodyB.id&Impl::kSlotMask);joint.state.settings=settings;joint.warm.fill(0);if(joint.restoredContinuationDt>0){joint.state.angularDrive.impulses={0,0,0};joint.restoredContinuationDt=0;}return true;}return false;}

bool PhysicsWorld::SetPairCollisionEnabled(BodyHandle a,BodyHandle b,bool enabled){
    if(!m_impl||a.id==b.id||!m_impl->Get(a)||!m_impl->Get(b))return false;
    auto pair=std::minmax(a.id,b.id);if((m_impl->suppressedPairs.count(pair)==0)==enabled)return true;Wake(a);Wake(b);m_impl->InvalidateRestoredContinuation(a.id&Impl::kSlotMask);m_impl->InvalidateRestoredContinuation(b.id&Impl::kSlotMask);++m_impl->Get(a)->contactObservationRevision;++m_impl->Get(b)->contactObservationRevision;if(enabled)m_impl->suppressedPairs.erase(pair);else m_impl->suppressedPairs.insert(pair);return true;
}

void PhysicsWorld::PersistTouches(SaveArchive& a,const std::function<uint64_t(BodyHandle)>& identity,const std::function<BodyHandle(uint64_t)>& resolve,const std::function<bool(BodyHandle)>& include){
 std::vector<TouchEvent> live;if(!a.reading)for(const auto& [_,event]:m_impl->previousTouches)if(m_impl->Get(event.a)&&m_impl->Get(event.b)&&(!include||(include(event.a)&&include(event.b))))live.push_back(event);
 uint32_t count=uint32_t(live.size());a(count);a.Require(count<=8192,"saved contact-pair limit");if(a.reading)ClearTouchHistory();
 for(uint32_t i=0;i<count;++i){uint64_t first=0,second=0;TouchEvent event;if(!a.reading){event=live.at(i);first=identity(event.a);second=identity(event.b);}
  a.Require(a.reading||(first&&second),"saved contact has unowned required body");
  a(first,second,event.sensor,event.point,event.normal,event.relativeVelocity,event.impulseAvailable,event.normalImpulse);
  if(a.reading){event.a=resolve(first);event.b=resolve(second);a.Require(event.a.IsValid()&&event.b.IsValid()&&event.a.id!=event.b.id,"saved contact body unavailable");if(event.a.id>event.b.id){std::swap(event.a,event.b);event.normal=-event.normal;event.relativeVelocity=-event.relativeVelocity;}event.phase=TouchPhase::Stay;a.Require(m_impl->previousTouches.emplace(std::make_pair(event.a.id,event.b.id),event).second,"duplicate saved contact pair");}
 }
}

void PhysicsWorld::PersistBodyForces(SaveArchive& archive,BodyHandle handle){
 auto* body=m_impl->Get(handle);archive.Require(body!=nullptr,"saved force body unavailable");archive(body->rigidBody.forceAccumulator,body->rigidBody.torqueAccumulator);
}

void PhysicsWorld::PersistKinematic(SaveArchive& archive,BodyHandle handle,glm::dvec3 capturedOriginDelta) {
 auto* body=m_impl->Get(handle);archive.Require(body&&body->isKinematic,"saved kinematic body unavailable");
 auto state=body->kinematic;auto linear=body->rigidBody.linearVelocity,angular=body->rigidBody.angularVelocity;
 archive(state.control,state.target.position,state.target.rotation,state.linearVelocity,state.angularVelocity,
         state.remainingSeconds,state.targetNextStep,linear,angular);
 if(archive.reading)state.target.position=glm::vec3(glm::dvec3(state.target.position)-capturedOriginDelta);
 archive.Require(state.control==KinematicControl::Stopped||state.control==KinematicControl::Target||state.control==KinematicControl::Velocity,"invalid kinematic control");
 archive.Require(UsableKinematicPose(state.target)&&state.remainingSeconds>=0&&state.remainingSeconds<=60,
                 "invalid kinematic target state");
 archive.Require(state.control==KinematicControl::Target||(!state.targetNextStep&&state.remainingSeconds==0),"inconsistent kinematic interval");
 archive.Require(UsableVelocity(state.linearVelocity)&&UsableVelocity(state.angularVelocity)&&UsableVelocity(linear)&&UsableVelocity(angular),"unusable saved kinematic velocity");
 if(state.control==KinematicControl::Target){const auto delta=state.target.position+state.target.rotation*body->shape.pivotOffset-body->rigidBody.position;
     archive.Require(UsableVelocity(delta)&&(state.targetNextStep||state.remainingSeconds==0||
         (UsableVelocity(delta/state.remainingSeconds)&&std::isfinite(glm::pi<float>()/state.remainingSeconds))),"unusable saved kinematic target trajectory");}
 if(archive.reading){body->kinematic=state;body->rigidBody.linearVelocity=linear;body->rigidBody.angularVelocity=angular;
     body->kinematicActiveDuration=0;body->motion.Clear();body->previousPosition=body->rigidBody.position;body->previousOrientation=body->rigidBody.orientation;
     m_impl->InvalidateImpactPose(handle.id&Impl::kSlotMask);m_impl->RefreshProxy(*body);}
}

bool PhysicsWorld::SetMassDistribution(BodyHandle h,float mass,const glm::mat3& inertia){auto* b=m_impl->Get(h);if(!b||!b->isDynamic||!std::isfinite(mass)||mass<=0)return false;for(int i=0;i<3;++i)for(int j=0;j<3;++j)if(!std::isfinite(inertia[i][j])||std::abs(inertia[i][j]-inertia[j][i])>1e-5f)return false;if(inertia[0][0]<=0||inertia[0][0]*inertia[1][1]-inertia[0][1]*inertia[0][1]<=0||glm::determinant(inertia)<=0)return false;m_impl->InvalidateRestoredContinuation(h.id&Impl::kSlotMask);Wake(h);b->rigidBody.inverseMass=1/mass;b->rigidBody.inverseInertiaLocal=glm::inverse(inertia);return true;}

void PhysicsWorld::PersistJointContinuation(SaveArchive& a,JointHandle handle) {
    auto found=std::find_if(m_impl->joints.begin(),m_impl->joints.end(),
        [&](const auto& joint){return joint.handle.id==handle.id;});
    a.Require(found!=m_impl->joints.end(),"stale joint continuation handle");
    auto& joint=*found;auto context=m_impl->ContinuationJointContext(joint);
    const auto expectedContext=context;uint32_t version=1;
    float dt=m_impl->completedObservationsReady?m_impl->completedSolverDt:0;
    auto warm=joint.warm;auto drive=joint.state.angularDrive;
    a(version,context,dt);a.Require(version==1,"newer joint continuation format");
    a.Require(context==expectedContext,"joint continuation physical context differs");
    a.Require(dt>=0&&dt<=.1f,"invalid joint continuation interval");
    for(auto& value:warm)a(value);
    a(drive.enabled,drive.target,drive.relativeAngularVelocity,drive.stiffness,
      drive.damping,drive.maxTorque,drive.impulses);
    a.Require(std::abs(glm::dot(drive.target,drive.target)-1.f)<1e-4f,"nonunit completed angular-drive target");
    if(dt==0)a.Require(std::all_of(warm.begin(),warm.end(),[](float x){return x==0;})&&
        drive.impulses==glm::vec3(0),"joint history has no completed interval");
    if(a.reading){
        a.Require(SetJointAngularDrive(handle,drive),"invalid restored angular drive");
        // Preserve the actual completed producer command, including its target
        // deadband, rather than recomputing a slightly different quaternion.
        joint.state.angularDrive=drive;joint.warm=warm;
        joint.restoredContinuationDt=dt;m_impl->completedSolverDt=dt;
    }
}

bool PhysicsWorld::HasRestoredCompletedContactObservations(float dt) const {
    return m_impl&&std::isfinite(dt)&&dt>0&&m_impl->restoredCompletedObservations&&
        m_impl->completedObservationsReady&&m_impl->completedObservationEpoch!=0&&
        m_impl->completedObservationDt==dt;
}

void PhysicsWorld::PersistCompletedContactObservations(SaveArchive& a,
    const std::function<uint64_t(BodyHandle)>& identity,
    const std::function<BodyHandle(uint64_t)>& resolve,
    const std::function<bool(BodyHandle)>& include) {
    auto& w=*m_impl;uint32_t version=1;auto epoch=w.completedObservationEpoch;
    auto dt=w.completedObservationDt;bool ready=w.completedObservationsReady;
    auto eligible=[&](const CachedContact& c){
        auto* first=w.Get(w.MakeHandle(c.key.slotA));auto* second=w.Get(w.MakeHandle(c.key.slotB));
        return first&&second&&first->generation==c.key.generationA&&second->generation==c.key.generationB&&
            first->enabled&&second->enabled&&!first->sensor&&!second->sensor&&!first->queryOnly&&!second->queryOnly&&
            w.CanCollide(c.key.slotA,c.key.slotB)&&c.normalImpulse>0&&
            c.observationRevisionA==first->contactObservationRevision&&c.observationRevisionB==second->contactObservationRevision;
    };
    // Omitting a readable transient contact cannot become a fictional complete
    // (possibly empty) publication. The normal unavailable-sample policy then
    // remains authoritative for this intentionally incomplete world snapshot.
    if(!a.reading&&ready&&include)for(const auto& c:w.completedContactObservations)if(eligible(c)&&
        (!include(w.MakeHandle(c.key.slotA))||!include(w.MakeHandle(c.key.slotB)))){
        ready=false;epoch=0;dt=0;break;
    }
    a(version,ready,epoch,dt);a.Require(version==1,"newer completed-observation format");
    a.Require((!ready&&epoch==0&&dt==0)||(ready&&epoch!=0&&dt>0&&dt<=.1f),
        "invalid completed-observation publication");
    std::vector<const CachedContact*> live;
    if(!a.reading&&ready)for(const auto& c:w.completedContactObservations)if(eligible(c))live.push_back(&c);
    uint32_t count=uint32_t(live.size());a(count);a.Require(count<=65536,"saved completed-observation limit");
    a.Require(ready||count==0,"unpublished completed-observation rows");
    std::vector<CachedContact> restored;restored.reserve(count);
    using Signature=std::tuple<unsigned,unsigned,int,int,double,double,double,float,float,float>;
    std::set<Signature> seen;
    for(uint32_t i=0;i<count;++i){
        uint64_t first=0,second=0;int partA=0,partB=0;
        glm::dvec3 anchorA{0},anchorB{0};glm::vec3 normal{0};float impulse=0,separation=0;
        std::string contextA,contextB;
        if(!a.reading){const auto& c=*live[i];const auto& bodyA=w.bodies[c.key.slotA];const auto& bodyB=w.bodies[c.key.slotB];
            first=identity(w.MakeHandle(c.key.slotA));second=identity(w.MakeHandle(c.key.slotB));
            partA=c.key.partA;partB=c.key.partB;anchorA=c.localAnchorA;normal=c.normal;
            impulse=c.normalImpulse;separation=c.separation;
            const auto point=glm::dvec3(bodyA.rigidBody.position)+glm::mat3_cast(glm::dquat(bodyA.rigidBody.orientation))*anchorA;
            // The existing observation has only an A anchor. Its corresponding
            // B anchor is derived from that SAME point for slot-order remapping.
            anchorB=glm::transpose(glm::mat3_cast(glm::dquat(bodyB.rigidBody.orientation)))*(point-glm::dvec3(bodyB.rigidBody.position));
            contextA=w.ContinuationBodyContext(bodyA);contextB=w.ContinuationBodyContext(bodyB);
        }
        a(first,second,partA,partB,anchorA,anchorB,normal,impulse,separation,contextA,contextB);
        a.Require(first&&second&&first!=second&&impulse>0&&glm::dot(normal,normal)>.99f&&glm::dot(normal,normal)<1.01f,
            "invalid completed-observation row");
        if(a.reading){auto ha=resolve(first),hb=resolve(second);auto* bodyA=w.Get(ha);auto* bodyB=w.Get(hb);
            a.Require(bodyA&&bodyB&&bodyA->enabled&&bodyB->enabled&&!bodyA->sensor&&!bodyB->sensor&&!bodyA->queryOnly&&!bodyB->queryOnly,
                "completed-observation body unavailable");
            auto sa=ha.id&Impl::kSlotMask,sb=hb.id&Impl::kSlotMask;
            a.Require(contextA==w.ContinuationBodyContext(*bodyA)&&contextB==w.ContinuationBodyContext(*bodyB),
                "completed-observation physical context differs");
            a.Require(w.CanCollide(sa,sb)&&partA>=0&&partA<PrimitiveCount(bodyA->shape)&&partB>=0&&partB<PrimitiveCount(bodyB->shape),
                "completed-observation filter/primitive differs");
            if(sa>sb){std::swap(sa,sb);std::swap(bodyA,bodyB);std::swap(partA,partB);std::swap(anchorA,anchorB);normal=-normal;}
            a.Require(seen.insert({sa,sb,partA,partB,anchorA.x,anchorA.y,anchorA.z,normal.x,normal.y,normal.z}).second,
                "duplicate completed-observation row");
            restored.push_back({ContactKey{sa,sb,bodyA->generation,bodyB->generation,partA,partB},anchorA,normal,impulse,glm::vec3(0),
                separation,bodyA->contactObservationRevision,bodyB->contactObservationRevision});
        }
    }
    if(a.reading){std::stable_sort(restored.begin(),restored.end(),[](const auto& x,const auto& y){return x.key<y.key;});
        w.completedContactObservations=std::move(restored);w.completedObservationEpoch=epoch;
        w.completedObservationDt=dt;w.completedObservationsReady=ready;w.restoredCompletedObservations=ready;
    }
}

bool PhysicsWorld::ConfigureJointMaterial(JointHandle h,const JointMaterial& material){
 if(!m_impl||!ValidJointMaterial(material))return false;
 for(auto& j:m_impl->joints)if(j.handle.id==h.id){if(j.state.settings.type!=JointType::Fixed||j.state.angularDrive.enabled)return false;
  j.state.constitutive={};j.state.constitutive.material=material;j.warm.fill(0);Wake(j.state.settings.bodyA);if(j.state.settings.bodyB.IsValid())Wake(j.state.settings.bodyB);return true;}return false;
}
void PhysicsWorld::PersistJointMaterial(SaveArchive& a,JointHandle h){
 a.Require(m_impl!=nullptr,"material history physics unavailable");
 for(auto& j:m_impl->joints)if(j.handle.id==h.id){auto& c=j.state.constitutive;
  a.Require(c.material.enabled,"material history requires a material connection");
  a(c.translation,c.rotation,c.translationTravel,c.rotationTravel,c.plasticWork,c.failed);
  for(auto v:{c.translation,c.rotation,c.translationTravel,c.rotationTravel})for(int k=0;k<3;++k)a.Require(std::isfinite(v[k]),"nonfinite material connection history");
  a.Require(glm::all(glm::greaterThanEqual(c.translationTravel,glm::vec3(0)))&&glm::all(glm::greaterThanEqual(c.rotationTravel,glm::vec3(0)))&&std::isfinite(c.plasticWork)&&c.plasticWork>=0,"invalid material connection history");return;
 }throw std::runtime_error("stale material joint history");
}

void PhysicsWorld::PersistJointSolverState(SaveArchive& a,JointHandle h){for(auto& j:m_impl->joints)if(j.handle.id==h.id){for(auto& x:j.warm){a(x);a.Require(std::isfinite(x),"nonfinite fracture joint history");}a(j.state.reactionImpulse,j.state.reactionAngularImpulse);for(auto v:{j.state.reactionImpulse,j.state.reactionAngularImpulse})for(int k=0;k<3;++k)a.Require(std::isfinite(v[k]),"nonfinite fracture reaction history");return;}throw std::runtime_error("stale fracture solver history");}

BodyHandle PhysicsWorld::CreateQueryCapsule(float radius,float halfHeight,const BodyTransform& pose){
 auto h=m_impl->AddBody(Shape::Capsule(radius,halfHeight),pose.position,pose.rotation,false,0,0,0);m_impl->Get(h)->queryOnly=true;return h;
}
void PhysicsWorld::BeginPreStepQueryContacts(){m_impl->preStepQueryTouches.clear();m_impl->collectingPreStepQueries=true;}
void PhysicsWorld::ObserveQueryContact(BodyHandle h,const ShapeSweepHit& hit,const glm::vec3& velocity){
 auto* a=m_impl->Get(h);auto* b=m_impl->Get(hit.hitBody);if(!a||!b||!a->enabled||!a->queryOnly||!m_impl->CanCollide(h.id&Impl::kSlotMask,hit.hitBody.id&Impl::kSlotMask))return;
 a->rigidBody.linearVelocity=velocity;Contact c;c.point=hit.point;c.normal=hit.normal;
 m_impl->Observe(h.id&Impl::kSlotMask,hit.hitBody.id&Impl::kSlotMask,c,0,m_impl->collectingPreStepQueries);
}
void PhysicsWorld::FinishQueryTouches(){if(!m_impl->collectingPreStepQueries&&m_impl->queryTouchesPending){m_impl->FinishTouches();m_impl->queryTouchesPending=false;}}

bool PhysicsWorld::IsSleeping(BodyHandle h)const{auto* b=m_impl?m_impl->Get(h):nullptr;return b&&b->sleeping;}
void PhysicsWorld::Wake(BodyHandle h){if(m_impl&&m_impl->Get(h))m_impl->Wake(h.id&Impl::kSlotMask);}
void PhysicsWorld::SetSleepingEnabled(bool enabled){m_impl->sleepingEnabled=enabled;if(!enabled)for(auto i:m_impl->aliveSlots)m_impl->Wake(i);}
void PhysicsWorld::PersistSleep(SaveArchive& a,BodyHandle h){auto* b=m_impl->Get(h);a.Require(b,"missing sleep body");a(b->sleeping,b->quietSeconds,b->lastAcceleration,b->deferredAcceleration);a.Require(std::isfinite(b->quietSeconds)&&b->quietSeconds>=0&&std::isfinite(b->lastAcceleration.x)&&std::isfinite(b->lastAcceleration.y)&&std::isfinite(b->lastAcceleration.z),"invalid settling state");}

bool PhysicsWorld::GetPhysicalMaterial(BodyHandle h,std::string& id,float& friction,float& restitution)const{auto* b=m_impl?m_impl->Get(h):nullptr;if(!b)return false;id=b->physicalMaterial;friction=b->friction;restitution=b->restitution;return true;}
bool PhysicsWorld::SetPhysicalMaterial(BodyHandle h,const std::string& id,float friction,float restitution){auto* b=m_impl?m_impl->Get(h):nullptr;if(!b||!std::isfinite(friction)||friction<0||!std::isfinite(restitution)||restitution<0||restitution>1)return false;if(b->physicalMaterial==id&&b->friction==friction&&b->restitution==restitution)return true;m_impl->InvalidateRestoredContinuation(h.id&Impl::kSlotMask);Wake(h);b->physicalMaterial=id;b->friction=friction;b->restitution=restitution;const auto slot=h.id&Impl::kSlotMask;auto remove=[&](auto& cache){cache.erase(std::remove_if(cache.begin(),cache.end(),[&](const auto& c){return c.key.slotA==slot||c.key.slotB==slot;}),cache.end());};remove(m_impl->contactCache);remove(m_impl->pendingCache);remove(m_impl->completedContactObservations);return true;}

void PhysicsWorld::ShiftOrigin(glm::dvec3 delta) {
 if(!OriginLimits::ValidTranslation(delta))throw std::invalid_argument("invalid origin translation");
 auto& w=*m_impl;if(w.stepping||w.coupledStep)throw std::logic_error("origin translation requires completed fixed boundary");
 const auto shift=[&](glm::vec3& p){p=glm::vec3(glm::dvec3(p)-delta);};
 for(auto slot:w.aliveSlots){auto& b=w.bodies[slot];shift(b.rigidBody.position);shift(b.previousPosition);shift(b.kinematic.target.position);b.motion.ShiftOrigin(delta);b.currentBound.valid=b.previousBound.valid=false;w.InvalidateImpactPose(slot);}
 for(auto& j:w.joints)if(!j.state.settings.bodyB.IsValid())shift(j.state.settings.anchorB);
 for(auto& c:w.lastStepContacts)shift(c.point);
 for(auto* events:{&w.previousTouches,&w.stepTouches,&w.preStepQueryTouches})for(auto& entry:*events)shift(entry.second.point);
 for(auto& e:w.touchEvents)shift(e.point);
 w.tree.ShiftOrigin(delta);
}
