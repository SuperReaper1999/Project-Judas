#include "StructuralContactQP.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>

namespace {
bool ContactLawScales(const StructuralContactLawInput& input,double& rootN,double& rootT,
    double& a,double& b,std::array<double,2>& candidate,double& radius,double& length,std::string& error){
    error.clear();
    for(double value:input.impulse)if(!std::isfinite(value)){error="nonfinite structural contact impulse";return false;}
    for(double value:input.kinematics)if(!std::isfinite(value)){error="nonfinite structural contact kinematics";return false;}
    if(!std::isfinite(input.normalMobility)||!(input.normalMobility>0)||!std::isfinite(input.tangentMobility)||!(input.tangentMobility>0)||!std::isfinite(input.friction)||input.friction<0){error="invalid structural contact law mobility or friction";return false;}
    rootN=std::sqrt(input.normalMobility);rootT=std::sqrt(input.tangentMobility);
    a=input.impulse[0]*rootN;b=input.kinematics[0]/rootN;
    candidate={input.impulse[1]-input.kinematics[1]/input.tangentMobility,input.impulse[2]-input.kinematics[2]/input.tangentMobility};
    radius=input.friction*std::max(0.,input.impulse[0]);length=std::hypot(candidate[0],candidate[1]);
    if(!std::isfinite(a)||!std::isfinite(b)||!std::isfinite(length)||!std::isfinite(radius)){error="nonfinite scaled structural contact law";return false;}
    return true;
}
}
bool EvaluateStructuralContactLaw(const StructuralContactLawInput& input,StructuralContactLawResult& result,std::string& error){
    result={};double rootN,rootT,a,b,radius,length;std::array<double,2> candidate;
    if(!ContactLawScales(input,rootN,rootT,a,b,candidate,radius,length,error))return false;
    const double normalLength=std::hypot(a,b);result.residual[0]=normalLength-a-b;
    result.impulseDerivative[0]=rootN*(normalLength>0?a/normalLength-1:-1);
    result.kinematicDerivative[0]=(normalLength>0?b/normalLength-1:-1)/rootN;
    std::array<double,2> projected{},radiusDerivative{};double projectionDerivative[2][2]={{0,0},{0,0}};
    if(length<radius){projected=candidate;projectionDerivative[0][0]=projectionDerivative[1][1]=1;}
    else if(length>0){
        const std::array<double,2> unit{candidate[0]/length,candidate[1]/length};const double ratio=radius/length;
        for(unsigned i=0;i<2;++i){projected[i]=radius*unit[i];radiusDerivative[i]=unit[i];for(unsigned j=0;j<2;++j)projectionDerivative[i][j]=ratio*((i==j?1.:0.)-unit[i]*unit[j]);}
    }
    // At radius=length=0 this selects the exterior, zero-radius B-derivative
    // approached from negative pressure. Exact directional behavior below
    // still permits a newly positive pressure to create its real friction disk.
    const double dr=input.impulse[0]>=0?input.friction:0;
    for(unsigned i=0;i<2;++i){const unsigned row=i+1;result.residual[row]=rootT*(input.impulse[row]-projected[i]);
        result.impulseDerivative[row*3]=-rootT*radiusDerivative[i]*dr;
        for(unsigned j=0;j<2;++j){result.impulseDerivative[row*3+j+1]=rootT*((i==j?1.:0.)-projectionDerivative[i][j]);result.kinematicDerivative[row*3+j+1]=projectionDerivative[i][j]/rootT;}}
    for(double value:result.residual)if(!std::isfinite(value)){error="nonfinite structural contact residual";return false;}
    return true;
}
bool StructuralContactLawConverged(const StructuralContactLawInput& input,double maximumPressure,double normalArithmeticError,double tangentArithmeticError,std::string& error){
    StructuralContactLawResult law;
    if(!EvaluateStructuralContactLaw(input,law,error))return false;
    if(!std::isfinite(maximumPressure)||maximumPressure<0||!std::isfinite(normalArithmeticError)||normalArithmeticError<0||!std::isfinite(tangentArithmeticError)||tangentArithmeticError<0){error="invalid structural contact arithmetic certificate";return false;}
    constexpr double rootFloor=1e-11;const double rootN=std::sqrt(input.normalMobility);
    const double pressureFloor=64*std::numeric_limits<double>::epsilon()*maximumPressure+rootFloor/rootN;
    if(input.impulse[0]<-pressureFloor){error="structural contact pressure exceeds its matched weighted root floor";return false;}
    if(std::abs(law.residual[0])>rootFloor+normalArithmeticError){error="structural contact FB residual exceeds its weighted root certificate";return false;}
    if(std::hypot(law.residual[1],law.residual[2])>rootFloor+tangentArithmeticError){error="structural contact Coulomb residual exceeds its weighted root certificate";return false;}
    error.clear();return true;
}

bool StructuralContactLawDirectionalDerivative(const StructuralContactLawInput& input,const std::array<double,3>& impulseDirection,const std::array<double,3>& kinematicDirection,std::array<double,3>& derivative,std::string& error){
    derivative={};double rootN,rootT,a,b,radius,length;std::array<double,2> candidate;
    if(!ContactLawScales(input,rootN,rootT,a,b,candidate,radius,length,error))return false;
    for(double value:impulseDirection)if(!std::isfinite(value)){error="nonfinite structural contact impulse direction";return false;}
    for(double value:kinematicDirection)if(!std::isfinite(value)){error="nonfinite structural contact kinematic direction";return false;}
    const double da=impulseDirection[0]*rootN,db=kinematicDirection[0]/rootN,normalLength=std::hypot(a,b);
    derivative[0]=(normalLength>0?(a/normalLength)*da+(b/normalLength)*db:std::hypot(da,db))-da-db;
    const double dr=input.friction*(input.impulse[0]>0?impulseDirection[0]:input.impulse[0]==0?std::max(0.,impulseDirection[0]):0.);
    const std::array<double,2> dc{impulseDirection[1]-kinematicDirection[1]/input.tangentMobility,impulseDirection[2]-kinematicDirection[2]/input.tangentMobility};
    std::array<double,2> dp{};
    if(length<radius)dp=dc;
    else if(length>0){
        const std::array<double,2> unit{candidate[0]/length,candidate[1]/length};const double radial=unit[0]*dc[0]+unit[1]*dc[1];
        if(length==radius){const double exterior=std::max(0.,radial-dr);for(unsigned i=0;i<2;++i)dp[i]=dc[i]-unit[i]*exterior;}
        else for(unsigned i=0;i<2;++i)dp[i]=unit[i]*dr+(radius/length)*(dc[i]-unit[i]*radial);
    }else{
        // Projection is positively homogeneous at its joint zero. A new
        // direction is clipped to its actual directional pressure radius,
        // not a chosen universal normal or an invented positive capacity.
        const double directionLength=std::hypot(dc[0],dc[1]);const double factor=directionLength>dr&&directionLength>0?dr/directionLength:1;
        for(unsigned i=0;i<2;++i)dp[i]=dc[i]*factor;
    }
    for(unsigned i=0;i<2;++i)derivative[i+1]=rootT*(impulseDirection[i+1]-dp[i]);
    for(double value:derivative)if(!std::isfinite(value)){error="nonfinite structural contact directional derivative";return false;}
    return true;
}

bool SolveStructuralNormalQP(const std::vector<double>& gram,const std::vector<double>& gap,
    unsigned maximumRank,const std::vector<double>& warm,StructuralNormalQPResult& result,
    std::string& error,double gapTolerance){
    using Real=long double;
    result={};error.clear();const size_t count=gap.size();
    const auto fail=[&](const char* reason){error=reason;return false;};
    if(count&&count>std::numeric_limits<size_t>::max()/count)return fail("structural normal QP dimension overflow");
    if(gram.size()!=count*count||(!warm.empty()&&warm.size()!=count)||!std::isfinite(gapTolerance)||gapTolerance<=0)
        return fail("invalid structural normal QP dimensions or tolerance");
    if(!count)return true;
    for(double value:gram)if(!std::isfinite(value))return fail("nonfinite structural normal QP Gram matrix");
    std::vector<Real> scale(count),b(count),y(count,0),factor;
    for(size_t i=0;i<count;++i){
        if(!std::isfinite(gap[i])||(!warm.empty()&&(!std::isfinite(warm[i])||warm[i]<0)))return fail("invalid structural normal QP gap or warm hint");
        const double diagonal=gram[i*count+i];if(diagonal<0)return fail("negative structural normal QP diagonal");
        if(diagonal==0){
            if(gap[i]<-gapTolerance)return fail("infeasible prescribed structural normal contact");
            for(size_t j=0;j<count;++j)if(gram[i*count+j]!=0||gram[j*count+i]!=0)return fail("inconsistent zero-response structural contact row");
            continue;
        }
        scale[i]=std::sqrt(Real(diagonal));b[i]=Real(gap[i])/scale[i];
    }
    // Unit diagonal improves rank decisions for differently weighted material
    // samples. Symmetrization removes only arithmetic roundoff in a Gram
    // response; its actual diagonal and physical gap are retained exactly.
    const auto matrix=[&](size_t i,size_t j)->Real{
        return (Real(gram[i*count+j])+Real(gram[j*count+i]))/(2*scale[i]*scale[j]);
    };
    std::vector<size_t> active;std::vector<unsigned char> included(count,0);
    const auto rankTolerance=[&](){return Real(64)*std::numeric_limits<double>::epsilon()*Real(active.size()+1);};
    const auto refactor=[&](){
        const size_t rank=active.size();factor.assign(rank*rank,0);
        for(size_t i=0;i<rank;++i)for(size_t j=0;j<=i;++j){Real value=matrix(active[i],active[j]);
            for(size_t k=0;k<j;++k)value-=factor[i*rank+k]*factor[j*rank+k];
            if(i==j){if(!(value>rankTolerance()))return false;factor[i*rank+j]=std::sqrt(value);}
            else factor[i*rank+j]=value/factor[j*rank+j];
        }return true;
    };
    const auto solve=[&](const std::vector<Real>& rhs){
        const size_t rank=active.size();std::vector<Real> values=rhs;
        for(size_t i=0;i<rank;++i){for(size_t j=0;j<i;++j)values[i]-=factor[i*rank+j]*values[j];values[i]/=factor[i*rank+i];}
        for(size_t i=rank;i-->0;){for(size_t j=i+1;j<rank;++j)values[i]-=factor[j*rank+i]*values[j];values[i]/=factor[i*rank+i];}
        return values;
    };
    const auto erase=[&](size_t position){included[active[position]]=0;y[active[position]]=0;active.erase(active.begin()+position);};
    const uint64_t rankBound=std::min<size_t>(count,maximumRank);
    if(uint64_t(count)>std::numeric_limits<uint64_t>::max()/8/(rankBound+1))return fail("structural normal QP pivot dimension overflow");
    const uint64_t pivotBound=std::min<uint64_t>(std::numeric_limits<unsigned>::max(),std::max<uint64_t>(64,8*uint64_t(count)*(rankBound+1)));
    const auto pivot=[&](){if(uint64_t(result.pivots)>=pivotBound)return false;++result.pivots;return true;};
    const auto publish=[&](){
        result.multipliers.assign(count,0);result.primalResidual=result.complementarityResidual=0;result.rank=unsigned(active.size());
        for(size_t i=0;i<count;++i)if(scale[i]>0)result.multipliers[i]=double(y[i]/scale[i]);
        for(size_t i=0;i<count;++i){Real value=gap[i];for(auto j:active)value+=Real(gram[i*count+j])*Real(result.multipliers[j]);
            result.primalResidual=std::max(result.primalResidual,double(std::max(Real(0),-value)));
            result.complementarityResidual=std::max(result.complementarityResidual,double(std::abs(Real(result.multipliers[i])*value)));
        }
    };
    while(true){
        size_t enter=count;Real worst=-Real(gapTolerance);
        for(size_t i=0;i<count;++i){if(scale[i]==0)continue;Real value=b[i];for(auto j:active)value+=matrix(i,j)*y[j];
            if(included[i])continue;
            const Real physical=scale[i]*value;
            if(physical<worst){worst=physical;enter=i;}
            else if(enter!=count&&physical==worst&&!warm.empty()&&warm[i]>warm[enter])enter=i;
        }
        if(enter==count){publish();double maximum=0;for(double value:result.multipliers)maximum=std::max(maximum,value);
            if(!std::isfinite(result.primalResidual)||!std::isfinite(result.complementarityResidual)||result.primalResidual>gapTolerance*4||result.complementarityResidual>gapTolerance*4*std::max(1.,maximum))
                return fail("structural normal QP final complementarity residual exceeded its numerical contract");
            return true;
        }
        if(!pivot()){publish();return fail("structural normal QP exceeded its dimension-bounded pivot budget");}
        std::vector<Real> cross(active.size());for(size_t i=0;i<active.size();++i)cross[i]=matrix(active[i],enter);
        const auto coefficients=solve(cross);Real schur=1;
        for(size_t i=0;i<active.size();++i)schur-=cross[i]*coefficients[i];
        if(schur < -rankTolerance()){publish();return fail("structural normal QP Gram response is not positive semidefinite");}
        if(schur<=rankTolerance()){
            // A violated dependent plane cannot enter the same basis. Move
            // along its exact dual null direction: d_enter=1, d_old=-c.
            // A stronger redundant plane displaces the first old nonnegative
            // blocker without changing physical displacement at this pivot.
            // No blocker means the dual is unbounded: the primal constraints
            // are incompatible, not a justification for artificial softness.
            size_t leave=active.size();Real step=std::numeric_limits<Real>::infinity();
            for(size_t i=0;i<active.size();++i)if(coefficients[i]>rankTolerance()){
                const Real candidate=y[active[i]]/coefficients[i];
                if(candidate<step||(candidate==step&&leave<active.size()&&active[i]<active[leave])){step=candidate;leave=i;}
            }
            if(leave==active.size()||!std::isfinite(step)){publish();return fail("infeasible dependent structural normal contacts");}
            for(size_t i=0;i<active.size();++i)y[active[i]]=std::max(Real(0),y[active[i]]-step*coefficients[i]);
            y[enter]=step;erase(leave);active.push_back(enter);included[enter]=1;
            if(!refactor()){publish();return fail("structural normal QP dependent basis exchange lost numerical rank");}
        }else{
            if(active.size()>=rankBound){publish();return fail("structural normal QP independent rank exceeds its primal dimension");}
            active.push_back(enter);included[enter]=1;
            if(!refactor()){publish();return fail("structural normal QP active basis lost numerical rank");}
        }
        // The unrestricted optimum in the independent basis may have negative
        // multipliers. Walk toward it only until the first positivity boundary,
        // remove that row, and solve the smaller SAME frozen quadratic again.
        while(true){
            std::vector<Real> rhs(active.size());for(size_t i=0;i<active.size();++i)rhs[i]=-b[active[i]];
            const auto candidate=solve(rhs);size_t leave=active.size();Real step=1;
            for(size_t i=0;i<active.size();++i)if(candidate[i]<0){const Real crossing=y[active[i]]/(y[active[i]]-candidate[i]);
                if(crossing<step||(crossing==step&&leave<active.size()&&active[i]<active[leave])){step=crossing;leave=i;}}
            if(leave==active.size()){for(size_t i=0;i<active.size();++i)y[active[i]]=candidate[i];break;}
            for(size_t i=0;i<active.size();++i)y[active[i]]=std::max(Real(0),y[active[i]]+step*(candidate[i]-y[active[i]]));
            if(!pivot()){publish();return fail("structural normal QP exceeded its dimension-bounded positivity pivots");}
            erase(leave);if(!refactor()){publish();return fail("structural normal QP reduced basis lost numerical rank");}
        }
    }
}

bool SolveStructuralFrictionDisk(double a,double b,double d,const std::array<double,2>& rhs,
    double radius,std::array<double,2>& impulse,std::string& error){
    using Real=long double;impulse={0,0};error.clear();
    const auto fail=[&](const char* reason){error=reason;return false;};
    if(!std::isfinite(a)||!std::isfinite(b)||!std::isfinite(d)||!std::isfinite(rhs[0])||!std::isfinite(rhs[1])||!std::isfinite(radius)||radius<0||a<0||d<0)
        return fail("invalid structural friction metric or disk");
    const Real aa=a,bb=b,dd=d,trace=aa+dd,determinant=aa*dd-bb*bb;
    const Real metricScale=std::max({aa,dd,std::abs(bb)}),roundoff=Real(64)*std::numeric_limits<double>::epsilon()*metricScale*metricScale;
    if(determinant < -roundoff)return fail("structural friction response is not positive semidefinite");
    if(radius==0)return true;
    const Real angle=Real(.5)*std::atan2(2*bb,aa-dd),c=std::cos(angle),s=std::sin(angle);
    const Real high=Real(.5)*(trace+std::hypot(aa-dd,2*bb));
    // det/high avoids cancellation when one genuine response eigenvalue is
    // much smaller. A negative determinant inside arithmetic error is zero;
    // no positive compliance is introduced in the null direction.
    const Real low=high>0?std::max(Real(0),determinant/high):0;
    const std::array<Real,2> eigen{high,low};
    std::array<Real,2> load{c*Real(rhs[0])+s*Real(rhs[1]),-s*Real(rhs[0])+c*Real(rhs[1])};
    const Real loadNorm=std::hypot(Real(rhs[0]),Real(rhs[1])),loadRoundoff=Real(64)*std::numeric_limits<double>::epsilon()*loadNorm;
    for(unsigned i=0;i<2;++i)if(eigen[i]==0&&std::abs(load[i])<=loadRoundoff)load[i]=0;
    const auto solution=[&](Real alpha){std::array<Real,2> values{0,0};for(unsigned i=0;i<2;++i){const Real denominator=eigen[i]+alpha;
        if(denominator>0)values[i]=load[i]/denominator;else if(load[i]!=0)values[i]=std::numeric_limits<Real>::infinity();}return values;};
    auto values=solution(0);const Real limit=radius;
    if(std::hypot(values[0],values[1])>limit){
        // For PSD W, ||(W+alpha I)^-1 rhs|| <= ||rhs||/alpha.
        // This supplies a derived feasible bracket, including an actual null
        // metric. Sixty-four bisections resolve a double-precision scalar;
        // they are numerical algebra, not an added physics-quality budget.
        Real lower=0,upper=loadNorm/limit;
        for(unsigned iteration=0;iteration<64;++iteration){const Real middle=(lower+upper)*Real(.5);const auto trial=solution(middle);
            if(std::hypot(trial[0],trial[1])>limit)lower=middle;else upper=middle;}
        values=solution(upper);
    }
    impulse={double(c*values[0]-s*values[1]),double(s*values[0]+c*values[1])};
    if(!std::isfinite(impulse[0])||!std::isfinite(impulse[1])||std::hypot(impulse[0],impulse[1])>radius*(1+64*std::numeric_limits<double>::epsilon()))
        return fail("structural friction disk failed its finite-radius numerical contract");
    return true;
}

void WriteStructuralContactFailure(const std::string& base,uint64_t generation,unsigned interval,
    unsigned nonlinearRound,double seconds,unsigned physicalRows,const std::string& reason,
    const std::vector<StructuralContactFailureRow>& rows,const std::vector<double>& threeAxisGram,
    const std::vector<StructuralContactFailureSweep>& sweeps){
    static bool published=false;
    if(published||base.empty())return;
    FILE* summary=std::fopen((base+".contact-failure.txt").c_str(),"w");if(!summary)return;
    published=true;const size_t count=physicalRows,axes=3*count;
    const bool complete=count<=96&&rows.size()==count&&threeAxisGram.size()==axes*axes&&sweeps.size()<=2*count+8;
    std::fprintf(summary,"generation=%llu\ninterval=%u\nnonlinear_round=%u\nphysical_seconds=%.17g\nrows=%zu\nsweeps=%zu\nfull_frozen_operator=%u\nreason=%s\n",(unsigned long long)generation,interval,nonlinearRound,seconds,count,sweeps.size(),unsigned(complete),reason.c_str());
    std::fputs("Operator axes are normal,tangent0,tangent1 per row. Gap/slip are metres; multipliers are kg*m. Signed local quadratic and impulse*slip divided by seconds^2 are joules. Current native solver tolerances and budgets are unchanged.\n",summary);
    if(!sweeps.empty()){const auto& last=sweeps.back();std::fprintf(summary,"normal_qp_target=%.17g\nnormal_qp_certificate_factor=%.17g\nouter_primal_tolerance=%.17g\nouter_complementarity_tolerance=%.17g\nouter_tangent_tolerance=%.17g\n",last.qpTarget,last.qpCertificateFactor,last.outerPrimalTolerance,last.outerComplementarityTolerance,last.outerTangentTolerance);}
    if(!complete){std::fputs("Full algebra omitted: explicit96-row/2*rows+8-sweep diagnostic envelope.\n",summary);std::fclose(summary);return;}
    std::fclose(summary);
    if(FILE* output=std::fopen((base+".contact-failure-rows.csv").c_str(),"w")){
        std::fputs("row,world,body,primitive,sample,native_row,self,node0,node1,node2,weight0,weight1,weight2,other_node0,other_node1,other_node2,other_weight0,other_weight1,other_weight2,nx,ny,nz,t0x,t0y,t0z,t1x,t1y,t1z,pointx,pointy,pointz,q_normal,q_t0,q_t1,initial_normal,initial_t0,initial_t1\n",output);
        for(size_t i=0;i<count;++i){const auto& row=rows[i];std::fprintf(output,"%zu,%llu,%u,%u,%u,%u,%u",i,(unsigned long long)row.world,row.body,row.primitive,row.sample,row.nativeRow,unsigned(row.self));
            for(auto value:row.nodes)std::fprintf(output,",%u",value);
            for(double value:row.weights)std::fprintf(output,",%.17g",value);
            for(auto value:row.otherNodes)std::fprintf(output,",%u",value);
            for(double value:row.otherWeights)std::fprintf(output,",%.17g",value);
            for(const auto* values:{&row.normal,&row.tangent0,&row.tangent1,&row.point,&row.freeGap,&row.initialImpulse})for(double value:*values)std::fprintf(output,",%.17g",value);
            std::fputc('\n',output);
        }std::fclose(output);
    }
    if(FILE* output=std::fopen((base+".contact-failure-gram.csv").c_str(),"w")){
        std::fputs("row_i,axis_i,row_j,axis_j,response\n",output);
        for(size_t i=0;i<axes;++i)for(size_t j=0;j<axes;++j)std::fprintf(output,"%zu,%zu,%zu,%zu,%.17g\n",i/3,i%3,j/3,j%3,threeAxisGram[i*axes+j]);
        std::fclose(output);
    }
    if(FILE* output=std::fopen((base+".contact-failure-sweeps.csv").c_str(),"w")){
        std::fputs("sweep,qp_pivots,qp_rank,qp_primal,qp_complementarity,final_primal,final_complementarity,tangent_change,maximum_normal,row,normal,t0,t1,gap,slip0,slip1,radius,old_t0,old_t1,local_delta_quadratic_j,tangent_work_j,normal_work_j,normal_relative_displacement\n",output);
        const double inverseTime=seconds>0?1/(seconds*seconds):0;
        for(const auto& sweep:sweeps){if(sweep.rows.size()!=count)continue;
            for(size_t i=0;i<count;++i){const auto& row=sweep.rows[i];std::fprintf(output,"%u,%u,%u,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%zu",sweep.sweep,sweep.pivots,sweep.rank,sweep.qpPrimal,sweep.qpComplementarity,sweep.primal,sweep.complementarity,sweep.tangentChange,sweep.maximumNormal,i);
                for(unsigned k=0;k<9;++k)std::fprintf(output,",%.17g",row[k]);
                std::fprintf(output,",%.17g,%.17g,%.17g,%.17g\n",row[9]*inverseTime,(row[1]*row[4]+row[2]*row[5])*inverseTime,row[0]*row[10]*inverseTime,row[10]);
            }
        }std::fclose(output);
    }
}
