#include "Deformable.h"
#include "CollisionGeometry.h"
#include "CollisionAsset.h"
#include "PhysicsCastGeometry.h"
#include "Narrowphase.h"
#include "PerformanceProfiler.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <map>
#include <numeric>
#include <set>
#include <tuple>
namespace {
using V=glm::dvec3;using M=glm::dmat3;
// Existing opt-in numerical trace only. This bounded witness records when
// finite-feature discovery changes a retained contact plane; it neither
// queries geometry again nor mutates the contact or its accumulated wrench.
struct StructuralDiscoveryTrace {
    FILE* out=nullptr;unsigned events=0;
    StructuralDiscoveryTrace(){const char* base=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE");if(!base||!*base)return;
        out=std::fopen((std::string(base)+".discovery.csv").c_str(),"w");
        if(out)std::fputs("generation,interval,round,event,row,world,body,primitive,sample,n0,n1,n2,w0,w1,w2,old_point_x,old_point_y,old_point_z,new_point_x,new_point_y,new_point_z,old_normal_x,old_normal_y,old_normal_z,new_normal_x,new_normal_y,new_normal_z,normal_net_x,normal_net_y,normal_net_z,tangent_lambda_x,tangent_lambda_y,tangent_lambda_z,old_gap,new_gap,material_x,material_y,material_z,start_x,start_y,start_z,cast_plane,swept,retained_swept_plane,discovered_point_x,discovered_point_y,discovered_point_z,discovered_normal_x,discovered_normal_y,discovered_normal_z\n",out);
    }
    ~StructuralDiscoveryTrace(){if(out)std::fclose(out);}
};
void traceDiscovery(const DeformableInstance& instance,size_t row,bool created,BodyHandle body,unsigned primitive,unsigned sample,glm::uvec3 nodes,V weights,V oldPoint,V point,V oldNormal,V normal,V normalNet,V tangentLambda,double oldGap,double gap,V material,V start,bool castPlane,bool swept,bool retaining,V discoveredPoint,V discoveredNormal){
    if(!instance.StructuralDiagnosticActive()||(!created&&!retaining&&oldPoint==point&&oldNormal==normal))return;
    static StructuralDiscoveryTrace trace;if(!trace.out||trace.events>=4096)return;++trace.events;
    std::fprintf(trace.out,"%llu,%u,%u,%s,%zu,%llu,%u,%u,%u,%u,%u,%u",
        (unsigned long long)instance.generation,instance.StructuralDiagnosticInterval(),instance.StructuralDiagnosticRound(),created?"create":retaining?"retain":"replace",row,(unsigned long long)body.world,body.id,primitive,sample,nodes.x,nodes.y,nodes.z);
    for(const V value:{weights,oldPoint,point,oldNormal,normal,normalNet,tangentLambda})std::fprintf(trace.out,",%.17g,%.17g,%.17g",value.x,value.y,value.z);
    std::fprintf(trace.out,",%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%d,%d,%d",oldGap,gap,material.x,material.y,material.z,start.x,start.y,start.z,int(castPlane),int(swept),int(retaining));
    for(const V value:{discoveredPoint,discoveredNormal})std::fprintf(trace.out,",%.17g,%.17g,%.17g",value.x,value.y,value.z);
    std::fputc('\n',trace.out);std::fflush(trace.out);
}
V closest(V p,V a,V b,V c){V ab=b-a,ac=c-a,ap=p-a;
        double d1=glm::dot(ab,ap),d2=glm::dot(ac,ap);
        if(d1<=0&&d2<=0)return {1,0,0};
        V bp=p-b;
        double d3=glm::dot(ab,bp),d4=glm::dot(ac,bp);
        if(d3>=0&&d4<=d3)return {0,1,0};
        double vc=d1*d4-d3*d2;
        if(vc<=0&&d1>=0&&d3<=0){double v=d1/(d1-d3);
            return {1-v,v,0};
            }V cp=p-c;
        double d5=glm::dot(ab,cp),d6=glm::dot(ac,cp);
        if(d6>=0&&d5<=d6)return {0,0,1};
        double vb=d5*d2-d1*d6;
        if(vb<=0&&d2>=0&&d6<=0){double w=d2/(d2-d6);
            return {1-w,0,w};
            }double va=d3*d6-d5*d4;
        if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0){double w=(d4-d3)/((d4-d3)+(d5-d6));
            return {0,1-w,w};
            }double inv=1/(va+vb+vc);
        return {1-(vb+vc)*inv,vb*inv,vc*inv};
        }
std::pair<double,double> segments(V a,V b,V c,V d){V u=b-a,v=d-c,r=a-c;
        double A=glm::dot(u,u),B=glm::dot(u,v),C=glm::dot(v,v),D=glm::dot(u,r),E=glm::dot(v,r),den=A*C-B*B;
        if(A<1e-15||C<1e-15)return {0,0};
        double s=den>1e-15?std::clamp((B*E-C*D)/den,0.,1.):0;
        double t=std::clamp((B*s+E)/C,0.,1.);
        s=std::clamp((B*t-D)/A,0.,1.);
        return {s,t};
        }
double effective(PhysicsWorld& p,BodyHandle b,V point,V normal,double predictedSeconds=0){
    if(!p.IsDynamicBody(b))return 0;
        double m=p.GetMass(b);
        if(m<=0)return 0;
        V r=point-V(predictedSeconds>0?p.PredictCenterOfMass(b,float(predictedSeconds)):p.GetCenterOfMass(b)),rn=glm::cross(r,normal);
        const M inverseInertia=predictedSeconds>0?M(p.PredictedInverseInertiaWorld(b,float(predictedSeconds))):M(glm::inverse(p.GetInertiaWorld(b)));
        return 1/m+glm::dot(rn,inverseInertia*rn);
}
V pointVelocity(PhysicsWorld& p,BodyHandle b,V point,double predictedSeconds=0){if(predictedSeconds>0)return V(p.PredictPointVelocity(b,glm::vec3(point),float(predictedSeconds)));return V(p.GetLinearVelocity(b))+glm::cross(V(p.GetAngularVelocity(b)),point-V(p.GetCenterOfMass(b)));
        }
void observe(DeformableInstance& s,V point,V normal,double depth,bool swept,bool self,BodyHandle body={},double impulse=0){
    ++s.stats.contacts;
    s.stats.maximumPenetration=std::max(s.stats.maximumPenetration,depth);
    s.stats.sweptContacts+=swept;
    const DeformableContactObservation observation{point,normal,depth,swept,self,body,impulse};
    if(s.contactObservations.size()<256)s.contactObservations.push_back(observation);
    else{
        // Keep the strongest solved contacts instead of filling the bounded
        // witness entirely with early, repeatedly solved support contacts.
        auto weakest=std::min_element(s.contactObservations.begin(),s.contactObservations.end(),[](const auto& x,const auto& y){return x.normalImpulse<y.normalImpulse;});
        if(impulse>weakest->normalImpulse)*weakest=observation;
    }
}
bool edgeVisible(const DeformableInstance& s,unsigned e,const std::vector<int>& edgeBeams){
    if(e<s.asset->edgeFaces.size())for(auto f:s.asset->edgeFaces[e])if(s.FaceVisible(f))return true;
    // A beam remains a physical member even when it has no surrounding panel.
    if(s.Structural()){const int b=edgeBeams[e];return b>=0&&!s.structure.broken[unsigned(b)];}
    return s.asset->edgeFaces.empty(); // Compatibility with prepared legacy data.
}
// Bonded fracture seams use deliberate duplicated nodes. Their intact local
// neighborhoods act like one physical topology; disconnected remote faces are
// never excluded merely because they belong to the same surviving component.
bool localExclusions(const DeformableInstance& s,const std::vector<int>& edgeBeams,std::vector<std::vector<unsigned>>& faces,std::vector<std::vector<unsigned>>& edges){
    const auto& a=*s.asset;const unsigned count=unsigned(a.nodes.size());
    std::vector<unsigned> parent(count);std::iota(parent.begin(),parent.end(),0);
    auto root=[&](unsigned n){while(parent[n]!=n){parent[n]=parent[parent[n]];n=parent[n];}return n;};
    if(a.fracture)for(unsigned b=0;b<a.fracture->bonds.size();++b)if(!s.fracture.broken[b])for(auto pair:a.fracture->bonds[b].pairs){auto x=root(pair.x),y=root(pair.y);parent[std::max(x,y)]=std::min(x,y);}
    std::vector<std::vector<unsigned>> adjacent(count),nodeFaces(count),nodeEdges(count);
    for(unsigned index=0;index<a.edges.size();++index){const auto e=a.edges[index];const bool alive=!s.Structural()||edgeVisible(s,index,edgeBeams);
        if(alive){auto x=root(e.x),y=root(e.y);adjacent[x].push_back(y);adjacent[y].push_back(x);}}
    for(unsigned f=0;f<a.triangles.size();++f)if(s.FaceVisible(f))for(unsigned n:{a.triangles[f].x,a.triangles[f].y,a.triangles[f].z})nodeFaces[root(n)].push_back(f);
    for(unsigned e=0;e<a.edges.size();++e)if(edgeVisible(s,e,edgeBeams))for(unsigned n:{a.edges[e].x,a.edges[e].y})nodeEdges[root(n)].push_back(e);
    auto collect=[&](unsigned n,const auto& incident,std::set<unsigned>& out){n=root(n);out.insert(incident[n].begin(),incident[n].end());for(auto next:adjacent[n])out.insert(incident[next].begin(),incident[next].end());};
    size_t entries=0;
    faces.resize(count);for(unsigned n=0;n<count;++n){std::set<unsigned> out;collect(n,nodeFaces,out);entries+=out.size();if(entries>2000000)return false;faces[n]={out.begin(),out.end()};}
    edges.resize(a.edges.size());for(unsigned e=0;e<a.edges.size();++e){std::set<unsigned> out;collect(a.edges[e].x,nodeEdges,out);collect(a.edges[e].y,nodeEdges,out);entries+=out.size();if(entries>2000000)return false;edges[e]={out.begin(),out.end()};}
    return true;
}

struct ContactBounds {V low{0},high{0};bool valid=false;};
ContactBounds primitiveBounds(const PrimitivePose& p){
    V center=PrimitiveCenter(p),reach(0);const M r=PrimitiveRotation(p);
    if(p.shape.asset){const auto& a=*p.shape.asset;const V half=(a.maximum-a.minimum)*.5;center+=r*((a.maximum+a.minimum)*.5);reach=glm::abs(r[0])*half.x+glm::abs(r[1])*half.y+glm::abs(r[2])*half.z;}
    else if(p.shape.type==ShapeType::Box){const V half(p.shape.halfExtents);reach=glm::abs(r[0])*half.x+glm::abs(r[1])*half.y+glm::abs(r[2])*half.z;}
    else if(p.shape.type==ShapeType::Sphere)reach=V(p.shape.radius);
    else if(p.shape.type==ShapeType::Capsule)reach=glm::abs(r[1])*double(p.shape.halfHeight)+V(p.shape.radius);
    else return {}; // Preserve the full terrain/unknown narrowphase path.
    return {center-reach,center+reach,true};
}
ContactBounds predictedBounds(const PrimitivePose& local,const PreciseBodyPrediction& pose){
    const auto source=primitiveBounds(local);if(!source.valid)return source;
    const glm::dquat rotation=glm::normalize(pose.rotation);ContactBounds result{V(1e300),V(-1e300),true};
    // Transform all corners of the existing local geometry bound. This may
    // enlarge curved-shape bounds but cannot cull their represented surface,
    // and uses exactly the same future frame as the predictive narrowphase.
    for(unsigned corner=0;corner<8;++corner){const V point=pose.centerOfMass+rotation*V((corner&1)?source.high.x:source.low.x,(corner&2)?source.high.y:source.low.y,(corner&4)?source.high.z:source.low.z);
        result.low=glm::min(result.low,point);result.high=glm::max(result.high,point);}
    return result;
}
bool separated(V low,V high,const ContactBounds& bounds,double thickness){
    if(!bounds.valid)return false;
    // The authoritative cast rounds its origin/direction to float. Include
    // both that conversion error (also for long/far-world casts) and its 10 um
    // convergence tolerance, so the bound cannot reject a narrowphase hit.
    const V scale=glm::max(glm::max(glm::abs(low),glm::abs(high)),glm::max(glm::abs(bounds.low),glm::abs(bounds.high)))+(high-low);
    const V padding=V(thickness+1e-5)+scale*(16.*std::numeric_limits<float>::epsilon());
    return glm::any(glm::lessThan(high+padding,bounds.low))||glm::any(glm::greaterThan(low-padding,bounds.high));
}

}
void DeformableInstance::PrepareContactEdges(){
    if(contactIndexedAsset==asset)return;
    contactIndexedAsset=asset;contactEdgeBeam.assign(asset->edges.size(),-1);
    rigidSampleTree.clear();rigidSampleTreeNodes.clear();rigidSampleTreeWeights.clear();rigidSampleTopology=~uint64_t(0);
    if(!Structural())return;
    // Immutable authored topology is indexed once. Visibility still reads the
    // current broken state every solve, including a same-revision restore.
    std::map<std::pair<unsigned,unsigned>,unsigned> beamByNodes;
    for(unsigned b=0;b<asset->structure->beams.size();++b){const auto& beam=asset->structure->beams[b];beamByNodes.emplace(std::minmax(beam.a,beam.b),b);}
    for(unsigned e=0;e<asset->edges.size();++e){const auto n=asset->edges[e];const auto found=beamByNodes.find(std::minmax(n.x,n.y));if(found!=beamByNodes.end())contactEdgeBeam[e]=int(found->second);}
}
void DeformableInstance::PrepareRigidSampleTree(){
    bool same=rigidSampleTopology==TopologyRevision()&&rigidSampleTreeNodes.size()==contactRigidSamples.size()&&rigidSampleTreeWeights.size()==contactRigidSamples.size();
    for(size_t i=0;same&&i<contactRigidSamples.size();++i)same=rigidSampleTreeNodes[i]==contactRigidSamples[i].nodes&&rigidSampleTreeWeights[i]==contactRigidSamples[i].weights;
    if(same&&!rigidSampleTree.empty())return;
    // Comparing actual identities also handles a restored broken pattern with
    // the SAME revision/count: no saved cache or revision guess owns geometry.
    rigidSampleTopology=TopologyRevision();rigidSampleTree.clear();rigidSampleTreeNodes.clear();rigidSampleTreeWeights.clear();
    const unsigned count=unsigned(contactRigidSamples.size());if(!count)return;rigidSampleTree.reserve(size_t(count)*2-1);
    std::vector<V> centres(count);std::vector<unsigned> indices(count);std::iota(indices.begin(),indices.end(),0);
    for(unsigned i=0;i<count;++i){const auto& sample=contactRigidSamples[i];rigidSampleTreeNodes.push_back(sample.nodes);rigidSampleTreeWeights.push_back(sample.weights);centres[i]=V(0);
        for(int k=0;k<3;++k)centres[i]+=asset->nodes[sample.nodes[k]]*sample.weights[k];}
    auto build=[&](auto&& recurse,size_t begin,size_t end)->unsigned{
        const unsigned node=unsigned(rigidSampleTree.size());rigidSampleTree.emplace_back();
        if(end-begin==1){rigidSampleTree[node].primitive=indices[begin];return node;}
        V low(1e300),high(-1e300);for(size_t i=begin;i<end;++i){low=glm::min(low,centres[indices[i]]);high=glm::max(high,centres[indices[i]]);}
        const V extent=high-low;unsigned axis=extent.y>extent.x?1:0;if(extent.z>extent[axis])axis=2;const size_t middle=(begin+end)/2;
        std::nth_element(indices.begin()+begin,indices.begin()+middle,indices.begin()+end,[&](unsigned a,unsigned b){return centres[a][axis]==centres[b][axis]?a<b:centres[a][axis]<centres[b][axis];});
        const auto left=recurse(recurse,begin,middle),right=recurse(recurse,middle,end);rigidSampleTree[node].left=left;rigidSampleTree[node].right=right;return node;
    };build(build,0,count);
}
void DeformableInstance::RefitRigidSampleTree(V oldCOM,V futureCOM,const glm::dquat& relativeRotation,uint64_t revision){
    for(size_t i=rigidSampleTree.size();i-->0;){auto& node=rigidSampleTree[i];
        if(node.primitive==~0u){node.low=glm::min(rigidSampleTree[node.left].low,rigidSampleTree[node.right].low);node.high=glm::max(rigidSampleTree[node.left].high,rigidSampleTree[node.right].high);continue;}
        auto& sample=contactRigidSamples[node.primitive];V point(0),old(0);
        if(contactSampleCacheEnabled){
            if(!sample.pointValid){sample.point=V(0);for(int k=0;k<3;++k){sample.point+=positions[sample.nodes[k]]*sample.weights[k];sample.pointRevision[k]=contactNodeRevision[sample.nodes[k]];}sample.pointValid=true;}
            if(!sample.oldValid){sample.old=V(0);for(int k=0;k<3;++k)sample.old+=start[sample.nodes[k]]*sample.weights[k];sample.oldValid=true;}
            point=sample.point;old=sample.old;sample.relativeOld=futureCOM+relativeRotation*(old-oldCOM);sample.relativeBody=revision;
        }else for(int k=0;k<3;++k){point+=positions[sample.nodes[k]]*sample.weights[k];old+=start[sample.nodes[k]]*sample.weights[k];}
        const V transported=contactSampleCacheEnabled?sample.relativeOld:futureCOM+relativeRotation*(old-oldCOM);
        node.low=glm::min(point,transported);node.high=glm::max(point,transported);
    }
}
void DeformableInstance::QueryRigidSampleTree(V minimum,V maximum,double thickness){
    rigidSampleCandidates.clear();if(rigidSampleTree.empty())return;const ContactBounds primitive{minimum,maximum,true};
    unsigned stack[64],size=1;stack[0]=0;
    while(size){const auto& node=rigidSampleTree[stack[--size]];if(separated(node.low,node.high,primitive,thickness))continue;
        if(node.primitive!=~0u)rigidSampleCandidates.push_back(node.primitive);
        else{if(size+2>64){stats.capacityExceeded=true;error="structural sample tree traversal exceeded bounded stack; instance stopped";return;}stack[size++]=node.right;stack[size++]=node.left;}
    }
    // Discovery used to scan node, edge, then face samples. Preserve exactly
    // that numerical ordering, independently of the immutable tree topology.
    std::sort(rigidSampleCandidates.begin(),rigidSampleCandidates.end());
}
void DeformableInstance::RigidContacts(double h,double fraction,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    JUDAS_PROFILE_SCOPE("Deformable rigid contacts");
    const double thickness=settings.material.thickness;
    PrepareContactEdges();contactVisibleEdges.clear();contactVisibleFaces.clear();
    for(unsigned e=0;e<asset->edges.size();++e)if(edgeVisible(*this,e,contactEdgeBeam))contactVisibleEdges.push_back(e);
    for(unsigned f=0;f<asset->triangles.size();++f)if(FaceVisible(f))contactVisibleFaces.push_back(f);
    contactRigidSamples.clear();contactNodeRevision.assign(positions.size(),0);
    auto addSample=[&](glm::uvec3 nodes,V weights){RigidContactSample sample;sample.nodes=nodes;sample.weights=weights;contactRigidSamples.push_back(sample);};
    for(unsigned n=0;n<positions.size();++n)addSample(glm::uvec3(n),V(1,0,0));
    for(auto e:contactVisibleEdges){auto edge=asset->edges[e];addSample({edge.x,edge.y,edge.y},V(.5,.5,0));}
    for(auto f:contactVisibleFaces)addSample(asset->triangles[f],V(1./3));
    // Swept particle bounds include the actual old and predicted material
    // positions, rather than a fixed rest-cell padding that misses thin walls.
    V low=Minimum(),high=Maximum();for(auto p:start){low=glm::min(low,p);high=glm::max(high,p);}
    PhysicsQueryFilter query;query.includeLayers=settings.collisionMask;
    if(structuralPredictiveCoupling)physics.QueryPredictedBodiesInAabbInto(glm::vec3(low-V(thickness)),glm::vec3(high+V(thickness)),float(h),rigidCandidates,query);
    else physics.QueryBodiesInAabbInto(glm::vec3(low-V(thickness)),glm::vec3(high+V(thickness)),rigidCandidates,query);
    using ContactKey=std::tuple<uint64_t,unsigned,unsigned,unsigned>;
    const auto key=[](BodyHandle body,unsigned primitive,unsigned sample){return ContactKey{body.world,body.id,primitive,sample};};
    std::map<ContactKey,size_t> retained;
    if(structuralPredictiveCoupling){
        std::set<std::pair<uint64_t,unsigned>> queried;
        for(auto body:rigidCandidates)queried.emplace(body.world,body.id);
        for(size_t i=0;i<structuralContactRows.size();++i){auto& row=structuralContactRows[i];if(row.self)continue;
            row.seen=false;retained.emplace(key(row.body,row.primitive,row.sample),i);
            // A previously solved body can move outside a freshly refitted
            // query bound. Keep it eligible for revalidation/release; this
            // does not make an inactive collider an infinite contact plane.
            if(physics.IsBodyEnabled(row.body)&&queried.emplace(row.body.world,row.body.id).second)rigidCandidates.push_back(row.body);
        }
        // Native broadphase preview publishes float endpoints. A known
        // finite participant can have a bounded unpublished momentum remainder
        // during this same nonlinear solve. Include it even before its first
        // row exists; the ordinary reciprocal filters and precise child bounds
        // below still decide whether any actual material contact is present.
        for(const auto& owned:structuralOwnedBodies)if((owned.idealImpulse!=owned.impulse||owned.idealMoment!=owned.moment)&&physics.IsBodyEnabled(owned.handle)&&physics.IsDynamicBody(owned.handle)&&queried.emplace(owned.handle.world,owned.handle.id).second)
            rigidCandidates.push_back(owned.handle);
    }
    stats.candidates+=rigidCandidates.size();
    if(structuralPredictiveCoupling&&contactCullingEnabled&&!rigidCandidates.empty())PrepareRigidSampleTree();
    auto sample=[&](RigidContactSample& cached,unsigned sampleIndex,unsigned primitiveIndex,uint64_t bodyRevision,BodyHandle body,const PrimitivePose& primitive,const PrimitivePose& localPrimitive,const BodyTransform& oldPose,const BodyTransform& pose,const PreciseBodyPrediction& precise,const glm::dquat& relativeRotation,const ContactBounds& bounds,double predictedSeconds,bool& predictedDirty){
        if(!error.empty())return;
        const auto nodes=cached.nodes;const auto weights=cached.weights;
        if(asset->fracture&&fracture.removed[asset->fracture->nodePart[nodes.x]])return;
        if((weights.x<=1e-12||contactPinned[nodes.x])&&(weights.y<=1e-12||contactPinned[nodes.y])&&(weights.z<=1e-12||contactPinned[nodes.z]))return;
        const V futureCOM=structuralPredictiveCoupling?precise.centerOfMass:V(pose.position);
        V p(0),old(0),relativeOld(0);
        if(contactSampleCacheEnabled){
            bool changed=!cached.pointValid;
            for(int k=0;k<3;++k)changed|=cached.pointRevision[k]!=contactNodeRevision[nodes[k]];
            if(changed){cached.point=V(0);for(int k=0;k<3;++k){cached.point+=positions[nodes[k]]*weights[k];cached.pointRevision[k]=contactNodeRevision[nodes[k]];}cached.pointValid=true;}
            if(!cached.oldValid){cached.old=V(0);for(int k=0;k<3;++k)cached.old+=start[nodes[k]]*weights[k];cached.oldValid=true;}
            if(cached.relativeBody!=bodyRevision){cached.relativeOld=futureCOM+relativeRotation*(cached.old-V(oldPose.position));cached.relativeBody=bodyRevision;}
            p=cached.point;old=cached.old;relativeOld=cached.relativeOld;
        }else{
            // Independent arithmetic reference for cache equivalence fixtures.
            for(int k=0;k<3;++k){p+=positions[nodes[k]]*weights[k];old+=start[nodes[k]]*weights[k];}
            relativeOld=futureCOM+relativeRotation*(old-V(oldPose.position));
        }
        const auto previousRow=structuralPredictiveCoupling?retained.find(key(body,primitiveIndex,sampleIndex)):retained.end();
        V normal(0),point(0);double depth=0;bool swept=false,castPlane=false;
        // Resolve finite translation in the primitive's final snapshot frame.
        // Endpoint rigid translation/rotation is included; this is a bounded
        // material-point cast, not an unrelated rigid rotating-body CCD solver.
        if(contactCullingEnabled&&previousRow==retained.end()&&separated(glm::min(p,relativeOld),glm::max(p,relativeOld),bounds,thickness))return;
        // Query the SAME native shape dispatcher in its authored body-local
        // snapshot. Public casts return float witness coordinates: rounding a
        // WORLD point before subtracting COM would bake a far-world ULP into
        // the local contact plane. Only this coordinate frame changes; shape,
        // skin, feature discovery and the ordinary post-step path do not.
        const glm::dquat physicalGeometryRotation=glm::normalize(precise.rotation);
        const glm::dquat toGeometry=glm::inverse(physicalGeometryRotation);
        const auto& geometry=structuralPredictiveCoupling?localPrimitive:primitive;
        const V geometryP=structuralPredictiveCoupling?toGeometry*(p-precise.centerOfMass):p;
        const V geometryOld=structuralPredictiveCoupling?toGeometry*(relativeOld-precise.centerOfMass):relativeOld;
        const V travel=geometryP-geometryOld;const double distance=glm::length(travel);
        if(distance>thickness*.5){
            Shape sphere;sphere.type=ShapeType::Sphere;sphere.radius=float(thickness);
            BodyTransform origin;origin.position=glm::vec3(geometryOld);
            const glm::vec3 castDirection(travel/distance);
            try{auto hit=CastAgainstPrimitive(sphere,origin,castDirection,distance,geometry);
                if(hit.hit&&!hit.initialOverlap){normal=V(hit.normal);point=V(hit.point);
                    depth=glm::dot(point+normal*thickness-geometryP,normal);swept=depth>1e-10;castPlane=true;}
                else if(structuralPredictiveCoupling&&hit.hit&&hit.initialOverlap){
                    // A material point resting on a thin wall starts its next
                    // sweep overlapping the contact skin. Preserve the real
                    // approach-side normal from that initial geometry; an
                    // unsigned final distance on the far side misses the
                    // entire crossing or chooses the opposite wall face.
                    auto initial=geometry.shape.asset?SegmentGeometry(geometryOld,geometryOld,thickness,geometry):PointGeometry(geometryOld,geometry);
                    if(initial.valid&&glm::dot(travel,initial.normal)<0){normal=initial.normal;point=initial.point;depth=glm::dot(point+normal*thickness-geometryP,normal);swept=depth>1e-10;castPlane=swept;}
                }
            }catch(const std::exception& e){error=std::string("deformable point cast: ")+e.what();return;}
        }
        if(!swept&&!(structuralPredictiveCoupling&&castPlane)){
            GeometryDistance result;
            if(geometry.shape.asset)result=SegmentGeometry(geometryP,geometryP,thickness,geometry);
            else{result=PointGeometry(geometryP,geometry);if(result.valid)result.gap=(result.contains?-result.gap:result.gap)-thickness;}
            if(!result.valid||(result.gap>=0&&previousRow==retained.end()))return;
            normal=result.normal;point=result.point;depth=-result.gap;
        }
        if(!std::isfinite(depth)||glm::dot(normal,normal)<.5||(!structuralPredictiveCoupling&&depth<=0))return;
        if(structuralPredictiveCoupling){
            if(depth>0&&physics.IsDynamicBody(body)){
                // Wake only demonstrated contacts, not every broadphase
                // candidate. Deferred authoritative gravity is consumed once
                // before this finite participant's future geometry is frozen.
                physics.PreparePredictedBody(body,float(h));
                const auto prepared=StructuralPrediction(physics,body,h);
                if(prepared.centerOfMass!=precise.centerOfMass||prepared.rotation!=precise.rotation){predictedDirty=true;return;}
            }
            size_t index;
            if(previousRow==retained.end()){
                // The same finite geometry and filtering above discover rows
                // for the common mechanical solve. There is no second
                // collision path and no local hard projection to undo.
                if(structuralContactRows.size()>=65536){stats.capacityExceeded=true;error="structural contact row capacity exceeded; instance stopped";return;}
                index=structuralContactRows.size();structuralContactRows.emplace_back();retained.emplace(key(body,primitiveIndex,sampleIndex),index);
                auto& row=structuralContactRows.back();row.nodes=nodes;row.weights=weights;row.body=body;row.primitive=primitiveIndex;row.sample=sampleIndex;
            }else index=previousRow->second;
            auto& row=structuralContactRows[index];row.seen=true;row.swept|=swept;row.startPoint=old;
            const V priorLocalPoint=row.localPoint,priorLocalNormal=row.localNormal,discoveredLocalPoint=point,discoveredLocalNormal=normal;const double priorGap=row.gap;
            // Preserve current finite-cast provenance separately from the
            // accumulated swept-contact observation. The real root now uses
            // live finite-path geometry; no experimental plane retention runs.
            const bool retaining=false;row.sweptPlane=castPlane;
            row.localPoint=point;row.localNormal=normal;
            point=precise.centerOfMass+physicalGeometryRotation*row.localPoint;normal=physicalGeometryRotation*row.localNormal;
            depth=glm::dot(point+normal*thickness-p,normal);
            row.worldPoint=point;row.normal=normal;row.gap=-depth;
            traceDiscovery(*this,index,previousRow==retained.end(),body,primitiveIndex,sampleIndex,nodes,weights,priorLocalPoint,row.localPoint,priorLocalNormal,row.localNormal,row.normalNet,row.tangentLambda,priorGap,row.gap,p,old,castPlane,swept,retaining,discoveredLocalPoint,discoveredLocalNormal);
            PrimitivePose initial=primitive;initial.parentPosition=oldPose.position;initial.parentOrientation=oldPose.rotation;
            auto initialDistance=initial.shape.asset?SegmentGeometry(old,old,thickness,initial):PointGeometry(old,initial);
            if(initialDistance.valid&&!initial.shape.asset)initialDistance.gap=(initialDistance.contains?-initialDistance.gap:initialDistance.gap)-thickness;
            row.oldDepth=initialDistance.valid?std::max(0.,-initialDistance.gap):0.;
            stats.maximumPenetration=std::max(stats.maximumPenetration,std::max(0.,depth));
            return;
        }
        double w=0;for(int k=0;k<3;++k)w+=inverseMass[nodes[k]]*weights[k]*weights[k];
        const double rigid=effective(physics,body,point,normal,predictedSeconds),den=w+rigid;if(den<1e-20)return;
        double normalImpulse=depth/(den*h);
        if(rigid>0){
            // The rigid pose does not move within material iterations. Its
            // velocity does react, so a finite partner must not receive the
            // remaining positional overlap impulse repeatedly. Solve only the
            // remaining closing velocity, plus a small old-overlap drift bias.
            PrimitivePose oldPrimitive=primitive;oldPrimitive.parentPosition=oldPose.position;oldPrimitive.parentOrientation=oldPose.rotation;
            GeometryDistance prior;
            if(oldPrimitive.shape.asset)prior=SegmentGeometry(old,old,thickness,oldPrimitive);
            else{prior=PointGeometry(old,oldPrimitive);if(prior.valid)prior.gap=(prior.contains?-prior.gap:prior.gap)-thickness;}
            const double oldDepth=prior.valid?std::max(0.,-prior.gap):0.;
            const double closing=glm::dot((p-old)/h-pointVelocity(physics,body,point,predictedSeconds),normal);
            const double allowed=std::max(0.,.1*oldDepth/h-closing)/den;
            normalImpulse=std::min(normalImpulse,allowed);
        }
        if(normalImpulse<=1e-15)return;
        const double dl=normalImpulse*h;
        for(int k=0;k<3;++k)positions[nodes[k]]+=normal*dl*inverseMass[nodes[k]]*weights[k];
        // Positional material correction is its impulse over this interval;
        // the finite rigid participant receives exactly its opposite, once.
        if(rigid>0){if(predictedSeconds>0){physics.ApplyPredictedImpulseAtPoint(body,glm::vec3(-normal*dl/h),glm::vec3(point),float(predictedSeconds));predictedDirty=true;}else physics.ApplyImpulseAtPoint(body,glm::vec3(-normal*dl/h),glm::vec3(point));}
        const V velocity=(p-old)/h-pointVelocity(physics,body,point,predictedSeconds);
        const V tangent=velocity-normal*glm::dot(velocity,normal);const double speed=glm::length(tangent);
        if(speed>1e-10){const V dir=tangent/speed;const double tangentialMass=w+effective(physics,body,point,dir,predictedSeconds);
            const double frictionImpulse=std::min(speed/tangentialMass,settings.material.friction*dl/h);
            for(int k=0;k<3;++k)positions[nodes[k]]-=dir*frictionImpulse*h*inverseMass[nodes[k]]*weights[k];
            if(rigid>0){if(predictedSeconds>0){physics.ApplyPredictedImpulseAtPoint(body,glm::vec3(dir*frictionImpulse),glm::vec3(point),float(predictedSeconds));predictedDirty=true;}else physics.ApplyImpulseAtPoint(body,glm::vec3(dir*frictionImpulse),glm::vec3(point));}
        }
        // Every subsequent sample sharing a corrected contributor must see
        // the updated geometry, including later samples in this same child.
        // Advancing only at body/child boundaries would change solve ordering.
        for(int k=0;k<3;++k)++contactNodeRevision[nodes[k]];
        observe(*this,point,normal,depth,swept,false,body,dl/h);
    };
    uint64_t bodyRevision=0;
    for(auto body:rigidCandidates){unsigned layer;CategoryMask mask;
        if(!physics.GetCollisionFilter(body,layer,mask)||(mask&CategoryBit(settings.collisionLayer))==0||physics.IsBodySensor(body))continue;
        contactPinned.assign(positions.size(),0);bool ignoreBody=false;
        for(size_t i=0;i<settings.attachments.size()&&i<targets.size();++i){
            if(released[i]||!settings.attachments[i].enabled||!targets[i].valid||targets[i].body.id!=body.id||targets[i].body.world!=body.world)continue;
            if(!settings.attachedBodyContact){ignoreBody=true;break;}
            // All enabled unreleased groups on this exact body form one local
            // union. Mixed pinned/free samples continue to receive contact.
            for(auto n:asset->groups.at(settings.attachments[i].group))contactPinned[n]=1;
        }
        if(ignoreBody)continue;
        Shape shape;BodyTransform pose;if(!physics.GetBodyShape(body,shape,pose))continue;
        ++bodyRevision;
        auto prev=physics.GetPreviousTransform(body);prev.position+=prev.rotation*shape.pivotOffset;
        const BodyTransform current=pose;
        const double previousFraction=std::max(0.,fraction-1./std::max(1u,activeSubsteps));
        BodyTransform oldPose;oldPose.position=glm::mix(prev.position,current.position,float(previousFraction));oldPose.rotation=glm::slerp(prev.rotation,current.rotation,float(previousFraction));
        pose.position=glm::mix(prev.position,current.position,float(fraction));pose.rotation=glm::slerp(prev.rotation,current.rotation,float(fraction));
        // This branch runs BEFORE the authoritative rigid pose advance. A
        // kinematic target has only published its command at that boundary;
        // its geometry must therefore use the same future preview as dynamic
        // bodies. Static prediction simply preserves the current pose. The
        // ordinary post-step path above keeps its historical interpolation.
        const double predictedSeconds=structuralPredictiveCoupling?h:0;
        bool predictedDirty=predictedSeconds>0;
        if(predictedSeconds>0)oldPose=current; // Actual COM, no pivot round-trip.
        PreciseBodyPrediction precise;precise.centerOfMass=V(pose.position);precise.rotation=glm::dquat(pose.rotation);
        glm::dquat relativeRotation=glm::dquat(pose.rotation)*glm::inverse(glm::dquat(oldPose.rotation));
        RigidBody parent;parent.position=pose.position;parent.orientation=pose.rotation;
        auto refreshPrediction=[&](){if(!predictedDirty)return;
            precise=StructuralPrediction(physics,body,predictedSeconds);
            pose=physics.PredictTransform(body,float(predictedSeconds));pose.position+=pose.rotation*shape.pivotOffset;
            parent.position=pose.position;parent.orientation=pose.rotation;
            relativeRotation=glm::normalize(precise.rotation)*glm::inverse(glm::normalize(glm::dquat(oldPose.rotation)));++bodyRevision;predictedDirty=false;};
        V transportedLow(1e300),transportedHigh(-1e300);uint64_t transportedRevision=0;
        uint64_t sampleTreeRevision=0;
        for(int i=0;i<PrimitiveCount(shape);++i){refreshPrediction();auto primitive=PrimitiveAt(shape,parent,i);
            RigidBody localParent;localParent.position=glm::vec3(0);localParent.orientation=glm::quat(1,0,0,0);
            const auto localPrimitive=PrimitiveAt(shape,localParent,i);
            const auto currentBounds=[&](){return structuralPredictiveCoupling?predictedBounds(localPrimitive,precise):primitiveBounds(primitive);};
            auto bounds=currentBounds();
            const auto firstRetained=retained.lower_bound(key(body,unsigned(i),0));
            const bool retainedPrimitive=firstRetained!=retained.end()&&std::get<0>(firstRetained->first)==body.world&&std::get<1>(firstRetained->first)==body.id&&std::get<2>(firstRetained->first)==unsigned(i);
            if(structuralPredictiveCoupling&&contactCullingEnabled&&bounds.valid){
                for(unsigned pass=0;pass<2;++pass){
                    if(sampleTreeRevision!=bodyRevision){RefitRigidSampleTree(V(oldPose.position),precise.centerOfMass,relativeRotation,bodyRevision);sampleTreeRevision=bodyRevision;}
                    QueryRigidSampleTree(bounds.low,bounds.high,thickness);if(!error.empty())return;
                    // Previously accumulated pressure must be revalidated even
                    // when the sample now lies outside this child's bounds.
                    // Include only its exact original sample, not all points.
                    auto existing=retained.lower_bound(key(body,unsigned(i),0));
                    while(existing!=retained.end()&&std::get<0>(existing->first)==body.world&&std::get<1>(existing->first)==body.id&&std::get<2>(existing->first)==unsigned(i)){
                        const auto index=std::get<3>(existing->first);if(index<contactRigidSamples.size())rigidSampleCandidates.push_back(index);++existing;
                    }
                    std::sort(rigidSampleCandidates.begin(),rigidSampleCandidates.end());rigidSampleCandidates.erase(std::unique(rigidSampleCandidates.begin(),rigidSampleCandidates.end()),rigidSampleCandidates.end());
                    bool changed=false;
                    for(unsigned index:rigidSampleCandidates){auto& point=contactRigidSamples[index];const uint64_t before=bodyRevision;
                        for(unsigned attempt=0;attempt<2;++attempt){
                            if(predictedDirty){refreshPrediction();primitive=PrimitiveAt(shape,parent,i);bounds=currentBounds();}
                            sample(point,index,unsigned(i),bodyRevision,body,primitive,localPrimitive,oldPose,pose,precise,relativeRotation,bounds,predictedSeconds,predictedDirty);
                            if(!predictedDirty)break;
                        }
                        if(!error.empty())return;
                        if(bodyRevision!=before){changed=true;break;}
                    }
                    if(!changed)break;
                    // Consuming deferred gravity changes a demonstrated
                    // body's preview once. Refit/requery this SAME child so
                    // newly eligible samples cannot be missed by stale bounds.
                    if(pass==1){error="structural contact prediction changed repeatedly during discovery; instance stopped";return;}
                }
                continue;
            }
            if(contactCullingEnabled&&bounds.valid&&!retainedPrimitive){
                if(transportedRevision!=bodyRevision){transportedLow=V(1e300);transportedHigh=V(-1e300);for(auto p:start){const V old=(structuralPredictiveCoupling?precise.centerOfMass:V(pose.position))+relativeRotation*(p-V(oldPose.position));transportedLow=glm::min(transportedLow,old);transportedHigh=glm::max(transportedHigh,old);}transportedRevision=bodyRevision;}
                // Earlier child solves may have changed the material. Refit
                // the current bounds here. The transported old envelope is
                // constant for every child of this represented body pose.
                const V lo=glm::min(Minimum(),transportedLow),hi=glm::max(Maximum(),transportedHigh);
                if(separated(lo,hi,bounds,thickness))continue;
            }
            for(unsigned pass=0;pass<(structuralPredictiveCoupling?2u:1u);++pass){bool changed=false;
            for(auto& point:contactRigidSamples){const uint64_t before=bodyRevision;
                // A solved reaction changes the predicted pose, although the
                // actual rigid pose is advanced only once by PhysicsWorld.
                // Refresh before the next sample and invalidate only its
                // body-relative old-point cache through the body revision.
                // Discovery can consume a sleeping body's deferred gravity.
                // That changes prediction exactly once, so revalidate this
                // SAME weighted sample before using its finite contact row.
                for(unsigned attempt=0;attempt<2;++attempt){
                    if(predictedDirty){refreshPrediction();primitive=PrimitiveAt(shape,parent,i);bounds=currentBounds();}
                    sample(point,unsigned(&point-contactRigidSamples.data()),unsigned(i),bodyRevision,body,primitive,localPrimitive,oldPose,pose,precise,relativeRotation,bounds,predictedSeconds,predictedDirty);
                    if(!structuralPredictiveCoupling||!predictedDirty)break;
                }
                if(structuralPredictiveCoupling&&bodyRevision!=before){changed=true;break;}
            }
            if(!changed)break;
            if(pass==1){error="structural contact prediction changed repeatedly during discovery; instance stopped";return;}
            }
        }
    }
}
void DeformableInstance::PublishStructuralContacts(double h){
    if(h<=0)return;
    struct Patch{BodyHandle body;V impulse{0},weightedPoint{0},moment{0};double weight=0,depth=0;bool swept=false,self=false;};
    std::vector<Patch> patches;patches.reserve(std::min<size_t>(structuralContactRows.size(),256));
    using PatchKey=std::tuple<uint64_t,unsigned,unsigned>;
    std::map<PatchKey,std::vector<size_t>> coincident;
    const double gamma=128*std::numeric_limits<double>::epsilon();
    for(const auto& row:structuralContactRows){
        if(!row.seen)continue;
        const double magnitude=glm::length(row.normalNet);
        if(magnitude<=1e-15||!std::isfinite(magnitude))continue;
        size_t found=patches.size();
        if(!row.self){auto& candidates=coincident[PatchKey{row.body.world,row.body.id,row.sample}];
            for(auto index:candidates){const auto& patch=patches[index];const V point=patch.weightedPoint/patch.weight;const double length=glm::length(patch.impulse);
                if(length<=1e-15||glm::length(row.worldPoint-point)>gamma*(glm::length(row.worldPoint)+glm::length(point)+1)||glm::length(row.normalNet/magnitude-patch.impulse/length)>gamma*2)continue;
                const V nextImpulse=patch.impulse+row.normalNet,nextPoint=(patch.weightedPoint+row.worldPoint*magnitude)/(patch.weight+magnitude),nextMoment=patch.moment+glm::cross(row.worldPoint,row.normalNet);
                const double momentBound=gamma*(glm::length(nextMoment)+glm::length(nextPoint)*glm::length(nextImpulse)+1);
                if(glm::length(glm::cross(nextPoint,nextImpulse)-nextMoment)<=momentBound){found=index;break;}
            }
            if(found==patches.size())candidates.push_back(found);
        }
        if(found==patches.size())patches.push_back({row.body,V(0),V(0),V(0),0,0,false,row.self});
        auto& patch=patches[found];patch.impulse+=row.normalNet;patch.weightedPoint+=row.worldPoint*magnitude;patch.moment+=glm::cross(row.worldPoint,row.normalNet);patch.weight+=magnitude;
        patch.depth=std::max(patch.depth,std::max(0.,-row.gap));patch.swept|=row.swept;
    }
    // Redundant authored primitives can distribute one physical reaction over
    // many valid dual rows. Coalesce only coincident witnesses of the SAME
    // material sample/body before the bounded256 observation selection, with
    // both vector impulse and moment checked. Distant patches and self-contact
    // remain distinct; genuine>256 distinct witnesses still have bounded output.
    for(const auto& patch:patches){const double magnitude=glm::length(patch.impulse);if(magnitude<=1e-15)continue;
        observe(*this,patch.weightedPoint/patch.weight,patch.impulse/magnitude,patch.depth,patch.swept,patch.self,patch.body,magnitude/h);
    }
}
// Balanced trees use rest-space primitive centres only to choose topology. Refit
// includes current and prior substep bounds, so folded/deformed surfaces retain
// exact conservative candidate coverage without cell replication or allocations.
void DeformableInstance::InitializeSurfaceTree(std::vector<SurfaceNode>& tree,bool edge){
    size_t count=edge?asset->edges.size():asset->triangles.size();
    tree.clear();if(!count)return;tree.reserve(count*2-1);
    std::vector<unsigned> indices(count);for(unsigned i=0;i<count;++i)indices[i]=i;
    auto centre=[&](unsigned i){if(edge){auto e=asset->edges[i];return (asset->nodes[e.x]+asset->nodes[e.y])*.5;}auto f=asset->triangles[i];return (asset->nodes[f.x]+asset->nodes[f.y]+asset->nodes[f.z])/3.;};
    auto build=[&](auto&& recurse,size_t begin,size_t end)->unsigned {
        unsigned node=unsigned(tree.size());tree.push_back({});
        if(end-begin==1){tree[node].primitive=indices[begin];return node;}
        V lo(1e300),hi(-1e300);for(size_t i=begin;i<end;++i){lo=glm::min(lo,centre(indices[i]));hi=glm::max(hi,centre(indices[i]));}
        V extent=hi-lo;unsigned axis=extent.y>extent.x?1:0;if(extent.z>extent[axis])axis=2;
        size_t middle=(begin+end)/2;std::nth_element(indices.begin()+begin,indices.begin()+middle,indices.begin()+end,[&](unsigned a,unsigned b){double x=centre(a)[axis],y=centre(b)[axis];return x==y?a<b:x<y;});
        auto left=recurse(recurse,begin,middle),right=recurse(recurse,middle,end);tree[node].left=left;tree[node].right=right;return node;
    };build(build,0,count);
}
void DeformableInstance::BuildSurfaceTree(){
    JUDAS_PROFILE_SCOPE("Deformable surface candidates");
    auto refit=[&](std::vector<SurfaceNode>& tree,bool edge){for(size_t i=tree.size();i-->0;){auto& n=tree[i];
        if(n.primitive!=~0u){n.low=V(1e300);n.high=V(-1e300);auto include=[&](unsigned v){n.low=glm::min(n.low,glm::min(positions[v],start[v]));n.high=glm::max(n.high,glm::max(positions[v],start[v]));};
            if(edge){auto e=asset->edges[n.primitive];include(e.x);include(e.y);}else{auto f=asset->triangles[n.primitive];include(f.x);include(f.y);include(f.z);}
        }else{n.low=glm::min(tree[n.left].low,tree[n.right].low);n.high=glm::max(tree[n.left].high,tree[n.right].high);}
    }};refit(faceTree,false);refit(edgeTree,true);
}
void DeformableInstance::SurfaceCandidates(V low,V high,bool edge,const std::vector<unsigned>* exclusions,unsigned minimum){
    candidates.clear();const auto& tree=edge?edgeTree:faceTree;if(tree.empty())return;
    auto& excluded=edge?edgeExcluded:faceExcluded;
    if(++queryEpoch==0){std::fill(faceExcluded.begin(),faceExcluded.end(),0);std::fill(edgeExcluded.begin(),edgeExcluded.end(),0);++queryEpoch;}
    if(exclusions)for(auto primitive:*exclusions)excluded[primitive]=queryEpoch;
    unsigned stack[64],size=1;stack[0]=0;
    while(size){const auto& n=tree[stack[--size]];if(glm::any(glm::lessThan(high,n.low))||glm::any(glm::greaterThan(low,n.high)))continue;
        if(n.primitive!=~0u){if(n.primitive>=minimum&&excluded[n.primitive]!=queryEpoch)candidates.push_back(n.primitive);}
        else{if(size+2>64){stats.capacityExceeded=true;return;}stack[size++]=n.right;stack[size++]=n.left;}
    }
    std::sort(candidates.begin(),candidates.end());
}
// A Verlet-style conservative pair cache. Both participants may move at most
// skin since construction, so candidate padding is contact thickness + 2*skin.
// Only broadphase work is reused; every material iteration tests current geometry.
void DeformableInstance::PrepareSelfCandidates(){
    PrepareContactEdges();
    JUDAS_PROFILE_SCOPE("Deformable self pair cache");
    double skin=settings.material.thickness*.5;
    bool rebuild=!selfCandidatesValid||selfCandidateTopology!=TopologyRevision();
    if(!rebuild)for(size_t i=0;i<positions.size();++i)if(glm::length(positions[i]-contactReference[i])>skin||glm::length(start[i]-contactStartReference[i])>skin){rebuild=true;break;}
    if(!rebuild)return;
    selfCandidatesValid=true;selfCandidateTopology=TopologyRevision();contactReference=positions;contactStartReference=start;
    selfFacePairs.clear();selfEdgePairs.clear();BuildSurfaceTree();
    double padding=settings.material.thickness*2+skin*2;
    if((asset->fracture||Structural())&&contactExclusionTopology!=TopologyRevision()){
        if(!localExclusions(*this,contactEdgeBeam,contactExcludedFaces,contactExcludedEdges)){stats.capacityExceeded=true;selfCandidatesValid=false;return;}
        contactExclusionTopology=TopologyRevision();
    }
    const auto& excludedFaces=contactExcludedFaces.empty()?asset->excludedFaces:contactExcludedFaces;
    const auto& excludedEdges=contactExcludedEdges.empty()?asset->excludedEdges:contactExcludedEdges;
    auto append=[&](auto& pairs,unsigned x,unsigned y){if(pairs.size()==pairs.capacity()){stats.capacityExceeded=true;selfCandidatesValid=false;return;}pairs.push_back({x,y});};
    for(unsigned n=0;n<positions.size();++n){SurfaceCandidates(glm::min(positions[n],start[n])-V(padding),glm::max(positions[n],start[n])+V(padding),false,&excludedFaces[n]);for(auto f:candidates)append(selfFacePairs,n,f);}
    auto visit=[&](auto&& recurse,unsigned x,unsigned y)->void {
        const auto& a=edgeTree[x];const auto& b=edgeTree[y];
        if(glm::any(glm::lessThan(a.high+V(padding),b.low))||glm::any(glm::greaterThan(a.low-V(padding),b.high)))return;
        bool leafA=a.primitive!=~0u,leafB=b.primitive!=~0u;
        if(leafA&&leafB){unsigned e=a.primitive,f=b.primitive;if(e==f)return;if(e>f)std::swap(e,f);const auto& excluded=excludedEdges[e];if(!std::binary_search(excluded.begin(),excluded.end(),f))append(selfEdgePairs,e,f);return;}
        if(x==y){recurse(recurse,a.left,a.left);recurse(recurse,a.left,a.right);recurse(recurse,a.right,a.right);return;}
        if(!leafA&&(leafB||glm::dot(a.high-a.low,a.high-a.low)>=glm::dot(b.high-b.low,b.high-b.low))){recurse(recurse,a.left,y);recurse(recurse,a.right,y);}else{recurse(recurse,x,b.left);recurse(recurse,x,b.right);}
    };if(!edgeTree.empty())visit(visit,0,0);
}
void DeformableInstance::SurfaceContacts(DeformableInstance& a,DeformableInstance& b,double h){
    JUDAS_PROFILE_SCOPE("Deformable surface contacts");
    bool self=&a==&b;
    if(self&&!a.settings.selfContact)return;
    if((a.settings.collisionMask&CategoryBit(b.settings.collisionLayer))==0||(b.settings.collisionMask&CategoryBit(a.settings.collisionLayer))==0)return;
    a.PrepareContactEdges();if(!self)b.PrepareContactEdges();
    if(self)a.PrepareSelfCandidates();else b.BuildSurfaceTree();
    double thickness=a.settings.material.thickness+b.settings.material.thickness;
    const bool coupledSelf=self&&a.structuralPredictiveCoupling;
    // A cross-instance projector is another physical consumer's impulse.
    // The anchored nonlinear block must preserve that external contribution
    // in its free predictor; otherwise its mass residual would undo contact.
    // This does not touch this instance's own condensed self-contact history.
    if(!self&&((a.structuralPredictiveCoupling&&a.structuralFreePositions.size()!=a.positions.size())||
        (b.structuralPredictiveCoupling&&b.structuralFreePositions.size()!=b.positions.size()))){
        a.error=b.error="external structural contact requires a prepared free predictor";return;
    }
    const auto external=[&](DeformableInstance& instance,unsigned node,V change){
        if(!self&&instance.structuralPredictiveCoupling)instance.structuralFreePositions[node]+=change;
    };
    using SelfKey=std::tuple<unsigned,unsigned,unsigned>;
    std::map<SelfKey,size_t> retained;
    if(coupledSelf)for(size_t i=0;i<a.structuralContactRows.size();++i){auto& row=a.structuralContactRows[i];if(!row.self)continue;row.seen=false;retained.emplace(SelfKey{row.primitive,row.sample,row.otherPrimitive},i);}
    const auto active=[](const StructuralContactRow& row){return row.normalLambda>1e-15||glm::length(row.tangentLambda)>1e-15;};
    auto emit=[&](SelfKey key,glm::uvec3 nodes,V weights,glm::uvec3 other,V otherWeights,V normal,V point,double gap,double oldDepth,bool swept){
        if(!a.error.empty()||!std::isfinite(gap)||glm::dot(normal,normal)<.5)return;
        auto found=retained.find(key);size_t index;
        if(found==retained.end()){
            if(a.structuralContactRows.size()>=65536){a.stats.capacityExceeded=true;a.error="structural contact row capacity exceeded; instance stopped";return;}
            index=a.structuralContactRows.size();a.structuralContactRows.emplace_back();retained.emplace(key,index);
            auto& row=a.structuralContactRows.back();row.self=true;row.primitive=std::get<0>(key);row.sample=std::get<1>(key);row.otherPrimitive=std::get<2>(key);
        }else index=found->second;
        auto& row=a.structuralContactRows[index];row.nodes=nodes;row.weights=weights;row.otherNodes=other;row.otherWeights=otherWeights;
        row.seen=true;row.swept|=swept;row.normal=normal;row.worldPoint=point;row.gap=gap;row.oldDepth=oldDepth;row.startPoint=V(0);
        for(int k=0;k<3;++k)row.startPoint+=a.start[nodes[k]]*weights[k];
        a.stats.maximumPenetration=std::max(a.stats.maximumPenetration,std::max(0.,-gap));
    };
    // A vertex against one edge/vertex is ONE material contact feature,
    // irrespective of which incident surface edge discovered it. Retaining
    // independent cursors for those aliases creates incompatible old planes.
    auto pointPoint=[&](unsigned n,unsigned m){if(n==m)return;if(n>m)std::swap(n,m);
        if(a.asset->fracture&&(a.fracture.removed[a.asset->fracture->nodePart[n]]||a.fracture.removed[a.asset->fracture->nodePart[m]]))return;
        const SelfKey key{3,n,m};const auto old=retained.find(key);const V delta=a.positions[n]-a.positions[m];const double distance=glm::length(delta);
        if((distance>=thickness||distance<1e-12)&&old==retained.end())return;
        if(a.inverseMass[n]+a.inverseMass[m]<1e-20)return;
        const V normal=distance>1e-12?delta/distance:a.structuralContactRows[old->second].normal;
        emit(key,glm::uvec3(n),V(1,0,0),glm::uvec3(m),V(1,0,0),normal,a.positions[m],distance-thickness,std::max(0.,thickness-glm::length(a.start[n]-a.start[m])),false);
    };
    auto pointEdge=[&](unsigned n,unsigned edge){const auto w=a.asset->edges[edge];if(n==w.x||n==w.y||!edgeVisible(a,edge,a.contactEdgeBeam))return;
        if(a.asset->fracture&&a.fracture.removed[a.asset->fracture->nodePart[n]])return;
        const SelfKey key{2,n,edge};const auto old=retained.find(key);const V direction=a.positions[w.y]-a.positions[w.x];const double squared=glm::dot(direction,direction);if(squared<1e-15)return;
        double t=std::clamp(glm::dot(a.positions[n]-a.positions[w.x],direction)/squared,0.,1.);
        if(old!=retained.end()&&active(a.structuralContactRows[old->second]))t=a.structuralContactRows[old->second].otherWeights.y;
        else if(t==0||t==1){pointPoint(n,t==0?w.x:w.y);return;}
        const V point=glm::mix(a.positions[w.x],a.positions[w.y],t),delta=a.positions[n]-point;const double distance=glm::length(delta);
        if((distance>=thickness||distance<1e-12)&&old==retained.end())return;
        if(a.inverseMass[n]+(1-t)*(1-t)*a.inverseMass[w.x]+t*t*a.inverseMass[w.y]<1e-20)return;
        const V normal=distance>1e-12?delta/distance:a.structuralContactRows[old->second].normal;
        const V oldPoint=glm::mix(a.start[w.x],a.start[w.y],t);
        emit(key,glm::uvec3(n),V(1,0,0),{w.x,w.y,w.y},V(1-t,t,0),normal,point,distance-thickness,std::max(0.,thickness-glm::length(a.start[n]-oldPoint)),false);
    };
    {JUDAS_PROFILE_SCOPE("Deformable vertex face contacts");
    auto contact=[&](unsigned n,unsigned t){if(!b.FaceVisible(t))return;auto f=b.asset->triangles[t];
            if(a.asset->fracture&&a.fracture.removed[a.asset->fracture->nodePart[n]])return;
            ++a.stats.candidates;
            V p=a.positions[n],x=b.positions[f.x],y=b.positions[f.y],z=b.positions[f.z],normal=glm::cross(y-x,z-x);
            double len=glm::length(normal);
            if(len<1e-10)return;
            normal/=len;
            V weights=closest(p,x,y,z);
            const auto old=coupledSelf?retained.find(SelfKey{0,n,t}):retained.end();
            // A physical contact manifold refers to actual material points.
            // Moving its barycentric impulse to a different feature while it
            // is accumulated would silently redistribute force. Release this
            // manifold before rediscovering different closest coordinates.
            if(old!=retained.end()&&active(a.structuralContactRows[old->second]))weights=a.structuralContactRows[old->second].otherWeights;
            if(coupledSelf&&(old==retained.end()||!active(a.structuralContactRows[old->second]))){
                unsigned nonzero=0;for(unsigned k=0;k<3;++k)nonzero+=weights[k]!=0;
                if(nonzero==1){for(unsigned k=0;k<3;++k)if(weights[k]!=0)pointPoint(n,f[k]);return;}
                if(nonzero==2){unsigned x=~0u,y=~0u;for(unsigned k=0;k<3;++k)if(weights[k]!=0){if(x==~0u)x=f[k];else y=f[k];}
                    for(unsigned edge=0;edge<a.asset->edges.size();++edge){const auto e=a.asset->edges[edge];if((e.x==x&&e.y==y)||(e.x==y&&e.y==x)){pointEdge(n,edge);return;}}
                }
            }
            V q=x*weights.x+y*weights.y+z*weights.z,delta=p-q;
            double distance=glm::length(delta);
            V oldNormal=glm::cross(b.start[f.y]-b.start[f.x],b.start[f.z]-b.start[f.x]);
            double oldLength=glm::length(oldNormal);
            double oldSide=oldLength>1e-10?glm::dot(a.start[n]-b.start[f.x],oldNormal/oldLength):glm::dot(delta,normal);
            double side=glm::dot(delta,normal);
            bool crossed=oldSide*side<0&&weights.x>1e-8&&weights.y>1e-8&&weights.z>1e-8;
            if(distance>=thickness&&!crossed&&old==retained.end())return;
            if(crossed)normal*=oldSide>=0?1.:-1.;
            else normal=distance>1e-10?delta/distance:normal*(oldSide>=0?1.:-1.);
            double gap=glm::dot(delta,normal),den=a.inverseMass[n];
            for(int k=0;k<3;++k)den+=b.inverseMass[f[k]]*weights[k]*weights[k];
            if(den<1e-20)return;
            if(coupledSelf){const V oldPoint=b.start[f.x]*weights.x+b.start[f.y]*weights.y+b.start[f.z]*weights.z;
                emit({0,n,t},glm::uvec3(n),V(1,0,0),f,weights,normal,q,gap-thickness,std::max(0.,thickness-glm::length(a.start[n]-oldPoint)),crossed);return;}
            double impulse=(thickness-gap)/den;
            V correction=normal*impulse*a.inverseMass[n];
            a.positions[n]+=correction;
            external(a,n,correction);
            if(!self){a.velocities[n]+=correction/h;
                a.Wake();
                b.Wake();
                }for(int k=0;k<3;++k){V other=-normal*impulse*b.inverseMass[f[k]]*weights[k];
                b.positions[f[k]]+=other;
                external(b,f[k],other);
                if(!self)b.velocities[f[k]]+=other/h;
                }observe(a,q,normal,std::max(0.,thickness-gap),crossed,self,{},impulse/h);

    };
    if(self){std::set<std::pair<unsigned,unsigned>> visited;for(auto pair:a.selfFacePairs){contact(pair.x,pair.y);if(coupledSelf)visited.emplace(pair.x,pair.y);}
        if(coupledSelf){std::vector<std::pair<unsigned,unsigned>> previous;for(const auto& entry:retained)if(std::get<0>(entry.first)==0)previous.emplace_back(std::get<1>(entry.first),std::get<2>(entry.first));for(auto pair:previous)if(visited.emplace(pair).second)contact(pair.first,pair.second);}}
    else for(unsigned n=0;n<a.positions.size();++n){b.SurfaceCandidates(glm::min(a.positions[n],a.start[n])-V(thickness),glm::max(a.positions[n],a.start[n])+V(thickness),false);for(unsigned f:b.candidates)contact(n,f);}
    }
    {JUDAS_PROFILE_SCOPE("Deformable edge edge contacts");
    // Traverse tree pairs once, rather than issuing one complete BVH query for
    // every edge. Identical subtree pairs visit only their upper triangle.
    if(!self){b.BuildSurfaceTree();a.BuildSurfaceTree();}
    auto contact=[&](unsigned e,unsigned j){if(!edgeVisible(a,e,a.contactEdgeBeam)||!edgeVisible(b,j,b.contactEdgeBeam))return;if(self){if(e==j)return;if(e>j)std::swap(e,j);}
        auto v=a.asset->edges[e],w=b.asset->edges[j];if(a.asset->fracture&&a.fracture.removed[a.asset->fracture->nodePart[v.x]])return;if(b.asset->fracture&&b.fracture.removed[b.asset->fracture->nodePart[w.x]])return;++a.stats.candidates;
            auto [s,t]=segments(a.positions[v.x],a.positions[v.y],b.positions[w.x],b.positions[w.y]);
            const auto old=coupledSelf?retained.find(SelfKey{1,e,j}):retained.end();
            if(old!=retained.end()&&active(a.structuralContactRows[old->second])){s=a.structuralContactRows[old->second].weights.y;t=a.structuralContactRows[old->second].otherWeights.y;}
            if(coupledSelf&&(old==retained.end()||!active(a.structuralContactRows[old->second]))){
                const bool endpointA=s==0||s==1,endpointB=t==0||t==1;
                if(endpointA&&endpointB){pointPoint(s==0?v.x:v.y,t==0?w.x:w.y);return;}
                if(endpointA){pointEdge(s==0?v.x:v.y,j);return;}
                if(endpointB){pointEdge(t==0?w.x:w.y,e);return;}
            }
            V delta=glm::mix(a.positions[v.x],a.positions[v.y],s)-glm::mix(b.positions[w.x],b.positions[w.y],t);
            double d=glm::length(delta);
            if((d>=thickness&&old==retained.end())||(d<1e-12&&old==retained.end()))return;
            V normal=d>1e-12?delta/d:a.structuralContactRows[old->second].normal;
            double den=a.inverseMass[v.x]*(1-s)*(1-s)+a.inverseMass[v.y]*s*s+b.inverseMass[w.x]*(1-t)*(1-t)+b.inverseMass[w.y]*t*t;
            if(den<1e-20)return;
            if(coupledSelf){const V point=glm::mix(b.positions[w.x],b.positions[w.y],t);const double oldDistance=glm::length(glm::mix(a.start[v.x],a.start[v.y],s)-glm::mix(b.start[w.x],b.start[w.y],t));
                emit({1,e,j},{v.x,v.y,v.y},V(1-s,s,0),{w.x,w.y,w.y},V(1-t,t,0),normal,point,d-thickness,std::max(0.,thickness-oldDistance),false);return;}
            double dl=(thickness-d)/den;
            V ca=normal*dl*a.inverseMass[v.x]*(1-s),cb=normal*dl*a.inverseMass[v.y]*s,cc=-normal*dl*b.inverseMass[w.x]*(1-t),cd=-normal*dl*b.inverseMass[w.y]*t;
            a.positions[v.x]+=ca;
            a.positions[v.y]+=cb;
            b.positions[w.x]+=cc;
            b.positions[w.y]+=cd;
            external(a,v.x,ca);external(a,v.y,cb);external(b,w.x,cc);external(b,w.y,cd);
            if(!self){a.velocities[v.x]+=ca/h;
                a.velocities[v.y]+=cb/h;
                b.velocities[w.x]+=cc/h;
                b.velocities[w.y]+=cd/h;
                a.Wake();
                b.Wake();
                }observe(a,glm::mix(b.positions[w.x],b.positions[w.y],t),normal,thickness-d,false,self,{},dl/h);

    };
    auto visit=[&](auto&& recurse,unsigned x,unsigned y)->void {
        const auto& left=a.edgeTree[x];const auto& right=b.edgeTree[y];
        if(glm::any(glm::lessThan(left.high+V(thickness),right.low))||glm::any(glm::greaterThan(left.low-V(thickness),right.high)))return;
        bool leafA=left.primitive!=~0u,leafB=right.primitive!=~0u;
        if(leafA&&leafB){contact(left.primitive,right.primitive);return;}
        if(self&&x==y){recurse(recurse,left.left,left.left);recurse(recurse,left.left,left.right);recurse(recurse,left.right,left.right);return;}
        if(!leafA&&(leafB||glm::dot(left.high-left.low,left.high-left.low)>=glm::dot(right.high-right.low,right.high-right.low))){recurse(recurse,left.left,y);recurse(recurse,left.right,y);}
        else{recurse(recurse,x,right.left);recurse(recurse,x,right.right);}
    };if(self){std::set<std::pair<unsigned,unsigned>> visited;for(auto pair:a.selfEdgePairs){contact(pair.x,pair.y);if(coupledSelf)visited.emplace(pair.x,pair.y);}
        if(coupledSelf){std::vector<std::pair<unsigned,unsigned>> previous;for(const auto& entry:retained)if(std::get<0>(entry.first)==1)previous.emplace_back(std::get<1>(entry.first),std::get<2>(entry.first));for(auto pair:previous)if(visited.emplace(pair).second)contact(pair.first,pair.second);}}
        else if(!a.edgeTree.empty()&&!b.edgeTree.empty())visit(visit,0,0);
    }
    if(coupledSelf){std::vector<SelfKey> previous;for(const auto& entry:retained)if(std::get<0>(entry.first)>=2)previous.push_back(entry.first);
        for(const auto& key:previous){if(std::get<0>(key)==2)pointEdge(std::get<1>(key),std::get<2>(key));else pointPoint(std::get<1>(key),std::get<2>(key));}
    }
    // External pairs resolve once at the fixed-step coupling boundary; self
    // contact is substepped. Apply the same positional delta to velocity once.
    (void)h;
}
