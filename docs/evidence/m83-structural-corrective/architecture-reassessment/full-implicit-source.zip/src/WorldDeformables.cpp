#include "RuntimeWorld.h"
#include "ResourceManager.h"
#include "PoseComposition.h"
#include "SaveArchive.h"
#include "SceneFingerprint.h"
#include "PerformanceProfiler.h"
#include "WorldPresentation.h"
#include "ContactSolver.h"
#include <atomic>
#include <algorithm>
#include <fstream>
#include <glm/gtc/matrix_transform.hpp>
namespace {
std::atomic<uint64_t> epochs{1};
constexpr const char* stateHeader="Judas.DeformableState.1\n";
constexpr const char* strengthStateHeader="Judas.DeformableState.2\n";
constexpr const char* structuralStateHeader="Judas.DeformableState.3\n";
glm::dmat4 matrix(const SceneTransform& t){return glm::translate(glm::dmat4(1),glm::dvec3(t.position))*glm::mat4_cast(glm::dquat(t.rotation));
        }
}
DeformableInstance* RuntimeWorld::RuntimeDeformable(EntityId id,std::string& error,bool staged){
    // Only residency restoration may prepare a pending owner. Script access
    // always uses the published path and cannot obtain a private region handle.
    auto pending=m_scriptDefinitions.find(id);
    const auto* definition=staged&&m_regionPending.count(id)&&pending!=m_scriptDefinitions.end()?&pending->second:RuntimeDefinition(id);
    if(!definition||!definition->deformable){error="stale entity/no deformable";
        return nullptr;
        }
    if(auto it=m_deformables.find(id);it!=m_deformables.end()){error=it->second.simulation.error;
        return &it->second.simulation;
        }
    if(!m_assets){error="deformable resource service unavailable";
        return nullptr;
        }auto asset=m_assets->GetDeformable(definition->deformable->asset,error);
    if(!asset)return nullptr;
    if((asset->fracture||asset->structure)&&(definition->liquidBasin||definition->liquidContainer||definition->liquidConnection)){error="liquid-bearing fractured/structural geometry unsupported; remove fracture or conserved liquid component";return nullptr;}
    if(!asset->sourceAsset.empty()){
        const auto* source=m_assets->Assets()->Find(asset->sourceAsset);
        std::string digest;
        if(!source||!SceneFingerprintSha256File(source->path,digest,error)||digest!=asset->sourceFingerprint){error="stale deformable binding: rebake source "+asset->sourceAsset;
            return nullptr;
            }
    }
    // A bone resource may publish after the cloth. Defer construction instead
    // of mistaking asynchronous startup for a permanently destroyed target.
    for(const auto& attachment:definition->deformable->attachments)if(attachment.enabled&&attachment.kind==DeformableAttachment::Kind::Bone){
        const auto* target=RuntimeDefinition(attachment.target);
        if(target&&target->animation&&target->render){auto* animation=RuntimeAnimation(attachment.target);if(!animation||!animation->asset){error="loading";return nullptr;}}
    }
    for(auto& a:definition->deformable->attachments)if(!asset->groups.count(a.group)){error="deformable attachment group not found: "+a.group;
        return nullptr;
        }
    auto& record=m_deformables[id];
    try{record.simulation.Initialize(asset,*definition->deformable,matrix(definition->transform),epochs.fetch_add(1));}
    catch(const std::exception& failure){error=failure.what();m_deformables.erase(id);return nullptr;}
    record.targets.resize(definition->deformable->attachments.size());
    error.clear();
    return &record.simulation;
}
void RuntimeWorld::SampleDeformableTargets(EntityId id,bool interval,float predictionSeconds){
    auto& record=m_deformables.at(id);auto* simulation=&record.simulation;
        record.targets.resize(simulation->settings.attachments.size());
        for(size_t i=0;i<simulation->settings.attachments.size();++i){auto& a=simulation->settings.attachments[i];
            auto& t=record.targets[i];
            glm::dmat4 current(1);
            bool valid=true;
            if(a.kind==DeformableAttachment::Kind::World){t.body={};current=matrix(RuntimeDefinition(id)->transform);
                }
            else{auto* d=RuntimeDefinition(a.target);
                if(!d||!IsPublished(a.target))valid=false;
                else{current=matrix(PresentedTransform(a.target,d->transform,1));
                    if(a.kind==DeformableAttachment::Kind::Body){t.body=RuntimeBody(a.target);
                        valid=m_physics.IsBodyEnabled(t.body);
                        if(interval&&valid){auto pose=predictionSeconds>0?m_physics.PredictTransform(t.body,predictionSeconds):m_physics.GetTransform(t.body);SceneTransform physical;physical.position=pose.position;physical.rotation=pose.rotation;current=matrix(physical);}
                        }else{t.body={};
                        auto* animation=RuntimeAnimation(a.target);
                        if(!animation||!animation->asset||!d->animation->enabled)valid=false;
                        else{int joint=FindSkeletonJoint(animation->asset->skeleton,a.joint);
                            if(joint<0)valid=false;
                            else if(animation->recentWorld.size()!=animation->asset->skeleton.parents.size())valid=false;
                            else{current=glm::dmat4(animation->recentWorld[joint]);
                                }}}}
            }
            if(valid){t.previous=t.valid?t.current:current;
                if(predictionSeconds>0&&a.kind==DeformableAttachment::Kind::Body){auto p=m_physics.GetPreviousTransform(t.body);SceneTransform previousPose;previousPose.position=p.position;previousPose.rotation=p.rotation;t.previous=matrix(previousPose);}
                if(interval&&!t.valid&&a.kind==DeformableAttachment::Kind::Body&&m_physics.IsBodyEnabled(t.body)){auto p=m_physics.GetPreviousTransform(t.body);SceneTransform previousPose;previousPose.position=p.position;previousPose.rotation=p.rotation;t.previous=matrix(previousPose);}
                t.current=current;
                }t.valid=valid;
            if(!valid&&!simulation->released[i])simulation->released[i]=true;
             // lost target releases, never aliases a new body
        }
}
unsigned RuntimeWorld::StructuralSubsteps(){
    unsigned count=1;
    for(auto id:m_deformableOwners)if(IsPublished(id)){std::string error;auto* s=RuntimeDeformable(id,error);
        if(s&&s->Structural()&&s->settings.enabled&&s->error.empty())count=std::max(count,s->settings.substeps);}
    return count;
}
unsigned RuntimeWorld::StructuralIterations(){
    unsigned count=0;
    for(auto id:m_deformableOwners)if(IsPublished(id)){std::string error;auto* s=RuntimeDeformable(id,error);
        if(s&&s->Structural()&&s->settings.enabled&&s->error.empty())count=std::max(count,s->settings.iterations);}
    return count;
}
PhysicsWorld::VelocityCoupling RuntimeWorld::StructuralVelocityCoupling(unsigned& interval,unsigned intervals){
    auto active=std::make_shared<std::vector<EntityId>>();
    PhysicsWorld::VelocityCoupling phase;phase.iterations=std::max(1u,StructuralIterations());
    const auto rounds=std::max(unsigned(ContactSolver::kVelocityIterations),phase.iterations);
    phase.begin=[this,active,&interval,intervals,rounds](float h){
        active->clear();
        for(auto id:m_deformableOwners)if(IsPublished(id)){std::string error;auto* s=RuntimeDeformable(id,error);
            if(!s||!s->Structural()||!s->settings.enabled||!s->error.empty())continue;
            auto& record=m_deformables.at(id);SampleDeformableTargets(id,true,h);
            if(s->BeginStructuralInterval(h,m_physics,GravityForEntity(id),record.targets,interval==0,true)){
                if(!s->sleeping)for(size_t i=0;i<s->settings.attachments.size();++i)if(s->settings.attachments[i].enabled&&!s->released[i]&&record.targets[i].valid)m_physics.PreparePredictedBody(record.targets[i].body,h);
                s->stats.iterations=rounds;active->push_back(id);
            }
            record.coupledThisStep=true;++record.revision;
        }
    };
    phase.solve=[this,active](float h,unsigned){
        // Resolve all unilateral material contacts before the shared beam/pin
        // compatibility solve. A final post-solve projection would change the
        // accepted strain without the corresponding constitutive reaction.
        for(auto id:*active){auto& record=m_deformables.at(id);record.simulation.SolveStructuralContacts(h,m_physics,record.targets);}
        for(size_t a=0;a<active->size();++a)for(size_t b=a+1;b<active->size();++b){auto& x=m_deformables.at((*active)[a]).simulation;auto& y=m_deformables.at((*active)[b]).simulation;
            if(!x.error.empty()||!y.error.empty())continue;
            const auto padding=glm::dvec3(x.settings.material.thickness+y.settings.material.thickness);
            glm::dvec3 xl=x.Minimum(),xh=x.Maximum(),yl=y.Minimum(),yh=y.Maximum();
            for(auto p:x.previous){xl=glm::min(xl,p);xh=glm::max(xh,p);}
            for(auto p:y.previous){yl=glm::min(yl,p);yh=glm::max(yh,p);}
            if(glm::any(glm::lessThan(xh+padding,yl))||glm::any(glm::lessThan(yh+padding,xl)))continue;
            DeformableInstance::SurfaceContacts(x,y,h);DeformableInstance::SurfaceContacts(y,x,h);
        }
        for(auto id:*active){auto& record=m_deformables.at(id);record.simulation.SolveStructuralIteration(h,m_physics,record.targets);}
    };
    phase.finish=[this,active,&interval,intervals](float h){
        for(auto id:*active)m_deformables.at(id).simulation.EndStructuralInterval(h,m_physics,interval+1==intervals);
    };
    return phase;
}
void RuntimeWorld::AdvanceStructuralInterval(double dt,unsigned interval,unsigned intervals){
    JUDAS_PROFILE_SCOPE("Coupled structural material");
    std::vector<DeformableRecord*> active;
    std::vector<std::pair<glm::dvec3,glm::dvec3>> initialBounds;
    unsigned iterations=0;
    for(auto id:m_deformableOwners)if(IsPublished(id)){std::string error;auto* s=RuntimeDeformable(id,error);
        if(!s||!s->Structural()||!s->settings.enabled||!s->error.empty())continue;
        auto& record=m_deformables.at(id);SampleDeformableTargets(id,true);
        const auto bounds=std::make_pair(s->Minimum(),s->Maximum());
        if(s->BeginStructuralInterval(dt,m_physics,GravityForEntity(id),record.targets,interval==0)){
            active.push_back(&record);initialBounds.push_back(bounds);iterations=std::max(iterations,s->settings.iterations);
        }
        record.coupledThisStep=true;++record.revision;
    }
    // Resolve all participants before accepting plastic work or failure. A
    // post-accept pair correction otherwise publishes member geometry whose
    // new load was never evaluated at this boundary. One deterministic round
    // uses the highest requested quality, so no participant is under-solved.
    for(auto* record:active)record->simulation.stats.iterations=iterations;
    for(unsigned iteration=0;iteration<iterations;++iteration){
        for(auto* record:active)record->simulation.SolveStructuralContacts(dt,m_physics,record->targets);
        for(size_t a=0;a<active.size();++a)for(size_t b=a+1;b<active.size();++b){auto& x=active[a]->simulation;auto& y=active[b]->simulation;
            if(!x.error.empty()||!y.error.empty())continue;
            const auto radius=x.settings.material.thickness+y.settings.material.thickness;
            const glm::dvec3 xl=glm::min(x.Minimum(),initialBounds[a].first),xh=glm::max(x.Maximum(),initialBounds[a].second);
            const glm::dvec3 yl=glm::min(y.Minimum(),initialBounds[b].first),yh=glm::max(y.Maximum(),initialBounds[b].second);
            if(glm::any(glm::lessThan(xh+glm::dvec3(radius),yl))||glm::any(glm::lessThan(yh+glm::dvec3(radius),xl)))continue;
            DeformableInstance::SurfaceContacts(x,y,dt);DeformableInstance::SurfaceContacts(y,x,dt);
        }
        for(auto* record:active)record->simulation.SolveStructuralIteration(dt,m_physics,record->targets);
    }
    for(auto* record:active)record->simulation.EndStructuralInterval(dt,m_physics,interval+1==intervals);
}
void RuntimeWorld::UpdateDeformables(double dt){
    if(m_deformableOwners.empty())return;
    JUDAS_PROFILE_SCOPE("World deformables");
    // A one-interval world still requires contact-before-material-acceptance.
    // Multi-interval Simulation has already completed this phase and marks
    // every participant; the ordinary one-interval path arrives here unmarked.
    bool structuralPending=false;
    for(auto id:m_deformableOwners)if(IsPublished(id)){
        std::string error;auto* s=RuntimeDeformable(id,error);
        if(s&&s->Structural()&&s->settings.enabled&&s->error.empty()&&!m_deformables.at(id).coupledThisStep){structuralPending=true;break;}
    }
    if(structuralPending)AdvanceStructuralInterval(dt,0,1);
    bool coupled=false;
    for(auto id:m_deformableOwners){if(!IsPublished(id))continue;
        std::string error;
        auto* simulation=RuntimeDeformable(id,error);
        if(!simulation)continue;
        auto& record=m_deformables.at(id);
        if(record.coupledThisStep){record.coupledThisStep=false;coupled=true;continue;}
        SampleDeformableTargets(id);
        if(simulation->asset->fracture&&simulation->asset->fracture->rigid){
            if(!record.rigid.initialized&&!m_restoreConstruction){std::string prepareError;if(!PrepareRigidFracture(id,prepareError)){simulation->error=prepareError;continue;}}
            if(record.rigid.initialized)UpdateRigidFracture(id,dt);
        }else simulation->Step(dt,m_physics,GravityForEntity(id),record.targets);
        if(simulation->asset->fracture&&!simulation->asset->fracture->rigid&&simulation->settings.enabled)simulation->fracture.Commit(*simulation->asset->fracture);
        ++record.revision;
    }
    for(auto a=m_deformables.begin();a!=m_deformables.end();++a)for(auto b=std::next(a);b!=m_deformables.end();++b){auto& x=a->second.simulation;
        auto& y=b->second.simulation;
        if(coupled&&x.Structural()&&y.Structural())continue;
        if((x.asset->fracture&&x.asset->fracture->rigid)||(y.asset->fracture&&y.asset->fracture->rigid)||!x.settings.enabled||!y.settings.enabled||!x.error.empty()||!y.error.empty()||!IsPublished(a->first)||!IsPublished(b->first))continue;
        double thickness=x.settings.material.thickness+y.settings.material.thickness;
        if(glm::any(glm::lessThan(x.Maximum()+glm::dvec3(thickness),y.Minimum()))||glm::any(glm::lessThan(y.Maximum()+glm::dvec3(thickness),x.Minimum())))continue;
        DeformableInstance::SurfaceContacts(x,y,dt);
        DeformableInstance::SurfaceContacts(y,x,dt);
        }
}
void RuntimeWorld::DrawDeformables(Renderer& renderer,float alpha)const{
    for(auto& [id,record]:m_deformables){const auto* d=RuntimeDefinition(id);
        if(!d||!d->deformable||!IsPublished(id)||!RenderVisible(id)||!record.simulation.settings.enabled)continue;
        auto& sim=record.simulation;
        if(record.mappedRevision!=record.revision||record.mappedAlpha!=alpha){
            sim.MapRender(alpha,record.presentation);
            if(!record.mesh.IsValid())record.mesh=renderer.CreateMesh(record.presentation);
            else if(record.meshTopology!=sim.TopologyRevision()){renderer.DestroyMesh(record.mesh);record.mesh=renderer.CreateMesh(record.presentation);}
            else renderer.UpdateMeshVertices(record.mesh,record.presentation.vertices);
            record.meshTopology=sim.TopologyRevision();
            record.mappedRevision=record.revision;record.mappedAlpha=alpha;
        }
        // An empty indexed topology is an absent physical skin, not a
        // nonindexed triangle soup made from the unused original vertices.
        if((sim.Structural()||sim.asset->fracture)&&record.presentation.indices.empty())continue;
        renderer.SetRenderLayer(RenderLayerOf(id));
        renderer.SetMaterialBindings(d->render?BuildRenderMaterialBindings(m_assets,*d->render):std::vector<MaterialBinding>{});
        auto texture=d->render&&m_assets?m_assets->TryGetTexture(d->render->textureAsset):TextureHandle{};
        renderer.DrawMesh(record.mesh,glm::vec3(0),glm::quat(1,0,0,0),glm::vec3(1),texture,d->render?d->render->color:glm::vec3(.5f,.6f,.8f),d->render?d->render->alpha:1.f,nullptr,d->render?&d->render->hiddenParts:nullptr);
    }
}
void RuntimeWorld::RemoveDeformable(EntityId id){auto it=m_deformables.find(id);
    if(it==m_deformables.end())return;
    auto children=it->second.rigid.parts;
    for(auto joint:it->second.rigid.bonds)m_physics.DestroyJoint(joint);
    for(auto joint:it->second.rigid.supports)m_physics.DestroyJoint(joint);
    if(m_assets&&m_assets->GetRenderer()&&it->second.mesh.IsValid())m_assets->GetRenderer()->DestroyMesh(it->second.mesh);
    m_deformables.erase(it);
    for(auto child:children)if(child&&RuntimeDefinition(child))DestroyEntity(child);
    }
void RuntimeWorld::ClearDeformables(){while(!m_deformables.empty())RemoveDeformable(m_deformables.begin()->first);
    }
void RuntimeWorld::InvalidateDeformableTargets(EntityId id){auto it=m_deformables.find(id);if(it!=m_deformables.end())it->second.targets.clear();}
bool RuntimeWorld::ResetDeformable(EntityId id,std::string& error){auto* s=RuntimeDeformable(id,error);
    if(!s)return false;
    if(s->asset->fracture||s->Structural()){error="structural damage is irreversible; reload the authored scene";return false;}
    s->Reset(matrix(RuntimeDefinition(id)->transform));
    ++m_deformables.at(id).revision;
    for(auto& t:m_deformables.at(id).targets)t.valid=false;
    return true;
    }
bool RuntimeWorld::CaptureDeformable(EntityId id,std::string& bytes,std::string& error){auto* s=RuntimeDeformable(id,error);
    if(!s)return false;
    try{SaveArchive a;
        const bool strengths=std::any_of(s->settings.attachments.begin(),s->settings.attachments.end(),[](const auto& attachment){return attachment.forceLimit>0||attachment.torqueLimit>0;});
        s->Persist(a,true,strengths||s->Structural(),s->Structural());
        if(s->asset->fracture&&s->asset->fracture->rigid)PersistRigidFracture(id,a);
        bytes=(s->Structural()?structuralStateHeader:strengths?strengthStateHeader:stateHeader)+std::move(a.bytes);
        return true;
        }catch(const std::exception& e){error=e.what();
        return false;
        }}
bool RuntimeWorld::RestoreDeformable(EntityId id,const std::string& bytes,std::string& error,bool staged){auto* s=RuntimeDeformable(id,error,staged);
    if(!s)return false;
    try{const bool structural=bytes.rfind(structuralStateHeader,0)==0;
        const bool strengths=structural||bytes.rfind(strengthStateHeader,0)==0;
        const bool framed=strengths||bytes.rfind(stateHeader,0)==0;
        if(bytes.rfind("Judas.DeformableState.",0)==0&&!framed)throw std::runtime_error("unsupported deformable state version");
        SaveArchive a(framed?bytes.substr(std::char_traits<char>::length(stateHeader)):bytes);
        s->Persist(a,framed,strengths,structural);
        if(s->asset->fracture&&s->asset->fracture->rigid)PersistRigidFracture(id,a);
        a.Finish();
        ++m_deformables.at(id).revision;m_deformables.at(id).meshTopology=~uint64_t(0);
        for(auto& t:m_deformables.at(id).targets)t.valid=false;
        return true;
        }catch(const std::exception& e){error=e.what();
        return false;
        }}

void RuntimeWorld::SetDeformableEnabled(EntityId id,bool enabled){auto it=m_deformables.find(id);if(it==m_deformables.end())return;auto& s=it->second.simulation;if(s.settings.enabled==enabled)return;s.settings.enabled=enabled;s.Wake();for(auto child:it->second.rigid.parts)if(RuntimeDefinition(child))SetColliderEnabled(child,enabled);}
