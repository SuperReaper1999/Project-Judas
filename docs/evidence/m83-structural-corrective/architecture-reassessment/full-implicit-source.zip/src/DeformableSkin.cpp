#include "Deformable.h"
#include "PerformanceProfiler.h"
#include <algorithm>
#include <cmath>
namespace {using V=glm::dvec3;}
void DeformableInstance::MapRender(double alpha,MeshData& mesh)const{
    JUDAS_PROFILE_SCOPE("Deformable render mapping");
    if(mesh.vertices.size()!=asset->render.vertices.size())mesh=asset->render;
    alpha=std::clamp(alpha,0.,1.);
    if(asset->fracture){mesh.indices.clear();mesh.primitives.clear();for(int material=0;material<2;++material){unsigned first=unsigned(mesh.indices.size());for(unsigned f=0;f<asset->triangles.size();++f)if(FaceVisible(f)&&(asset->fracture->faceBond[f]<0?0:1)==material)for(unsigned k=0;k<3;++k)mesh.indices.push_back(f*3+k);unsigned count=unsigned(mesh.indices.size())-first;if(count)mesh.primitives.push_back({first,count,material});}}
    if(Structural()){
        mesh.indices.clear();mesh.primitives.clear();
        auto visible=[&](unsigned triangle){
            const auto face=asset->structure->renderSurfaces[triangle];
            if(!FaceVisible(face))return false;
            const auto physical=asset->triangles[face];
            const auto component=structure.component[physical.x];
            // Authoring seams bound each visible triangle to one surviving
            // local component. A break never averages vertices across a gap.
            for(unsigned k=0;k<3;++k){const auto& b=asset->binding[asset->render.indices[triangle*3+k]];
                for(unsigned n=0;n<4;++n)if(b.weights[n]>1e-12&&structure.component[b.nodes[n]]!=component)return false;
            }
            return true;
        };
        auto append=[&](unsigned first,unsigned count,int material){
            const auto outputFirst=unsigned(mesh.indices.size());
            for(unsigned i=first;i<first+count;i+=3)if(visible(i/3))for(unsigned k=0;k<3;++k)mesh.indices.push_back(asset->render.indices[i+k]);
            const auto outputCount=unsigned(mesh.indices.size())-outputFirst;
            if(outputCount)mesh.primitives.push_back({outputFirst,outputCount,material});
        };
        if(asset->render.primitives.empty())append(0,unsigned(asset->render.indices.size()),0);
        else for(const auto& primitive:asset->render.primitives)append(primitive.first,primitive.count,primitive.material);
    }
    for(size_t i=0;i<mesh.vertices.size();++i){auto b=asset->binding[i];
        V p(0);
        for(int k=0;k<4;++k)p+=glm::mix(previous[b.nodes[k]],positions[b.nodes[k]],alpha)*b.weights[k];
        mesh.vertices[i].position=glm::vec3(p);
        mesh.vertices[i].normal=glm::vec3(0);
        mesh.vertices[i].tangent=glm::vec4(0);
        }
    for(size_t i=0;i<mesh.indices.size();i+=3){auto ia=mesh.indices[i],ib=mesh.indices[i+1],ic=mesh.indices[i+2];
        auto& a=mesh.vertices[ia];
        auto& b=mesh.vertices[ib];
        auto& c=mesh.vertices[ic];
        auto e1=b.position-a.position,e2=c.position-a.position;
        auto normal=glm::cross(e1,e2);
        auto uv1=b.uv-a.uv,uv2=c.uv-a.uv;
        float den=uv1.x*uv2.y-uv1.y*uv2.x;
        glm::vec3 tangent=std::abs(den)>1e-10f?(e1*uv2.y-e2*uv1.y)/den:glm::vec3(1,0,0);
        for(auto n:{ia,ib,ic}){mesh.vertices[n].normal+=normal;
            mesh.vertices[n].tangent+=glm::vec4(tangent,(den<0?-1.f:1.f)*glm::length(normal));
            }}
    for(auto& v:mesh.vertices){if(glm::length(v.normal)>1e-9f)v.normal=glm::normalize(v.normal);
        glm::vec3 tangent=glm::vec3(v.tangent)-v.normal*glm::dot(v.normal,glm::vec3(v.tangent));
        if(glm::length(tangent)>1e-9f)tangent=glm::normalize(tangent);
        v.tangent=glm::vec4(tangent,v.tangent.w<0?-1.f:1.f);
        }
}
