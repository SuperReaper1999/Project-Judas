#pragma once
#include <glm/glm.hpp>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>
class SaveArchive;
struct DeformableAsset;

// A structural region supplies a one-dimensional elastic/plastic law. Units
// are SI: modulus/strength/hardening Pa, damping N s/m and section area m².
// Plastic capacities are fractions of the immutable authored beam length.
struct StructuralRegion {
    std::string key;
    double youngModulus=2e8,damping=100;
    double tensionYield=2e6,compressionYield=2e6;
    double tensionUltimate=2e7,compressionUltimate=2e7,hardening=1e6;
    double maxShortening=.6,maxExtension=.08,panelThickness=.001;
    void Save(SaveArchive&);
};
struct StructuralBeam {
    std::string key;
    unsigned a=0,b=0,region=0;
    double area=.0001,restLength=0; // restLength is derived from authored nodes.
    void Save(SaveArchive&);
};
struct StructuralCook {
    std::vector<StructuralRegion> regions;
    std::vector<StructuralBeam> beams;
    std::vector<unsigned> surfaceRegions;
    std::vector<std::vector<unsigned>> surfaceSupports;
    // One physical surface per render triangle. Deliberate panel seams keep
    // visible triangles local when the surviving physical graph separates.
    std::vector<unsigned> renderSurfaces;
    void Save(SaveArchive&);
};
bool PrepareStructuralCook(DeformableAsset&,std::string&);
bool ImportStructuralNetwork(const std::string&,DeformableAsset&,std::string&);
// Diagonally preconditioned SPD Schur solve. Its bound follows the actual row
// dimension, independent of the authored nonlinear/contact iteration count.
bool SolveStructuralSchur(const std::vector<double>& diagonal,const std::vector<double>& rhs,
    const std::function<void(const std::vector<double>&,std::vector<double>&)>& multiply,
    std::vector<double>& solution,unsigned& iterations,double& residual);
// Equivalent primal SPD solve with a reusable Cholesky preconditioner. Pin
// elimination removes redundant multiplier rows; no material is softened.
bool SolveStructuralPrimal(const std::vector<double>& matrix,const std::vector<double>& rhs,
    std::vector<double>& factor,std::vector<double>& solution,unsigned& iterations,double& residual);
struct StructuralPrimalTraversal {
    size_t count=0;
    bool ready=false;
    std::vector<size_t> lowerRows,lowerColumns,upperRows,upperColumns;
    std::vector<double> lowerValues,upperValues;
    void Clear(){ready=false;count=0;lowerRows.clear();lowerColumns.clear();upperRows.clear();upperColumns.clear();lowerValues.clear();upperValues.clear();}
};
// One frozen operator can serve the member correction and several contact
// response columns. Sparse traversal omits EXACT zeros only; equations and
// true-residual acceptance are identical to the dense reference.
class StructuralPrimalSolver {
    const std::vector<double>& matrix;
    std::vector<double>& factor;
    size_t count=0;
    bool valid=false;
    std::vector<size_t> rows,columns;
    StructuralPrimalTraversal localTraversal;
    StructuralPrimalTraversal* traversal=nullptr;
    std::function<double(const std::vector<double>&)> residualNorm;
    bool Factorize();
    void PrepareFactorTraversal();
    void Multiply(const std::vector<double>&,std::vector<double>&)const;
    void Precondition(const std::vector<double>&,std::vector<double>&)const;
    double Norm(const std::vector<double>&)const;
public:
    StructuralPrimalSolver(const std::vector<double>&,std::vector<double>&,StructuralPrimalTraversal* retained=nullptr,
        std::function<double(const std::vector<double>&)> physicalResidualNorm={});
    bool Solve(const std::vector<double>&,std::vector<double>&,unsigned&,double&);
};

// Matrix-free nonsymmetric physical Newton solve. Right preconditioning is
// numerical only; rank-deficient incompatible systems fail without compliance.
bool SolveStructuralNewtonKrylov(const std::vector<double>& rhs,
    const std::function<bool(const std::vector<double>&,std::vector<double>&)>& action,
    const std::function<bool(const std::vector<double>&,std::vector<double>&)>& precondition,
    std::vector<double>& solution,unsigned& iterations,double& residual,std::string& error);

// Numerical trust-region proposal for a failed Newton chart. Column scaling
// and regularization affect only the trial direction, never material forces
// or physical root tolerances. The caller must check the actual nonlinear law.
bool StructuralLeastSquaresProposal(const std::vector<double>& jacobian,
    const std::vector<double>& residual,double regularization,std::vector<double>& direction);

struct StructuralState {
    uint64_t revision=1;
    std::vector<double> restLengths,accumulatedPlasticStrain,multipliers,stressDemand;
    // Interval-local world positional impulse (h times force impulse). It is
    // applied-history ownership in standalone/Schur paths; the reduced physical
    // root records its constitutive target for diagnostics, not a second kick.
    // Rotating standalone gradients must undo the actual old world vector.
    std::vector<glm::dvec3> appliedBeamImpulse,beamLinearizationNormal;
    std::vector<uint8_t> broken,pending;
    std::vector<unsigned> component;
    double plasticWork=0,fractureWork=0,dampingWork=0;
    // Native, interval-local convergence diagnostics; not durable material.
    unsigned linearIterations=0;
    double linearResidual=0,maximumPinDrift=0,nonlinearResidual=0,nonlinearRoundoffBound=0;
    double publicationLinearError=0,publicationAngularError=0;
    bool precisionLimited=false;
    void Initialize(const StructuralCook&,unsigned nodes);
    void BeginInterval(const StructuralCook&,const std::vector<glm::dvec3>& positions);
    void Solve(const StructuralCook&,std::vector<glm::dvec3>& positions,const std::vector<double>& inverseMass,double h);
    // Consistent implicit axial force and derivative. Plastic return mapping
    // is eliminated against the interval's immutable historical state.
    bool Linearize(const StructuralCook&,unsigned beam,double length,double h,double& force,double& tangent);
    // Pure constitutive trial for nonlinear residuals: no plastic/history write.
    bool EvaluateForce(const StructuralCook&,unsigned beam,double length,double h,double& force,double& tangent,double& rest,double& plastic)const;
    // Exact one-sided derivative at yield and plastic-capacity corners.
    bool EvaluateForceDirectional(const StructuralCook&,unsigned,double length,double h,double lengthDirection,double& forceDirection)const;
    // Frozen-geometry axial proposal, not an accepted geometry: modelLength
    // may be signed. Returns the selected branch tangent and its affine value
    // at baseLength, including the essential intercept across a corner.
    bool EvaluateAffineForce(const StructuralCook&,unsigned,double baseLength,double modelLength,double h,double& valueAtBase,double& tangent,unsigned* branch=nullptr)const;
    bool EvaluateAffineDirectional(const StructuralCook&,unsigned,double modelLength,double h,double lengthDirection,double& forceDirection)const;
    std::array<double,4> ForceEvents(const StructuralCook&,unsigned)const;
    // Interval-anchored backward-Euler material potential: elastic energy,
    // plastic dissipation and objective axial viscosity. Its length derivative
    // is exactly Linearize's force, including authored plastic capacity.
    double IntervalPotential(const StructuralCook&,const std::vector<glm::dvec3>&,double h)const;
    void AcceptInterval(const StructuralCook&,const std::vector<glm::dvec3>& positions,double h);
    bool Commit(const StructuralCook&,const std::vector<glm::dvec3>& positions={});
    void Connectivity(const StructuralCook&,unsigned nodes);
    bool Connected(const std::vector<unsigned>&,const std::vector<unsigned>&)const;
    bool FaceVisible(const DeformableAsset&,unsigned face)const;
    double ElasticEnergy(const StructuralCook&,const std::vector<glm::dvec3>& positions)const;
    void Persist(SaveArchive&,const StructuralCook&,unsigned nodes);
private:
    // Nonlinear iterations may revise their plastic trial in either direction.
    // Only a completed interval changes irreversible material history/work.
    std::vector<double> intervalRest,intervalPlastic,trialRest,trialPlastic,intervalLengths;
};
