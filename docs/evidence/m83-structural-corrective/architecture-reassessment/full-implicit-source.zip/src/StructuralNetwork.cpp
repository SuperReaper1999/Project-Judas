#include "StructuralNetwork.h"
#include "Deformable.h"
#include "SaveArchive.h"
#include "PerformanceProfiler.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <limits>
#include <numeric>
#include <set>
#include <sstream>

namespace {
using V=glm::dvec3;
}
void StructuralRegion::Save(SaveArchive& a){a(key,youngModulus,damping,tensionYield,compressionYield,tensionUltimate,compressionUltimate,hardening,maxShortening,maxExtension,panelThickness);}
void StructuralBeam::Save(SaveArchive& s){s(key,a,b,region,area);}
void StructuralCook::Save(SaveArchive& a){a(regions,beams,surfaceRegions,surfaceSupports,renderSurfaces);}

bool PrepareStructuralCook(DeformableAsset& a,std::string& error){
    const auto fail=[&](const char* message){error=message;return false;};
    if(!a.structure||a.kind!=DeformableKind::Structure||a.fracture||!a.tetrahedra.empty())return fail("structural network requires its own node/beam topology");
    auto& c=*a.structure;
    if(c.regions.empty()||c.regions.size()>64||c.beams.empty()||c.beams.size()>32768||c.surfaceRegions.size()!=a.triangles.size()||c.surfaceSupports.size()!=a.triangles.size())return fail("structural region/beam/surface count invalid");
    std::set<std::string> keys;
    for(const auto& r:c.regions){
        if(r.key.empty()||!keys.insert(r.key).second)return fail("empty/duplicate structural region");
        for(double value:{r.youngModulus,r.damping,r.tensionYield,r.compressionYield,r.tensionUltimate,r.compressionUltimate,r.hardening,r.maxShortening,r.maxExtension,r.panelThickness})if(!std::isfinite(value)||value<0)return fail("invalid structural region material");
        if(r.youngModulus<=0||r.tensionYield<=0||r.compressionYield<=0||r.tensionUltimate<r.tensionYield||r.compressionUltimate<r.compressionYield||r.maxShortening>=1||r.maxExtension>4)return fail("invalid structural elastic/plastic capacities");
    }
    keys.clear();std::set<std::pair<unsigned,unsigned>> pairs;
    a.measures.assign(a.nodes.size(),0);
    for(auto& b:c.beams){
        if(b.key.empty()||!keys.insert(b.key).second||b.a>=a.nodes.size()||b.b>=a.nodes.size()||b.a==b.b||b.region>=c.regions.size()||!std::isfinite(b.area)||b.area<=0||!pairs.insert(std::minmax(b.a,b.b)).second)return fail("invalid/duplicate structural beam");
        b.restLength=glm::length(a.nodes[b.b]-a.nodes[b.a]);
        const double volume=b.area*b.restLength,stiffness=c.regions[b.region].youngModulus*b.area/b.restLength;
        if(!std::isfinite(volume)||!std::isfinite(stiffness)||b.restLength<=1e-9||volume<=0||stiffness<=0)return fail("invalid structural beam length/volume/stiffness");
        a.measures[b.a]+=volume*.5;a.measures[b.b]+=volume*.5;
    }
    for(unsigned f=0;f<a.triangles.size();++f){
        const auto face=a.triangles[f];
        if(c.surfaceRegions[f]>=c.regions.size()||c.surfaceSupports[f].size()>64)return fail("invalid structural surface material/supports");
        const double area=.5*glm::length(glm::cross(a.nodes[face.y]-a.nodes[face.x],a.nodes[face.z]-a.nodes[face.x]));
        const double volume=area*c.regions[c.surfaceRegions[f]].panelThickness;
        if(!std::isfinite(volume))return fail("nonfinite structural panel volume");
        for(auto n:{face.x,face.y,face.z})a.measures[n]+=volume/3;
        std::set<unsigned> support;
        for(auto b:c.surfaceSupports[f])if(b>=c.beams.size()||!support.insert(b).second)return fail("invalid/duplicate structural surface support");
    }
    if(a.render.vertices.empty()){
        c.renderSurfaces.resize(a.triangles.size());std::iota(c.renderSurfaces.begin(),c.renderSurfaces.end(),0);
    }else{
        if(c.renderSurfaces.size()!=a.render.indices.size()/3)return fail("structural render triangle requires physical surface ownership");
        for(auto surface:c.renderSurfaces)if(surface>=a.triangles.size())return fail("structural render surface outside topology");
    }
    return true;
}

bool ImportStructuralNetwork(const std::string& text,DeformableAsset& output,std::string& error){
    try{
        if(text.size()>8*1024*1024)throw std::runtime_error("structural source exceeds 8 MiB");
        std::istringstream in(text);std::string token;unsigned version=0;
        if(!(in>>token>>version)||token!="JudasStructuralSource"||version!=1)throw std::runtime_error("expected JudasStructuralSource 1");
        DeformableAsset a;a.kind=DeformableKind::Structure;a.structure=std::make_shared<StructuralCook>();auto& c=*a.structure;
        bool end=false;
        while(in>>token){
            if(token=="node"){V p;in>>p.x>>p.y>>p.z;a.nodes.push_back(p);a.massWeights.push_back(1);if(a.nodes.size()>8192)throw std::runtime_error("structural node limit");}
            else if(token=="mass-weight"){unsigned n=0;double value=0;in>>n>>value;if(n>=a.massWeights.size())throw std::runtime_error("mass-weight requires an existing node");a.massWeights[n]=value;}
            else if(token=="region"){StructuralRegion r;in>>std::quoted(r.key)>>r.youngModulus>>r.damping>>r.tensionYield>>r.compressionYield>>r.tensionUltimate>>r.compressionUltimate>>r.hardening>>r.maxShortening>>r.maxExtension>>r.panelThickness;c.regions.push_back(r);if(c.regions.size()>64)throw std::runtime_error("structural region limit");}
            else if(token=="beam"){StructuralBeam b;in>>std::quoted(b.key)>>b.a>>b.b>>b.region>>b.area;c.beams.push_back(b);if(c.beams.size()>32768)throw std::runtime_error("structural beam limit");}
            else if(token=="surface"){glm::uvec3 f;unsigned region=0,count=0;in>>f.x>>f.y>>f.z>>region>>count;if(count>64)throw std::runtime_error("structural surface support limit");std::vector<unsigned> supports(count);for(auto& b:supports)in>>b;a.triangles.push_back(f);c.surfaceRegions.push_back(region);c.surfaceSupports.push_back(std::move(supports));if(a.triangles.size()>32768)throw std::runtime_error("structural surface limit");}
            else if(token=="group"){std::string name;unsigned count=0;in>>std::quoted(name)>>count;if(count>8192)throw std::runtime_error("structural group limit");std::vector<unsigned> nodes(count);for(auto& n:nodes)in>>n;if(!a.groups.emplace(name,std::move(nodes)).second)throw std::runtime_error("duplicate structural group");}
            else if(token=="render-vertex"){MeshVertex v;DeformableBinding b;in>>v.uv.x>>v.uv.y;for(int k=0;k<4;++k)in>>b.nodes[k];for(int k=0;k<4;++k)in>>b.weights[k];for(int k=0;k<4;++k){if(b.nodes[k]>=a.nodes.size())throw std::runtime_error("render binding requires existing nodes");v.position+=glm::vec3(a.nodes[b.nodes[k]]*b.weights[k]);}a.render.vertices.push_back(v);a.binding.push_back(b);if(a.render.vertices.size()>65536)throw std::runtime_error("structural render vertex limit");}
            else if(token=="render-triangle"){unsigned x=0,y=0,z=0,surface=0;int material=0;in>>x>>y>>z>>surface>>material;if(material<0||material>=64)throw std::runtime_error("structural render material limit");const unsigned first=unsigned(a.render.indices.size());a.render.indices.insert(a.render.indices.end(),{x,y,z});c.renderSurfaces.push_back(surface);if(a.render.primitives.empty()||a.render.primitives.back().material!=material)a.render.primitives.push_back({first,3,material});else a.render.primitives.back().count+=3;}
            else if(token=="end"){end=true;break;}
            else throw std::runtime_error("unknown structural source record: "+token);
            if(!in)throw std::runtime_error("truncated structural source record: "+token);
        }
        if(!end||(in>>token))throw std::runtime_error("missing end/trailing structural source data");
        if(!PrepareDeformableAsset(a,error))return false;
        output=std::move(a);return true;
    }catch(const std::exception& e){error=e.what();return false;}
}

void StructuralState::Initialize(const StructuralCook& c,unsigned nodes){
    revision=1;plasticWork=fractureWork=dampingWork=0;linearIterations=0;linearResidual=maximumPinDrift=nonlinearResidual=nonlinearRoundoffBound=0;precisionLimited=false;publicationLinearError=publicationAngularError=0;restLengths.resize(c.beams.size());
    for(unsigned b=0;b<c.beams.size();++b)restLengths[b]=c.beams[b].restLength;
    accumulatedPlasticStrain.assign(c.beams.size(),0);broken.assign(c.beams.size(),0);pending.assign(c.beams.size(),0);multipliers.assign(c.beams.size(),0);stressDemand.assign(c.beams.size(),0);appliedBeamImpulse.assign(c.beams.size(),V(0));beamLinearizationNormal.assign(c.beams.size(),V(0));Connectivity(c,nodes);
}
void StructuralState::BeginInterval(const StructuralCook& c,const std::vector<V>& x){
    std::fill(multipliers.begin(),multipliers.end(),0);
    intervalRest=trialRest=restLengths;intervalPlastic=trialPlastic=accumulatedPlasticStrain;linearIterations=0;linearResidual=nonlinearResidual=nonlinearRoundoffBound=0;precisionLimited=false;publicationLinearError=publicationAngularError=0;
    appliedBeamImpulse.assign(c.beams.size(),V(0));beamLinearizationNormal.assign(c.beams.size(),V(0));
    intervalLengths.resize(c.beams.size());for(unsigned i=0;i<c.beams.size();++i){const auto delta=x[c.beams[i].b]-x[c.beams[i].a];intervalLengths[i]=glm::length(delta);if(intervalLengths[i]>1e-12)beamLinearizationNormal[i]=delta/intervalLengths[i];}
}
bool SolveStructuralSchur(const std::vector<double>& diagonal,const std::vector<double>& rhs,
    const std::function<void(const std::vector<double>&,std::vector<double>&)>& multiply,
    std::vector<double>& solution,unsigned& iterations,double& residual){
    const size_t count=rhs.size();solution.assign(count,0);iterations=0;residual=0;
    if(count==0)return true;
    std::vector<double> r=rhs,z(count),direction(count),product(count);
    double norm=0;
    for(size_t i=0;i<count;++i){if(!(diagonal[i]>0)||!std::isfinite(diagonal[i])||!std::isfinite(r[i]))return false;
        z[i]=r[i]/diagonal[i];direction[i]=z[i];norm+=r[i]*z[i];}
    if(!std::isfinite(norm))return false;
    const double initial=std::sqrt(std::max(0.,norm)),tolerance=std::max(1e-11,initial*1e-9);
    residual=initial;if(initial<=tolerance)return true;
    // In exact arithmetic SPD CG terminates in at most count steps. A second
    // dimension-length pass accommodates finite-precision loss of conjugacy;
    // exhaustion is an explicit failure, never hidden by damaged rest lengths.
    const size_t bound=std::min<size_t>(4096,2*count+8);
    for(size_t round=0;round<bound;++round){multiply(direction,product);double denominator=0;
        for(size_t i=0;i<count;++i)denominator+=direction[i]*product[i];
        if(!(denominator>0)||!std::isfinite(denominator))return false;
        const double alpha=norm/denominator;
        for(size_t i=0;i<count;++i){solution[i]+=alpha*direction[i];r[i]-=alpha*product[i];z[i]=r[i]/diagonal[i];}
        double next=0;for(size_t i=0;i<count;++i)next+=r[i]*z[i];
        iterations=unsigned(round+1);residual=std::sqrt(std::max(0.,next));
        if(!std::isfinite(next)||!std::isfinite(residual))return false;
        if(residual<=tolerance){
            // Check the actual operator residual, not merely the recursively
            // updated CG estimate, before accepting the physical correction.
            multiply(solution,product);double actual=0;
            for(size_t i=0;i<count;++i){const double q=rhs[i]-product[i];actual+=q*q/diagonal[i];}
            residual=std::sqrt(std::max(0.,actual));return residual<=tolerance*4;
        }
        const double beta=next/norm;for(size_t i=0;i<count;++i)direction[i]=z[i]+beta*direction[i];norm=next;
    }
    return false;
}
StructuralPrimalSolver::StructuralPrimalSolver(const std::vector<double>& values,std::vector<double>& reference,StructuralPrimalTraversal* retained,std::function<double(const std::vector<double>&)> physicalResidualNorm):matrix(values),factor(reference),traversal(retained?retained:&localTraversal),residualNorm(std::move(physicalResidualNorm)){
    JUDAS_PROFILE_SCOPE("Structural primal sparse preparation");
    count=size_t(std::sqrt(double(matrix.size())));if(count*count!=matrix.size())return;
    rows.resize(count+1);for(size_t i=0;i<count;++i){if(!(matrix[i*count+i]>0)||!std::isfinite(matrix[i*count+i]))return;
        rows[i]=columns.size();for(size_t j=0;j<count;++j)if(matrix[i*count+j]!=0)columns.push_back(j);}rows[count]=columns.size();
    // This object owns one frozen CURRENT operator and many right-hand
    // sides. Refactor it once here, rather than repeatedly running tight CG
    // against a historical matrix's factor for every contact/preconditioner.
    if(!Factorize())return;
    PrepareFactorTraversal();valid=true;
}
bool StructuralPrimalSolver::Factorize(){
    JUDAS_PROFILE_SCOPE("Structural primal factorization");traversal->ready=false;factor=matrix;
    // Right-looking Cholesky applies the SAME products to each lower entry
    // in the SAME ascending k order as the left-looking dot product. Mirrored
    // solved columns make the rank update contiguous/vectorizable; no pivot,
    // sparsity threshold, stiffness or arithmetic reassociation is introduced.
    for(size_t k=0;k<count;++k){const double diagonal=factor[k*count+k];
        if(!(diagonal>0)||!std::isfinite(diagonal)){factor.clear();return false;}
        const double root=std::sqrt(diagonal);factor[k*count+k]=root;
        for(size_t i=k+1;i<count;++i){const double value=factor[i*count+k]/root;factor[i*count+k]=value;factor[k*count+i]=value;}
        const double* column=factor.data()+k*count;
        for(size_t i=k+1;i<count;++i){const double value=factor[i*count+k];
            // Exact zeros carry no rank update. There is no drop tolerance;
            // every nonzero product keeps the original accumulation order.
            if(value==0)continue;
            double* row=factor.data()+i*count;
            for(size_t j=k+1;j<=i;++j)row[j]-=value*column[j];}
    }
    // Upper entries were scratch for the contiguous transpose. Retain their
    // old matrix copies so the existing factor-buffer contract is unchanged.
    for(size_t i=0;i<count;++i)for(size_t j=i+1;j<count;++j)factor[i*count+j]=matrix[i*count+j];
    return true;
}
void StructuralPrimalSolver::PrepareFactorTraversal(){
    if(traversal->ready&&traversal->count==count)return;
    JUDAS_PROFILE_SCOPE("Structural factor sparse preparation");
    traversal->lowerRows.assign(count+1,0);traversal->upperRows.assign(count+1,0);traversal->lowerColumns.clear();traversal->lowerValues.clear();
    for(size_t i=0;i<count;++i){traversal->lowerRows[i]=traversal->lowerColumns.size();for(size_t j=0;j<i;++j){const double value=factor[i*count+j];if(value!=0){traversal->lowerColumns.push_back(j);traversal->lowerValues.push_back(value);++traversal->upperRows[j+1];}}}
    traversal->lowerRows[count]=traversal->lowerColumns.size();for(size_t i=1;i<=count;++i)traversal->upperRows[i]+=traversal->upperRows[i-1];
    traversal->upperColumns.resize(traversal->lowerColumns.size());traversal->upperValues.resize(traversal->lowerValues.size());auto cursor=traversal->upperRows;
    for(size_t i=0;i<count;++i)for(size_t k=traversal->lowerRows[i];k<traversal->lowerRows[i+1];++k){const size_t index=cursor[traversal->lowerColumns[k]]++;traversal->upperColumns[index]=i;traversal->upperValues[index]=traversal->lowerValues[k];}
    traversal->count=count;traversal->ready=true;
}
void StructuralPrimalSolver::Multiply(const std::vector<double>& input,std::vector<double>& output)const{
    output.resize(count);for(size_t i=0;i<count;++i){double value=0;for(size_t k=rows[i];k<rows[i+1];++k){const auto j=columns[k];value+=matrix[i*count+j]*input[j];}output[i]=value;}
}
void StructuralPrimalSolver::Precondition(const std::vector<double>& input,std::vector<double>& output)const{
    output.resize(count);for(size_t i=0;i<count;++i){double value=input[i];for(size_t k=traversal->lowerRows[i];k<traversal->lowerRows[i+1];++k)value-=traversal->lowerValues[k]*output[traversal->lowerColumns[k]];output[i]=value/factor[i*count+i];}
    for(size_t i=count;i-->0;){double value=output[i];for(size_t k=traversal->upperRows[i];k<traversal->upperRows[i+1];++k)value-=traversal->upperValues[k]*output[traversal->upperColumns[k]];output[i]=value/factor[i*count+i];}
}
double StructuralPrimalSolver::Norm(const std::vector<double>& r)const{if(residualNorm)return residualNorm(r);double value=0;for(size_t i=0;i<count;++i)value+=r[i]*r[i]/matrix[i*count+i];return std::sqrt(std::max(0.,value));}
bool StructuralPrimalSolver::Solve(const std::vector<double>& rhs,std::vector<double>& solution,unsigned& iterations,double& residual){
    JUDAS_PROFILE_SCOPE("Structural primal linear solve");iterations=0;residual=0;solution.assign(count,0);
    if(!valid||rhs.size()!=count)return false;
    if(count==0)return true;
    for(auto value:rhs)if(!std::isfinite(value))return false;
    std::vector<double> r=rhs,z(count),direction(count),product(count);
    const double initial=Norm(rhs),tolerance=std::max(1e-11,initial*1e-9);residual=initial;
    if(!std::isfinite(initial)||initial<0)return false;
    if(initial<=tolerance)return true;
    // All right-hand sides reuse the SAME factor. A direct triangular solve
    // is accepted only by the unchanged actual physical residual contract.
    // Ill-conditioned roundoff retains bounded CG residual refinement below;
    // no stiffness, compliance or acceptance tolerance changes.
    Precondition(rhs,solution);Multiply(solution,product);
    for(size_t i=0;i<count;++i)r[i]=rhs[i]-product[i];
    iterations=1;residual=Norm(r);
    if(std::isfinite(residual)&&residual<=tolerance*4)return true;
    if(!std::isfinite(residual)||residual<0)return false;
    Precondition(r,z);direction=z;double previous=std::inner_product(r.begin(),r.end(),z.begin(),0.);
    const size_t bound=std::min<size_t>(4096,2*count+8);
    for(size_t round=0;round<bound;++round){Multiply(direction,product);const double denominator=std::inner_product(direction.begin(),direction.end(),product.begin(),0.);
        if(!(denominator>0)||!std::isfinite(denominator))break;
        const double alpha=previous/denominator;
        for(size_t i=0;i<count;++i){solution[i]+=alpha*direction[i];r[i]-=alpha*product[i];}iterations=unsigned(round+2);residual=Norm(r);
        if(residual<=tolerance){Multiply(solution,product);for(size_t i=0;i<count;++i)r[i]=rhs[i]-product[i];residual=Norm(r);if(residual<=tolerance*4)return true;}
        Precondition(r,z);const double next=std::inner_product(r.begin(),r.end(),z.begin(),0.);
        if(!(next>=0)||!std::isfinite(next)||previous<=0)break;
        const double beta=next/previous;
        for(size_t i=0;i<count;++i)direction[i]=z[i]+beta*direction[i];
        previous=next;
    }
    // Recheck the actual operator after bounded refinement. The factor is
    // already current; refactoring that identical matrix cannot repair a
    // residual and must not replay expensive algebra per right-hand side.
    Multiply(solution,product);
    for(size_t i=0;i<count;++i)r[i]=rhs[i]-product[i];
    residual=Norm(r);
    const bool accepted=std::isfinite(residual)&&residual<=tolerance*4;
    if(!accepted){static bool recorded=false;if(const char* path=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE")){if(*path&&!recorded&&count<=512){recorded=true;
        std::ofstream dump(std::string(path)+".linear-failure.txt");dump<<std::setprecision(17)<<"StructuralLinearFailure 1\n"<<count<<' '<<iterations<<' '<<tolerance<<' '<<residual<<"\nA\n";
        for(size_t i=0;i<count;++i){for(size_t j=0;j<count;++j)dump<<matrix[i*count+j]<<' ';dump<<'\n';}
        for(const auto& item:std::vector<std::pair<const char*,const std::vector<double>*>>{{"rhs",&rhs},{"solution",&solution},{"actual-residual",&r}}){dump<<item.first<<'\n';for(double value:*item.second)dump<<value<<' ';dump<<'\n';}
    }}}
    return accepted;
}
bool SolveStructuralPrimal(const std::vector<double>& matrix,const std::vector<double>& rhs,std::vector<double>& factor,std::vector<double>& solution,unsigned& iterations,double& residual){
    StructuralPrimalSolver solver(matrix,factor);return solver.Solve(rhs,solution,iterations,residual);
}
bool SolveStructuralNewtonKrylov(const std::vector<double>& rhs,
    const std::function<bool(const std::vector<double>&,std::vector<double>&)>& action,
    const std::function<bool(const std::vector<double>&,std::vector<double>&)>& precondition,
    std::vector<double>& solution,unsigned& iterations,double& residual,std::string& error){
    JUDAS_PROFILE_SCOPE("Structural physical Newton Krylov");
    const size_t n=rhs.size();solution.assign(n,0);iterations=0;residual=0;error.clear();
    const auto norm=[](const std::vector<double>& v){long double sum=0;for(double x:v){if(!std::isfinite(x))return std::numeric_limits<double>::infinity();sum+=static_cast<long double>(x)*x;}return std::sqrt(double(sum));};
    const double initial=norm(rhs),tolerance=std::max(1e-11,initial*1e-9);residual=initial;
    if(!std::isfinite(initial)){error="nonfinite physical Newton right-hand side";return false;}if(initial<=tolerance)return true;
    // An n-dimensional Krylov termination bound only has meaning while that
    // basis is retained. Restarting at48 can discard a still-unsolved invariant
    // direction in a perfectly invertible stiff/nonsymmetric small assembly.
    // The supported small root retains its full basis (<7 MiB at512 DOFs).
    // Large contact systems keep an explicitly bounded restarted policy.
    const size_t restart=n<=512?n:48,bound=std::min<size_t>(4096,2*n+8);std::vector<double> r=rhs,product;
    while(iterations<bound){const double beta=norm(r);if(!std::isfinite(beta)){error="nonfinite physical Newton residual";return false;}
        std::vector<std::vector<double>> basis(restart+1,std::vector<double>(n)),directions(restart);
        std::vector<double> h((restart+1)*restart,0),c(restart),s(restart),g(restart+1,0);g[0]=beta;
        for(size_t i=0;i<n;++i)basis[0][i]=r[i]/beta;
        size_t used=0;bool invariant=false;
        for(size_t j=0;j<restart&&iterations<bound;++j){if(!precondition(basis[j],directions[j])||directions[j].size()!=n||!action(directions[j],product)||product.size()!=n){error="physical Newton operator/preconditioner failed";return false;}
            if(!std::isfinite(norm(product))){error="nonfinite physical Newton operator";return false;}
            // Two-pass modified Gram-Schmidt, with actual right-preconditioned
            // directions retained (flexible GMRES). No rank regularization.
            for(unsigned pass=0;pass<2;++pass)for(size_t k=0;k<=j;++k){long double dot=0;for(size_t i=0;i<n;++i)dot+=static_cast<long double>(basis[k][i])*product[i];const double q=double(dot);h[k*restart+j]+=q;for(size_t i=0;i<n;++i)product[i]-=q*basis[k][i];}
            h[(j+1)*restart+j]=norm(product);invariant=h[(j+1)*restart+j]==0;
            if(!invariant)for(size_t i=0;i<n;++i)basis[j+1][i]=product[i]/h[(j+1)*restart+j];
            for(size_t k=0;k<j;++k){const double a=h[k*restart+j],b=h[(k+1)*restart+j];h[k*restart+j]=c[k]*a+s[k]*b;h[(k+1)*restart+j]=-s[k]*a+c[k]*b;}
            const double a=h[j*restart+j],b=h[(j+1)*restart+j],length=std::hypot(a,b);if(length==0){used=j;invariant=true;break;}
            c[j]=a/length;s[j]=b/length;h[j*restart+j]=length;h[(j+1)*restart+j]=0;g[j+1]=-s[j]*g[j];g[j]*=c[j];used=j+1;++iterations;
            if(std::abs(g[j+1])<=tolerance||invariant)break;
        }
        std::vector<double> y(used);for(size_t i=used;i-->0;){double value=g[i];for(size_t j=i+1;j<used;++j)value-=h[i*restart+j]*y[j];const double diagonal=h[i*restart+i];if(diagonal==0||!std::isfinite(diagonal)){error="singular physical Newton active system";return false;}y[i]=value/diagonal;}
        for(size_t j=0;j<used;++j)for(size_t i=0;i<n;++i)solution[i]+=directions[j][i]*y[j];
        if(!action(solution,product)||product.size()!=n){error="physical Newton true-residual evaluation failed";return false;}
        for(size_t i=0;i<n;++i)r[i]=rhs[i]-product[i];
        residual=norm(r);
        if(std::isfinite(residual)&&residual<=4*tolerance)return true;
        if(invariant||used==0){error="physical Newton invariant subspace cannot satisfy actual residual";return false;}
    }
    error="physical Newton Krylov exceeded dimension-bounded residual policy";return false;
}

bool StructuralLeastSquaresProposal(const std::vector<double>& jacobian,const std::vector<double>& residual,double regularization,std::vector<double>& direction){
    JUDAS_PROFILE_SCOPE("Structural numerical trust proposal");
    const size_t n=residual.size();direction.clear();
    if(n>512||jacobian.size()!=n*n||!(regularization>0)||!std::isfinite(regularization))return false;
    std::vector<double> scale(n,0),normalized(jacobian),normal(n*n,0),rhs(n,0),factor,z;
    for(double v:residual)if(!std::isfinite(v))return false;
    for(size_t row=0;row<n;++row)for(size_t col=0;col<n;++col){const double v=jacobian[row*n+col];if(!std::isfinite(v))return false;scale[col]=std::hypot(scale[col],v);}
    for(double& v:scale)if(v==0)v=1;
    for(size_t row=0;row<n;++row)for(size_t col=0;col<n;++col)normalized[row*n+col]/=scale[col];
    for(size_t row=0;row<n;++row)for(size_t i=0;i<n;++i){const double v=normalized[row*n+i];rhs[i]-=v*residual[row];
        for(size_t j=0;j<=i;++j)normal[i*n+j]+=v*normalized[row*n+j];}
    for(size_t i=0;i<n;++i){normal[i*n+i]+=regularization;for(size_t j=0;j<i;++j)normal[j*n+i]=normal[i*n+j];}
    unsigned iterations;double error;StructuralPrimalSolver solver(normal,factor);
    if(!solver.Solve(rhs,z,iterations,error))return false;
    direction.resize(n);for(size_t i=0;i<n;++i){direction[i]=z[i]/scale[i];if(!std::isfinite(direction[i]))return false;}
    return true;
}

bool StructuralState::Linearize(const StructuralCook& c,unsigned i,double length,double h,double& force,double& tangent){
    double rest=0,plastic=0;if(!EvaluateForce(c,i,length,h,force,tangent,rest,plastic))return false;
    trialRest[i]=rest;trialPlastic[i]=plastic;return true;
}
namespace {
bool StructuralScalarForce(const StructuralCook& c,unsigned i,double length,double h,double oldRest,double oldPlastic,double oldLength,double& force,double& tangent,double& rest,double& plastic,unsigned* branch=nullptr){
    if(branch)*branch=0;
    const auto& b=c.beams[i];const auto& r=c.regions[b.region];
    const double strain=(length-oldRest)/b.restLength;
    const double trial=r.youngModulus*strain,sign=trial>=0?1.:-1.;
    const double yield=(sign>0?r.tensionYield:r.compressionYield)+r.hardening*oldPlastic;
    rest=oldRest;plastic=oldPlastic;double modulus=r.youngModulus;
    if(std::abs(trial)>yield){
        const double increment=(std::abs(trial)-yield)/(r.youngModulus+r.hardening);
        const double proposed=oldRest+sign*b.restLength*increment;
        rest=std::clamp(proposed,b.restLength*(1-r.maxShortening),b.restLength*(1+r.maxExtension));
        plastic+=std::abs(rest-oldRest)/b.restLength;
        // Plastic capacity saturation returns to the elastic tangent. Within
        // capacity the exact return-map derivative is E H/(E+H), not E.
        if(proposed>b.restLength*(1-r.maxShortening)&&proposed<b.restLength*(1+r.maxExtension)){modulus=r.youngModulus*r.hardening/(r.youngModulus+r.hardening);if(branch)*branch=sign>0?1:2;}
        else if(branch)*branch=sign>0?3:4;
    }
    const double elastic=r.youngModulus*b.area/b.restLength*(length-rest);
    force=elastic+r.damping*(length-oldLength)/h;
    tangent=modulus*b.area/b.restLength+r.damping/h;
    return std::isfinite(force)&&std::isfinite(tangent);
}
}
bool StructuralState::EvaluateForce(const StructuralCook& c,unsigned i,double length,double h,double& force,double& tangent,double& rest,double& plastic)const{
    if(i>=c.beams.size()||broken[i]||length<1e-12||h<=0||!std::isfinite(length))return false;
    return StructuralScalarForce(c,i,length,h,intervalRest[i],intervalPlastic[i],intervalLengths[i],force,tangent,rest,plastic);
}
bool StructuralState::EvaluateAffineForce(const StructuralCook& c,unsigned i,double baseLength,double modelLength,double h,double& valueAtBase,double& tangent,unsigned* branch)const{
    if(i>=c.beams.size()||broken[i]||h<=0||!std::isfinite(baseLength)||!std::isfinite(modelLength))return false;
    double force,rest,plastic;if(!StructuralScalarForce(c,i,modelLength,h,intervalRest[i],intervalPlastic[i],intervalLengths[i],force,tangent,rest,plastic,branch))return false;
    valueAtBase=force+tangent*(baseLength-modelLength);return std::isfinite(valueAtBase);
}

bool StructuralState::EvaluateForceDirectional(const StructuralCook& c,unsigned i,double length,double h,double dlength,double& derivative)const{
    if(length<1e-12)return false;
    return EvaluateAffineDirectional(c,i,length,h,dlength,derivative);
}
bool StructuralState::EvaluateAffineDirectional(const StructuralCook& c,unsigned i,double length,double h,double dlength,double& derivative)const{
    if(i>=c.beams.size()||broken[i]||h<=0||!std::isfinite(length)||!std::isfinite(dlength))return false;
    const auto& b=c.beams[i];const auto& r=c.regions[b.region];const double trial=r.youngModulus*(length-intervalRest[i])/b.restLength,sign=trial>=0?1.:-1.;
    const double yield=(sign>0?r.tensionYield:r.compressionYield)+r.hardening*intervalPlastic[i];double drest=0;
    const double difference=std::abs(trial)-yield;
    if(difference>0||(difference==0&&sign*dlength>0)){
        const double proposed=intervalRest[i]+sign*b.restLength*std::max(0.,difference)/(r.youngModulus+r.hardening);
        const double lower=b.restLength*(1-r.maxShortening),upper=b.restLength*(1+r.maxExtension);
        drest=r.youngModulus/(r.youngModulus+r.hardening)*dlength;
        if(proposed<lower||proposed>upper)drest=0;
        else if(proposed==lower)drest=std::max(0.,drest);
        else if(proposed==upper)drest=std::min(0.,drest);
    }
    derivative=r.youngModulus*b.area/b.restLength*(dlength-drest)+r.damping/h*dlength;
    return std::isfinite(derivative);
}
std::array<double,4> StructuralState::ForceEvents(const StructuralCook& c,unsigned i)const{
    const auto& b=c.beams.at(i);const auto& r=c.regions.at(b.region);const double yT=r.tensionYield+r.hardening*intervalPlastic.at(i),yC=r.compressionYield+r.hardening*intervalPlastic.at(i),old=intervalRest.at(i),upper=b.restLength*(1+r.maxExtension),lower=b.restLength*(1-r.maxShortening);
    return {old+yT*b.restLength/r.youngModulus,old-yC*b.restLength/r.youngModulus,upper+(r.hardening/r.youngModulus)*(upper-old)+yT*b.restLength/r.youngModulus,lower+(r.hardening/r.youngModulus)*(lower-old)-yC*b.restLength/r.youngModulus};
}
double StructuralState::IntervalPotential(const StructuralCook& c,const std::vector<V>& x,double h)const{
    if(h<=0||intervalRest.size()!=c.beams.size())return std::numeric_limits<double>::infinity();
    double potential=0;
    for(unsigned i=0;i<c.beams.size();++i){if(broken[i])continue;const auto& b=c.beams[i];const auto& r=c.regions[b.region];
        const double length=glm::length(x[b.b]-x[b.a]);if(!(length>1e-12)||!std::isfinite(length))return std::numeric_limits<double>::infinity();
        const double trial=r.youngModulus*(length-intervalRest[i])/b.restLength,sign=trial>=0?1.:-1.;
        const double yield=(sign>0?r.tensionYield:r.compressionYield)+r.hardening*intervalPlastic[i];
        double rest=intervalRest[i];if(std::abs(trial)>yield){const double increment=(std::abs(trial)-yield)/(r.youngModulus+r.hardening);
            rest=std::clamp(rest+sign*b.restLength*increment,b.restLength*(1-r.maxShortening),b.restLength*(1+r.maxExtension));}
        const double plastic=rest-intervalRest[i],elastic=length-rest,viscous=length-intervalLengths[i];
        potential+=.5*r.youngModulus*b.area/b.restLength*elastic*elastic+b.area*yield*std::abs(plastic)
            +.5*b.area*r.hardening/b.restLength*plastic*plastic+.5*r.damping/h*viscous*viscous;
    }
    return potential;
}
void StructuralState::Solve(const StructuralCook& c,std::vector<V>& x,const std::vector<double>& w,double h){
    struct Row{unsigned beam,a,b;V normal;double compliance,rhs,oldParallel;};std::vector<Row> rows;
    std::vector<double> diagonal,rhs;std::vector<V> baseImpulse(x.size(),V(0)),constantTargets(c.beams.size(),V(0));std::vector<uint8_t> constant(c.beams.size(),0);
    for(unsigned i=0;i<c.beams.size();++i){if(broken[i])continue;const auto& b=c.beams[i];const V delta=x[b.b]-x[b.a];const double length=glm::length(delta);double force=0,tangent=0;
        if(!Linearize(c,i,length,h,force,tangent))throw std::runtime_error("invalid structural member length or constitutive state");
        const V n=delta/length;beamLinearizationNormal[i]=n;const double oldParallel=glm::dot(n,appliedBeamImpulse[i]);
        // Undo the transverse part actually applied by earlier iterations.
        // The remaining parallel increment uses the same coupled Schur rows.
        V rebase=n*oldParallel-appliedBeamImpulse[i];
        if(tangent<=1e-20){constant[i]=1;constantTargets[i]=n*(-h*h*force);rebase=constantTargets[i]-appliedBeamImpulse[i];}
        baseImpulse[b.a]-=rebase;baseImpulse[b.b]+=rebase;
        if(constant[i])continue;
        const double compliance=1/(h*h*tangent),r=-force/tangent-compliance*oldParallel;
        rows.push_back({i,b.a,b.b,n,compliance,r,oldParallel});diagonal.push_back(w[b.a]+w[b.b]+compliance);rhs.push_back(r);
    }
    for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];rhs[i]-=glm::dot(row.normal,w[row.b]*baseImpulse[row.b]-w[row.a]*baseImpulse[row.a]);}
    std::vector<V> motion(x.size());std::vector<double> solution;
    const auto multiply=[&](const std::vector<double>& input,std::vector<double>& output){std::fill(motion.begin(),motion.end(),V(0));
        for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];motion[row.a]-=row.normal*input[i];motion[row.b]+=row.normal*input[i];}
        output.resize(rows.size());for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];output[i]=glm::dot(row.normal,w[row.b]*motion[row.b]-w[row.a]*motion[row.a])+row.compliance*input[i];}
    };
    unsigned rounds=0;double residual=0;if(!SolveStructuralSchur(diagonal,rhs,multiply,solution,rounds,residual))throw std::runtime_error("structural compatibility solve failed its dimension-bounded residual contract");
    linearIterations=std::max(linearIterations,rounds);linearResidual=residual;
    for(unsigned n=0;n<x.size();++n)x[n]+=w[n]*baseImpulse[n];
    for(unsigned i=0;i<c.beams.size();++i)if(constant[i]){appliedBeamImpulse[i]=constantTargets[i];multipliers[i]=glm::dot(constantTargets[i],beamLinearizationNormal[i]);}
    for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];multipliers[row.beam]=row.oldParallel+solution[i];appliedBeamImpulse[row.beam]=row.normal*multipliers[row.beam];x[row.a]-=row.normal*w[row.a]*solution[i];x[row.b]+=row.normal*w[row.b]*solution[i];}
}
void StructuralState::AcceptInterval(const StructuralCook& c,const std::vector<V>& x,double h){
    for(unsigned i=0;i<c.beams.size();++i){if(broken[i])continue;const auto& b=c.beams[i];const auto& r=c.regions[b.region];
        double acceptedForce=0,acceptedTangent=0;Linearize(c,i,glm::length(x[b.b]-x[b.a]),h,acceptedForce,acceptedTangent);
        const double change=trialRest[i]-intervalRest[i],increment=std::abs(change)/b.restLength;
        if(increment>0){const double yield=(change>0?r.tensionYield:r.compressionYield)+r.hardening*intervalPlastic[i];plasticWork+=b.area*b.restLength*(yield*increment+.5*r.hardening*increment*increment);}
        restLengths[i]=trialRest[i];accumulatedPlasticStrain[i]=trialPlastic[i];
        // Only the accepted material geometry supplies an ultimate demand.
        // Early Gauss-Seidel trial rows are solver history, not real overload.
        const double stress=r.youngModulus*(glm::length(x[b.b]-x[b.a])-restLengths[i])/b.restLength;
        const double lengthChange=glm::length(x[b.b]-x[b.a])-intervalLengths[i];dampingWork+=r.damping*lengthChange*lengthChange/h;
        stressDemand[i]=std::max(stressDemand[i],std::abs(stress));
        if(stress>(r.tensionUltimate)||-stress>r.compressionUltimate)pending[i]=1;
    }
}
void StructuralState::Connectivity(const StructuralCook& c,unsigned nodes){
    component.resize(nodes);std::iota(component.begin(),component.end(),0);
    const auto root=[&](unsigned n){while(component[n]!=n)n=component[n];return n;};
    for(unsigned i=0;i<c.beams.size();++i)if(!broken[i]){const auto& b=c.beams[i];const unsigned a=root(b.a),d=root(b.b);component[std::max(a,d)]=std::min(a,d);}
    for(unsigned n=0;n<nodes;++n)component[n]=root(n);
}
bool StructuralState::Commit(const StructuralCook& c,const std::vector<V>& x){
    bool changed=false;
    for(unsigned i=0;i<broken.size();++i)if(pending[i]&&!broken[i]){
        const auto& b=c.beams[i];
        if(b.a<x.size()&&b.b<x.size()){
            const double extension=glm::length(x[b.b]-x[b.a])-restLengths[i];
            // Removing a load path dissipates the elastic energy it actually
            // stored at this commit. No debris receives an invented impulse.
            fractureWork+=.5*c.regions[b.region].youngModulus*b.area/b.restLength*extension*extension;
        }
        broken[i]=1;changed=true;
    }
    std::fill(pending.begin(),pending.end(),0);
    if(changed){++revision;Connectivity(c,unsigned(component.size()));}
    return changed;
}
bool StructuralState::Connected(const std::vector<unsigned>& a,const std::vector<unsigned>& b)const{
    if(a.empty()||b.empty())return false;
    unsigned connected=~0u;
    for(const auto* group:{&a,&b})for(auto n:*group){if(n>=component.size())return false;if(connected==~0u)connected=component[n];else if(component[n]!=connected)return false;}
    return true;
}
bool StructuralState::FaceVisible(const DeformableAsset& a,unsigned face)const{
    if(face>=a.triangles.size())return false;
    const auto& c=*a.structure;const auto f=a.triangles[face];
    if(f.x>=component.size()||f.y>=component.size()||f.z>=component.size()||component[f.x]!=component[f.y]||component[f.x]!=component[f.z])return false;
    for(auto support:c.surfaceSupports[face])if(broken[support])return false;
    return true;
}
double StructuralState::ElasticEnergy(const StructuralCook& c,const std::vector<V>& x)const{double energy=0;for(unsigned i=0;i<c.beams.size();++i)if(!broken[i]){const auto& b=c.beams[i];const double extension=glm::length(x[b.b]-x[b.a])-restLengths[i];energy+=.5*c.regions[b.region].youngModulus*b.area/b.restLength*extension*extension;}return energy;}
void StructuralState::Persist(SaveArchive& a,const StructuralCook& c,unsigned nodes){
    a(revision,restLengths,accumulatedPlasticStrain,broken,plasticWork,fractureWork,dampingWork);
    a.Require(revision>0&&restLengths.size()==c.beams.size()&&accumulatedPlasticStrain.size()==c.beams.size()&&broken.size()==c.beams.size()&&plasticWork>=0&&fractureWork>=0&&dampingWork>=0,"structural snapshot topology/state mismatch");
    for(unsigned i=0;i<c.beams.size();++i){const auto& b=c.beams[i];const auto& r=c.regions[b.region];a.Require(restLengths[i]>=b.restLength*(1-r.maxShortening)-1e-12&&restLengths[i]<=b.restLength*(1+r.maxExtension)+1e-12&&accumulatedPlasticStrain[i]>=0&&broken[i]<=1,"invalid saved structural plasticity/failure");}
    if(a.reading){pending.assign(c.beams.size(),0);multipliers.assign(c.beams.size(),0);stressDemand.assign(c.beams.size(),0);linearIterations=0;linearResidual=maximumPinDrift=nonlinearResidual=nonlinearRoundoffBound=0;precisionLimited=false;publicationLinearError=publicationAngularError=0;appliedBeamImpulse.assign(c.beams.size(),V(0));beamLinearizationNormal.assign(c.beams.size(),V(0));Connectivity(c,nodes);}
}
