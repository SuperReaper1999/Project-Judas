#include "StructuralContactGeometry.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

StructuralContactGeometryResult EvaluateStructuralContactGeometry(glm::dvec3 point,const PrimitivePose& primitive){
    using V=glm::dvec3;using M=glm::dmat3;
    StructuralContactGeometryResult result;
    if(primitive.shape.asset||(primitive.shape.type!=ShapeType::Box&&primitive.shape.type!=ShapeType::Sphere&&primitive.shape.type!=ShapeType::Capsule))return result;
    const auto native=PointGeometry(point,primitive);
    if(!native.valid||!std::isfinite(native.gap))return result;
    const M rotation=PrimitiveRotation(primitive);const V local=glm::transpose(rotation)*(point-PrimitiveCenter(primitive));
    V normal(0);M hessian(0);
    const double signedDistance=native.contains?-native.gap:native.gap;
    if(primitive.shape.type==ShapeType::Box&&native.contains){
        // Inside a box, native distance uses its nearest face. At a medial
        // tie any selected face gives a valid one-sided/B-derivative; never
        // replace that native feature selection with a world-axis assumption.
        const V depth=V(primitive.shape.halfExtents)-glm::abs(local);unsigned axis=depth.y<depth.x?1:0;if(depth.z<depth[axis])axis=2;
        normal[axis]=local[axis]>=0?1:-1;
    }else{
        V offset=local;M projection(1);
        if(primitive.shape.type==ShapeType::Box){const V half(primitive.shape.halfExtents);offset=local-glm::clamp(local,-half,half);projection=M(0);
            for(unsigned k=0;k<3;++k)if(local[k]<-half[k]||local[k]>half[k])projection[k][k]=1;
        }else if(primitive.shape.type==ShapeType::Capsule){const double half=primitive.shape.halfHeight;offset.y-=std::clamp(local.y,-half,half);
            // At an exact cap/shaft seam select the cylindrical side. The
            // normal is continuous; its other one-sided derivative is the cap.
            if(local.y>=-half&&local.y<=half)projection[1][1]=0;
        }
        const double length=glm::length(offset);if(!(length>0)||!std::isfinite(length))return result;
        normal=offset/length;hessian=(projection-glm::outerProduct(normal,normal))/length;
        // Native degenerate-normal fallbacks are not differentiable radial
        // geometry. Keep them on the existing path instead of inventing a
        // derivative or silently redefining their public query behaviour.
        const double bound=128*std::numeric_limits<double>::epsilon()*std::max(1.,glm::length(native.normal));
        if(glm::length(rotation*normal-native.normal)>bound)return result;
    }
    result.signedDistance=signedDistance;result.point=native.point;result.normal=native.normal;
    result.dNormal=rotation*hessian*glm::transpose(rotation);
    result.dPoint=rotation*(M(1)-glm::outerProduct(normal,normal)-signedDistance*hessian)*glm::transpose(rotation);
    for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)if(!std::isfinite(result.dNormal[i][j])||!std::isfinite(result.dPoint[i][j]))return StructuralContactGeometryResult{};
    result.valid=true;return result;
}

StructuralContactPathGeometryResult EvaluateStructuralContactPathGeometry(glm::dvec3 start,glm::dvec3 end,const PrimitivePose& primitive){
    using V=glm::dvec3;using M=glm::dmat3;
    StructuralContactPathGeometryResult result;
    if(primitive.shape.asset||(primitive.shape.type!=ShapeType::Box&&primitive.shape.type!=ShapeType::Sphere&&primitive.shape.type!=ShapeType::Capsule))return result;
    const M rotation=PrimitiveRotation(primitive);const V centre=PrimitiveCenter(primitive),a=glm::transpose(rotation)*(start-centre),v=glm::transpose(rotation)*(end-start);
    // Reuse the native SegmentBox algebra: on each clamp interval the squared
    // distance is one quadratic. Caps extend the same representation; no ray
    // iteration, TOI tolerance or alternative collision geometry is introduced.
    std::vector<double> cuts{0,1};
    if(primitive.shape.type==ShapeType::Box){const V half(primitive.shape.halfExtents);for(unsigned k=0;k<3;++k)if(v[k]!=0)for(double face:{-half[k],half[k]}){const double t=(face-a[k])/v[k];if(t>0&&t<1)cuts.push_back(t);}}
    else if(primitive.shape.type==ShapeType::Capsule&&v.y!=0)for(double face:{-double(primitive.shape.halfHeight),double(primitive.shape.halfHeight)}){const double t=(face-a.y)/v.y;if(t>0&&t<1)cuts.push_back(t);}
    std::sort(cuts.begin(),cuts.end());cuts.erase(std::unique(cuts.begin(),cuts.end()),cuts.end());
    double best=std::numeric_limits<double>::infinity(),fraction=0;M active(0);V anchor(0);
    const auto evaluate=[&](double t,const M& projection,V base){const V offset=projection*(a+t*v-base);const double squared=glm::dot(offset,offset);
        if(squared<best){best=squared;fraction=t;active=projection;anchor=base;}};
    for(size_t i=1;i<cuts.size();++i){const double low=cuts[i-1],high=cuts[i],middle=(low+high)*.5;const V point=a+middle*v;M projection(1);V base(0);
        if(primitive.shape.type==ShapeType::Box){projection=M(0);const V half(primitive.shape.halfExtents);for(unsigned k=0;k<3;++k)if(point[k]<-half[k]||point[k]>half[k]){projection[k][k]=1;base[k]=point[k]<0?-half[k]:half[k];}}
        else if(primitive.shape.type==ShapeType::Capsule){const double half=primitive.shape.halfHeight;if(point.y<-half)base.y=-half;else if(point.y>half)base.y=half;else projection[1][1]=0;}
        const V velocity=projection*v,offset=projection*(a-base);const double quadratic=glm::dot(velocity,velocity),linear=glm::dot(velocity,offset);
        evaluate(low,projection,base);evaluate(high,projection,base);if(quadratic>0)evaluate(std::clamp(-linear/quadratic,low,high),projection,base);
    }
    if(!(best>0)||!std::isfinite(best))return result;
    const V path=start+fraction*(end-start);const auto native=EvaluateStructuralContactGeometry(path,primitive);
    if(!native.valid||!(native.signedDistance>0))return result;
    const V offset=active*(a+fraction*v-anchor),velocity=active*v;const double length=glm::length(offset),quadratic=glm::dot(velocity,velocity);V fractionLocalGradient(0);
    if(fraction>0&&fraction<1&&quadratic>0)fractionLocalGradient=-(offset+fraction*velocity)/quadratic;
    const V fractionGradient=rotation*fractionLocalGradient;const M pathDerivative=fraction*M(1)+glm::outerProduct(end-start,fractionGradient);
    // The selected clamp interval is a valid B-derivative at exact feature
    // ties; choosing it consistently for both tau and curvature matters.
    const V localNormal=offset/length;const M localHessian=(active-glm::outerProduct(localNormal,localNormal))/length;
    const M normalDerivative=rotation*localHessian*glm::transpose(rotation),pointDerivative=rotation*(M(1)-glm::outerProduct(localNormal,localNormal)-native.signedDistance*localHessian)*glm::transpose(rotation);
    result.signedDistance=native.signedDistance;result.point=native.point;result.normal=native.normal;result.dNormal=normalDerivative*pathDerivative;result.dPoint=pointDerivative*pathDerivative;
    result.fraction=fraction;result.fractionGradient=fractionGradient;result.pathPoint=path;result.gradient=fraction*result.normal;
    for(unsigned i=0;i<3;++i)if(!std::isfinite(result.gradient[i])||!std::isfinite(result.fractionGradient[i]))return StructuralContactPathGeometryResult{};
    for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)if(!std::isfinite(result.dNormal[i][j])||!std::isfinite(result.dPoint[i][j]))return StructuralContactPathGeometryResult{};
    result.valid=true;return result;
}
