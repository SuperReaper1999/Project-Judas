#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <vector>

// Frozen normal-contact problem: minimize .5 lambda^T H lambda + q^T lambda
// for lambda >= 0, where H = J A^-1 J^T is positive semidefinite. Multipliers
// are positional impulses (kg*m), and q / primalResidual are signed gap (m).
// Redundant samples are handled through an independent active basis, never
// by adding contact compliance or a diagonal regularizer.
struct StructuralNormalQPResult {
    std::vector<double> multipliers;
    double primalResidual=0;
    double complementarityResidual=0; // maximum |lambda_i * final_gap_i|
    unsigned pivots=0,rank=0;
};

// maximumRank is the dimension of the condensed primal system. A nonempty
// warm vector is only an entering-order hint; returned multipliers are the
// absolute solution to this problem, not an additional warm-start impulse.
bool SolveStructuralNormalQP(const std::vector<double>& gram,
    const std::vector<double>& gap,unsigned maximumRank,
    const std::vector<double>& warm,StructuralNormalQPResult& result,
    std::string& error,double gapTolerance=1e-8);

// Exact frozen tangential metric-disk minimization:
// .5 t^T [[a,b],[b,d]] t - rhs^T t, ||t|| <= radius.
// Caller forms rhs=W*t_old-relative_displacement. The result is an absolute
// positional friction impulse, including release of old pressure. Singular
// PSD metrics are valid; indefinite metrics and invalid inputs fail explicitly.
bool SolveStructuralFrictionDisk(double a,double b,double d,
    const std::array<double,2>& rhs,double radius,
    std::array<double,2>& impulse,std::string& error);

// Actual unilateral/Coulomb constitutive law, independent of a frozen QP.
// impulse=(normal lambda,tangent0,tangent1), in kg*m;
// kinematics=(signed gap,relative tangent displacement0,displacement1), in m.
// Positive mobilities are frozen row scalings (1/kg), not compliance.
struct StructuralContactLawInput {
    std::array<double,3> impulse{},kinematics{};
    double normalMobility=1,tangentMobility=1,friction=0;
};
struct StructuralContactLawResult {
    std::array<double,3> residual{}; // all three have units sqrt(kg)*m
    // Row-major generalized derivative blocks. At the FB origin the norm
    // subgradient is(0,0); the nonzero disk boundary uses its exterior branch.
    std::array<double,9> impulseDerivative{},kinematicDerivative{};
};
bool EvaluateStructuralContactLaw(const StructuralContactLawInput&,
    StructuralContactLawResult&,std::string& error);
// Match the actual weighted Newton/Krylov root floor(1e-11), rather than
// requiring pressure sign accuracy tighter than the solved FB equation.
// Arithmetic errors are independently derived scaled residual bounds, never
// simulation tolerances. This certificate DOES NOT clamp multipliers or
// replace the caller's raw gap/complementarity/friction acceptance checks.
bool StructuralContactLawConverged(const StructuralContactLawInput&,
    double maximumPressure,double normalArithmeticError,
    double tangentArithmeticError,std::string& error);
// Exact one-sided directional derivative, including the NONLINEAR derivative
// at zero pressure/gap or zero disk radius. Used to check actual merit slope;
// callers must not reinterpret that origin derivative as a linear operator.
bool StructuralContactLawDirectionalDerivative(const StructuralContactLawInput&,
    const std::array<double,3>& impulseDirection,
    const std::array<double,3>& kinematicDirection,
    std::array<double,3>& derivative,std::string& error);

// Optional, failure-only frozen-algebra evidence. No physics objects or
// solver memory are exposed. The caller supplies at most 96 rows and captures
// only a dimension-bounded set of sweeps; the writer publishes once/process.
struct StructuralContactFailureRow {
    uint64_t world=0;
    unsigned body=0,primitive=0,sample=0,nativeRow=0;
    bool self=false;
    std::array<unsigned,3> nodes{},otherNodes{};
    std::array<double,3> weights{},otherWeights{},normal{},tangent0{},tangent1{},point{};
    std::array<double,3> freeGap{},initialImpulse{};
};
struct StructuralContactFailureSweep {
    unsigned sweep=0,pivots=0,rank=0;
    double qpPrimal=0,qpComplementarity=0,primal=0,complementarity=0;
    double tangentChange=0,maximumNormal=0;
    double qpTarget=0,qpCertificateFactor=0;
    double outerPrimalTolerance=0,outerComplementarityTolerance=0,outerTangentTolerance=0;
    // Each row: normal,t0,t1,finalGap,slip0,slip1,radius,oldT0,oldT1,
    // signed local frozen-quadratic objective change, final normal-relative
    // displacement (the latter differs from geometric contact gap).
    std::vector<std::array<double,11>> rows;
};
void WriteStructuralContactFailure(const std::string& base,uint64_t generation,
    unsigned interval,unsigned nonlinearRound,double seconds,unsigned physicalRows,const std::string& reason,
    const std::vector<StructuralContactFailureRow>& rows,
    const std::vector<double>& threeAxisGram,
    const std::vector<StructuralContactFailureSweep>& sweeps);
