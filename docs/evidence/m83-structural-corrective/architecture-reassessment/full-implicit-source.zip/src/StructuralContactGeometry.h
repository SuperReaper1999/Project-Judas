#pragma once
#include "CollisionGeometry.h"

// Differential of the existing native point-distance geometry. This is a
// solver-local mathematical seam, not a replacement public physics query.
// Sphere centres/capsule axes have no unique distance normal and return invalid.
// Exact feature ties select a native-compatible semismooth branch.
struct StructuralContactGeometryResult {
    bool valid=false;
    double signedDistance=std::numeric_limits<double>::infinity();
    glm::dvec3 point{0},normal{0};
    glm::dmat3 dNormal{0},dPoint{0};
};
StructuralContactGeometryResult EvaluateStructuralContactGeometry(glm::dvec3 point,const PrimitivePose&);

// Exterior minimum separation along the same straight relative material path
// used by native discovery. The gradient/derivatives are with respect to END.
// Solid intersection and radial singularities return invalid, so a caller must
// retain its acquired recovery contact rather than treating them as clear.
struct StructuralContactPathGeometryResult : StructuralContactGeometryResult {
    double fraction=0;
    glm::dvec3 gradient{0},fractionGradient{0},pathPoint{0};
};
StructuralContactPathGeometryResult EvaluateStructuralContactPathGeometry(glm::dvec3 start,glm::dvec3 end,const PrimitivePose&);
