#!/usr/bin/env python3
"""Run selected M83 corrective checks sequentially using existing binaries.

No configure, build, bake, fixture patch, retry, commit, or push is performed.
Every invocation needs a new output directory. The default is the focused
foundation/rest/specimen set; the complete car matrix is always explicit.

Examples (commands are plans until this script is invoked):
  python3 scripts/m83_structural_corrective.py --list
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-focus-01 --plan
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-car-01 \
      --cases normal low medium high offset comparison rotated group
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-cold-01 \
      --cases cold-write cold-read
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-stream-01 \
      --cases stream-write stream-read
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-step-01 \
      --cases sensitivity-60x4 sensitivity-60x8 sensitivity-120x4
  python3 scripts/m83_structural_corrective.py --output /tmp/m83-export-01 \
      --cases export exported-medium package-smoke \
      --package-dir /tmp/Judas_M83_Structural_01

Separate read invocation: --cases cold-read --cold-from /tmp/m83-write-01.
Likewise stream-read accepts --stream-from. The source writer must have passed.
Use native graphics for host timings. Software mode is explicitly identified;
it does not establish the host's native rendering performance or human approval.
"""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
APP = 'judas_structural_crash_application_tests'
NATIVE = {
    'network': ('judas_structural_network_tests', False),
    'normal-qp': ('judas_structural_contact_qp_tests', False),
    'contact-skin': ('judas_structural_contact_skin_tests', False),
    'coupled': ('judas_coupled_physics_tests', False),
    'world-coupling': ('judas_structural_world_coupling_tests', True),
    'm79-structure': ('judas_structural_tests', False),
    'm80-bending': ('judas_bending_tests', False),
    'm83-damage': ('judas_mechanical_damage_tests', False),
    'm83-connections': ('judas_mechanical_connection_tests', False),
    'm83-script': ('judas_mechanical_damage_script_tests', True),
    'powertrain': ('judas_powertrain_tests', False),
}
APPLICATION = {
    'rest': ('medium', 'rest'),
    'normal': ('normal', 'watch'),
    'low': ('low', 'watch'),
    'medium': ('medium', 'watch'),
    'high': ('high', 'watch'),
    'offset': ('offset', 'watch'),
    'comparison': ('comparison', 'watch'),
    'rotated': ('rotated', 'watch'),
    'group': ('group', 'watch'),
    'specimen': ('specimen', 'watch'),
    'cold-write': ('medium', 'write'),
    'cold-read': ('medium', 'read'),
    'impact-write': ('low', 'impact-write'),
    'impact-read': ('low', 'impact-read'),
    'post-write': ('low', 'post-write'),
    'post-read': ('low', 'post-read'),
    'lifecycle': ('medium', 'lifecycle'),
    'streaming': ('medium', 'streaming'),
    'stream-write': ('medium', 'stream-write'),
    'stream-read': ('medium', 'stream-read'),
}
SENSITIVITY = {
    'sensitivity-60x4': (1 / 60, 4),
    'sensitivity-60x8': (1 / 60, 8),
    'sensitivity-120x4': (1 / 120, 4),
}
EXTRA = ('export', 'exported-medium', 'package-smoke')
ALIASES = {
    'foundation': ('network', 'normal-qp', 'contact-skin', 'coupled', 'world-coupling'),
    'regressions': ('m79-structure', 'm80-bending', 'm83-damage',
                    'm83-connections', 'm83-script', 'powertrain'),
}
DEFAULT = ('foundation', 'rest', 'specimen')
READERS = {
    'cold-read': ('cold-write', 'expected-physical.bin', 'cold_from'),
    'stream-read': ('stream-write', 'retained-annex.bin', 'stream_from'),
    'impact-read': ('impact-write', 'expected-physical.bin', 'impact_from'),
    'post-read': ('post-write', 'expected-physical.bin', 'post_from'),
}


class Blocked(RuntimeError):
    """A required earlier case did not provide a reviewable input."""


def inside(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def tree_hashes(path):
    return {str(p.relative_to(path)): digest(p)
            for p in sorted(path.rglob('*')) if p.is_file()}


def save_json(path, value):
    # The directory belongs to this fresh run. Update only this run's ledger.
    temp = path.with_name(path.name + '.pending')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def expand(tokens):
    result = []
    available = set(NATIVE) | set(APPLICATION) | set(SENSITIVITY) | set(EXTRA)
    for token in tokens:
        for name in token.split(','):
            for case in ALIASES.get(name, (name,)):
                if case not in available:
                    raise ValueError('Unknown case: ' + case)
                if case in result:
                    raise ValueError('Duplicate case: ' + case)
                result.append(case)
    return result


def environment(args, case_dir):
    env = {k: v for k, v in os.environ.items() if not k.startswith('JUDAS_')}
    env.update(SDL_AUDIODRIVER='dummy', JUDAS_WORLD_STATE='none',
               XDG_DATA_HOME=str(case_dir / 'user-data'))
    if args.graphics == 'software':
        env.update(SDL_VIDEODRIVER='offscreen', LIBGL_ALWAYS_SOFTWARE='1')
    else:
        env['SDL_VIDEODRIVER'] = 'x11'
        env.pop('LIBGL_ALWAYS_SOFTWARE', None)
    if args.profile:
        env.update(JUDAS_PROFILE='1',
                   JUDAS_PROFILE_OUTPUT=str(case_dir / 'artifacts/profile.json'))
    if args.iteration_trace:
        env.update(JUDAS_STRUCTURAL_ITERATION_TRACE=str(case_dir / 'artifacts/iterations.csv'),
                   JUDAS_STRUCTURAL_ITERATION_TRACE_SKIP=str(args.trace_skip))
    return env


def command_for(case, args, case_dir):
    artifact = case_dir / 'artifacts'
    if case in NATIVE:
        binary, takes_output = NATIVE[case]
        return [str(args.build_dir / binary)] + ([str(artifact / 'fixtures')] if takes_output else [])
    if case == 'export':
        return [str(args.build_dir / 'judas_export'),
                str(case_dir / 'project/structural_crash_lab.judasproj'),
                str(args.package_dir), str(args.build_dir / 'judas')]
    if case == 'package-smoke':
        return [str(args.package_dir / 'judas')]
    if case == 'exported-medium':
        return [str(args.build_dir / APP), str(args.package_dir / 'Scenes/medium.judas'),
                'watch', str(artifact)]
    if case in SENSITIVITY:
        dt, substeps = SENSITIVITY[case]
        return [str(args.build_dir / APP),
                str(case_dir / 'project/Scenes' / (args.sensitivity_scene + '.judas')),
                'watch', str(artifact), format(dt, '.17g'), str(substeps)]
    scene, mode = APPLICATION[case]
    return [str(args.build_dir / APP), str(case_dir / 'project/Scenes' / (scene + '.judas')),
            mode, str(artifact)]


def source_writer(case, args, passed):
    writer, witness, option = READERS[case]
    external = getattr(args, option)
    source = external if external else args.output / writer
    if source.name != writer:
        source = source / writer
    result = json.loads((source / 'RESULTS.json').read_text())
    if result.get('state') != 'passed':
        raise Blocked('Reader requires a passed writer: ' + str(source))
    if not external and writer not in passed:
        raise Blocked('Select ' + writer + ' before ' + case + ', or supply --' + option.replace('_', '-'))
    if result.get('binary_sha256') != digest(args.build_dir / APP):
        if not (case in ('impact-read','post-read') and args.compare_diagnostic_binary):
            raise Blocked('Writer used another application candidate; create a fresh write run with this binary')
    if not (source / 'artifacts' / witness).is_file():
        raise Blocked('Writer has no retained-state witness: ' + witness)
    return source, witness


def prepare(case, args, case_dir, passed):
    if case in READERS:
        source, witness = source_writer(case, args, passed)
        # The fresh process gets the actual successful save, not a replayed
        # impact or a new authored state. Its logs/traces have separate paths.
        shutil.copytree(source / 'project', case_dir / 'project')
        # Shipping save slots are user data, not writable project content.
        # Copy the exact successful writer's user-data tree to the fresh
        # reader's isolated location, preserving project identity and bytes.
        if (source / 'user-data').is_dir():
            shutil.copytree(source / 'user-data', case_dir / 'user-data')
        shutil.copy2(source / 'artifacts' / witness, case_dir / 'artifacts' / witness)
        writer_result = json.loads((source / 'RESULTS.json').read_text())
        return {'writer': str(source), 'witness_sha256': digest(source / 'artifacts' / witness),
                'writer_binary_sha256': writer_result.get('binary_sha256'),
                'diagnostic_binary_change': writer_result.get('binary_sha256') != digest(args.build_dir / APP)}
    if case in APPLICATION or case in SENSITIVITY or case == 'export':
        shutil.copytree(args.project_dir, case_dir / 'project',
                        ignore=shutil.ignore_patterns('Saves', '__pycache__'))
    return {}


def terminate_owned(process):
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()


def run_command(command, cwd, env, log, timeout):
    with log.open('x') as stream:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            return process.wait(timeout=timeout), False
        except subprocess.TimeoutExpired:
            stream.write('\nRUNNER TIMEOUT; terminating only this process group.\n')
            stream.flush()
            terminate_owned(process)
            return process.returncode, True
        finally:
            terminate_owned(process)


def shipping_smoke(args, case_dir, env):
    if args.graphics != 'native':
        raise RuntimeError('package-smoke uses the native X11 window close path; select --graphics native')
    before = tree_hashes(args.package_dir)
    spec = importlib.util.spec_from_file_location('m83_owned_window', ROOT / 'scripts/m60_package_smoke.py')
    windows = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(windows)
    # No input harness or altered package script: launch the shipping binary
    # without arguments from an unrelated working directory and close its PID.
    with (case_dir / 'runtime.log').open('x') as stream:
        process = subprocess.Popen([str(args.package_dir / 'judas')], cwd='/tmp',
                                   env=env, stdout=stream, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            time.sleep(args.shipping_seconds)
            if process.poll() is not None:
                raise RuntimeError('Shipping runtime exited before the normal window close')
            window = windows.close_window(process.pid)
            code = process.wait(timeout=min(args.timeout, 30))
        finally:
            terminate_owned(process)
    text = (case_dir / 'runtime.log').read_text(errors='replace')
    unchanged = before == tree_hashes(args.package_dir)
    clean = code == 0 and 'Project:' in text and 'Asset problem:' not in text and 'script asset=' not in text
    return code, {'closed_own_window': window, 'package_unchanged': unchanged,
                  'ordinary_startup_clean_exit': clean, 'pass': clean and unchanged}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--output', type=Path, help='New evidence/workspace directory; never reused')
    parser.add_argument('--cases', nargs='+', default=DEFAULT, help='Named cases, comma-separated names, or foundation/regressions aliases')
    parser.add_argument('--build-dir', type=Path, default=ROOT / 'build', help='Existing candidate binary directory; never built here')
    parser.add_argument('--project-dir', type=Path, default=ROOT / 'projects/structural_crash_lab')
    parser.add_argument('--package-dir', type=Path, help='Fresh export directory outside the repository and build tree')
    parser.add_argument('--cold-from', type=Path, help='Earlier successful runner directory or its cold-write case')
    parser.add_argument('--stream-from', type=Path, help='Earlier successful runner directory or its stream-write case')
    parser.add_argument('--impact-from', type=Path, help='Earlier exact preimpact writer for bounded first-boundary diagnostics')
    parser.add_argument('--post-from', type=Path, help='Earlier exact postimpact writer for bounded resumed-driver diagnostics')
    parser.add_argument('--compare-diagnostic-binary', action='store_true', help='Only impact-read/post-read: intentionally replay a preserved earlier-binary snapshot; not final cold-save certification')
    parser.add_argument('--sensitivity-scene', choices=('normal', 'low', 'medium', 'high', 'offset'), default='medium')
    parser.add_argument('--graphics', choices=('native', 'software'), default='native')
    parser.add_argument('--timeout', type=float, default=600, help='Seconds per sequential command; no automatic retry')
    parser.add_argument('--shipping-seconds', type=float, default=5)
    parser.add_argument('--profile', action='store_true', help='Opt into native profiler overhead; fixture stage costs are always recorded')
    parser.add_argument('--iteration-trace', action='store_true', help='Bounded first-boundary native solver diagnostic')
    parser.add_argument('--trace-skip', type=int, default=0, help='Skip initial structural intervals before the bounded diagnostic window')
    parser.add_argument('--keep-going', action='store_true', help='Continue selected independent cases after failure; dependent cases remain blocked')
    parser.add_argument('--list', action='store_true', help='List cases without running or creating files')
    parser.add_argument('--plan', action='store_true', help='Print selected commands without running or creating files')
    args = parser.parse_args()
    if args.list:
        print('Default:', ' '.join(DEFAULT))
        print('Aliases:', json.dumps(ALIASES))
        print('Cases:', ' '.join((*NATIVE, *APPLICATION, *SENSITIVITY, *EXTRA)))
        return 0
    try:
        cases = expand(args.cases)
    except ValueError as error:
        parser.error(str(error))
    if not args.output:
        parser.error('--output is required, including for --plan')
    for name in ('output', 'build_dir', 'project_dir', 'package_dir', 'cold_from', 'stream_from', 'impact_from'):
        value = getattr(args, name)
        if value is not None:
            setattr(args, name, value.resolve())
    if inside(args.output, args.build_dir) or inside(args.output, args.project_dir):
        parser.error('Evidence/project snapshots must be outside the build and source project directories')
    if args.output.exists():
        parser.error('Output already exists; retain it and choose a new directory for any retry')
    if args.timeout <= 0 or not 0 < args.shipping_seconds < args.timeout:
        parser.error('Require positive timeout and 0 < shipping-seconds < timeout')
    if args.trace_skip < 0:
        parser.error('--trace-skip must be nonnegative')
    if any(case in EXTRA for case in cases):
        if args.package_dir is None:
            parser.error('--package-dir is required for export or package checks')
        if inside(args.package_dir, ROOT) or inside(args.package_dir, args.build_dir):
            parser.error('Package executables must stay outside the repository and build tree')
        if inside(args.output, args.package_dir):
            parser.error('Export directory must not contain or replace the evidence directory')
        if 'export' in cases and args.package_dir.exists():
            parser.error('Export destination already exists; choose a fresh package directory')
        for case in ('exported-medium', 'package-smoke'):
            if case in cases and 'export' in cases and cases.index(case) < cases.index('export'):
                parser.error('Select export before ' + case)
    for case, (writer, _, option) in READERS.items():
        if case in cases and not getattr(args, option) and (writer not in cases or cases.index(writer) > cases.index(case)):
            parser.error('Select ' + writer + ' before ' + case + ' or provide --' + option.replace('_', '-'))
    plan = [{'case': case, 'command': command_for(case, args, args.output / case),
             'cwd': '/tmp' if case in ('exported-medium', 'package-smoke') else str(ROOT)} for case in cases]
    if args.plan:
        print(json.dumps({'graphics': args.graphics, 'sequential': True, 'builds': False, 'commands': plan}, indent=2))
        return 0
    args.output.mkdir(parents=True, exist_ok=False)
    manifest = {'scope': 'Selected Linux M83 corrective checks; automated evidence does not establish human acceptance',
                'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'graphics': args.graphics, 'profile_enabled': args.profile, 'builds': False,
                'selected_cases': cases, 'default_focused_set': list(DEFAULT), 'commands': [],
                'runner_sha256': digest(Path(__file__)), 'project_source_sha256': tree_hashes(args.project_dir),
                'human_validation': 'NOT CLAIMED', 'overall_pass': False}
    for label, command in (('head', ['git', 'rev-parse', 'HEAD']), ('working_tree', ['git', 'status', '--short'])):
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        manifest[label] = result.stdout.strip() if result.returncode == 0 else result.stderr.strip()
    save_json(args.output / 'RESULTS.json', manifest)
    passed = set()
    for item in plan:
        case = item['case']; case_dir = args.output / case
        (case_dir / 'artifacts').mkdir(parents=True, exist_ok=False)
        record = dict(item, state='running', timeout_seconds=args.timeout)
        started = time.monotonic()
        save_json(case_dir / 'RESULTS.json', record)
        print('Starting', case, flush=True)
        try:
            if case in ('exported-medium', 'package-smoke') and 'export' in cases and 'export' not in passed:
                raise Blocked('This run did not produce a successful export')
            record.update(prepare(case, args, case_dir, passed))
            binary = Path(item['command'][0])
            if not binary.is_file() or not os.access(binary, os.X_OK):
                raise RuntimeError('Missing existing candidate executable; build it separately: ' + str(binary))
            record.update(binary_sha256=digest(binary), binary_modified_ns=binary.stat().st_mtime_ns)
            if (case_dir / 'project').exists():
                save_json(case_dir / 'PROJECT_SHA256.json', tree_hashes(case_dir / 'project'))
            env = environment(args, case_dir)
            record['environment'] = {k: env[k] for k in ('SDL_VIDEODRIVER', 'SDL_AUDIODRIVER', 'JUDAS_WORLD_STATE', 'XDG_DATA_HOME')}
            record['environment'].update({k:v for k,v in env.items() if k.startswith('JUDAS_STRUCTURAL_')})
            if case == 'package-smoke':
                code, extra = shipping_smoke(args, case_dir, env); record.update(extra)
                success = code == 0 and extra['pass']
            else:
                code, timed_out = run_command(item['command'], item['cwd'], env, case_dir / 'runtime.log', args.timeout)
                record['timed_out'] = timed_out; success = code == 0 and not timed_out
            record.update(exit_code=code, state='passed' if success else 'failed')
            if case == 'export' and args.package_dir.is_dir():
                record['package'] = str(args.package_dir)
                save_json(case_dir / 'PACKAGE_SHA256.json', tree_hashes(args.package_dir))
            if success:
                passed.add(case)
        except Exception as error:
            record.update(state='blocked' if isinstance(error, Blocked) else 'failed', error=str(error))
            with (case_dir / 'runner-error.txt').open('x') as stream:
                stream.write(str(error) + '\n')
        record['seconds'] = time.monotonic() - started
        save_json(case_dir / 'RESULTS.json', record)
        manifest['commands'].append(record)
        manifest['overall_pass'] = len(passed) == len(cases)
        save_json(args.output / 'RESULTS.json', manifest)
        print(case, record['state'], '%.3f seconds' % record['seconds'], flush=True)
        if record['state'] != 'passed' and not args.keep_going:
            break
    manifest['not_run'] = [case for case in cases if not any(item['case'] == case for item in manifest['commands'])]
    manifest['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    save_json(args.output / 'RESULTS.json', manifest)
    return 0 if manifest['overall_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
