#!/usr/bin/env python3
"""Original M83 structural crash content, separate from preserved damage labs.

The source files are reusable mechanical authoring data. A steel beam contributes
area * rest length * density; a skin triangle contributes thickness * area *
density. Scene bodies account for the cabin and finite suspension hardware.
Driver scripts issue ordinary source, brake and steering commands only.
"""
from pathlib import Path
import argparse
import itertools
import json
import math
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'projects/structural_crash_lab'
DENSITY = 7850.0
IDS = {name: '83'*10 + 'c83c' + f'{index:08x}' for index, name in enumerate(
    ('controller', 'math', 'ui', 'font', 'nominal', 'strong', 'weak', 'specimen',
     'car', 'specimen_prefab', 'cabin', 'wheel', 'paint', 'metal', 'world'), 1)}

# These are declared engineering demonstration targets, not automotive
# calibration. Keep their record intact if a measured case fails.
PROFILES = {
    'normal': {'target_mps': 10, 'bump_m': .08, 'no_plastic': True,
               'residual_limit_m': .002, 'broken_paths': 0},
    'low': {'target_mps': 5, 'speed_tolerance_mps': .5,
            'retained_crush_m': [0, .05], 'broken_paths': 0},
    'medium': {'target_mps': 15, 'speed_tolerance_mps': .75,
               'retained_crush_m': [.10, .35], 'yield_before_break': True},
    'high': {'target_mps': 25, 'speed_tolerance_mps': 1,
             'retained_crush_m': [.25, .65], 'physical_path_failure': True,
             'yield_before_break': True},
    'offset': {'target_mps': 15, 'speed_tolerance_mps': .75, 'overlap': .4,
               'crush_asymmetry_m': .05, 'mount_displacement_m': .02,
               'alignment_change_degrees': 2},
    'comparison': {'target_mps': 15, 'strength_factors': [.75, 1, 1.25]},
}


def vec(value):
    return ' '.join(f'{number:.10g}' for number in value)


def rotation(axis, angle):
    return (math.cos(angle/2), *(number*math.sin(angle/2) for number in axis))


def rotate(q, v):
    w, x, y, z = q
    cross = (y*v[2]-z*v[1], z*v[0]-x*v[2], x*v[1]-y*v[0])
    cross2 = (y*cross[2]-z*cross[1], z*cross[0]-x*cross[2], x*cross[1]-y*cross[0])
    return tuple(v[i]+2*(w*cross[i]+cross2[i]) for i in range(3))


def settings(name, next_id=10000):
    return ('JudasScene 3\nsettings\n  name '+json.dumps(name)+'\n'
            '  world-origin 0 0 0\n  sun-color 1 .97 .91\n'
            '  sun-direction -.3 .8 .5\n  ambient .34 .37 .40\n'
            f'  fluid-scale 1\n  fidelity-policy none\n  next-id {next_id}\nend\n')


def object_(identity, name, position, fields='', q=(1, 0, 0, 0), parent=0):
    # Version-3 component readers require the complete base component record,
    # even where a box does not use a sphere radius or a mesh asset. Keep these
    # emitted defaults aligned with SceneSerialization's registered grammar.
    authored = {line.strip().split()[0] for line in fields.splitlines() if line.strip()}
    defaults = {}
    if 'render' in authored:
        defaults.update({'render.half-extents': '.5 .5 .5', 'render.radius': '.5',
                         'render.color': '.8 .8 .8', 'render.alpha': '1',
                         'render.secondary-color': '.8 .8 .8', 'render.secondary-alpha': '1',
                         'render.mesh-asset': '""', 'render.texture-asset': '""'})
    if 'body' in authored:
        defaults.update({'body.half-extents': '.5 .5 .5', 'body.radius': '.5',
                         'body.terrain': '""', 'body.mass': '1', 'body.friction': '.7',
                         'body.restitution': '0', 'body.initial-velocity': '0 0 0',
                         'body.pickable': 'false', 'body.managed': 'false',
                         'body.compound-count': '0'})
    if 'player-start' in authored:
        defaults['player-start.yaw'] = '0'
    if 'wheel.enabled' in authored:
        defaults.update({'wheel.requiredTags': '0', 'wheel.excludedTags': '0'})
    fields += ''.join(f'  {key} {value}\n' for key, value in defaults.items() if key not in authored)
    return f'object {identity} {json.dumps(name)}\n'+(f'  parent {parent}\n' if parent else '')+\
        f'  position {vec(position)}\n  rotation {vec(q)}\n  scale 1 1 1\n'+fields+'end\n'


def render(half, color):
    return f'  render box\n  render.half-extents {vec(half)}\n  render.color {vec(color)}\n'


def body(half, mass=0, layer=0, mask=7):
    return f'  body {"dynamic" if mass else "static"} box\n  body.half-extents {vec(half)}\n'+\
        f'  body.mass {mass or 1}\n  body.friction .7\n  body.restitution 0\n'+\
        f'  body.collision-layer {layer}\n  body.collision-mask {mask}\n'


def compound(parts, mass, layer=1):
    return ('  body dynamic compound\n'+f'  body.mass {mass}\n  body.friction .7\n  body.restitution 0\n'
            f'  body.collision-layer {layer}\n  body.collision-mask 7\n'
            f'  body.compound-count {len(parts)}\n'+''.join(
                '  body.compound-box '+vec(center)+' '+vec(half)+'\n' for _, center, half in parts))


def metadata(relative, name, kind):
    (OUT/(relative+'.judasmeta')).write_text(
        f'JudasAssetMeta 1\nid "{IDS[name]}"\ntype {kind}\nsource ""\n')


class Network:
    """A locally braced graph and explicit panel/support ownership."""
    def __init__(self):
        self.nodes, self.beams, self.surfaces, self.groups = [], [], [], {}
        self.node_names, self.beam_lookup = [], {}

    def node(self, name, point):
        self.node_names.append(name)
        self.nodes.append(point)
        return len(self.nodes)-1

    def beam(self, a, b, region=0, area=.00012, name=None):
        key = tuple(sorted((a, b)))
        if key in self.beam_lookup:
            return self.beam_lookup[key]
        index = len(self.beams)
        self.beams.append((name or f'{self.node_names[a]}--{self.node_names[b]}', a, b, region, area))
        self.beam_lookup[key] = index
        return index

    def triangle(self, a, b, c, region=2):
        # Every skin corner has a deliberate local graph connection. A broken
        # perimeter hides only its own patch; no long triangle crosses a gap.
        supports = [self.beam(a, b, region, .000008),
                    self.beam(b, c, region, .000008),
                    self.beam(c, a, region, .000008)]
        self.surfaces.append((a, b, c, region, supports))

    def quad(self, a, b, c, d, region=2):
        self.triangle(a, b, c, region)
        self.triangle(a, c, d, region)

    def mass(self, thickness=.0008):
        beam_volume = sum(area*math.dist(self.nodes[a], self.nodes[b])
                          for _, a, b, _, area in self.beams)
        panel_volume = 0
        for a, b, c, _, _ in self.surfaces:
            u = [self.nodes[b][i]-self.nodes[a][i] for i in range(3)]
            v = [self.nodes[c][i]-self.nodes[a][i] for i in range(3)]
            cross = (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])
            panel_volume += math.sqrt(sum(x*x for x in cross))*.5*thickness
        return DENSITY*beam_volume, DENSITY*panel_volume

    def source(self, strength=1):
        rows = ['JudasStructuralSource 1']
        rows += ['node '+vec(point) for point in self.nodes]
        # Frame/mount sections stay elastic during ordinary handling. Crush
        # members yield in compression earlier than they fail; tensile plastic
        # extension is tightly bounded so intact material cannot form ropes.
        regions = [
            ('crush-rail', 200e9, 35, 260e6, 200e6, 600e6, 360e6, 140e6, .60, .045, .0008),
            ('mount-brace', 200e9, 35, 450e6, 350e6, 750e6, 600e6, 180e6, .35, .025, .0008),
            ('body-panel', 70e9, 12, 160e6, 120e6, 320e6, 250e6, 75e6, .70, .035, .0008),
        ]
        for key, E, damping, yt, yc, ut, uc, hardening, shortening, extension, thickness in regions:
            rows.append('region '+json.dumps(key)+' '+vec(
                (E, damping, yt*strength, yc*strength, ut*strength, uc*strength,
                 hardening*strength, shortening, extension, thickness)))
        rows += [f'beam {json.dumps(name)} {a} {b} {region} {area:.10g}'
                 for name, a, b, region, area in self.beams]
        rows += [f'surface {a} {b} {c} {region} {len(supports)} '+vec(supports)
                 for a, b, c, region, supports in self.surfaces]
        rows += ['group '+json.dumps(name)+f' {len(nodes)} '+vec(nodes)
                 for name, nodes in self.groups.items()]
        return '\n'.join(rows+['end'])+'\n'


def front_network():
    graph = Network()
    stations = (-.74, -1.03, -1.30, -1.68, -2.08)
    rails = {}
    for side, suffix in ((-1, 'left'), (1, 'right')):
        rail = []
        for s, z in enumerate(stations):
            # A small authored rail taper is original geometry, not a damaged
            # pose. Each bay is braced against shear, extension and twisting.
            y_offset = .012*math.sin(s*math.pi*.5)
            corners = [graph.node(f'rail-{suffix}-{s}-{k}',
                                  (side*.49+dx, dy+y_offset, z))
                       for k, (dx, dy) in enumerate(((-.10, -.11), (.10, -.11),
                                                   (.10, .11), (-.10, .11)))]
            for a, b in itertools.combinations(corners, 2):
                graph.beam(a, b, 1, .00004)
            if rail:
                for k in range(4):
                    graph.beam(rail[-1][k], corners[k], 0, .00012)
                    graph.beam(rail[-1][k], corners[(k+1)%4], 0, .000035)
                    graph.beam(rail[-1][k], corners[(k+2)%4], 0, .00002)
            rail.append(corners)
        rails[side] = rail
        graph.groups['rear_'+suffix] = rail[0]
        graph.groups['mount_'+suffix] = rail[2]
        graph.groups['tip_'+suffix] = rail[-1]
        graph.groups['rail_'+suffix] = [n for station in rail for n in station]
    skin = []
    for s, z in enumerate(stations):
        upper_y = .31-.10*s/(len(stations)-1)
        row = [graph.node(f'bonnet-{s}-{k}', (x, upper_y, z))
               for k, x in enumerate((-.83, 0, .83))]
        for side, index in ((-1, 0), (1, 2)):
            # Skin supports remain within this section. They do not bypass
            # longitudinal crush zones through a rigid front chassis box.
            for corner in rails[side][s][2:]:
                graph.beam(row[index], corner, 2, .000015)
                graph.beam(row[1], corner, 2, .000008)
        graph.beam(row[0], row[1], 2, .00001)
        graph.beam(row[1], row[2], 2, .00001)
        if skin:
            for k in range(2):
                graph.quad(skin[-1][k], skin[-1][k+1], row[k+1], row[k])
        skin.append(row)
    fender_lower = {}
    for side, index, suffix in ((-1, 0, 'left'), (1, 2, 'right')):
        lower = []
        for s, z in enumerate(stations):
            # Wheel-arch clearance is explicit physical geometry. A raised
            # lower fender over the tyre avoids initial overlapping contacts.
            y = -.10 if s in (0, 4) else .14
            lower.append(graph.node(f'fender-{suffix}-{s}', (side*.86, y, z)))
            # At the wheel carrier, route the fender support above its finite
            # bearing. A lower-corner diagonal would pass through the bearing
            # even though both endpoint nodes lie outside that rigid shape.
            support_corner = (3 if side < 0 else 2) if s == 2 else (0 if side < 0 else 1)
            graph.beam(lower[-1], rails[side][s][support_corner], 2, .000012)
            graph.beam(lower[-1], skin[s][index], 2, .000012)
            if s:
                quad = (skin[s-1][index], lower[s-1], lower[s], skin[s][index])
                graph.quad(*(reversed(quad) if side < 0 else quad))
        graph.groups['panel_'+suffix] = [row[index] for row in skin]+lower
        graph.groups['rear_'+suffix] += [skin[0][index], lower[0]]
        fender_lower[side] = lower
    # A closed finite front skin leads the rigid wheel hardware by 0.78m.
    # Its front, lower and side faces are the actual crash envelope.
    bumper_front = [graph.node(f'bumper-front-{k}', (x, y, -2.22))
                    for k, (x, y) in enumerate(((-.86, -.10), (0, -.10), (.86, -.10),
                                                (-.86, .21), (0, .21), (.86, .21)))]
    bumper_rear = [fender_lower[-1][-1], graph.node('bumper-rear-center', (0, -.10, -2.08)),
                   fender_lower[1][-1]]
    for i in range(2):
        graph.quad(bumper_front[i+3], bumper_front[i+4], bumper_front[i+1], bumper_front[i])
        graph.quad(skin[-1][i], skin[-1][i+1], bumper_front[i+4], bumper_front[i+3])
        graph.quad(bumper_rear[i+1], bumper_rear[i], bumper_front[i], bumper_front[i+1])
    # The rear opens into the adjoining bonnet/fenders. An internal closing
    # face would give the bonnet seam three incident collision triangles.
    graph.quad(bumper_rear[0], skin[-1][0], bumper_front[3], bumper_front[0])
    graph.quad(skin[-1][2], bumper_rear[2], bumper_front[2], bumper_front[5])
    for side, i in ((-1, 0), (1, 2)):
        for node in (bumper_front[i], bumper_front[i+3], bumper_rear[i]):
            for rail_node in rails[side][-1]:
                graph.beam(node, rail_node, 0, .00004)
    graph.groups['bumper_left'] = [bumper_front[0], bumper_front[3], bumper_rear[0]]
    graph.groups['bumper_right'] = [bumper_front[2], bumper_front[5], bumper_rear[2]]
    graph.groups['bonnet'] = [n for row in skin for n in row]
    graph.groups['rear_left'].append(skin[0][1])
    # One owner for the central rear corner avoids double-pinning a node.
    return graph


CABIN_PARTS = [
    ('Cabin floor and rear frame', (0, -.18, .43), (.72, .065, 1.17)),
    ('Firewall', (0, .10, -.69), (.72, .29, .05)),
    ('Rear body', (0, -.04, 1.30), (.76, .17, .27)),
    ('Left sill', (-.74, -.035, .24), (.045, .13, .92)),
    ('Right sill', (.74, -.035, .24), (.045, .13, .92)),
    ('Left front pillar', (-.66, .42, -.52), (.045, .31, .045)),
    ('Right front pillar', (.66, .42, -.52), (.045, .31, .045)),
    ('Left rear pillar', (-.66, .42, .94), (.045, .31, .045)),
    ('Right rear pillar', (.66, .42, .94), (.045, .31, .045)),
    ('Cabin roof', (0, .75, .20), (.66, .035, .78)),
    ('Left door outer panel', (-.791, .08, .21), (.015, .17, .72)),
    ('Right door outer panel', (.791, .08, .21), (.015, .17, .72)),
]


def wheel(chassis, mount):
    values = {'enabled': 'true', 'chassis': str(chassis), 'mount': vec(mount),
              'orientation': '1 0 0 0', 'radius': '.32', 'minLength': '.10',
              'restLength': '.35', 'maxLength': '.53', 'springStiffness': '26000',
              'damping': '1900', 'spinInertia': '.8', 'friction': '1',
              'rollingResistance': '.012', 'collisionLayer': '1', 'collisionMask': '1'}
    return ''.join(f'  wheel.{name} {value}\n' for name, value in values.items())


def drivetrain(root):
    graph = {'version': 1, 'enabled': True, 'shafts': [
        {'name': 'motor', 'kind': 'internal', 'inertia': .4, 'initialAngularVelocity': 0,
         'viscousDrag': .01, 'target': '0', 'bearing': str(root), 'axis': [1, 0, 0]}],
        'sources': [{'name': 'motor', 'shaft': 0, 'kind': 'electric',
                     'torqueCurve': [], 'maxTorque': 180, 'maxPower': 50000, 'starterTorque': 0}],
        'links': [], 'brakes': []}
    for i in range(4):
        graph['shafts'].append({'name': f'wheel{i+1}', 'kind': 'wheel', 'inertia': .2,
            'initialAngularVelocity': 0, 'viscousDrag': 0, 'target': str(root+1+i),
            'bearing': '0', 'axis': [1, 0, 0]})
        row = {'name': f'drive{i+1}', 'kind': 'clutch', 'input': 0, 'output': i+1,
               'outputB': 0, 'ratio': .25, 'maxTorque': 350}
        if i < 2:
            suffix = 'left' if i == 0 else 'right'
            row['connection'] = {'owner': str(root+20), 'attachment': 'mount_'+suffix,
                                  'rootAttachment': 'rear_'+suffix}
        graph['links'].append(row)
        graph['brakes'].append({'name': f'wheel{i+1}', 'shaft': i+1, 'maxTorque': 400})
    return '  powertrain.graph '+json.dumps(json.dumps(graph, separators=(',', ':')))+'\n'


def deformable(asset, attachments):
    values = {'asset': IDS[asset], 'enabled': 1, 'selfContact': 1, 'attachedBodyContact': 1, 'substeps': 8,
              'iterations': 12, 'collisionLayer': 2, 'collisionMask': 7,
              'material.density': DENSITY, 'material.stretchCompliance': 1e-6,
              'material.shearCompliance': 1e-6, 'material.bendCompliance': 1e-6,
              'material.volumeCompliance': 1e-6, 'material.damping': 0,
              'material.thickness': .015, 'material.friction': .5,
              'material.airDrag': 0, 'material.yieldStrain': 0, 'material.plasticRate': 0,
              'material.maximumPlasticStrain': .7, 'airVelocity': '0 0 0'}
    fields = ''.join(f'  deformable.{key} {json.dumps(str(value))}\n' for key, value in values.items())
    rows = [str(len(attachments))]
    for name, target, offset in attachments:
        rows += [json.dumps(name), '1', str(target), '""', vec(offset), '1']
    fields += '  deformable.attachments '+json.dumps(' '.join(rows))+'\n'
    return fields


def car(root, position, variant='nominal', q=(1, 0, 0, 0), gravity_source=0):
    color = {'nominal': (.94, .38, .12), 'strong': (.12, .62, .49),
             'weak': (.50, .43, .80)}[variant]
    selection = (f'  gravity-selection.mode "field"\n  gravity-selection.source {gravity_source}\n'
                 '  gravity-selection.acceleration 0 0 0\n') if gravity_source else ''
    rows = [object_(root, 'Original compact hatch / rigid central cabin', position,
                    compound(CABIN_PARTS, 500)+drivetrain(root)+selection, q)]
    for i, (name, p, half) in enumerate(CABIN_PARTS):
        rows.append(object_(root+100+i, name, p, render(half, color), parent=root))
    for side, index, suffix in ((-1, 0, 'left'), (1, 1, 'right')):
        center = (side*.64, .012*math.sin(math.pi), -1.30)
        parts = [('Rail mount bracket', (-side*.14, 0, 0), (.11, .11, .09)),
                 ('Finite suspension arm', (0, -.10, 0), (.20, .035, .10)),
                 ('Wheel bearing', (side*.14, -.045, 0), (.055, .075, .07))]
        rows.append(object_(root+10+index, 'Independent '+suffix+' suspension mount assembly', center,
                            compound(parts, 10)+selection, parent=root))
        for j, (name, p, half) in enumerate(parts):
            rows.append(object_(root+120+index*5+j, suffix+' '+name, p,
                                render(half, (.24, .29, .32)), parent=root+10+index))
    fields = deformable(variant, [('rear_left', root, (0, 0, 0)),
        ('rear_right', root, (0, 0, 0)),
        ('mount_left', root+10, (.64, 0, 1.30)),
        ('mount_right', root+11, (-.64, 0, 1.30))])
    fields += render((.86, .3, .74), color)+selection
    rows.append(object_(root+20, 'Steel front rails, bonnet, fenders and leading bumper skin',
                        (0, 0, 0), fields, parent=root))
    for i, (side, z) in enumerate(((-1, -1.30), (1, -1.30), (-1, 1.12), (1, 1.12))):
        owner = root+10+i if i < 2 else root
        mount = (side*.14, .08, 0) if i < 2 else (side*.78, .08, z)
        local_position = (side*.14, -.27, 0) if i < 2 else (side*.78, -.27, z)
        rows.append(object_(root+1+i, 'Front physical tyre' if i < 2 else 'Rear physical tyre', local_position,
            f'  render mesh\n  render.mesh-asset "{IDS["wheel"]}"\n  render.color .045 .052 .06\n'+wheel(owner, mount), parent=owner))
    rows += [object_(root+140, 'Front glazing inside supported cabin', (0, .44, -.575),
                     render((.59, .27, .012), (.06, .20, .25)), parent=root),
             object_(root+141, 'Rear glazing', (0, .43, .987),
                     render((.59, .27, .012), (.06, .20, .25)), parent=root)]
    for side, i in ((-1, 0), (1, 1)):
        rows += [object_(root+142+i, 'Cabin side glass', (side*.681, .44, .21),
                         render((.01, .25, .65), (.06, .20, .25)), parent=root),
                 object_(root+144+i, 'Door handle', (side*.813, .17, .50),
                         render((.01, .018, .06), (.22, .27, .29)), parent=root)]
    return ''.join(rows)


def script(case):
    return ('  scripts 1\n  script.0.id 1\n'+f'  script.0.asset "{IDS["controller"]}"\n'
            '  script.0.enabled true\n  script.0.properties '+
            json.dumps(json.dumps({'case': case}))+'\n'+f'  ui.asset "{IDS["ui"]}"\n  ui.name "lab"\n  ui.enabled true\n')


def scene(case, rotated=False, cars=1):
    q = rotation((0, 0, 1), .61) if rotated else (1, 0, 0, 0)
    rows = [object_(1, 'Laboratory gravity frame', (0, 0, 0),
                    '  gravity uniform 9.81\n  gravity.region sphere 500\n', q),
            object_(3, 'Ordinary ground', rotate(q, (0, -.20, 60)),
                    render((30, .20, 100), (.10, .14, .17))+body((30, .20, 100)), q),
            object_(10, 'Driver inputs, tour, view and UI', (0, 0, 0), script(case)),
            object_(12, 'Compatibility camera seed', rotate(q, (5, 4, 132)), '  player-start first-person\n', q)]
    variants = ['nominal'] if cars == 1 else ['nominal', 'weak', 'strong'][:cars]
    for index, variant in enumerate(variants):
        root = 900+index*300
        x = index*6-(cars-1)*3
        position = (x, .60, 125 if case != 'normal' else 85)
        rows.append(car(root, rotate(q, position), variant, q))
        if case != 'normal':
            # The offset wall overlaps the car's left 40%, contacting the
            # actual leading corner skin instead of a scripted dent/mount.
            wall_x, wall_half = (x-2.272, 2.10) if case == 'offset' else (x, 2.10)
            rows.append(object_(5000+index, 'Real frontal wall' if case != 'offset' else 'Real 40% offset wall',
                rotate(q, (wall_x, 1, -.25)), render((wall_half, 1, .25), (.40, .43, .44))+
                body((wall_half, 1, .25)), q))
        for stripe in range(18):
            for side in (-1, 1):
                rows.append(object_(6000+index*100+stripe*2+(side+1)//2, 'Lane marker',
                    rotate(q, (x+side*1.8, .012, 120-stripe*6)), render((.025, .012, 1), (.67, .73, .74)), q))
    if case == 'normal':
        for step in range(8):
            height = .08*(step+1)/8
            rows.append(object_(1600+step, 'Modest 80 mm suspension bump',
                rotate(q, (0, height*.5, 24-step*.18)), render((2, height*.5, .10), (.36, .42, .46))+
                body((2, height*.5, .10)), q))
    return settings('Structural crash / '+case+(' / rotated' if rotated else ''))+''.join(rows)


def specimen_network():
    graph = Network()
    stations = []
    for s in range(5):
        corners = [graph.node(f'fixture-{s}-{k}', (dx, dy, .30-s*.30))
                   for k, (dx, dy) in enumerate(((-.1, -.11), (.1, -.11), (.1, .11), (-.1, .11)))]
        for a, b in itertools.combinations(corners, 2):
            graph.beam(a, b, 1, .00004)
        if stations:
            for a in range(4):
                graph.beam(stations[-1][a], corners[a], 0, .00012)
                graph.beam(stations[-1][a], corners[(a+1)%4], 0, .000035)
            for k in range(4):
                graph.quad(stations[-1][k], corners[k], corners[(k+1)%4], stations[-1][(k+1)%4])
        stations.append(corners)
    graph.quad(*stations[0])
    graph.quad(*reversed(stations[-1]))
    graph.groups = {'root': stations[0], 'load': stations[-1]}
    return graph


def specimen(root=500, position=(0, 1.1, 0)):
    rows = [object_(root, 'Visible specimen clamp', position,
                    compound([('Rear pin clamp', (0, 0, .43), (.30, .38, .15))], 1, 0).replace(
                        'body dynamic compound', 'body static compound')),
            object_(root+1, 'Reusable rail specimen', (0, 0, 0),
                    deformable('specimen', [('root', root, (0, 0, 0))])+
                    render((.1, .11, .60), (.91, .47, .12)), parent=root),
            object_(root+2, 'Finite physical loading platen', (0, 0, -1.05),
                    render((.18, .18, .12), (.42, .49, .52))+body((.18, .18, .12), 20, 1), parent=root)]
    for i, (name, p, half) in enumerate((
            ('Platen guide floor', (0, -.24, -.55), (.25, .025, .85)),
            ('Left platen guide', (-.24, 0, -.55), (.025, .24, .85)),
            ('Right platen guide', (.24, 0, -.55), (.025, .24, .85)))):
        rows.append(object_(root+3+i, name, p, render(half, (.22, .29, .33))+body(half), parent=root))
    rows.append(object_(root+6, 'Visible rear pin clamp shell', (0, 0, .43),
                        render((.30, .38, .15), (.30, .36, .39)), parent=root))
    return ''.join(rows)


def create(source_only=False, baker=None):
    for directory in ('Assets/deformables', 'Assets/models', 'Assets/prefabs', 'Assets/scripts',
                      'Assets/fonts', 'Assets/ui', 'Assets/worlds', 'Scenes', 'Authoring'):
        (OUT/directory).mkdir(parents=True, exist_ok=True)
    graph = front_network()
    beam_mass, panel_mass = graph.mass()
    authoring = {'name': 'Judas original compact hatch', 'density_kg_m3': DENSITY,
        'cabin_mass_kg': 500, 'carriers_mass_kg': 20, 'beam_mass_kg': beam_mass,
        'panel_mass_kg': panel_mass, 'total_mass_kg': 520+beam_mass+panel_mass,
        'nodes': len(graph.nodes), 'beams': len(graph.beams), 'physical_skin_triangles': len(graph.surfaces),
        'node_names': graph.node_names, 'groups': graph.groups, 'profiles': PROFILES,
        'quality': {'fixed_hz': 60, 'substeps': 8, 'iterations': 12},
        'mass_method': '7850 * (sum beam area * rest length + sum panel thickness * triangle area)',
        'speed_inputs': 'Ordinary 180 Nm / 50 kW source, mechanical brakes, measured-speed feedback',
        'energy_at_speeds_j': {str(v): .5*(520+beam_mass+panel_mass)*v*v for v in (5, 15, 25)}}
    (OUT/'Authoring/compact-hatch.json').write_text(json.dumps(authoring, indent=2)+'\n')
    for variant, factor in (('nominal', 1), ('weak', .75), ('strong', 1.25)):
        relative = f'Assets/deformables/{variant}.judasdeform'
        source = OUT/f'Assets/deformables/{variant}.source'
        source.write_text(graph.source(factor))
        if not source_only:
            subprocess.run([str(baker), 'structural-network', str(OUT/relative), str(source)], check=True)
        metadata(relative, variant, 'deformable')
    fixture = specimen_network()
    (OUT/'Assets/deformables/specimen.source').write_text(fixture.source())
    if not source_only:
        subprocess.run([str(baker), 'structural-network', str(OUT/'Assets/deformables/specimen.judasdeform'),
                        str(OUT/'Assets/deformables/specimen.source')], check=True)
    metadata('Assets/deformables/specimen.judasdeform', 'specimen', 'deformable')
    shutil.copyfile(ROOT/'projects/damage_lab/Assets/models/vehicle_wheel.obj', OUT/'Assets/models/wheel.obj')
    shutil.copyfile(ROOT/'projects/damage_lab/Assets/fonts/DejaVuSans.ttf', OUT/'Assets/fonts/DejaVuSans.ttf')
    shutil.copyfile(ROOT/'projects/damage_lab/Assets/fonts/LICENSE.txt', OUT/'Assets/fonts/LICENSE.txt')
    shutil.copyfile(ROOT/'projects/damage_lab/Assets/scripts/math.js', OUT/'Assets/scripts/math.js')
    ui = (ROOT/'projects/damage_lab/Assets/ui/lab.judasui').read_text().replace(
        '83838383838383838383838300000005', IDS['font'])
    replacements = {
        'JUDAS / COUPLED PHYSICAL DAMAGE': 'JUDAS / STRUCTURAL CRASH LAB',
        'Plastic mount / strong control / cohesive fracture / powered buggies': 'Original compact hatch / rigid cabin / local steel crush structure',
        'B load | I physical bearing impact | H overload | Tab assembly | V watch': '5 / 15 / 25 m/s frontal impacts, offset impact and ordinary driving',
        'Material bends. Real bearings move. Connections fail. Mechanical loads change.': 'V drives the selected test. Inspect the physical result, then try W/S.',
        'W/S power | A/D steer | Space brake | B load | I impact | H overload | Tab | V watch | P prefab | F3 annex | 1/2 | F5/F8 | R | Esc': 'V watch | W/S drive | A/D steer | Space brake | 1–8 cases | Tab | P prefab | G structure | J contacts | F5/F8 | R | Esc',
        'DAMAGE LAB PAUSED': 'STRUCTURAL CRASH LAB PAUSED',
        'damage-current': 'structural-current',
    }
    for old, new in replacements.items():
        ui = ui.replace(old, new)
    (OUT/'Assets/ui/lab.judasui').write_text(ui)
    for relative, name, kind in (('Assets/models/wheel.obj', 'wheel', 'mesh'),
        ('Assets/scripts/math.js', 'math', 'script'), ('Assets/scripts/controller.js', 'controller', 'script'),
        ('Assets/fonts/DejaVuSans.ttf', 'font', 'font'), ('Assets/ui/lab.judasui', 'ui', 'ui'),
        ('Assets/prefabs/car.judasprefab', 'car', 'prefab'),
        ('Assets/prefabs/specimen.judasprefab', 'specimen_prefab', 'prefab'),
        ('Assets/worlds/lab.judasworld', 'world', 'world')):
        metadata(relative, name, kind)
    (OUT/'Assets/prefabs/car.judasprefab').write_text(settings('Reusable original structural car', 200)+car(1, (0, 0, 0)))
    (OUT/'Assets/prefabs/specimen.judasprefab').write_text(settings('Reusable structural specimen', 9)+specimen(1, (0, 0, 0)))
    for case in PROFILES:
        (OUT/f'Scenes/{case}.judas').write_text(scene(case, cars=3 if case == 'comparison' else 1))
    (OUT/'Scenes/rotated.judas').write_text(scene('medium', True))
    (OUT/'Scenes/group.judas').write_text(scene('group', cars=3))
    specimen_scene = settings('Generic rail load/unload/crush specimen')+object_(1, 'Specimen gravity frame', (0, 0, 0),
        '  gravity uniform 9.81\n  gravity.region sphere 100\n')+object_(3, 'Specimen ground', (0, -.20, 0),
        render((5, .20, 5), (.10, .14, .17))+body((5, .20, 5)))+object_(10, 'Specimen inputs and UI', (0, 0, 0), script('specimen'))+specimen()
    (OUT/'Scenes/specimen.judas').write_text(specimen_scene)
    annex = settings('Retained independent structural car and local wall', 6000)+\
        car(1, (0, .70, 125), 'weak', gravity_source=302)+\
        object_(301, 'Independent raised annex deck', (0, -.10, 60),
                render((3, .20, 100), (.14, .18, .20))+body((3, .20, 100)))+\
        object_(302, 'Annex-owned selected gravity', (0, 0, 60),
                '  gravity uniform 9.81\n  gravity.region box 3 5 160\n')+\
        object_(5000, 'Local physical annex impact wall', (0, 1.10, -.25),
                render((2.1, 1, .25), (.40, .43, .44))+body((2.1, 1, .25)))
    (OUT/'Scenes/annex.judas').write_text(annex)
    (OUT/'Assets/worlds/lab.judasworld').write_text(
        'JudasWorld 1\nbudget 2 8 2 8388608 8388608 8388608 2097152\n'
        'region "annex" "Scenes/annex.judas" 16 0 0 0 0 0 1 4 5 165 1 "snapshot" 1048576 ""\n')
    actions = {'brake': 'key:Space', 'select': 'key:Tab', 'watch': 'key:V', 'spawn': 'key:P',
        'tour': 'key:T', 'region': 'key:F3', 'normal': 'key:1', 'low': 'key:2', 'medium': 'key:3', 'high': 'key:4',
        'offset': 'key:5', 'comparison': 'key:6', 'specimen': 'key:7', 'rotated': 'key:8',
        'structure': 'key:G', 'contacts': 'key:J', 'load': 'key:B', 'overload': 'key:H',
        'save_game': 'key:F5', 'load_game': 'key:F8', 'restart': 'key:R', 'pause': 'key:Escape',
        'ui_click': 'mouse:Left', 'ui_activate': 'key:Return', 'ui_up': 'key:Up', 'ui_down': 'key:Down'}
    axes = {'throttle': [('key:S', -1), ('key:W', 1)], 'steer': [('key:D', -1), ('key:A', 1)],
            'look_x': [('mouse:dx', 1)], 'look_y': [('mouse:dy', 1)]}
    mapping = f'1 {len(actions)+len(axes)} '+''.join(
        f'"{name}" 0 1 "{binding}" 1 0 ' for name, binding in actions.items())+''.join(
        f'"{name}" 1 {len(bindings)} '+''.join(f'"{binding}" {scale} 0 ' for binding, scale in bindings)
        for name, bindings in axes.items())
    classification = 'JudasClassification 1 0 0 3 3 0 "Environment" 1 "Assembly" 2 "Material" 1 1 0 "Default"'
    (OUT/'structural_crash_lab.judasproj').write_text('JudasProject 1\nname "Structural Crash Lab"\n'
        'startup-scene "Scenes/medium.judas"\nassets-dir "Assets"\nscenes-dir "Scenes"\n'
        'saves-dir "Saves"\nlegacy-gameplay "false"\nclassification '+json.dumps(classification)+
        '\ninput-map '+json.dumps(mapping)+f'\nworld-manifest "{IDS["world"]}"\n')
    print(json.dumps({k: authoring[k] for k in ('nodes', 'beams', 'physical_skin_triangles',
        'beam_mass_kg', 'panel_mass_kg', 'total_mass_kg', 'energy_at_speeds_j')}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true', help='Author text/assets without invoking the native baker')
    parser.add_argument('--baker', type=Path, default=ROOT/'build/judas_deformable_bake')
    arguments = parser.parse_args()
    create(arguments.source_only, arguments.baker)
