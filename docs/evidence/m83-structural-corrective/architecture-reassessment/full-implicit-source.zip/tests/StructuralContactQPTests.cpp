#include "StructuralContactQP.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>
namespace {
unsigned checks=0,failures=0;
void check(bool pass,const char* label){++checks;failures+=!pass;std::printf("%s %s\n",pass?"PASS":"FAIL",label);}
bool near(double a,double b){return std::abs(a-b)<=1e-8*std::max({1.,std::abs(a),std::abs(b)});}
}
int main(){
    StructuralNormalQPResult result;std::string error;
    check(SolveStructuralNormalQP({}, {},0,{},result,error)&&result.multipliers.empty(),"empty contact system requires no reaction");
    check(SolveStructuralNormalQP({2},{-4},1,{},result,error)&&near(result.multipliers[0],2)&&result.primalResidual<1e-10,"one finite normal row resolves the exact signed penetration");
    check(SolveStructuralNormalQP({2},{4},1,{100},result,error)&&result.multipliers[0]==0,"a separated row releases stale warm pressure rather than applying it twice");
    check(SolveStructuralNormalQP({2,0,0,4},{-4,-12},2,{},result,error)&&near(result.multipliers[0],2)&&near(result.multipliers[1],3),"independent normal rows retain their finite response weights");
    check(SolveStructuralNormalQP({2,1,1,2},{-3,-3},2,{},result,error)&&near(result.multipliers[0],1)&&near(result.multipliers[1],1),"coupled normal rows solve their shared response rather than one ordered projection");
    const auto singleSweep=[](const std::vector<double>& h,const std::vector<double>& q){std::vector<double> lambda(q.size(),0);
        for(size_t i=0;i<q.size();++i){double gap=q[i];for(size_t j=0;j<q.size();++j)gap+=h[i*q.size()+j]*lambda[j];lambda[i]=std::max(0.,lambda[i]-gap/h[i*q.size()+i]);}return lambda;};
    const auto orderedPressure=singleSweep({2,1,1,2},{-3,-3});
    check(near(orderedPressure[0]*(-3+2*orderedPressure[0]+orderedPressure[1]),1.125)&&SolveStructuralNormalQP({2,1,1,2},{-3,-3},2,{},result,error)&&result.complementarityResidual<1e-10,"the old single ordered sweep leaves measurable false pressure on a separated row while the exact QP releases it");
    const auto orderedPenetration=singleSweep({2,-1,-1,2},{-1,-1});
    check(near(-1+2*orderedPenetration[0]-orderedPenetration[1],-.75)&&SolveStructuralNormalQP({2,-1,-1,2},{-1,-1},2,{},result,error)&&near(result.multipliers[0],1)&&near(result.multipliers[1],1)&&result.primalResidual<1e-10,"the old single ordered sweep reopens an earlier contact while the exact QP closes both coupled planes");
    check(SolveStructuralNormalQP({1,1,1,1},{-1,-1},1,{},result,error)&&result.rank==1&&near(result.multipliers[0]+result.multipliers[1],1),"exact duplicate material samples share one physical pressure without regularization");
    check(SolveStructuralNormalQP({1,.5,.5,.25},{-1,-.75},1,{},result,error)&&result.rank==1&&near(result.multipliers[0],0)&&near(result.multipliers[1],3)&&result.pivots>=2,"a stronger dependent plane exchanges the old blocker through its exact dual nullspace");
    check(SolveStructuralNormalQP({1,.5,.5,.25},{-1,-.25},1,{},result,error)&&near(result.multipliers[0],1)&&result.multipliers[1]==0,"a weaker dependent plane adds neither false pressure nor singular failure");
    const std::vector<double> centroid={1,0,.5,0,1,.5,.5,.5,.5};
    check(SolveStructuralNormalQP(centroid,{-1,-.9,-.99},2,{},result,error)&&near(result.multipliers[0]+.5*result.multipliers[2],1)&&near(result.multipliers[1]+.5*result.multipliers[2],.98)&&result.rank==2,"a stronger weighted-centroid row replaces the correct node constraint while preserving independent rank");
    check(!SolveStructuralNormalQP({1,-1,-1,1},{-1,-1},1,{},result,error)&&error.find("infeasible")!=std::string::npos,"opposed incompatible normal constraints report true infeasibility instead of contact softness");
    check(SolveStructuralNormalQP({0},{1},0,{},result,error)&&result.multipliers[0]==0,"a prescribed separated row has zero response and no invented reaction");
    check(!SolveStructuralNormalQP({0},{-1},0,{},result,error)&&error.find("prescribed")!=std::string::npos,"a prescribed penetrating row fails explicitly");
    check(!SolveStructuralNormalQP({1,0,0,1},{-1,-1},1,{},result,error)&&error.find("rank")!=std::string::npos,"an incorrect primal rank bound cannot silently discard an independent contact");
    check(!SolveStructuralNormalQP({1,-2,-2,1},{-1,-1},2,{},result,error)&&error.find("semidefinite")!=std::string::npos,"an active indefinite response is rejected rather than regularized");
    check(!SolveStructuralNormalQP({1},{-1},1,{-1},result,error),"invalid negative warm pressure fails safely");

    std::array<double,2> tangent;
    check(SolveStructuralFrictionDisk(2,0,4,{2,8},10,tangent,error)&&near(tangent[0],1)&&near(tangent[1],2),"a sticking tangential row solves its actual anisotropic response inside the Coulomb disk");
    check(SolveStructuralFrictionDisk(2,0,2,{6,8},1,tangent,error)&&near(tangent[0],.6)&&near(tangent[1],.8),"an isotropic sliding row retains the ordinary analytic Coulomb limit");
    const double diagonalProjection=std::sqrt(.5),deltaX=diagonalProjection-1,deltaY=diagonalProjection;
    const double oldClipChange=-deltaY+.5*(100*deltaX*deltaX+deltaY*deltaY);
    const bool anisotropicSolved=SolveStructuralFrictionDisk(100,0,1,{100,1},1,tangent,error);const auto metricTangent=tangent;
    const auto objective=[](double a,double b,double d,std::array<double,2> rhs,std::array<double,2> t){return .5*(a*t[0]*t[0]+2*b*t[0]*t[1]+d*t[1]*t[1])-rhs[0]*t[0]-rhs[1]*t[1];};
    check(oldClipChange>3.8&&anisotropicSolved&&objective(100,0,1,{100,1},tangent)<=objective(100,0,1,{100,1},{1,0})&&near(std::hypot(tangent[0],tangent[1]),1),"the old radial clip measurably creates quadratic energy while the metric Coulomb solve does not");
    const double gradientX=100*tangent[0]-100,gradientY=tangent[1]-1;
    check(anisotropicSolved&&std::abs(tangent[0]*gradientY-tangent[1]*gradientX)<1e-8&&tangent[0]*gradientX+tangent[1]*gradientY<=0,"the anisotropic disk solution satisfies its independent constrained KKT condition");
    check(SolveStructuralFrictionDisk(4,0,0,{2,0},1,tangent,error)&&near(tangent[0],.5)&&near(tangent[1],0),"a singular tangent metric with a range-compatible load uses its exact minimum-norm sticking solution");
    const bool singularSolved=SolveStructuralFrictionDisk(4,0,0,{2,1},1,tangent,error);
    check(singularSolved&&near(std::hypot(tangent[0],tangent[1]),1)&&std::abs(tangent[0]*(-1)-tangent[1]*(4*tangent[0]-2))<1e-8&&objective(4,0,0,{2,1},tangent)<=-1,"a loaded null direction resolves the actual bounded disk without inventing stiffness");
    check(SolveStructuralFrictionDisk(0,0,0,{3,4},2,tangent,error)&&near(tangent[0],1.2)&&near(tangent[1],1.6),"a zero tangent metric retains the exact finite-radius linear minimum");
    check(SolveStructuralFrictionDisk(2,0,4,{2,8},0,tangent,error)&&tangent[0]==0&&tangent[1]==0,"zero authored friction permits no tangential reaction");
    check(!SolveStructuralFrictionDisk(1,2,1,{1,1},1,tangent,error)&&error.find("semidefinite")!=std::string::npos,"an indefinite tangent response fails instead of being hidden by friction regularization");
    const double c=std::cos(.71),s=std::sin(.71);const std::array<double,2> rotatedLoad{100*c-s,100*s+c};
    check(SolveStructuralFrictionDisk(100*c*c+s*s,99*c*s,100*s*s+c*c,rotatedLoad,1,tangent,error)&&near(tangent[0],c*metricTangent[0]-s*metricTangent[1])&&near(tangent[1],s*metricTangent[0]+c*metricTangent[1]),"rotating the tangent basis preserves the same physical metric-disk impulse");

    // Constitutive checks exercise the actual semismooth law independently
    // of the frozen normal/friction QP used as a numerical proposal.
    const auto lawInput=[](std::array<double,3> impulse,std::array<double,3> kinematics,double mu){StructuralContactLawInput input;input.impulse=impulse;input.kinematics=kinematics;input.normalMobility=2;input.tangentMobility=1.3;input.friction=mu;return input;};
    const auto norm3=[](const std::array<double,3>& v){return std::hypot(v[0],std::hypot(v[1],v[2]));};
    StructuralContactLawResult law;
    check(EvaluateStructuralContactLaw(lawInput({0,0,0},{.4,0,0},.5),law,error)&&norm3(law.residual)==0,"the actual normal/contact law is exactly zero for a separated unloaded row");
    check(EvaluateStructuralContactLaw(lawInput({2,.3,.4},{0,0,0},.5),law,error)&&norm3(law.residual)<1e-14,"positive pressure and subcapacity static friction satisfy the actual sticking KKT law");
    check(EvaluateStructuralContactLaw(lawInput({2,-.6,-.8},{0,1.2,1.6},.5),law,error)&&norm3(law.residual)<1e-14,"a Coulomb-limit impulse opposing actual slip satisfies the actual sliding KKT law");
    check(EvaluateStructuralContactLaw(lawInput({0,0,0},{0,3,-4},0),law,error)&&norm3(law.residual)==0,"zero authored friction permits real sliding without inventing tangent pressure");
    check(EvaluateStructuralContactLaw(lawInput({-.2,0,0},{0,0,0},.5),law,error)&&law.residual[0]>.5,"negative tensile contact pressure is an executable non-KKT negative control");
    check(EvaluateStructuralContactLaw(lawInput({0,0,0},{-.1,0,0},.5),law,error)&&law.residual[0]>.1,"penetration with absent pressure cannot masquerade as a converged actual normal law");
    check(EvaluateStructuralContactLaw(lawInput({2,.6,.8},{0,1.2,1.6},.5),law,error)&&norm3(law.residual)>.5,"a friction impulse aiding slip fails the actual law even when it fits the magnitude cap");
    check(EvaluateStructuralContactLaw(lawInput({0,.4,.2},{.1,0,0},.5),law,error)&&norm3(law.residual)>.4,"stale tangent reaction without normal pressure is detected rather than retained");
    auto invalidLaw=lawInput({0,0,0},{0,0,0},.5);invalidLaw.normalMobility=0;
    check(!EvaluateStructuralContactLaw(invalidLaw,law,error),"a missing finite normal response fails the law utility explicitly");

    const auto smoothDerivative=[&](const StructuralContactLawInput& input){StructuralContactLawResult actual;std::string issue;if(!EvaluateStructuralContactLaw(input,actual,issue))return false;
        for(unsigned column=0;column<6;++column){auto minus=input,plus=input;auto& lower=column<3?minus.impulse:minus.kinematics;auto& upper=column<3?plus.impulse:plus.kinematics;const unsigned variable=column%3;const double step=1e-6*std::max(1.,std::abs(lower[variable]));lower[variable]-=step;upper[variable]+=step;
            StructuralContactLawResult a,b;if(!EvaluateStructuralContactLaw(minus,a,issue)||!EvaluateStructuralContactLaw(plus,b,issue))return false;
            for(unsigned row=0;row<3;++row){const double numerical=(b.residual[row]-a.residual[row])/(2*step),analytic=(column<3?actual.impulseDerivative:actual.kinematicDerivative)[row*3+variable];if(std::abs(numerical-analytic)>2e-7*std::max({1.,std::abs(numerical),std::abs(analytic)}))return false;}}
        return true;};
    check(smoothDerivative(lawInput({1,.2,.1},{.4,.03,-.02},.7)),"all six impulse/kinematic columns match independent central differences in the smooth sticking region");
    check(smoothDerivative(lawInput({2,-.6,-.8},{-.1,1.2,1.6},.5)),"all six contact-law derivative columns match independent central differences in the smooth sliding region");
    check(smoothDerivative(lawInput({-.4,.2,-.3},{.1,.4,-.2},.5)),"the negative-pressure zero-capacity branch has its own correct generalized derivative");

    const auto directional=[&](const StructuralContactLawInput& input,std::array<double,3> di,std::array<double,3> dk){std::array<double,3> derivative{};std::string issue;StructuralContactLawResult zeroValue;
        if(!EvaluateStructuralContactLaw(input,zeroValue,issue)||!StructuralContactLawDirectionalDerivative(input,di,dk,derivative,issue))return false;
        auto perturbed=input;constexpr double step=1e-7;for(unsigned j=0;j<3;++j){perturbed.impulse[j]+=step*di[j];perturbed.kinematics[j]+=step*dk[j];}
        StructuralContactLawResult value;
        if(!EvaluateStructuralContactLaw(perturbed,value,issue))return false;
        for(unsigned j=0;j<3;++j){const double measured=(value.residual[j]-zeroValue.residual[j])/step;if(std::abs(measured-derivative[j])>2e-6*std::max({1.,std::abs(measured),std::abs(derivative[j])}))return false;}return true;};
    const auto originLaw=lawInput({0,0,0},{0,0,0},.5);
    check(directional(originLaw,{1,.2,-.3},{.2,.4,.1}),"joint zero pressure/gap/disk uses its exact positive one-sided normal and friction directional derivative");
    check(directional(originLaw,{-1,.2,.3},{-.4,-.3,.2}),"a negative origin direction creates no fictional positive friction capacity");
    const auto boundaryLaw=lawInput({2,1,0},{0,0,0},.5);
    check(directional(boundaryLaw,{0,2,.3},{.4,.2,-.1}),"the disk-boundary outward direction differentiates the actual clipped surface");
    check(directional(boundaryLaw,{1,-2,.3},{-.1,.2,-.1}),"the same disk-boundary inward direction differentiates the real sticking branch");
    check(directional(boundaryLaw,{2,1,.2},{0,0,0}),"an exact boundary-tangent direction includes the changing pressure radius");
    std::array<double,3> originDerivative{};const bool originDerived=StructuralContactLawDirectionalDerivative(originLaw,{1,0,0},{1,0,0},originDerivative,error);
    const bool originEvaluated=EvaluateStructuralContactLaw(originLaw,law,error);const double fixedClarke=originEvaluated?law.impulseDerivative[0]+law.kinematicDerivative[0]:0;
    check(originDerived&&originEvaluated&&std::abs(originDerivative[0]-fixedClarke)>1,"the exact origin directional derivative detects the incorrect assumption that one fixed Clarke matrix is a universal directional slope");
    // Rotating a tangent coordinate basis changes neither the physical law
    // nor its one-sided response; the normal/gravity frame is supplied outside.
    const auto originalLaw=lawInput({2,-.6,-.8},{.1,1.2,1.6},.5);auto rotatedLaw=originalLaw;
    rotatedLaw.impulse[1]=c*originalLaw.impulse[1]-s*originalLaw.impulse[2];rotatedLaw.impulse[2]=s*originalLaw.impulse[1]+c*originalLaw.impulse[2];
    rotatedLaw.kinematics[1]=c*originalLaw.kinematics[1]-s*originalLaw.kinematics[2];rotatedLaw.kinematics[2]=s*originalLaw.kinematics[1]+c*originalLaw.kinematics[2];
    StructuralContactLawResult unrotated,rotated;
    check(EvaluateStructuralContactLaw(originalLaw,unrotated,error)&&EvaluateStructuralContactLaw(rotatedLaw,rotated,error)&&near(rotated.residual[0],unrotated.residual[0])&&near(rotated.residual[1],c*unrotated.residual[1]-s*unrotated.residual[2])&&near(rotated.residual[2],s*unrotated.residual[1]+c*unrotated.residual[2]),"the actual contact constitutive law is invariant under a rotated tangent basis");

    // Reproduced rotating-kinematic inactive row: weighted FB was already
    // below the Newton1e-11 floor while a gamma-only pressure-sign check
    // demanded stricter accuracy and then rejected the zero Newton proposal.
    auto inactiveFloor=lawInput({-2.5e-12,0,0},{.025,0,0},0);inactiveFloor.normalMobility=.01;
    check(StructuralContactLawConverged(inactiveFloor,3.75,0,0,error)&&inactiveFloor.impulse[0]==-2.5e-12,"the reproduced tiny inactive pressure matches the existing scaled root floor without modifying its physical state");
    auto meaningfulNegative=inactiveFloor;meaningfulNegative.impulse[0]=-1e-5;
    check(!StructuralContactLawConverged(meaningfulNegative,3.75,0,0,error),"a genuinely tensile negative contact pressure remains outside the unchanged weighted root floor");
    auto penetratingFloor=inactiveFloor;penetratingFloor.impulse[0]=0;penetratingFloor.kinematics[0]=-1e-5;
    check(!StructuralContactLawConverged(penetratingFloor,3.75,0,0,error),"real penetration cannot pass the matched certificate merely because pressure is tiny");
    check(StructuralContactLawConverged(lawInput({2,0,0},{0,0,0},.5),2,0,0,error),"a valid positive pressure at zero gap satisfies the matched weighted certificate");
    auto loadedPenetration=lawInput({2,0,0},{-1e-5,0,0},.5);
    check(!StructuralContactLawConverged(loadedPenetration,2,0,0,error),"positive pressure cannot hide an actual negative gap in the FB root certificate");
    for(double mobility:{1e-4,1.,100.}){auto scaled=inactiveFloor;scaled.normalMobility=mobility;scaled.impulse[0]=-2.5e-13/std::sqrt(mobility);
        check(StructuralContactLawConverged(scaled,3.75,0,0,error),"the same solved FB error is certified consistently after changing the finite mass response scale");}
    auto amplifiedFloor=inactiveFloor;amplifiedFloor.normalMobility=100;
    check(!StructuralContactLawConverged(amplifiedFloor,3.75,0,0,error),"a mass scaling that raises the actual FB error above1e-11 is rejected rather than granting a universal pressure tolerance");
    check(!StructuralContactLawConverged(lawInput({2,.6,.8},{0,1.2,1.6},.5),2,0,0,error),"the matched normal floor does not waive a genuine wrong-direction Coulomb residual");
    check(!StructuralContactLawConverged(inactiveFloor,3.75,-1,0,error),"invalid negative arithmetic error budgets fail the pure certificate safely");

    // Construct KKT solutions independently: three physical displacement DOFs
    // plus seven redundant weighted samples. Their positive final slack makes
    // the exact physical load unique even though the Gram matrix is singular.
    for(unsigned fixture=0;fixture<24;++fixture){
        constexpr unsigned rows=10,dimension=3;double j[rows][dimension]={{1,0,0},{0,1,0},{0,0,1}};
        for(unsigned i=3;i<rows;++i){double total=0;for(unsigned k=0;k<dimension;++k){j[i][k]=1+double((fixture*13+i*7+k*11)%17);total+=j[i][k];}for(auto& value:j[i])value/=total;}
        const double actual[dimension]={1+.03*fixture,2+.02*fixture,3+.01*fixture};
        std::vector<double> gram(rows*rows,0),gap(rows,0),warm(rows,0);
        for(unsigned i=0;i<rows;++i){for(unsigned k=0;k<dimension;++k)gap[i]-=j[i][k]*actual[k];if(i>=dimension)gap[i]+=.1;
            for(unsigned q=0;q<rows;++q){for(unsigned k=0;k<dimension;++k)gram[i*rows+q]+=j[i][k]*j[q][k];}
            warm[i]=double((i+fixture)%4);}
        const bool solved=SolveStructuralNormalQP(gram,gap,dimension,warm,result,error);double measured[dimension]={0,0,0};
        if(solved)for(unsigned i=0;i<rows;++i)for(unsigned k=0;k<dimension;++k)measured[k]+=j[i][k]*result.multipliers[i];
        check(solved&&near(measured[0],actual[0])&&near(measured[1],actual[1])&&near(measured[2],actual[2])&&result.primalResidual<1e-8&&result.complementarityResidual<1e-7,"redundant node/edge/centroid KKT fixture recovers its independently specified physical displacement");
    }
    std::printf("CHECKS %u FAILURES %u\n",checks,failures);return failures?1:0;
}
