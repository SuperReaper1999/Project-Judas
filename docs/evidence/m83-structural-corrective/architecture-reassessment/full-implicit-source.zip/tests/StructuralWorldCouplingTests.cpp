#include "RuntimeWorld.h"
#include "WorldPersistence.h"
#include "ResourceManager.h"
#include "AssetDatabase.h"
#include "SaveArchive.h"
#include "UniformGravity.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <glm/gtc/matrix_transform.hpp>
namespace fs=std::filesystem;
namespace {
unsigned checks=0;
void Check(bool value,const char* label){++checks;std::printf("%s %s\n",value?"PASS":"FAIL",label);if(!value)throw std::runtime_error(label);}
using V=glm::dvec3;
glm::dmat4 Frame(const BodyTransform& pose){return glm::translate(glm::dmat4(1),V(pose.position))*glm::mat4_cast(glm::dquat(pose.rotation));}
glm::dmat4 Frame(const SceneTransform& pose){return glm::translate(glm::dmat4(1),V(pose.position))*glm::mat4_cast(glm::dquat(pose.rotation));}
double MatrixError(const glm::dmat4& a,const glm::dmat4& b){double error=0;for(unsigned i=0;i<4;++i)error=std::max(error,glm::length(a[i]-b[i]));return error;}
double PatchError(const DeformableInstance& patch,const glm::dmat4& pose){double error=0;for(unsigned n=0;n<patch.positions.size();++n)error=std::max(error,glm::length(patch.positions[n]-V(pose*glm::dvec4(patch.asset->nodes[n],1))));return error;}
DeformableAsset Patch(){
    DeformableAsset a;a.kind=DeformableKind::Structure;a.structure=std::make_shared<StructuralCook>();
    a.nodes={{-.4,0,0},{.4,0,0},{0,.4,0}};a.triangles={{0,1,2}};a.groups["patch"]={0,1,2};
    StructuralRegion region;region.key="elastic patch";region.youngModulus=1e6;region.damping=0;
    region.tensionYield=region.compressionYield=1e8;region.tensionUltimate=region.compressionUltimate=1e9;
    a.structure->regions={region};
    for(unsigned n=0;n<3;++n){StructuralBeam b;b.key="brace-"+std::to_string(n);b.a=n;b.b=(n+1)%3;b.area=.002;a.structure->beams.push_back(b);}
    a.structure->surfaceRegions={0};a.structure->surfaceSupports={{0,1,2}};
    std::string error;if(!PrepareDeformableAsset(a,error))throw std::runtime_error(error);return a;
}
Scene Fixture(const AssetId& asset){
    Scene scene;auto& support=scene.CreateObject("ordinary translating rotating support");support.id=1;
    support.body=SceneBodyComponent{};support.body->motion=SceneBodyMotion::Dynamic;support.body->mass=20;support.body->halfExtents={.5f,.5f,.05f};support.body->collisionMask=0;
    auto& owner=scene.CreateObject("local structural patch");owner.id=2;owner.deformable=DeformableSettings{};
    auto& cfg=*owner.deformable;cfg.asset=asset;cfg.substeps=8;cfg.iterations=4;cfg.selfContact=false;cfg.collisionMask=0;cfg.material.density=100;cfg.material.damping=0;cfg.attachedBodyContact=true;
    DeformableAttachment pin;pin.group="patch";pin.kind=DeformableAttachment::Kind::Body;pin.target=1;cfg.attachments={pin};return scene;
}
void Macro(RuntimeWorld& world){
    const auto intervals=world.StructuralSubsteps();
    unsigned interval=0;auto phase=world.StructuralVelocityCoupling(interval,intervals);
    world.Physics().StepCoupled(1.f/60,intervals,[&](float,unsigned i){interval=i;},{},&phase);
    world.UpdateDeformables(1./60);
}
std::string MaterialBytes(DeformableInstance& material){
    // Participant 5 writes the attachment-strength layout for every owner,
    // while structural-only fields remain conditional on its actual asset.
    SaveArchive archive;material.Persist(archive,true,true,true);return archive.bytes;
}
void MixedParticipantContinuation(const AssetId& structuralAsset,const fs::path& root,AssetDatabase& database,ResourceManager& resources){
    std::string error;
    const auto registerAsset=[&](const DeformableAsset& asset,const char* name){
        const auto path=root/"Assets"/name;std::ofstream(path,std::ios::binary)<<EncodeDeformableAsset(asset);
        AssetRecord record;if(!database.Track(path.string(),record,error))throw std::runtime_error(error);return record.id;
    };
    const std::array<AssetId,3> legacyAssets{
        registerAsset(MakeDeformableSheet(2,2,.3,.3),"mixed-cloth.judasdeform"),
        registerAsset(MakeDeformableBlock({1,1,1},{.2,.2,.2}),"mixed-solid.judasdeform"),
        registerAsset(MakeFractureBlock({2,1,1},{.4,.2,.2},false),"mixed-fracture.judasdeform")};
    Scene scene=Fixture(structuralAsset);
    auto& gravity=scene.CreateObject("zero gravity mixed participant control");gravity.id=10;
    gravity.gravity=SceneGravityComponent{};gravity.gravity->kind=SceneGravityKind::Uniform;gravity.gravity->magnitude=0;
    gravity.gravity->regionShape=SceneRegionShape::Box;gravity.gravity->regionHalfExtents={32,32,32};
    for(unsigned i=0;i<legacyAssets.size();++i){auto& owner=scene.CreateObject("independent legacy material");owner.id=20+i;
        owner.transform.position={4.f+4.f*i,2.f,0};owner.deformable=DeformableSettings{};
        auto& settings=*owner.deformable;settings.asset=legacyAssets[i];settings.substeps=2;settings.iterations=4;
        settings.selfContact=false;settings.collisionMask=0;settings.material.density=20;settings.material.damping=0;
    }
    // A second ordinary body lets the cold world allocate DIFFERENT native
    // body indices without changing logical entities or their authored data.
    auto& spare=scene.CreateObject("independent rigid allocation control");spare.id=23;spare.transform.position={20,2,0};
    spare.body=SceneBodyComponent{};spare.body->motion=SceneBodyMotion::Dynamic;spare.body->mass=2;spare.body->collisionMask=0;
    scene.SetNextId(24);
    RuntimeWorld world;world.legacyGameplay=false;
    Check(world.Build(scene,&resources,error),"mixed structure cloth solid and fracture world builds through ordinary assets");
    auto* structural=world.RuntimeDeformable(2,error);Check(structural&&structural->Structural(),"mixed fixture retains its actual structural participant");
    std::array<std::vector<V>,3> authoredPositions;
    for(unsigned i=0;i<legacyAssets.size();++i){auto* material=world.RuntimeDeformable(20+i,error);
        Check(material&&!material->Structural(),"mixed legacy participant publishes its own ordinary simulation");authoredPositions[i]=material->positions;
        Check(material->Impulse(i==0?"":"right",{.004,.002,-.001}),"ordinary physical impulse seeds nontrivial legacy material motion");
    }
    auto* fractured=world.RuntimeDeformable(22,error);
    Check(fractured->asset->fracture&&fractured->fracture.Request(*fractured->asset->fracture,0,fractured->fracture.revision)&&fractured->fracture.Commit(*fractured->asset->fracture),
        "mixed fixture commits an ordinary legacy fracture interface with durable topology");
    world.Physics().SetLinearVelocity(world.RuntimeBody(1),{.2f,.03f,-.1f});
    Check(world.Physics().GetLinearVelocity(world.RuntimeBody(1))==glm::vec3(.2f,.03f,-.1f),"mixed structural support receives real physical motion");
    Macro(world);Macro(world);
    std::map<EntityId,std::string> expected;
    for(auto id:{EntityId(2),EntityId(20),EntityId(21),EntityId(22)}){auto* material=world.RuntimeDeformable(id,error);
        Check(material&&material->error.empty(),"mixed physical participants complete their original intervals without failure");expected[id]=MaterialBytes(*material);
    }
    bool nontrivial=true;for(unsigned i=0;i<legacyAssets.size();++i)nontrivial&=world.RuntimeDeformable(20+i,error)->positions!=authoredPositions[i];
    Check(nontrivial&&fractured->fracture.revision>1&&fractured->fracture.broken[0],"all legacy owners have actual moving state and the fracture owner has a real cut before save");
    std::map<std::string,SaveChunk> chunks;
    Check(WorldPersistence::Capture(world,chunks,error)&&chunks.at("deformables").version==5,"mixed save uses participant 5 for structural and legacy physical state together");
    Scene saved;Check(WorldPersistence::SceneFrom(chunks,saved,error),"mixed snapshot reconstructs ordinary logical scene content");
    const auto support=std::find_if(saved.Objects().begin(),saved.Objects().end(),[](const auto& object){return object.id==1;});
    const auto other=std::find_if(saved.Objects().begin(),saved.Objects().end(),[](const auto& object){return object.id==23;});
    Check(support!=saved.Objects().end()&&other!=saved.Objects().end(),"mixed snapshot retains both ordinary rigid owners");std::iter_swap(support,other);
    RuntimeWorld cold;cold.legacyGameplay=false;
    Check(cold.Build(saved,&resources,error,nullptr,nullptr,true)&&WorldPersistence::Prepare(cold,error),"fresh mixed world prepares resources with reordered ordinary body allocation");
    const auto originalBody=world.RuntimeBody(1),coldBody=cold.RuntimeBody(1);
    Check(originalBody.world!=coldBody.world&&originalBody.id!=coldBody.id,"cold support uses a different actual body mapping rather than cached native indices");
    bool absentState=true;for(const auto& [id,bytes]:expected){auto* material=cold.RuntimeDeformable(id,error);absentState&=material&&MaterialBytes(*material)!=bytes;}
    Check(absentState,"authored-only negative control cannot substitute for nontrivial mixed physical restoration");
    Check(WorldPersistence::Restore(cold,chunks,error),"participant 5 restores mixed owners through the normal physical publication boundary");
    bool exact=true;for(const auto& [id,bytes]:expected){auto* material=cold.RuntimeDeformable(id,error);exact&=material&&MaterialBytes(*material)==bytes;}
    Check(exact,"mixed cold state retains exact nodes velocities plastic references fracture topology and structural history");
    Macro(world);Macro(cold);double continuationError=0;bool healthy=true;
    for(const auto& [id,bytes]:expected){(void)bytes;auto* a=world.RuntimeDeformable(id,error);auto* b=cold.RuntimeDeformable(id,error);
        healthy&=a&&b&&a->error.empty()&&b->error.empty();if(a&&b)for(unsigned n=0;n<a->positions.size();++n)continuationError=std::max(continuationError,glm::length(a->positions[n]-b->positions[n]));
    }
    const auto a=world.Physics().GetTransform(world.RuntimeBody(1)),b=cold.Physics().GetTransform(cold.RuntimeBody(1));
    const double bodyError=glm::length(V(a.position)-V(b.position)),velocityError=glm::length(V(world.Physics().GetLinearVelocity(world.RuntimeBody(1)))-V(cold.Physics().GetLinearVelocity(cold.RuntimeBody(1))));
    std::printf("MIXED_PARTICIPANT_COLD materials=4 bodyMapping=(%u,%u) nodeError=%.12g bodyError=%.12g velocityError=%.12g\n",originalBody.id,coldBody.id,continuationError,bodyError,velocityError);
    Check(healthy&&continuationError<1e-9&&bodyError<1e-6&&velocityError<1e-6,"first resumed mixed step follows real physical endpoints under a fresh native body mapping");
    auto downgraded=chunks;downgraded.at("deformables").version=4;RuntimeWorld rejected;rejected.legacyGameplay=false;
    Check(rejected.Build(saved,&resources,error,nullptr,nullptr,true)&&WorldPersistence::Prepare(rejected,error)&&!WorldPersistence::Restore(rejected,downgraded,error),
        "mixed participant downgrade cannot silently discard structural history while parsing legacy owners");
    rejected.Destroy();cold.Destroy();world.Destroy();
}
void SharedCarrierClosure(const fs::path& root,AssetDatabase& database,ResourceManager& resources){
    // This translational problem has an independently soluble linear BE root.
    // Two separate material owners may refer to one ordinary finite body; a
    // cached per-owner root is not proof of the final common physical state.
    DeformableAsset asset;asset.kind=DeformableKind::Structure;asset.structure=std::make_shared<StructuralCook>();
    asset.nodes={{0,0,0},{1,0,0}};asset.groups["pin"]={0};asset.groups["free"]={1};
    StructuralRegion region;region.key="linear closure control";region.youngModulus=1e8;region.damping=0;
    region.tensionYield=region.compressionYield=1e12;region.tensionUltimate=region.compressionUltimate=2e12;
    asset.structure->regions={region};StructuralBeam beam;beam.key="one physical member";beam.a=0;beam.b=1;beam.area=1;asset.structure->beams={beam};
    std::string error;Check(PrepareDeformableAsset(asset,error),"independent linear shared-carrier closure asset prepares without plasticity or contact");
    const auto path=root/"Assets/shared-carrier.judasdeform";std::ofstream(path,std::ios::binary)<<EncodeDeformableAsset(asset);AssetRecord record;
    Check(database.Track(path.string(),record,error),"shared-carrier control uses an ordinary registered material asset");
    struct Result {bool healthy=false,saved=false,historyUnchanged=true,externalVelocityChanged=false;double pinError=0,freeError=0,residual=0,pinDifference=0,actualDisplacement=0,poseDelta=0;std::string error;};
    const auto run=[&](float origin,unsigned count,bool shared,bool external){
        Scene scene;auto& gravity=scene.CreateObject("zero gravity closure fixture");gravity.id=100;gravity.transform.position={origin,0,0};
        gravity.gravity=SceneGravityComponent{};gravity.gravity->kind=SceneGravityKind::Uniform;gravity.gravity->magnitude=0;
        gravity.gravity->regionShape=SceneRegionShape::Box;gravity.gravity->regionHalfExtents={16,16,16};
        for(unsigned i=0;i<(shared?1:count);++i){auto& body=scene.CreateObject("ordinary finite carrier");body.id=1+i;body.transform.position={origin,4.f*i,0};
            body.body=SceneBodyComponent{};body.body->motion=SceneBodyMotion::Dynamic;body.body->shape=SceneShape::Sphere;body.body->radius=.5f;body.body->mass=1;body.body->collisionMask=0;}
        for(unsigned i=0;i<count;++i){auto& material=scene.CreateObject("independent implicit material owner");material.id=11+i;material.transform.position={origin,shared?0.f:4.f*i,0};
            material.deformable=DeformableSettings{};auto& settings=*material.deformable;settings.asset=record.id;settings.substeps=1;settings.iterations=12;
            settings.selfContact=false;settings.collisionMask=0;settings.material.density=2;settings.material.damping=0;settings.material.friction=0;
            DeformableAttachment pin;pin.group="pin";pin.kind=DeformableAttachment::Kind::Body;pin.target=shared?1:1+i;settings.attachments={pin};}
        scene.SetNextId(101);RuntimeWorld world;world.legacyGameplay=false;Check(world.Build(scene,&resources,error),"ordinary closure world builds with public component ownership");
        const float nativeH=1.f/480;const double h=nativeH;const double alpha=h*h*region.youngModulus,rho=alpha/(1+alpha),weight=1+rho;
        const double common=shared?rho*(count==2?.3:.1)/(1+count*weight):0;
        std::vector<DeformableInstance*> materials;std::vector<double> delta;
        for(unsigned i=0;i<count;++i){auto* material=world.RuntimeDeformable(11+i,error);Check(material&&material->NodeMass(0)==1&&material->NodeMass(1)==1,"closure fixture has actual one-kilogram free and pinned material nodes");
            materials.push_back(material);delta.push_back(.1*(i+1));Check(material->Impulse("free",{delta.back()/h,0,0}),"real free-node impulse supplies the analytically declared closure input");}
        unsigned interval=0;auto phase=world.StructuralVelocityCoupling(interval,1);const auto ordinarySolve=phase.solve;BodyTransform beforeExternal{};V beforeVelocity(0);Result result;
        if(external)phase.solve=[&](float dt,unsigned iteration){ordinarySolve(dt,iteration);if(iteration+1==phase.iterations){beforeExternal=world.Physics().PredictTransform(world.RuntimeBody(1),dt);beforeVelocity=world.Physics().GetLinearVelocity(world.RuntimeBody(1));world.Physics().ApplyLinearImpulse(world.RuntimeBody(1),{.0001f,0,0});result.externalVelocityChanged=V(world.Physics().GetLinearVelocity(world.RuntimeBody(1)))!=beforeVelocity;}};
        world.Physics().Step(nativeH,&phase);world.UpdateDeformables(h);result.healthy=true;
        for(unsigned i=0;i<count;++i){auto& material=*materials[i];result.healthy&=material.error.empty();if(!material.error.empty())result.error+=material.error+"; ";
            const auto body=world.RuntimeBody(shared?1:1+i);const double physicalX=h*double(world.Physics().GetLinearVelocity(body).x);
            const double pin=material.positions[0].x-origin,free=material.positions[1].x-origin-1,expectedPin=shared?common:rho*delta[i]/(1+weight),expectedFree=(delta[i]+alpha*expectedPin)/(1+alpha);
            result.pinError=std::max(result.pinError,std::abs(pin-expectedPin));result.freeError=std::max(result.freeError,std::abs(free-expectedFree));
            // Use the actual native final velocity's unrounded trajectory,
            // not its world-position ULP, to audit the common endpoint force.
            result.residual=std::max(result.residual,std::abs(free-delta[i]+alpha*(free-physicalX)));
            result.historyUnchanged&=material.structure.restLengths==std::vector<double>{1}&&material.structure.accumulatedPlasticStrain==std::vector<double>{0}&&material.structure.broken==std::vector<uint8_t>{0}&&material.structure.plasticWork==0&&material.structure.fractureWork==0&&material.structure.dampingWork==0;
            if(i)result.pinDifference=std::max(result.pinDifference,std::abs(material.positions[0].x-materials[0]->positions[0].x));}
        result.actualDisplacement=h*double(world.Physics().GetLinearVelocity(world.RuntimeBody(1)).x);
        if(external)result.poseDelta=glm::length(V(world.Physics().GetTransform(world.RuntimeBody(1)).position)-V(beforeExternal.position));
        std::map<std::string,SaveChunk> chunks;result.saved=WorldPersistence::Capture(world,chunks,error);
        std::printf("SHARED_CARRIER_CLOSURE origin=%.9g owners=%u shared=%d external=%d dt=%.12g iterations=12 healthy=%d saved=%d analyticalPinError=%.12g analyticalFreeError=%.12g actualForceResidual=%.12g pinDifference=%.12g actualDisplacement=%.12g externalVelocityChanged=%d externalPoseDelta=%.12g historyUnchanged=%d error=%s\n",origin,count,int(shared),int(external),h,int(result.healthy),int(result.saved),result.pinError,result.freeError,result.residual,result.pinDifference,result.actualDisplacement,int(result.externalVelocityChanged),result.poseDelta,int(result.historyUnchanged),result.error.c_str());
        world.Destroy();return result;
    };
    // Collect every control before asserting, so a genuine failure preserves
    // both local/far cases and the independent ownership controls in one log.
    const auto single=run(0,1,true,false),separate=run(0,2,false,false),local=run(0,2,true,false),far=run(125,2,true,false),late=run(125,1,true,true);
    const auto correct=[](const Result& result){return result.healthy&&result.saved&&result.pinError<1e-8&&result.freeError<1e-8&&result.residual<1e-5;};
    const auto refused=[](const Result& result){return !result.healthy&&!result.saved&&result.historyUnchanged&&result.error.find("actual rigid endpoint changed")!=std::string::npos;};
    Check(correct(single),"single-owner control reaches its independent analytical physical endpoint and can save");
    Check(correct(separate),"separate-carrier control preserves independent analytical endpoints without false ownership rejection");
    Check(correct(local)||refused(local),"shared carrier at the origin reaches the common physical root or explicitly refuses stale completion and save");
    Check(correct(far)||refused(far),"shared carrier at125m cannot accept a cached local root behind native position rounding");
    Check(late.externalVelocityChanged&&refused(late),"a real late small external kick at125m invalidates closure even when rounded pose scarcely changes");
}
DeformableAsset ContactPatch(bool plane,double yield=1e8,double ultimate=1e9,double shortening=.6){
    DeformableAsset a;a.kind=DeformableKind::Structure;a.structure=std::make_shared<StructuralCook>();
    // An intentional initial overlap makes the ordering witness independent
    // of gravity, scripts, impact timing, or a rigid collider. Only node zero
    // is free; its three noncollinear guides keep the contact correction from
    // being absorbed as a rigid translation/rotation of the whole patch.
    a.nodes=plane?std::vector<V>{{-2,0,-2},{2,0,-2},{0,0,2}}:std::vector<V>{{-.3,.002,-.2},{.3,.08,-.2},{0,.08,.4},{0,.25,-.1}};
    a.triangles={{0,1,2}};a.groups[plane?"plane":"guides"]=plane?std::vector<unsigned>{0,1,2}:std::vector<unsigned>{1,2,3};
    StructuralRegion r;r.key="contact specimen";r.youngModulus=1e6;r.damping=0;r.hardening=1e4;
    r.tensionYield=1e8;r.tensionUltimate=1e9;r.compressionYield=yield;r.compressionUltimate=ultimate;r.maxShortening=shortening;
    a.structure->regions={r};
    for(unsigned i=0;i<a.nodes.size();++i)for(unsigned j=i+1;j<a.nodes.size();++j){StructuralBeam b;b.key="member-"+std::to_string(i)+"-"+std::to_string(j);b.a=i;b.b=j;b.area=.002;a.structure->beams.push_back(b);}
    a.structure->surfaceRegions={0};a.structure->surfaceSupports={plane?std::vector<unsigned>{0,1,2}:std::vector<unsigned>{0,1,3}};
    std::string error;if(!PrepareDeformableAsset(a,error))throw std::runtime_error(error);return a;
}
DeformableAsset SingleContactLoadPath(){
    DeformableAsset a;a.kind=DeformableKind::Structure;a.structure=std::make_shared<StructuralCook>();
    // A separate specimen has exactly ONE physical path to its guide. Unlike
    // the tetrahedral K4 above, one accepted failure really detaches node 0.
    // Contact comes from its physical node against the same structural plane;
    // no fabricated skin or extra guide path supplies hidden support.
    a.nodes={{0,.002,0},{0,.25,0}};a.groups["guides"]={1};
    StructuralRegion r;r.key="single contact load path";r.youngModulus=1e6;r.damping=0;r.hardening=1e4;
    r.tensionYield=1e8;r.tensionUltimate=1e9;r.compressionYield=500;r.compressionUltimate=1000;r.maxShortening=0;
    a.structure->regions={r};StructuralBeam b;b.key="sole compression member";b.a=0;b.b=1;b.area=.002;a.structure->beams={b};
    std::string error;if(!PrepareDeformableAsset(a,error))throw std::runtime_error(error);return a;
}
DeformableSettings ContactSettings(const AssetId& asset,bool plane,unsigned substeps){
    DeformableSettings cfg;cfg.asset=asset;cfg.substeps=substeps;cfg.iterations=4;cfg.selfContact=false;
    cfg.collisionLayer=0;cfg.collisionMask=CategoryBit(0);cfg.material.density=100;cfg.material.damping=0;cfg.material.thickness=.02;
    DeformableAttachment pin;pin.group=plane?"plane":"guides";pin.kind=DeformableAttachment::Kind::World;cfg.attachments={pin};return cfg;
}
Scene ContactFixture(const AssetId& plane,const AssetId& patch,unsigned substeps){
    Scene scene;auto& gravity=scene.CreateObject("zero gravity contact ordering fixture");gravity.id=100;
    gravity.gravity=SceneGravityComponent{};gravity.gravity->kind=SceneGravityKind::Uniform;gravity.gravity->magnitude=0;
    gravity.gravity->regionShape=SceneRegionShape::Box;gravity.gravity->regionHalfExtents={4,4,4};
    auto& lower=scene.CreateObject("clamped physical structural plane");lower.id=101;lower.deformable=ContactSettings(plane,true,substeps);
    auto& upper=scene.CreateObject("guided physical structural contact patch");upper.id=102;upper.deformable=ContactSettings(patch,false,substeps);scene.SetNextId(103);return scene;
}
double UnobservedStress(const DeformableInstance& instance){
    double gap=0;for(unsigned i=0;i<instance.asset->structure->beams.size();++i){const auto& b=instance.asset->structure->beams[i];
        const double actual=instance.asset->structure->regions[b.region].youngModulus*std::abs(glm::length(instance.positions[b.b]-instance.positions[b.a])-instance.structure.restLengths[i])/b.restLength;
        gap=std::max(gap,actual-instance.structure.stressDemand[i]);
    }return gap;
}
void ContactAcceptance(const AssetId& planeId,const AssetId& patchId,unsigned substeps,unsigned mode,ResourceManager& resources){
    RuntimeWorld world;world.legacyGameplay=false;std::string error;const bool built=world.Build(ContactFixture(planeId,patchId,substeps),&resources,error);
    if(!built)std::fprintf(stderr,"CONTACT_FIXTURE_BUILD: %s\n",error.c_str());
    Check(built,"two ordinary structural participants build without rigid contact or scripts");
    auto* lower=world.RuntimeDeformable(101,error);auto* upper=world.RuntimeDeformable(102,error);
    if(!lower||!upper)throw std::runtime_error("contact specimen did not publish");
    const auto clamped=lower->positions;double mass=0;for(unsigned n=0;n<upper->positions.size();++n)mass+=upper->NodeMass(n);
    if(substeps==1&&mode!=3){world.Physics().Step(1.f/60);world.UpdateDeformables(1./60);}else Macro(world);
    double acceptedMass=0,plastic=0;unsigned broken=0;
    for(unsigned n=0;n<upper->positions.size();++n)acceptedMass+=upper->NodeMass(n);
    for(unsigned i=0;i<upper->structure.restLengths.size();++i){plastic=std::max(plastic,std::abs(upper->structure.restLengths[i]-upper->asset->structure->beams[i].restLength));broken+=upper->structure.broken[i]!=0;}
    const double gap=UnobservedStress(*upper);
    std::printf("STRUCTURE_PAIR substeps=%u mode=%u contacts=%zu maximumUnobservedStress=%.12g plasticRestChange=%.12g broken=%u revision=%llu\n",substeps,mode,upper->stats.contacts+lower->stats.contacts,gap,plastic,broken,(unsigned long long)upper->TopologyRevision());
    Check(upper->error.empty()&&lower->error.empty()&&upper->stats.contacts+lower->stats.contacts>0&&lower->positions==clamped&&acceptedMass==mass&&upper->stats.substeps==substeps,"real structural pair contact preserves clamped support and nodal mass in the requested world interval path");
    Check(gap<1e-6,"accepted structural pair geometry has no member stress absent from this macro's constitutive observation");
    if(mode==1)Check(plastic>1e-4&&upper->structure.plasticWork>0&&broken==0,"pair contact accepts ductile rest change and plastic work before leaving the same physical boundary");
    if(mode==2){
        bool justified=true;for(unsigned i=0;i<upper->structure.broken.size();++i)if(upper->structure.broken[i]){const auto& member=upper->asset->structure->beams[i];const auto& region=upper->asset->structure->regions[member.region];
            const double stress=region.youngModulus*(glm::length(upper->positions[member.b]-upper->positions[member.a])-upper->structure.restLengths[i])/member.restLength;
            justified&=stress>region.tensionUltimate||-stress>region.compressionUltimate;
        }
        std::vector<uint8_t> reachable(upper->positions.size(),0);reachable[0]=1;bool changed=true;
        while(changed){changed=false;for(unsigned i=0;i<upper->structure.broken.size();++i)if(!upper->structure.broken[i]){const auto& member=upper->asset->structure->beams[i];if(reachable[member.a]!=reachable[member.b]){reachable[member.a]=reachable[member.b]=1;changed=true;}}}
        bool independentlySupported=true;for(auto n:upper->asset->groups.at("guides"))independentlySupported&=reachable[n]!=0;
        Check(broken>0&&upper->TopologyRevision()>1&&justified&&upper->ConnectedNodes({0},upper->asset->groups.at("guides"))==independentlySupported&&(broken!=1||independentlySupported),"accepted ultimate failures remove only real paths and surviving tetrahedral connectivity matches independent traversal");
    }
    if(mode==3){
        Check(broken==1&&upper->TopologyRevision()>1&&!upper->ConnectedNodes({0},upper->asset->groups.at("guides")),"exhausting the sole physical load path commits actual separation at the same boundary");
        const auto detached=upper->positions[0];const auto guide=upper->positions[1];Macro(world);double continuedMass=0;for(unsigned n=0;n<upper->positions.size();++n)continuedMass+=upper->NodeMass(n);
        Check(upper->error.empty()&&upper->positions[1]==guide&&upper->positions[0].y>detached.y+1e-3&&continuedMass==mass&&!upper->ConnectedNodes({0},upper->asset->groups.at("guides")),"detached material retains finite mass and moves through ordinary contact without a surviving hidden connection");
    }
    world.Destroy();
}
}
int main(int argc,char** argv){try{
    const auto destination=fs::absolute(argc>1?fs::path(argv[1]):fs::temp_directory_path()/"judas-structural-world");
    const auto root=destination/std::to_string(std::chrono::steady_clock::now().time_since_epoch().count());fs::create_directories(root/"Assets");
    const auto asset=Patch();const auto path=root/"Assets/patch.judasdeform";std::ofstream(path,std::ios::binary)<<EncodeDeformableAsset(asset);
    AssetDatabase database;database.Scan(root.string(),(root/"Assets").string());AssetRecord record;std::string error;
    Check(database.Track(path.string(),record,error),"ordinary structural asset registration succeeds");
    ResourceManager resources(nullptr,&database);resources.SetBlockingMode(true);
    RuntimeWorld world;world.legacyGameplay=false;const auto scene=Fixture(record.id);
    Check(world.Build(scene,&resources,error),"native world fixture builds without project scripts or a renderer");
    auto* patch=world.RuntimeDeformable(2,error);Check(patch&&patch->Structural(),"normal world lazily publishes structural material");
    Check(world.SetRuntimeMotionType(1,SceneBodyMotion::Kinematic,false,error),"ordinary body supports prescribed translation and rotation");
    const auto body=world.RuntimeBody(1);Check(world.Physics().SetKinematicVelocity(body,{3,.5f,-2},{0,4,0}),"physical body receives ordinary persistent velocity command");
    const auto staleFrame=Frame(world.PresentedTransform(1,scene.Find(1)->transform,1));
    DeformableInstance negative;negative.Initialize(patch->asset,patch->settings,glm::dmat4(1),900);
    DeformableTarget staleTarget;staleTarget.valid=true;staleTarget.body=body;staleTarget.previous=staleTarget.current=staleFrame;
    double targetError=0,trackingError=0,staleError=0,wrapperDrift=0;unsigned intervals=0;
    unsigned currentInterval=0;auto velocityPhase=world.StructuralVelocityCoupling(currentInterval,8);
    world.Physics().StepCoupled(1.f/60,8,[&](float,unsigned i){currentInterval=i;},[&](float h,unsigned i){
        (void)i;++intervals;
        const auto actual=Frame(world.Physics().GetTransform(body));
        const auto& target=world.Deformables().at(2).targets.front();
        targetError=std::max(targetError,MatrixError(target.current,actual));trackingError=std::max(trackingError,PatchError(*patch,actual));
        wrapperDrift=std::max(wrapperDrift,MatrixError(Frame(world.PresentedTransform(1,scene.Find(1)->transform,1)),staleFrame));
        // Executable negative control recreates the stale-publication input.
        // Its physically integrated material must fail the same pose metric;
        // checking only that one source method was called would not prove it.
        negative.StepStructuralInterval(h,world.Physics(),UniformGravity({0,0,0}),{staleTarget},i==0,i==7);
        staleError=std::max(staleError,PatchError(negative,actual));
    },&velocityPhase);
    world.UpdateDeformables(1./60);const auto physical=world.Physics().GetTransform(body);
    const double translation=glm::length(V(physical.position));const double rotation=glm::length(glm::dquat(physical.rotation)*V(1,0,0)-V(1,0,0));
    std::printf("WORLD_TARGET intervals=%u targetMatrixError=%.12g patchError=%.12g stalePatchError=%.12g wrapperPublicationDrift=%.12g translation=%.9g rotationBasisTravel=%.9g\n",intervals,targetError,trackingError,staleError,wrapperDrift,translation,rotation);
    Check(intervals==8&&translation>.05&&rotation>.05,"fixture physically translates and rotates over eight real rigid intervals");
    Check(wrapperDrift<1e-12,"dynamic presentation wrapper deliberately remains at macro start during every interval");
    Check(targetError<1e-9&&trackingError<1e-9&&patch->error.empty(),"body targets and material patch track actual current physical pose before wrapper publication");
    Check(staleError>.03&&negative.error.empty(),"deliberately stale-publication material fails the same physical tracking metric");

    // The normal participant and retained-state envelopes carry structure only
    // under their new versions. Loading under an old reader must reject rather
    // than silently retain an intact authored graph.
    std::map<std::string,SaveChunk> chunks;
    Check(WorldPersistence::Capture(world,chunks,error)&&chunks.at("deformables").version==5,"normal world capture emits structural deformables participant 5");
    std::string retained;Check(world.CaptureDeformable(2,retained,error)&&retained.rfind("Judas.DeformableState.3\n",0)==0,"retained structural material uses explicit state envelope 3");
    Scene saved;RuntimeWorld cold;cold.legacyGameplay=false;
    Check(WorldPersistence::SceneFrom(chunks,saved,error)&&cold.Build(saved,&resources,error,nullptr,nullptr,true)&&WorldPersistence::Prepare(cold,error)&&WorldPersistence::Restore(cold,chunks,error),"fresh private world restores required structural state and ordinary body motion");
    auto* restored=cold.RuntimeDeformable(2,error);
    Check(restored&&restored->positions==patch->positions&&restored->velocities==patch->velocities&&restored->structure.restLengths==patch->structure.restLengths&&restored->structure.broken==patch->structure.broken&&restored->generation!=patch->generation,"cold construction preserves exact physical patch state with a fresh handle");
    auto legacy=chunks;legacy.at("deformables").version=4;RuntimeWorld rejected;rejected.legacyGameplay=false;
    Check(rejected.Build(saved,&resources,error,nullptr,nullptr,true)&&WorldPersistence::Prepare(rejected,error)&&!WorldPersistence::Restore(rejected,legacy,error),"downgraded participant 4 cannot discard required structural state");
    auto oldRetained=retained;oldRetained.replace(0,std::string("Judas.DeformableState.3\n").size(),"Judas.DeformableState.2\n");
    Check(!cold.RestoreDeformable(2,oldRetained,error)&&restored->positions==patch->positions,"retained reader 2 rejects structural state without changing live node geometry");
    Check(cold.RestoreDeformable(2,retained,error),"retained reader 3 restores the matching structural record");
    Macro(world);Macro(cold);double resumedError=0;restored=cold.RuntimeDeformable(2,error);
    for(unsigned n=0;n<patch->positions.size();++n)resumedError=std::max(resumedError,glm::length(patch->positions[n]-restored->positions[n]));
    std::printf("COLD_RESUME patchError=%.12g\n",resumedError);
    Check(resumedError<1e-9&&restored->error.empty()&&patch->error.empty(),"first resumed coupled interval reconstructs targets from physical motion without stale publication");
    MixedParticipantContinuation(record.id,root,database,resources);
    const auto plane=ContactPatch(true),elastic=ContactPatch(false),ductile=ContactPatch(false,500,1e8),exhausted=ContactPatch(false,500,1000,0),singlePath=SingleContactLoadPath();
    auto registerContact=[&](const DeformableAsset& a,const char* name){const auto p=root/"Assets"/name;std::ofstream(p,std::ios::binary)<<EncodeDeformableAsset(a);AssetRecord r;
        if(!database.Track(p.string(),r,error))throw std::runtime_error(error);
        return r.id;};
    const auto planeId=registerContact(plane,"contact-plane.judasdeform"),elasticId=registerContact(elastic,"contact-elastic.judasdeform"),ductileId=registerContact(ductile,"contact-ductile.judasdeform"),exhaustedId=registerContact(exhausted,"contact-exhausted.judasdeform"),singlePathId=registerContact(singlePath,"contact-single-path.judasdeform");
    // Executable negative control recreates the removed post-accept contact
    // order with the identical elastic participants and physical contact law.
    PhysicsWorld isolated;isolated.Init();DeformableInstance negativeLower,negativeUpper;
    negativeLower.Initialize(std::make_shared<DeformableAsset>(plane),ContactSettings(planeId,true,1),glm::dmat4(1),901);
    negativeUpper.Initialize(std::make_shared<DeformableAsset>(elastic),ContactSettings(elasticId,false,1),glm::dmat4(1),902);
    DeformableTarget fixed;fixed.valid=true;fixed.previous=fixed.current=glm::dmat4(1);
    negativeLower.StepStructuralInterval(1./60,isolated,UniformGravity({0,0,0}),{fixed},true,true);
    negativeUpper.StepStructuralInterval(1./60,isolated,UniformGravity({0,0,0}),{fixed},true,true);
    DeformableInstance::SurfaceContacts(negativeUpper,negativeLower,1./60);DeformableInstance::SurfaceContacts(negativeLower,negativeUpper,1./60);
    const double negativeGap=UnobservedStress(negativeUpper);std::printf("POST_ACCEPT_NEGATIVE maximumUnobservedStress=%.12g\n",negativeGap);
    Check(negativeUpper.error.empty()&&negativeLower.error.empty()&&negativeUpper.stats.contacts+negativeLower.stats.contacts>0&&negativeGap>100,"post-accept negative control fails the same observed stress contract after real structural contact");
    ContactAcceptance(planeId,elasticId,1,0,resources);
    ContactAcceptance(planeId,ductileId,1,1,resources);
    ContactAcceptance(planeId,exhaustedId,1,2,resources);
    ContactAcceptance(planeId,singlePathId,1,3,resources);
    ContactAcceptance(planeId,elasticId,8,0,resources);
    SharedCarrierClosure(root,database,resources);
    rejected.Destroy();cold.Destroy();world.Destroy();resources.Shutdown();
    std::printf("Structural world coupling %u PASS\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"Structural world coupling FAIL after %u: %s\n",checks,e.what());return 1;}}
