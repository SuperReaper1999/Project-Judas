#include "PhysicsWorld.h"
#include "SaveArchive.h"
#include <array>
#include <cstdio>
#include <cmath>
#include <stdexcept>
#include <limits>
namespace {unsigned checks=0,failures=0;void Check(bool ok,const char* text){++checks;failures+=!ok;std::printf("%s %s\n",ok?"PASS":"FAIL",text);}constexpr float dt=1.f/60;}
int main(){
    PhysicsWorld ordinary,coupled;ordinary.Init();coupled.Init();
    auto a=ordinary.CreateDynamicBox({0,4,0},{.2f,.3f,.4f},2,0,0),b=coupled.CreateDynamicBox({0,4,0},{.2f,.3f,.4f},2,0,0);
    ordinary.ApplyForce(a,{120,0,0});coupled.ApplyForce(b,{120,0,0});ordinary.Step(dt);coupled.StepCoupled(dt,1,{},{});
    Check(ordinary.GetTransform(a).position==coupled.GetTransform(b).position&&ordinary.GetLinearVelocity(a)==coupled.GetLinearVelocity(b),"single coupled interval preserves exact ordinary physics path");
    coupled.ResetBody(b,{0,4,0},{1,0,0,0});coupled.ApplyForce(b,{120,0,0});unsigned before=0,after=0;
    coupled.StepCoupled(dt,8,[&](float h,unsigned i){++before;Check(i<8&&std::abs(h*8-dt)<1e-8,"bounded interval callback uses actual cadence");},[&](float,unsigned){++after;});
    Check(before==8&&after==8&&std::abs(coupled.GetLinearVelocity(b).x-1)<1e-6,"macro force retained over all intervals without repeating impulses");
    Check(coupled.GetPreviousTransform(b).position==glm::vec3(0,4,0),"presentation previous pose stays at macro start");
    auto motion=coupled.GetBodyMotionSegments(b);Check(motion.size()>=8&&std::abs(motion.front().begin)<1e-12&&std::abs(motion.back().end-dt)<1e-8,"motion ledger spans full fixed step across coupled intervals");
    bool bad=false;try{coupled.StepCoupled(dt,0,{},{});}catch(const std::invalid_argument&){bad=true;}Check(bad,"invalid substep request rejected before simulation");
    auto k=coupled.CreateStaticBox({-2,0,0},{.25f,.25f,.25f},0,0);coupled.SetMotionType(k,BodyMotionType::Kinematic);coupled.MoveKinematic(k,{{2,0,0},{1,0,0,0}});
    coupled.StepCoupled(dt,8,{},{});Check(glm::length(coupled.GetTransform(k).position-glm::vec3(2,0,0))<1e-5&&coupled.GetPreviousTransform(k).position==glm::vec3(-2,0,0),"next-fixed-step kinematic target spans macro cadence instead of first interval");
    PhysicsWorld support;support.Init();support.CreateStaticBox({0,-.5f,0},{4,.5f,4},.5f,0);auto rider=support.CreateDynamicBox({0,.5f,0},{.5f,.5f,.5f},10,.5f,0);
    for(unsigned step=0;step<120;++step){support.StepCoupled(dt,8,[&](float h,unsigned){support.ApplyLinearAcceleration(rider,{0,-9.81f,0},h);},{});Check(support.LastStepTouchEvents().size()<=1,"rigid contact events publish one pair event per macro step");}
    std::vector<PhysicsWorld::BodyContactSample> contacts;double impulse=0;const bool available=support.ReadBodyContactSample(rider,contacts);for(const auto& c:contacts)impulse+=c.normalImpulse;
    std::printf("SUPPORT contacts=%zu impulse_ns=%.9g expected_ns=%.9g\n",contacts.size(),impulse,10*9.81*dt);
    Check(available&&contacts.size()>=3&&std::abs(impulse-10*9.81*dt)<.05,"completed observations preserve manifold points and macro support impulse");
    PhysicsWorld small;small.Init();small.CreateStaticBox({0,-.5f,0},{4,.5f,4},.5f,0);auto tiny=small.CreateDynamicBox({0,.01f,0},{.01f,.01f,.01f},1,.5f,0);
    for(unsigned i=0;i<60;++i)small.StepCoupled(dt,3,[&](float h,unsigned){small.ApplyLinearAcceleration(tiny,{0,-9.81f,0},h);},{});
    contacts.clear();Check(small.ReadBodyContactSample(tiny,contacts)&&contacts.size()>=3,"sub-five-centimetre patch retains distinct manifold rows across non-power-of-two intervals");
    PhysicsWorld jointWorld;jointWorld.Init();auto suspended=jointWorld.CreateDynamicBox({0,2,0},{.1f,.1f,.1f},2,0,0);
    JointSettings pin;pin.type=JointType::Fixed;pin.bodyA=suspended;pin.anchorB={0,2,0};auto hinge=jointWorld.CreateJoint(pin);
    jointWorld.StepCoupled(dt,8,[&](float h,unsigned){jointWorld.ApplyLinearAcceleration(suspended,{0,-9.81f,0},h);},{});JointState reaction;const bool found=jointWorld.GetJoint(hinge,reaction);
    Check(found&&std::abs(glm::length(reaction.reactionImpulse)-2*9.81f*dt)<.01f,"completed joint reaction spans the macro interval for structural strength observations");
    bool bounded=true;
    for(unsigned step=0;step<90;++step){
        jointWorld.StepCoupled(dt,8,[&](float h,unsigned){jointWorld.ApplyLinearAcceleration(suspended,{0,-9.81f,0},h);},{});
        JointState sample;jointWorld.GetJoint(hinge,sample);
        bounded&=std::isfinite(glm::length(sample.reactionImpulse))&&glm::length(sample.reactionImpulse)<2*9.81f*dt+.01f;
    }
    jointWorld.GetJoint(hinge,reaction);
    Check(jointWorld.IsSleeping(suspended)&&bounded&&reaction.reactionImpulse==glm::vec3(0)&&reaction.reactionAngularImpulse==glm::vec3(0)&&reaction.motorImpulse==0,
        "sleeping coupled joints publish only actual interval reactions without multiplying prior macro observations");
    SaveArchive sleepContinuation;jointWorld.PersistJointContinuation(sleepContinuation,hinge);
    SaveArchive parsed(sleepContinuation.bytes);uint32_t version=0;std::string context;float interval=0;std::array<float,12> warm{};parsed(version,context,interval);for(auto& value:warm)parsed(value);
    bool hasWarm=false;for(float value:warm)hasWarm|=value!=0;
    for(unsigned step=0;step<3;++step)jointWorld.StepCoupled(dt,8,[&](float h,unsigned){jointWorld.ApplyLinearAcceleration(suspended,{0,-9.81f,0},h);},{});
    SaveArchive stillSleeping;jointWorld.PersistJointContinuation(stillSleeping,hinge);
    Check(hasWarm&&sleepContinuation.bytes==stillSleeping.bytes,
        "clearing sleeping reaction observations preserves nonzero last-interval joint warm history exactly");
    jointWorld.Wake(suspended);
    jointWorld.StepCoupled(dt,8,[&](float h,unsigned){jointWorld.ApplyLinearAcceleration(suspended,{0,-9.81f,0},h);},{});
    jointWorld.GetJoint(hinge,reaction);const bool nonzeroBeforeDisable=glm::length(reaction.reactionImpulse)>.1f;
    pin.enabled=false;const bool disabled=jointWorld.SetJoint(hinge,pin);bool disabledZero=true;
    for(unsigned step=0;step<4;++step){jointWorld.StepCoupled(dt,8,[&](float h,unsigned){jointWorld.ApplyLinearAcceleration(suspended,{0,-9.81f,0},h);},{});JointState sample;jointWorld.GetJoint(hinge,sample);disabledZero&=!sample.active&&sample.reactionImpulse==glm::vec3(0)&&sample.reactionAngularImpulse==glm::vec3(0)&&sample.motorImpulse==0;}
    Check(nonzeroBeforeDisable&&disabled&&disabledZero,
        "disabled coupled joint cannot republish or amplify its last loaded macro reaction");
    PhysicsWorld launch;launch.Init();
    launch.CreateStaticBox({1,0,0},{.05f,1,1},0,0);
    auto launched=launch.CreateDynamicBox({0,0,0},{.05f,.05f,.05f},1,0,0);
    PhysicsWorld::VelocityCoupling phase;phase.iterations=1;
    phase.solve=[&](float,unsigned iteration){if(iteration==0)launch.ApplyLinearImpulse(launched,{200,0,0});};
    launch.Step(dt,&phase);
    Check(launch.LastStepStats().impactEvents>0&&launch.GetTransform(launched).position.x<=.902f,
        "an optional material velocity reaction refreshes actual CCD candidates before its one rigid pose advance");
    PhysicsWorld prescribed;prescribed.Init();
    auto moving=prescribed.CreateStaticBox({0,0,0},{.2f,.3f,.4f},0,0);
    prescribed.SetMotionType(moving,BodyMotionType::Kinematic);
    prescribed.SetKinematicVelocity(moving,{2,-1,3},{1,2,-.5f});
    BodyTransform predicted;bool readonly=false;
    phase.solve={};phase.begin=[&](float h){predicted=prescribed.PredictTransform(moving,h);readonly=prescribed.GetTransform(moving).position==glm::vec3(0);};
    prescribed.Step(dt,&phase);auto actual=prescribed.GetTransform(moving);
    Check(readonly&&glm::length(predicted.position-actual.position)<1e-6f&&std::abs(glm::dot(predicted.rotation,actual.rotation))>1-1e-6f,
        "kinematic material prediction previews the actual prescribed drift without advancing its live pose");
    prescribed.MoveKinematic(moving,{{1,2,3},glm::angleAxis(.4f,glm::normalize(glm::vec3(1,2,3)))},.01f);
    bool stoppedPreview=false;phase.begin=[&](float h){predicted=prescribed.PredictTransform(moving,h);stoppedPreview=prescribed.PredictPointVelocity(moving,predicted.position,h)==glm::vec3(0);};
    prescribed.Step(dt,&phase);actual=prescribed.GetTransform(moving);
    Check(stoppedPreview&&glm::length(predicted.position-actual.position)<1e-6f&&std::abs(glm::dot(predicted.rotation,actual.rotation))>1-1e-6f,
        "a prescribed target ending inside the interval predicts its endpoint and stopped velocity correctly");
    PhysicsWorld waking;waking.Init();auto asleep=waking.CreateDynamicBox({0,2,0},{.1f,.1f,.1f},2,0,0);
    pin=JointSettings{};pin.type=JointType::Fixed;pin.bodyA=asleep;pin.anchorB={0,2,0};auto anchor=waking.CreateJoint(pin);
    for(unsigned i=0;i<120;++i){waking.ApplyLinearAcceleration(asleep,{0,-9.81f,0},dt);waking.Step(dt);}
    const bool wasSleeping=waking.IsSleeping(asleep);waking.ApplyLinearAcceleration(asleep,{0,-9.81f,0},dt);
    phase.begin=[&](float h){waking.PreparePredictedBody(asleep,h);};
    phase.solve=[&](float,unsigned i){if(i==0)waking.ApplyLinearImpulse(asleep,{2,0,0});};
    waking.Step(dt,&phase);waking.GetJoint(anchor,reaction);
    Check(wasSleeping&&glm::length(waking.GetLinearVelocity(asleep))<1e-4f&&glm::length(waking.GetTransform(asleep).position-glm::vec3(0,2,0))<1e-4f&&reaction.reactionImpulse.y>.3f,
        "a material-woken body receives this interval's deferred gravity and ordinary fixed-joint constraints");
    PhysicsWorld freeWake;freeWake.Init();auto free=freeWake.CreateDynamicBox({0,0,0},{.1f,.1f,.1f},2,0,0);
    for(unsigned i=0;i<120;++i)freeWake.Step(dt);
    const bool freeAsleep=freeWake.IsSleeping(free);freeWake.ApplyLinearAcceleration(free,{0,-9.81f,0},dt);
    phase.solve={};phase.begin=[&](float h){freeWake.PreparePredictedBody(free,h);freeWake.PreparePredictedBody(free,h);};
    freeWake.Step(dt,&phase);
    Check(freeAsleep&&std::abs(freeWake.GetLinearVelocity(free).y+9.81f*dt)<1e-6f,
        "preparing the same sleeping finite participant twice consumes deferred gravity exactly once");
    // Unlike the mapped pin above, this sleeping partner wakes only when a
    // material reaction arrives inside a solver round. Its existing native
    // joint and sampled gravity must participate in that same fixed boundary.
    PhysicsWorld lateWake;lateWake.Init();auto late=lateWake.CreateDynamicBox({0,2,0},{.1f,.1f,.1f},2,0,0);
    pin=JointSettings{};pin.type=JointType::Fixed;pin.bodyA=late;pin.anchorB={0,2,0};auto lateAnchor=lateWake.CreateJoint(pin);
    for(unsigned i=0;i<120;++i){lateWake.ApplyLinearAcceleration(late,{0,-9.81f,0},dt);lateWake.Step(dt);}
    const bool lateAsleep=lateWake.IsSleeping(late);lateWake.ApplyLinearAcceleration(late,{0,-9.81f,0},dt);
    phase.begin={};phase.solve=[&](float h,unsigned i){if(i==0)lateWake.ApplyPredictedImpulseAtPoint(late,{2,0,0},{0,2,0},h);};
    lateWake.Step(dt,&phase);lateWake.GetJoint(lateAnchor,reaction);
    Check(lateAsleep&&glm::length(lateWake.GetLinearVelocity(late))<1e-4f&&reaction.reactionImpulse.y>.3f,
        "a previously unmapped contact-woken island receives gravity and its existing native joint in the current interval");
    PhysicsWorld trials;trials.Init();
    const auto trialBody=trials.CreateShape(Shape::Box({.2f,.3f,.4f}),
        {{3,4,5},glm::angleAxis(.6f,glm::normalize(glm::vec3(1,2,3)))},true,2,0,0);
    trials.SetLinearVelocity(trialBody,{1,-2,3});trials.SetAngularVelocity(trialBody,{2,-1,.7f});
    const auto originalPose=trials.GetTransform(trialBody);
    const auto originalLinear=trials.GetLinearVelocity(trialBody),originalAngular=trials.GetAngularVelocity(trialBody);
    const glm::vec3 candidateLinear(.3f,-.2f,.1f),candidateAngular(.03f,.04f,-.02f);
    const auto trialPose=trials.PredictTransformAfterImpulse(trialBody,.003f,candidateLinear,candidateAngular);
    const auto trialCom=trials.PredictCenterOfMassAfterImpulse(trialBody,.003f,candidateLinear,candidateAngular);
    glm::vec3 previewLinear,previewAngular;
    const bool previewValid=trials.PredictVelocitiesAfterImpulse(trialBody,candidateLinear,candidateAngular,previewLinear,previewAngular);
    Check(trials.GetTransform(trialBody).position==originalPose.position&&trials.GetTransform(trialBody).rotation==originalPose.rotation&&
        trials.GetLinearVelocity(trialBody)==originalLinear&&trials.GetAngularVelocity(trialBody)==originalAngular,
        "rejected numerical impulse previews cannot mutate authoritative rigid pose or velocities");
    trials.ApplyLinearImpulse(trialBody,candidateLinear);trials.ApplyAngularImpulse(trialBody,candidateAngular);
    Check(previewValid&&previewLinear==trials.GetLinearVelocity(trialBody)&&previewAngular==trials.GetAngularVelocity(trialBody),
        "pure velocity preview matches the actual binary32 native impulse kick exactly");
    const auto committedPreview=trials.PredictTransform(trialBody,.003f);
    Check(trialPose.position==committedPreview.position&&trialPose.rotation==committedPreview.rotation&&trialCom==trials.PredictCenterOfMass(trialBody,.003f),
        "pure candidate prediction exactly matches ordinary impulses and native angular drift on anisotropic inertia");
    bool rejectsInvalid=false;try{trials.PredictTransformAfterImpulse(trialBody,.003f,{NAN,0,0},{0,0,0});}catch(const std::invalid_argument&){rejectsInvalid=true;}
    Check(rejectsInvalid&&trials.GetTransform(trialBody).position==originalPose.position,
        "invalid candidate momentum fails before publishing any physical state");
    const auto fixedTrial=trials.CreateStaticBox({8,9,10},{1,1,1},0,0);
    Check(trials.PredictTransformAfterImpulse(fixedTrial,dt,candidateLinear,candidateAngular).position==trials.GetTransform(fixedTrial).position,
        "a numerical trial cannot make an immovable collider dynamic");
    Check(trials.PredictVelocitiesAfterImpulse(fixedTrial,candidateLinear,candidateAngular,previewLinear,previewAngular)&&previewLinear==glm::vec3(0)&&previewAngular==glm::vec3(0),
        "pure velocity preview cannot apply a kick to an immovable collider");
    Check(!trials.PredictVelocitiesAfterImpulse({},candidateLinear,candidateAngular,previewLinear,previewAngular)&&previewLinear==glm::vec3(0)&&previewAngular==glm::vec3(0),
        "pure velocity preview rejects stale bodies without returning unrelated physical state");
    bool rejectsInvalidVelocity=false;try{trials.PredictVelocitiesAfterImpulse(trialBody,{0,0,0},{NAN,0,0},previewLinear,previewAngular);}catch(const std::invalid_argument&){rejectsInvalidVelocity=true;}
    Check(rejectsInvalidVelocity&&trials.GetTransform(trialBody).position==originalPose.position,
        "invalid numerical velocity previews fail without publishing pose or impulse");
    const auto angularDerivative=[&](glm::quat orientation,glm::vec3 velocity){
        trials.ResetBody(trialBody,{3,4,5},orientation);trials.SetAngularVelocity(trialBody,velocity);
        const auto pose=trials.GetTransform(trialBody);const auto rate=trials.GetAngularVelocity(trialBody);
        constexpr float h=1.f/480,epsilon=.02f;
        const auto derivative=trials.PredictedAngularImpulseJacobian(trialBody,h);
        double relative=0;
        for(unsigned axis=0;axis<3;++axis){glm::vec3 perturbation(0);perturbation[axis]=epsilon;
            const auto plus=trials.PredictTransformAfterImpulse(trialBody,h,{0,0,0},perturbation);
            const auto minus=trials.PredictTransformAfterImpulse(trialBody,h,{0,0,0},-perturbation);
            auto difference=glm::normalize(glm::dquat(plus.rotation)*glm::conjugate(glm::normalize(glm::dquat(minus.rotation))));
            if(difference.w<0)difference=-difference;
            const glm::dvec3 imaginary(difference.x,difference.y,difference.z);const double length=glm::length(imaginary);
            const auto finite=length>0?imaginary*(std::atan2(length,difference.w)/(double(epsilon)*length)):glm::dvec3(0);
            relative=std::max(relative,glm::length(finite-derivative[axis])/std::max(1e-12,glm::length(finite)));
        }
        std::printf("NATIVE_ANGULAR_JACOBIAN speed=%.9g relativeError=%.9g\n",glm::length(velocity),relative);
        return relative<.002&&trials.GetTransform(trialBody).position==pose.position&&trials.GetTransform(trialBody).rotation==pose.rotation&&trials.GetAngularVelocity(trialBody)==rate;
    };
    const auto oblique=glm::angleAxis(.6f,glm::normalize(glm::vec3(1,2,3)));
    Check(angularDerivative(oblique,{0,0,0}),"native endpoint angular derivative matches independent impulse previews at rest without physical mutation");
    Check(angularDerivative(oblique,{2,-1,.7f}),"native endpoint angular derivative follows anisotropic implicit midpoint and Cayley drift at ordinary speed");
    Check(angularDerivative(oblique,{75,-100,50}),"native endpoint angular derivative follows the same fast anisotropic spin without assuming a small rotation");
    Check(trials.PredictedAngularImpulseJacobian(fixedTrial,dt)==glm::dmat3(0)&&trials.PredictedAngularImpulseJacobian({},dt)==glm::dmat3(0),
        "endpoint derivative cannot give an immovable or stale body a numerical angular degree of freedom");
    const auto preciseTrajectory=[&](glm::vec3 position){
        trials.ResetBody(trialBody,position,oblique);trials.SetLinearVelocity(trialBody,{1,-2,4.924925f});trials.SetAngularVelocity(trialBody,{2,-1,.7f});
        const auto pose=trials.GetTransform(trialBody);const auto velocity=trials.GetLinearVelocity(trialBody),omega=trials.GetAngularVelocity(trialBody);
        constexpr float h=1.f/480;const auto precise=trials.PredictPreciseTransformAfterImpulse(trialBody,h);
        const auto native=trials.PredictTransform(trialBody,h);double excess=0,translationError=0;
        const auto halfCell=[](float value){return .5*std::max(double(std::nextafter(value,INFINITY))-value,double(value)-std::nextafter(value,-INFINITY));};
        for(unsigned axis=0;axis<3;++axis){const double product=double(velocity[axis])*double(h);const float roundedProduct=velocity[axis]*h;
            const double bound=std::abs(double(roundedProduct)-product)+halfCell(native.position[axis])+std::numeric_limits<double>::epsilon()*std::abs(precise.centerOfMass[axis]);
            const double difference=std::abs(precise.centerOfMass[axis]-double(native.position[axis]));excess=std::max(excess,difference-bound);translationError=std::max(translationError,difference);}
        // A quaternion multiply/add, norm and normalization use fewer than64
        // scalar operations; gamma64 bounds their floating forward error.
        const double unit=.5*std::numeric_limits<float>::epsilon(),gamma=64*unit/(1-64*unit);
        const auto nativeRotation=glm::normalize(glm::dquat(native.rotation));const double orientationError=glm::length(precise.rotation-nativeRotation);
        std::printf("PRECISE_NATIVE_TRAJECTORY origin=%.9g translationError=%.12g boundExcess=%.12g quaternionError=%.12g gamma64=%.12g\n",glm::length(position),translationError,excess,orientationError,gamma);
        return excess<=1e-15&&orientationError<=gamma&&trials.GetTransform(trialBody).position==pose.position&&trials.GetTransform(trialBody).rotation==pose.rotation&&trials.GetLinearVelocity(trialBody)==velocity&&trials.GetAngularVelocity(trialBody)==omega;
    };
    Check(preciseTrajectory({0,0,0}),"precise material trajectory agrees with native publication within actual operation rounding at a nearby origin without mutation");
    Check(preciseTrajectory({0,0,125}),"the same precise trajectory removes far-origin pose quantization while bounding actual native publication error");
    const auto preciseStatic=trials.PredictPreciseTransformAfterImpulse(fixedTrial,dt,candidateLinear,candidateAngular);
    Check(preciseStatic.centerOfMass==glm::dvec3(trials.GetCenterOfMass(fixedTrial))&&preciseStatic.rotation==glm::dquat(trials.GetTransform(fixedTrial).rotation),
        "precise trajectory does not give static geometry an independent motion or impulse");
    bool rejectsInvalidPrecise=false;try{trials.PredictPreciseTransformAfterImpulse(trialBody,INFINITY,{0,0,0},{0,0,0});}catch(const std::invalid_argument&){rejectsInvalidPrecise=true;}
    Check(rejectsInvalidPrecise&&trials.GetTransform(trialBody).position==glm::vec3(0,0,125),
        "invalid precise prediction duration fails without touching authoritative physical state");
    trials.SetLinearVelocity(trialBody,{0,0,0});trials.SetAngularVelocity(trialBody,{0,0,0});
    const auto quietAnchor=trials.GetTransform(trialBody);
    const auto quietPrecise=trials.PredictPreciseTransformAfterImpulse(trialBody,dt);
    Check(quietPrecise.rotation==glm::dquat(quietAnchor.rotation)&&quietPrecise.centerOfMass==glm::dvec3(trials.GetCenterOfMass(trialBody)),
        "precise zero-motion prediction preserves the oblique rounded anchor rather than manufacturing normalization motion");
    const auto smoothDerivative=[&](glm::vec3 spin){
        trials.ResetBody(trialBody,{0,0,125},oblique);trials.SetLinearVelocity(trialBody,{1,-2,3});trials.SetAngularVelocity(trialBody,spin);
        const auto anchor=trials.GetTransform(trialBody);const auto originalV=trials.GetLinearVelocity(trialBody),originalW=trials.GetAngularVelocity(trialBody);
        constexpr double h=1./480,epsilon=1e-7;const glm::dvec3 p(.123,-.321,.081),l(.013,-.032,.014);
        const auto derivative=trials.PredictedSmoothAngularImpulseJacobian(trialBody,h,p,l);double relative=0;
        for(unsigned axis=0;axis<3;++axis){glm::dvec3 perturbation(0);perturbation[axis]=epsilon;
            const auto plus=trials.PredictSmoothTransformAfterImpulse(trialBody,h,p,l+perturbation),minus=trials.PredictSmoothTransformAfterImpulse(trialBody,h,p,l-perturbation);
            auto difference=glm::normalize(plus.rotation*glm::conjugate(glm::normalize(minus.rotation)));if(difference.w<0)difference=-difference;
            const glm::dvec3 imaginary(difference.x,difference.y,difference.z);const double length=glm::length(imaginary);
            const auto finite=length>0?imaginary*(std::atan2(length,difference.w)/(epsilon*length)):glm::dvec3(0);
            relative=std::max(relative,glm::length(finite-derivative[axis])/std::max(1e-12,glm::length(finite)));
        }
        std::printf("SMOOTH_ANGULAR_JACOBIAN speed=%.9g relativeError=%.12g\n",glm::length(spin),relative);
        return relative<1e-5&&trials.GetTransform(trialBody).position==anchor.position&&trials.GetTransform(trialBody).rotation==anchor.rotation&&trials.GetLinearVelocity(trialBody)==originalV&&trials.GetAngularVelocity(trialBody)==originalW;
    };
    Check(smoothDerivative({0,0,0}),"smooth native-law derivative matches independent nonzero candidate momentum at rest without publication");
    Check(smoothDerivative({2,-1,.7f}),"smooth native-law derivative matches anisotropic candidate midpoint motion at ordinary speed");
    Check(smoothDerivative({75,-100,50}),"smooth native-law derivative matches fast anisotropic candidate motion without a small-angle assumption");
    trials.SetLinearVelocity(trialBody,{15,0,0});trials.SetAngularVelocity(trialBody,{0,0,0});
    const glm::dvec3 tinyImpulse(1e-8,0,0);const auto smoothTiny=trials.PredictSmoothTransformAfterImpulse(trialBody,1./480,tinyImpulse);
    glm::vec3 roundedV,roundedW;trials.PredictVelocitiesAfterImpulse(trialBody,glm::vec3(tinyImpulse),{},roundedV,roundedW);
    Check(roundedV.x==15&&smoothTiny.linearVelocity.x>15&&trials.GetLinearVelocity(trialBody).x==15,
        "a sub-ULP candidate impulse remains in smooth root evaluation while the unchanged native float negative control rounds it away");
    const auto smoothStatic=trials.PredictSmoothTransformAfterImpulse(fixedTrial,dt,{1,2,3},{4,5,6});
    Check(smoothStatic.centerOfMass==glm::dvec3(trials.GetCenterOfMass(fixedTrial))&&smoothStatic.linearVelocity==glm::dvec3(0)&&smoothStatic.angularVelocity==glm::dvec3(0)&&trials.PredictedSmoothAngularImpulseJacobian(fixedTrial,dt)==glm::dmat3(0),
        "smooth mathematical trials cannot create static-body motion or degrees of freedom");
    Check(trials.PredictSmoothTransformAfterImpulse({},dt).centerOfMass==glm::dvec3(0)&&trials.PredictedSmoothAngularImpulseJacobian({},dt)==glm::dmat3(0),
        "smooth mathematical trials fail safely for stale native body identities");
    bool rejectsInvalidSmooth=false;try{trials.PredictSmoothTransformAfterImpulse(trialBody,dt,{0,0,NAN});}catch(const std::invalid_argument&){rejectsInvalidSmooth=true;}
    Check(rejectsInvalidSmooth&&trials.GetLinearVelocity(trialBody).x==15,
        "nonfinite smooth trial momentum is rejected without touching physical state");
    trials.ResetBody(trialBody,{0,0,125},oblique);trials.SetLinearVelocity(trialBody,{1,-2,3});trials.SetAngularVelocity(trialBody,{75,-100,50});
    const auto endpointAnchor=trials.GetTransform(trialBody);const auto endpointV=trials.GetLinearVelocity(trialBody),endpointW=trials.GetAngularVelocity(trialBody);
    glm::vec3 endV,endW;const bool endpointAvailable=trials.PredictDynamicEndVelocities(trialBody,1.f/480,endV,endW);
    Check(endpointAvailable&&trials.GetTransform(trialBody).position==endpointAnchor.position&&trials.GetTransform(trialBody).rotation==endpointAnchor.rotation&&trials.GetLinearVelocity(trialBody)==endpointV&&trials.GetAngularVelocity(trialBody)==endpointW,
        "native endpoint motion prediction transports angular momentum without advancing or mutating physical state");
    trials.Step(1.f/480);
    Check(trials.GetLinearVelocity(trialBody)==endV&&trials.GetAngularVelocity(trialBody)==endW,
        "predicted dynamic endpoint velocities match actual anisotropic native advancement bitwise");
    bool invalidEndpoint=false;try{trials.PredictDynamicEndVelocities(trialBody,NAN,endV,endW);}catch(const std::invalid_argument&){invalidEndpoint=true;}
    Check(invalidEndpoint&&!trials.PredictDynamicEndVelocities({},dt,endV,endW)&&endV==glm::vec3(0)&&endW==glm::vec3(0),
        "endpoint motion prediction rejects invalid durations and stale handles without stale outputs");
    std::printf("Coupled physics checks=%u failures=%u\n",checks,failures);return failures?1:0;
}
