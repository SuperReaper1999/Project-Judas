#include "Application.h"
#include "EngineHost.h"
#include "InteractivePlay.h"
#include "RuntimeWorld.h"
#include "SceneSession.h"
#include "WorldStreaming.h"
#include "WorldPersistence.h"
#include "Simulation.h"
#include "SaveService.h"
#include "SaveStorage.h"
#include "SaveArchive.h"
#include "ScreenshotWriter.h"
#include <SDL2/SDL.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <thread>

// New application acceptance contract. The old M83 evidence/tests remain
// independent. Ordinary project inputs drive every demonstrated vehicle.
namespace {
unsigned checks=0,failures=0;
void Check(bool ok,const char* text){++checks;failures+=!ok;std::printf("%s %s\n",ok?"PASS":"FAIL",text);std::fflush(stdout);}
using V=glm::dvec3;
constexpr double nominalMass=571.9529063763489;
double WallEntranceViolation(V point,V halfExtents,const BodyTransform& shapePose){
 // All authored crash walls present their local +Z face to the approaching
 // car. Measure distance beyond that entrance plane, not nearest-surface
 // depth: a corner that crossed the entire wall must remain a failure.
 // GetBodyShape supplies the physical shape's centre, including body pivot
 // offset; the entity transform is not the collision-box centre in general.
 const V local=glm::inverse(glm::normalize(glm::dquat(shapePose.rotation)))*
  (point-V(shapePose.position));
 if(std::abs(local.x)>halfExtents.x||std::abs(local.y)>halfExtents.y)return 0;
 return std::max(0.,halfExtents.z-local.z);
}
void CheckWallEntranceMeasurement(){
 const V extents(2.1,1,.25);BodyTransform pose;
 Check(WallEntranceViolation(V(0,0,.35),extents,pose)==0&&
       WallEntranceViolation(V(0,0,.25),extents,pose)==0,
  "wall entrance measurement accepts clear and exactly touching corners");
 Check(std::abs(WallEntranceViolation(V(0,0,.15),extents,pose)-.10)<1e-12,
  "wall entrance measurement reports known interior penetration");
 Check(std::abs(WallEntranceViolation(V(0,0,-.35),extents,pose)-.60)<1e-12,
  "wall entrance measurement rejects a corner entirely beyond the wall exit");
 Check(WallEntranceViolation(V(2.2,0,-.35),extents,pose)==0&&
       WallEntranceViolation(V(0,1.1,-.35),extents,pose)==0,
  "wall entrance measurement does not invent contact outside the wall footprint");
 pose.rotation=glm::angleAxis(.67f,glm::normalize(glm::vec3(1,2,3)));
 pose.position=glm::vec3(-3,5,2);
 const V beyond=V(pose.position)+glm::normalize(glm::dquat(pose.rotation))*V(0,0,-.35);
 Check(std::abs(WallEntranceViolation(beyond,extents,pose)-.60)<1e-12,
  "wall entrance measurement preserves penetration under arbitrary rotation and translation");
 // The independently known centre is offset from an entity pivot. Feeding
 // that centre is necessary: the entity origin would miss this corner.
 pose.rotation=glm::quat(1,0,0,0);pose.position=glm::vec3(3,2,4);
 Check(std::abs(WallEntranceViolation(V(3,2,3.65),extents,pose)-.60)<1e-12,
  "wall entrance measurement uses the actual collision centre rather than an entity pivot");
}
struct Observation {
 EntityId root=0,material=0,wall=0;
 std::array<EntityId,2> mounts{};
 std::array<EntityId,4> wheels{};
 std::vector<V> initialLocal;
 std::vector<double> initialRest;
 std::array<V,2> initialMount{};
 std::array<double,2> initialSpan{};
 V initialPosition{0};
 double initialMass=0,initialEnergy=0,initialSuppliedWork=0,motorWork=0,brakeWork=0;
 double approachSpeed=0,lastUnimpactedSpeed=0,contactImpulse=0,plasticBefore=0,plasticAtFirstBreak=0;
 double maximumPlastic=0,retainedPlastic=0,retainedAxialShortening=0,maximumExtension=0,energyCreation=0;
 double maximumPenetration=0,wallNodeDepth=0,minimumWheelTravel=1,maximumWheelTravel=0;
 double bumpSpeed=0;bool bumpContact=false;
 std::array<double,2> crush{},maximumCrush{},mountDisplacement{},alignmentDegrees{};
 unsigned contactTick=0,firstPlasticTick=0,firstBreakTick=0,broken=0;
 bool unhealthy=false,released=false,frontCut=false,rearIntact=true;
};
V Group(const DeformableInstance& m,const char* name){
 auto found=m.asset->groups.find(name);if(found==m.asset->groups.end()||found->second.empty())return {};
 V value{0};for(auto n:found->second)value+=m.positions[n];return value/double(found->second.size());
}
double Plastic(const DeformableInstance& m,const Observation& o){
 double value=0;for(size_t i=0;i<m.structure.restLengths.size()&&i<o.initialRest.size();++i)
  value=std::max(value,std::abs(m.structure.restLengths[i]-o.initialRest[i]));
 return value;
}
double AxialShortening(const DeformableInstance& m){
 // Four longitudinal member chains in each of two rails. Rest shortening is
 // invariant under free fragment translation/rotation after a physical cut.
 double total=0;for(size_t i=0;i<m.asset->structure->beams.size();++i){const auto& b=m.asset->structure->beams[i];
  if(b.region==0&&std::abs(b.area-.00012)<1e-12&&b.key.rfind("rail-",0)==0)
   total+=b.restLength-m.structure.restLengths[i];}
 return total/8.;
}
double Mass(RuntimeWorld& world,const Observation& o){
 std::string error;auto* m=world.RuntimeDeformable(o.material,error);double total=m?m->Mass():0;
 for(auto id:{o.root,o.mounts[0],o.mounts[1]})total+=world.Physics().GetMass(world.RuntimeBody(id));
 return total;
}
double Energy(RuntimeWorld& world,const Observation& o){
 std::string error;const auto* m=world.RuntimeDeformable(o.material,error);if(!m)return 0;
 const V up=-V(world.Gravity().Sample(glm::vec3(o.initialPosition)))/9.81;
 double energy=m->structure.ElasticEnergy(*m->asset->structure,m->positions)+m->structure.plasticWork+m->structure.fractureWork+m->structure.dampingWork;
 for(auto id:{o.root,o.mounts[0],o.mounts[1]}){
  const auto body=world.RuntimeBody(id);
  const V v=world.Physics().GetLinearVelocity(body),w=world.Physics().GetAngularVelocity(body);
  energy+=.5*world.Physics().GetMass(body)*glm::dot(v,v)+
   .5*glm::dot(w,glm::dmat3(world.Physics().GetInertiaWorld(body))*w)+
   world.Physics().GetMass(body)*9.81*glm::dot(V(world.Physics().GetCenterOfMass(body)),up);
 }
 for(unsigned n=0;n<m->positions.size();++n)energy+=m->NodeMass(n)*
  (.5*glm::dot(m->velocities[n],m->velocities[n])+9.81*glm::dot(m->positions[n],up));
 if(const auto* train=world.RuntimePowertrain(o.root))for(size_t i=0;i<train->settings.shafts.size();++i)
  if(train->settings.shafts[i].kind==PowertrainShaftKind::Internal)energy+=
   .5*train->settings.shafts[i].inertia*std::pow(train->absoluteSpin[i],2);
 for(unsigned i=0;i<4;++i)if(const auto* wheel=world.RuntimeWheel(o.wheels[i])){
  energy+=.5*wheel->settings.spinInertia*std::pow(wheel->state.angularVelocity,2);
  // The existing wheel spring is unilateral. Its stored compression energy
  // belongs in gross accounting; omitting it mistakes loading/unloading for
  // creation/loss. Bump-stop recovery is not a separate durable spring.
  if(wheel->state.available&&wheel->state.contact){
   const double compression=std::max(0.,double(wheel->settings.restLength-wheel->state.length));
   energy+=.5*wheel->settings.springStiffness*compression*compression;
  }
 }
 return energy;
}
std::string Capture(RuntimeWorld& world,const Observation& o){
 std::string error;auto* m=world.RuntimeDeformable(o.material,error);SaveArchive a;
 a(m->positions,m->velocities,m->structure.restLengths,m->structure.accumulatedPlasticStrain,
   m->structure.broken,m->structure.component,m->structure.plasticWork,m->structure.fractureWork,m->structure.dampingWork,m->released);
 for(auto id:{o.root,o.mounts[0],o.mounts[1]}){
  auto body=world.RuntimeBody(id);auto p=world.Physics().GetTransform(body);
  auto v=world.Physics().GetLinearVelocity(body),w=world.Physics().GetAngularVelocity(body);
  double mass=world.Physics().GetMass(body);a(p.position,p.rotation,v,w,mass);
 }
 for(unsigned i=0;i<4;++i){std::string bytes;WorldPersistence::CaptureWheel(world,o.wheels[i],bytes,error);a(bytes);}
 std::string bytes;WorldPersistence::CapturePowertrain(world,o.root,bytes,error);a(bytes);return a.bytes;
}
void WriteBytes(const std::filesystem::path& path,const std::string& bytes){std::ofstream f(path,std::ios::binary);f.write(bytes.data(),std::streamsize(bytes.size()));}
std::string ReadBytes(const std::filesystem::path& path){std::ifstream f(path,std::ios::binary);return {std::istreambuf_iterator<char>(f),{}};}
std::string NormalizedCook(const DeformableAsset& original){
 auto copy=original;copy.structure=std::make_shared<StructuralCook>(*original.structure);
 // Only source identity/fingerprint and intended strength differences are
 // normalized. Geometry, bracing, density measures, render ownership, E,
 // damping, strain capacities and every other physical field remain exact.
 copy.sourceAsset.clear();copy.sourceFingerprint.clear();
 for(auto& r:copy.structure->regions){r.tensionYield=r.compressionYield=1;
  r.tensionUltimate=r.compressionUltimate=2;r.hardening=0;}
 return EncodeDeformableAsset(copy);
}
std::string MaterialBytes(DeformableMaterial material){SaveArchive a;material.Save(a);return a.bytes;}
Observation AnnexObservation(WorldStreaming& stream,RuntimeWorld& world){
 Observation o;o.root=stream.Resolve("annex",1);o.material=stream.Resolve("annex",21);o.wall=stream.Resolve("annex",5000);
 o.mounts={stream.Resolve("annex",11),stream.Resolve("annex",12)};
 for(unsigned i=0;i<4;++i)o.wheels[i]=stream.Resolve("annex",2+i);
 std::string error;if(auto* m=world.RuntimeDeformable(o.material,error)){
  for(const auto& beam:m->asset->structure->beams)o.initialRest.push_back(beam.restLength);
  o.initialMass=Mass(world,o);
 }return o;
}
bool LocalAnnexReferences(WorldStreaming& stream,RuntimeWorld& world,const Observation& o){
 std::string error;const auto* m=world.RuntimeDeformable(o.material,error);const auto* train=world.RuntimePowertrain(o.root);
 if(!m||!train)return false;
 bool local=stream.Owner(o.root)=="annex"&&stream.Owner(o.material)=="annex";
 for(const auto& a:m->settings.attachments)local&=a.target==o.root||a.target==o.mounts[0]||a.target==o.mounts[1];
 for(auto id:{o.root,o.material,o.mounts[0],o.mounts[1]}){const auto* def=world.RuntimeDefinition(id);
  local&=def&&def->gravitySelection&&def->gravitySelection->source==stream.Resolve("annex",302);}
 for(unsigned i=0;i<4;++i){const auto* wheel=world.RuntimeWheel(o.wheels[i]);local&=wheel&&
  wheel->settings.chassis==(i<2?o.mounts[i]:o.root)&&stream.Owner(o.wheels[i])=="annex";}
 for(unsigned i=0;i<2;++i)local&=train->settings.links[i].connection.owner==o.material;
 return local;
}
struct Costs {std::vector<double> physics,render,frame;};
void ReportCosts(const char* stage,Costs& costs){
 if(costs.physics.empty())return;
 auto numbers=[](std::vector<double>& values){std::sort(values.begin(),values.end());return std::array<double,3>{
  values[values.size()/2],values[size_t(.95*(values.size()-1))],values.back()};};
 auto p=numbers(costs.physics),r=numbers(costs.render),f=numbers(costs.frame);
 std::printf("PERF stage=%s samples=%zu physics_median_ms=%.6f physics_p95_ms=%.6f physics_max_ms=%.6f render_median_ms=%.6f render_p95_ms=%.6f render_max_ms=%.6f frame_median_ms=%.6f frame_p95_ms=%.6f frame_max_ms=%.6f\n",
  stage,costs.physics.size(),p[0],p[1],p[2],r[0],r[1],r[2],f[0],f[1],f[2]);
}
}

int main(int argc,char** argv){
 if(argc<4||argc>6)return 2;
 CheckWallEntranceMeasurement();
 const std::string scene=argv[1],mode=argv[2];
 const std::string scenario=std::filesystem::path(scene).stem().string();
 const bool streaming=mode=="streaming"||mode=="stream-write"||mode=="stream-read";
 const bool streamRead=mode=="stream-read",streamWrite=mode=="stream-write";
 const bool startup=mode=="startup";
 const bool postWrite=mode=="post-write",postRead=mode=="post-read";
 const bool impactWrite=mode=="impact-write"||postWrite,impactRead=mode=="impact-read"||postRead;
 const bool read=mode=="read"||streamRead||impactRead,write=mode=="write"||impactWrite,rest=mode=="rest"||startup,lifecycle=mode=="lifecycle",probe=mode=="probe";
 const double frameDt=argc>=5?std::stod(argv[4]):1./60;
 const bool manualCadence=std::abs(frameDt-1./60)>1e-9;
 const unsigned overrideSubsteps=argc>=6?unsigned(std::stoul(argv[5])):0;
 if(frameDt<=0||frameDt>1./30||overrideSubsteps>16||(manualCadence&&(read||write||lifecycle)))return 2;
 const auto output=std::filesystem::absolute(argv[3]);std::filesystem::create_directories(output);
 std::ofstream trace(output/"structural-trace.csv");trace<<std::setprecision(12)
  <<"tick,root,speed_mps,mass_kg,motor_work_j,brake_work_approx_j,mechanical_plus_dissipated_energy_j,energy_creation_j,plastic_rest_change_m,retained_axial_shortening_m,plastic_work_j,fracture_work_j,damping_work_j,broken_beams,left_crush_m,right_crush_m,left_mount_displacement_m,right_mount_displacement_m,left_alignment_deg,right_alignment_deg,wall_impulse_ns,wall_node_depth_m,attempted_penetration_m,max_intact_length_ratio,front_drive_connected,rear_drive_connected,error\n";
 std::ofstream contactTrace(output/"contacts.csv");contactTrace<<std::setprecision(12)
  <<"tick,root,other,px,py,pz,nx,ny,nz,normal_impulse_ns,attempted_penetration_m,swept,self\n";
 std::ofstream wheelTrace(output/"wheel-trace.csv");wheelTrace<<std::setprecision(12)
  <<"tick,root,wheel,available,contact,length_m,normal_load_n,lateral_impulse_ns,longitudinal_impulse_ns,steering_rad\n";
 std::ofstream memberTrace(output/"startup-members.csv");memberTrace<<std::setprecision(12)
  <<"tick,member,region,geometric_stress_pa,peak_stress_pa,last_constraint_force_stress_pa,plastic_rest_delta_m,broken\n";
 std::vector<Observation> observations;
 unsigned frame=0,ready=0,phase=0,phaseFrame=0,readFailureFrame=0;bool complete=false,frozen=false;
 Window* window=nullptr;RuntimeWorld* original=nullptr;RuntimeWorld* beforeLoad=nullptr;
 std::map<std::string,Costs> costs;auto started=std::chrono::steady_clock::now();
 std::string expectedPhysical;std::vector<EntityId> spawned;std::map<EntityId,V> spawnedPositions;
 uint64_t region=0;Observation annex;std::string retainedAnnex;EntityId previousAnnex=0;
 double streamedWallImpulse=0;unsigned streamedImpactTick=0;
 std::vector<V> specimenInitial;Observation specimenObservation;
 double specimenElastic=0,specimenUnloaded=0,specimenPlasticBefore=0,specimenPlatenImpulse=0;
 unsigned specimenPlasticTick=0,specimenBreakTick=0;
 size_t pausedSteps=0;V pausedPosition{0};bool capturedBefore=false,capturedImpact=false,capturedAfter=false;
 auto key=[&](const char* value,bool down){window->QueueTestPhysical(std::string("key:")+value,down?1.f:0.f);};
 ApplicationControl control;control.hidden=true;control.frameSeconds=[&](float){return frozen||manualCadence?0.f:float(frameDt);};
 control.hostReady=[&](EngineHost& host){window=&host.GetWindow();window->SetTestInputMode(true);SDL_GL_SetSwapInterval(0);
  std::string ignored;host.Audio().Init(ignored,true);};
 control.worldReady=[&](EngineHost&,RuntimeWorld& world,InteractivePlay&){original=&world;};
 control.beforeFrame=[&](EngineHost&,RuntimeWorld& world,InteractivePlay&){
  started=std::chrono::steady_clock::now();
  if(read&&phase==1){key("F8",true);beforeLoad=&world;phase=2;}
  else if(read&&phase==2){key("F8",false);if(&world!=beforeLoad){frozen=true;phase=3;}}
 };
 control.afterFrame=[&](EngineHost& host,RuntimeWorld& world,InteractivePlay& play){
  ++frame;std::string error;double manualPhysicsMs=0;
  if(manualCadence&&!frozen){
   // Sensitivity mode deliberately freezes the normal application's 60 Hz
   // accumulator, then executes exactly one ordinary played-world interval
   // at the requested physical cadence. JS and logical input remain active.
   window->Input().BeginFixedStep();const auto physicalStarted=std::chrono::steady_clock::now();
   StepPlayedWorld(play.Session(),*window,float(frameDt));
   manualPhysicsMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-physicalStarted).count();
  }
  if(scenario=="specimen"){
   auto* m=world.RuntimeDeformable(501,error);
   const bool present=m&&m->Structural()&&world.Physics().IsBodyEnabled(world.RuntimeBody(502))&&
    world.Scripts()&&world.Scripts()->Diagnostics().empty();
   if(!ready&&present){ready=frame;specimenInitial=m->positions;specimenObservation.initialRest=m->structure.restLengths;
    Check(m->settings.selfContact&&m->settings.attachedBodyContact&&world.Physics().IsDynamicBody(world.RuntimeBody(502))&&
      std::abs(world.Physics().GetMass(world.RuntimeBody(502))-20)<1e-8,
      "generic non-vehicle assembly loads a real 20 kg platen, visible guides and live structural collision");
    std::printf("WORKLOAD specimen_nodes=%zu beams=%zu skin_triangles=%zu substeps=%u iterations=%u physical_hz=%.9g\n",
     m->positions.size(),m->asset->structure->beams.size(),m->asset->triangles.size(),m->settings.substeps,m->settings.iterations,1/frameDt);
   }
   if(ready&&present){const unsigned tick=frame-ready;const double time=(double(tick)-90)*frameDt;
    if(tick==90)key("V",true);
    if(tick==91)key("V",false);
    double displacement=0,edgeChange=0;
    for(size_t n=0;n<m->positions.size();++n)displacement=std::max(displacement,glm::length(m->positions[n]-specimenInitial[n]));
    for(size_t b=0;b<m->asset->structure->beams.size();++b)if(!m->structure.broken[b]){
     const auto& beam=m->asset->structure->beams[b];edgeChange=std::max(edgeChange,
      std::abs(glm::length(m->positions[beam.a]-m->positions[beam.b])-beam.restLength));}
    const double plastic=Plastic(*m,specimenObservation);
    if(plastic>1e-7&&!specimenPlasticTick)specimenPlasticTick=tick;
    const auto broken=std::count(m->structure.broken.begin(),m->structure.broken.end(),uint8_t(1));
    if(broken&&!specimenBreakTick)specimenBreakTick=tick;
    if(time>=2&&time<4)specimenElastic=std::max(specimenElastic,edgeChange);
    if(time<8)specimenPlasticBefore=std::max(specimenPlasticBefore,plastic);
    if(time>=6&&time<7)specimenUnloaded=std::max(specimenUnloaded,displacement);
    for(const auto& c:m->contactObservations)if(world.EntityIdOfBody(c.body)==502){
     specimenPlatenImpulse+=c.normalImpulse;
     contactTrace<<tick<<",500,502,"<<c.point.x<<','<<c.point.y<<','<<c.point.z<<','<<c.normal.x<<','<<c.normal.y<<','<<c.normal.z<<','
      <<c.normalImpulse<<','<<c.penetration<<','<<c.swept<<','<<c.self<<'\n';}
    auto& c=costs[time<8?"specimen-load-unload":time<11?"specimen-crush":"specimen-retained"];
    if(tick>60){c.physics.push_back(manualCadence?manualPhysicsMs:play.LastFixedStepMilliseconds());
     c.render.push_back(play.LastSceneMilliseconds());c.frame.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count());}
    if(time>=18){
     std::printf("SPECIMEN elastic_edge_change_m=%.12g unloaded_residual_m=%.12g plastic_before_overload_m=%.12g retained_plastic_m=%.12g retained_intact_edge_change_m=%.12g platen_impulse_ns=%.12g plastic_work_j=%.12g fracture_work_j=%.12g first_plastic_tick=%u first_break_tick=%u broken=%zu material_mass_kg=%.12g\n",
      specimenElastic,specimenUnloaded,specimenPlasticBefore,plastic,edgeChange,specimenPlatenImpulse,m->structure.plasticWork,m->structure.fractureWork,
      specimenPlasticTick,specimenBreakTick,size_t(broken),m->Mass());
     Check(specimenPlatenImpulse>0,"ordinary physical platen contacts carry the non-vehicle specimen's loading impulses");
     Check(specimenElastic>1e-6&&specimenPlasticBefore<1e-7&&specimenUnloaded<=.002,
      "non-vehicle normal physical load elastically deforms then unloads within 2 mm without plastic flow");
     Check(plastic>.005&&edgeChange>.005&&m->structure.plasticWork>0&&m->error.empty(),
      "non-vehicle physical overload leaves actual retained nonrigid geometry and plastic rest change");
     if(broken)Check(specimenPlasticTick&&specimenPlasticTick<specimenBreakTick,
      "non-vehicle physical specimen yields before its ultimate graph failure");
     std::vector<unsigned char> pixels;host.GetRenderer().CaptureFrame(window->Width(),window->Height(),pixels);
     WriteRgbPng((output/"specimen-retained.png").string(),window->Width(),window->Height(),pixels);
     complete=true;world.UI().RequestQuit();
    }
   }
   if(frame>4000){Check(false,"bounded ordinary non-vehicle specimen deadline");world.UI().RequestQuit();}
   std::this_thread::sleep_for(std::chrono::milliseconds(1));return;
  }
  auto* material=world.RuntimeDeformable(920,error);auto* train=world.RuntimePowertrain(900);
  const bool available=material&&material->Structural()&&train&&train->state.available&&
   world.RuntimeWheel(901)&&world.RuntimeWheel(904)&&world.Scripts()&&world.Scripts()->Diagnostics().empty();
  auto capture=[&](const char* filename){std::vector<unsigned char> pixels;
   host.GetRenderer().CaptureFrame(window->Width(),window->Height(),pixels);
   return WriteRgbPng((output/filename).string(),window->Width(),window->Height(),pixels);};
  if(!ready&&available){
   ready=frame;
   for(const auto& definition:world.ScriptObjects(false))if(definition.powertrain&&definition.id<kRuntimeEntityIdBase){
    Observation o;o.root=definition.id;o.material=o.root+20;o.mounts={o.root+10,o.root+11};
    for(unsigned i=0;i<4;++i)o.wheels[i]=o.root+1+i;
    o.wall=5000+(o.root-900)/300;auto* m=world.RuntimeDeformable(o.material,error);
    if(!m||!m->Structural())continue;
    const auto p=world.Physics().GetTransform(world.RuntimeBody(o.root));o.initialPosition=p.position;
    const auto inverse=glm::inverse(glm::dquat(p.rotation));const V forward=glm::dquat(p.rotation)*V(0,0,-1);
    for(auto point:m->positions)o.initialLocal.push_back(inverse*(point-V(p.position)));
    o.initialRest=m->structure.restLengths;o.initialMass=Mass(world,o);o.initialEnergy=Energy(world,o);
    o.initialSuppliedWork=world.RuntimePowertrain(o.root)->suppliedWork;
    for(unsigned side=0;side<2;++side){o.initialMount[side]=inverse*(V(world.Physics().GetTransform(world.RuntimeBody(o.mounts[side])).position)-V(p.position));
     o.initialSpan[side]=glm::dot(Group(*m,side?"tip_right":"tip_left")-Group(*m,side?"rear_right":"rear_left"),forward);}
    if(overrideSubsteps)m->settings.substeps=overrideSubsteps;
    observations.push_back(std::move(o));
   }
   Check(!observations.empty()&&material->asset->nodes.size()==72&&material->asset->structure->beams.size()==307,
    "ordinary project loads the declared locally braced structural graph and collision skin");
   Check(std::all_of(observations.begin(),observations.end(),[](const auto& o){return std::abs(o.initialMass-nominalMass)<1e-4;}),
    "all finite body and derived beam/panel masses account for the declared 571.953 kg car");
   Check(material->settings.selfContact&&material->settings.attachedBodyContact&&material->settings.collisionMask==7&&
    material->settings.attachments.size()==4&&material->asset->groups.at("mount_left").size()==4&&
    material->asset->groups.at("mount_right").size()==4,
    "front suspension uses independent noncollinear graph patches with relevant collision enabled");
   if(observations.size()==3){bool identical=true;
    for(size_t i=1;i<observations.size();++i){auto* other=world.RuntimeDeformable(observations[i].material,error);
     identical&=NormalizedCook(*material->asset)==NormalizedCook(*other->asset)&&
      MaterialBytes(material->settings.material)==MaterialBytes(other->settings.material)&&
      material->settings.substeps==other->settings.substeps&&material->settings.iterations==other->settings.iterations;}
    Check(identical,"strength variants preserve exact cooked topology/render ownership, elastic/damping material, masses and solve quality");
   }
   std::printf("WORKLOAD cars=%zu bodies=%zu dynamic_bodies=%zu nodes_each=%zu beams_each=%zu skin_triangles_each=%zu substeps=%u iterations=%u physical_hz=%.9g manual_cadence=%d source_work=actual_impulse_midpoint_angular_speed brake_work=last_interval_torque_macro_dt_approximate\n",
    observations.size(),world.Physics().AliveBodyCount(),world.Physics().DynamicBodyCount(),material->positions.size(),
    material->asset->structure->beams.size(),material->asset->triangles.size(),material->settings.substeps,material->settings.iterations,1/frameDt,manualCadence);
   if(read){expectedPhysical=ReadBytes(output/(streamRead?"retained-annex.bin":"expected-physical.bin"));phase=1;}
  }
  if(ready&&available&&!read&&!lifecycle&&!streaming&&(!write||phase==0)){
   const unsigned tick=frame-ready;
   bool impact=false,post=false;
   for(auto& o:observations){
    auto* m=world.RuntimeDeformable(o.material,error);auto* t=world.RuntimePowertrain(o.root);
    auto root=world.Physics().GetTransform(world.RuntimeBody(o.root));
    const V forward=glm::dquat(root.rotation)*V(0,0,-1),velocity=world.Physics().GetLinearVelocity(world.RuntimeBody(o.root));
    const double speed=glm::dot(velocity,forward),plastic=Plastic(*m,o);
    o.maximumPlastic=std::max(o.maximumPlastic,plastic);o.retainedPlastic=plastic;o.retainedAxialShortening=AxialShortening(*m);
    if(plastic>1e-7&&!o.firstPlasticTick)o.firstPlasticTick=tick;
    o.broken=unsigned(std::count(m->structure.broken.begin(),m->structure.broken.end(),uint8_t(1)));
    if(o.broken&&!o.firstBreakTick){o.firstBreakTick=tick;o.plasticAtFirstBreak=plastic;}
    double wallImpulse=0;
    for(const auto& contact:m->contactObservations){
     const auto other=world.EntityIdOfBody(contact.body);
     contactTrace<<tick<<','<<o.root<<','<<other<<','<<contact.point.x<<','<<contact.point.y<<','<<contact.point.z<<','
      <<contact.normal.x<<','<<contact.normal.y<<','<<contact.normal.z<<','<<contact.normalImpulse<<','<<contact.penetration<<','<<contact.swept<<','<<contact.self<<'\n';
     if(other==o.wall&&contact.normalImpulse>0){wallImpulse+=contact.normalImpulse;if(!o.contactTick){o.contactTick=tick;o.approachSpeed=o.lastUnimpactedSpeed;}}
    }
    o.contactImpulse+=wallImpulse;
    if(!o.contactTick){o.plasticBefore=std::max(o.plasticBefore,plastic);o.lastUnimpactedSpeed=speed;}
    const auto inv=glm::inverse(glm::dquat(root.rotation));
    for(unsigned side=0;side<2;++side){
     o.crush[side]=o.initialSpan[side]-glm::dot(Group(*m,side?"tip_right":"tip_left")-Group(*m,side?"rear_right":"rear_left"),forward);
     if(m->ConnectedNodes(m->asset->groups.at(side?"rear_right":"rear_left"),m->asset->groups.at(side?"tip_right":"tip_left")))
      o.maximumCrush[side]=std::max(o.maximumCrush[side],o.crush[side]);
     auto mount=world.Physics().GetTransform(world.RuntimeBody(o.mounts[side]));
     o.mountDisplacement[side]=glm::length(inv*(V(mount.position)-V(root.position))-o.initialMount[side]);
     V axle=inv*(glm::dquat(mount.rotation)*V(1,0,0));
     o.alignmentDegrees[side]=std::abs(std::atan2(axle.z,axle.x))*180/3.14159265358979323846;
    }
    for(size_t i=0;i<m->asset->structure->beams.size();++i)if(!m->structure.broken[i]){
     const auto& b=m->asset->structure->beams[i];o.maximumExtension=std::max(o.maximumExtension,
      glm::length(m->positions[b.a]-m->positions[b.b])/b.restLength);
    }
    if(startup)for(size_t i=0;i<m->asset->structure->beams.size();++i){
     const auto& b=m->asset->structure->beams[i];const auto& r=m->asset->structure->regions[b.region];
     const double h=frameDt/m->settings.substeps;
     memberTrace<<tick<<','<<b.key<<','<<r.key<<','<<r.youngModulus*(glm::length(m->positions[b.b]-m->positions[b.a])-m->structure.restLengths[i])/b.restLength<<','
      <<m->structure.stressDemand[i]<<','<<-m->structure.multipliers[i]/(h*h*b.area)<<','<<m->structure.restLengths[i]-b.restLength<<','<<unsigned(m->structure.broken[i])<<'\n';
    }
    o.maximumPenetration=std::max(o.maximumPenetration,m->stats.maximumPenetration);
    // Residual wall-node depth is separate from the contact solver's attempted
    // crossing depth. It uses surviving physical skin corners in wall space.
    if(o.contactTick){Shape shape;BodyTransform shapePose;
     if(world.Physics().GetBodyShape(world.RuntimeBody(o.wall),shape,shapePose))for(unsigned f=0;f<m->asset->triangles.size();++f)if(m->FaceVisible(f))
      for(unsigned k=0;k<3;++k)o.wallNodeDepth=std::max(o.wallNodeDepth,
       WallEntranceViolation(m->positions[m->asset->triangles[f][k]],V(shape.halfExtents),shapePose));
    }
    o.motorWork=t->suppliedWork-o.initialSuppliedWork;
    for(size_t b=0;b<t->settings.brakes.size();++b)o.brakeWork+=std::abs(t->state.brakeTorque[b]*t->state.shafts[t->settings.brakes[b].shaft].angularVelocity)*frameDt;
    const double energy=Energy(world,o);o.energyCreation=std::max(o.energyCreation,energy-o.initialEnergy-o.motorWork);
    o.released|=std::any_of(m->released.begin(),m->released.end(),[](auto r){return r!=0;});
    unsigned front=0,rear=0;
    for(size_t l=0;l<t->settings.links.size();++l){if(l<2){front+=t->state.links[l].connected;
     if(!t->state.links[l].connected){o.frontCut=true;if(t->state.links[l].active||std::abs(t->state.links[l].torque)>1e-8)o.unhealthy=true;}}
     else{rear+=t->state.links[l].connected;o.rearIntact&=t->state.links[l].connected;}}
    o.unhealthy|=!m->error.empty()||m->stats.capacityExceeded;
    for(unsigned i=0;i<4;++i)if(auto* w=world.RuntimeWheel(o.root+1+i)){
     o.minimumWheelTravel=std::min(o.minimumWheelTravel,double(w->state.length));o.maximumWheelTravel=std::max(o.maximumWheelTravel,double(w->state.length));
     const auto support=world.EntityIdOfBody(w->state.body);
     if(scenario=="normal"&&w->state.contact&&w->state.normalForce>0&&support>=1600&&support<1608&&!o.bumpContact){
      o.bumpContact=true;o.bumpSpeed=speed;
     }
     wheelTrace<<tick<<','<<o.root<<','<<o.root+1+i<<','<<w->state.available<<','<<w->state.contact<<','<<w->state.length<<','<<w->state.normalForce<<','
      <<w->state.lateralImpulse<<','<<w->state.longitudinalImpulse<<','<<w->command.steeringAngle<<'\n';}
    trace<<tick<<','<<o.root<<','<<speed<<','<<Mass(world,o)<<','<<o.motorWork<<','<<o.brakeWork<<','<<energy<<','<<o.energyCreation<<','<<plastic<<','<<o.retainedAxialShortening<<','
     <<m->structure.plasticWork<<','<<m->structure.fractureWork<<','<<m->structure.dampingWork<<','<<o.broken<<','<<o.crush[0]<<','<<o.crush[1]<<','<<o.mountDisplacement[0]<<','<<o.mountDisplacement[1]<<','
     <<o.alignmentDegrees[0]<<','<<o.alignmentDegrees[1]<<','<<wallImpulse<<','<<o.wallNodeDepth<<','<<m->stats.maximumPenetration<<','<<o.maximumExtension<<','<<front<<','<<rear<<','<<m->error<<'\n';
    impact|=o.contactTick&&tick-o.contactTick<120;post|=o.contactTick&&tick-o.contactTick>=120;
   }
   if(tick>(startup?0:60)){auto& c=costs[impact?"impact":post?"post-crash":"normal"];
    c.physics.push_back(manualCadence?manualPhysicsMs:play.LastFixedStepMilliseconds());c.render.push_back(play.LastSceneMilliseconds());
    c.frame.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count());}
   if(tick==90&&!rest){key("V",true);}
   if(tick==91)key("V",false);
   if(!capturedBefore&&tick>180&&!observations[0].contactTick)capturedBefore=capture("before.png");
   if(!capturedImpact&&observations[0].contactTick&&tick==observations[0].contactTick+2)capturedImpact=capture("impact.png");
   const unsigned endTick=postWrite?2100:impactWrite?1800:startup?20:unsigned(std::ceil((rest?20:46)/frameDt));
   if(tick==endTick){
    capturedAfter=capture("after.png");
    Check(available&&std::none_of(observations.begin(),observations.end(),[](const auto& o){return o.unhealthy||o.released;}),
     "structural driving/crash completes without solve failure or scripted attachment release");
    for(auto& o:observations){auto* m=world.RuntimeDeformable(o.material,error);
     std::printf("STRUCTURAL root=%llu speed_mps=%.9g mass_kg=%.12g contact_tick=%u first_plastic_tick=%u first_break_tick=%u broken=%u wall_impulse_ns=%.9g plastic_before_m=%.9g plastic_retained_m=%.9g retained_axial_shortening_m=%.9g left_crush_m=%.9g right_crush_m=%.9g maximum_left_crush_m=%.9g maximum_right_crush_m=%.9g left_mount_m=%.9g right_mount_m=%.9g left_alignment_deg=%.9g right_alignment_deg=%.9g motor_work_j=%.9g brake_work_approx_j=%.9g plastic_work_j=%.9g fracture_work_j=%.9g damping_work_j=%.9g energy_creation_j=%.9g wall_node_depth_m=%.9g attempted_penetration_m=%.9g intact_extension_ratio=%.9g front_cut=%d rear_intact=%d\n",
      static_cast<unsigned long long>(o.root),o.approachSpeed,Mass(world,o),o.contactTick,o.firstPlasticTick,o.firstBreakTick,o.broken,o.contactImpulse,o.plasticBefore,o.retainedPlastic,
      o.retainedAxialShortening,o.crush[0],o.crush[1],o.maximumCrush[0],o.maximumCrush[1],o.mountDisplacement[0],o.mountDisplacement[1],o.alignmentDegrees[0],o.alignmentDegrees[1],
      o.motorWork,o.brakeWork,m->structure.plasticWork,m->structure.fractureWork,m->structure.dampingWork,o.energyCreation,o.wallNodeDepth,o.maximumPenetration,o.maximumExtension,o.frontCut,o.rearIntact);
     std::printf("COMPATIBILITY root=%llu last_linear_iterations=%u last_linear_residual=%.12g actual_pin_drift_m=%.12g\n",
      static_cast<unsigned long long>(o.root),m->structure.linearIterations,m->structure.linearResidual,m->structure.maximumPinDrift);
     Check(std::abs(Mass(world,o)-o.initialMass)<1e-6,"deformation and disconnection retain all accounted finite mass");
     Check(o.maximumExtension<1.15,"intact members remain bounded against unintended rope-like elongation");
     Check(o.energyCreation<std::max(2000.,o.motorWork*.10),"gross mechanical plus plastic energy does not grow beyond the measured driver work budget");
    }
    const auto& o=observations[0];const double retained=.5*(o.crush[0]+o.crush[1]);
    if(rest||scenario=="normal"){
     Check(!o.contactTick&&o.maximumPlastic<1e-7&&!o.broken&&!o.frontCut,
      "ordinary load/acceleration/braking/steering produces no permanent structural damage");
     if(!rest){Check(std::max(o.mountDisplacement[0],o.mountDisplacement[1])<=.002,
      "ordinary load/unload returns actual wheel mount geometry within the declared 2 mm residual");
      Check(o.maximumWheelTravel-o.minimumWheelTravel>.04&&o.brakeWork>100,
       "ordinary driving exercises real suspension travel and mechanical braking");}
     if(!rest){std::printf("BUMP actual_contact=%d speed_mps=%.9g\n",o.bumpContact,o.bumpSpeed);
      Check(o.bumpContact&&std::abs(o.bumpSpeed-5)<=1,
       "ordinary 5 m/s driving actually loads the authored 80 mm bump through tyre collision geometry");}
    }else if(!probe&&!impactWrite){
     double target=scenario=="low"?5:scenario=="high"?25:15;
     double tolerance=scenario=="low"?.5:scenario=="high"?1:.75;
     Check(o.contactTick&&o.contactImpulse>0&&std::abs(o.approachSpeed-target)<=tolerance,
      "actual deforming collision skin receives the declared road-speed frontal/corner impact");
     Check(o.wallNodeDepth<.03,"surviving physical skin corners have less than 30 mm residual wall penetration");
     if(scenario=="low")Check(retained>=-.005&&retained<=.05&&!o.frontCut,
      "5 m/s encounter retains limited front damage and intact mechanical drive paths");
     if(scenario=="medium"||scenario=="rotated")Check(retained>=.10&&retained<=.35&&o.retainedPlastic>.005&&
      material->ConnectedNodes(material->asset->groups.at("rear_left"),material->asset->groups.at("tip_left"))&&
      material->ConnectedNodes(material->asset->groups.at("rear_right"),material->asset->groups.at("tip_right")),
      "15 m/s encounter retains the declared 100–350 mm local front crush");
     if(scenario=="high")Check(o.retainedAxialShortening>=.25&&o.retainedAxialShortening<=.65&&o.frontCut&&o.broken&&o.firstPlasticTick<o.firstBreakTick,
      "25 m/s encounter progressively yields then breaks a real mechanical path with 250–650 mm retained crush");
     if(scenario=="offset")Check(o.crush[0]-o.crush[1]>=.05&&
      (o.mountDisplacement[0]>=.02||o.alignmentDegrees[0]>=2),
      "offset impact creates asymmetric local crush and actual displaced/rotated wheel mounting geometry");
     if(o.broken)Check(o.plasticAtFirstBreak>.005&&o.firstPlasticTick>=o.contactTick&&o.firstPlasticTick<o.firstBreakTick,
      "local retained yielding precedes ultimate structural failure under actual wall loading");
     if(observations.size()==3&&scenario=="comparison")Check(
      observations[1].retainedPlastic>observations[2].retainedPlastic+.0001||observations[1].broken>observations[2].broken,
      "same geometry/mass/input stronger and weaker authored structural regions change physical deformation/failure");
    }
    if(write){frozen=true;expectedPhysical=Capture(world,observations[0]);WriteBytes(output/"expected-physical.bin",expectedPhysical);
     key("F5",true);phase=1;phaseFrame=frame;}
    else{complete=true;world.UI().RequestQuit();}
   }
  }
  if(write&&phase==1&&frame==phaseFrame+1){key("F5",false);phase=2;}
  if(write&&phase==2){auto* service=world.SceneControl()->Saves(host.Resources());
    for(uint64_t id=1;id<12;++id)if(const auto* status=service->Status(id);status&&status->operation=="save"){
     if(status->state=="completed"){Check(true,"ordinary save commits the actual deformed graph, bodies, wheels and drivetrain");complete=true;world.UI().RequestQuit();}
     if(status->state=="failed"){Check(false,"ordinary structural save completes");complete=true;world.UI().RequestQuit();}}
  }
  if(read&&!streamRead&&ready&&phase==3){
   Check(&world!=original&&play.FixedStepsSinceReset()==0,"fresh process observes the loaded physical endpoint before solver continuation");
   Check(!expectedPhysical.empty()&&Capture(world,observations[0])==expectedPhysical,
    "cold load exactly retains structural positions/velocities/plasticity/failures, body mass/poses and mechanical state");
   capture("cold-restored.png");frozen=false;key("W",true);phase=4;phaseFrame=frame;
  }
  if(read&&!streamRead&&phase==4&&frame>phaseFrame){const bool healthy=material&&material->error.empty();
   if(healthy||!readFailureFrame){auto& c=costs[healthy?"cold-continuation-healthy":"cold-continuation-failed-step"];
    c.physics.push_back(play.LastFixedStepMilliseconds());c.render.push_back(play.LastSceneMilliseconds());
    c.frame.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count());}
   if(!healthy&&!readFailureFrame){readFailureFrame=frame-phaseFrame;std::printf("COLD_CONTINUATION_FAILURE frame=%u numerical_round=%u error=%s\n",readFailureFrame,material?material->StructuralDiagnosticRound():0,material?material->error.c_str():"missing material");}}
  if(read&&!streamRead&&phase==4&&frame==phaseFrame+(postRead?120:impactRead?30:60)){key("W",false);
   Check(play.FixedStepsSinceReset()>0&&material->error.empty()&&Mass(world,observations[0])==observations[0].initialMass,
    "cold restored damaged vehicle resumes actual driver, material, collision and mechanical stepping");
   if(impactRead){auto* resumed=world.RuntimeDeformable(observations[0].material,error);
    std::printf("IMPACT_DIAGNOSTIC broken=%zu plasticWork=%.12g fractureWork=%.12g maxPinDrift=%.12g error=%s\n",
     std::count(resumed->structure.broken.begin(),resumed->structure.broken.end(),uint8_t(1)),resumed->structure.plasticWork,resumed->structure.fractureWork,resumed->structure.maximumPinDrift,resumed->error.c_str());
   }
   complete=true;world.UI().RequestQuit();
  }
  if(streaming&&ready){
   auto* stream=world.SceneControl()->Streaming(world,error);
   if(!stream){std::printf("STREAM ERROR %s\n",error.c_str());Check(false,"project provides its registered structural annex");complete=true;world.UI().RequestQuit();return;}
   const unsigned tick=frame-ready;
   if(!streamRead&&phase==0&&tick>=90){region=stream->Request("annex",false,error);phase=1;phaseFrame=frame;}
   if(streamRead&&phase==3){
    Check(&world!=original&&play.FixedStepsSinceReset()==0,"fresh process loads the suspended structural region before physical continuation");
    retainedAnnex=expectedPhysical;region=stream->Request("annex",false,error);phase=5;
   }
   auto status=region?stream->Status(region):std::optional<RegionStatus>{};
   if(!streamRead&&phase==1&&status&&status->state=="active"){
    annex=AnnexObservation(*stream,world);auto* m=world.RuntimeDeformable(annex.material,error);
    if(m&&world.RuntimePowertrain(annex.root)&&world.RuntimeWheel(annex.wheels[3])){
     Check(LocalAnnexReferences(*stream,world,annex),"streamed car owns all material, gravity, mount, wheel and transmission dependencies inside its registered region");
     key("Tab",true);phase=2;phaseFrame=frame;
    }
   }
   if(!streamRead&&phase==2){
    if(frame==phaseFrame+1){key("Tab",false);key("W",true);}
    auto* m=world.RuntimeDeformable(annex.material,error);auto* t=world.RuntimePowertrain(annex.root);
    if(m&&t){
     for(const auto& c:m->contactObservations)if(world.EntityIdOfBody(c.body)==annex.wall&&c.normalImpulse>0){
      streamedWallImpulse+=c.normalImpulse;if(!streamedImpactTick)streamedImpactTick=tick;}
     bool cut=false;for(unsigned i=0;i<2;++i)cut|=!world.PowertrainConnectionIntact(t->settings.links[i].connection);
     if((cut&&Plastic(*m,annex)>.005)||(frame-phaseFrame)>2400){
      Check(streamedWallImpulse>0&&Plastic(*m,annex)>.005&&std::any_of(m->structure.broken.begin(),m->structure.broken.end(),[](auto b){return b!=0;})&&cut,
       "ordinary driving into the annex wall genuinely deforms and breaks a streamed physical/mechanical load path before retention");
      key("W",false);key("Space",true);phase=3;phaseFrame=frame;
     }
    }
   }
   if(!streamRead&&phase==3&&frame-phaseFrame>=120){
    frozen=true;retainedAnnex=Capture(world,annex);WriteBytes(output/"retained-annex.bin",retainedAnnex);
    previousAnnex=annex.root;key("Space",false);stream->Release(region);phase=4;
   }
   if(!streamRead&&phase==4&&status&&status->state=="unloaded"){
    Check(!world.RuntimeDefinition(previousAnnex)&&status->retained>0&&
     !world.RuntimeDefinition(annex.material)&&!world.RuntimeDefinition(annex.mounts[0])&&!world.RuntimeDefinition(annex.mounts[1]),
     "ordinary region suspension retires physical identities and accounts retained deformation without ownership escape");
    if(streamWrite){key("F5",true);phase=20;phaseFrame=frame;}
    else{region=stream->Request("annex",false,error);phase=5;}
   }
   if(phase==5&&status&&status->state=="active"){
    auto restored=AnnexObservation(*stream,world);auto* m=world.RuntimeDeformable(restored.material,error);auto* t=world.RuntimePowertrain(restored.root);
    if(m&&t){
     Check((streamRead||restored.root!=previousAnnex)&&!retainedAnnex.empty()&&Capture(world,restored)==retainedAnnex,
      "cold region re-publication exactly retains graph plasticity/failures, body poses/mass, wheel spin and drivetrain commands under remapped identities");
     bool cut=false;for(unsigned i=0;i<2;++i)cut|=!world.PowertrainConnectionIntact(t->settings.links[i].connection);
     Check(LocalAnnexReferences(*stream,world,restored)&&cut,
      "restored structural references point to the new local physical endpoints and retain disconnected torque paths");
     annex=restored;frozen=false;if(streamRead)key("Tab",true);key("W",true);phase=6;phaseFrame=frame;
    }
   }
   if(phase==6&&frame==phaseFrame+1)key("Tab",false);
   if(phase==6&&frame-phaseFrame>=60){key("W",false);auto* m=world.RuntimeDeformable(annex.material,error);auto* t=world.RuntimePowertrain(annex.root);
    bool disabled=false;for(unsigned i=0;i<2;++i)if(!world.PowertrainConnectionIntact(t->settings.links[i].connection))
     disabled|=!t->state.links[i].active&&!t->state.links[i].connected&&std::abs(t->state.links[i].torque)<1e-8&&t->command.links[i].enabled;
    Check(m&&m->error.empty()&&disabled&&std::abs(Mass(world,annex)-nominalMass)<1e-4,
     "revisited damaged car continues real stepping while broken mechanical paths transmit zero torque with commands enabled");
    complete=true;world.UI().RequestQuit();
   }
   if(phase==20&&frame==phaseFrame+1){key("F5",false);phase=21;}
   if(phase==21){auto* service=world.SceneControl()->Saves(host.Resources());for(uint64_t id=1;id<12;++id)
    if(const auto* s=service->Status(id);s&&s->operation=="save"&&(s->state=="completed"||s->state=="failed")){
     Check(s->state=="completed","ordinary save commits a suspended damaged structural region for a fresh-process revisit");complete=true;world.UI().RequestQuit();}}
   if(status&&status->state=="failed"){std::printf("STREAM ERROR %s\n",status->error.c_str());Check(false,"bounded ordinary structural region publication");complete=true;world.UI().RequestQuit();}
  }
  if(lifecycle&&ready){
   const unsigned tick=frame-ready;
   if(tick==90||tick==150)key("P",true);
   if(tick==91||tick==151)key("P",false);
   if(tick==240){
    for(const auto& def:world.ScriptObjects(false))if(def.id>=kRuntimeEntityIdBase&&def.powertrain)spawned.push_back(def.id);
    bool intact=spawned.size()==2;for(auto root:spawned){auto* t=world.RuntimePowertrain(root);const auto owner=t->settings.links[0].connection.owner;
     auto* m=world.RuntimeDeformable(owner,error);intact&=m&&m->Structural()&&m->structure.broken.empty()==false&&
      std::none_of(m->structure.broken.begin(),m->structure.broken.end(),[](auto b){return b!=0;})&&
      world.PowertrainConnectionIntact(t->settings.links[0].connection);spawnedPositions[root]=world.Physics().GetTransform(world.RuntimeBody(root)).position;}
    Check(intact,"two ordinary prefab instances construct independently remapped intact structural/mechanical assemblies");key("W",true);
   }
   if(tick==360){key("W",false);unsigned moved=0;for(auto root:spawned)moved+=glm::length(V(world.Physics().GetTransform(world.RuntimeBody(root)).position)-spawnedPositions[root])>.2;
    Check(moved==1,"manual driving operates the selected prefab while other assemblies remain braked");key("Escape",true);}
   if(tick==361){key("Escape",false);pausedSteps=play.FixedStepsSinceReset();pausedPosition=world.Physics().GetTransform(world.RuntimeBody(900)).position;}
   if(tick==400){Check(play.IsPaused()&&play.FixedStepsSinceReset()==pausedSteps&&
      V(world.Physics().GetTransform(world.RuntimeBody(900)).position)==pausedPosition,"ordinary pause freezes the actual physical clock and endpoint");key("Escape",true);}
   if(tick==401)key("Escape",false);
   if(tick==430){Check(!play.IsPaused()&&play.FixedStepsSinceReset()>pausedSteps,"ordinary resume restores physical stepping");
    beforeLoad=&world;key("R",true);phase=5;}
   if(tick==431)key("R",false);
   if(phase==5&&&world!=beforeLoad){bool retired=true;for(auto root:spawned)retired&=!world.RuntimeDefinition(root);
    Check(retired&&material&&material->Structural()&&material->structure.revision==1,
     "ordinary reload retires prefab physics and reconstructs the intact authored graph");complete=true;world.UI().RequestQuit();}
  }
  std::this_thread::sleep_for(std::chrono::milliseconds(1));
  if(frame>unsigned(std::ceil(70/frameDt))+200){Check(false,"bounded structural application deadline");world.UI().RequestQuit();}
 };
 Application application;std::string argument=scene;char name[]="judas";char* arguments[]={name,argument.data()};
 Check(application.Run(2,arguments,&control)==0&&complete,"ordinary structural crash project starts and shuts down normally");
 for(auto& [stage,c]:costs)ReportCosts(stage.c_str(),c);
 std::printf("M83 structural application scenario=%s mode=%s checks=%u failures=%u\n",scenario.c_str(),mode.c_str(),checks,failures);
 return failures?1:0;
}
