#include "Deformable.h"
#include "UniformGravity.h"
#include "CollisionGeometry.h"
#include "Narrowphase.h"
#include "PhysicsCastGeometry.h"
#include "StructuralContactGeometry.h"
#include <algorithm>
#include <array>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <glm/gtc/matrix_transform.hpp>
namespace {
int checks=0,failures=0;
void check(bool pass,const char* label){++checks;failures+=!pass;std::printf("%s %s\n",pass?"PASS":"FAIL",label);}
using V=glm::dvec3;
std::shared_ptr<DeformableAsset> panels(std::string& error){
    auto a=std::make_shared<DeformableAsset>();a->kind=DeformableKind::Structure;a->structure=std::make_shared<StructuralCook>();
    a->nodes={{0,0,0},{1,0,0},{0,1,0},{1.2,0,0},{2.2,0,0},{1.2,1,0}};
    StructuralRegion material;material.key="panel";material.youngModulus=100;material.damping=0;material.tensionYield=1e9;material.compressionYield=1e9;material.tensionUltimate=1e10;material.compressionUltimate=1e10;
    a->structure->regions={material};
    auto beam=[&](unsigned x,unsigned y){StructuralBeam b;b.key="member-"+std::to_string(a->structure->beams.size());b.a=x;b.b=y;b.area=.01;a->structure->beams.push_back(b);};
    beam(0,1);beam(1,2);beam(2,0);beam(3,4);beam(4,5);beam(5,3);beam(1,3);
    a->triangles={{0,1,2},{3,4,5},{1,3,5}};a->structure->surfaceRegions={0,0,0};a->structure->surfaceSupports={{0,1,2},{3,4,5},{6}};
    // Two local skins plus an explicitly owned join. UV-seam vertices are
    // duplicated deliberately; mapping never guesses ownership from position.
    for(unsigned face=0;face<a->triangles.size();++face)for(unsigned n:{a->triangles[face].x,a->triangles[face].y,a->triangles[face].z}){
        MeshVertex vertex;vertex.position=glm::vec3(a->nodes[n]);vertex.uv={float(n%2),float(n/2)};
        a->render.indices.push_back(unsigned(a->render.vertices.size()));a->render.vertices.push_back(vertex);
        DeformableBinding binding;binding.nodes=glm::uvec4(n);a->binding.push_back(binding);
    }
    a->render.primitives={{0,6,0},{6,3,1}};a->structure->renderSurfaces={0,1,2};
    if(!PrepareDeformableAsset(*a,error))return {};
    return a;
}
V positionMomentum(const DeformableInstance& s,const std::vector<V>& before){V total(0);for(unsigned n=0;n<before.size();++n)total+=(s.positions[n]-before[n])*s.NodeMass(n);return total;}
}
int main(){
    // Independent differentiations of the actual finite geometry. A frozen
    // contact tangent would pass a planar example but fails these curved
    // edge/corner controls, so this checks the mechanism rather than a symbol.
    const auto geometryDerivative=[&](const Shape& shape,V local,const char* label){
        bool valid=true;double maximum=0;
        for(bool rotated:{false,true}){
            RigidBody body;body.position=rotated?glm::vec3(125,-37,91):glm::vec3(0);
            body.orientation=rotated?glm::angleAxis(.73f,glm::normalize(glm::vec3(1,2,3))):glm::quat(1,0,0,0);
            const auto primitive=PrimitiveAt(shape,body,0);const auto rotation=PrimitiveRotation(primitive);
            const V point=PrimitiveCenter(primitive)+rotation*local;
            const auto value=EvaluateStructuralContactGeometry(point,primitive);valid&=value.valid;
            if(!value.valid)continue;
            for(unsigned axis=0;axis<3;++axis){V direction(0);direction[axis]=1;constexpr double epsilon=1e-6;
                const auto plus=EvaluateStructuralContactGeometry(point+epsilon*direction,primitive),minus=EvaluateStructuralContactGeometry(point-epsilon*direction,primitive);
                valid&=plus.valid&&minus.valid;if(!plus.valid||!minus.valid)continue;
                maximum=std::max(maximum,glm::length((plus.normal-minus.normal)/(2*epsilon)-value.dNormal*direction));
                maximum=std::max(maximum,glm::length((plus.point-minus.point)/(2*epsilon)-value.dPoint*direction));
                maximum=std::max(maximum,std::abs((plus.signedDistance-minus.signedDistance)/(2*epsilon)-glm::dot(value.normal,direction)));
            }
        }
        std::printf("FINITE_GEOMETRY_DERIVATIVE %s maximum=%.17g valid=%d\n",label,maximum,int(valid));
        check(valid&&maximum<2e-6,label);
    };
    geometryDerivative(Shape::Box({1,2,3}),V(1.2,.3,.4),"finite box face derivative agrees with actual geometry in origin and rotated displaced frames");
    geometryDerivative(Shape::Box({1,2,3}),V(1.2,2.3,.4),"finite rounded box edge curvature agrees with actual geometry");
    geometryDerivative(Shape::Box({1,2,3}),V(1.2,2.3,3.4),"finite rounded box corner curvature agrees with actual geometry");
    geometryDerivative(Shape::Box({1,2,3}),V(.8,.3,.4),"box interior nearest-face signed distance preserves the existing geometric branch");
    geometryDerivative(Shape::Sphere(1),V(1.2,.3,.4),"sphere exterior distance and surface witness derivatives agree");
    geometryDerivative(Shape::Sphere(1),V(.4,.3,.2),"sphere interior signed distance and surface witness derivatives agree");
    geometryDerivative(Shape::Capsule(.5f,1),V(.8,.3,.4),"capsule shaft curvature agrees with actual geometry");
    geometryDerivative(Shape::Capsule(.5f,1),V(.4,1.7,.2),"capsule cap curvature agrees with actual geometry");
    {
        RigidBody body;
        check(!EvaluateStructuralContactGeometry(V(0),PrimitiveAt(Shape::Sphere(1),body,0)).valid,"singular sphere centre does not invent a unique normal derivative");
        check(!EvaluateStructuralContactGeometry(V(0),PrimitiveAt(Shape::Capsule(.5f,1),body,0)).valid,"singular capsule axis does not invent a unique normal derivative");
    }
    const auto pathDerivative=[&](const Shape& shape,V a,V b,const char* label){
        bool valid=true;double maximum=0;
        for(bool rotated:{false,true}){RigidBody body;body.position=rotated?glm::vec3(125,-37,91):glm::vec3(0);
            body.orientation=rotated?glm::angleAxis(.73f,glm::normalize(glm::vec3(1,2,3))):glm::quat(1,0,0,0);
            const auto primitive=PrimitiveAt(shape,body,0);const auto rotation=PrimitiveRotation(primitive);
            const V start=PrimitiveCenter(primitive)+rotation*a,end=PrimitiveCenter(primitive)+rotation*b;
            const auto value=EvaluateStructuralContactPathGeometry(start,end,primitive);valid&=value.valid&&value.fraction>0&&value.fraction<1;
            if(!value.valid)continue;
            for(unsigned axis=0;axis<3;++axis){V direction(0);direction[axis]=1;constexpr double epsilon=1e-6;
                const auto plus=EvaluateStructuralContactPathGeometry(start,end+epsilon*direction,primitive),minus=EvaluateStructuralContactPathGeometry(start,end-epsilon*direction,primitive);
                valid&=plus.valid&&minus.valid;if(!plus.valid||!minus.valid)continue;
                maximum=std::max(maximum,glm::length((plus.normal-minus.normal)/(2*epsilon)-value.dNormal*direction));
                maximum=std::max(maximum,glm::length((plus.point-minus.point)/(2*epsilon)-value.dPoint*direction));
                maximum=std::max(maximum,std::abs((plus.signedDistance-minus.signedDistance)/(2*epsilon)-glm::dot(value.gradient,direction)));
                maximum=std::max(maximum,std::abs((plus.fraction-minus.fraction)/(2*epsilon)-glm::dot(value.fractionGradient,direction)));
            }
        }
        std::printf("FINITE_PATH_DERIVATIVE %s maximum=%.17g valid=%d\n",label,maximum,int(valid));check(valid&&maximum<2e-6,label);
    };
    pathDerivative(Shape::Box({1,2,3}),V(1.2,2.8,0),V(1.7,2.1,.2),"whole-path box edge distance and curvature derivatives agree in rotated displaced frames");
    pathDerivative(Shape::Sphere(1),V(-2,1.3,.4),V(2,1.5,.6),"whole-path sphere distance and curvature derivatives agree");
    pathDerivative(Shape::Capsule(.5f,1),V(-1,.2,.8),V(1,.5,.6),"whole-path capsule shaft distance and curvature derivatives agree");
    {
        bool crossing=true,clear=true,intersection=true;
        for(bool rotated:{false,true}){RigidBody body;body.position=rotated?glm::vec3(125,-37,91):glm::vec3(0);
            body.orientation=rotated?glm::angleAxis(.73f,glm::normalize(glm::vec3(1,2,3))):glm::quat(1,0,0,0);
            const auto primitive=PrimitiveAt(Shape::Box({1,1,1}),body,0);const auto rotation=PrimitiveRotation(primitive);const auto world=[&](V p){return PrimitiveCenter(primitive)+rotation*p;};
            const V start=world(V(1.02,0,.999)),end=world(V(.999,0,1.02));
            const auto point=EvaluateStructuralContactGeometry(end,primitive);
            const auto path=EvaluateStructuralContactPathGeometry(start,end,primitive);
            crossing&=point.valid&&path.valid&&point.signedDistance>.015&&path.signedDistance<.015&&path.fraction>0&&path.fraction<1;
            const auto miss=EvaluateStructuralContactPathGeometry(world(V(1.04,0,.999)),world(V(.999,0,1.04)),primitive);clear&=miss.valid&&miss.signedDistance>.015;
            intersection&=!EvaluateStructuralContactPathGeometry(world(V(0,0,2)),world(V(0,0,-2)),primitive).valid;
        }
        check(crossing,"clear endpoint cannot hide actual oblique corner skin crossing, including rotated geometry");
        check(clear,"genuine finite corner path escape remains clear");
        check(intersection,"solid-crossing path requires the acquired recovery constraint instead of pretending clearance");
    }
    std::string error;PhysicsWorld physics;physics.Init();UniformGravity zero({0,0,0});
    DeformableSettings cfg;cfg.material.damping=0;cfg.material.friction=0;cfg.material.thickness=.015;cfg.substeps=1;cfg.iterations=1;
    auto fracture=std::make_shared<DeformableAsset>(MakeFractureBlock({1,1,4},{.2,.2,2},false));
    DeformableInstance intact;intact.Initialize(fracture,cfg,glm::dmat4(1),1);auto original=intact.positions;
    DeformableInstance::SurfaceContacts(intact,intact,1./60);
    check(intact.positions==original&&intact.stats.contacts==0,"intact duplicated fracture seams do not repel or inject motion");
    DeformableInstance folded;folded.Initialize(fracture,cfg,glm::dmat4(1),2);
    for(auto n:fracture->fracture->parts.back().nodes)folded.positions[n]+=V(.01,.01,-1.45);
    auto before=folded.positions;DeformableInstance::SurfaceContacts(folded,folded,1./60);
    check(folded.stats.contacts>0&&folded.positions!=before,"nonadjacent connected fracture cells collide during a fold");
    check(glm::length(positionMomentum(folded,before))<1e-10,"self-contact projections preserve mass-weighted position momentum");
    check(!folded.contactObservations.empty()&&folded.contactObservations.size()<=256,"bounded contact observations retain actual surface normals");
    // Break after building the pair cache. Previously excluded seam pairs must
    // become eligible even when the particles have not moved at all.
    intact.fracture.pending[0]=1;intact.fracture.Commit(*fracture->fracture);before=intact.positions;
    DeformableInstance::SurfaceContacts(intact,intact,1./60);
    check(intact.stats.contacts>0&&intact.positions!=before,"fracture revision invalidates seam exclusions for newly detached contact");

    auto skin=panels(error);check(bool(skin),("authored local skin fixture prepares: "+error).c_str());
    if(skin){
        DeformableInstance mapped;mapped.Initialize(skin,cfg,glm::dmat4(1),3);MeshData view;mapped.MapRender(1,view);
        check(view.indices.size()==9&&view.primitives.size()==2,"intact mapped bodywork preserves authored triangles and material groups");
        mapped.structure.pending[6]=1;mapped.structure.Commit(*skin->structure);
        for(unsigned n:{3u,4u,5u})mapped.positions[n]+=V(0,0,3);
        mapped.previous=mapped.positions;mapped.MapRender(1,view);
        double longest=0;for(unsigned i=0;i<view.indices.size();i+=3)for(unsigned k=0;k<3;++k)longest=std::max(longest,double(glm::length(view.vertices[view.indices[i+k]].position-view.vertices[view.indices[i+(k+1)%3]].position)));
        check(view.indices.size()==6&&longest<1.5,"broken join disappears without a triangle spanning the detached gap");
        check(std::abs(view.vertices[3].position.z-3)<1e-6&&std::abs(view.vertices[0].position.z)<1e-6,"each surviving skin patch follows its own physical component");
        // A skin binding that crosses the new split cannot remain visible,
        // even if its source physical triangle remains intact.
        auto cross=std::make_shared<DeformableAsset>(*skin);cross->structure=std::make_shared<StructuralCook>(*skin->structure);cross->binding[0].nodes={0,3,0,0};cross->binding[0].weights={.5,.5,0,0};
        if(PrepareDeformableAsset(*cross,error)){DeformableInstance mixed;mixed.Initialize(cross,cfg,glm::dmat4(1),4);mixed.structure.pending[6]=1;mixed.structure.Commit(*cross->structure);mixed.MapRender(1,view);check(view.indices.size()==3,"a split weighted support hides its triangle instead of averaging the gap");}
        else check(true,"authoring rejects a skin binding spanning nonlocal support");
        std::fill(mapped.structure.pending.begin(),mapped.structure.pending.end(),uint8_t(1));
        mapped.structure.Commit(*skin->structure,mapped.positions);mapped.MapRender(1,view);
        check(view.indices.empty()&&view.primitives.empty()&&!view.vertices.empty(),"all failed skin supports retain empty indexed topology without resurrecting unused vertex triangles");
    }

    // A 10 mm actual wall is crossed by 25 m/s material in one 60 Hz step.
    // The endpoint is already outside its far side, so discrete overlap alone
    // cannot explain this response. No rigid outer vehicle box is involved.
    auto sheet=std::make_shared<DeformableAsset>(MakeDeformableSheet(2,2,.5,.5));
    auto wall=physics.CreateStaticBox({0,.25f,0},{1,1,.005f},0,0);
    DeformableInstance fast;cfg.selfContact=false;fast.Initialize(sheet,cfg,glm::translate(glm::dmat4(1),V(0,0,.2)),5);
    for(auto& velocity:fast.velocities)velocity={0,0,-25};
    fast.Step(1./60,physics,zero,{});
    check(fast.error.empty()&&fast.stats.sweptContacts>0&&fast.Minimum().z>=.0199,"25 m/s material point sweep stops at the real thin wall's approach surface");
    physics.DestroyBody(wall);

    // Analytic finite-mass negative control: a 100 kg freely translating
    // material patch meets a 0.5 kg box. Repeating a positional solve against
    // the box's frozen pose must not accelerate it as an infinite obstacle.
    struct FiniteResult {double energy=0,initialEnergy=0,residual=0;V momentum{0},initialMomentum{0};bool healthy=false;};
    auto finiteContact=[&](unsigned iterations){
        DeformableSettings q=cfg;q.iterations=iterations;q.material.density=400;
        q.material.stretchCompliance=q.material.shearCompliance=q.material.bendCompliance=1e6;
        auto targetBody=physics.CreateDynamicBox({0,.25f,0},{.6f,.6f,.01f},.5f,0,0);
        DeformableInstance patch;patch.Initialize(sheet,q,glm::translate(glm::dmat4(1),V(0,0,.04)),100+iterations);
        for(auto& v:patch.velocities)v={0,0,-2};
        FiniteResult result;
        for(unsigned n=0;n<patch.velocities.size();++n){result.initialMomentum+=patch.velocities[n]*patch.NodeMass(n);result.initialEnergy+=.5*patch.NodeMass(n)*glm::dot(patch.velocities[n],patch.velocities[n]);}
        patch.Step(1./60,physics,zero,{});const V rigidVelocity(physics.GetLinearVelocity(targetBody)),omega(physics.GetAngularVelocity(targetBody));
        result.momentum=rigidVelocity*double(physics.GetMass(targetBody));
        result.energy=.5*physics.GetMass(targetBody)*glm::dot(rigidVelocity,rigidVelocity)+.5*glm::dot(omega,glm::dmat3(physics.GetInertiaWorld(targetBody))*omega);
        for(unsigned n=0;n<patch.velocities.size();++n){result.momentum+=patch.velocities[n]*patch.NodeMass(n);result.energy+=.5*patch.NodeMass(n)*glm::dot(patch.velocities[n],patch.velocities[n]);}
        Shape targetShape;BodyTransform pose;physics.GetBodyShape(targetBody,targetShape,pose);RigidBody body;body.position=pose.position;body.orientation=pose.rotation;const auto primitive=PrimitiveAt(targetShape,body,0);
        auto measure=[&](V p){const auto d=PointGeometry(p,primitive);if(d.valid)result.residual=std::max(result.residual,q.material.thickness+(d.contains?d.gap:-d.gap));};
        for(auto p:patch.positions)measure(p);
        for(auto edge:sheet->edges)measure((patch.positions[edge.x]+patch.positions[edge.y])*.5);
        for(auto face:sheet->triangles)measure((patch.positions[face.x]+patch.positions[face.y]+patch.positions[face.z])/3.);
        result.healthy=patch.error.empty()&&patch.stats.contacts>0;
        std::printf("FINITE_CONTACT iterations=%u initialEnergy=%.9g finalEnergy=%.9g momentumError=%.9g actualResidual=%.9g targetSpeed=%.9g\n",iterations,result.initialEnergy,result.energy,glm::length(result.momentum-result.initialMomentum),result.residual,glm::length(rigidVelocity));
        physics.DestroyBody(targetBody);return result;
    };
    const auto finiteOne=finiteContact(1),finiteTwelve=finiteContact(12);
    check(finiteOne.healthy&&finiteTwelve.healthy&&glm::length(finiteOne.momentum-finiteOne.initialMomentum)<1e-4&&glm::length(finiteTwelve.momentum-finiteTwelve.initialMomentum)<1e-4,"finite rigid/material normal reactions conserve closed linear momentum at 1 and 12 iterations");
    check(finiteOne.energy<=finiteOne.initialEnergy*1.00001&&finiteTwelve.energy<=finiteTwelve.initialEnergy*1.00001,"a light finite target cannot gain unexplained energy from repeated frozen-pose overlap solves");
    check(finiteOne.residual<=.02&&finiteTwelve.residual<=.02,"independently measured finite-partner endpoint overlap stays within the declared 20 mm interval bound");

    // Contact with an attachment target is an explicit opt-in. Only samples
    // entirely in the active patch are exempt; other bodywork remains physical.
    auto patch=std::make_shared<DeformableAsset>(MakeDeformableSheet(2,3,.5,1));
    auto support=physics.CreateStaticBox({0,.5f,0},{1,.6f,.1f},0,0);
    DeformableAttachment pin;pin.group="top";pin.kind=DeformableAttachment::Kind::Body;pin.target=1;
    cfg.attachments={pin};DeformableTarget target;target.valid=true;target.body=support;
    target.previous=target.current=glm::translate(glm::dmat4(1),V(0,.5,0));cfg.attachments[0].offset={0,-.5,0};
    DeformableInstance legacy;legacy.Initialize(patch,cfg,glm::dmat4(1),6);legacy.Step(1./60,physics,zero,{target});
    check(legacy.error.empty()&&legacy.stats.contacts==0,"legacy attached-body contact policy retains whole-target exclusion");
    cfg.attachedBodyContact=true;DeformableInstance local;local.Initialize(patch,cfg,glm::dmat4(1),7);local.Step(1./60,physics,zero,{target});
    bool pinned=true;for(auto n:patch->groups.at("top"))pinned&=glm::length(local.positions[n]-patch->nodes[n])<1e-9;
    check(pinned&&local.stats.contacts>0&&local.positions.back().z>.1,"opt-in target contact exempts pinned patch while unfolded bodywork receives contact");
    local.Release("top");local.Step(1./60,physics,zero,{target});bool releasedContact=true;for(auto n:patch->groups.at("top"))releasedContact&=local.positions[n].z>.1;
    check(releasedContact&&local.error.empty(),"released attachment patch immediately participates in real body contact");
    // Two separately authored pin patches target the exact same physical body.
    // Faces/midpoints straddle both groups, so checking each group in isolation
    // would create artificial contact even though every contributor is pinned.
    auto unionPatch=std::make_shared<DeformableAsset>(*patch);
    unionPatch->groups["leftPatch"]={0,2,4};unionPatch->groups["rightPatch"]={1,3,5};
    check(PrepareDeformableAsset(*unionPatch,error),"independent local pin groups share one prepared physical surface");
    DeformableSettings unionCfg=cfg;DeformableAttachment leftPin=pin,rightPin=pin;
    leftPin.group="leftPatch";rightPin.group="rightPatch";leftPin.offset=rightPin.offset={0,-.5,0};unionCfg.attachments={leftPin,rightPin};
    DeformableInstance unionPinned;unionPinned.Initialize(unionPatch,unionCfg,glm::dmat4(1),8);unionPinned.Step(1./60,physics,zero,{target,target});
    check(unionPinned.error.empty()&&unionPinned.stats.contacts==0&&unionPinned.positions==unionPatch->nodes,"fully pinned weighted samples use the union of active groups on the same body");
    unionPinned.Release("leftPatch");unionPinned.Step(1./60,physics,zero,{target,target});
    bool remainingPinned=true,uncoveredTouches=false;
    for(auto n:unionPatch->groups.at("rightPatch"))remainingPinned&=glm::length(unionPinned.positions[n]-unionPatch->nodes[n])<1e-9;
    for(auto n:unionPatch->groups.at("leftPatch"))uncoveredTouches|=unionPinned.positions[n].z>.1;
    check(unionPinned.error.empty()&&unionPinned.stats.contacts>0&&remainingPinned&&uncoveredTouches,"releasing one union patch restores mixed pinned/unpinned sample contact without exempting the remaining surface");
    // An active group on a different body is not coverage for this collider,
    // even when it contains every missing material node.
    auto otherSupport=physics.CreateStaticBox({0,.5f,2},{1,.6f,.1f},0,0);
    DeformableTarget otherTarget=target;otherTarget.body=otherSupport;
    otherTarget.previous=otherTarget.current=glm::translate(glm::dmat4(1),V(0,.5,2));
    DeformableSettings distinctCfg=unionCfg;distinctCfg.attachments[1].target=2;
    DeformableInstance separateTargets;separateTargets.Initialize(unionPatch,distinctCfg,glm::dmat4(1),9);separateTargets.Step(1./60,physics,zero,{target,otherTarget});
    check(separateTargets.error.empty()&&separateTargets.stats.contacts>0,"pin coverage never combines groups targeting different physical body identities");
    physics.DestroyBody(otherSupport);physics.DestroyBody(support);

    // The native reference switch bypasses only the new primitive/sample
    // bounds. Compare the complete numerical result and retained witnesses,
    // including impacts whose end points are outside a very thin collider.
    struct CullResult {std::vector<V> positions,velocities;std::vector<DeformableContactObservation> observations;V rigidLinear{0},rigidAngular{0};uint64_t contacts=0,swept=0;double penetration=0;bool healthy=false;};
    auto cullFixture=[&](bool enabled,bool cacheEnabled,const Shape& shape,BodyTransform pose,bool dynamic,bool moving,V materialOffset,V speed){
        PhysicsWorld world;world.Init();
        const auto body=world.CreateShape(shape,pose,dynamic,dynamic?.5f:0,0,0);
        if(moving){world.SetLinearVelocity(body,{1.1f,.2f,-.6f});world.SetAngularVelocity(body,{0,3,0});world.Step(1.f/60);}
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;
        q.material.damping=0;q.material.friction=.2;q.material.thickness=.015;q.material.density=400;
        q.material.stretchCompliance=q.material.shearCompliance=q.material.bendCompliance=1e6;
        DeformableInstance instance;instance.Initialize(sheet,q,glm::translate(glm::dmat4(1),materialOffset),200);instance.SetContactCullingEnabled(enabled);
        instance.SetContactSampleCacheEnabled(cacheEnabled);
        for(auto& v:instance.velocities)v=speed;
        instance.Step(1./60,world,zero,{});
        CullResult out;out.positions=instance.positions;out.velocities=instance.velocities;out.observations=instance.contactObservations;
        out.rigidLinear=V(world.GetLinearVelocity(body));out.rigidAngular=V(world.GetAngularVelocity(body));out.contacts=instance.stats.contacts;out.swept=instance.stats.sweptContacts;out.penetration=instance.stats.maximumPenetration;out.healthy=instance.error.empty()&&body.IsValid();
        world.Shutdown();return out;
    };
    auto sameCullResult=[](const CullResult& a,const CullResult& b){
        bool same=a.healthy&&b.healthy&&a.positions==b.positions&&a.velocities==b.velocities&&a.rigidLinear==b.rigidLinear&&a.rigidAngular==b.rigidAngular&&a.contacts==b.contacts&&a.swept==b.swept&&a.penetration==b.penetration&&a.observations.size()==b.observations.size();
        for(unsigned i=0;same&&i<a.observations.size();++i){const auto& x=a.observations[i];const auto& y=b.observations[i];same=x.point==y.point&&x.normal==y.normal&&x.penetration==y.penetration&&x.swept==y.swept&&x.self==y.self&&x.body.id==y.body.id&&x.normalImpulse==y.normalImpulse;}
        return same;
    };
    auto compareCulls=[&](const char* label,const Shape& shape,BodyTransform pose,bool dynamic,bool moving,V offset,V speed,bool requireContact,bool requireSweep){
        const auto full=cullFixture(false,false,shape,pose,dynamic,moving,offset,speed),culled=cullFixture(true,true,shape,pose,dynamic,moving,offset,speed);
        const auto cacheOnly=cullFixture(false,true,shape,pose,dynamic,moving,offset,speed),cullOnly=cullFixture(true,false,shape,pose,dynamic,moving,offset,speed);
        check(sameCullResult(full,culled)&&sameCullResult(full,cacheOnly)&&sameCullResult(full,cullOnly)&&(!requireContact||full.contacts>0)&&(!requireSweep||full.swept>0),label);
    };
    BodyTransform at;at.position={0,.25f,0};
    compareCulls("conservative culls exactly preserve static thin-wall swept contacts",Shape::Box({1,1,.005f}),at,false,false,{0,0,.2},{0,0,-25},true,true);
    at.position={4096,.25f,-4096};
    compareCulls("float-rounded far-world point casts match the unculled thin-wall reference",Shape::Box({1,1,.005f}),at,false,false,{4096,0,-4095.8},{0,0,-25},true,true);
    at.position={0,.25f,0};
    compareCulls("finite-body momentum and repeated overlap solves match with culls enabled",Shape::Box({.6f,.6f,.01f}),at,true,false,{0,0,.04},{0,0,-2},true,false);
    CompoundBox near({0,0,0},{.6f,.6f,.005f});near.rotation=glm::angleAxis(.12f,glm::vec3(0,1,0));
    std::vector<CompoundBox> children{near,CompoundBox({4,0,0},{.1f,.1f,.1f}),CompoundBox({-4,0,0},{.1f,.1f,.1f})};
    at.rotation=glm::angleAxis(.05f,glm::vec3(1,0,0));
    compareCulls("rotated compound children and moving parent casts match the full path",Shape::Compound(children),at,true,true,{0,0,.2},{0,0,-25},true,true);
    at.rotation=glm::quat(1,0,0,0);
    compareCulls("sphere primitive bounds preserve actual discrete contact samples",Shape::Sphere(.3f),at,false,false,{0,0,.2},{0,0,0},true,false);
    compareCulls("capsule primitive bounds preserve actual discrete contact samples",Shape::Capsule(.1f,.3f),at,false,false,{0,0,.08},{0,0,0},true,false);
    // Two actual child surfaces repeatedly correct shared contributors. This
    // catches a cache invalidated only after a child/body, which would reuse
    // stale weighted nodes for subsequent edge/face samples in the same solve.
    CompoundBox tilted({0,0,0},{.6f,.6f,.01f});tilted.rotation=glm::angleAxis(.22f,glm::vec3(0,1,0));
    children={tilted,CompoundBox({0,0,.05f},{.6f,.6f,.01f})};
    compareCulls("sample revisions preserve exact sequential corrections across overlapping compound children",Shape::Compound(children),at,false,false,{0,0,.04},{0,0,-2},true,false);

    // A future-contact body starts outside every material/node bound. Its
    // ordinary integrator would cross this free member in one step. The
    // predictive solve must react before that single authoritative advance;
    // the disabled mode is a numerical missed-contact negative control.
    auto translatingMember=std::make_shared<DeformableAsset>();translatingMember->kind=DeformableKind::Structure;translatingMember->structure=std::make_shared<StructuralCook>();
    translatingMember->nodes={{-.05,0,0},{.05,0,0}};StructuralRegion soft;soft.key="free-member";soft.youngModulus=1e-6;soft.damping=0;soft.tensionYield=soft.compressionYield=1e9;soft.tensionUltimate=soft.compressionUltimate=1e10;
    translatingMember->structure->regions={soft};StructuralBeam member;member.key="translating-member";member.a=0;member.b=1;member.area=.01;translatingMember->structure->beams={member};
    check(PrepareDeformableAsset(*translatingMember,error),"free structural member prepares for finite predictive translation proof");
    struct PredictiveResult {V initialMomentum{0},momentum{0},expectedMomentum{0};double initialEnergy=0,energy=0,gravityWork=0,predictionError=0;uint64_t contacts=0,swept=0;bool healthy=false,initialCandidateAbsent=false;std::vector<V> positions,velocities;};
    auto predictiveContact=[&](bool predictive,bool culling,bool cache,glm::dquat frame,V localGravity,const Shape& bodyShape=Shape::Box({1,1,.01f}),V localAngular=V(0)){
        PhysicsWorld world;world.Init();BodyTransform initialPose;initialPose.position=glm::vec3(frame*V(0,0,1));initialPose.rotation=glm::quat(frame);
        const auto body=world.CreateShape(bodyShape,initialPose,true,.5f,0,0);world.SetLinearVelocity(body,glm::vec3(frame*V(0,0,-70)));world.SetAngularVelocity(body,glm::vec3(frame*localAngular));
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=100000;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance free;free.Initialize(translatingMember,q,glm::mat4_cast(frame),300);free.SetContactCullingEnabled(culling);free.SetContactSampleCacheEnabled(cache);
        const V acceleration=frame*localGravity;UniformGravity field{glm::vec3(acceleration)};world.ApplyLinearAcceleration(body,glm::vec3(acceleration),1.f/60);
        const auto nodeStart=free.positions;double totalMass=world.GetMass(body);for(unsigned n=0;n<free.positions.size();++n)totalMass+=free.NodeMass(n);
        PredictiveResult result;
        // ApplyLinearAcceleration is a velocity contribution before Step;
        // exclude it from the pre-force state used by the work balance.
        const V initialVelocity=frame*V(0,0,-70),initialAngular(world.GetAngularVelocity(body));result.initialMomentum=initialVelocity*double(world.GetMass(body));result.initialEnergy=.5*world.GetMass(body)*glm::dot(initialVelocity,initialVelocity)+.5*glm::dot(initialAngular,glm::dmat3(world.GetInertiaWorld(body))*initialAngular);
        result.expectedMomentum=result.initialMomentum+acceleration*(totalMass*double(1.f/60));
        const auto initial=world.QueryBodiesInAabb(glm::vec3(free.Minimum()-V(.02)),glm::vec3(free.Maximum()+V(.02)));result.initialCandidateAbsent=initial.empty();
        BodyTransform predicted;PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){free.BeginStructuralInterval(h,world,field,{},true,predictive);};
        coupling.solve=[&](float h,unsigned){free.SolveStructuralContacts(h,world,{});free.SolveStructuralIteration(h,world,{});predicted=world.PredictTransform(body,h);};
        coupling.finish=[&](float h){free.EndStructuralInterval(h,world,true);};
        world.Step(1.f/60,&coupling);
        const auto actual=world.GetTransform(body);const V linear(world.GetLinearVelocity(body)),angular(world.GetAngularVelocity(body));
        result.predictionError=glm::length(V(actual.position)-V(predicted.position));result.momentum=linear*double(world.GetMass(body));result.energy=.5*world.GetMass(body)*glm::dot(linear,linear)+.5*glm::dot(angular,glm::dmat3(world.GetInertiaWorld(body))*angular);
        result.gravityWork=world.GetMass(body)*glm::dot(acceleration,V(actual.position)-V(initialPose.position));
        for(unsigned n=0;n<free.positions.size();++n){result.momentum+=free.velocities[n]*free.NodeMass(n);result.energy+=.5*free.NodeMass(n)*glm::dot(free.velocities[n],free.velocities[n]);result.gravityWork+=free.NodeMass(n)*glm::dot(acceleration,free.positions[n]-nodeStart[n]);}
        result.positions=free.positions;result.velocities=free.velocities;
        result.contacts=free.stats.contacts;result.swept=free.stats.sweptContacts;result.healthy=free.error.empty();
        std::printf("PREDICTIVE_CONTACT enabled=%d culling=%d cache=%d initialCandidateAbsent=%d contacts=%llu swept=%llu momentumError=%.9g initialEnergy=%.9g finalEnergy=%.9g gravityWork=%.9g predictionError=%.9g bodyEndZ=%.9g\n",predictive,culling,cache,result.initialCandidateAbsent,(unsigned long long)result.contacts,(unsigned long long)result.swept,glm::length(result.momentum-result.expectedMomentum),result.initialEnergy,result.energy,result.gravityWork,result.predictionError,actual.position.z);
        world.Shutdown();return result;
    };
    auto samePredictive=[](const PredictiveResult& a,const PredictiveResult& b){return a.healthy&&b.healthy&&a.positions==b.positions&&a.velocities==b.velocities&&a.contacts==b.contacts&&a.swept==b.swept&&a.momentum==b.momentum&&a.energy==b.energy&&a.predictionError==b.predictionError;};
    const glm::dquat identity(1,0,0,0);
    const auto futureFull=predictiveContact(true,false,false,identity,V(0)),futureFast=predictiveContact(true,true,true,identity,V(0)),futureCache=predictiveContact(true,false,true,identity,V(0)),futureCull=predictiveContact(true,true,false,identity,V(0)),pastOnly=predictiveContact(false,true,true,identity,V(0));
    check(futureFull.healthy&&futureFull.initialCandidateAbsent&&futureFull.contacts>0&&futureFull.swept>0&&samePredictive(futureFull,futureFast)&&samePredictive(futureFull,futureCache)&&samePredictive(futureFull,futureCull),"future dynamic reach receives swept structural contact with exact cache/cull reference equivalence");
    check(glm::length(futureFull.momentum-futureFull.expectedMomentum)<1e-3&&futureFull.energy<=futureFull.initialEnergy*1.0001&&futureFull.predictionError<1e-5,"predictive finite-body contact conserves momentum and energy before the ordinary translating body advance");
    check(pastOnly.healthy&&pastOnly.contacts==0,"ordinary start-pose contact is an executable missed-future-translation negative control");

    // Rotate the entire physical setup and the acceleration together. This is
    // the same finite-mass contact, not an alternate world-up contact branch.
    const auto orientation=glm::angleAxis(.73,glm::normalize(V(1,2,3)));
    const auto tiltedFull=predictiveContact(true,false,false,orientation,V(0,-9.81,0)),tiltedFast=predictiveContact(true,true,true,orientation,V(0,-9.81,0));
    check(tiltedFull.initialCandidateAbsent&&tiltedFull.contacts>0&&tiltedFull.swept>0&&samePredictive(tiltedFull,tiltedFast),"oblique finite-body prediction preserves actual contact and exact culling/cache equivalence under ordinary gravity");
    check(glm::length(tiltedFull.momentum-tiltedFull.expectedMomentum)<1e-3&&tiltedFull.energy<=tiltedFull.initialEnergy+tiltedFull.gravityWork+.01&&tiltedFull.predictionError<1e-5,"oblique predictive contact preserves momentum plus sampled-gravity impulse without creating unexplained energy");

    // The predictive sample BVH must preserve original ordering across several
    // independently posed compound children, including children that never
    // meet any material sample. The scanner remains the numerical reference.
    CompoundBox first({0,0,0},{.6f,.6f,.01f});first.rotation=glm::angleAxis(.11f,glm::vec3(0,1,0));
    CompoundBox second({0,0,.05f},{.6f,.6f,.01f});second.rotation=glm::angleAxis(-.09f,glm::vec3(0,1,0));
    const auto compoundShape=Shape::Compound({first,second,CompoundBox({4,0,0},{.1f,.1f,.1f}),CompoundBox({-4,0,0},{.1f,.1f,.1f})});
    const auto compoundReference=predictiveContact(true,false,false,orientation,V(0),compoundShape,V(.2,1.7,-.3));
    const auto compoundFast=predictiveContact(true,true,true,orientation,V(0),compoundShape,V(.2,1.7,-.3)),compoundCache=predictiveContact(true,false,true,orientation,V(0),compoundShape,V(.2,1.7,-.3)),compoundCull=predictiveContact(true,true,false,orientation,V(0),compoundShape,V(.2,1.7,-.3));
    check(compoundReference.healthy&&compoundReference.contacts>0&&compoundReference.swept>0&&samePredictive(compoundReference,compoundFast)&&samePredictive(compoundReference,compoundCache)&&samePredictive(compoundReference,compoundCull),"predictive sample-tree selection exactly matches the scanner across oblique moving compound children and retained contacts");

    auto canonicalSelfFeature=[&](glm::dquat frame,bool secondPoint,bool far){
        auto asset=std::make_shared<DeformableAsset>();asset->kind=DeformableKind::Structure;asset->structure=std::make_shared<StructuralCook>();
        const double z=far?.334:.034;asset->nodes={{0,0,z},{1,0,1+z},{0,1,1+z},{-1,-1,1+z},{-1,0,0},{1,0,0},{0,-2,-1}};
        StructuralRegion region;region.key="contact identity";region.youngModulus=1000;region.damping=0;region.tensionYield=region.compressionYield=1e12;region.tensionUltimate=region.compressionUltimate=1e13;asset->structure->regions={region};
        for(auto pair:std::vector<glm::uvec2>{{0,1},{0,2},{0,3},{4,5},{5,6},{6,4}}){StructuralBeam beam;beam.key="edge-"+std::to_string(asset->structure->beams.size());beam.a=pair.x;beam.b=pair.y;beam.area=.001;asset->structure->beams.push_back(beam);}
        asset->triangles={{0,1,2},{0,2,3},{0,3,1},{4,5,6}};asset->structure->surfaceRegions.assign(4,0);asset->structure->surfaceSupports={{0,1},{1,2},{0,2},{3,4,5}};
        if(secondPoint){asset->nodes.push_back({.6,0,z});asset->nodes.push_back({.6,1,1+z});StructuralBeam beam;beam.key="independent point";beam.a=7;beam.b=8;beam.area=.001;asset->structure->beams.push_back(beam);}
        std::string failure;if(!PrepareDeformableAsset(*asset,failure)){std::printf("SELF_FEATURE prepare=%s\n",failure.c_str());return false;}
        PhysicsWorld world;world.Init();DeformableSettings settings;settings.selfContact=true;settings.substeps=1;settings.iterations=12;settings.material.density=10000;settings.material.damping=settings.material.friction=settings.material.airDrag=0;
        DeformableInstance patch;patch.Initialize(asset,settings,glm::mat4_cast(frame),710);
        for(unsigned n=0;n<patch.positions.size();++n)if(n<4||n>=7)patch.velocities[n]=frame*V(0,0,-3);
        V initialMomentum(0);for(unsigned n=0;n<patch.positions.size();++n)initialMomentum+=patch.NodeMass(n)*patch.velocities[n];
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=12;coupling.begin=[&](float h){patch.BeginStructuralInterval(h,world,zero,{},true,true);};coupling.solve=[&](float h,unsigned){patch.SolveStructuralContacts(h,world,{});patch.SolveStructuralIteration(h,world,{});};coupling.finish=[&](float h){patch.EndStructuralInterval(h,world,true);};world.Step(1.f/240,&coupling);
        unsigned observations=0;for(const auto& contact:patch.contactObservations)observations+=contact.self;
        V momentum(0);for(unsigned n=0;n<patch.positions.size();++n)momentum+=patch.NodeMass(n)*patch.velocities[n];const double difference=glm::length(momentum-initialMomentum);
        std::printf("SELF_FEATURE second=%u far=%u observations=%u expected=%u momentum_error=%.12g error=%s\n",unsigned(secondPoint),unsigned(far),observations,far?0u:secondPoint?2u:1u,difference,patch.error.c_str());
        const bool valid=patch.error.empty()&&observations==(far?0u:secondPoint?2u:1u)&&difference<1e-8;world.Shutdown();return valid;
    };
    check(canonicalSelfFeature(identity,false,false),"three incident edges and a face share one physical vertex-edge contact identity");
    check(canonicalSelfFeature(orientation,false,false),"canonical self-contact ownership preserves the same feature and momentum after rotation");
    check(canonicalSelfFeature(identity,true,false),"separate contact vertices on the same edge remain two physical force locations");
    check(canonicalSelfFeature(identity,false,true),"separated self-contact negative control emits no hidden pressure");

    struct KinematicResult {std::vector<V> positions;uint64_t contacts=0,swept=0;double predictionError=0,angleError=0;bool healthy=false;};
    auto kinematicContact=[&](bool predictive,bool rotate,bool culling,bool cache){
        PhysicsWorld world;world.Init();const V center=rotate?V(0):V(0,0,1);const auto body=world.CreateStaticBox(glm::vec3(center),{1,1,.01f},0,0);world.SetMotionType(body,BodyMotionType::Kinematic);
        world.SetKinematicVelocity(body,rotate?glm::vec3(0):glm::vec3(0,0,-70),rotate?glm::vec3(0,glm::half_pi<float>()/(1.f/60),0):glm::vec3(0));
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=100000;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance free;free.Initialize(translatingMember,q,glm::translate(glm::dmat4(1),rotate?V(0,0,.5):V(0)),400);free.SetContactCullingEnabled(culling);free.SetContactSampleCacheEnabled(cache);
        BodyTransform predicted;PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){free.BeginStructuralInterval(h,world,zero,{},true,predictive);};
        coupling.solve=[&](float h,unsigned){free.SolveStructuralContacts(h,world,{});free.SolveStructuralIteration(h,world,{});predicted=world.PredictTransform(body,h);};
        coupling.finish=[&](float h){free.EndStructuralInterval(h,world,true);};world.Step(1.f/60,&coupling);
        const auto actual=world.GetTransform(body);KinematicResult result;result.positions=free.positions;result.contacts=free.stats.contacts;result.swept=free.stats.sweptContacts;result.healthy=free.error.empty();result.predictionError=glm::length(V(actual.position)-V(predicted.position));result.angleError=1-std::abs(glm::dot(actual.rotation,predicted.rotation));
        std::printf("KINEMATIC_MATERIAL_CONTACT predictive=%d rotate=%d culling=%d cache=%d contacts=%llu swept=%llu positionError=%.9g rotationError=%.9g healthy=%d error=%s\n",predictive,rotate,culling,cache,(unsigned long long)result.contacts,(unsigned long long)result.swept,result.predictionError,result.angleError,result.healthy,free.error.c_str());
        world.Shutdown();return result;
    };
    const auto translated=kinematicContact(true,false,true,true),translatedReference=kinematicContact(true,false,false,false),translatedPast=kinematicContact(false,false,true,true);
    check(translated.healthy&&translated.contacts>0&&translated.swept>0&&translated.positions==translatedReference.positions&&translated.contacts==translatedReference.contacts&&translated.predictionError<1e-5&&translated.angleError<1e-6,"prescribed translating geometry participates before its one authoritative advance with exact optimized/reference agreement");
    check(translatedPast.healthy&&translatedPast.contacts==0,"omitting kinematic future geometry demonstrably misses the translating impact");
    const auto rotated=kinematicContact(true,true,true,true),rotatedReference=kinematicContact(true,true,false,false),rotatedPast=kinematicContact(false,true,true,true);
    check(rotated.healthy&&rotated.contacts>0&&rotated.positions==rotatedReference.positions&&rotated.contacts==rotatedReference.contacts&&rotated.predictionError<1e-5&&rotated.angleError<1e-6,"prescribed rotation participates through endpoint-relative material casts before the authoritative advance");
    check(rotatedPast.healthy&&rotatedPast.contacts==0,"omitting prescribed future orientation misses the rotating contact fixture");

    // Starting at an already resting contact skin is a distinct CCD boundary.
    // A cast legitimately reports initialOverlap; testing only the final
    // unsigned distance would then miss a full thin-wall crossing. The same
    // fixture also gives an analytic Coulomb sliding control: with 4 m/s
    // tangential and 15 m/s closing motion, mu=.1 may remove only 1.5 m/s.
    struct SkinResult {V meanVelocity{0},normalImpulse{0};double violation=0,energy=0,initialEnergy=0;uint64_t contacts=0;bool healthy=false;};
    auto restingSkin=[&](bool predictive,double friction){
        PhysicsWorld world;world.Init();const auto wall=world.CreateStaticBox({0,0,0},{1,1,.005f},0,0);
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=100000;q.material.damping=0;q.material.friction=friction;q.material.thickness=.015;
        DeformableInstance free;free.Initialize(translatingMember,q,glm::translate(glm::dmat4(1),V(0,0,.02)),450);for(auto& velocity:free.velocities)velocity={4,0,-15};
        SkinResult result;double totalMass=0;for(unsigned n=0;n<free.positions.size();++n){totalMass+=free.NodeMass(n);result.initialEnergy+=.5*free.NodeMass(n)*glm::dot(free.velocities[n],free.velocities[n]);}
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){free.BeginStructuralInterval(h,world,zero,{},true,predictive);};
        coupling.solve=[&](float h,unsigned){free.SolveStructuralContacts(h,world,{});free.SolveStructuralIteration(h,world,{});};
        coupling.finish=[&](float h){free.EndStructuralInterval(h,world,true);};world.Step(1.f/240,&coupling);
        for(unsigned n=0;n<free.positions.size();++n){result.meanVelocity+=free.velocities[n]*free.NodeMass(n);result.energy+=.5*free.NodeMass(n)*glm::dot(free.velocities[n],free.velocities[n]);}result.meanVelocity/=totalMass;
        for(const auto& contact:free.contactObservations)if(contact.body.id==wall.id&&contact.body.world==wall.world)result.normalImpulse+=contact.normal*contact.normalImpulse;
        result.violation=std::max(0.,.005+q.material.thickness-free.Minimum().z);result.contacts=free.stats.contacts;result.healthy=free.error.empty();
        std::printf("RESTING_SKIN predictive=%d friction=%.9g meanVelocity=(%.9g,%.9g,%.9g) wallViolation=%.9g normalImpulse=(%.9g,%.9g,%.9g) energy=%.9g initialEnergy=%.9g contacts=%llu error=%s\n",predictive,friction,result.meanVelocity.x,result.meanVelocity.y,result.meanVelocity.z,result.violation,result.normalImpulse.x,result.normalImpulse.y,result.normalImpulse.z,result.energy,result.initialEnergy,(unsigned long long)result.contacts,free.error.c_str());
        world.Shutdown();return result;
    };
    const auto skinFrictionless=restingSkin(true,0),skinLowFriction=restingSkin(true,.1),skinHighFriction=restingSkin(true,.5),skinPastOnly=restingSkin(false,0);
    check(skinFrictionless.healthy&&skinFrictionless.contacts>0&&skinFrictionless.violation<1e-4&&std::abs(skinFrictionless.meanVelocity.z)<.02&&std::abs(skinFrictionless.meanVelocity.x-4)<.02&&skinFrictionless.energy<=skinFrictionless.initialEnergy,"a predictive point starting on the skin cannot cross the thin wall and preserves frictionless tangential motion");
    check(skinPastOnly.healthy&&skinPastOnly.violation>.05&&skinPastOnly.contacts==0,"initial-overlap final-distance-only contact is an executable full-wall-crossing negative control");
    check(skinLowFriction.healthy&&skinLowFriction.violation<1e-4&&std::abs(skinLowFriction.meanVelocity.x-2.5)<.02&&skinLowFriction.energy<=skinLowFriction.initialEnergy,"condensed low-friction contact obeys the analytic Coulomb impulse bound without artificial tangential freezing");
    check(skinHighFriction.healthy&&skinHighFriction.violation<1e-4&&std::abs(skinHighFriction.meanVelocity.x)<.02&&skinHighFriction.energy<=skinHighFriction.initialEnergy,"sufficient authored friction stops the same sliding contact through actual mechanical impulses");

    // The first free trajectory intersects a FINITE wall near its corner.
    // A second ordinary wall can redirect that trajectory so its entire final
    // segment passes outside the first wall. Retaining the first pressure as an
    // infinite plane would incorrectly stop the member's forward motion. No
    // material transform/velocity is repaired after the initial authored input.
    auto escapeMember=std::make_shared<DeformableAsset>(*translatingMember);escapeMember->structure=std::make_shared<StructuralCook>(*translatingMember->structure);
    escapeMember->nodes={{0,-.025,0},{0,.025,0}};
    check(PrepareDeformableAsset(*escapeMember,error),"finite-wall escape member prepares with a real physical edge and no positional repair");
    struct EscapeResult {V meanVelocity{0},meanPosition{0};double frontImpulse=0,sideImpulse=0,initialEnergy=0,energy=0,maximumPenetration=0;bool healthy=false;std::string error;};
    auto finiteWallEscape=[&](glm::dquat frame,bool redirect,bool filtered,bool destroy){
        PhysicsWorld world;world.Init();BodyTransform frontPose;frontPose.rotation=glm::quat(frame);
        const auto front=world.CreateShape(Shape::Box({.1f,.4f,.005f}),frontPose,false,0,0,0);
        BodyHandle side;if(redirect){BodyTransform sidePose;sidePose.position=glm::vec3(frame*V(.12,0,0));sidePose.rotation=glm::quat(frame);side=world.CreateShape(Shape::Box({.005f,.4f,1}),sidePose,false,0,0,0);}
        if(filtered)world.SetCollisionFilter(front,0,0);
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=100000;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance free;free.Initialize(escapeMember,q,glm::translate(glm::dmat4(1),frame*V(.16,0,.1))*glm::mat4_cast(frame),470);
        for(auto& velocity:free.velocities)velocity=frame*V(-33.6,0,-48);
        EscapeResult result;for(unsigned n=0;n<free.positions.size();++n)result.initialEnergy+=.5*free.NodeMass(n)*glm::dot(free.velocities[n],free.velocities[n]);
        bool removed=false;PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){free.BeginStructuralInterval(h,world,zero,{},true,true);};
        coupling.solve=[&](float h,unsigned round){if(destroy&&!removed&&round==1){world.DestroyBody(front);BodyTransform replacement;replacement.position={20,20,20};world.CreateShape(Shape::Box({.1f,.1f,.1f}),replacement,false,0,0,0);removed=true;}
            free.SolveStructuralContacts(h,world,{});free.SolveStructuralIteration(h,world,{});};
        coupling.finish=[&](float h){free.EndStructuralInterval(h,world,true);};world.Step(1.f/240,&coupling);
        for(unsigned n=0;n<free.positions.size();++n){const double mass=free.NodeMass(n);result.meanVelocity+=mass*(glm::inverse(frame)*free.velocities[n]);result.meanPosition+=mass*(glm::inverse(frame)*free.positions[n]);result.energy+=.5*mass*glm::dot(free.velocities[n],free.velocities[n]);}result.meanVelocity/=free.Mass();result.meanPosition/=free.Mass();
        for(const auto& witness:free.contactObservations){if(witness.body.world==front.world&&witness.body.id==front.id)result.frontImpulse+=witness.normalImpulse;if(witness.body.world==side.world&&witness.body.id==side.id)result.sideImpulse+=witness.normalImpulse;}
        for(auto body:{front,side})if(world.IsBodyEnabled(body)){Shape shape;BodyTransform pose;world.GetBodyShape(body,shape,pose);RigidBody rigid;rigid.position=pose.position;rigid.orientation=pose.rotation;const auto primitive=PrimitiveAt(shape,rigid,0);
            for(auto point:free.positions){const auto distance=PointGeometry(point,primitive);if(distance.valid)result.maximumPenetration=std::max(result.maximumPenetration,q.material.thickness+(distance.contains?distance.gap:-distance.gap));}}
        result.healthy=free.error.empty();result.error=free.error;
        std::printf("FINITE_MANIFOLD_ESCAPE redirect=%d filtered=%d destroy=%d frame=(%.9g,%.9g,%.9g,%.9g) position=(%.9g,%.9g,%.9g) velocity=(%.9g,%.9g,%.9g) frontImpulse=%.9g sideImpulse=%.9g penetration=%.9g initialEnergy=%.9g energy=%.9g error=%s\n",redirect,filtered,destroy,frame.w,frame.x,frame.y,frame.z,result.meanPosition.x,result.meanPosition.y,result.meanPosition.z,result.meanVelocity.x,result.meanVelocity.y,result.meanVelocity.z,result.frontImpulse,result.sideImpulse,result.maximumPenetration,result.initialEnergy,result.energy,result.error.c_str());
        world.Shutdown();return result;
    };
    const auto actualCorner=finiteWallEscape(identity,false,false,false),escapingCorner=finiteWallEscape(identity,true,false,false),rotatedEscape=finiteWallEscape(orientation,true,false,false),filteredCorner=finiteWallEscape(identity,false,true,false),destroyedCorner=finiteWallEscape(identity,false,false,true);
    check(actualCorner.healthy&&actualCorner.frontImpulse>1&&actualCorner.maximumPenetration<1e-4&&actualCorner.energy<=actualCorner.initialEnergy+.01,"an actual finite corner intercepts the original swept path with a physical dissipative impulse");
    const auto escaped=[](const EscapeResult& r){return r.healthy&&r.sideImpulse>1&&r.frontImpulse<1e-4&&r.meanPosition.x>.13&&r.meanPosition.z<-.09&&std::abs(r.meanVelocity.z+48)<.001&&r.maximumPenetration<1e-4&&r.energy<=r.initialEnergy+.01;};
    check(escaped(escapingCorner),"a second physical wall redirects the path clear of the finite first wall and retires its old plane pressure");
    check(escaped(rotatedEscape)&&glm::length(rotatedEscape.meanPosition-escapingCorner.meanPosition)<1e-5&&glm::length(rotatedEscape.meanVelocity-escapingCorner.meanVelocity)<.001,"finite swept-manifold release remains equivalent after rotating every physical shape and input");
    const auto freePass=[](const EscapeResult& r){return r.healthy&&r.frontImpulse==0&&r.sideImpulse==0&&std::abs(r.meanPosition.x-.02)<1e-6&&std::abs(r.meanPosition.z+.1)<1e-6&&glm::length(r.meanVelocity-V(-33.6,0,-48))<.001;};
    check(freePass(filteredCorner),"ordinary reciprocal filtering excludes the finite wall rather than retaining a hidden pressure plane");
    check(freePass(destroyedCorner),"destroying a contacted finite body and reusing its slot retires stale pressure without aliasing the replacement");

    // Sustained friction must work after the large impact-penetration merit
    // decrease is gone. Uniform gravity supplies only normal load, so these
    // identical free points have the independent Coulomb result v=4-mu*g*t.
    auto sustainedSlide=[&](glm::dquat frame,double friction,double initialSpeed=4){
        PhysicsWorld world;world.Init();BodyTransform pose;pose.rotation=glm::quat(frame);const auto plane=world.CreateShape(Shape::Box({10,10,.005f}),pose,false,0,0,0);
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=100000;q.material.damping=0;q.material.friction=friction;q.material.thickness=.015;
        DeformableInstance patch;patch.Initialize(translatingMember,q,glm::translate(glm::dmat4(1),frame*V(0,0,.02))*glm::mat4_cast(frame),460);for(auto& velocity:patch.velocities)velocity=frame*V(initialSpeed,0,0);
        UniformGravity field{glm::vec3(frame*V(0,0,-9.81))};PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){patch.BeginStructuralInterval(h,world,field,{},true,true);};coupling.solve=[&](float h,unsigned){patch.SolveStructuralContacts(h,world,{});patch.SolveStructuralIteration(h,world,{});};coupling.finish=[&](float h){patch.EndStructuralInterval(h,world,true);};
        uint64_t contacts=0;V reaction(0);double violation=0;for(unsigned step=0;step<24&&patch.error.empty();++step){world.Step(1.f/240,&coupling);contacts+=patch.stats.contacts;
            for(const auto& witness:patch.contactObservations)if(witness.body.id==plane.id&&witness.body.world==plane.world)reaction+=witness.normal*witness.normalImpulse;
            for(auto point:patch.positions)violation=std::max(violation,.02-glm::dot(point,frame*V(0,0,1)));}
        V mean(0);for(unsigned n=0;n<patch.positions.size();++n)mean+=patch.velocities[n]*patch.NodeMass(n);mean/=patch.Mass();const V local=glm::inverse(frame)*mean;const double expected=std::max(0.,initialSpeed-friction*9.81*24*double(1.f/240));
        std::printf("SUSTAINED_COULOMB mu=%.9g dt=1/240 steps=24 frame=(%.9g,%.9g,%.9g,%.9g) actualSpeed=%.9g expectedSpeed=%.9g normalSpeed=%.9g violation=%.9g reaction=%.9g contacts=%llu error=%s\n",friction,frame.w,frame.x,frame.y,frame.z,local.x,expected,local.z,violation,glm::length(reaction),(unsigned long long)contacts,patch.error.c_str());
        const bool pass=patch.error.empty()&&contacts>0&&std::abs(local.x-expected)<.001&&std::abs(local.z)<.001&&violation<1e-4;world.Shutdown();return pass;
    };
    check(sustainedSlide(identity,0),"a supported frictionless material member retains tangential speed under sustained normal gravity");
    check(sustainedSlide(identity,.5),"sustained finite Coulomb sliding follows analytic deceleration after impact recovery is absent");
    check(sustainedSlide(orientation,.5),"the same sustained normal-load friction law holds in an arbitrarily rotated frame");
    check(sustainedSlide(identity,.5,.03),"a slowly sliding supported member crosses into static friction without a numerical stall or reverse acceleration");
    check(sustainedSlide(orientation,.5,.03),"the same sliding-to-sticking transition remains healthy after arbitrary rotation");
    check(sustainedSlide(identity,0,.03),"the slow-speed negative control keeps moving when physical friction is absent");

    // Steel must transfer a frontal contact to its actual finite attachment,
    // rather than merely solving a small local node against the wall and then
    // letting a stiff member pull that node through it. A compact rear body is
    // deliberately excluded from this wall's collision mask: there is no
    // hidden rigid nose to make a deficient material contact appear correct.
    auto steel=std::make_shared<DeformableAsset>();steel->kind=DeformableKind::Structure;steel->structure=std::make_shared<StructuralCook>();
    steel->nodes={{0,0,0},{.1,0,0}};steel->groups["rear"]={1};StructuralRegion steelRegion;steelRegion.key="finite pinned steel";
    steelRegion.youngModulus=200e9;steelRegion.damping=35;steelRegion.tensionYield=steelRegion.compressionYield=400e6;steelRegion.tensionUltimate=steelRegion.compressionUltimate=600e6;steelRegion.hardening=140e6;
    steel->structure->regions={steelRegion};StructuralBeam steelBeam;steelBeam.key="physical steel member";steelBeam.a=0;steelBeam.b=1;steelBeam.area=.01;steel->structure->beams={steelBeam};
    check(PrepareDeformableAsset(*steel,error),"finite-pinned stiff contact member prepares with actual SI steel stiffness and mass");
    struct SteelResult {double initialViolation=0,violation=0,pinDrift=0,momentumError=0,predictionError=0,linearResidual=0;unsigned linearIterations=0;uint64_t contacts=0;bool healthy=false,lateImpulseApplied=false,historyUnchanged=false;std::string error;};
    auto finitePinnedSteel=[&](float rearMass,bool lateImpulse=false){
        PhysicsWorld world;world.Init();const auto wall=world.CreateStaticBox({0,0,0},{.005f,1,1},0,0),rear=world.CreateDynamicBox({.13f,0,0},{.02f,.02f,.02f},rearMass,0,0);
        world.SetCollisionFilter(rear,0,0);world.SetLinearVelocity(rear,{-15,0,0});
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=7850;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableAttachment attachment;attachment.group="rear";attachment.kind=DeformableAttachment::Kind::Body;attachment.target=1;attachment.offset={-.1,0,0};q.attachments={attachment};
        DeformableInstance member;member.Initialize(steel,q,glm::translate(glm::dmat4(1),V(.03,0,0)),500);for(auto& velocity:member.velocities)velocity={-15,0,0};
        const double h=double(1.f/240);double totalMass=world.GetMass(rear);for(unsigned n=0;n<member.positions.size();++n)totalMass+=member.NodeMass(n);
        const V initialMomentum(-15*totalMass,0,0);SteelResult result;result.initialViolation=std::max(0.,.005+q.material.thickness-member.Minimum().x);
        DeformableTarget target;target.valid=true;target.body=rear;const auto initial=world.GetTransform(rear);target.previous=glm::translate(glm::dmat4(1),V(initial.position))*glm::mat4_cast(glm::dquat(initial.rotation));
        auto sampleTarget=[&](){const auto pose=world.PredictTransform(rear,float(h));target.current=glm::translate(glm::dmat4(1),V(pose.position))*glm::mat4_cast(glm::dquat(pose.rotation));};
        const auto initialRest=member.structure.restLengths,initialPlastic=member.structure.accumulatedPlasticStrain;const auto initialBroken=member.structure.broken;
        BodyTransform predicted;PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float dt){world.PreparePredictedBody(rear,dt);sampleTarget();member.BeginStructuralInterval(dt,world,zero,{target},true,true);};
        coupling.solve=[&](float dt,unsigned iteration){sampleTarget();member.SolveStructuralContacts(dt,world,{target});sampleTarget();member.SolveStructuralIteration(dt,world,{target});predicted=world.PredictTransform(rear,dt);
            if(lateImpulse&&iteration+1==q.iterations&&member.error.empty()){world.ApplyLinearImpulse(rear,{5,0,0});result.lateImpulseApplied=true;}};
        coupling.finish=[&](float dt){member.EndStructuralInterval(dt,world,true);};world.Step(float(h),&coupling);
        const auto actual=world.GetTransform(rear);V finalMomentum=V(world.GetLinearVelocity(rear))*double(world.GetMass(rear));for(unsigned n=0;n<member.positions.size();++n)finalMomentum+=member.velocities[n]*member.NodeMass(n);
        V externalImpulse(0);for(const auto& witness:member.contactObservations)if(witness.body.id==wall.id&&witness.body.world==wall.world)externalImpulse+=witness.normal*witness.normalImpulse;
        // Signed approach-side violation detects a complete thin-wall crossing
        // too. An unsigned endpoint overlap would falsely pass once a point
        // had already travelled out of the wall's far side.
        result.violation=std::max(0.,.005+q.material.thickness-member.Minimum().x);result.pinDrift=glm::length(member.positions[1]-V(actual.position));result.momentumError=glm::length(finalMomentum-initialMomentum-externalImpulse);
        result.predictionError=glm::length(V(actual.position)-V(predicted.position));result.contacts=member.stats.contacts;result.linearIterations=member.structure.linearIterations;result.linearResidual=member.structure.linearResidual;
        result.healthy=member.error.empty()&&std::none_of(member.structure.broken.begin(),member.structure.broken.end(),[](uint8_t broken){return broken!=0;});result.error=member.error;
        result.historyUnchanged=member.structure.restLengths==initialRest&&member.structure.accumulatedPlasticStrain==initialPlastic&&member.structure.broken==initialBroken&&member.structure.plasticWork==0&&member.structure.fractureWork==0&&member.structure.dampingWork==0;
        std::printf("FINITE_PINNED_STEEL rearMass=%.9g speed=15 dt=%.12g iterations=12 initialViolation=%.9g wallApproachViolation=%.9g pinDrift=%.9g momentumError=%.9g predictionError=%.9g contactCount=%llu linearIterations=%u linearResidual=%.9g lateImpulseApplied=%d historyUnchanged=%d error=%s\n",rearMass,h,result.initialViolation,result.violation,result.pinDrift,result.momentumError,result.predictionError,(unsigned long long)result.contacts,result.linearIterations,result.linearResidual,result.lateImpulseApplied,result.historyUnchanged,member.error.c_str());
        world.Shutdown();return result;
    };
    const auto lightSteel=finitePinnedSteel(.5f),heavySteel=finitePinnedSteel(500.f);
    check(lightSteel.healthy&&lightSteel.initialViolation==0&&lightSteel.contacts>0&&lightSteel.violation<=.03&&lightSteel.pinDrift<.001&&lightSteel.momentumError<.01&&lightSteel.predictionError<1e-5,"stiff finite member transfers a frontal contact through its real light attachment with bounded wall violation and no invented momentum");
    check(heavySteel.healthy&&heavySteel.initialViolation==0&&heavySteel.contacts>0&&heavySteel.violation<=.03&&heavySteel.pinDrift<.001&&heavySteel.momentumError<.01&&heavySteel.predictionError<1e-5,"the same actual steel/contact solve remains bounded with a 500 kg finite rear assembly and no hidden nose collider");

    const auto staleEndpointSteel=finitePinnedSteel(500.f,true);
    check(!staleEndpointSteel.healthy&&staleEndpointSteel.lateImpulseApplied&&staleEndpointSteel.historyUnchanged&&staleEndpointSteel.contacts==0&&staleEndpointSteel.predictionError>1e-5&&staleEndpointSteel.error.find("actual rigid endpoint changed")!=std::string::npos,"an ordinary external impulse after the last solve invalidates the actual endpoint and rejects history/contact publication rather than trusting cached convergence");

    // A collinear rod cannot expose a rotated warm-force residual. This short
    // fully braced 3D crush cell uses the car's actual steel/return-map law,
    // finite rear inertia and an offset wall. The unhit side keeps moving,
    // causing real member direction changes while plasticity is active.
    auto crushCell=std::make_shared<DeformableAsset>();crushCell->kind=DeformableKind::Structure;crushCell->structure=std::make_shared<StructuralCook>();
    for(double z:{0.,.3})for(double y:{-.1,.1})for(double x:{-.15,.15})crushCell->nodes.emplace_back(x,y,z);
    crushCell->groups["rear"]={4,5,6,7};StructuralRegion cellRegion;cellRegion.key="braced plastic steel";cellRegion.youngModulus=200e9;cellRegion.damping=35;
    cellRegion.tensionYield=260e6;cellRegion.compressionYield=200e6;cellRegion.tensionUltimate=600e6;cellRegion.compressionUltimate=360e6;cellRegion.hardening=140e6;cellRegion.maxShortening=.6;cellRegion.maxExtension=.045;
    crushCell->structure->regions={cellRegion};for(unsigned a=0;a<8;++a)for(unsigned b=a+1;b<8;++b){StructuralBeam member;member.key="braced-cell-"+std::to_string(a)+"-"+std::to_string(b);member.a=a;member.b=b;member.area=.0003;crushCell->structure->beams.push_back(member);}
    check(PrepareDeformableAsset(*crushCell,error),"short braced 3D plastic crush cell prepares with the car's actual SI material law");
    struct CellResult {double initialEnergy=0,maximumEnergy=0,finalEnergy=0,maximumPinDrift=0,maximumDirectionTravel=0,plasticWork=0,finalMass=0,initialMass=0;unsigned broken=0;uint64_t contacts=0;bool healthy=true;std::string error;};
    auto offsetPlasticCell=[&](glm::dquat frame,V translation=V(0)){
        PhysicsWorld world;world.Init();const V origin=translation+frame*V(0,0,.0205),rearOrigin=origin+frame*V(0,0,.3);
        BodyTransform wallPose;wallPose.position=glm::vec3(translation+frame*V(-.15,0,0));wallPose.rotation=glm::quat(frame);world.CreateShape(Shape::Box({.1f,.4f,.005f}),wallPose,false,0,0,0);
        BodyTransform rearPose;rearPose.position=glm::vec3(rearOrigin);rearPose.rotation=glm::quat(frame);const auto rear=world.CreateShape(Shape::Box({.2f,.15f,.2f}),rearPose,true,500,0,0);world.SetCollisionFilter(rear,0,0);world.SetLinearVelocity(rear,glm::vec3(frame*V(0,0,-15)));
        DeformableSettings q;q.substeps=8;q.iterations=12;q.selfContact=false;q.material.density=7850;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableAttachment attachment;attachment.group="rear";attachment.kind=DeformableAttachment::Kind::Body;attachment.target=1;attachment.offset={0,0,-.3};q.attachments={attachment};
        DeformableInstance cell;cell.Initialize(crushCell,q,glm::translate(glm::dmat4(1),origin)*glm::mat4_cast(frame),600);for(auto& velocity:cell.velocities)velocity=frame*V(0,0,-15);
        CellResult result;result.initialMass=world.GetMass(rear)+cell.Mass();
        const auto components=[&](){std::array<double,8> part{};const V velocity(world.GetLinearVelocity(rear)),omega(world.GetAngularVelocity(rear));
            part[1]=.5*world.GetMass(rear)*glm::dot(velocity,velocity);part[2]=.5*glm::dot(omega,glm::dmat3(world.GetInertiaWorld(rear))*omega);part[7]=part[1]+part[2];
            for(unsigned n=0;n<cell.positions.size();++n){const double ke=.5*cell.NodeMass(n)*glm::dot(cell.velocities[n],cell.velocities[n]);part[0]+=ke;part[7]+=ke;}
            part[3]=cell.structure.ElasticEnergy(*crushCell->structure,cell.positions);part[4]=cell.structure.plasticWork;part[5]=cell.structure.fractureWork;part[6]=cell.structure.dampingWork;
            part[7]=part[7]+part[3]+part[4]+part[5]+part[6];return part;};
        const auto energy=[&](){return components()[7];};
        result.initialEnergy=result.maximumEnergy=energy();unsigned interval=0,completedIntervals=0;
        FILE* energyTrace=nullptr;if(const char* base=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE")){energyTrace=std::fopen((std::string(base)+".braced.csv").c_str(),"a");
            if(energyTrace&&std::ftell(energyTrace)==0)std::fputs("frame_w,frame_x,frame_y,frame_z,translation_x,translation_y,translation_z,completed_interval,macro,substep,node_ke_j,body_linear_ke_j,body_angular_ke_j,elastic_j,plastic_j,fracture_j,damping_j,total_j,input_j,nonlinear_residual,linear_residual,actual_pin_drift_m,reported_pin_drift_m,omega_x,omega_y,omega_z,broken,error\n",energyTrace);}
        DeformableTarget target;target.valid=true;target.body=rear;
        const auto sampleTarget=[&](float h){const auto current=world.GetTransform(rear),predicted=world.PredictTransform(rear,h);target.previous=glm::translate(glm::dmat4(1),V(current.position))*glm::mat4_cast(glm::dquat(current.rotation));target.current=glm::translate(glm::dmat4(1),V(predicted.position))*glm::mat4_cast(glm::dquat(predicted.rotation));};
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){world.PreparePredictedBody(rear,h);sampleTarget(h);cell.BeginStructuralInterval(h,world,zero,{target},interval==0,true);};
        coupling.solve=[&](float h,unsigned){sampleTarget(h);cell.SolveStructuralContacts(h,world,{target});sampleTarget(h);cell.SolveStructuralIteration(h,world,{target});};
        coupling.finish=[&](float h){cell.EndStructuralInterval(h,world,interval==7);result.maximumEnergy=std::max(result.maximumEnergy,energy());result.maximumPinDrift=std::max(result.maximumPinDrift,cell.structure.maximumPinDrift);
            ++completedIntervals;if(energyTrace){const auto part=components();const auto pose=world.GetTransform(rear);const V omega(world.GetAngularVelocity(rear));double pinDrift=0;
                for(auto n:crushCell->groups.at("rear"))pinDrift=std::max(pinDrift,glm::length(cell.positions[n]-(V(pose.position)+glm::dquat(pose.rotation)*(crushCell->nodes[n]+attachment.offset))));
                unsigned broken=0;for(auto value:cell.structure.broken)broken+=value!=0;
                std::fprintf(energyTrace,"%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%u,%u,%u,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%u,%s\n",frame.w,frame.x,frame.y,frame.z,translation.x,translation.y,translation.z,completedIntervals,(completedIntervals-1)/8,interval,part[0],part[1],part[2],part[3],part[4],part[5],part[6],part[7],result.initialEnergy,cell.structure.nonlinearResidual,cell.structure.linearResidual,pinDrift,cell.structure.maximumPinDrift,omega.x,omega.y,omega.z,broken,cell.error.c_str());std::fflush(energyTrace);}
            for(const auto& beam:crushCell->structure->beams){const V current=cell.positions[beam.b]-cell.positions[beam.a];if(glm::length(current)>1e-12){const V initial=frame*(crushCell->nodes[beam.b]-crushCell->nodes[beam.a]);result.maximumDirectionTravel=std::max(result.maximumDirectionTravel,glm::length(glm::normalize(current)-glm::normalize(initial)));}}};
        for(unsigned macro=0;macro<4;++macro){world.StepCoupled(1.f/60,8,[&](float,unsigned i){interval=i;},{},&coupling);result.contacts+=cell.stats.contacts;if(!cell.error.empty()){result.healthy=false;result.error=cell.error;break;}}
        result.finalEnergy=energy();result.plasticWork=cell.structure.plasticWork;result.finalMass=world.GetMass(rear)+cell.Mass();for(auto value:cell.structure.broken)result.broken+=value!=0;
        std::printf("BRACED_PLASTIC_CELL speed=15 dt=1/480 iterations=12 intervals=32 frame=(%.9g,%.9g,%.9g,%.9g) translation=(%.9g,%.9g,%.9g) inputEnergy=%.9g maximumAccountedEnergy=%.9g finalAccountedEnergy=%.9g createdEnergy=%.9g plasticWork=%.9g maximumPinDrift=%.9g directionTravel=%.9g broken=%u contacts=%llu massError=%.9g error=%s\n",frame.w,frame.x,frame.y,frame.z,translation.x,translation.y,translation.z,result.initialEnergy,result.maximumEnergy,result.finalEnergy,result.maximumEnergy-result.initialEnergy,result.plasticWork,result.maximumPinDrift,result.maximumDirectionTravel,result.broken,(unsigned long long)result.contacts,result.finalMass-result.initialMass,result.error.c_str());
        if(energyTrace)std::fclose(energyTrace);
        world.Shutdown();return result;
    };
    const auto straightFrameCell=offsetPlasticCell(identity),obliqueFrameCell=offsetPlasticCell(orientation),translatedFrameCell=offsetPlasticCell(identity,V(125,125,125));
    const auto physicalCell=[](const CellResult& result){return result.healthy&&result.contacts>0&&result.maximumDirectionTravel>.01&&result.plasticWork>0&&result.maximumPinDrift<.001&&result.finalMass==result.initialMass&&result.maximumEnergy<=result.initialEnergy*1.01+1;};
    check(physicalCell(straightFrameCell),"offset contact physically bends and plastically loads a finite 3D steel cell without more than 1 percent unexplained energy or stale pin geometry");
    check(physicalCell(obliqueFrameCell),"the same rotating-member plastic energy and actual-pin contract holds for an arbitrarily oriented 3D cell");

    check(physicalCell(translatedFrameCell),"the exact same 15 m/s steel cell retains the unchanged energy and actual-pin bounds at125 m coordinates");

    // Public shape casts intentionally return float result vectors. Native
    // local-frame discovery must not feed a rounded far-world witness back as
    // a shifted material plane. Exercise the real dispatcher both ways.
    {
        const Shape wall=Shape::Box({.1f,.4f,.005f}),sphere=Shape::Sphere(.015f);const V centre(125,125,125);
        RigidBody localBody,worldBody;localBody.position=glm::vec3(0);worldBody.position=glm::vec3(centre);
        const auto localPrimitive=PrimitiveAt(wall,localBody,0),worldPrimitive=PrimitiveAt(wall,worldBody,0);
        BodyTransform localStart,worldStart;localStart.position={0,0,.03f};worldStart.position=glm::vec3(centre+V(0,0,.03));
        const auto localHit=CastAgainstPrimitive(sphere,localStart,{0,0,-1},.1,localPrimitive),worldHit=CastAgainstPrimitive(sphere,worldStart,{0,0,-1},.1,worldPrimitive);
        const double localPlaneError=std::abs(double(localHit.point.z)-double(wall.halfExtents.z));
        const double aliasedWorldPlaneError=std::abs(double(worldHit.point.z)-centre.z-double(wall.halfExtents.z));
        std::printf("NATIVE_CAST_WITNESS_FRAME centre=125 localPlaneError=%.17g globalFloatWitnessAlias=%.17g localHit=%d worldHit=%d\n",localPlaneError,aliasedWorldPlaneError,localHit.hit,worldHit.hit);
        check(localHit.hit&&worldHit.hit&&localPlaneError<1e-12&&aliasedWorldPlaneError>1e-6,"native body-local cast preserves the actual authored plane while the same far-world float witness demonstrates the rounding negative control");
    }

    // A stress-free stiff cell has no power source. Repeat the actual shared
    // finite-pin interval at the origin and far from it; a rounded endpoint
    // must not produce a fictitious preload, plasticity, or accumulating work.
    auto quietPinnedCell=[&](glm::dquat frame,V translation){
        PhysicsWorld world;world.Init();BodyTransform bodyPose;bodyPose.position=glm::vec3(translation+frame*V(0,0,.3));bodyPose.rotation=glm::quat(frame);
        const auto rear=world.CreateShape(Shape::Box({.2f,.15f,.2f}),bodyPose,true,500,0,0);world.SetCollisionFilter(rear,0,0);
        const auto authored=world.GetTransform(rear);const glm::dquat placedRotation(authored.rotation);
        const V placedOrigin=V(authored.position)+placedRotation*V(0,0,-.3);
        DeformableSettings q;q.substeps=8;q.iterations=12;q.selfContact=false;q.collisionMask=0;q.material.density=7850;q.material.damping=q.material.friction=0;
        DeformableAttachment attachment;attachment.group="rear";attachment.kind=DeformableAttachment::Kind::Body;attachment.target=1;attachment.offset={0,0,-.3};q.attachments={attachment};
        DeformableInstance cell;cell.Initialize(crushCell,q,glm::translate(glm::dmat4(1),placedOrigin)*glm::mat4_cast(placedRotation),601);
        const auto initialPositions=cell.positions;const auto initialRest=cell.structure.restLengths;double maximumEnergy=0,maximumPin=0,maximumDrift=0;unsigned interval=0;
        const auto energy=[&](){const V v(world.GetLinearVelocity(rear)),w(world.GetAngularVelocity(rear));double value=.5*world.GetMass(rear)*glm::dot(v,v)+.5*glm::dot(w,glm::dmat3(world.GetInertiaWorld(rear))*w);
            for(unsigned n=0;n<cell.positions.size();++n)value+=.5*cell.NodeMass(n)*glm::dot(cell.velocities[n],cell.velocities[n]);
            return value+cell.structure.ElasticEnergy(*crushCell->structure,cell.positions)+cell.structure.plasticWork+cell.structure.fractureWork+cell.structure.dampingWork;};
        const double initialEnergy=energy();DeformableTarget target;target.valid=true;target.body=rear;
        const auto sampleTarget=[&](float h){const auto current=world.GetTransform(rear),predicted=world.PredictTransform(rear,h);target.previous=glm::translate(glm::dmat4(1),V(current.position))*glm::mat4_cast(glm::dquat(current.rotation));target.current=glm::translate(glm::dmat4(1),V(predicted.position))*glm::mat4_cast(glm::dquat(predicted.rotation));};
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){world.PreparePredictedBody(rear,h);sampleTarget(h);cell.BeginStructuralInterval(h,world,zero,{target},interval==0,true);};
        coupling.solve=[&](float h,unsigned){sampleTarget(h);cell.SolveStructuralContacts(h,world,{target});cell.SolveStructuralIteration(h,world,{target});};
        coupling.finish=[&](float h){cell.EndStructuralInterval(h,world,interval==7);maximumEnergy=std::max(maximumEnergy,energy());
            const auto pose=world.GetTransform(rear);for(auto n:crushCell->groups.at("rear"))maximumPin=std::max(maximumPin,glm::length(cell.positions[n]-(V(pose.position)+glm::dquat(pose.rotation)*(crushCell->nodes[n]+attachment.offset))));
            for(unsigned n=0;n<cell.positions.size();++n)maximumDrift=std::max(maximumDrift,glm::length(cell.positions[n]-initialPositions[n]));};
        for(unsigned macro=0;macro<6&&cell.error.empty();++macro)world.StepCoupled(1.f/60,8,[&](float,unsigned i){interval=i;},{},&coupling);
        unsigned broken=0;for(auto value:cell.structure.broken)broken+=value!=0;
        const bool unchangedHistory=cell.structure.restLengths==initialRest&&cell.structure.plasticWork==0&&cell.structure.fractureWork==0&&cell.structure.dampingWork==0;
        std::printf("QUIET_PINNED_STEEL intervals=48 dt=1/480 iterations=12 translation=(%.9g,%.9g,%.9g) frame=(%.9g,%.9g,%.9g,%.9g) initialEnergy=%.12g maximumEnergy=%.12g actualPinDrift=%.12g geometricDrift=%.12g plasticWork=%.12g broken=%u unchangedHistory=%d error=%s\n",translation.x,translation.y,translation.z,frame.w,frame.x,frame.y,frame.z,initialEnergy,maximumEnergy,maximumPin,maximumDrift,cell.structure.plasticWork,broken,unchangedHistory,cell.error.c_str());
        const bool pass=cell.error.empty()&&broken==0&&unchangedHistory&&maximumPin<.001&&maximumDrift<1e-6&&maximumEnergy<=initialEnergy+1e-6;world.Shutdown();return pass;
    };
    check(quietPinnedCell(identity,V(0)),"repeated stiff finite-pin intervals stay quiet without invented plasticity or energy at the origin");
    check(quietPinnedCell(identity,V(125,125,125)),"repeated stiff finite-pin intervals stay quiet at125 m without an endpoint-rounding preload");

    // A closed off-centre collision with an isotropic finite cube isolates
    // contact-wrench history from angular-inertia transport and rear pins.
    // The same physical skin and SI masses are tested with zero / nonzero spin
    // and with the entire setup rotated. No gravity, friction, or power source
    // can explain angular momentum or energy appearing in this interval.
    auto rotatingPatch=std::make_shared<DeformableAsset>();rotatingPatch->kind=DeformableKind::Structure;rotatingPatch->structure=std::make_shared<StructuralCook>();
    rotatingPatch->nodes={{.15,.04,0},{.20,.04,0}};StructuralRegion contactMember;contactMember.key="finite contact witness";contactMember.youngModulus=1000;contactMember.damping=0;
    contactMember.tensionYield=contactMember.compressionYield=1e12;contactMember.tensionUltimate=contactMember.compressionUltimate=1e13;
    rotatingPatch->structure->regions={contactMember};StructuralBeam contactBeam;contactBeam.key="finite contact member";contactBeam.a=0;contactBeam.b=1;contactBeam.area=.001;rotatingPatch->structure->beams={contactBeam};
    check(PrepareDeformableAsset(*rotatingPatch,error),"finite rotating-contact angular-momentum fixture prepares with isotropic rigid inertia");
    struct RotatingContactResult {V initialLinear{0},finalLinear{0},initialAngular{0},finalAngular{0};double initialEnergy=0,finalEnergy=0,normalTravel=0,pointTravel=0;uint64_t contacts=0;bool healthy=false;std::string error;};
    auto rotatingContact=[&](glm::dquat frame,double spin){
        PhysicsWorld world;world.Init();BodyTransform bodyPose;bodyPose.rotation=glm::quat(frame);const Shape box=Shape::Box({.25f,.25f,.25f});
        const auto body=world.CreateShape(box,bodyPose,true,20,0,0);world.SetAngularVelocity(body,glm::vec3(frame*V(0,spin,0)));
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=10000;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance patch;patch.Initialize(rotatingPatch,q,glm::translate(glm::dmat4(1),frame*V(0,0,.2705))*glm::mat4_cast(frame),650);for(auto& velocity:patch.velocities)velocity=frame*V(1.5,0,-12);
        RotatingContactResult result;
        const auto measure=[&](V& linear,V& angular,double& energy){const V centre(world.GetCenterOfMass(body)),v(world.GetLinearVelocity(body)),omega(world.GetAngularVelocity(body));const glm::dmat3 inertia(world.GetInertiaWorld(body));
            linear=v*double(world.GetMass(body));angular=glm::cross(centre,linear)+inertia*omega;energy=.5*world.GetMass(body)*glm::dot(v,v)+.5*glm::dot(omega,inertia*omega);
            for(unsigned n=0;n<patch.positions.size();++n){const V momentum=patch.velocities[n]*patch.NodeMass(n);linear+=momentum;angular+=glm::cross(patch.positions[n],momentum);energy+=.5*patch.NodeMass(n)*glm::dot(patch.velocities[n],patch.velocities[n]);}
            energy+=patch.structure.ElasticEnergy(*rotatingPatch->structure,patch.positions)+patch.structure.plasticWork+patch.structure.fractureWork+patch.structure.dampingWork;
        };
        measure(result.initialLinear,result.initialAngular,result.initialEnergy);
        const V initialRigidSpin=glm::dmat3(world.GetInertiaWorld(body))*V(world.GetAngularVelocity(body));
        RigidBody beforeBody;beforeBody.position=bodyPose.position;beforeBody.orientation=bodyPose.rotation;const auto beforePrimitive=PrimitiveAt(box,beforeBody,0);std::vector<GeometryDistance> beforeDistance;for(auto point:patch.positions)beforeDistance.push_back(PointGeometry(point,beforePrimitive));
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;coupling.begin=[&](float h){patch.BeginStructuralInterval(h,world,zero,{},true,true);};
        coupling.solve=[&](float h,unsigned){patch.SolveStructuralContacts(h,world,{});patch.SolveStructuralIteration(h,world,{});};coupling.finish=[&](float h){patch.EndStructuralInterval(h,world,true);};world.Step(1.f/480,&coupling);
        measure(result.finalLinear,result.finalAngular,result.finalEnergy);result.healthy=patch.error.empty();result.error=patch.error;result.contacts=patch.stats.contacts;
        const auto afterPose=world.GetTransform(body);RigidBody afterBody;afterBody.position=afterPose.position;afterBody.orientation=afterPose.rotation;const auto afterPrimitive=PrimitiveAt(box,afterBody,0);
        for(unsigned n=0;n<patch.positions.size();++n){const auto after=PointGeometry(patch.positions[n],afterPrimitive);if(beforeDistance[n].valid&&after.valid){result.normalTravel=std::max(result.normalTravel,glm::length(after.normal-beforeDistance[n].normal));result.pointTravel=std::max(result.pointTravel,glm::length(after.point-beforeDistance[n].point));}}
        // Backward Euler applies normal force at the interval END geometry,
        // whereas x1=x0+h*v1 gives orbital deltaL=x0 cross deltaP. Its discrete
        // angular term is therefore -h*(v_material_end-V_body_end) cross P.
        // Match the published real witness to this fixture's authored node /
        // edge sample and record matching error; retain the original strict
        // conservation assertion below rather than relabelling it a pass.
        V expectedBEDelta(0),witnessRigidMoment(0);double maximumWitnessMatch=0;const V bodyEndVelocity(world.GetLinearVelocity(body)),bodyEndCOM(world.GetCenterOfMass(body));
        FILE* angularTrace=nullptr;if(const char* base=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE")){angularTrace=std::fopen((std::string(base)+".angular.csv").c_str(),"a");if(angularTrace&&std::ftell(angularTrace)==0)std::fputs("frame_w,frame_x,frame_y,frame_z,spin,sample,weight_0,weight_1,witness_match_m,impulse_x,impulse_y,impulse_z,material_vx,material_vy,material_vz,body_vx,body_vy,body_vz,be_delta_x,be_delta_y,be_delta_z\n",angularTrace);}
        for(const auto& witness:patch.contactObservations)if(!witness.self&&witness.body.id==body.id&&witness.body.world==body.world){
            const V materialPoint=witness.point+witness.normal*q.material.thickness;const std::array<double,3> weights{1,0,.5};unsigned selected=0;double best=1e300;
            for(unsigned sample=0;sample<weights.size();++sample){const V candidate=patch.positions[0]*weights[sample]+patch.positions[1]*(1-weights[sample]);const double distance=glm::length(candidate-materialPoint);if(distance<best){best=distance;selected=sample;}}
            maximumWitnessMatch=std::max(maximumWitnessMatch,best);const double w=weights[selected];const V materialVelocity=patch.velocities[0]*w+patch.velocities[1]*(1-w),impulse=witness.normal*witness.normalImpulse;
            const V term=-double(1.f/480)*glm::cross(materialVelocity-bodyEndVelocity,impulse);expectedBEDelta+=term;witnessRigidMoment-=glm::cross(witness.point-bodyEndCOM,impulse);
            if(angularTrace)std::fprintf(angularTrace,"%.17g,%.17g,%.17g,%.17g,%.17g,%u,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n",frame.w,frame.x,frame.y,frame.z,spin,selected,w,1-w,best,impulse.x,impulse.y,impulse.z,materialVelocity.x,materialVelocity.y,materialVelocity.z,bodyEndVelocity.x,bodyEndVelocity.y,bodyEndVelocity.z,term.x,term.y,term.z);
        }
        if(angularTrace)std::fclose(angularTrace);
        const V observedDelta=result.finalAngular-result.initialAngular,rigidSpinChange=glm::dmat3(world.GetInertiaWorld(body))*V(world.GetAngularVelocity(body))-initialRigidSpin;
        std::printf("FINITE_CONTACT_BE_ANGULAR spin=%.9g frame=(%.9g,%.9g,%.9g,%.9g) observed=(%.12g,%.12g,%.12g) expectedBE=(%.12g,%.12g,%.12g) unexplained=%.12g witnessMatch=%.12g rigidMomentError=%.12g nonlinearResidual=%.12g\n",spin,frame.w,frame.x,frame.y,frame.z,observedDelta.x,observedDelta.y,observedDelta.z,expectedBEDelta.x,expectedBEDelta.y,expectedBEDelta.z,glm::length(observedDelta-expectedBEDelta),maximumWitnessMatch,glm::length(rigidSpinChange-witnessRigidMoment),patch.structure.nonlinearResidual);
        std::printf("ROTATING_FINITE_CONTACT spin=%.9g dt=1/480 iterations=12 frame=(%.9g,%.9g,%.9g,%.9g) contacts=%llu linearError=%.9g angularError=%.9g inputAngular=%.9g inputEnergy=%.9g finalEnergy=%.9g normalTravel=%.9g pointTravel=%.9g error=%s\n",spin,frame.w,frame.x,frame.y,frame.z,(unsigned long long)result.contacts,glm::length(result.finalLinear-result.initialLinear),glm::length(result.finalAngular-result.initialAngular),glm::length(result.initialAngular),result.initialEnergy,result.finalEnergy,result.normalTravel,result.pointTravel,result.error.c_str());
        world.Shutdown();return result;
    };
    const auto stationaryContact=rotatingContact(identity,0),spinningContact=rotatingContact(identity,30),obliqueSpinningContact=rotatingContact(orientation,30);
    const auto closedContact=[](const RotatingContactResult& result){return result.healthy&&result.contacts>0&&glm::length(result.finalLinear-result.initialLinear)<1e-3&&glm::length(result.finalAngular-result.initialAngular)<=.001*std::max(1.,glm::length(result.initialAngular))&&result.finalEnergy<=result.initialEnergy*1.01+.01;};
    check(closedContact(stationaryContact),"stationary finite off-centre contact preserves closed linear/angular momentum without an external energy source");
    check(closedContact(spinningContact)&&spinningContact.normalTravel>.01&&spinningContact.pointTravel>.001,"a genuinely moving finite contact witness preserves angular ownership as its normal and lever change");
    check(closedContact(obliqueSpinningContact)&&obliqueSpinningContact.normalTravel>.01&&obliqueSpinningContact.pointTravel>.001,"the same finite contact angular ownership holds after rotating the entire physical setup");

    // The legacy cross-instance material projector is external to each
    // participant's own anchored BE force balance. Two independent finite
    // sheets must keep its real equal/opposite impulse instead of each block
    // silently returning to its pre-contact free predictor.
    auto pairedSheet=std::make_shared<DeformableAsset>();pairedSheet->kind=DeformableKind::Structure;pairedSheet->structure=std::make_shared<StructuralCook>();
    pairedSheet->nodes={{-.2,-.1,0},{.2,-.1,0},{0,.2,0}};StructuralRegion pairedMaterial;pairedMaterial.key="external sheet";pairedMaterial.youngModulus=1000;pairedMaterial.damping=0;
    pairedMaterial.tensionYield=pairedMaterial.compressionYield=1e12;pairedMaterial.tensionUltimate=pairedMaterial.compressionUltimate=1e13;pairedSheet->structure->regions={pairedMaterial};
    for(auto ends:{glm::uvec2(0,1),glm::uvec2(1,2),glm::uvec2(2,0)}){StructuralBeam beam;beam.key="sheet-edge-"+std::to_string(pairedSheet->structure->beams.size());beam.a=ends.x;beam.b=ends.y;beam.area=.001;pairedSheet->structure->beams.push_back(beam);}
    pairedSheet->triangles={{0,1,2}};pairedSheet->structure->surfaceRegions={0};pairedSheet->structure->surfaceSupports={{0,1,2}};
    check(PrepareDeformableAsset(*pairedSheet,error),"two independent structural sheets prepare for external-contact ownership proof");
    struct PairResult {V momentum{0},com{0};double separation=0;uint64_t contacts=0;bool healthy=false;};
    auto pairedContact=[&](glm::dquat frame,bool collide){
        PhysicsWorld world;world.Init();DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=1000;q.material.damping=q.material.friction=0;q.material.thickness=.015;if(!collide)q.collisionMask=0;
        DeformableInstance upper,lower;upper.Initialize(pairedSheet,q,glm::translate(glm::dmat4(1),frame*V(0,0,.01))*glm::mat4_cast(frame),700);lower.Initialize(pairedSheet,q,glm::translate(glm::dmat4(1),frame*V(0,0,-.01))*glm::mat4_cast(frame),701);
        V initialCOM(0);double total=0;for(auto* instance:{&upper,&lower})for(unsigned n=0;n<instance->positions.size();++n){initialCOM+=instance->positions[n]*instance->NodeMass(n);total+=instance->NodeMass(n);}initialCOM/=total;
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){upper.BeginStructuralInterval(h,world,zero,{},true,true);lower.BeginStructuralInterval(h,world,zero,{},true,true);};
        coupling.solve=[&](float h,unsigned){upper.SolveStructuralContacts(h,world,{});lower.SolveStructuralContacts(h,world,{});DeformableInstance::SurfaceContacts(upper,lower,h);upper.SolveStructuralIteration(h,world,{});lower.SolveStructuralIteration(h,world,{});};
        coupling.finish=[&](float h){upper.EndStructuralInterval(h,world,true);lower.EndStructuralInterval(h,world,true);};world.Step(1.f/240,&coupling);
        PairResult result;result.healthy=upper.error.empty()&&lower.error.empty();result.contacts=upper.stats.contacts+lower.stats.contacts;V centres[2]={V(0),V(0)};unsigned index=0;
        for(auto* instance:{&upper,&lower}){for(unsigned n=0;n<instance->positions.size();++n){result.momentum+=instance->velocities[n]*instance->NodeMass(n);result.com+=instance->positions[n]*instance->NodeMass(n);centres[index]+=instance->positions[n]*instance->NodeMass(n);}centres[index]/=instance->Mass();++index;}
        result.com=result.com/total-initialCOM;result.separation=glm::dot(centres[0]-centres[1],frame*V(0,0,1));
        std::printf("EXTERNAL_MATERIAL_CONTACT enabled=%d frame=(%.9g,%.9g,%.9g,%.9g) contacts=%llu separation=%.9g momentumError=%.9g comError=%.9g errors=(%s,%s)\n",collide,frame.w,frame.x,frame.y,frame.z,(unsigned long long)result.contacts,result.separation,glm::length(result.momentum),glm::length(result.com),upper.error.c_str(),lower.error.c_str());
        world.Shutdown();return result;
    };
    const auto materialPair=pairedContact(identity,true),obliqueMaterialPair=pairedContact(orientation,true),filteredMaterialPair=pairedContact(identity,false);
    check(materialPair.healthy&&materialPair.contacts>0&&materialPair.separation>.021&&glm::length(materialPair.momentum)<1e-8&&glm::length(materialPair.com)<1e-10,"independent BE participants retain external equal/opposite material contact without undoing separation");
    check(obliqueMaterialPair.healthy&&obliqueMaterialPair.contacts>0&&obliqueMaterialPair.separation>.021&&glm::length(obliqueMaterialPair.momentum)<1e-8&&glm::length(obliqueMaterialPair.com)<1e-10,"external material contact ownership remains conservative when the whole two-sheet setup is rotated");
    check(filteredMaterialPair.healthy&&filteredMaterialPair.contacts==0&&std::abs(filteredMaterialPair.separation-.02)<1e-10&&glm::length(filteredMaterialPair.momentum)<1e-8,"reciprocal filtering leaves the same unsupported pair calm and unseparated");

    // Exercise the dense-operator row envelope using only valid public shape
    // content: each ordinary compound has the supported maximum64 children.
    // Eleven finite sets of three actual node/edge samples produce2112 rows,
    // so failure must precede the count-squared Gram allocation and material
    // acceptance. No internal contact vector is injected by this fixture.
    auto contactRowEnvelope=[&](unsigned bodies){
        PhysicsWorld world;world.Init();std::vector<CompoundBox> children(64,CompoundBox({0,0,0},{1,1,.005f}));
        BodyTransform pose;for(unsigned i=0;i<bodies;++i)world.CreateShape(Shape::Compound(children),pose,false,0,0,0);
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.density=1000;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance patch;patch.Initialize(translatingMember,q,glm::translate(glm::dmat4(1),V(0,0,.02)),800);for(auto& velocity:patch.velocities)velocity={0,0,-1};
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;coupling.begin=[&](float h){patch.BeginStructuralInterval(h,world,zero,{},true,true);};coupling.solve=[&](float h,unsigned){patch.SolveStructuralContacts(h,world,{});patch.SolveStructuralIteration(h,world,{});};coupling.finish=[&](float h){patch.EndStructuralInterval(h,world,true);};
        const auto rest=patch.structure.restLengths,plastic=patch.structure.accumulatedPlasticStrain;const auto broken=patch.structure.broken;const V initialMomentum=V(0,0,-patch.Mass());world.Step(1.f/240,&coupling);
        V finalMomentum(0),reaction(0);for(unsigned n=0;n<patch.positions.size();++n)finalMomentum+=patch.velocities[n]*patch.NodeMass(n);for(const auto& witness:patch.contactObservations)reaction+=witness.normal*witness.normalImpulse;const double momentumError=glm::length(finalMomentum-initialMomentum-reaction);
        const bool healthy=patch.error.empty(),historyUnchanged=patch.structure.restLengths==rest&&patch.structure.accumulatedPlasticStrain==plastic&&patch.structure.broken==broken&&patch.structure.plasticWork==0&&patch.structure.fractureWork==0;
        std::printf("STRUCTURAL_CONTACT_ROW_ENVELOPE ordinaryBodies=%u childrenPerBody=64 authoredSamples=%zu expectedCollectedRows=%zu healthy=%d measuredPenetration=%.9g historyUnchanged=%d momentumError=%.9g error=%s\n",bodies,patch.asset->nodes.size()+patch.asset->edges.size(),size_t(bodies)*64*(patch.asset->nodes.size()+patch.asset->edges.size()),healthy,patch.stats.maximumPenetration,historyUnchanged,momentumError,patch.error.c_str());
        const bool pass=bodies==10?healthy&&patch.stats.contacts>0&&momentumError<1e-5:!healthy&&patch.error.find("2048-row")!=std::string::npos&&patch.stats.maximumPenetration>0&&historyUnchanged;world.Shutdown();return pass;
    };
    check(contactRowEnvelope(10),"actual1920-row valid redundant contact resolves with measured wall momentum within the dense-row envelope");
    check(contactRowEnvelope(11),"actual2112-row contact content stops explicitly before dense allocation or irreversible history acceptance");

    // The dense condensed-contact envelope is deliberate and must fail
    // explicitly, not silently ghost through a surface or soften the network.
    // The SAME 522-DOF graph must still use the general Schur solver when no
    // contact is present, including ordinary reciprocal collision filtering.
    auto large=std::make_shared<DeformableAsset>();large->kind=DeformableKind::Structure;large->structure=std::make_shared<StructuralCook>();StructuralRegion largeRegion;
    largeRegion.key="bounded contact envelope";largeRegion.youngModulus=1e6;largeRegion.damping=0;largeRegion.tensionYield=largeRegion.compressionYield=1e8;largeRegion.tensionUltimate=largeRegion.compressionUltimate=1e9;large->structure->regions={largeRegion};
    for(unsigned n=0;n<174;++n){large->nodes.emplace_back((double(n)-86.5)*.001,0,0);if(n){StructuralBeam beam;beam.key="large-member-"+std::to_string(n);beam.a=n-1;beam.b=n;beam.area=.001;large->structure->beams.push_back(beam);}}
    check(PrepareDeformableAsset(*large,error),"522-DOF structure prepares within the ordinary authored network envelope");
    struct EnvelopeResult {bool healthy=false,historyUnchanged=false;std::string error;double penetration=0,movement=0,initialExtension=0,finalExtension=0;size_t candidates=0;};
    auto contactEnvelope=[&](double height,bool allowed){
        PhysicsWorld world;world.Init();const auto wall=world.CreateStaticBox({0,0,0},{1,1,.005f},0,0);if(!allowed)world.SetCollisionFilter(wall,0,0);
        DeformableSettings q;q.substeps=1;q.iterations=12;q.selfContact=false;q.material.damping=q.material.friction=0;q.material.thickness=.015;
        DeformableInstance network;network.Initialize(large,q,glm::translate(glm::dmat4(1),V(0,0,height)),550);network.positions.back().x+=.0002;for(auto& velocity:network.velocities)velocity={1,0,0};
        const auto before=network.positions;const auto rest=network.structure.restLengths;PhysicsWorld::VelocityCoupling coupling;coupling.iterations=q.iterations;
        coupling.begin=[&](float h){network.BeginStructuralInterval(h,world,zero,{},true,true);};
        coupling.solve=[&](float h,unsigned){network.SolveStructuralContacts(h,world,{});network.SolveStructuralIteration(h,world,{});};
        coupling.finish=[&](float h){network.EndStructuralInterval(h,world,true);};world.Step(1.f/240,&coupling);
        EnvelopeResult result;result.healthy=network.error.empty();result.error=network.error;result.penetration=network.stats.maximumPenetration;result.candidates=network.stats.candidates;
        double totalMass=0;for(unsigned n=0;n<network.positions.size();++n){totalMass+=network.NodeMass(n);result.movement+=(network.positions[n].x-before[n].x)*network.NodeMass(n);}result.movement/=totalMass;
        for(unsigned i=0;i<large->structure->beams.size();++i){const auto& beam=large->structure->beams[i];result.initialExtension=std::max(result.initialExtension,std::abs(glm::length(before[beam.b]-before[beam.a])-beam.restLength));result.finalExtension=std::max(result.finalExtension,std::abs(glm::length(network.positions[beam.b]-network.positions[beam.a])-beam.restLength));}
        result.historyUnchanged=network.structure.restLengths==rest&&network.structure.plasticWork==0&&network.structure.fractureWork==0&&std::none_of(network.structure.broken.begin(),network.structure.broken.end(),[](uint8_t value){return value!=0;});
        std::printf("STRUCTURAL_CONTACT_ENVELOPE dimensions=522 height=%.9g allowed=%d healthy=%d candidates=%zu measuredPenetration=%.9g comDisplacement=%.9g initialExtension=%.9g finalExtension=%.9g historyUnchanged=%d error=%s\n",height,allowed,result.healthy,result.candidates,result.penetration,result.movement,result.initialExtension,result.finalExtension,result.historyUnchanged,result.error.c_str());
        world.Shutdown();return result;
    };
    const auto awayEnvelope=contactEnvelope(2,true),filteredEnvelope=contactEnvelope(.005,false),unsupportedEnvelope=contactEnvelope(.005,true);
    check(awayEnvelope.healthy&&awayEnvelope.historyUnchanged&&std::abs(awayEnvelope.movement-double(1.f/240))<1e-8&&awayEnvelope.penetration==0&&awayEnvelope.finalExtension<awayEnvelope.initialExtension*.9,"a structure above the condensed dimension bound resolves real elastic strain while preserving free COM motion through the general solver");
    check(filteredEnvelope.healthy&&filteredEnvelope.historyUnchanged&&filteredEnvelope.candidates>0&&filteredEnvelope.penetration==0&&std::abs(filteredEnvelope.movement-double(1.f/240))<1e-8&&filteredEnvelope.finalExtension<filteredEnvelope.initialExtension*.9,"the same strained large graph respects reciprocal filtering without falsely entering the condensed-contact envelope");
    check(!unsupportedEnvelope.healthy&&unsupportedEnvelope.historyUnchanged&&unsupportedEnvelope.penetration>0&&unsupportedEnvelope.error.find("condensed structural contacts")!=std::string::npos&&unsupportedEnvelope.error.find("512")!=std::string::npos,"actual unsupported large-graph contact stops explicitly without publishing plasticity or silently falling back to ghosting");
    std::printf("CHECKS %d FAILURES %d\n",checks,failures);physics.Shutdown();return failures?1:0;
}
