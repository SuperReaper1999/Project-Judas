#include "Deformable.h"
#include "SaveArchive.h"
#include "UniformGravity.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <cstdio>
#include <set>
#include <glm/gtc/matrix_transform.hpp>

namespace {
using V=glm::dvec3;
int checks=0,failures=0;
void Check(bool ok,const char* message){++checks;if(!ok)++failures;std::printf("%s %s\n",ok?"PASS":"FAIL",message);}
std::shared_ptr<DeformableAsset> SingleBeam(){
    auto a=std::make_shared<DeformableAsset>();a->kind=DeformableKind::Structure;a->structure=std::make_shared<StructuralCook>();
    a->nodes={{0,0,0},{1,0,0}};a->groups={{"left",{0}},{"right",{1}}};
    StructuralRegion r;r.key="bar";r.youngModulus=1e8;r.damping=50;r.tensionYield=r.compressionYield=1e6;r.tensionUltimate=r.compressionUltimate=1e7;r.hardening=2e6;r.panelThickness=0;
    a->structure->regions={r};a->structure->beams={{"bar",0,1,0,.001,0}};
    std::string error;Check(PrepareDeformableAsset(*a,error),"one metre analytical beam prepares without fictitious solid volume");return a;
}
DeformableSettings Settings(unsigned substeps=4){DeformableSettings s;s.material.density=10000;s.material.damping=20;s.material.airDrag=0;s.collisionMask=0;s.selfContact=false;s.substeps=substeps;s.iterations=8;return s;}
std::shared_ptr<DeformableAsset> Truss(){
    auto a=std::make_shared<DeformableAsset>();a->kind=DeformableKind::Structure;a->structure=std::make_shared<StructuralCook>();auto& c=*a->structure;
    // The unchanged small-signal mass/stiffness reference has a 1.444 Hz
    // bending mode with 76.585% of strain energy in this protected section.
    // Its 400 N s/m damper gives modal zeta .07417 (target .075), while the
    // crush section retains 50 N s/m. This is objective member viscosity,
    // not a drag on the frame's translation or a substitute for its bracing.
    StructuralRegion cabin;cabin.key="protected";cabin.youngModulus=1e8;cabin.damping=400;cabin.tensionYield=cabin.compressionYield=1e8;cabin.tensionUltimate=cabin.compressionUltimate=2e8;cabin.panelThickness=0;
    StructuralRegion crush=cabin;crush.key="crush";crush.damping=50;crush.tensionYield=5e6;crush.compressionYield=4e5;crush.tensionUltimate=crush.compressionUltimate=1e7;crush.hardening=1e6;crush.maxShortening=.6;crush.maxExtension=.08;c.regions={cabin,crush};
    for(unsigned section=0;section<4;++section)for(unsigned corner=0;corner<4;++corner)a->nodes.push_back({section*.5,(corner&1)?.1:-.1,(corner&2)?.1:-.1});
    a->groups["left"]={0,1,2,3};a->groups["right"]={12,13,14,15};a->groups["upper"]={13,15};a->groups["lower"]={12,14};
    std::set<std::pair<unsigned,unsigned>> seen;
    for(unsigned cell=0;cell<3;++cell)for(unsigned i=cell*4;i<cell*4+8;++i)for(unsigned j=i+1;j<cell*4+8;++j)if(seen.insert({i,j}).second)c.beams.push_back({"member-"+std::to_string(c.beams.size()),i,j,cell==0?0u:1u,.0001,0});
    std::string error;Check(PrepareDeformableAsset(*a,error),"three hollow cells have complete shear and torsion bracing");return a;
}
double PlasticMaximum(const DeformableInstance& s,unsigned region){double value=0;for(unsigned i=0;i<s.asset->structure->beams.size();++i){const auto& b=s.asset->structure->beams[i];if(b.region==region)value=std::max(value,std::abs(s.structure.restLengths[i]-b.restLength));}return value;}
unsigned Broken(const DeformableInstance& s){return unsigned(std::count(s.structure.broken.begin(),s.structure.broken.end(),uint8_t(1)));}
V Momentum(const DeformableInstance& s){V value(0);for(unsigned n=0;n<s.positions.size();++n)value+=s.velocities[n]*s.NodeMass(n);return value;}
double Energy(const DeformableInstance& s){double value=s.structure.ElasticEnergy(*s.asset->structure,s.positions);for(unsigned n=0;n<s.positions.size();++n)value+=.5*s.NodeMass(n)*glm::dot(s.velocities[n],s.velocities[n]);return value;}
}

int main(){
    PhysicsWorld physics;physics.Init();UniformGravity zero({0,0,0});std::string error;
    auto bar=SingleBeam();auto config=Settings();DeformableAttachment pin;pin.group="left";config.attachments={pin};DeformableTarget fixed;fixed.valid=true;
    DeformableInstance elastic;elastic.Initialize(bar,config,glm::dmat4(1),1);
    Check(std::abs(elastic.Mass()-10)<1e-12,"mass is density times original area/length volume, unchanged by plastic shortening");
    for(unsigned step=0;step<120;++step){elastic.Force("right",{500,0,0});elastic.Step(1./60,physics,zero,{fixed});}
    const double extension=elastic.positions[1].x-1;
    std::printf("ELASTIC expected_m=.005 actual_m=%.12g rest_m=%.12g\n",extension,elastic.structure.restLengths[0]);
    Check(elastic.error.empty()&&std::abs(extension-.005)<.00025,"half-yield force matches independent F/k analytical extension");
    Check(elastic.structure.restLengths[0]==1&&Broken(elastic)==0,"ordinary tensile load produces no permanent rest change or failure");
    for(unsigned step=0;step<180;++step)elastic.Step(1./60,physics,zero,{fixed});
    Check(std::abs(elastic.positions[1].x-1)<.0005,"elastic load/unload recovers below half a millimetre");

    DeformableInstance yielding;yielding.Initialize(bar,config,glm::dmat4(1),2);
    for(unsigned step=0;step<18;++step){yielding.Force("right",{-1500,0,0});yielding.Step(1./60,physics,zero,{fixed});}
    const double shortened=1-yielding.structure.restLengths[0];
    Check(yielding.error.empty()&&shortened>.05&&Broken(yielding)==0&&yielding.structure.plasticWork>0,"compression overload consumes plastic work and shortens before ultimate failure");
    for(unsigned step=0;step<180;++step)yielding.Step(1./60,physics,zero,{fixed});
    std::printf("PLASTIC retained_m=%.12g shape_m=%.12g work_j=%.12g mass_kg=%.12g\n",shortened,1-yielding.positions[1].x,yielding.structure.plasticWork,yielding.Mass());
    Check(1-yielding.positions[1].x>.05&&std::abs(yielding.Mass()-10)<1e-12,"unloading retains crush with exact original mass");
    for(unsigned step=0;step<90&&Broken(yielding)==0;++step){yielding.Force("right",{20000,0,0});yielding.Step(1./60,physics,zero,{fixed});}
    Check(Broken(yielding)==1&&!yielding.ConnectedNodes({0},{1}),"ultimate overload irreversibly removes the actual beam load path");
    StructuralState energyLedger;energyLedger.Initialize(*bar->structure,2);auto stretched=bar->nodes;stretched[1].x+=.01;const double stored=energyLedger.ElasticEnergy(*bar->structure,stretched);energyLedger.pending[0]=1;const auto originalShape=stretched;energyLedger.Commit(*bar->structure,stretched);
    Check(std::abs(energyLedger.fractureWork-stored)<1e-12&&energyLedger.ElasticEnergy(*bar->structure,stretched)==0&&stretched==originalShape,"failure accounts actual disposed elastic energy without moving nodes");
    SaveArchive brokenSaved;yielding.Persist(brokenSaved);DeformableInstance brokenReload;brokenReload.Initialize(bar,config,glm::dmat4(1),40);SaveArchive brokenRead(brokenSaved.bytes);brokenReload.Persist(brokenRead);brokenRead.Finish();
    Check(brokenReload.structure.broken==yielding.structure.broken&&brokenReload.structure.revision==yielding.structure.revision&&brokenReload.structure.fractureWork==yielding.structure.fractureWork&&!brokenReload.ConnectedNodes({0},{1}),"cold structural state retains ultimate failure, disposal work and disconnected topology");

    // Internal damping acts on relative axial motion. It cannot steal the COM
    // momentum of an unstrained body moving through an empty world.
    auto freeConfig=Settings();DeformableInstance free;free.Initialize(bar,freeConfig,glm::dmat4(1),3);free.Impulse("",{30,20,-10});const V initialMomentum=Momentum(free);const double initialEnergy=Energy(free);
    for(unsigned step=0;step<120;++step)free.Step(1./60,physics,zero,{});
    Check(glm::length(Momentum(free)-initialMomentum)<1e-8&&std::abs(Energy(free)-initialEnergy)<1e-8,"relative member damping conserves uniform translation and energy");
    DeformableInstance oscillating;oscillating.Initialize(bar,freeConfig,glm::dmat4(1),4);oscillating.Impulse("right",{1,0,0});const V oscillatingMomentum=Momentum(oscillating);const double oscillatingEnergy=Energy(oscillating);double maximumEnergy=oscillatingEnergy;
    for(unsigned step=0;step<90;++step){oscillating.Step(1./60,physics,zero,{});maximumEnergy=std::max(maximumEnergy,Energy(oscillating));}
    Check(glm::length(Momentum(oscillating)-oscillatingMomentum)<1e-8&&Energy(oscillating)<oscillatingEnergy&&maximumEnergy<=oscillatingEnergy*1.001,"relative damper dissipates vibration without momentum loss or unexplained energy growth");

    auto truss=Truss();auto specimenConfig=Settings();specimenConfig.material.density=7850;specimenConfig.attachments={pin};
    for(unsigned mode=0;mode<3;++mode){DeformableInstance specimen;specimen.Initialize(truss,specimenConfig,glm::dmat4(1),10+mode);
        for(unsigned step=0;step<120;++step){if(mode==0)specimen.Force("right",{-50,0,0});if(mode==1)specimen.Force("right",{0,0,10});if(mode==2){specimen.Force("upper",{0,0,5});specimen.Force("lower",{0,0,-5});}specimen.Step(1./60,physics,zero,{fixed});}
        Check(specimen.error.empty()&&Broken(specimen)==0&&PlasticMaximum(specimen,0)<1e-12&&PlasticMaximum(specimen,1)<1e-12,"ordinary compression, bend or twist leaves all braced members elastic");
        for(unsigned step=0;step<180;++step)specimen.Step(1./60,physics,zero,{fixed});
        double residual=0;for(unsigned n=0;n<specimen.positions.size();++n)residual=std::max(residual,glm::length(specimen.positions[n]-truss->nodes[n]));
        std::printf("TRUSS mode=%u residual_m=%.12g\n",mode,residual);Check(residual<.001,"ordinary hollow frame unload residual stays below one millimetre");
    }
    const auto crush=[&](double dt,unsigned substeps,const glm::dmat4& frame,double* appliedWork=nullptr){auto s=specimenConfig;s.substeps=substeps;DeformableInstance specimen;specimen.Initialize(truss,s,frame,20);DeformableTarget support=fixed;support.previous=support.current=frame;const V load=glm::dmat3(frame)*V(-800,0,0);
        const auto forcePoint=[&](){V point(0);double mass=0;for(auto n:truss->groups.at("right")){point+=specimen.positions[n]*specimen.NodeMass(n);mass+=specimen.NodeMass(n);}return point/mass;};
        if(appliedWork)*appliedWork=0;
        for(unsigned step=0;step<unsigned(std::lround(.3/dt));++step){const V before=forcePoint();specimen.Force("right",load);specimen.Step(dt,physics,zero,{support});if(appliedWork)*appliedWork+=glm::dot(load,forcePoint()-before);}
        for(unsigned step=0;step<unsigned(std::lround(1./dt));++step)specimen.Step(dt,physics,zero,{support});
        return specimen;};
    double inputWork=0;auto baseline=crush(1./60,4,glm::dmat4(1),&inputWork);const auto rotatedFrame=glm::rotate(glm::dmat4(1),.7,glm::normalize(V(1,2,3)));auto rotated=crush(1./60,4,rotatedFrame);auto equalInterval=crush(1./120,2,glm::dmat4(1));auto finer=crush(1./60,8,glm::dmat4(1));
    const double retained=PlasticMaximum(baseline,1),protectedRest=PlasticMaximum(baseline,0);
    std::printf("CRUSH local_m=%.12g protected_m=%.12g broken=%u plastic_work_j=%.12g equal_h_m=%.12g fine_h_m=%.12g\n",retained,protectedRest,Broken(baseline),baseline.structure.plasticWork,PlasticMaximum(equalInterval,1),PlasticMaximum(finer,1));
    Check(baseline.error.empty()&&retained>.05&&protectedRest<.005&&Broken(baseline)==0,"local crush precedes fracture while the protected frame retains its authored rest");
    double rotationError=0;for(unsigned n=0;n<baseline.positions.size();++n)rotationError=std::max(rotationError,glm::length(glm::dmat3(rotatedFrame)*baseline.positions[n]-rotated.positions[n]));
    Check(rotated.error.empty()&&rotationError<1e-6,"constitutive response rotates with the specimen instead of a world-up axis");
    Check(equalInterval.error.empty()&&std::abs(PlasticMaximum(equalInterval,1)-retained)<.002,"equal internal timestep at sixty and one hundred twenty Hz preserves crush");
    Check(finer.error.empty()&&std::abs(PlasticMaximum(finer,1)-retained)<.02,"finer internal timestep changes local crush by less than twenty millimetres");
    const double accounted=Energy(baseline)+baseline.structure.plasticWork+baseline.structure.fractureWork+baseline.structure.dampingWork;
    std::printf("WORK input_j=%.12g retained_j=%.12g plastic_j=%.12g viscous_j=%.12g numerical_loss_j=%.12g\n",inputWork,Energy(baseline),baseline.structure.plasticWork,baseline.structure.dampingWork,inputWork-accounted);
    Check(inputWork>0&&baseline.structure.dampingWork>0&&accounted<=inputWork*1.01,"elastic/kinetic energy and physical dissipation do not exceed actual applied work");

    SaveArchive saved;baseline.Persist(saved);DeformableInstance restored;restored.Initialize(truss,specimenConfig,glm::dmat4(1),30);SaveArchive read(saved.bytes);restored.Persist(read);read.Finish();
    Check(restored.positions==baseline.positions&&restored.velocities==baseline.velocities&&restored.structure.restLengths==baseline.structure.restLengths&&restored.structure.broken==baseline.structure.broken&&restored.structure.plasticWork==baseline.structure.plasticWork&&restored.structure.fractureWork==baseline.structure.fractureWork&&restored.structure.dampingWork==baseline.structure.dampingWork,"snapshot exactly retains shape, velocity, physical work and structural topology");
    bool oldRejected=false;try{SaveArchive legacy;baseline.Persist(legacy,true,true,false);}catch(const std::exception&){oldRejected=true;}Check(oldRejected,"a structural participant cannot silently write the legacy state layout");
    // The car's metal-scale stiffness is the adversarial case the old scalar
    // Gauss-Seidel sweep did not cover. Compare constitutive geometry with the
    // solved force; swapping only ultimate evaluation to lambda cannot pass.
    auto stiff=std::make_shared<DeformableAsset>(*truss);stiff->structure=std::make_shared<StructuralCook>(*truss->structure);
    for(auto& region:stiff->structure->regions){region.youngModulus=2e11;region.damping=35;region.tensionYield=region.compressionYield=1e12;region.tensionUltimate=region.compressionUltimate=2e12;}
    Check(PrepareDeformableAsset(*stiff,error),"200 GPa braced compatibility fixture preserves authored topology and finite mass");
    auto stiffPositions=stiff->nodes;auto stiffStart=stiffPositions;std::vector<double> stiffWeights(stiffPositions.size());
    for(unsigned n=0;n<stiffPositions.size();++n){stiffWeights[n]=1/(stiff->measures[n]*7850);if(n<4)stiffWeights[n]=0;else stiffPositions[n].z-=.0001;}
    StructuralState compatible;compatible.Initialize(*stiff->structure,unsigned(stiffPositions.size()));compatible.BeginInterval(*stiff->structure,stiffStart);
    const double stiffH=1./240;
    for(unsigned outer=0;outer<8;++outer)compatible.Solve(*stiff->structure,stiffPositions,stiffWeights,stiffH);
    double forceMismatch=0,largestStress=0;
    for(unsigned i=0;i<stiff->structure->beams.size();++i){const auto& beam=stiff->structure->beams[i];const auto& material=stiff->structure->regions[beam.region];
        const double length=glm::length(stiffPositions[beam.b]-stiffPositions[beam.a]);
        const double stress=material.youngModulus*(length-beam.restLength)/beam.restLength;
        const double solved=-compatible.multipliers[i]/(stiffH*stiffH*beam.area)-material.damping*(length-beam.restLength)/(stiffH*beam.area);
        forceMismatch=std::max(forceMismatch,std::abs(stress-solved));largestStress=std::max(largestStress,std::abs(stress));
    }
    std::printf("STIFF_COMPATIBILITY max_stress_pa=%.12g mismatch_pa=%.12g pcg_iterations=%u residual=%.12g\n",largestStress,forceMismatch,compatible.linearIterations,compatible.linearResidual);
    Check(forceMismatch<1000&&compatible.linearIterations<=2*stiff->structure->beams.size()+8,"whole-network compatibility converges at metal stiffness without an invented geometric overload");
    compatible.AcceptInterval(*stiff->structure,stiffPositions,stiffH);
    Check(std::all_of(compatible.restLengths.begin(),compatible.restLengths.end(),[&,index=size_t(0)](double rest)mutable{return rest==stiff->structure->beams[index++].restLength;})&&std::none_of(compatible.pending.begin(),compatible.pending.end(),[](uint8_t value){return value!=0;}),"below-yield compatible structure neither plastically deforms nor marks ultimate failure");
    StructuralState ephemeral=compatible;ephemeral.precisionLimited=true;ephemeral.nonlinearRoundoffBound=1e-12;ephemeral.nonlinearResidual=5e-13;
    SaveArchive ephemeralBytes;ephemeral.Persist(ephemeralBytes,*stiff->structure,unsigned(stiff->nodes.size()));StructuralState coldDiagnostic;coldDiagnostic.Initialize(*stiff->structure,unsigned(stiff->nodes.size()));
    SaveArchive ephemeralRead(ephemeralBytes.bytes);coldDiagnostic.Persist(ephemeralRead,*stiff->structure,unsigned(stiff->nodes.size()));ephemeralRead.Finish();
    Check(!coldDiagnostic.precisionLimited&&coldDiagnostic.nonlinearRoundoffBound==0&&coldDiagnostic.nonlinearResidual==0&&coldDiagnostic.restLengths==ephemeral.restLengths,"cold material reconstruction preserves durable rest while discarding interval-only precision certificates");
    const auto precisionControl=[&](bool displace){PhysicsWorld world;world.Init();auto s=Settings(1);s.iterations=12;DeformableInstance member;member.Initialize(bar,s,glm::dmat4(1),displace?92:91);for(auto& v:member.velocities)v={4,0,0};
        const double h=double(1.f/240),delta=64*double(std::nextafter(4.f,std::numeric_limits<float>::infinity())-4.f)*h;bool firstCertificate=false;double correction=0;
        PhysicsWorld::VelocityCoupling coupling;coupling.iterations=12;coupling.begin=[&](float dt){member.BeginStructuralInterval(dt,world,zero,{},true,true);if(displace)member.positions[0].x+=delta;};
        coupling.solve=[&](float dt,unsigned round){const double before=member.positions[0].x;member.SolveStructuralContacts(dt,world,{});member.SolveStructuralIteration(dt,world,{});if(round==0){firstCertificate=member.structure.precisionLimited;correction=std::abs(member.positions[0].x-before);}};
        coupling.finish=[&](float dt){member.EndStructuralInterval(dt,world,true);};world.Step(float(h),&coupling);
        std::printf("PRECISION_CONTROL displace=%d delta_m=%.17g firstCertificate=%d firstCorrection=%.17g finalResidual=%.17g bound=%.17g error=%s\n",displace,delta,int(firstCertificate),correction,member.structure.nonlinearResidual,member.structure.nonlinearRoundoffBound,member.error.c_str());
        const bool pass=member.error.empty()&&(displace?(!firstCertificate&&correction>delta/4):firstCertificate);world.Shutdown();return pass;};
    Check(precisionControl(false),"a free uniform-translation root terminates at its measured binary64 arithmetic cell without inventing deformation");
    Check(precisionControl(true),"a representable sixty-four-native-velocity-ULP free displacement is corrected and cannot be waived as precision-limited");
    std::vector<double> redundantSolution;unsigned redundantIterations=0;double redundantResidual=0;
    const auto redundant=[](const std::vector<double>& x,std::vector<double>& y){y.assign(2,x[0]+x[1]);};
    Check(SolveStructuralSchur({1,1},{.002,.002},redundant,redundantSolution,redundantIterations,redundantResidual)&&std::abs(redundantSolution[0]+redundantSolution[1]-.002)<1e-12,"consistent redundant constraints solve without inventing regularization or mass");
    Check(!SolveStructuralSchur({1,1},{.002,-.002},redundant,redundantSolution,redundantIterations,redundantResidual),"incompatible singular constraint has an explicit bounded failure instead of silently repairing state");
    std::vector<double> primalFactor,primalSolution;unsigned primalIterations=0;double primalResidual=0;
    const double beamStiffness=100,beamResidual=-.01,pinResidual=.02;
    std::vector<double> twoRowSolution;unsigned twoRowIterations=0;double twoRowResidual=0;
    const auto twoRows=[](const std::vector<double>& x,std::vector<double>& y){y={1.51*x[0]-.5*x[1],-.5*x[0]+.502*x[1]};};
    const bool twoRowsSolved=SolveStructuralSchur({1.51,.502},{beamResidual,pinResidual},twoRows,twoRowSolution,twoRowIterations,twoRowResidual);
    const bool primalSolved=SolveStructuralPrimal({1+beamStiffness,-beamStiffness,-beamStiffness,502+beamStiffness},
        {beamStiffness*(beamResidual+pinResidual),-beamStiffness*(beamResidual+pinResidual)-2*pinResidual},primalFactor,primalSolution,primalIterations,primalResidual);
    Check(twoRowsSolved&&primalSolved&&std::abs(primalSolution[0]-twoRowSolution[0])<1e-12&&std::abs(primalSolution[1]+.002*twoRowSolution[1])<1e-12&&std::abs(primalSolution[1]+pinResidual-.5*(-twoRowSolution[0]+twoRowSolution[1]))<1e-12,
        "primal finite-pin elimination exactly matches the general Schur correction including a 500 kg body and 2 kg pin node");
    Check(SolveStructuralPrimal({201,-200,-200,702},{.25,-.29},primalFactor,primalSolution,primalIterations,primalResidual)&&primalResidual<1e-9&&std::abs(201*primalSolution[0]-200*primalSolution[1]-.25)<1e-9,
        "cached reference factor solves the changed positive matrix to its actual residual without changing stiffness");
    primalFactor.clear();Check(!SolveStructuralPrimal({1,2,2,1},{1,0},primalFactor,primalSolution,primalIterations,primalResidual),
        "non-positive primal operator is rejected rather than regularized or softened");
    const std::vector<double> stiffScalarMatrix={1e16},stiffScalarLoad={1e-5};std::vector<double> stiffScalarFactor,legacyScalarSolution,physicalScalarSolution;
    unsigned scalarIterations=0;double scalarResidual=0;StructuralPrimalSolver legacyScalar(stiffScalarMatrix,stiffScalarFactor);
    const bool oldScalarStopped=legacyScalar.Solve(stiffScalarLoad,legacyScalarSolution,scalarIterations,scalarResidual)&&legacyScalarSolution[0]==0;
    StructuralPrimalSolver physicalScalar(stiffScalarMatrix,stiffScalarFactor,nullptr,[](const std::vector<double>& value){return std::abs(value[0]);});
    const bool physicalScalarSolved=physicalScalar.Solve(stiffScalarLoad,physicalScalarSolution,scalarIterations,scalarResidual);
    Check(oldScalarStopped&&std::abs(stiffScalarLoad[0]-stiffScalarMatrix[0]*legacyScalarSolution[0])==1e-5,"old stiffness-diagonal stop demonstrably loses a nonzero physical load in a stiff operator");
    Check(physicalScalarSolved&&physicalScalarSolution[0]!=0&&std::abs(stiffScalarLoad[0]-stiffScalarMatrix[0]*physicalScalarSolution[0])<1e-11,"physical mass residual stopping solves the same stiff load without changing iterations or tolerance constants");
    StructuralPrimalSolver invalidMetric(stiffScalarMatrix,stiffScalarFactor,nullptr,[](const std::vector<double>&){return std::numeric_limits<double>::infinity();});
    Check(!invalidMetric.Solve(stiffScalarLoad,physicalScalarSolution,scalarIterations,scalarResidual),"an invalid physical residual metric fails explicitly instead of accepting infinity against infinity");
    StructuralPrimalTraversal retainedTraversal;std::vector<double> retainedFactor;
    const std::vector<double> referenceMatrix={201,-200,-200,702},changedMatrix={301,-300,-300,802};
    StructuralPrimalSolver firstPrepared(referenceMatrix,retainedFactor,&retainedTraversal);
    const bool firstPreparedPass=firstPrepared.Solve({.25,-.29},primalSolution,primalIterations,primalResidual);
    const auto savedLower=retainedTraversal.lowerValues;
    StructuralPrimalSolver nextPrepared(changedMatrix,retainedFactor,&retainedTraversal);
    const bool nextPreparedPass=nextPrepared.Solve({.25,-.29},primalSolution,primalIterations,primalResidual);
    const bool currentFactor=retainedFactor.size()==4&&std::abs(retainedFactor[0]*retainedFactor[0]-301)<1e-10&&std::abs(retainedFactor[0]*retainedFactor[2]+300)<1e-10&&std::abs(retainedFactor[2]*retainedFactor[2]+retainedFactor[3]*retainedFactor[3]-802)<1e-10;
    Check(firstPreparedPass&&nextPreparedPass&&currentFactor&&retainedTraversal.lowerValues!=savedLower&&std::abs(301*primalSolution[0]-300*primalSolution[1]-.25)<1e-9,
        "changed positive operator reconstructs its actual current Cholesky factor instead of retaining a stale preconditioner");
    const auto frozenFactor=retainedFactor,frozenTraversal=retainedTraversal.lowerValues;bool multipleCurrentRhs=true;
    for(const auto& expected:std::vector<std::vector<double>>{{1,2},{-.5,.25},{3,-1}}){const std::vector<double> load={301*expected[0]-300*expected[1],-300*expected[0]+802*expected[1]};
        multipleCurrentRhs&=nextPrepared.Solve(load,primalSolution,primalIterations,primalResidual)&&primalIterations==1&&primalResidual<1e-9&&std::abs(primalSolution[0]-expected[0])<1e-11&&std::abs(primalSolution[1]-expected[1])<1e-11&&retainedFactor==frozenFactor&&retainedTraversal.lowerValues==frozenTraversal;}
    Check(multipleCurrentRhs,"multiple independent right-hand sides reuse one frozen current factor and retain the unchanged actual residual certificate");
    const std::vector<double> indefiniteCurrent={1,2,2,1};StructuralPrimalSolver newlyIndefinite(indefiniteCurrent,retainedFactor,&retainedTraversal);
    Check(!newlyIndefinite.Solve({1,0},primalSolution,primalIterations,primalResidual),"a retained positive factor cannot disguise a new same-sized indefinite operator");
    retainedFactor.clear();retainedTraversal.Clear();StructuralPrimalSolver coldPrepared(changedMatrix,retainedFactor,&retainedTraversal);
    Check(coldPrepared.Solve({.25,-.29},primalSolution,primalIterations,primalResidual)&&retainedTraversal.ready&&retainedTraversal.lowerValues!=savedLower,
        "cold/refactor invalidation reconstructs sparse preconditioner values rather than reusing stale numerical storage");
    // A between-round external displacement is explicitly included in the
    // free prediction. The assertion concerns only the internal displacement
    // and its actual WORLD impulse; no conservation claim is made for the
    // external operation. A collinear positive control cannot reveal a scalar
    // history reinterpreted along a changing axis.
    StructuralState potentialState;potentialState.Initialize(*bar->structure,2);potentialState.BeginInterval(*bar->structure,bar->nodes);
    bool potentialDerivative=true;
    for(double length:{.995,1.005,.9,1.05,.35,1.2}){const double epsilon=1e-7;auto lower=bar->nodes,upper=bar->nodes;lower[1].x=length-epsilon;upper[1].x=length+epsilon;
        const double derivative=(potentialState.IntervalPotential(*bar->structure,upper,1./240)-potentialState.IntervalPotential(*bar->structure,lower,1./240))/(2*epsilon);double force=0,tangent=0;
        potentialState.Linearize(*bar->structure,0,length,1./240,force,tangent);potentialDerivative&=std::abs(derivative-force)<std::max(1e-4,std::abs(force)*1e-7);}
    Check(potentialDerivative,"anchored incremental potential independently differentiates to elastic, plastic, capacity-limited and viscous force");
    const auto beforeTrialRest=potentialState.restLengths,beforeTrialPlastic=potentialState.accumulatedPlasticStrain;
    bool pureTrial=true;
    for(double length:{.995,1.005,.9,1.05,.35,1.2}){double force=0,tangent=0,rest=0,plastic=0;
        const StructuralState& immutable=potentialState;pureTrial&=immutable.EvaluateForce(*bar->structure,0,length,1./240,force,tangent,rest,plastic);
        StructuralState accepted=potentialState;double acceptedForce=0,acceptedTangent=0;pureTrial&=accepted.Linearize(*bar->structure,0,length,1./240,acceptedForce,acceptedTangent)
            &&force==acceptedForce&&tangent==acceptedTangent&&std::isfinite(rest)&&plastic>=0;}
    Check(pureTrial&&potentialState.restLengths==beforeTrialRest&&potentialState.accumulatedPlasticStrain==beforeTrialPlastic,"pure rejected constitutive trials match accepted force/tangent without mutating anchored material history");
    double invalidForce=0,invalidTangent=0,invalidRest=0,invalidPlastic=0;
    Check(!potentialState.EvaluateForce(*bar->structure,0,0,1./240,invalidForce,invalidTangent,invalidRest,invalidPlastic)&&potentialState.restLengths==beforeTrialRest&&potentialState.accumulatedPlasticStrain==beforeTrialPlastic,"invalid pure constitutive trial fails explicitly and preserves material history");

    const auto historyProof=[&](bool turn){
        const double h=1./240;const std::vector<double> weight={.2,.2};
        std::vector<V> x=bar->nodes,prediction=x;x[1].x+=.02;prediction=x;
        StructuralState state;state.Initialize(*bar->structure,2);state.BeginInterval(*bar->structure,bar->nodes);
        state.Solve(*bar->structure,x,weight,h);
        if(turn){x[1].y+=.25;prediction[1].y+=.25;}
        double maximumIdentity=0;
        for(unsigned round=0;round<8;++round){state.Solve(*bar->structure,x,weight,h);const auto p=state.appliedBeamImpulse[0];
            maximumIdentity=std::max({maximumIdentity,glm::length(x[0]-prediction[0]+weight[0]*p),glm::length(x[1]-prediction[1]-weight[1]*p)});}
        const V delta=x[1]-x[0],n=glm::normalize(delta);double force=0,tangent=0;state.Linearize(*bar->structure,0,glm::length(delta),h,force,tangent);
        const double forceResidual=glm::length(state.appliedBeamImpulse[0]+n*(h*h*force));
        std::printf("WORLD_HISTORY rotated=%u displacement_identity_m=%.12g constitutive_impulse_residual_kgm=%.12g\n",unsigned(turn),maximumIdentity,forceResidual);
        return maximumIdentity<1e-10&&forceResidual<1e-10;
    };
    Check(historyProof(false),"collinear internal world impulse agrees with actual finite-mass displacement and constitutive force");
    Check(historyProof(true),"nonlinear axis rotation removes the actually applied transverse history rather than reinterpreting a scalar multiplier");

    bool affineBranches=true;bool affineInterceptRequired=false;
    for(double modelLength:{.995,1.005,.9,1.05,.35,1.2}){double intercept=0,tangent=0;unsigned branch=0;
        affineBranches&=potentialState.EvaluateAffineForce(*bar->structure,0,1,modelLength,1./240,intercept,tangent,&branch);
        const double nearby=modelLength+1e-6;double force=0,actualTangent=0,rest=0,plastic=0;potentialState.EvaluateForce(*bar->structure,0,nearby,1./240,force,actualTangent,rest,plastic);
        affineBranches&=std::abs(intercept+tangent*(nearby-1)-force)<1e-5;
        double baseForce=0,baseTangent=0;potentialState.Linearize(*bar->structure,0,1,1./240,baseForce,baseTangent);
        affineInterceptRequired|=std::abs(baseForce+tangent*(nearby-1)-force)>100;
    }
    Check(affineBranches,"frozen axial elastic, plastic and capacity branches retain their exact affine value across loading and unloading");
    Check(affineInterceptRequired,"changing only the branch tangent demonstrably moves the physical yield corner; its affine intercept is essential");
    auto exactCornerCook=*bar->structure;auto& cornerRegion=exactCornerCook.regions[0];cornerRegion.youngModulus=cornerRegion.hardening=128e6;cornerRegion.tensionYield=cornerRegion.compressionYield=1e6;cornerRegion.maxShortening=cornerRegion.maxExtension=.125;
    StructuralState exactCorner;exactCorner.Initialize(exactCornerCook,2);exactCorner.BeginInterval(exactCornerCook,bar->nodes);
    const double hCorner=1./240,elasticCorner=128e6*exactCornerCook.beams[0].area+cornerRegion.damping/hCorner,plasticCorner=64e6*exactCornerCook.beams[0].area+cornerRegion.damping/hCorner;
    double derivative0=0,derivative1=0;
    Check(exactCorner.EvaluateForceDirectional(exactCornerCook,0,1+1./128,hCorner,1,derivative0)&&exactCorner.EvaluateForceDirectional(exactCornerCook,0,1+1./128,hCorner,-1,derivative1)&&std::abs(derivative0-plasticCorner)<1e-8&&std::abs(derivative1+elasticCorner)<1e-8,"exact tension-yield directional derivatives distinguish outward plastic loading from elastic unloading");
    Check(exactCorner.EvaluateForceDirectional(exactCornerCook,0,1-1./128,hCorner,-1,derivative0)&&exactCorner.EvaluateForceDirectional(exactCornerCook,0,1-1./128,hCorner,1,derivative1)&&std::abs(derivative0+plasticCorner)<1e-8&&std::abs(derivative1-elasticCorner)<1e-8,"exact compression-yield directional derivatives preserve the opposite one-sided branches");
    Check(exactCorner.EvaluateForceDirectional(exactCornerCook,0,1.25+1./128,hCorner,1,derivative0)&&exactCorner.EvaluateForceDirectional(exactCornerCook,0,1.25+1./128,hCorner,-1,derivative1)&&std::abs(derivative0-elasticCorner)<1e-8&&std::abs(derivative1+plasticCorner)<1e-8,"tension capacity uses elastic outward resistance and plastic inward tangent at the exact same force");
    Check(exactCorner.EvaluateForceDirectional(exactCornerCook,0,.75-1./128,hCorner,-1,derivative0)&&exactCorner.EvaluateForceDirectional(exactCornerCook,0,.75-1./128,hCorner,1,derivative1)&&std::abs(derivative0+elasticCorner)<1e-8&&std::abs(derivative1-plasticCorner)<1e-8,"compression capacity has the corresponding exact one-sided derivative without changing plastic limits");
    double modelValue=0,modelTangent=0;unsigned modelBranch=0;
    Check(exactCorner.EvaluateAffineForce(exactCornerCook,0,1,-.1,hCorner,modelValue,modelTangent,&modelBranch)&&modelBranch==4&&!exactCorner.EvaluateForce(exactCornerCook,0,-.1,hCorner,invalidForce,invalidTangent,invalidRest,invalidPlastic),"signed formal axial proposal selects its compressive affine capacity branch while actual negative geometric length remains rejected");

    // At a frozen proposal's yield crossing both axial affine branches agree.
    // Multiplying their DIFFERENT base intercepts by a changing lever would
    // introduce a false branch jump, even though the force itself is continuous.
    const double yieldCorner=1+1./128;double elasticValue=0,elasticTangent=0,plasticValue=0,plasticTangent=0;
    exactCorner.EvaluateAffineForce(exactCornerCook,0,1,yieldCorner-1./1024,hCorner,elasticValue,elasticTangent);
    exactCorner.EvaluateAffineForce(exactCornerCook,0,1,yieldCorner+1./1024,hCorner,plasticValue,plasticTangent);
    const double elasticAtCorner=elasticValue+elasticTangent*(yieldCorner-1),plasticAtCorner=plasticValue+plasticTangent*(yieldCorner-1);
    const V changingArm(0,.1,0),originalResidual(.2,.3,.4);
    const V oldBranchJump=glm::cross(changingArm,V(plasticValue-elasticValue,0,0));
    Check(std::abs(elasticAtCorner-plasticAtCorner)<1e-8&&glm::length(oldBranchJump)>1,"the original intercept-dependent moving-lever model has a real jump at a physically continuous yield crossing");
    const V newElasticMoment=glm::cross(changingArm,originalResidual)+glm::cross(V(0,1,0),V(elasticAtCorner,0,0));
    const V newPlasticMoment=glm::cross(changingArm,originalResidual)+glm::cross(V(0,1,0),V(plasticAtCorner,0,0));
    Check(glm::length(newElasticMoment-newPlasticMoment)<1e-8,"freezing the original nonaxial lever derivative preserves exact axial branch continuity in the numerical proposal");

    const auto exactEvents=exactCorner.ForceEvents(exactCornerCook,0);
    Check(exactEvents==std::array<double,4>{1+1./128,1-1./128,1.25+1./128,.75-1./128},"axial event locations exactly recover both yield crossings and both capacity crossings including the hardening contribution");

    const auto identity=[](const std::vector<double>& x,std::vector<double>& y){y=x;return true;};
    const auto nonsymmetric=[](const std::vector<double>& x,std::vector<double>& y){y={2*x[0]+5*x[1],-3*x[0]+x[1]};return true;};
    const auto indefinite=[](const std::vector<double>& x,std::vector<double>& y){y={-2*x[0],3*x[1]};return true;};
    const auto rankOne=[](const std::vector<double>& x,std::vector<double>& y){y.assign(2,x[0]+x[1]);return true;};
    std::vector<double> newtonSolution;unsigned newtonIterations=0;double newtonResidual=0;std::string newtonError;
    const bool nonsymmetricPass=SolveStructuralNewtonKrylov({12,-1},nonsymmetric,identity,newtonSolution,newtonIterations,newtonResidual,newtonError);
    Check(nonsymmetricPass&&std::abs(newtonSolution[0]-1)<1e-9&&std::abs(newtonSolution[1]-2)<1e-9&&newtonResidual<1e-9,"physical Newton Krylov solves an actual nonsymmetric force/kinematic Jacobian without symmetrizing its physics");
    Check(SolveStructuralNewtonKrylov({-4,9},indefinite,identity,newtonSolution,newtonIterations,newtonResidual,newtonError)&&std::abs(newtonSolution[0]-2)<1e-9&&std::abs(newtonSolution[1]-3)<1e-9,"physical Newton Krylov retains a genuine negative geometric-stiffness direction without compliance regularization");
    Check(SolveStructuralNewtonKrylov({2,2},rankOne,identity,newtonSolution,newtonIterations,newtonResidual,newtonError)&&std::abs(newtonSolution[0]+newtonSolution[1]-2)<1e-9,"consistent redundant Newton equations solve on their actual range");
    Check(!SolveStructuralNewtonKrylov({2,-2},rankOne,identity,newtonSolution,newtonIterations,newtonResidual,newtonError)&&!newtonError.empty(),"incompatible redundant physical equations fail instead of receiving invented rank repair");
    Check(!SolveStructuralNewtonKrylov({std::numeric_limits<double>::infinity()},identity,identity,newtonSolution,newtonIterations,newtonResidual,newtonError),"nonfinite physical Newton input is rejected before a false infinity-versus-infinity stop");
    const auto missingAction=[](const std::vector<double>&,std::vector<double>&){return false;};
    Check(!SolveStructuralNewtonKrylov({1},missingAction,identity,newtonSolution,newtonIterations,newtonResidual,newtonError),"missing physical operator fails explicitly without publishing a partial correction");
    Check(SolveStructuralNewtonKrylov({0,0},identity,identity,newtonSolution,newtonIterations,newtonResidual,newtonError)&&newtonIterations==0&&newtonSolution==std::vector<double>({0,0}),"exact physical equilibrium returns without numerical work or invented impulses");
    // A cyclic permutation is invertible. Its first48 Arnoldi vectors are
    // orthogonal to e0, so a48-vector restart makes exactly no progress. This
    // control detects lost Krylov history, rather than increasing a budget.
    const auto cyclic64=[](const std::vector<double>& x,std::vector<double>& y){y.resize(64);for(unsigned i=0;i<64;++i)y[(i+1)%64]=x[i];return true;};
    std::vector<double> cycleLoad(64,0),cycleExpected(64,0);cycleLoad[0]=1;cycleExpected[63]=1;
    Check(SolveStructuralNewtonKrylov(cycleLoad,cyclic64,identity,newtonSolution,newtonIterations,newtonResidual,newtonError)&&newtonSolution==cycleExpected&&newtonIterations==64&&newtonResidual==0,"full small-system Arnoldi retains the64th invariant direction that an unchanged48-vector restart would discard");
    // Exact old-restart witness: projection of e0 onto A span(e0...e47)
    // is zero, and the same statement repeats at every restart.
    bool restartedStagnates=true;for(unsigned column=0;column<48;++column){std::vector<double> unit(64,0),image;unit[column]=1;cyclic64(unit,image);restartedStagnates&=image[0]==0;}
    Check(restartedStagnates,"the preserved48-vector restart has unit residual on the same invertible cyclic control within its dimension-bound");

    std::vector<double> trust;
    Check(StructuralLeastSquaresProposal({2,0,0,4},{2,-8},.25,trust)&&std::abs(trust[0]+.8)<1e-12&&std::abs(trust[1]-1.6)<1e-12,"column-scaled numerical trust proposal matches independent diagonal least-squares minimizer");
    Check(!StructuralLeastSquaresProposal({1},{1},0,trust)&&!StructuralLeastSquaresProposal({1},{1},-1,trust)&&!StructuralLeastSquaresProposal({1},{std::numeric_limits<double>::infinity()},1,trust),"invalid numerical trust requests fail without inventing physical compliance");
    Check(StructuralLeastSquaresProposal({1,1,2,2},{1,2},.1,trust)&&std::isfinite(trust[0]+trust[1])&&trust[0]+trust[1]<0,"rank-deficient Newton chart admits a finite residual-reducing numerical proposal without claiming a physical root");
    const auto encoded=EncodeDeformableAsset(*truss);DeformableAsset decoded;Check(encoded.rfind("JudasDeformable4\n",0)==0&&DecodeDeformableAsset({encoded.begin(),encoded.end()},decoded,error)&&EncodeDeformableAsset(decoded)==encoded,"structural asset version four roundtrip preserves authoring exactly");
    const std::string source="JudasStructuralSource 1\nnode 0 0 0\nnode 1 0 0\nregion \"bar\" 1e8 50 1e6 1e6 1e7 1e7 2e6 .6 .08 0\nbeam \"bar\" 0 1 0 .001\ngroup \"left\" 1 0\ngroup \"right\" 1 1\nend\n";DeformableAsset parsed;Check(ImportStructuralNetwork(source,parsed,error)&&parsed.structure->beams.size()==1&&parsed.measures==bar->measures,"reusable structural source derives original physical member volume");
    std::printf("SUMMARY %d checks %d failures\n",checks,failures);return failures?1:0;
}
