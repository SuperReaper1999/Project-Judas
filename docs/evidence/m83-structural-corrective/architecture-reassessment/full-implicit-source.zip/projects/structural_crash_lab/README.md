# Structural Crash Lab

This separate M83 project preserves the earlier damage, wheel and powertrain
projects. Open `structural_crash_lab.judasproj`, or launch its exported runtime.
The orange car is an original compact hatch with a supported rigid cabin and
a separate yielding steel front structure. Its simulation members are visible
through the optional structure overlay; normal presentation uses bodywork.

## Driving and inspection

| Control | Action |
|---|---|
| W / S | Drive forward / reverse through the real source and tyre forces |
| A / D | Steer the front wheels |
| Space | Mechanical brakes |
| V | Repeat the current test using ordinary driver commands |
| T | Watch normal driving, low/medium/high impacts, offset impact and comparison |
| 1 | Normal acceleration, braking, steering and an 80 mm bump |
| 2 / 3 / 4 | Frontal 5 / 15 / 25 m/s targets |
| 5 | Approximately 40% left corner overlap at 15 m/s |
| 6 | Identical nominal, weaker and stronger structural cars at 15 m/s |
| 7 | Independent non-vehicle rail and finite loading platen |
| 8 | Entire car, wall, ground and gravity frame rotated together |
| Tab | Select another car; manual controls operate the selected assembly |
| P | Spawn an independent complete car from the editable prefab |
| F3 | Request/release the retained annex; Tab selects its independent car |
| G | Show live structural graph, plastic state and mounting patches |
| J | Show physical collision shapes, resolved contacts and wheel geometry |
| F5 / F8 | Save / restore actual physical deformation and mechanical state |
| R | Reload the authored intact scene |
| Escape | Pause/resume |

The tour feeds measured speed into ordinary throttle and brake commands. It
uses actual material/wall contacts to observe impact, unloads the structure,
and attempts to drive the damaged result. It writes no damage flags, beam rest
lengths, body poses, wheel mount positions or velocities. Actual impact speed
is a measured result and can differ from the target when a test fails.

On the non-vehicle specimen, V runs load/unload/overload/inspection. B toggles
1.5 kN of physical force on its 20 kg platen; H toggles 150 kN. Its clamp and
platen guides are visible ordinary collision bodies. The demonstration shares
the car's structural material mechanism and steel region definitions.

## Authoring construction

The reference recipe is `tools/CreateStructuralCrashLab.py`; the generated
`Authoring/compact-hatch.json` records the model inventory, mass derivation,
quality settings, speed inputs and intended outcomes before tuning.

The central cabin is a 500 kg compound body: floor/frame, firewall, rear body,
sills, pillars, roof and doors. Its visible shell matches those authored
collision members. Its hollow cabin is not an incompressible soft volume and
no rigid collision box extends through the front crush zone.

The front structure has 72 nodes, 307 beams and 48 collision skin triangles.
Two longitudinal rails have local cross braces, diagonal braces and distinct
noncollinear suspension patches. The independent 10 kg front mount assemblies
sit inside the wheel arches. Their actual displaced poses determine wheel
alignment and suspension direction. Rear wheels use the cabin body.

Bonnet, fenders and leading bumper have explicit physical surfaces bound to
their local graph nodes. Every visible triangle belongs to a physical surface
with local supporting beams. A broken section removes its joining skin patch;
free components cannot stretch a triangle across the gap. The leading skin
is 0.78 m ahead of the nearest rigid suspension bulk and receives wall loads.
Self/inter-part contact remains enabled for the demonstrated deformation.

The structural source declares three mechanical regions:

| Region | Role |
|---|---|
| Crush rail | Stiff elastic support, compression yield, hardening and finite ultimate capacity |
| Mount brace | Stronger support around suspension patches; limited permanent extension |
| Body panel | Thin steel skin with lower forming strength and local break seams |

Use named groups `rear_left/right`, `mount_left/right`, `tip_left/right` and
`panel_left/right` when editing. Body attachments use full local patches to
transmit force and moment. Front transmission links require the corresponding
surviving rear-to-mount graph path. A broken path stops transmitting torque
through engine continuity checks; the driver command remains enabled.

All variants retain the same topology, masses, driver input and solve quality.
Weaker/stronger variants scale yield, ultimate and hardening stresses by 0.75 /
1.25. Elastic stiffness and damping remain independent of those strength values.
These are bounded engineering demonstration settings, not automotive calibration.

Steel density is 7,850 kg/m³. Mass is derived from each beam's area times rest
length, plus each skin triangle's 0.8 mm thickness times area. The current front
beam/skin masses are 27.995 / 23.958 kg, giving **571.953 kg** total including
cabin and two front mount bodies. Detached material retains its accounted mass.

The fender supports at the front wheel station attach to the upper/outboard
rail corners, clearing the finite wheel bearings. This routes the actual
support members above the hardware while preserving the visible skin and
local body-contact behavior.

To regenerate text/assets without invoking a native program:

```text
python3 tools/CreateStructuralCrashLab.py --source-only
```

The build-free corrective runner uses the existing candidate binaries and
executes only selected cases, sequentially. Every run requires a new evidence
directory; failed logs are retained and retries require another directory.
Its default focused set is the numerical/contact/coupling foundation, rest,
and the non-vehicle specimen. Use `--list` or `--plan` to inspect the choices:

```text
python3 scripts/m83_structural_corrective.py --list
python3 scripts/m83_structural_corrective.py --output /tmp/m83-focus-01 --plan
python3 scripts/m83_structural_corrective.py --output /tmp/m83-cold-01 --cases cold-write cold-read
```

Native graphics are the default for Linux host timings. `--graphics software`
explicitly labels software rendering. Exported executables require a fresh
`--package-dir` outside the repository; the runner does not build or commit
them. The runner's module documentation lists car, lifecycle, streaming,
sensitivity, export and shipping-startup commands. Those commands are not
validation evidence until they have actually been run successfully.

After building the generic baker, omit `--source-only` and supply its location
with `--baker`. This authors only the new project. `.source` assets use the
generic `JudasStructuralSource 1` grammar; the normal
`judas_deformable_bake structural-network` command produces runtime cooks.

## Declared outcomes and measurements

Targets are recorded in `Authoring/compact-hatch.json`. Normal driving should
produce no plasticity or broken paths and settle within 2 mm of the original
mount geometry. Low frontal impact should retain limited damage; medium impact
should retain 100–350 mm local front crush; high impact should retain 250–650 mm
of longitudinal rail rest shortening and eventually lose a physical drive path
after yielding. Offset impact should damage the struck side more and change
its real mount position or alignment.

Free fragment motion is reported separately from crush. The high-impact
shortening measure averages the eight axial rail member chains and remains
invariant under detached fragment translation/rotation. Connected geometric
crush and permanent beam rest changes are separate measurements.

The application fixture records actual wall impulses, pre-impact speed,
region/rail crush, plastic and fracture work, wheel mounts, drive connectivity,
accounted mass, surviving skin corner penetration and work costs. Motor input
work uses actual solved source impulses and midpoint shaft speed. Brake work
integration is explicitly approximate. Contact attempted
crossing depth is not residual penetration. Actual 120 Hz sensitivity steps
the ordinary played world at 1/120 s; 120 display frames alone do not count.

Annex retention owns all car material, body, gravity, wheel and transmission
references locally. It can retire and publish fresh identities while retaining
actual deformation, failures, wheel spin and driver state. F5 while the annex
is suspended saves its retained state for a fresh-process revisit.

Automated results and measured limits belong to the corrective evidence report.
The declared targets here are requirements, not claims that they have passed.
Human acceptance still requires judging ordinary driving and the visible,
normal-speed before/impact/after result in the editor and exported runtime.
