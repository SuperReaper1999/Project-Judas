// Project policy: ordinary driver commands, observations, views and saves.
// Structural rest lengths, failures, contacts and mounts belong to the engine.
import {world,input,ui,scenes,saves,session} from 'judas';
import {add,sub,dot,rotate,inverse,qm,axis} from './math.js';

export const properties={case:{type:'string',default:'medium'},autopilot:{type:'boolean',default:false}};
const carPrefab='83838383838383838383c83c00000009';
const cases=['normal','low','medium','high','offset','comparison','specimen','rotated'];
const targets={normal:10,low:5,medium:15,high:25,offset:15,comparison:15,rotated:15,group:15};
const limit=(x,a,b)=>Math.max(a,Math.min(b,x));

export default class {
 constructor({properties}){
  this.props=properties;
  this.state={selected:0,automatic:false,time:0,impactTime:-1,lastSpeed:0,
   yaw:1.10,pitch:-.28,spawned:[],structure:false,contacts:false,load:false,overload:false,region:false};
  this.pending=[];this.families=new Map();this.request=0;this.region='';
  this.message='V drives this test. W/S, A/D and Space control the selected car.';
 }
 start(){
  this.hud=ui.get('lab');if(this.hud){this.hud.modal=false;this.hud.get('pause').visible=false;}
  this.state.automatic=!!(this.state.automatic||this.props.autopilot||session.get('structuralTour'));
  input.pointerCapture=true;ui.debugOverlayVisible=false;
  this.debug();
 }
 restore(){this.families=new Map();this.pending=[];this.region='';this.start();
  if(this.state.region)this.region=scenes.requestRegion('annex');}
 assemblies(){
  const ids=this.props.case==='comparison'||this.props.case==='group'?['900','1200','1500']:['900'];
  const cars=[...ids,...this.state.spawned].map(id=>world.entity(id));
  const annex=scenes.resolveRegionEntity('annex','1');if(annex)cars.push(annex);
  return cars.filter(e=>e?.valid&&e.powertrain);
 }
 current(){const cars=this.assemblies();return cars[this.state.selected%cars.length]||null;}
 family(owner){
  let f=this.families.get(owner.id);
  if(!f){
   const children=owner.children;
   const mounts=children.filter(e=>e.valid&&e.collider);
   const wheels=[...children.filter(e=>e.wheel),...mounts.flatMap(e=>e.children.filter(c=>c.wheel))];
   f={children,mounts,wheels:wheels.map(e=>({entity:e,handle:e.wheel,front:e.wheel.settings.chassisId!==owner.id})),
      material:null,settings:owner.powertrain.settings};
   this.families.set(owner.id,f);
  }
  if(!f.material?.valid)f.material=f.children.find(e=>e.valid&&e.deformable)||null;
  return f;
 }
 debug(){
  // This changes presentation only. All overlay geometry is read from the
  // live physical representation, including deformed surfaces and mounts.
  world.debugView={deformables:this.state.structure,collisionShapes:this.state.contacts,
                   contacts:this.state.contacts,wheels:this.state.contacts};
 }
 update(){
  if(this.hud?.modal)return;
  for(const action of ['select','watch','tour','spawn','load','overload','region'])
   if(input.pressed(action))this.pending.push(action);
  for(const name of cases)if(input.pressed(name)){
   session.set('structuralTour',null);scenes.load('Scenes/'+name+'.judas');
  }
  if(input.pressed('restart')){session.set('structuralTour',null);scenes.reload();}
  if(input.pressed('structure')){this.state.structure=!this.state.structure;this.debug();}
  if(input.pressed('contacts')){this.state.contacts=!this.state.contacts;this.debug();}
  this.state.yaw-=input.axis('look_x')*.002;
  this.state.pitch=limit(this.state.pitch-input.axis('look_y')*.002,-.9,.15);
 }
 measuredSpeed(owner){
  const frame=world.entity('1').transform;
  return dot(owner.velocity,rotate(frame.rotation,{x:0,y:0,z:-1}));
 }
 forwardPosition(owner){
  const frame=world.entity('1').transform;
  return rotate(inverse(frame.rotation),sub(owner.transform.position,frame.position)).z;
 }
 wallObserved(owner){
  const f=this.family(owner),state=f.material?.deformable.state;
  // The engine identifies actual resolved material contact with an ordinary
  // wall. Ground support and a silhouette near the wall cannot count as impact.
  return !!state?.contactSamples.some(c=>c.entityId&&['5000','5001','5002'].includes(c.entityId)&&c.normalImpulse>0);
 }
 driver(target,speed){
  // A measured-speed driver controls real torque and mechanical brakes. It
  // neither clamps velocity nor prescribes how a crash should damage the car.
  const error=target-speed;
  return {throttle:target>0?limit(error*.45,0,1):0,
          braking:target===0?1:limit(-error*.25,0,.65)};
 }
 fixedUpdate(dt){
  for(const action of this.pending){
   if(action==='select')this.state.selected++;
   if(action==='watch'){
    session.set('structuralTour',null);this.state.automatic=!this.state.automatic;
    this.state.time=0;this.state.impactTime=-1;
    this.message=this.state.automatic?'Test started with ordinary driver inputs.':'Manual driving restored.';
   }
   if(action==='tour'){
    session.set('structuralTour',{index:0});scenes.load('Scenes/normal.judas');
   }
   if(action==='spawn'){
    const selected=this.current(),frame=world.entity('1').transform;
    const position=selected?add(selected.transform.position,rotate(frame.rotation,{x:4,y:0,z:4})):
                   add(frame.position,rotate(frame.rotation,{x:4,y:.60,z:6}));
    const instance=world.spawnPrefab(carPrefab,{position,rotation:frame.rotation,scale:{x:1,y:1,z:1}});
    this.state.spawned.push(instance.id);this.state.selected=this.assemblies().length-1;
    this.message='Independent car spawned from the same editable prefab.';
   }
   if(action==='load')this.state.load=!this.state.load;
   if(action==='overload')this.state.overload=!this.state.overload;
   if(action==='region'){
    this.state.region=!this.state.region;
    if(this.state.region)this.region=scenes.requestRegion('annex');
    else if(this.region){scenes.releaseRegion(this.region);this.region='';}
    this.message=this.state.region?'Annex requested. Tab selects its independent car.':'Annex released; actual material and mechanical state are retained.';
   }
  }
  this.pending=[];
  if(this.props.case==='specimen'){
   const platen=world.entity('502');
   let loading=this.state.overload?150000:this.state.load?1500:0;
   if(this.state.automatic){
    this.state.time+=dt;const t=this.state.time;
    loading=t>=2&&t<4?1500:t>=8&&t<10?150000:0;
    this.message=t<2?'1 / SPECIMEN SETTLE':t<4?'2 / ORDINARY ELASTIC LOAD':
       t<8?'3 / UNLOAD AND RECOVER':t<10?'4 / PHYSICAL OVERLOAD':'5 / UNLOAD AND INSPECT RETAINED CRUSH';
    if(t>=16)this.finishTour();
   }else this.message=this.state.overload?'Physical platen overload: inspect retained rail crush.':
                this.state.load?'Physical elastic load: B removes it.':'V watches load/unload/crush; B applies modest load, H applies overload.';
   if(loading)platen.applyForce(rotate(world.entity('1').transform.rotation,{x:0,y:0,z:loading}));
   return;
  }
  const current=this.current();if(!current)return;
  let throttle=input.axis('throttle'),braking=input.held('brake')?1:0,steer=input.axis('steer')*.25;
  if(this.state.automatic){
   this.state.time+=dt;const t=this.state.time;
   if(this.props.case==='normal'){
    const target=t<3||t>=9&&t<12||t>=23?0:t<9?10:5;
    const command=this.driver(target,this.measuredSpeed(current));
    throttle=command.throttle;braking=command.braking;
    steer=t>=12&&t<17?.20*Math.sin((t-12)*Math.PI*.8):0;
    this.message=t<3?'1 / SETTLE':t<9?'2 / ORDINARY ACCELERATION':t<12?'3 / BRAKING':
                 t<17?'4 / STEERING':t<23?'5 / MODEST BUMP':'6 / UNLOAD AND INSPECT';
    if(t>=30)this.finishTour();
   }else{
    const observed=this.assemblies().some(owner=>this.wallObserved(owner));
    if(observed&&this.state.impactTime<0)this.state.impactTime=t;
    const after=this.state.impactTime<0?-1:t-this.state.impactTime;
    const target=t<3?0:targets[this.props.case]||15;
    const command=this.driver(target,this.measuredSpeed(current));
    throttle=command.throttle;braking=command.braking;steer=0;
    if(after>=.35){throttle=0;braking=1;}
    // Attempt to drive the physical damaged result through surviving paths.
    if(after>=5&&after<7){throttle=.4;braking=0;}
    this.message=t<3?'1 / INTACT: same editable car and material settings':
       after<0?`2 / APPROACH: ${target} m/s target; actual speed is measured`:
       after<5?'3 / IMPACT AND UNLOAD: inspect local permanent crush':
       after<7?'4 / ATTEMPT TO DRIVE THE PHYSICAL DAMAGED CAR':
       '5 / INSPECT: G structure, J contacts, F5 save, F8 cold restore';
    if(after>=13||t>=45)this.finishTour();
   }
  }
  for(const owner of this.assemblies()){
   const f=this.family(owner),active=this.state.automatic||owner.id===current.id;
   owner.powertrain.set({sources:f.settings.sources.map(s=>({name:s.name,input:active?throttle:0})),
     brakes:f.settings.brakes.map(b=>({name:b.name,engagement:active?braking:1}))});
   for(const wheel of f.wheels)if(wheel.entity.valid&&wheel.handle.valid)
    wheel.handle.set({driveTorque:0,brakeTorque:0,steeringAngle:active&&wheel.front?steer:0});
  }
 }
 finishTour(){
  this.state.automatic=false;this.message='Test complete. Inspect, drive, save or choose another case.';
  const tour=session.get('structuralTour');
  if(tour){const sequence=['normal','low','medium','offset','high','comparison'];
   const next=tour.index+1;if(next<sequence.length){session.set('structuralTour',{index:next});
    scenes.load('Scenes/'+sequence[next]+'.judas');}else session.set('structuralTour',null);
  }
 }
 presentationUpdate(){
  const current=this.current()||world.entity('500');if(!current?.valid)return;
  const frame=world.entity('1').presentedTransform;
  const heading=qm(frame.rotation,axis({x:0,y:1,z:0},this.state.yaw));
  const rotation=qm(heading,axis({x:1,y:0,z:0},this.state.pitch));
  const focus=add(current.presentedTransform.position,rotate(frame.rotation,{x:0,y:.2,z:-.2}));
  world.setView({position:add(focus,rotate(heading,{x:0,y:2.5,z:this.props.case==='specimen'?5:7})),rotation},60,{near:.06,far:350});
 }
 uiUpdate(){
  if(!this.hud)return;
  if(input.pressed('pause')){this.hud.modal=!this.hud.modal;this.hud.get('pause').visible=this.hud.modal;input.pointerCapture=!this.hud.modal;}
  if(input.pressed('save_game'))this.command('save');if(input.pressed('load_game'))this.command('load');
  if(this.request){const status=saves.status(this.request);if(status&&['completed','failed','cancelled'].includes(status.state)){
   this.message=status.state+(status.error?' — '+status.error:'');this.request=0;
  }}
  this.hud.get('title').text='JUDAS / STRUCTURAL CRASH LAB';
  this.hud.get('score').text=this.props.case.toUpperCase()+' | '+(this.state.automatic?'WATCH':'MANUAL');
  const owner=this.current();
  if(owner){const f=this.family(owner),material=f.material?.deformable.state,structure=material?.structural;
   this.hud.get('progress').text=`Speed ${this.measuredSpeed(owner).toFixed(1)} m/s | front drive ${owner.powertrain.state.links.slice(0,2).filter(l=>l.connected).length}/2 | broken beams ${structure?.broken||0} | plastic work ${((structure?.plasticWork||0)/1000).toFixed(1)} kJ`;
   this.hud.get('message').text=material?.error||this.message;
  }else this.hud.get('message').text=this.message;
  this.hud.get('controls').text='V watch | T tour | W/S drive | A/D steer | Space brake | 1–8 cases | Tab | P spawn | F3 annex | G/J overlays | F5/F8 | R | Esc';
 }
 command(operation){if(!this.request)this.request=operation==='save'?
  saves.save('structural-current',{name:'Actual structural crush, wheel mounts and drivetrain'}):saves.load('structural-current');}
 onUI(event){
  if(event.type==='back'||event.type==='click'&&event.element==='resume'){
   this.hud.modal=false;this.hud.get('pause').visible=false;input.pointerCapture=true;
  }
  if(event.type==='click'&&event.element==='restart')scenes.reload();
  if(event.type==='click'&&event.element==='quit')ui.quit();
  if(event.type==='click'&&['save','load'].includes(event.element))this.command(event.element);
  if(event.type==='click'&&event.element==='delete')this.request=saves.delete('structural-current');
 }
 destroy(){if(this.region)scenes.releaseRegion(this.region);input.pointerCapture=false;world.clearView();}
}
