# Deformable

Current deformation API (introduced in M62). Judas owns deformation and contact; project JavaScript chooses
forces, attachments and game meaning. Obtain `entity.deformable`; it returns null
until the normal immutable resource is ready, or if the component is absent.
Failed/stale baked resources throw a diagnostic `TypeError`; they are not a successful empty simulation.
Cache a ready handle, check `valid` after destruction/reload, and reacquire after
scene replacement. Invalid handles throw `ReferenceError` except `valid`.

## State and picking

`state` reports enabled/sleeping/error, mass (kg), world/local-simulation-frame
AABB `minimum`/`maximum`, node/contact counts, minimum element Jacobian, maximum
strain, named `groups` and per-attachment observations. These are snapshots, not mutable solver storage.

`raycast(origin, direction, maximum)` queries this instance's **current deformed
boundary**, returning `{point, normal, distance, location}` or null. Coordinates
are metres in the normal fixed-origin simulation frame. Direction is normalized.
`location` is a checked generation/triangle/barycentric snapshot, not a node pointer.
This query is separate from M44 rigid-body casts. Shape casts, CharacterMotor
blocking and M42 deformable events are not implied.

## Fixed-update mutation

All operations below belong in `fixedUpdate`; calling them in frame/UI callbacks
throws `TypeError`. Reading state/picking is allowed outside fixed updates.

| Operation | Meaning |
|---|---|
| `enabled = boolean` | Pause/resume this instance; retained node state; wake on resume |
| `reset()` | Reset legacy cloth/solid shape, velocity, plasticity, pins and interpolation; node/beam structures require authored reload |
| `force(vector, group = "")` | One-step total force in newtons, distributed by mass over group; empty means whole asset |
| `impulse(vector, group = "")` | Total impulse in kg·m/s, distributed by group mass |
| `impulseAt(location, vector)` | Barycentrically distributed impulse; stale/invalid location returns false |
| `release(group)` | Release that attachment, retaining actual motion; returns false if absent |
| `attach(group, options)` | Replace/create a group attachment and wake |
| `setMaterial(options)` | Change supplied material fields, validate ranges, wake |

Unknown force/impulse groups return false. `force` also returns false for disabled
or failed simulations, preventing queued-force accumulation. Invalid ordinary
force/impulse vectors, materials and attachment targets throw; invalid
`impulseAt` locations/vectors return false.
`attach` options: `kind: "world" | "body" | "bone"`, `target: Entity` for body/bone,
`joint: stable skeleton key` for bone, and optional local-metre `offset`.
World pins use the owner's current transform as the prescribed frame. Body/bone targets transform each
group's rest node plus offset in their local frame. Body targets exchange reaction;
world/static/bone targets prescribe motion. Bone targets consume the existing final
authoritative pose, including passive ragdoll contributions, never interpolated GL
data. Lost targets release; explicit reacquisition is project policy.

Material fields: `density` (kg/m² cloth, kg/m³ solid), `stretchCompliance`,
`shearCompliance`, `volumeCompliance` (inverse membrane/strain energy stiffness),
`bendCompliance` (distance-hinge compliance), `damping` and `airDrag` (s⁻¹),
`airVelocity` (m/s), `thickness` (metres), `friction` (dimensionless),
`yieldStrain` (dimensionless; zero disables plasticity), `plasticRate` (s⁻¹),
`maximumPlasticStrain` (dimensionless bounded rest-strain envelope).
The tetrahedral plastic-flow model preserves element rest volume. Node/beam structural plasticity uses the separate axial law below. These are approximate game materials,
not a calibration promise. Density changes preserve velocity, changing momentum.

```js
import {world} from 'judas';
export default class Fabric {
  constructor({entity}) { this.entity = entity; this.state = {started:false}; }
  fixedUpdate(dt) {
    const patch = this.entity.deformable;
    if (!patch) return;
    if (!this.state.started) {
      patch.setMaterial({airDrag: 0.3, airVelocity: {x: 2, y: 0, z: 1}});
      this.state.started = true;
    }
  }
}
```

See [lifecycle](lifecycle.md), [physics](physics.md),
[animation](animation-ragdolls.md), [saves](saves.md) and [streaming](streaming.md).
M64 extends sampled rigid contact to cooked static meshes, convex hulls and
oriented compound children through the same authoritative geometry path. This
does not add exact mesh/cloth CCD, motor blocking or deformable M42 events.
See [M64 geometry coverage](../M64_COLLISION.md) and the
[M62 implementation/limits](../M62_DEFORMABLES.md) for the physical support envelope.

## M63 fracture cooks

An optional partition uses this same resource/component. See [Fracture](fracture.md)
for irreversible interfaces, rigid/deformable representation, interior materials,
topology-aware picks, support release and the restrictions on reset/material/attach.

## M80 elastic/plastic structural solids

[M80 bending](../M80_BENDING.md) reuses this API for physically deforming
tetrahedral solids and optional soft section-based failure. Solid elastic strain
uses `shearCompliance`; `volumeCompliance` controls volume preservation.
`stretchCompliance`/`bendCompliance` remain cloth parameters. Yield/rate/capped
isochoric rest flow produces permanent deformation; the plastic cap is not a
failure threshold. Optional cooked interface strength determines physical fracture.
`state.maximumStrain` is a diagnostic strain magnitude, not accumulated damage.
Current node geometry still supplies contact, rendering and `raycast`; no new
M44 cast, CharacterMotor blocking or M42 soft-event contract is implied.

Without finite attachment strengths, new saves use deformables participant 3 and versioned retained streaming state to
preserve the original material basis independently of a moved owner/support frame.
Older records still decode, but cannot promise historical owner-rotation
continuation when that reference was absent. These are internal persistence
versions; the JavaScript handle API and cooked asset format are unchanged.
Self-contact excludes local adjacent topology and intact duplicated bond seams.
Nonadjacent surfaces can contact while still connected, and separated components
retain contact. Hidden internal fracture faces and their purely internal edges
are excluded. Candidate and adjacency budgets remain bounded; unsupported solves
retain explicit errors.

## M83 material/body connection strength

`attach` accepts optional `forceLimit` (N) and `torqueLimit` (N m), each zero or
omitted for unlimited strength. Finite limits require an ordinary **dynamic body**
target. World, bone, static and kinematic prescribed targets have no measured
finite-mass reaction in this solver and reject finite strength. Rigid fracture
families retain their M79 section-bond failure path; these limits apply to soft
material/body patches, including cloth and tetrahedral solids.

The actual signed impulses applied to the body are summed within each substep.
Force is the resultant divided by substep duration; moment uses the attachment
patch centroid as its origin. Exceeding either authored limit releases that patch
at the successfully completed fixed-step boundary. It does not delete the body,
reset its velocity, teleport a wheel, or apply an additional break impulse.
Three or more non-collinear attachment nodes can constrain a physical carrier's
orientation as well as position; deformation therefore changes its actual pose.
Collision between carrier and material follows ordinary authored layer/mask rules.

`state.attachments` is an array of `{group, enabled, released, active, forceLimit,
torqueLimit, force, moment, peakForce, peakTorque}`. `force`/`moment` are detached
world/simulation-space vector snapshots from the last substep. Peaks are maximum
**signed resultant** demand in the last evaluated fixed step, not sums of individual
node magnitudes or accumulated gameplay damage. Failed solves can retain partial
evaluated-substep diagnostics while withholding pending release. `active` means
both component and attachment enabled and not released; it does not independently
certify the target's readiness. Reactions are
reconstructed after load and are zero until reevaluated. Released state, material
geometry, velocity and plastic rest persist normally. Explicit `reset`/`attach`
are project-directed reconstruction operations, not automatic healing.

Saves containing finite strengths use deformables participant 4; retained region
state uses `Judas.DeformableState.2`. Default unlimited content retains participant
3 / retained-state 1 and unchanged authored attachment rows. Older formats decode
with unlimited historical strength; no absent strength history is invented.

A [Powertrain connection prerequisite](powertrains.md#physical-connection-prerequisite)
can require this patch and an intact M79 material path. The next mechanical fixed
interval observes committed release/fracture. See [M83 model and bounds](../M83_MECHANICAL_DAMAGE.md).


## M83 node/beam structures and contact observations

An authored structural cook uses the existing Deformable component and handle.
`state.kind` is `"cloth"`, `"solid"` or `"structure"`. Node/beam regions separately
author elastic modulus, axial damping, tension/compression yield, hardening,
ultimate strength and plastic shortening/extension capacities. These regional
laws come from the cook; section area remains authored during plastic shortening/extension, so this representation does not enforce continuum incompressibility. Tetrahedral compliance and isochoric plastic-flow
settings do not substitute for a beam law. Structural density is kg/m³ of the
actual authored beam and panel material volumes. Local physical surfaces receive
loads and supply picking and skin support. Explicit panel boundaries/supports
hide joining triangles when their supporting paths break, while surviving skins
follow their own connected nodes.

`state.structural` is null for cloth and tetrahedral solids. For a node/beam cook,
it contains `{revision, beams, broken, plasticWork, fractureWork, dampingWork,
elasticEnergy, maximumPlasticStrain}`. `beams` and `broken` are counts; `revision` identifies the
committed physical topology. Work/energy values are joules from the authored
model. `dampingWork` accumulates the energy dissipated by the implicit member
dampers; it is retained alongside plastic and released fracture work. `maximumPlasticStrain` is the greatest accumulated absolute plastic beam
strain, rather than a gameplay health value. Geometry, beam rest lengths, broken
connections and their physical work records are retained by normal saves.
Structural cooks use `JudasDeformable4`; a save containing any node/beam instance
uses deformables participant 5, and retained streaming state uses
`Judas.DeformableState.3`. Older participant/envelope readers reject structural
state rather than silently restoring an intact graph. Existing cloth/solid cooks
and nonstructural participant 3/4 or retained-state 1/2 routes remain supported.

`state.contactSamples` contains at most 256 of the strongest solved contacts from
the last evaluated fixed step. Each detached sample is
`{point, normal, penetration, swept, self, entityId, normalImpulse}`. Points and
normals are in simulation/world space. `entityId` identifies the other rigid
entity when available; it is null for material self/inter-material contact or a
body without a published entity. It exposes no native body handle.
`normalImpulse` is the solved normal contact impulse in N·s. It can distinguish
an actual loaded wall contact from floor contact when the project also checks
the known wall entity identity and surface normal.

`penetration` and `state.maximumPenetration` report the overlap or attempted
crossing correction **before contact resolution**, in metres. A swept crossing can have
a large attempted correction even when the corrected final shape stays outside
the wall. Measure the final damaged envelope against the actual collider to
report residual penetration. `state.sweptContacts` counts accepted material-point
sweeps. These diagnostics can be partial if the solve fails and do not replace
the `state.error` check or an independent mass/energy ledger.

Actual rigid contact uses nodes, physical edge midpoints and visible physical
face centroids. Swept material-point tests use each resolved rigid primitive and
include endpoint rigid motion in its final snapshot frame. This is bounded
translational point contact; it does not certify arbitrary fast rotating rigid
motion or arbitrary thin deformable-surface CCD.

Legacy cloth/solid contact retains its geometric projection and finite-target
unilateral reaction from remaining relative closing velocity, with a 0.1
old-overlap drift bias. Predictive node/beam instances instead discover contact
rows for their common implicit member/body solve before the rigid world's
authoritative CCD/pose advance. Normal response uses that assembly's condensed
mass/stiffness response; tangential response is bounded by authored Coulomb
friction. Reported structural normal impulses are net world-space reactions,
including legitimate release, rather than sums of positive trial updates.

The condensed structural contact route currently requires independent finite
pin patches with at most **512 reduced degrees of freedom, including finite
contact partners**. Discovered contact outside that route stops the instance
with an explicit `state.error`; larger contact-free structures retain a general
Schur solve. Same-instance self-contact is condensed. Inter-instance material
contacts remain pair projections; mixed legacy pairs are not one common implicit
structural contact operator. Sampling and topology limits remain applicable.

The solver checks actual physical equilibrium and contact laws independently of
its numerical proposal. Its Jacobian includes force-dependent transverse
stiffness and actual native angular response. Plastic/failure history publishes
only after accepted root and actual endpoint pose/motion checks. A later impulse
can invalidate completion even when a far-world position rounds unchanged;
failed intervals expose `state.error` and cannot be saved as completed state.
There is no whole-world rollback or post-step pin teleport.

Inter-instance shared carriers are sequentially coupled, not one global implicit
root; they must actually close or reject completion. The backward-Euler contact
model has a measured orbital angular truncation term. Independent final
penetration, mount, work and deformation measurements remain necessary.
The corrective candidate is still under investigation; analytic passes do not
certify the full-car road-speed cases. See [current scope and evidence](../M83_STRUCTURAL_CRASH.md).

`deformable.attachedBodyContact` is an optional authored boolean, default false.
The default excludes active attachment targets as whole bodies. When true, only
weighted contact samples entirely covered by the union of active, unreleased
attachment groups on that same physical body are exempt from that target.
Groups on another body cannot supply coverage. Other folded material can contact
it, and a mixed pinned/unpinned sample remains physical. Released patches
immediately regain contact. Normal bilateral collision layers/masks still apply.
Use [world debug views](entities.md#diagnostic-geometry) to inspect material
surfaces, connections and actual contact normals alongside rigid collision.
