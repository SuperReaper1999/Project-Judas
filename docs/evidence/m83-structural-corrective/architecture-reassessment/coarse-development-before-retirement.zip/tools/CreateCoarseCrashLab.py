#!/usr/bin/env python3
"""M83 current content: real coarse material partitions, wheels and transmission.
The rejected node laboratory remains a separate preserved research project.
"""
from pathlib import Path
import argparse,json,math,shutil,subprocess
import CreateStructuralCrashLab as f
ROOT=f.ROOT
OUT=ROOT/'projects/coarse_crash_lab'
f.OUT=OUT
f.IDS={k:v.replace('c83c','c83d') for k,v in f.IDS.items()}

def material(variant,root):
 values={'asset':f.IDS[variant],'enabled':1,'selfContact':1,'substeps':2,'iterations':12,
 'collisionLayer':1,'collisionMask':7,'material.density':526/(1.6*.56*3.6),'material.stretchCompliance':1e-7,
 'material.shearCompliance':1e-7,'material.bendCompliance':1e-5,'material.volumeCompliance':1e-8,
 'material.damping':0,'material.thickness':.025,'material.friction':.6,'material.airDrag':0,
 'material.yieldStrain':0,'material.plasticRate':0,'material.maximumPlasticStrain':0,'airVelocity':'0 0 0'}
 fields=''.join(f'  deformable.{k} {json.dumps(str(v))}\n' for k,v in values.items())
 fields+='  deformable.attachments '+json.dumps(f'2 "part-4" 1 {root} "" 0 0 0 1 "part-5" 1 {root} "" 0 0 0 1')+'\n'
 return fields

def train(root):
 graph={'version':1,'enabled':True,'shafts':[{'name':'motor','kind':'internal','inertia':.4,'initialAngularVelocity':0,'viscousDrag':.01,'target':'0','bearing':str(root),'axis':[1,0,0]}],
 'sources':[{'name':'motor','shaft':0,'kind':'electric','torqueCurve':[],'maxTorque':220,'maxPower':75000,'starterTorque':0}],'links':[],'brakes':[]}
 for i in range(4):
  graph['shafts'].append({'name':f'wheel{i+1}','kind':'wheel','inertia':.2,'initialAngularVelocity':0,'viscousDrag':0,'target':str(root+i+1),'bearing':'0','axis':[1,0,0]})
  link={'name':f'drive{i+1}','kind':'clutch','input':0,'output':i+1,'outputB':0,'ratio':.25,'maxTorque':350}
  if i<2:link['connection']={'owner':str(root+20),'attachment':f'part-{i}','rootAttachment':f'part-{i+4}','groups':True}
  graph['links'].append(link);graph['brakes'].append({'name':f'wheel{i+1}','shaft':i+1,'maxTorque':500})
 return '  powertrain.graph '+json.dumps(json.dumps(graph,separators=(',',':')))+'\n'

def car(root,pos,variant='nominal',q=(1,0,0,0)):
 # Supported hollow roof and pillars: these collision boxes have their own
 # explicit50kg; they do not duplicate the526kg six-section lower body.
 shell=[('roof',(0,.77,.52),(.75,.035,.98)),('rear rail',(0,.20,1.72),(.75,.20,.06)),
 ('left A',(-.74,.55,-.34),(.035,.25,.035)),('right A',(.74,.55,-.34),(.035,.25,.035)),
 ('left B',(-.74,.55,.58),(.035,.25,.035)),('right B',(.74,.55,.58),(.035,.25,.035)),
 ('left C',(-.74,.55,1.42),(.035,.25,.035)),('right C',(.74,.55,1.42),(.035,.25,.035))]
 color={'nominal':(.95,.35,.12),'strong':(.3,.75,.46),'weak':(.75,.28,.52)}[variant]
 result=f.object_(root,'Supported hollow cabin',pos,f.compound(shell,50)+train(root),q)
 for i,(name,p,h) in enumerate(shell):result+=f.object_(root+100+i,name,p,f.render(h,color),parent=root)
 for i,(p,h) in enumerate([((0,.48,-.35),(.68,.24,.012)),((0,.48,1.44),(.68,.24,.012)),((-.76,.48,.55),(.01,.24,.83)),((.76,.48,.55),(.01,.24,.83))]):
  result+=f.object_(root+120+i,'Cabin glass',p,f.render(h,(.05,.23,.30)),parent=root)
 result+=f.object_(root+20,'Six physical crush sections',(0,0,0),material(variant,root)+f.render((.8,.28,1.8),color),parent=root)
 for i,(side,z) in enumerate([(-1,-1.20),(1,-1.20),(-1,1.20),(1,1.20)]):
  mount=(side*.43,.12,0) if i<2 else (side*.83,.12,z)
  chassis=root+20 if i<2 else root
  wheel=f.wheel(chassis,mount)
  if i<2:wheel+=f'  wheel.part "part-{i}"\n'
  result+=f.object_(root+1+i,'Tyre', (side*.83,-.20,z),f'  render mesh\n  render.mesh-asset "{f.IDS["wheel"]}"\n  render.color .055 .06 .075\n'+wheel,parent=root)
 return result

def script(case):return f.script(case)
def scene(case):
 q=f.rotation((1/math.sqrt(14),2/math.sqrt(14),3/math.sqrt(14)),.7) if case=='rotated' else (1,0,0,0)
 result=f.settings('Physical section crash / '+case)+f.object_(1,'Gravity frame',(0,0,0),'  gravity uniform 9.81\n  gravity.region sphere 200\n',q)
 result+=f.object_(3,'Ground',(0,-.15,0),f.render((40,.15,150),(.11,.16,.20))+f.body((40,.15,150)),parent=1)
 if case!='normal':
  half=(.4,1.3,.3) if case=='offset' else (20,1.3,.3)
  result+=f.object_(5000,'Impact wall',(.57 if case=='offset' else 0,1.3,-.3),f.render(half,(.40,.47,.51))+f.body(half),parent=1)
 else:result+=f.object_(5000,'Uneven road',(0,.04,-8),f.render((3,.04,.25),(.35,.42,.47))+f.body((3,.04,.25)),parent=1)
 result+=f.object_(10,'Inputs and public JS',(0,0,0),script(case))
 count=4 if case=='group' else 3 if case=='comparison' else 1
 for i in range(count):
  pos=f.rotate(q,((i-(count-1)/2)*4.5,.67,90))
  result+=car(900+300*i,pos,('weak','nominal','strong')[i] if case=='comparison' else 'nominal',q)
 result+=f.object_(60,'Observer start',f.rotate(q,(7,3,96)),'  player-start first-person\n',q)
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--baker',type=Path,default=ROOT/'build/judas_deformable_bake');p.add_argument('--source-only',action='store_true');a=p.parse_args()
 for d in ['Assets/deformables','Assets/models','Assets/scripts','Assets/fonts','Assets/ui','Assets/prefabs','Assets/worlds','Scenes','Saves']:(OUT/d).mkdir(parents=True,exist_ok=True)
 for name,scale in [('nominal',1),('strong',1.4),('weak',.7)]:
  rel=f'Assets/deformables/{name}.judasdeform'
  if not a.source_only:subprocess.run([str(a.baker),'material-sections',str(OUT/rel),'2','1','3','1.6','.56','3.6',str(scale)],check=True)
  f.metadata(rel,name,'deformable')
 for rel in ['Assets/models/wheel.obj','Assets/fonts/DejaVuSans.ttf','Assets/fonts/LICENSE.txt','Assets/scripts/math.js','Assets/ui/lab.judasui']:
  source=ROOT/'projects/structural_crash_lab'/rel
  if rel.endswith('.txt') or rel.endswith('.ttf') or rel.endswith('.obj'):shutil.copyfile(source,OUT/rel)
  else:(OUT/rel).write_text(source.read_text().replace('c83c','c83d').replace('STRUCTURAL CRASH LAB','PHYSICAL CRASH LAB'))
 for rel,name,kind in [('Assets/models/wheel.obj','wheel','mesh'),('Assets/fonts/DejaVuSans.ttf','font','font'),('Assets/scripts/math.js','math','script'),('Assets/scripts/controller.js','controller','script'),('Assets/ui/lab.judasui','ui','ui'),('Assets/prefabs/car.judasprefab','car','prefab'),('Assets/worlds/lab.judasworld','world','world')]:f.metadata(rel,name,kind)
 for case in ['normal','low','medium','high','offset','comparison','rotated','group']:(OUT/f'Scenes/{case}.judas').write_text(scene(case))
 (OUT/'Assets/prefabs/car.judasprefab').write_text(f.settings('Physical car prefab')+car(900,(0,.67,0)))
 annex=f.settings('Independent streamed physical car')+f.object_(301,'Annex ground',(0,-.15,60),f.render((10,.15,20),(.14,.20,.18))+f.body((10,.15,20)))+car(900,(0,.67,60))
 (OUT/'Scenes/annex.judas').write_text(annex)
 (OUT/'Assets/worlds/lab.judasworld').write_text('JudasWorld 1\nbudget 2 8 2 8388608 8388608 8388608 2097152\nregion "annex" "Scenes/annex.judas" 16 0 0 0 0 0 1 4 5 165 1 "snapshot" 1048576 ""\n')
 original=(ROOT/'projects/structural_crash_lab/structural_crash_lab.judasproj').read_text()
 (OUT/'coarse_crash_lab.judasproj').write_text(original.replace('Structural Crash Lab','Physical Crash Lab').replace('c83c','c83d'))
 print(OUT)
if __name__=='__main__':main()
