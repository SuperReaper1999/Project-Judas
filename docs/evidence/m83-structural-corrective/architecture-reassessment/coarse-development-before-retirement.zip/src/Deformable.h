#pragma once
#include "Classification.h"
#include "FractureTypes.h"
#include "StructuralNetwork.h"
#include "MeshData.h"
#include "PhysicsWorld.h"
#include "GravityField.h"
#include <array>
#include <map>
#include <memory>
#include <string>
#include <vector>

class SaveArchive;
struct SceneObject;
enum class DeformableKind { Cloth, Solid, Structure };
struct DeformableMaterial {
    double density=0.4; // kg/m² for cloth, kg/m³ for solids
    double stretchCompliance=1e-6,shearCompliance=1e-5,bendCompliance=1e-3,volumeCompliance=1e-7;
    double damping=0.4,thickness=0.025,friction=0.4,airDrag=0;
    double yieldStrain=0,plasticRate=0,maximumPlasticStrain=0.4;
    glm::dvec3 airVelocity{0};
    void Save(SaveArchive&);
};
struct DeformableAttachment {
    enum class Kind { World, Body, Bone };
    std::string group,joint;
    Kind kind=Kind::World;
    uint64_t target=0;
    glm::dvec3 offset{0};
    bool enabled=true;
    // Optional finite strength of a physical body/material patch. Zero keeps
    // the legacy unlimited connection. Limits are resultant N and N m, not
    // per-node thresholds or a gameplay damage counter.
    double forceLimit=0,torqueLimit=0;
    void Save(SaveArchive&);
};
struct DeformableSettings {
    std::string asset;
    bool enabled=true,selfContact=true,attachedBodyContact=false;
    unsigned substeps=4,iterations=4,collisionLayer=0;
    CategoryMask collisionMask=kAllCategories;
    DeformableMaterial material;
    std::vector<DeformableAttachment> attachments;
};
bool ValidDeformableSettings(const DeformableSettings&,std::string&);
std::map<std::string,std::string> DeformableProperties(const SceneObject&);
bool ApplyDeformableProperties(const std::map<std::string,std::string>&,SceneObject&,std::string&);

// Immutable decoded/baked topology. Render seams are separate vertices whose
// stored weights address deliberate simulation indices, never position welding.
struct DeformableBinding {
    glm::uvec4 nodes{0}; glm::dvec4 weights{1,0,0,0};
    void Save(SaveArchive&);
};
struct DeformableTriangle {
    glm::uvec3 nodes{0}; glm::dmat2 inverseRest{1};double area=0;
};
struct DeformableTet {
    glm::uvec4 nodes{0};glm::dmat3 rest{1},inverseRest{1};double volume=0;
};
struct DeformableBend {unsigned a=0,b=0;double rest=0;};
struct DeformableAsset {
    DeformableKind kind=DeformableKind::Cloth;
    std::shared_ptr<FractureCook> fracture;
    std::shared_ptr<StructuralCook> structure;
    std::vector<glm::dvec3> nodes;
    std::vector<double> massWeights; // positive nodal mass multiplier
    std::vector<glm::uvec3> triangles;
    std::vector<glm::uvec4> tetrahedra;
    std::map<std::string,std::vector<unsigned>> groups;
    MeshData render;
    std::vector<DeformableBinding> binding;
    std::string sourceAsset,sourceFingerprint;
    // Derived, validated once during preparation. Not mutable instance state.
    std::vector<double> measures;
    std::vector<DeformableTriangle> cloth;
    std::vector<DeformableTet> solids;
    std::vector<DeformableBend> bends;
    std::vector<glm::uvec2> edges;
    std::vector<std::vector<unsigned>> neighbors,excludedFaces,excludedEdges,edgeFaces;
    double cellSize=0;
};
bool PrepareDeformableAsset(DeformableAsset&,std::string&);
bool DecodeDeformableAsset(const std::vector<unsigned char>&,DeformableAsset&,std::string&);
std::string EncodeDeformableAsset(const DeformableAsset&);
DeformableAsset MakeDeformableSheet(unsigned columns,unsigned rows,double width,double height,unsigned renderSubdivision=1);
DeformableAsset MakeDeformableBlock(glm::uvec3 cells,glm::dvec3 size);
bool ImportDeformableCloth(const MeshData&,DeformableAsset&,std::string&);

struct DeformableLocation {uint64_t generation=0;unsigned triangle=0;glm::dvec3 weights{1,0,0};uint64_t topologyRevision=0;};
struct DeformableHit {bool hit=false;double distance=0;glm::dvec3 point{0},normal{0};DeformableLocation location;};
struct DeformableStats {size_t nodes=0,triangles=0,tets=0,contacts=0,candidates=0,sweptContacts=0;unsigned substeps=0,iterations=0;double minimumJacobian=1,maximumStrain=0,maximumPenetration=0;bool capacityExceeded=false;};
struct DeformableContactObservation {glm::dvec3 point{0},normal{0};double penetration=0;bool swept=false,self=false;BodyHandle body{};double normalImpulse=0;};

// Targets are sampled by RuntimeWorld AFTER ordinary pose resolution, once per
// fixed step. Prescribed targets never receive reaction; Body targets do.
struct DeformableTarget {bool valid=false;glm::dmat4 previous{1},current{1};BodyHandle body;};
struct DeformableAttachmentState {
    glm::dvec3 force{0},moment{0}; // Last substep's actual body reaction, world-space.
    double peakForce=0,peakTorque=0; // Maximum resultant demand in the completed fixed step.
};
class DeformableInstance {
public:
    std::shared_ptr<const DeformableAsset> asset;
    DeformableSettings settings;
    uint64_t generation=0;
    std::vector<glm::dvec3> positions,previous,velocities;
    std::vector<glm::dmat3> plasticRest;
    std::vector<uint8_t> released;
    std::vector<DeformableAttachmentState> attachmentState;
    bool sleeping=false;double quietSeconds=0;
    std::string error;
    DeformableStats stats;
    FractureState fracture;
    StructuralState structure;
    std::vector<DeformableContactObservation> contactObservations;
    double NodeMass(unsigned n)const{return mass.at(n);}
    bool PartLoad(unsigned part,glm::dvec3 value,bool impulse);
    bool Structural()const{return asset&&bool(asset->structure);}
    uint64_t TopologyRevision()const{return Structural()?structure.revision:asset&&asset->fracture?fracture.revision:0;}
    bool ConnectedNodes(const std::vector<unsigned>&,const std::vector<unsigned>&)const;
    bool FaceVisible(unsigned face)const;
    void Cohesive(double h);
    void Initialize(std::shared_ptr<const DeformableAsset>,const DeformableSettings&,const glm::dmat4&,uint64_t);
    void Reset(const glm::dmat4&);
    bool SetMaterial(const DeformableMaterial&,std::string&);
    bool Impulse(const std::string& group,glm::dvec3 impulse);
    bool Impulse(const DeformableLocation&,glm::dvec3 impulse);
    bool Force(const std::string& group,glm::dvec3 force);
    bool Release(const std::string& group);
    void Wake(){sleeping=false;quietSeconds=0;}
    void Step(double dt,PhysicsWorld&,const GravityField&,const std::vector<DeformableTarget>&);
    void StepStructuralInterval(double dt,PhysicsWorld&,const GravityField&,const std::vector<DeformableTarget>&,bool beginMacro,bool endMacro);
    bool BeginStructuralInterval(double dt,PhysicsWorld&,const GravityField&,const std::vector<DeformableTarget>&,bool beginMacro,bool predictive=false);
    void SolveStructuralContacts(double dt,PhysicsWorld&,const std::vector<DeformableTarget>&);
    void SolveStructuralIteration(double dt,PhysicsWorld&,const std::vector<DeformableTarget>&);
    void EndStructuralInterval(double dt,PhysicsWorld&,bool endMacro);
    void MapRender(double alpha,MeshData&)const;
    DeformableHit Raycast(glm::dvec3 origin,glm::dvec3 direction,double maximum)const;
    void Persist(SaveArchive&,bool materialFrame=true,bool attachmentLimits=true,bool structuralState=true);
    glm::dvec3 Minimum()const;
    glm::dvec3 Maximum()const;
    double Mass()const;
    // Shared accelerated surface solve, including self contact with topology
    // exclusions. Both participants receive the same mass-weighted projection.
    static void SurfaceContacts(DeformableInstance&,DeformableInstance&,double);
    // Native diagnostic reference path: disable only conservative early culls.
    // Sampling, topology, pin coverage and narrowphase remain identical.
    void SetContactCullingEnabled(bool enabled){contactCullingEnabled=enabled;}
    void SetContactSampleCacheEnabled(bool enabled){contactSampleCacheEnabled=enabled;}
    bool StructuralDiagnosticActive()const{return structuralTraceActive;}
    unsigned StructuralDiagnosticInterval()const{return structuralTraceInterval;}
    unsigned StructuralDiagnosticRound()const{return structuralTraceRound;}
private:
    std::vector<double> inverseMass,mass,lambda,volumeLambda;
    std::vector<glm::dvec3> start,forces,lastGravity;
    std::vector<glm::dvec3> attachmentImpulse,attachmentMoment;
    std::vector<uint8_t> attachmentPending;
    glm::dmat4 initial{1};
    struct SurfaceNode {glm::dvec3 low{0},high{0};unsigned left=~0u,right=~0u,primitive=~0u;};
    std::vector<SurfaceNode> faceTree,edgeTree;
    std::vector<unsigned> candidates,faceExcluded,edgeExcluded;
    unsigned queryEpoch=0;
    std::vector<glm::uvec2> selfFacePairs,selfEdgePairs;
    std::vector<glm::dvec3> contactReference,contactStartReference;
    bool selfCandidatesValid=false;
    uint64_t selfCandidateTopology=0;
    uint64_t contactExclusionTopology=~uint64_t(0);
    std::vector<std::vector<unsigned>> contactExcludedFaces,contactExcludedEdges;
    std::shared_ptr<const DeformableAsset> contactIndexedAsset;
    std::vector<int> contactEdgeBeam;
    std::vector<uint8_t> contactPinned;
    std::vector<unsigned> contactVisibleEdges,contactVisibleFaces;
    struct RigidContactSample {
        glm::uvec3 nodes{0};glm::dvec3 weights{0},point{0},old{0},relativeOld{0};
        std::array<uint64_t,3> pointRevision{};
        uint64_t relativeBody=0;
        bool pointValid=false,oldValid=false;
    };
    std::vector<RigidContactSample> contactRigidSamples;
    std::vector<uint64_t> contactNodeRevision;
    // Predictive discovery refits one conservative sample tree per body.
    // It indexes the same physical samples as the independent scanner.
    std::vector<SurfaceNode> rigidSampleTree;
    std::vector<glm::uvec3> rigidSampleTreeNodes;
    std::vector<glm::dvec3> rigidSampleTreeWeights;
    std::vector<unsigned> rigidSampleCandidates;
    uint64_t rigidSampleTopology=~uint64_t(0);
    void PrepareRigidSampleTree();
    void RefitRigidSampleTree(glm::dvec3,glm::dvec3,const glm::dquat&,uint64_t);
    void QueryRigidSampleTree(glm::dvec3,glm::dvec3,double);
    bool contactCullingEnabled=true;
    bool contactSampleCacheEnabled=true;
    void PrepareContactEdges();
    unsigned activeSubsteps=1;
    double structuralMacroSeconds=0;
    bool structuralIntervalTargetMoving=false,structuralIntervalOpen=false;
    // Native velocity participant only: material and finite pins share the
    // rigid world's predicted endpoint before its one authoritative advance.
    bool structuralPredictiveCoupling=false;
    bool structuralTraceActive=false;
    unsigned structuralTraceInterval=0,structuralTraceRound=0,structuralTraceNumericalRound=0;
    std::vector<std::vector<glm::dvec3>> structuralPinMultipliers;
    std::vector<std::vector<glm::dvec3>> structuralPinMoments;
    std::vector<BodyHandle> structuralPinnedBodies;
    std::vector<double> structuralPrimalFactor;
    StructuralPrimalTraversal structuralFactorTraversal;
    std::vector<glm::dvec3> structuralFreePositions;
    struct StructuralOwnedBody {
        BodyHandle handle{};
        // Actual native world impulses owned by this participant only. Other
        // rigid/contact/joint solver contributions remain in the free motion.
        glm::dvec3 impulse{0},moment{0};
        // Smooth requested interval wrench and actual native publication are
        // separate. Their bounded sub-ULP remainder is never hidden force work.
        glm::dvec3 idealImpulse{0},idealMoment{0};
    };
    std::vector<StructuralOwnedBody> structuralOwnedBodies;
    double structuralMeritPenalty=0;
    bool structuralRootCertified=false,structuralRootRequired=false,structuralIntervalCompleted=true;
    unsigned structuralRootDimension=0;
    struct StructuralEndpoint {BodyHandle body;BodyTransform predicted;glm::vec3 linearVelocity,angularVelocity;};
    std::vector<StructuralEndpoint> structuralPredictedEndpoints;
    struct StructuralContactRow {
        glm::uvec3 nodes{0},otherNodes{0};
        glm::dvec3 weights{0},otherWeights{0};
        BodyHandle body{};
        unsigned primitive=0,sample=0,otherPrimitive=0;
        bool self=false,swept=false,seen=false,sweptPlane=false;
        glm::dvec3 localPoint{0},localNormal{0},worldPoint{0},normal{0},startPoint{0};
        double gap=0,oldDepth=0,normalLambda=0;
        glm::dvec3 tangentLambda{0},normalNet{0},bodyMoment{0};
    };
    std::vector<StructuralContactRow> structuralContactRows;
    PreciseBodyPrediction StructuralPrediction(PhysicsWorld&,BodyHandle,double,glm::dvec3 extraImpulse=glm::dvec3(0),glm::dvec3 extraMoment=glm::dvec3(0))const;
    void PublishStructuralContacts(double);
    void RefreshStructuralPins(double,PhysicsWorld&,const std::vector<DeformableTarget>&);
    bool StructuralPrimalBlock(double,PhysicsWorld&,const std::vector<DeformableTarget>&,bool& applicable);
    bool StructuralBlock(double,PhysicsWorld&,const std::vector<DeformableTarget>&);
    void PrepareSelfCandidates();
    void InitializeSurfaceTree(std::vector<SurfaceNode>&,bool);
    std::vector<BodyHandle> rigidCandidates;
    void Internal(double);
    void Plastic(double);
    void Attach(double,double,PhysicsWorld&,const std::vector<DeformableTarget>&);
    void RigidContacts(double,double,PhysicsWorld&,const std::vector<DeformableTarget>&);
    void BuildSurfaceTree();
    void SurfaceCandidates(glm::dvec3,glm::dvec3,bool,const std::vector<unsigned>* exclusions=nullptr,unsigned minimum=0);
};
