#include "Deformable.h"
#include "CollisionGeometry.h"
#include "Narrowphase.h"
#include "SaveArchive.h"
#include "PerformanceProfiler.h"
#include "StructuralContactQP.h"
#include "StructuralContactGeometry.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <glm/gtc/matrix_transform.hpp>

namespace {
using V=glm::dvec3;
    using M=glm::dmat3;
M StructuralInertiaMetric(PhysicsWorld& physics,BodyHandle body){
    // The public native tensor is computed/inverted in float. Roundoff may
    // make its off-diagonal copies differ; an energy Hessian is symmetric.
    // Retain the physical tensor and reconcile only that antisymmetric noise.
    const M inertia=physics.GetInertiaWorld(body);
    return .5*(inertia+glm::transpose(inertia));
}
bool finite(V v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);
        }
bool validMasses(const DeformableAsset& a,double density){
    double total=0;
    for(size_t i=0;i<a.measures.size();++i){
        double mass=a.measures[i]*a.massWeights[i]*density;
        if(!std::isfinite(mass)||mass<=0||!std::isfinite(1/mass))return false;
        total+=mass;
    }
    return std::isfinite(total)&&total>0;
}
M columns(const std::vector<V>& x,glm::uvec4 n){return M(x[n.y]-x[n.x],x[n.z]-x[n.x],x[n.w]-x[n.x]);
        }
M cofactor(M f){return M(glm::cross(f[1],f[2]),glm::cross(f[2],f[0]),glm::cross(f[0],f[1]));
        }
V target(const glm::dmat4& m,V p){return V(m*glm::dvec4(p,1));
        }
// Closest triangle coordinates, valid for edges/vertices as well as its face.


void scalar(std::vector<V>& x,const std::vector<double>& w,const unsigned* ids,const V* gradients,unsigned n,double C,double compliance,double h,double& lambda){
    double alpha=compliance/(h*h),den=alpha;
        for(unsigned k=0;k<n;++k)den+=w[ids[k]]*glm::dot(gradients[k],gradients[k]);
        if(den<1e-20)return;
        double dl=(-C-alpha*lambda)/den;
        lambda+=dl;
        for(unsigned k=0;k<n;++k)x[ids[k]]+=w[ids[k]]*dl*gradients[k];
}
double effective(PhysicsWorld& p,BodyHandle b,V point,V normal){
    if(!p.IsDynamicBody(b))return 0;
        double m=p.GetMass(b);
        if(m<=0)return 0;
        V r=point-V(p.GetCenterOfMass(b)),rn=glm::cross(r,normal);
        return 1/m+glm::dot(rn,M(glm::inverse(p.GetInertiaWorld(b)))*rn);
}
V pointVelocity(PhysicsWorld& p,BodyHandle b,V point){return V(p.GetLinearVelocity(b))+glm::cross(V(p.GetAngularVelocity(b)),point-V(p.GetCenterOfMass(b)));
        }
// Bounded, native-only investigation of stiff-network compatibility. The
// reference is interval-start rest, so the first elastic startup intervals
// provide an exact residual; plastic intervals are explicitly marked. This
// diagnostic never changes material state, quality, contact, or body motion.
struct StructuralIterationTrace {
    FILE* network=nullptr;FILE* attachments=nullptr;FILE* blocks=nullptr;FILE* dual=nullptr;FILE* bodies=nullptr;FILE* nonlinear=nullptr;
    unsigned skip=0;
    std::map<uint64_t,unsigned> calls;
    StructuralIterationTrace(){const char* path=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE");if(!path||!*path)return;
        if(const char* omitted=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE_SKIP")){char* end=nullptr;const auto value=std::strtoul(omitted,&end,10);if(end&&!*end&&value<=1000000)skip=unsigned(value);}
        nonlinear=std::fopen((std::string(path)+".nonlinear.csv").c_str(),"w");
        if(nonlinear)std::fputs("generation,interval,substep,iteration,alpha,backtracks,penalty,merit_before,merit_after,slope,root_gap_residual_m,root_complementarity,krylov_iterations,root_dimension,true_equilibrium_residual,worst_free_velocity_defect_mps,worst_body_velocity_defect_mps,worst_body_angular_defect_radps,actual_gap_violation_m,actual_complementarity,actual_friction_residual_kgm,precision_limited,physical_roundoff_bound,numerical_iteration\n",nonlinear);
        network=std::fopen(path,"w");blocks=std::fopen((std::string(path)+".blocks.csv").c_str(),"w");dual=std::fopen((std::string(path)+".dual.csv").c_str(),"w");bodies=std::fopen((std::string(path)+".bodies.csv").c_str(),"w");attachments=std::fopen((std::string(path)+".attachments.csv").c_str(),"w");
        if(network)std::fputs("generation,interval,macro_substep,iteration,stage,beam,key,interval_start_plastic,reference_geom_pa,constraint_elastic_pa,compatibility_m,compatibility_pa,max_geom_pa,max_constraint_pa,contacts,actual_world_impulse_x,actual_world_impulse_y,actual_world_impulse_z,reprojected_scalar_x,reprojected_scalar_y,reprojected_scalar_z,world_history_mismatch,linearization_normal_x,linearization_normal_y,linearization_normal_z,current_normal_x,current_normal_y,current_normal_z\n",network);
        if(attachments)std::fputs("generation,interval,macro_substep,iteration,attachment,body,max_start_drift_m,max_end_drift_m,max_relative_velocity_mps,body_linear_velocity_delta_mps,body_angular_velocity_delta_radps,max_unintegrated_point_motion_m,body_pose_translation_delta_m,body_pose_rotation_delta,max_node_attachment_motion_m,reaction_impulse_ns,reaction_moment_nms\n",attachments);
        if(blocks)std::fputs("generation,interval,substep,iteration,stage,dimension,beams,contacts,free_node_correction_m,free_body_translation_m,free_body_angle_rad,tangent_min,tangent_max,world_history_max,body_linear_impulse_ns,body_angular_impulse_nms\n",blocks);
        if(dual)std::fputs("generation,interval,substep,iteration,row,body,world,primitive,sample,self,gap_m,inverse_response,normal_lambda_old,normal_lambda_new,normal_delta,tangent_old,tangent_new,tangent_delta,normal_history_mismatch,normal_x,normal_y,normal_z,tangent_det\n",dual);
        if(bodies)std::fputs("generation,interval,substep,iteration,body,world,impulse_x,impulse_y,impulse_z,angular_x,angular_y,angular_z,linear_before_x,linear_before_y,linear_before_z,linear_after_x,linear_after_y,linear_after_z,angular_before_x,angular_before_y,angular_before_z,angular_after_x,angular_after_y,angular_after_z\n",bodies);
    }
    ~StructuralIterationTrace(){if(nonlinear)std::fclose(nonlinear);if(blocks)std::fclose(blocks);if(dual)std::fclose(dual);if(bodies)std::fclose(bodies);if(network)std::fclose(network);if(attachments)std::fclose(attachments);}
};
StructuralIterationTrace& IterationTrace(){static StructuralIterationTrace trace;return trace;}
void TraceNetwork(StructuralIterationTrace& trace,const DeformableInstance& instance,const std::vector<V>& intervalStart,double h,unsigned interval,unsigned iteration,const char* stage){
    if(!trace.network)return;
    double largest=-1,maxGeometry=0,maxConstraint=0;unsigned worst=0;double geometry=0,constraint=0,residual=0;
    for(unsigned i=0;i<instance.asset->structure->beams.size();++i){if(instance.structure.broken[i])continue;const auto& b=instance.asset->structure->beams[i];const auto& r=instance.asset->structure->regions[b.region];
        const double length=glm::length(instance.positions[b.b]-instance.positions[b.a]),old=glm::length(intervalStart[b.b]-intervalStart[b.a]);
        const double geometric=r.youngModulus*(length-instance.structure.restLengths[i])/b.restLength;
        const double solved=-instance.structure.multipliers[i]/(h*h*b.area)-r.damping*(length-old)/(h*b.area);
        maxGeometry=std::max(maxGeometry,std::abs(geometric));maxConstraint=std::max(maxConstraint,std::abs(solved));
        if(std::abs(geometric-solved)>largest){largest=std::abs(geometric-solved);worst=i;geometry=geometric;constraint=solved;residual=(geometric-solved)*b.area/(r.youngModulus*b.area/b.restLength+r.damping/h);}
    }
    if(largest<0)return;
    const auto& beam=instance.asset->structure->beams[worst];
    const V currentNormal=glm::normalize(instance.positions[beam.b]-instance.positions[beam.a]),actualImpulse=instance.structure.appliedBeamImpulse[worst],scalarImpulse=currentNormal*instance.structure.multipliers[worst],priorNormal=instance.structure.beamLinearizationNormal[worst];
    const bool plastic=std::any_of(instance.structure.accumulatedPlasticStrain.begin(),instance.structure.accumulatedPlasticStrain.end(),[](double value){return value>0;});
    std::fprintf(trace.network,"%llu,%u,%u,%u,%s,%u,%s,%u,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%zu,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n",(unsigned long long)instance.generation,interval,instance.stats.substeps,iteration,stage,worst,beam.key.c_str(),plastic?1u:0u,geometry,constraint,residual,largest,maxGeometry,maxConstraint,instance.stats.contacts,actualImpulse.x,actualImpulse.y,actualImpulse.z,scalarImpulse.x,scalarImpulse.y,scalarImpulse.z,glm::length(actualImpulse-scalarImpulse),priorNormal.x,priorNormal.y,priorNormal.z,currentNormal.x,currentNormal.y,currentNormal.z);
    std::fflush(trace.network);
}
}
void DeformableInstance::Initialize(std::shared_ptr<const DeformableAsset> data,const DeformableSettings& config,const glm::dmat4& transform,uint64_t epoch){
    std::string e;
    if(!data||!ValidDeformableSettings(config,e))throw std::invalid_argument(e.empty()?"missing deformable asset":e);
    if(data->nodes.size()!=data->measures.size()||data->nodes.size()!=data->massWeights.size()||data->neighbors.size()!=data->nodes.size())throw std::invalid_argument("deformable topology is not prepared");
    if(!validMasses(*data,config.material.density))throw std::invalid_argument("deformable derived mass is not finite and positive");
    if(data->fracture&&data->fracture->rigid&&std::any_of(config.attachments.begin(),config.attachments.end(),[](const auto& a){return a.forceLimit>0||a.torqueLimit>0;}))throw std::invalid_argument("finite material attachment strength requires deformable material; rigid fracture uses section bonds");
    asset=std::move(data);
    settings=config;
    generation=epoch;
    initial=transform;
    size_t n=asset->nodes.size();
    positions.resize(n);
    previous.resize(n);
    start.resize(n);
    velocities.resize(n);
    forces.resize(n);
    lastGravity.resize(n);
    mass.resize(n);
    inverseMass.resize(n);
    lambda.resize(asset->cloth.size()*3+asset->solids.size()*6+asset->bends.size());
    volumeLambda.resize(asset->solids.size());
    plasticRest.resize(asset->solids.size());
    released.resize(config.attachments.size());
    attachmentState.resize(config.attachments.size());
    candidates.reserve(std::max(asset->triangles.size(),asset->edges.size()));
    InitializeSurfaceTree(faceTree,false);InitializeSurfaceTree(edgeTree,true);
    faceExcluded.resize(asset->triangles.size());edgeExcluded.resize(asset->edges.size());
    contactReference.resize(n);contactStartReference.resize(n);
    selfFacePairs.reserve(std::min<size_t>(524288,asset->nodes.size()*64));selfEdgePairs.reserve(std::min<size_t>(524288,asset->edges.size()*64));
    rigidCandidates.reserve(256);
    if(asset->fracture)fracture.Initialize(*asset->fracture);
    contactObservations.reserve(256);
    Reset(transform);
}
void DeformableInstance::Reset(const glm::dmat4& transform){
    initial=transform;
    structuralPrimalFactor.clear();structuralFactorTraversal.Clear();structuralContactRows.clear();structuralFreePositions.clear();structuralOwnedBodies.clear();structuralPinMoments.clear();structuralMeritPenalty=0;structuralTraceInterval=structuralTraceRound=structuralTraceNumericalRound=0;structuralTraceActive=false;structuralIntervalCompleted=true;structuralRootCertified=false;structuralRootRequired=false;structuralRootDimension=0;structuralPredictedEndpoints.clear();
    selfCandidatesValid=false;
    contactExclusionTopology=~uint64_t(0);
    error.clear();
    for(size_t i=0;i<positions.size();++i){positions[i]=previous[i]=start[i]=target(transform,asset->nodes[i]);
        velocities[i]=forces[i]=lastGravity[i]=V(0);
        mass[i]=asset->measures[i]*asset->massWeights[i]*settings.material.density;
        inverseMass[i]=1/mass[i];
        }
    for(size_t i=0;i<plasticRest.size();++i)plasticRest[i]=M(transform)*asset->solids[i].rest;
    if(Structural())structure.Initialize(*asset->structure,unsigned(positions.size()));
    std::fill(released.begin(),released.end(),false);
    attachmentState.assign(settings.attachments.size(),{});
    contactObservations.clear();
    Wake();
}
bool DeformableInstance::SetMaterial(const DeformableMaterial& m,std::string& e){if(asset->fracture&&asset->fracture->rigid){e="rigid fracture material is authored; reload to change mass/contact properties";return false;}auto s=settings;
    s.material=m;
    if(!ValidDeformableSettings(s,e))return false;
    // Preflight before changing any runtime material/mass state.
    if(!validMasses(*asset,m.density)){e="deformable derived mass is not finite and positive";return false;}
    settings=s;selfCandidatesValid=false;
    for(size_t i=0;i<mass.size();++i){mass[i]=asset->measures[i]*asset->massWeights[i]*m.density;
        inverseMass[i]=1/mass[i];
        }Wake();
    return true;
    }
double DeformableInstance::Mass()const{double total=0;
    for(unsigned n=0;n<mass.size();++n)if(!asset->fracture||!fracture.removed[asset->fracture->nodePart[n]])total+=mass[n];
    return total;
    }
bool DeformableInstance::ConnectedNodes(const std::vector<unsigned>& a,const std::vector<unsigned>& b)const{
    if(Structural())return structure.Connected(a,b);
    if(!asset||a.empty()||b.empty())return false;
    if(!asset->fracture)return true;
    unsigned component=~0u;
    for(const auto* nodes:{&a,&b})for(auto n:*nodes){if(n>=asset->fracture->nodePart.size())return false;const auto part=asset->fracture->nodePart[n];if(fracture.removed[part])continue;const auto actual=fracture.component[part];if(component==~0u)component=actual;else if(actual!=component)return false;}
    return component!=~0u;
}
bool DeformableInstance::FaceVisible(unsigned face)const{
    if(!asset||face>=asset->triangles.size())return false;
    if(Structural())return structure.FaceVisible(*asset,face);
    return !asset->fracture||fracture.FaceVisible(*asset,face);
}
bool DeformableInstance::PartLoad(unsigned part,V value,bool impulse){if(!asset->fracture||part>=asset->fracture->parts.size()||fracture.removed[part]||!finite(value)||!settings.enabled)return false;const auto& nodes=asset->fracture->parts[part].nodes;double total=0;for(auto n:nodes)total+=mass[n];for(auto n:nodes)if(impulse)velocities[n]+=value/total;else forces[n]+=value*mass[n]/total;Wake();return true;}
bool DeformableInstance::Impulse(const std::string& group,V impulse){if(!finite(impulse))return false;
    auto it=asset->groups.find(group);
    if(!group.empty()&&it==asset->groups.end())return false;
    double total=0;
    for(unsigned i=0;i<mass.size();++i)if((!asset->fracture||!fracture.removed[asset->fracture->nodePart[i]])&&(group.empty()||std::find(it->second.begin(),it->second.end(),i)!=it->second.end()))total+=mass[i];
    for(unsigned i=0;i<mass.size();++i)if((!asset->fracture||!fracture.removed[asset->fracture->nodePart[i]])&&(group.empty()||std::find(it->second.begin(),it->second.end(),i)!=it->second.end()))velocities[i]+=impulse/total;
    Wake();
    return true;
    }
bool DeformableInstance::Force(const std::string& group,V force){if(!settings.enabled||!error.empty()||!finite(force))return false;
    auto it=asset->groups.find(group);
    if(!group.empty()&&it==asset->groups.end())return false;
    double total=0;
    for(unsigned i=0;i<mass.size();++i)if((!asset->fracture||!fracture.removed[asset->fracture->nodePart[i]])&&(group.empty()||std::find(it->second.begin(),it->second.end(),i)!=it->second.end()))total+=mass[i];
    for(unsigned i=0;i<mass.size();++i)if((!asset->fracture||!fracture.removed[asset->fracture->nodePart[i]])&&(group.empty()||std::find(it->second.begin(),it->second.end(),i)!=it->second.end()))forces[i]+=force*mass[i]/total;
    Wake();
    return true;
    }
bool DeformableInstance::Impulse(const DeformableLocation& hit,V impulse){if(hit.generation!=generation||hit.topologyRevision!=TopologyRevision()||hit.triangle>=asset->triangles.size()||!FaceVisible(hit.triangle)||!finite(hit.weights)||!finite(impulse)||glm::any(glm::lessThan(hit.weights,V(0)))||std::abs(hit.weights.x+hit.weights.y+hit.weights.z-1)>1e-7)return false;
    auto f=asset->triangles[hit.triangle];
    for(int k=0;k<3;++k)velocities[f[k]]+=impulse*hit.weights[k]/mass[f[k]];
    Wake();
    return true;
    }
bool DeformableInstance::Release(const std::string& group){bool found=false;
    for(size_t i=0;i<settings.attachments.size();++i)if(settings.attachments[i].group==group){released[i]=true;
        found=true;
        }if(found)Wake();
    return found;
    }
V DeformableInstance::Minimum()const{V b(std::numeric_limits<double>::max());
    for(auto p:positions)b=glm::min(b,p);
    return b;
    }
V DeformableInstance::Maximum()const{V b(-std::numeric_limits<double>::max());
    for(auto p:positions)b=glm::max(b,p);
    return b;
    }

void DeformableInstance::Cohesive(double h){
    if(!asset->fracture||asset->fracture->rigid)return;
    JUDAS_PROFILE_SCOPE("Fracture cohesive constraints");
    const auto& c=*asset->fracture;
    for(unsigned b=0;b<c.bonds.size();++b){const auto& bond=c.bonds[b];if(fracture.broken[b]||fracture.removed[bond.a]||fracture.removed[bond.b])continue;
        for(unsigned pair=0;pair<bond.pairs.size();++pair){auto ids=bond.pairs[pair];double alpha=c.compliance*bond.pairs.size()/(bond.area*h*h),den=inverseMass[ids.x]+inverseMass[ids.y]+alpha;if(den<=0)continue;
            auto& lambda=fracture.multipliers[b*16+pair];V delta=positions[ids.y]-positions[ids.x],dl=(-delta-alpha*lambda)/den;lambda+=dl;positions[ids.x]-=dl*inverseMass[ids.x];positions[ids.y]+=dl*inverseMass[ids.y];
        }
    }
}
void DeformableInstance::Internal(double h){
    JUDAS_PROFILE_SCOPE("Deformable internal constraints");
    const auto& m=settings.material;
    size_t row=0;
    for(auto& t:asset->cloth){unsigned ids[3]={t.nodes.x,t.nodes.y,t.nodes.z};
        V e1=positions[ids[1]]-positions[ids[0]],e2=positions[ids[2]]-positions[ids[0]];
        V f[2]={e1*t.inverseRest[0][0]+e2*t.inverseRest[0][1],e1*t.inverseRest[1][0]+e2*t.inverseRest[1][1]};
        for(unsigned c=0;c<3;++c){unsigned a=c==1?1:0,b=c==0?0:1;
            V gradients[3];
            double C=a==b?.5*(glm::dot(f[a],f[b])-1):glm::dot(f[a],f[b]);
            for(unsigned k=1;k<3;++k)gradients[k]=a==b?f[a]*t.inverseRest[a][k-1]:f[b]*t.inverseRest[a][k-1]+f[a]*t.inverseRest[b][k-1];
            gradients[0]=-gradients[1]-gradients[2];
            scalar(positions,inverseMass,ids,gradients,3,C,(a==b?m.stretchCompliance:m.shearCompliance)/t.area,h,lambda[row++]);
            e1=positions[ids[1]]-positions[ids[0]];
            e2=positions[ids[2]]-positions[ids[0]];
            f[0]=e1*t.inverseRest[0][0]+e2*t.inverseRest[0][1];
            f[1]=e1*t.inverseRest[1][0]+e2*t.inverseRest[1][1];
        }
    }
    for(size_t index=0;index<asset->solids.size();++index){auto& t=asset->solids[index];
        if(asset->fracture&&fracture.removed[asset->fracture->nodePart[t.nodes.x]]){row+=6;continue;}
        unsigned ids[4]={t.nodes.x,t.nodes.y,t.nodes.z,t.nodes.w};
        // Rest matrices remain in their saved authored world frame. Express
        // elastic columns in the material frame so global rotation cannot
        // rotate strain components into a different compliance response.
        M inv=glm::inverse(plasticRest[index])*M(initial);
        for(unsigned a=0;a<3;++a)for(unsigned b=a;b<3;++b){M f=columns(positions,t.nodes)*inv;
            V gradients[4];
            double C=a==b?.5*(glm::dot(f[a],f[b])-1):glm::dot(f[a],f[b]);
            for(unsigned k=1;k<4;++k)gradients[k]=a==b?f[a]*inv[a][k-1]:f[b]*inv[a][k-1]+f[a]*inv[b][k-1];
            gradients[0]=-gradients[1]-gradients[2]-gradients[3];
            scalar(positions,inverseMass,ids,gradients,4,C,m.shearCompliance/t.volume,h,lambda[row++]);
            }
        M f=columns(positions,t.nodes)*inv,d=cofactor(f)*glm::transpose(inv);
        V gradients[4]={-d[0]-d[1]-d[2],d[0],d[1],d[2]};
        double J=glm::determinant(f);
        stats.minimumJacobian=std::min(stats.minimumJacobian,J);
        scalar(positions,inverseMass,ids,gradients,4,J-1,m.volumeCompliance/t.volume,h,volumeLambda[index]);
    }
    for(auto b:asset->bends){unsigned ids[2]={b.a,b.b};
        V delta=positions[b.a]-positions[b.b];
        double len=glm::length(delta);
        if(len>1e-12){V gradients[2]={delta/len,-delta/len};
            scalar(positions,inverseMass,ids,gradients,2,len-b.rest,m.bendCompliance,h,lambda[row]);
            }++row;
        }
}
void DeformableInstance::Plastic(double h){
    JUDAS_PROFILE_SCOPE("Deformable plastic flow");
    auto& m=settings.material;
    for(size_t i=0;i<plasticRest.size();++i){if(asset->fracture&&fracture.removed[asset->fracture->nodePart[asset->solids[i].nodes.x]])continue;M ds=columns(positions,asset->solids[i].nodes),f=ds*glm::inverse(plasticRest[i]);
        M strain=glm::transpose(f)*f-M(1);
        double norm=std::sqrt(glm::dot(strain[0],strain[0])+glm::dot(strain[1],strain[1])+glm::dot(strain[2],strain[2]))*.5;
        stats.maximumStrain=std::max(stats.maximumStrain,norm);
        if(m.yieldStrain<=0||m.plasticRate<=0||norm<=m.yieldStrain||glm::determinant(f)<.2)continue;
        M rotation=f;
        for(unsigned k=0;k<8;++k)rotation=.5*(rotation+glm::transpose(glm::inverse(rotation)));
        double flow=std::min(m.plasticRate*h,(norm-m.yieldStrain)/std::max(norm,1e-12));
        M next=plasticRest[i]*(1-flow)+glm::transpose(rotation)*ds*flow;
        // Isochoric plastic flow: rest mass/volume stay unchanged. Stop flow
        // at the authored rest-strain envelope instead of repairing geometry.
        double det=glm::determinant(next),originalDet=glm::determinant(asset->solids[i].rest);
        if(det<=1e-12)continue;
        next*=std::cbrt(originalDet/det);
        M deformation=next*glm::inverse(M(initial)*asset->solids[i].rest),plasticStrain=glm::transpose(deformation)*deformation-M(1);
        double extent=std::sqrt(glm::dot(plasticStrain[0],plasticStrain[0])+glm::dot(plasticStrain[1],plasticStrain[1])+glm::dot(plasticStrain[2],plasticStrain[2]))*.5;
        if(extent<=m.maximumPlasticStrain)plasticRest[i]=next;
    }
}
void DeformableInstance::Attach(double h,double fraction,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    JUDAS_PROFILE_SCOPE("Deformable attachments");
    for(size_t a=0;a<settings.attachments.size();++a){const auto& attachment=settings.attachments[a];
        if(released[a]||!attachment.enabled||a>=targets.size()||!targets[a].valid)continue;
        auto group=asset->groups.find(attachment.group);
        if(group==asset->groups.end())continue;
        const auto& t=targets[a];
        const bool dynamicTarget=t.body.IsValid()&&physics.IsDynamicBody(t.body);
        // Keep the moment origin inside the patch, independently of its world
        // placement. A pure couple must remain a torque when its net force is
        // zero; summing per-node impulse magnitudes would invent a force.
        V centre(0);
        if(dynamicTarget){V localCentre(0);unsigned activeNodes=0;
            for(unsigned n:group->second)if(!asset->fracture||!fracture.removed[asset->fracture->nodePart[n]]){localCentre+=asset->nodes[n]+attachment.offset;++activeNodes;}
            if(!activeNodes)continue;
            localCentre/=activeNodes;
            centre=target(t.previous,localCentre)*(1-fraction)+target(t.current,localCentre)*fraction;
        }
        for(unsigned n:group->second){if(asset->fracture&&fracture.removed[asset->fracture->nodePart[n]])continue;V local=asset->nodes[n]+attachment.offset,destination=target(t.previous,local)*(1-fraction)+target(t.current,local)*fraction;
            if(!dynamicTarget){positions[n]=destination;
                continue;
                }
            // Velocity-level bilateral constraint. Body point velocity is read
            // again after each impulse; no repeated reaction against a frozen
            // infinite-mass target. A bounded positional drift bias follows the
            // prior sampled anchor, independently of prescribed target motion.
            double priorFraction=fraction-1./activeSubsteps;
            V priorDestination=target(t.previous,local)*(1-priorFraction)+target(t.current,local)*priorFraction;
            for(int axis=0;axis<3;++axis){V normal(0);normal[axis]=1;
                V relative=(positions[n]-start[n])/h-pointVelocity(physics,t.body,destination);
                double den=inverseMass[n]+effective(physics,t.body,destination,normal);
                if(den<=0)continue;
                double impulse=-(relative[axis]+.1*(start[n]-priorDestination)[axis]/h)/den;
                positions[n]+=normal*inverseMass[n]*impulse*h;
                const V reaction=-normal*impulse;
                // The constraint denominator and point velocity use a double
                // lever arm. Preserve that same arm for the actual reaction;
                // rounding an absolute world point to float before subtracting
                // the COM would alter a small patch's torque at large origins.
                const V arm=destination-V(physics.GetCenterOfMass(t.body));
                physics.ApplyLinearImpulse(t.body,glm::vec3(reaction));
                physics.ApplyAngularImpulse(t.body,glm::vec3(glm::cross(arm,reaction)));
                attachmentImpulse[a]+=reaction;
                attachmentMoment[a]+=glm::cross(destination-centre,reaction);
            }
        }
    }
}
void DeformableInstance::Step(double dt,PhysicsWorld& physics,const GravityField& gravity,const std::vector<DeformableTarget>& targets){
    if(Structural()){
        if(dt<=0)return;
        // Standalone callers retain the authored quality. The coupled world
        // path supplies one already integrated rigid interval instead.
        for(unsigned sub=0;sub<settings.substeps;++sub){auto interval=targets;const double a=double(sub)/settings.substeps,b=double(sub+1)/settings.substeps;
            for(auto& t:interval)if(t.valid){const auto old=t.previous,current=t.current;t.previous=old*(1-a)+current*a;t.current=old*(1-b)+current*b;}
            StepStructuralInterval(dt/settings.substeps,physics,gravity,interval,sub==0,sub+1==settings.substeps);
            if(!error.empty())break;
        }return;
    }
    if(!asset||!settings.enabled||!error.empty()||dt<=0){std::fill(forces.begin(),forces.end(),V(0));return;}
    // A prescribed world/bone/static frame has no finite dynamic reaction in
    // this solver. Refuse a finite-strength claim rather than silently treating
    // such a target as an infinite-strength connection. Unlimited legacy roots
    // continue through exactly the original prescribed-target path.
    for(size_t i=0;i<settings.attachments.size();++i){const auto& a=settings.attachments[i];
        if(!released[i]&&a.enabled&&(a.forceLimit>0||a.torqueLimit>0)&&i<targets.size()&&targets[i].valid&&!physics.IsDynamicBody(targets[i].body)){
            error="finite attachment strength requires a dynamic body target";std::fill(forces.begin(),forces.end(),V(0));return;
        }
    }
    JUDAS_PROFILE_SCOPE("Deformable fixed step");
    attachmentState.assign(settings.attachments.size(),{});
    contactObservations.clear();activeSubsteps=settings.substeps;
    attachmentImpulse.resize(settings.attachments.size());attachmentMoment.resize(settings.attachments.size());attachmentPending.assign(settings.attachments.size(),0);
    stats={};
    stats.nodes=positions.size();
    stats.triangles=asset->triangles.size();
    stats.tets=asset->solids.size();
    stats.substeps=settings.substeps;
    stats.iterations=settings.iterations;
    for(size_t n=0;n<inverseMass.size();++n)inverseMass[n]=1/mass[n];
    for(size_t i=0;i<settings.attachments.size();++i)if(!released[i]&&settings.attachments[i].enabled&&i<targets.size()&&targets[i].valid&&!targets[i].body.IsValid()){auto group=asset->groups.find(settings.attachments[i].group);
        if(group!=asset->groups.end())for(auto n:group->second)inverseMass[n]=0;
        }
    bool targetMoving=false;
    for(auto& t:targets)if(t.valid){double d=0;
        for(int k=0;k<4;++k)d+=glm::length(t.current[k]-t.previous[k]);
        targetMoving|=d>1e-8||(t.body.IsValid()&&physics.IsDynamicBody(t.body));
        }
    bool gravityChanged=false;
    for(size_t i=0;i<positions.size();++i){V g=gravity.Sample(glm::vec3(positions[i]));
        gravityChanged|=glm::length(g-lastGravity[i])>1e-5;
        lastGravity[i]=g;
        }
    if(targetMoving||gravityChanged||settings.material.airDrag>0)Wake();
    if(sleeping){PhysicsQueryFilter f;
        f.includeLayers=settings.collisionMask;
        physics.QueryBodiesInAabbInto(glm::vec3(Minimum()-V(settings.material.thickness)),glm::vec3(Maximum()+V(settings.material.thickness)),rigidCandidates,f);
        for(auto b:rigidCandidates)if(glm::length(physics.GetLinearVelocity(b))+glm::length(physics.GetAngularVelocity(b))>1e-5)Wake();
        if(sleeping)return;
        }
    previous=positions;
    double h=dt/settings.substeps;
    for(unsigned sub=0;sub<settings.substeps;++sub){
        std::fill(attachmentImpulse.begin(),attachmentImpulse.end(),V(0));
        std::fill(attachmentMoment.begin(),attachmentMoment.end(),V(0));
        {JUDAS_PROFILE_SCOPE("Deformable force prediction");
            start=positions;
            for(size_t n=0;n<positions.size();++n){if(asset->fracture&&fracture.removed[asset->fracture->nodePart[n]]){velocities[n]=V(0);continue;}V g=gravity.Sample(glm::vec3(positions[n]));
                V acceleration=g+forces[n]/mass[n];
                velocities[n]+=acceleration*h;
                double air=1-std::exp(-settings.material.airDrag*h);
                velocities[n]+=air*(settings.material.airVelocity-velocities[n]);
                velocities[n]*=std::exp(-settings.material.damping*h);
                positions[n]+=velocities[n]*h;
                }}
        if(asset->fracture)fracture.BeginSubstep();
        std::fill(lambda.begin(),lambda.end(),0);
        std::fill(volumeLambda.begin(),volumeLambda.end(),0);
        double fraction=double(sub+1)/settings.substeps;
        {PhysicsQueryFilter filter;
            filter.includeLayers=settings.collisionMask;
            physics.QueryBodiesInAabbInto(glm::vec3(Minimum()-V(settings.material.thickness+asset->cellSize)),glm::vec3(Maximum()+V(settings.material.thickness+asset->cellSize)),rigidCandidates,filter);
            }
        for(unsigned iteration=0;iteration<settings.iterations;++iteration){Internal(h);Cohesive(h);
            RigidContacts(h,fraction,physics,targets);
            SurfaceContacts(*this,*this,h);
            Attach(h,fraction,physics,targets);
            }
        for(size_t a=0;a<settings.attachments.size();++a){auto& state=attachmentState[a];
            state.force=attachmentImpulse[a]/h;state.moment=attachmentMoment[a]/h;
            const double force=glm::length(state.force),torque=glm::length(state.moment);
            if(!std::isfinite(force)||!std::isfinite(torque)){error="nonfinite material attachment reaction; instance stopped";return;}
            state.peakForce=std::max(state.peakForce,force);state.peakTorque=std::max(state.peakTorque,torque);
            const auto& setting=settings.attachments[a];
            if((setting.forceLimit>0&&force>setting.forceLimit)||(setting.torqueLimit>0&&torque>setting.torqueLimit))attachmentPending[a]=1;
        }
        for(size_t i=0;i<asset->solids.size();++i){if(asset->fracture&&fracture.removed[asset->fracture->nodePart[asset->solids[i].nodes.x]])continue;double J=glm::determinant(columns(positions,asset->solids[i].nodes)*glm::inverse(plasticRest[i]));if(!std::isfinite(J)||J<=0){error="deformable element inversion; outside supported deformation envelope; instance stopped";return;}}
        if(asset->fracture){const auto& c=*asset->fracture;
            for(unsigned b=0;b<c.bonds.size();++b){const auto& bond=c.bonds[b];
                if(fracture.broken[b]||fracture.removed[bond.a]||fracture.removed[bond.b])continue;
                const auto& part=c.parts[bond.a];M rotation(0);double volume=0;
                // A volume-weighted material frame avoids attributing an
                // entire bent section to one arbitrarily chosen tetrahedron.
                if(c.structural){for(auto index:part.tets){const auto& tet=asset->solids[index];rotation+=columns(positions,tet.nodes)*tet.inverseRest*tet.volume;volume+=tet.volume;}rotation/=volume;}
                else{const auto& tet=asset->solids[part.tets.front()];rotation=columns(positions,tet.nodes)*tet.inverseRest;}
                for(int k=0;k<(c.structural?8:5);++k)rotation=.5*(rotation+glm::transpose(glm::inverse(rotation)));
                bool valid=true;for(int k=0;k<3;++k)valid&=finite(rotation[k]);
                if(!valid||glm::determinant(rotation)<=0){error="invalid cohesive material frame; instance stopped";return;}
                V normal=glm::normalize(rotation*bond.normal),force(0),moment(0),centroid(0);
                if(c.structural){auto first=bond.pairs.front();V origin=(positions[first.x]+positions[first.y])*.5;centroid=origin;
                    for(unsigned pair=0;pair<bond.pairs.size();++pair){auto nodes=bond.pairs[pair];centroid+=((positions[nodes.x]+positions[nodes.y])*.5-origin)*bond.sectionWeights[pair];}}
                for(unsigned pair=0;pair<bond.pairs.size();++pair){V demand=-fracture.multipliers[b*16+pair]/(h*h);force+=demand;
                    if(c.structural){auto nodes=bond.pairs[pair];moment+=glm::cross((positions[nodes.x]+positions[nodes.y])*.5-centroid,demand);}
                    else fracture.Observe(c,b,demand*double(bond.pairs.size()),normal);
                }
                if(c.structural){M inverse=glm::transpose(rotation);fracture.ObserveSection(c,b,inverse*force,inverse*moment);}
                else fracture.Observe(c,b,force,normal);
            }
        }
        Plastic(h);
        for(size_t n=0;n<positions.size();++n){if(!finite(positions[n])){error="nonfinite deformable solve; instance stopped";
                return;
                }velocities[n]=(positions[n]-start[n])/h;
            }
        if(stats.capacityExceeded){error="deformable surface candidate capacity exceeded; instance stopped";
            return;
            }
    }
    // Failure is an irreversible change of connection ownership at the fixed
    // step boundary. Both material and body retain their already solved real
    // velocities; release adds no impulse, transform correction or reset.
    for(size_t a=0;a<released.size();++a)if(attachmentPending[a])released[a]=1;
    std::fill(forces.begin(),forces.end(),V(0));
    double speed=0;
    for(auto v:velocities)speed=std::max(speed,glm::length(v));
    if(speed<.015&&!targetMoving&&settings.material.airDrag==0)quietSeconds+=dt;
    else quietSeconds=0;
    if(quietSeconds>1)sleeping=true;
    JUDAS_PROFILE_COUNTER("Deformable nodes",double(stats.nodes),ProfileCounterMode::Sum);
    JUDAS_PROFILE_COUNTER("Deformable contacts",double(stats.contacts),ProfileCounterMode::Sum);
}

void DeformableInstance::StepStructuralInterval(double h,PhysicsWorld& physics,const GravityField& gravity,const std::vector<DeformableTarget>& targets,bool beginMacro,bool endMacro){
    if(!BeginStructuralInterval(h,physics,gravity,targets,beginMacro)){if(endMacro)std::fill(forces.begin(),forces.end(),V(0));return;}
    JUDAS_PROFILE_SCOPE("Structural network interval");
    for(unsigned iteration=0;iteration<settings.iterations;++iteration){SolveStructuralContacts(h,physics,targets);SolveStructuralIteration(h,physics,targets);}
    EndStructuralInterval(h,physics,endMacro);
}
PreciseBodyPrediction DeformableInstance::StructuralPrediction(PhysicsWorld& physics,BodyHandle handle,double h,V extraImpulse,V extraMoment)const{
    for(const auto& owned:structuralOwnedBodies)if(owned.handle.id==handle.id&&owned.handle.world==handle.world){extraImpulse+=owned.idealImpulse-owned.impulse;extraMoment+=owned.idealMoment-owned.moment;break;}
    return physics.PredictSmoothTransformAfterImpulse(handle,h,extraImpulse,extraMoment);
}
bool DeformableInstance::StructuralPrimalBlock(double h,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets,bool& applicable){
    JUDAS_PROFILE_SCOPE("Structural physical root block");
    applicable=false;structuralRootCertified=false;structuralRootRequired=false;structuralRootDimension=0;
    if(std::count_if(structuralContactRows.begin(),structuralContactRows.end(),[](const auto& row){return row.seen;})>2048){error="structural contact operator exceeds its explicit 2048-row envelope";return false;}
    struct Body{BodyHandle handle;PreciseBodyPrediction pose;M inertia,lower,weight;double mass;unsigned base=0,owned=0;M angularMap{0};};
    struct Pin{int body=-1;V point{0},arm{0},rotArm{0};std::vector<std::pair<unsigned,unsigned>> owners;};
    struct Gradient{std::array<std::pair<unsigned,double>,36> values{};unsigned count=0;
        auto begin()const{return values.begin();}auto end()const{return values.begin()+count;}
        void Put(unsigned dof,double value){if(value==0)return;for(unsigned i=0;i<count;++i)if(values[i].first==dof){values[i].second+=value;return;}
            if(count==values.size())throw std::runtime_error("structural gradient exceeds its proven contact/node bound");
            values[count++]={dof,value};}};
    struct Beam{unsigned index,a,b;V n;double length,force,tangent;M hessian;};
    std::vector<Body> bodies;std::vector<Pin> pins(positions.size());std::vector<V> centres(settings.attachments.size(),V(0));
    const auto bodyIndex=[&](BodyHandle handle){for(unsigned i=0;i<bodies.size();++i)if(bodies[i].handle.id==handle.id&&bodies[i].handle.world==handle.world)return i;
        const M inertia=StructuralInertiaMetric(physics,handle);const double bodyMass=physics.GetMass(handle);
        if(!(bodyMass>0)||!(glm::determinant(inertia)>0))return ~0u;
        unsigned owned=0;for(;owned<structuralOwnedBodies.size();++owned)if(structuralOwnedBodies[owned].handle.id==handle.id&&structuralOwnedBodies[owned].handle.world==handle.world)break;
        if(owned==structuralOwnedBodies.size())structuralOwnedBodies.push_back({handle,V(0),V(0)});
        M lower(0);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double value=inertia[j][i];for(unsigned k=0;k<j;++k)value-=lower[k][i]*lower[k][j];if(i==j){if(!(value>0))return ~0u;lower[j][i]=std::sqrt(value);}else lower[j][i]=value/lower[j][j];}
        const auto pose=StructuralPrediction(physics,handle,h);
        bodies.push_back({handle,pose,inertia,lower,glm::inverse(lower),bodyMass,0,owned,M(0)});return unsigned(bodies.size()-1);};
    for(unsigned a=0;a<settings.attachments.size();++a){const auto& attachment=settings.attachments[a];if(released[a]||!attachment.enabled||a>=targets.size()||!targets[a].valid)continue;
        const auto& t=targets[a];const auto& group=asset->groups.at(attachment.group);
        if(!physics.IsDynamicBody(t.body)){for(auto n:group)positions[n]=target(t.current,asset->nodes[n]+attachment.offset);continue;}
        const unsigned body=bodyIndex(t.body);if(body==~0u)return true;const auto& pose=bodies[body].pose;const double norm=glm::dot(pose.rotation,pose.rotation);
        for(unsigned p=0;p<group.size();++p){const unsigned n=group[p];if(inverseMass[n]<=0)return true;const V point=pose.position+pose.rotation*(asset->nodes[n]+attachment.offset);auto& pin=pins[n];
            if(pin.body>=0&&(unsigned(pin.body)!=body||glm::length(pin.point-point)>1e-9))return true;
            pin.body=int(body);pin.point=point;pin.arm=point-pose.centerOfMass;pin.rotArm=pin.arm-(1-norm)*(glm::inverse(glm::mat3_cast(pose.rotation))*pin.arm);pin.owners.push_back({a,p});centres[a]+=point;
        }centres[a]/=double(group.size());}
    for(const auto& row:structuralContactRows)if(row.seen&&!row.self&&physics.IsDynamicBody(row.body))if(bodyIndex(row.body)==~0u){error="structural contact requires finite nonsingular collider inertia";return false;}
    std::vector<int> nodeBase(positions.size(),-1);unsigned dimension=0;
    for(unsigned n=0;n<positions.size();++n)if(inverseMass[n]>0&&pins[n].body<0){nodeBase[n]=int(dimension);dimension+=3;}
    for(auto& body:bodies){body.base=dimension;dimension+=6;}if(dimension>512)return true;applicable=true;structuralRootRequired=true;
    for(unsigned n=0;n<pins.size();++n)if(pins[n].body>=0)positions[n]=pins[n].point;
    // A certified root needs no angular differential. Prepare this pure
    // native-motion derivative once, only if a numerical proposal needs it.
    bool angularReady=false;
    const auto prepareAngular=[&](){if(angularReady)return;for(auto& body:bodies){const auto& owned=structuralOwnedBodies[body.owned];
        body.angularMap=physics.PredictedSmoothAngularImpulseJacobian(body.handle,h,owned.idealImpulse-owned.impulse,owned.idealMoment-owned.moment)*body.inertia/h;
    }angularReady=true;};
    const auto& cook=*asset->structure;std::vector<Beam> beams;beams.reserve(cook.beams.size());
    std::vector<double> matrix;
    const auto append=[&](Gradient& gradient,unsigned n,V value){if(nodeBase[n]>=0){for(unsigned k=0;k<3;++k)gradient.Put(unsigned(nodeBase[n])+k,value[k]);}
        else if(pins[n].body>=0){const auto& body=bodies[unsigned(pins[n].body)];const V angular=glm::cross(pins[n].arm,value);for(unsigned k=0;k<3;++k){gradient.Put(body.base+k,value[k]);gradient.Put(body.base+3+k,angular[k]);}}};
    for(unsigned i=0;i<cook.beams.size();++i){if(structure.broken[i])continue;const auto& b=cook.beams[i];const V separation=positions[b.b]-positions[b.a];const double length=glm::length(separation);double force,tangent,rest,plastic;
        if(!structure.EvaluateForce(cook,i,length,h,force,tangent,rest,plastic)){error="invalid structural constitutive state";return false;}const V normal=separation/length;const M nn=glm::outerProduct(normal,normal);
        beams.push_back({i,b.a,b.b,normal,length,force,tangent,tangent*nn+(force/length)*(M(1)-nn)});
    }
    const auto preparePositiveMatrix=[&](){
        matrix.assign(size_t(dimension)*dimension,0);
        const auto add=[&](unsigned i,unsigned j,double value){matrix[size_t(i)*dimension+j]+=value;};
    for(unsigned n=0;n<positions.size();++n){if(nodeBase[n]>=0){for(unsigned k=0;k<3;++k)add(unsigned(nodeBase[n])+k,unsigned(nodeBase[n])+k,mass[n]);}
        else if(pins[n].body>=0){const auto& body=bodies[unsigned(pins[n].body)];std::array<V,6> basis;for(unsigned k=0;k<3;++k){basis[k]=V(0);basis[k][k]=1;basis[k+3]=glm::cross(basis[k],pins[n].arm);}
            for(unsigned i=0;i<6;++i)for(unsigned j=0;j<6;++j)add(body.base+i,body.base+j,mass[n]*glm::dot(basis[i],basis[j]));}}
    for(const auto& body:bodies){for(unsigned i=0;i<3;++i)add(body.base+i,body.base+i,body.mass);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)add(body.base+3+i,body.base+3+j,body.inertia[j][i]);}
        for(const auto& beam:beams){Gradient gradient;append(gradient,beam.a,-beam.n);append(gradient,beam.b,beam.n);
            for(const auto& a:gradient)for(const auto& q:gradient)add(a.first,q.first,h*h*beam.tangent*a.second*q.second);}
    };
    const auto physicalNorm=[&](const std::vector<double>& value){if(value.size()!=dimension)return std::numeric_limits<double>::infinity();double sum=0;
        for(unsigned n=0;n<nodeBase.size();++n)if(nodeBase[n]>=0){const unsigned base=unsigned(nodeBase[n]);const V r(value[base],value[base+1],value[base+2]);sum+=glm::dot(r,r)/mass[n];}
        for(const auto& body:bodies){const unsigned b=body.base;const V p(value[b],value[b+1],value[b+2]),l(value[b+3],value[b+4],value[b+5]);sum+=glm::dot(p,p)/body.mass+glm::dot(body.weight*l,body.weight*l);}return std::isfinite(sum)&&sum>=0?std::sqrt(sum):std::numeric_limits<double>::infinity();};
    // A converged physical root needs no linear solve. Build the positive
    // numerical operator only when a contact scaling or Newton direction
    // actually needs it; the force/moment/contact certificate is unchanged.
    std::unique_ptr<StructuralPrimalSolver> linear;
    const auto positiveSolver=[&]() -> StructuralPrimalSolver& {
        if(!linear){preparePositiveMatrix();linear=std::make_unique<StructuralPrimalSolver>(matrix,structuralPrimalFactor,&structuralFactorTraversal,physicalNorm);}
        return *linear;
    };
    const auto dot=[](const Gradient& g,const std::vector<double>& value){double result=0;for(const auto& item:g)result+=item.second*value[item.first];return result;};
    struct Contact{size_t index;int collider=-1;V n,t0,t1,localT0,localT1,point,oldPoint,materialStart;Gradient gn,g0,g1;double mobility=0,tangentMobility=0;std::array<double,3> initial{};bool staticGeometry=false,pathGeometry=false;PrimitivePose geometry;};
    std::vector<Contact> contacts;
    for(size_t index=0;index<structuralContactRows.size();++index){const auto& row=structuralContactRows[index];if(!row.seen)continue;Contact c;c.index=index;c.n=row.normal;
        if(row.self){c.point=V(0);for(unsigned k=0;k<3;++k)c.point+=row.otherWeights[k]*positions[row.otherNodes[k]];}
        else{const auto pose=StructuralPrediction(physics,row.body,h);const auto rotation=glm::normalize(pose.rotation);c.point=pose.centerOfMass+rotation*row.localPoint;c.n=glm::normalize(rotation*row.localNormal);
            const auto oldPose=physics.GetTransform(row.body);c.oldPoint=V(physics.GetCenterOfMass(row.body))+glm::normalize(glm::dquat(oldPose.rotation))*row.localPoint;
            for(unsigned i=0;i<bodies.size();++i)if(bodies[i].handle.id==row.body.id&&bodies[i].handle.world==row.body.world){c.collider=int(i);break;}}
        if(!row.self&&physics.GetMotionType(row.body)==BodyMotionType::Static){Shape shape;BodyTransform pose;
            if(physics.GetBodyShape(row.body,shape,pose)&&row.primitive<unsigned(PrimitiveCount(shape))){RigidBody parent;parent.position=pose.position;parent.orientation=pose.rotation;c.geometry=PrimitiveAt(shape,parent,int(row.primitive));
                const auto type=c.geometry.shape.type;const bool analytic=!c.geometry.shape.asset&&(type==ShapeType::Box||type==ShapeType::Sphere||type==ShapeType::Capsule);
                if(analytic){V sample(0);c.materialStart=V(0);for(unsigned k=0;k<3;++k){sample+=row.weights[k]*positions[row.nodes[k]];c.materialStart+=row.weights[k]*start[row.nodes[k]];}
                    const auto initialSurface=EvaluateStructuralContactGeometry(c.materialStart,c.geometry);
                    const auto surface=EvaluateStructuralContactPathGeometry(c.materialStart,sample,c.geometry);
                    // Choose one mathematical contact function for this whole
                    // root block. Existing contact-skin overlap must use the
                    // exact convex START support plane: a path minimum contains
                    // the fixed old point and therefore cannot remove even a
                    // tiny historical skin penetration by changing its endpoint.
                    // This is geometric recovery, not a relaxed gap threshold.
                    if(initialSurface.valid&&initialSurface.signedDistance<=settings.material.thickness){
                        c.staticGeometry=true;c.n=initialSurface.normal;c.point=initialSurface.point;
                    }else if(surface.valid&&surface.fraction>0){c.staticGeometry=true;c.pathGeometry=true;c.n=surface.normal;c.point=surface.point;}
                    else if(surface.valid&&surface.fraction==0&&glm::dot(surface.normal,sample-c.materialStart)>=0){
                        // At an initially separating support the convex START
                        // plane is globally valid. Its endpoint gap retires
                        // pressure instead of sticking to a constant tau=0
                        // minimum, and cannot certify a path through the body.
                        c.staticGeometry=true;c.n=surface.normal;c.point=surface.point;
                    }
                    // An initially solid-crossing/singular path from a clear
                    // start keeps its acquired CCD recovery plane. Exterior
                    // corner paths use one actual finite minimum, not several
                    // independently frozen nearly dependent TOI planes.
                }
            }}
        V reference(0);reference[std::abs(c.n.x)<=std::abs(c.n.y)&&std::abs(c.n.x)<=std::abs(c.n.z)?0:std::abs(c.n.y)<=std::abs(c.n.z)?1:2]=1;c.t0=glm::normalize(glm::cross(c.n,reference));c.t1=glm::cross(c.n,c.t0);
        if(c.collider>=0){const auto inverse=glm::inverse(glm::normalize(bodies[unsigned(c.collider)].pose.rotation));c.localT0=inverse*c.t0;c.localT1=inverse*c.t1;}
        const auto gradient=[&](V d){Gradient g;for(unsigned k=0;k<3;++k)append(g,row.nodes[k],d*row.weights[k]);if(row.self)for(unsigned k=0;k<3;++k)append(g,row.otherNodes[k],-d*row.otherWeights[k]);
            else if(c.collider>=0){const auto& body=bodies[unsigned(c.collider)];const V arm=glm::cross(c.point-body.pose.centerOfMass,d);for(unsigned k=0;k<3;++k){g.Put(body.base+k,-d[k]);g.Put(body.base+3+k,-arm[k]);}}
            return g;};
        c.gn=gradient(c.n);c.g0=gradient(c.t0);c.g1=gradient(c.t1);
        const auto response=[&](const Gradient& g,std::vector<double>& value){std::vector<double> load(dimension,0);for(const auto& item:g)load[item.first]+=item.second;unsigned iterations=0;double residual=0;
            if(!positiveSolver().Solve(load,value,iterations,residual))return false;
            structure.linearIterations=std::max(structure.linearIterations,iterations);structure.linearResidual=std::max(structure.linearResidual,residual);return true;};
        std::vector<double> rn,r0,r1;if(!response(c.gn,rn)||!response(c.g0,r0)||!response(c.g1,r1)){error="structural contact scaling failed its physical residual contract";return false;}
        c.mobility=dot(c.gn,rn);const double a=dot(c.g0,r0),b=.5*(dot(c.g0,r1)+dot(c.g1,r0)),d=dot(c.g1,r1);c.tangentMobility=.5*(a+d+std::hypot(a-d,2*b));
        if(!(c.mobility>0)||!(c.tangentMobility>0)||!std::isfinite(c.mobility+c.tangentMobility)){error="invalid structural contact mobility";return false;}
        c.initial={c.staticGeometry?row.normalLambda:glm::dot(row.normalNet,c.n),glm::dot(row.tangentLambda,c.t0),glm::dot(row.tangentLambda,c.t1)};contacts.push_back(c);}
    const unsigned total=dimension+unsigned(contacts.size())*3;structuralRootDimension=total;
    struct TrialContact{V n,t0,t1,point,relative,force,gapGradient;M normalDerivative{0};bool pathGeometry=false;StructuralContactLawInput law;StructuralContactLawResult result;};
    struct Trial{std::vector<V> x,nodeResidual,bodyP,bodyL;std::vector<PreciseBodyPrediction> pose;std::vector<TrialContact> contact;std::vector<double> residual;double merit=0,equilibrium=0,nodeVelocity=0,bodyVelocity=0,bodyAngular=0,gap=0,complementarity=0,friction=0;bool valid=true;};
    const auto evaluate=[&](const std::vector<double>& q){Trial trial;trial.x=positions;trial.pose.reserve(bodies.size());trial.contact.reserve(contacts.size());trial.residual.assign(total,0);
        for(unsigned n=0;n<positions.size();++n)if(nodeBase[n]>=0){const unsigned b=unsigned(nodeBase[n]);trial.x[n]+=V(q[b],q[b+1],q[b+2]);}
        for(const auto& body:bodies){const unsigned b=body.base;const V p=body.mass*V(q[b],q[b+1],q[b+2])/h,l=body.inertia*V(q[b+3],q[b+4],q[b+5])/h;
            // The zero trial is exactly the pure prediction already captured above.
            trial.pose.push_back(p==V(0)&&l==V(0)?body.pose:StructuralPrediction(physics,body.handle,h,p,l));}
        for(unsigned n=0;n<pins.size();++n)if(pins[n].body>=0){const auto& pose=trial.pose[unsigned(pins[n].body)];const auto& attachment=settings.attachments[pins[n].owners.front().first];trial.x[n]=pose.position+pose.rotation*(asset->nodes[n]+attachment.offset);}
        std::vector<V> load(positions.size(),V(0));
        for(const auto& beam:beams){const V delta=trial.x[beam.b]-trial.x[beam.a];const double length=glm::length(delta);double force,tangent,rest,plastic;
            if(!structure.EvaluateForce(cook,beam.index,length,h,force,tangent,rest,plastic)){trial.valid=false;trial.merit=std::numeric_limits<double>::infinity();return trial;}const V f=delta*(-h*h*force/length);load[beam.a]-=f;load[beam.b]+=f;}
        trial.bodyP.assign(bodies.size(),V(0));trial.bodyL.assign(bodies.size(),V(0));
        for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const auto& owned=structuralOwnedBodies[body.owned];const unsigned j=body.base;
            trial.bodyP[b]=h*owned.idealImpulse+body.mass*V(q[j],q[j+1],q[j+2]);trial.bodyL[b]=h*owned.idealMoment+body.inertia*V(q[j+3],q[j+4],q[j+5]);}
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& row=structuralContactRows[c.index];TrialContact t;t.n=c.n;t.t0=c.t0;t.t1=c.t1;t.point=c.point;t.relative=V(0);V sample(0);
            if(c.collider>=0){const auto& pose=trial.pose[unsigned(c.collider)];const auto rotation=glm::normalize(pose.rotation);t.n=glm::normalize(rotation*row.localNormal);t.t0=rotation*c.localT0;t.t1=rotation*c.localT1;t.point=pose.centerOfMass+rotation*row.localPoint;}
            if(row.self){t.point=V(0);for(unsigned k=0;k<3;++k){t.point+=row.otherWeights[k]*trial.x[row.otherNodes[k]];t.relative-=row.otherWeights[k]*(trial.x[row.otherNodes[k]]-start[row.otherNodes[k]]);}}
            for(unsigned k=0;k<3;++k){sample+=row.weights[k]*trial.x[row.nodes[k]];t.relative+=row.weights[k]*(trial.x[row.nodes[k]]-start[row.nodes[k]]);}
            double gap=glm::dot(t.n,sample-t.point)-(row.self?2:1)*settings.material.thickness;
            if(c.pathGeometry){const auto surface=EvaluateStructuralContactPathGeometry(c.materialStart,sample,c.geometry);
                // Actual finite-path separation preserves acquired CCD even
                // when a clear endpoint has rounded around the same corner.
                // A new solid crossing is outside this exterior root chart;
                // reject it rather than changing the residual to another face.
                // A tau=0 minimum is usable only with a strictly clear start:
                // complementarity then requires its old pressure to retire.
                if(!surface.valid||(surface.fraction==0&&!(surface.signedDistance>settings.material.thickness))){trial.valid=false;trial.merit=std::numeric_limits<double>::infinity();return trial;}
                t.pathGeometry=true;t.n=surface.normal;t.point=surface.point;t.normalDerivative=surface.dNormal;t.gapGradient=surface.gradient;gap=surface.signedDistance-settings.material.thickness;
                const double denominator=1+glm::dot(c.n,t.n);if(!(denominator>0)){trial.valid=false;trial.merit=std::numeric_limits<double>::infinity();return trial;}
                t.t0=c.t0-(glm::dot(c.t0,t.n)/denominator)*(t.n+c.n);t.t1=glm::cross(t.n,t.t0);
            }
            // A closest-point witness sliding over a static shape is not a
            // moving support. Its material velocity remains exactly zero.
            if(!row.self&&!c.staticGeometry)t.relative-=t.point-c.oldPoint;
            const unsigned j=dimension+3*i;const double rootN=std::sqrt(c.mobility),rootT=std::sqrt(c.tangentMobility);
            t.law.impulse={c.initial[0]+q[j]/rootN,c.initial[1]+q[j+1]/rootT,c.initial[2]+q[j+2]/rootT};t.law.kinematics={gap,glm::dot(t.t0,t.relative),glm::dot(t.t1,t.relative)};
            t.law.normalMobility=c.mobility;t.law.tangentMobility=c.tangentMobility;t.law.friction=settings.material.friction;std::string failure;
            if(!EvaluateStructuralContactLaw(t.law,t.result,failure)){trial.valid=false;trial.merit=std::numeric_limits<double>::infinity();return trial;}
            t.force=t.n*t.law.impulse[0]+t.t0*t.law.impulse[1]+t.t1*t.law.impulse[2];for(unsigned k=0;k<3;++k){load[row.nodes[k]]+=row.weights[k]*t.force;if(row.self)load[row.otherNodes[k]]-=row.otherWeights[k]*t.force;}
            if(c.collider>=0){const unsigned b=unsigned(c.collider);trial.bodyP[b]+=t.force;trial.bodyL[b]+=glm::cross(t.point-trial.pose[b].centerOfMass,t.force);}
            trial.gap=std::max(trial.gap,std::max(0.,-t.law.kinematics[0]));trial.complementarity=std::max(trial.complementarity,std::abs(t.law.impulse[0]*t.law.kinematics[0]));trial.friction=std::max(trial.friction,std::hypot(t.result.residual[1],t.result.residual[2])/rootT);
            for(unsigned k=0;k<3;++k)trial.residual[j+k]=t.result.residual[k];
            trial.contact.push_back(t);}
        trial.nodeResidual.resize(positions.size());
        for(unsigned n=0;n<positions.size();++n){const V r=mass[n]*(trial.x[n]-structuralFreePositions[n])-load[n];trial.nodeResidual[n]=r;
            if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);trial.bodyP[b]+=r;trial.bodyL[b]+=glm::cross(trial.x[n]-trial.pose[b].centerOfMass,r);}
            else if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);const V scaled=r/std::sqrt(mass[n]);for(unsigned k=0;k<3;++k)trial.residual[j+k]=scaled[k];trial.nodeVelocity=std::max(trial.nodeVelocity,glm::length(r)/(mass[n]*h));}}
        double norm=0;for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const unsigned j=body.base;const V p=trial.bodyP[b]/std::sqrt(body.mass),l=body.weight*trial.bodyL[b];
            for(unsigned k=0;k<3;++k){trial.residual[j+k]=p[k];trial.residual[j+3+k]=l[k];}trial.bodyVelocity=std::max(trial.bodyVelocity,glm::length(trial.bodyP[b])/(body.mass*h));trial.bodyAngular=std::max(trial.bodyAngular,glm::length(glm::inverse(body.inertia)*trial.bodyL[b])/h);}
        for(unsigned i=0;i<dimension;++i)norm+=trial.residual[i]*trial.residual[i];
        trial.equilibrium=std::sqrt(norm);for(unsigned i=dimension;i<total;++i)norm+=trial.residual[i]*trial.residual[i];trial.merit=.5*norm;trial.valid=std::isfinite(trial.merit);return trial;};
    const std::vector<double> zero(total,0);const Trial initial=evaluate(zero);if(!initial.valid){error="invalid structural physical root";return false;}
    // Analytic derivative of the actual physical residual. Native angular
    // prediction is on the RIGHT; the LEFT reaction remains ordinary r x f.
    std::vector<V> modelNodalIntercept(positions.size(),V(0));
    const auto differential=[&](const std::vector<double>& q,std::vector<double>& out,bool directional){if(q.size()!=total)return false;prepareAngular();std::vector<V> dx(positions.size(),V(0)),dcom(bodies.size()),dtheta(bodies.size()),dload(positions.size(),V(0)),dp(bodies.size()),dl(bodies.size());
        for(unsigned n=0;n<positions.size();++n)if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);dx[n]=V(q[j],q[j+1],q[j+2]);}
        for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const unsigned j=body.base;const V qt(q[j],q[j+1],q[j+2]),qa(q[j+3],q[j+4],q[j+5]);dcom[b]=body.pose.inverseMass*body.mass*qt;dtheta[b]=body.angularMap*qa;dp[b]=body.mass*qt;dl[b]=body.inertia*qa;}
        for(unsigned n=0;n<pins.size();++n)if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);dx[n]=dcom[b]+glm::cross(dtheta[b],pins[n].rotArm);}
        for(const auto& beam:beams){const V displacement=dx[beam.b]-dx[beam.a];V forceDirection;
            if(directional){const double dl=glm::dot(beam.n,displacement);double df;if(!structure.EvaluateForceDirectional(cook,beam.index,beam.length,h,dl,df))return false;
                forceDirection=beam.n*df+(beam.force/beam.length)*(displacement-beam.n*dl);}
            else forceDirection=beam.hessian*displacement;
            const V f=-h*h*forceDirection;dload[beam.a]-=f;dload[beam.b]+=f;}
        out.assign(total,0);
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& row=structuralContactRows[c.index];const auto& t=initial.contact[i];const unsigned j=dimension+3*i;const double rootN=std::sqrt(c.mobility),rootT=std::sqrt(c.tangentMobility);
            const std::array<double,3> dImpulse={q[j]/rootN,q[j+1]/rootT,q[j+2]/rootT};V dn(0),dt0(0),dt1(0),dpoint(0),dsample(0),drelative(0),sample(0);
            if(c.collider>=0){const unsigned b=unsigned(c.collider);dn=glm::cross(dtheta[b],t.n);dt0=glm::cross(dtheta[b],t.t0);dt1=glm::cross(dtheta[b],t.t1);dpoint=dcom[b]+glm::cross(dtheta[b],t.point-bodies[b].pose.centerOfMass);}
            if(row.self)for(unsigned k=0;k<3;++k)dpoint+=row.otherWeights[k]*dx[row.otherNodes[k]];
            for(unsigned k=0;k<3;++k){dsample+=row.weights[k]*dx[row.nodes[k]];sample+=row.weights[k]*initial.x[row.nodes[k]];}drelative=dsample-dpoint;
            if(c.staticGeometry)drelative=dsample;
            if(t.pathGeometry){dn=t.normalDerivative*dsample;const double denominator=1+glm::dot(c.n,t.n),a=glm::dot(c.t0,t.n),da=glm::dot(c.t0,dn),db=glm::dot(c.n,dn);
                const double change=(da*denominator-a*db)/(denominator*denominator);dt0=-change*(t.n+c.n)-(a/denominator)*dn;dt1=glm::cross(dn,t.t0)+glm::cross(t.n,dt0);}
            const V f=t.n*dImpulse[0]+t.t0*dImpulse[1]+t.t1*dImpulse[2]+dn*t.law.impulse[0]+dt0*t.law.impulse[1]+dt1*t.law.impulse[2];
            for(unsigned k=0;k<3;++k){dload[row.nodes[k]]+=row.weights[k]*f;if(row.self)dload[row.otherNodes[k]]-=row.otherWeights[k]*f;}
            if(c.collider>=0){const unsigned b=unsigned(c.collider);dp[b]+=f;dl[b]+=glm::cross(dpoint-dcom[b],t.force)+glm::cross(t.point-bodies[b].pose.centerOfMass,f);}
            const std::array<double,3> dk={t.pathGeometry?glm::dot(t.gapGradient,dsample):glm::dot(t.n,dsample-dpoint)+glm::dot(dn,sample-t.point),glm::dot(t.t0,drelative)+glm::dot(dt0,t.relative),glm::dot(t.t1,drelative)+glm::dot(dt1,t.relative)};
            if(directional){std::array<double,3> result;std::string failure;if(!StructuralContactLawDirectionalDerivative(t.law,dImpulse,dk,result,failure))return false;for(unsigned k=0;k<3;++k)out[j+k]=result[k];}
            else for(unsigned k=0;k<3;++k)for(unsigned axis=0;axis<3;++axis)out[j+k]+=t.result.impulseDerivative[3*k+axis]*dImpulse[axis]+t.result.kinematicDerivative[3*k+axis]*dk[axis];}
        for(unsigned n=0;n<positions.size();++n){const V r=mass[n]*dx[n]-dload[n];if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);dp[b]+=r;dl[b]+=glm::cross(dx[n]-dcom[b],initial.nodeResidual[n])+glm::cross(pins[n].arm,r);}
            else if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);const V scaled=r/std::sqrt(mass[n]);for(unsigned k=0;k<3;++k)out[j+k]=scaled[k];}}
        for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const unsigned j=body.base;const V p=dp[b]/std::sqrt(body.mass),l=body.weight*dl[b];for(unsigned k=0;k<3;++k){out[j+k]=p[k];out[j+3+k]=l[k];}}
        for(double value:out)if(!std::isfinite(value))return false;
        return true;};
    const auto action=[&](const std::vector<double>& q,std::vector<double>& out){return differential(q,out,false);};
    const auto precondition=[&](const std::vector<double>& input,std::vector<double>& output){std::vector<double> physical(dimension,0),q;
        for(unsigned n=0;n<positions.size();++n)if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);for(unsigned k=0;k<3;++k)physical[j+k]=input[j+k]*std::sqrt(mass[n]);}
        for(const auto& body:bodies){const unsigned j=body.base;const V l=body.lower*V(input[j+3],input[j+4],input[j+5]);for(unsigned k=0;k<3;++k){physical[j+k]=input[j+k]*std::sqrt(body.mass);physical[j+3+k]=l[k];}}
        unsigned iterations=0;double residual=0;if(!positiveSolver().Solve(physical,q,iterations,residual))return false;structure.linearIterations=std::max(structure.linearIterations,iterations);structure.linearResidual=std::max(structure.linearResidual,residual);
        output=input;for(unsigned i=0;i<dimension;++i)output[i]=q[i];return true;};
    const auto diagnose=[&](const char* reason,const std::vector<double>& proposal){const char* base=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE");static unsigned recorded=0,terminalRecorded=0;
        if(!base||!*base)return;
        const bool stalled=std::string(reason)=="bounded-stalled-proposal";
        if(stalled&&(!structuralTraceActive||recorded>=8))return;
        if(!stalled&&terminalRecorded>=4)return;
        const std::string path=std::string(base)+(stalled?".root-boundary-":".root-terminal-")+std::to_string(stalled?recorded++:terminalRecorded++)+".txt";FILE* out=std::fopen(path.c_str(),"w");if(!out)return;
        std::fprintf(out,"StructuralPhysicalRootBoundary 1\ngeneration %llu interval %u round %u h %.17g dimension %u contacts %zu reason %s\n",(unsigned long long)generation,structuralTraceInterval,structuralTraceRound,h,dimension,contacts.size(),reason);
        std::fputs("# analytic = selected material/geometry branch Jacobian; directional = selected geometric B derivative with actual material/contact directional law\n",out);
        std::fprintf(out,"initial merit %.17g equilibrium %.17g freeVelocity %.17g bodyVelocity %.17g angularVelocity %.17g gap %.17g complementarity %.17g friction %.17g\n",initial.merit,initial.equilibrium,initial.nodeVelocity,initial.bodyVelocity,initial.bodyAngular,initial.gap,initial.complementarity,initial.friction);
        for(unsigned n=0;n<positions.size();++n)std::fprintf(out,"node %u pin %d mass %.17g x %.17g %.17g %.17g free %.17g %.17g %.17g start %.17g %.17g %.17g residual %.17g %.17g %.17g\n",n,pins[n].body,mass[n],positions[n].x,positions[n].y,positions[n].z,structuralFreePositions[n].x,structuralFreePositions[n].y,structuralFreePositions[n].z,start[n].x,start[n].y,start[n].z,initial.nodeResidual[n].x,initial.nodeResidual[n].y,initial.nodeResidual[n].z);
        for(const auto& beam:beams){const auto& b=cook.beams[beam.index];const auto& material=cook.regions[b.region];double f,t,rest,plastic;structure.EvaluateForce(cook,beam.index,beam.length,h,f,t,rest,plastic);
            std::fprintf(out,"beam %u nodes %u %u length %.17g force %.17g tangent %.17g transverse %.17g rest %.17g plastic %.17g shorteningLimit %.17g extensionLimit %.17g\n",beam.index,beam.a,beam.b,beam.length,beam.force,beam.tangent,beam.force/beam.length,rest,plastic,b.restLength*(1-material.maxShortening),b.restLength*(1+material.maxExtension));}
        for(const auto& beam:beams)std::fprintf(out,"modelBranch %u axialTangent %.17g baseTangent %.17g\n",beam.index,glm::dot(beam.n,beam.hessian*beam.n),beam.tangent);
        for(const auto& beam:beams){const auto events=structure.ForceEvents(cook,beam.index);
            std::fprintf(out,"materialEvents %u events %.17g %.17g %.17g %.17g\n",beam.index,events[0],events[1],events[2],events[3]);}
        for(unsigned n=0;n<modelNodalIntercept.size();++n)std::fprintf(out,"modelIntercept %u %.17g %.17g %.17g\n",n,modelNodalIntercept[n].x,modelNodalIntercept[n].y,modelNodalIntercept[n].z);
        for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const auto& owned=structuralOwnedBodies[body.owned];std::fprintf(out,"body %u handle %llu %u mass %.17g com %.17g %.17g %.17g quaternion %.17g %.17g %.17g %.17g idealP %.17g %.17g %.17g actualP %.17g %.17g %.17g idealL %.17g %.17g %.17g actualL %.17g %.17g %.17g\n",b,(unsigned long long)body.handle.world,body.handle.id,body.mass,body.pose.centerOfMass.x,body.pose.centerOfMass.y,body.pose.centerOfMass.z,body.pose.rotation.w,body.pose.rotation.x,body.pose.rotation.y,body.pose.rotation.z,owned.idealImpulse.x,owned.idealImpulse.y,owned.idealImpulse.z,owned.impulse.x,owned.impulse.y,owned.impulse.z,owned.idealMoment.x,owned.idealMoment.y,owned.idealMoment.z,owned.moment.x,owned.moment.y,owned.moment.z);}
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& t=initial.contact[i];std::fprintf(out,"contact %u row %zu collider %d mobility %.17g %.17g impulse %.17g %.17g %.17g kinematics %.17g %.17g %.17g residual %.17g %.17g %.17g\n",i,c.index,c.collider,c.mobility,c.tangentMobility,t.law.impulse[0],t.law.impulse[1],t.law.impulse[2],t.law.kinematics[0],t.law.kinematics[1],t.law.kinematics[2],t.result.residual[0],t.result.residual[1],t.result.residual[2]);}
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& row=structuralContactRows[c.index];
            std::fprintf(out,"contactDefinition %u self %u staticGeometry %u pathGeometry %u nodes %u %u %u weights %.17g %.17g %.17g otherNodes %u %u %u otherWeights %.17g %.17g %.17g normal %.17g %.17g %.17g\n",i,unsigned(row.self),unsigned(c.staticGeometry),unsigned(c.pathGeometry),row.nodes[0],row.nodes[1],row.nodes[2],row.weights[0],row.weights[1],row.weights[2],row.otherNodes[0],row.otherNodes[1],row.otherNodes[2],row.otherWeights[0],row.otherWeights[1],row.otherWeights[2],c.n.x,c.n.y,c.n.z);
        }
        // These small failure witnesses already evaluate every unit direction.
        // Retain those SAME operator values and the actual Newton RHS so an
        // independent rank/consistency calculation can reproduce the algebra.
        // Larger systems keep their existing bounded directional diagnostics.
        if(total<=96){std::fprintf(out,"analytic_jacobian_dimension %u\nright_hand_side",total);for(double value:initial.residual)std::fprintf(out," %.17g",-value);std::fputc('\n',out);}
        std::vector<double> a,b;action(proposal,a);differential(proposal,b,true);double scale=0;for(double value:proposal)scale=std::max(scale,std::abs(value));if(scale==0)scale=1;
        for(unsigned i=0;i<total;++i)std::fprintf(out,"coordinate %u proposed %.17g residual %.17g analytic %.17g directional %.17g\n",i,proposal[i],initial.residual[i],i<a.size()?a[i]:0,i<b.size()?b[i]:0);
        const auto probe=[&](const std::vector<double>& vector,const char* label,unsigned column=~0u){std::vector<double> analytic,directional;action(vector,analytic);differential(vector,directional,true);double slope=0;for(unsigned i=0;i<total;++i)slope+=initial.residual[i]*directional[i];std::fprintf(out,"probe %s slope %.17g\n",label,slope);
            if(column<total&&analytic.size()==total){std::fprintf(out,"jacobian_column %u",column);for(double value:analytic)std::fprintf(out," %.17g",value);std::fputc('\n',out);}
            for(double epsilon:{1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10,1e-11}){std::vector<double> plus=vector,minus=vector;for(double& value:plus)value*=epsilon;for(double& value:minus)value*=-epsilon;const auto p=evaluate(plus),m=evaluate(minus);if(!p.valid||!m.valid){std::fprintf(out,"probeStep %s %.17g invalid\n",label,epsilon);continue;}
                double central=0,forward=0,norm=0;for(unsigned i=0;i<total;++i){const double c=(p.residual[i]-m.residual[i])/(2*epsilon),f=(p.residual[i]-initial.residual[i])/epsilon;central+=(c-analytic[i])*(c-analytic[i]);forward+=(f-directional[i])*(f-directional[i]);norm+=analytic[i]*analytic[i];}
                std::fprintf(out,"probeStep %s %.17g meritPlus %.17g meritMinus %.17g slopeCentral %.17g slopeForward %.17g jacCentralError %.17g jacForwardError %.17g jacNorm %.17g\n",label,epsilon,p.merit,m.merit,(p.merit-m.merit)/(2*epsilon),(p.merit-initial.merit)/epsilon,std::sqrt(central),std::sqrt(forward),std::sqrt(norm));
                // Failure-only bounded attribution distinguishes material,
                // body and contact rows instead of guessing from one norm.
                if(column==~0u&&epsilon==1e-7)for(unsigned i=0;i<total;++i){const double f=(p.residual[i]-initial.residual[i])/epsilon,b=(initial.residual[i]-m.residual[i])/epsilon;
                    std::fprintf(out,"probeCoordinate %s %u forward %.17g backward %.17g directional %.17g difference %.17g\n",label,i,f,b,directional[i],f-directional[i]);}}}
        ;std::vector<double> normalized=proposal;for(double& value:normalized)value/=scale;probe(normalized,"proposalNormalized");
        if(total<=96)for(unsigned i=0;i<total;++i){std::vector<double> unit(total,0);unit[i]=1;char label[32];std::snprintf(label,sizeof(label),"unit%u",i);probe(unit,label,i);}
        std::fclose(out);
    };
    // Binary64 arithmetic error is certified from actual operation terms and
    // the worst constitutive derivative. Native FLOAT kick error is not used
    // to waive a missing root; the compensated smooth wrench removes it.
    const auto certificate=[&](const Trial& trial,double& bound){const double eps=std::numeric_limits<double>::epsilon(),gamma=64*eps/(1-64*eps);std::vector<double> nodeError(positions.size()),geometry(positions.size()),absolute(positions.size());std::vector<unsigned> terms(positions.size(),1);
        for(unsigned n=0;n<positions.size();++n){geometry[n]=gamma*(glm::length(trial.x[n])+glm::length(structuralFreePositions[n]));nodeError[n]=mass[n]*geometry[n];absolute[n]=mass[n]*glm::length(trial.x[n]-structuralFreePositions[n]);}
        for(const auto& beam:beams){const auto& b=cook.beams[beam.index];const auto& r=cook.regions[b.region];const double length=glm::length(trial.x[beam.b]-trial.x[beam.a]);const double k=r.youngModulus*b.area/b.restLength+r.damping/h;double force,tangent,rest,plastic;
            if(!structure.EvaluateForce(cook,beam.index,length,h,force,tangent,rest,plastic))return false;
            const double derivative=std::max(k,std::abs(force)/length);
            const double e=h*h*(derivative*(geometry[beam.a]+geometry[beam.b]+gamma*length)+gamma*k*(length+structure.restLengths[beam.index]+glm::length(start[beam.b]-start[beam.a])));
            nodeError[beam.a]+=e;nodeError[beam.b]+=e;absolute[beam.a]+=h*h*std::abs(force);absolute[beam.b]+=h*h*std::abs(force);++terms[beam.a];++terms[beam.b];}
        std::vector<double> ep(bodies.size()),el(bodies.size()),ap(bodies.size()),al(bodies.size());std::vector<unsigned> count(bodies.size(),1);double maxLambda=0;
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& row=structuralContactRows[c.index];const auto& t=trial.contact[i];const double force=glm::length(t.force);maxLambda=std::max(maxLambda,std::abs(t.law.impulse[0]));
            for(unsigned k=0;k<3;++k){const double w=std::abs(row.weights[k]);nodeError[row.nodes[k]]+=gamma*w*force;absolute[row.nodes[k]]+=w*force;++terms[row.nodes[k]];if(row.self){const double other=std::abs(row.otherWeights[k]);nodeError[row.otherNodes[k]]+=gamma*other*force;absolute[row.otherNodes[k]]+=other*force;++terms[row.otherNodes[k]];}}
            if(c.collider>=0){const unsigned b=unsigned(c.collider);const double arm=glm::length(t.point-trial.pose[b].centerOfMass);ep[b]+=gamma*force;el[b]+=gamma*arm*force;ap[b]+=force;al[b]+=arm*force;++count[b];}}
        for(unsigned n=0;n<positions.size();++n)nodeError[n]+=double(terms[n]+8)*eps/(1-double(terms[n]+8)*eps)*absolute[n];
        bool result=trial.valid;double squared=0;
        for(unsigned n=0;n<positions.size();++n){if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);const double arm=glm::length(trial.x[n]-trial.pose[b].centerOfMass);ep[b]+=nodeError[n];el[b]+=arm*nodeError[n]+geometry[n]*glm::length(trial.nodeResidual[n]);ap[b]+=glm::length(trial.nodeResidual[n]);al[b]+=arm*glm::length(trial.nodeResidual[n]);++count[b];}
            else if(nodeBase[n]>=0){result&=glm::length(trial.nodeResidual[n])<=nodeError[n]+1e-11*std::sqrt(mass[n]);squared+=nodeError[n]*nodeError[n]/mass[n];}}
        for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const auto& owned=structuralOwnedBodies[body.owned];const double sum=double(count[b]+8)*eps/(1-double(count[b]+8)*eps);
            ep[b]+=gamma*h*glm::length(owned.idealImpulse)+sum*(ap[b]+h*glm::length(owned.idealImpulse));el[b]+=gamma*h*glm::length(owned.idealMoment)+sum*(al[b]+h*glm::length(owned.idealMoment));
            result&=glm::length(trial.bodyP[b])<=ep[b]+1e-11*std::sqrt(body.mass)&&glm::length(body.weight*trial.bodyL[b])<=glm::length(body.weight*V(el[b]))+1e-11;squared+=ep[b]*ep[b]/body.mass+glm::dot(body.weight*V(el[b]),body.weight*V(el[b]));}
        for(unsigned i=0;i<contacts.size();++i){const auto& c=contacts[i];const auto& row=structuralContactRows[c.index];const auto& t=trial.contact[i];double pointError=gamma*(glm::length(t.point)+settings.material.thickness);
            for(unsigned k=0;k<3;++k){pointError+=std::abs(row.weights[k])*geometry[row.nodes[k]];if(row.self)pointError+=std::abs(row.otherWeights[k])*geometry[row.otherNodes[k]];}
            if(c.collider>=0)pointError+=gamma*(glm::length(trial.pose[unsigned(c.collider)].centerOfMass)+glm::length(row.localPoint));
            const double rootN=std::sqrt(c.mobility),rootT=std::sqrt(c.tangentMobility),normalError=2*pointError/rootN+gamma*(std::abs(t.law.impulse[0])*rootN+std::abs(t.law.kinematics[0])/rootN);
            const double tangentError=2*pointError/rootT+gamma*rootT*(2*std::hypot(t.law.impulse[1],t.law.impulse[2])+settings.material.friction*maxLambda);std::string certificateError;
            result&=StructuralContactLawConverged(t.law,maxLambda,normalError,tangentError,certificateError);
        }
        bound=std::sqrt(squared);result&=trial.gap<=1e-8&&trial.complementarity<=1e-8*std::max(1.,maxLambda)&&trial.friction<=1e-10+1e-8*maxLambda;return result&&std::isfinite(bound);};
    double bound=0;const bool converged=certificate(initial,bound);std::vector<double> direction(total,0);unsigned krylov=0;double linearResidual=0,alpha=0,slope=0;unsigned backtracks=0;Trial accepted=initial;
    if(!converged){
        const std::vector<Beam> originalBeams=beams;
        const auto restoreCurrent=[&](){for(unsigned i=0;i<beams.size();++i)beams[i].hessian=originalBeams[i].hessian;};
        const auto nodalDirection=[&](const std::vector<double>& q){prepareAngular();std::vector<V> dx(positions.size(),V(0)),dcom(bodies.size()),dtheta(bodies.size());
            for(unsigned n=0;n<positions.size();++n)if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);dx[n]=V(q[j],q[j+1],q[j+2]);}
            for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const unsigned j=body.base;dcom[b]=body.pose.inverseMass*body.mass*V(q[j],q[j+1],q[j+2]);dtheta[b]=body.angularMap*V(q[j+3],q[j+4],q[j+5]);}
            for(unsigned n=0;n<pins.size();++n)if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);dx[n]=dcom[b]+glm::cross(dtheta[b],pins[n].rotArm);}
            return dx;};
        const auto project=[&](const std::vector<V>& nodal,std::vector<double>& out){std::vector<V> bp(bodies.size(),V(0)),bl(bodies.size(),V(0));
            for(unsigned n=0;n<positions.size();++n){if(nodeBase[n]>=0){const unsigned j=unsigned(nodeBase[n]);const V r=nodal[n]/std::sqrt(mass[n]);for(unsigned k=0;k<3;++k)out[j+k]+=r[k];}
                else if(pins[n].body>=0){const unsigned b=unsigned(pins[n].body);bp[b]+=nodal[n];bl[b]+=glm::cross(pins[n].arm,nodal[n]);}}
            for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];const unsigned j=body.base;const V p=bp[b]/std::sqrt(body.mass),l=body.weight*bl[b];for(unsigned k=0;k<3;++k){out[j+k]+=p[k];out[j+3+k]+=l[k];}}};
        const auto norm=[](const std::vector<double>& r){long double sum=0;for(double value:r){if(!std::isfinite(value))return std::numeric_limits<double>::infinity();sum+=static_cast<long double>(value)*value;}return std::sqrt(double(sum));};
        struct Proposal{std::vector<double> direction;Trial trial;double alpha=0,slope=0;unsigned backtracks=0;bool valid=false;};
        const auto globalize=[&](const std::vector<double>& q){Proposal p;p.direction=q;restoreCurrent();std::vector<double> derivative;if(!differential(q,derivative,true))return p;
            for(unsigned i=0;i<total;++i)p.slope+=initial.residual[i]*derivative[i];
            if(!(p.slope<0))return p;
            p.alpha=1;std::vector<double> candidate(total);const double roundoff=128*std::numeric_limits<double>::epsilon()*std::max(initial.merit,std::numeric_limits<double>::min());
            for(;;){for(unsigned i=0;i<total;++i)candidate[i]=p.alpha*q[i];p.trial=evaluate(candidate);if(p.trial.valid&&p.trial.merit<=initial.merit+1e-4*p.alpha*p.slope+roundoff){p.valid=true;break;}
                if(p.backtracks++==24)break;
                p.alpha*=.5;}
            // Binary halving can approach an unloading corner forever when
            // its outgoing tangent is thousands of times the incoming one.
            // Resolve an ACTUAL geometric event on this same pure trial line;
            // no transform or material reference is snapped to the corner.
            // A corner can lie closer than the smallest tested halving. In
            // that case the incoming derivative describes no tested positive
            // step: search from the unchanged current state before declaring
            // failure, still requiring the original physical Armijo test.
            if(p.backtracks){const double lower=p.valid?p.alpha:0,upper=p.valid?std::min(1.,2*p.alpha):p.alpha;const Trial& low=p.valid?p.trial:initial;
                for(unsigned i=0;i<total;++i)candidate[i]=upper*q[i];
                const Trial high=evaluate(candidate);
                if(high.valid){double bestAlpha=std::numeric_limits<double>::infinity();Trial best;
                    for(const auto& beam:beams){const double lowLength=glm::length(low.x[beam.b]-low.x[beam.a]),highLength=glm::length(high.x[beam.b]-high.x[beam.a]);double value,tangent;unsigned lowBranch,highBranch;
                        if(!structure.EvaluateAffineForce(cook,beam.index,beam.length,lowLength,h,value,tangent,&lowBranch)||!structure.EvaluateAffineForce(cook,beam.index,beam.length,highLength,h,value,tangent,&highBranch)||lowBranch==highBranch)continue;
                        for(double corner:structure.ForceEvents(cook,beam.index)){if(!std::isfinite(corner)||corner<=0)continue;const double lowGap=lowLength-corner,highGap=highLength-corner;
                            if(lowGap*highGap>0||lowGap==highGap)continue;
                            const double side=highLength>lowLength?1.:-1.;
                            // Choose the outgoing representable side using a
                            // forward binary64 coordinate-evaluation bound.
                            const double eps=std::numeric_limits<double>::epsilon(),gamma=64*eps/(1-64*eps),sideError=gamma*(glm::length(low.x[beam.a])+glm::length(low.x[beam.b])+glm::length(high.x[beam.a])+glm::length(high.x[beam.b])+corner);
                            const double target=corner+side*sideError;if(side*(highLength-target)<0)continue;
                            double lo=lower,hi=upper;Trial event=high;
                            for(unsigned refine=0;refine<64;++refine){const double mid=.5*(lo+hi);if(mid==lo||mid==hi)break;for(unsigned i=0;i<total;++i)candidate[i]=mid*q[i];const Trial trial=evaluate(candidate);if(!trial.valid)break;
                                const double length=glm::length(trial.x[beam.b]-trial.x[beam.a]);if(side*(length-target)>=0){hi=mid;event=trial;}else lo=mid;}
                            if(hi<bestAlpha&&event.valid&&event.merit<=initial.merit+1e-4*hi*p.slope+roundoff&&(!p.valid||event.merit<p.trial.merit)){bestAlpha=hi;best=std::move(event);}
                        }}
                    // Coulomb stick/slip and pressure-zero charts have their
                    // own corners. Material-only events leave Newton halving
                    // toward a friction corner without reaching its outgoing
                    // derivative. Locate the actual trial-law branch change;
                    // no pressure, friction coefficient or motion is repaired.
                    for(unsigned contact=0;contact<contacts.size();++contact)for(unsigned kind=0;kind<2;++kind){
                        const auto margin=[&](const Trial& trial){const auto& law=trial.contact[contact].law;
                            if(kind==0)return law.impulse[0];
                            return std::hypot(law.impulse[1]-law.kinematics[1]/law.tangentMobility,law.impulse[2]-law.kinematics[2]/law.tangentMobility)-law.friction*std::max(0.,law.impulse[0]);};
                        const double a=margin(low),b=margin(high);
                        if(b==0||a==b||(a!=0&&std::signbit(a)==std::signbit(b)))continue;
                        const double side=b>0?1.:-1.;double lo=lower,hi=upper;Trial event=high;
                        for(unsigned refine=0;refine<64;++refine){const double mid=.5*(lo+hi);if(mid==lo||mid==hi)break;
                            for(unsigned i=0;i<total;++i)candidate[i]=mid*q[i];
                            const Trial trial=evaluate(candidate);if(!trial.valid)break;
                            if(side*margin(trial)>0){hi=mid;event=trial;}else lo=mid;
                        }
                        if(hi<bestAlpha&&event.valid&&event.merit<=initial.merit+1e-4*hi*p.slope+roundoff&&(!p.valid||event.merit<p.trial.merit)){
                            bestAlpha=hi;best=std::move(event);
                        }
                    }
                    if(std::isfinite(bestAlpha)){p.alpha=bestAlpha;p.trial=std::move(best);p.valid=true;}}
            }
            return p;
        };
        std::vector<double> load=initial.residual;for(double& value:load)value=-value;std::string failure;
        if(!SolveStructuralNewtonKrylov(load,action,precondition,direction,krylov,linearResidual,failure)){error="structural physical Newton: "+failure;diagnose(error.c_str(),direction);return false;}
        Proposal selected=globalize(direction);
        // A truncated proposal that crosses a return-map branch needs a
        // piecewise material competitor even if binary halving happened to
        // accept it before the severe-backtracking fallback. The material
        // transition, rather than a frame-sensitive halving count, identifies
        // the missing outgoing tangent. These pure trials never mutate state.
        bool materialBranchCrossed=false;
        if(selected.valid&&selected.alpha<1){const auto full=evaluate(direction);if(full.valid)for(const auto& beam:beams){
            double f,k;unsigned currentBranch=0,fullBranch=0;
            if(!structure.EvaluateAffineForce(cook,beam.index,beam.length,beam.length,h,f,k,&currentBranch)||
                !structure.EvaluateAffineForce(cook,beam.index,beam.length,glm::length(full.x[beam.b]-full.x[beam.a]),h,f,k,&fullBranch))continue;
            if(currentBranch!=fullBranch){materialBranchCrossed=true;break;}
        }}
        if(!selected.valid||materialBranchCrossed||selected.backtracks>=8){
            FILE* modelTrace=nullptr;static unsigned modelRecorded=0;const char* traceBase=std::getenv("JUDAS_STRUCTURAL_ITERATION_TRACE");
            if(traceBase&&*traceBase&&structuralTraceActive&&modelRecorded<16){const std::string path=std::string(traceBase)+".material-model-"+std::to_string(modelRecorded++)+".csv";modelTrace=std::fopen(path.c_str(),"w");
                if(modelTrace){std::fprintf(modelTrace,"# generation=%llu interval=%u outer=%u h=%.17g total=%u currentValid=%d currentAlpha=%.17g currentMerit=%.17g\n",(unsigned long long)generation,structuralTraceInterval,structuralTraceRound,h,total,int(selected.valid),selected.alpha,selected.trial.merit);std::fputs("iteration,stage,modelResidual,modelMerit,slope,alpha,backtracks,event,stepInfinityNorm,linearResidual,linearIterations,reason\n",modelTrace);}}
            const auto modelLog=[&](unsigned iteration,const char* stage,double residual,double merit,double slope,double alpha,unsigned backtracks,double event,double infinity,double linear,unsigned iterations,const char* reason){if(modelTrace){std::fprintf(modelTrace,"%u,%s,%.17g,%.17g,%.17g,%.17g,%u,%.17g,%.17g,%.17g,%u,%s\n",iteration,stage,residual,merit,slope,alpha,backtracks,event,infinity,linear,iterations,reason);std::fflush(modelTrace);}};
            const auto modelResidual=[&](const std::vector<double>& q,std::vector<double>& r){restoreCurrent();if(!action(q,r))return false;const auto dx=nodalDirection(q);std::vector<V> correction(positions.size(),V(0));
                for(unsigned i=0;i<beams.size();++i){const auto& beam=beams[i];const double dl=glm::dot(beam.n,dx[beam.b]-dx[beam.a]);double f,k;
                    if(!structure.EvaluateAffineForce(cook,beam.index,beam.length,beam.length+dl,h,f,k))return false;
                    const double forceChange=f+k*dl-beam.force-beam.tangent*dl;const V v=h*h*beam.n*forceChange;correction[beam.a]-=v;correction[beam.b]+=v;}
                for(unsigned i=0;i<total;++i)r[i]+=initial.residual[i];
                project(correction,r);return std::isfinite(norm(r));};
            const auto prepareModel=[&](const std::vector<double>& q){const auto dx=nodalDirection(q);for(auto& beam:beams){double f,k;
                    if(!structure.EvaluateAffineForce(cook,beam.index,beam.length,beam.length+glm::dot(beam.n,dx[beam.b]-dx[beam.a]),h,f,k))return false;
                    const M nn=glm::outerProduct(beam.n,beam.n);beam.hessian=k*nn+(beam.force/beam.length)*(M(1)-nn);}return true;};
            const auto modelDerivative=[&](const std::vector<double>& q,const std::vector<double>& d,std::vector<double>& r){restoreCurrent();if(!action(d,r))return false;const auto x=nodalDirection(q),dx=nodalDirection(d);std::vector<V> correction(positions.size(),V(0));
                for(const auto& beam:beams){const double length=beam.length+glm::dot(beam.n,x[beam.b]-x[beam.a]),dl=glm::dot(beam.n,dx[beam.b]-dx[beam.a]);double df;
                    if(!structure.EvaluateAffineDirectional(cook,beam.index,length,h,dl,df))return false;
                    const V v=h*h*beam.n*(df-beam.tangent*dl);correction[beam.a]-=v;correction[beam.b]+=v;}project(correction,r);return true;};
            std::vector<double> q(total,0),r;const double modelTolerance=std::max(1e-11,norm(initial.residual)*1e-9);const unsigned modelBound=std::min<unsigned>(4096,2*unsigned(beams.size())+8);bool modelConverged=false;unsigned modelIterations=0;
            for(;modelIterations<modelBound;++modelIterations){if(!modelResidual(q,r)){modelLog(modelIterations,"failure",0,0,0,0,0,0,0,0,0,"model-residual-invalid");break;}const double residual=norm(r);modelLog(modelIterations,"begin",residual,.5*residual*residual,0,0,0,0,0,0,0,"");if(residual<=4*modelTolerance){modelConverged=true;break;}
                if(!prepareModel(q)){modelLog(modelIterations,"failure",residual,0,0,0,0,0,0,0,0,"branch-prepare-invalid");break;}
                std::vector<double> rhsModel=r,d,dr;for(double& value:rhsModel)value=-value;unsigned steps=0;double linearError=0;
                if(!SolveStructuralNewtonKrylov(rhsModel,action,precondition,d,steps,linearError,failure)){modelLog(modelIterations,"failure",residual,0,0,0,0,0,0,linearError,steps,failure.c_str());break;}
                krylov=std::max(krylov,steps);linearResidual=std::max(linearResidual,linearError);
                if(!modelDerivative(q,d,dr)){modelLog(modelIterations,"failure",residual,0,0,0,0,0,0,linearError,steps,"model-derivative-invalid");break;}
                double modelSlope=0,infinity=0;for(unsigned i=0;i<total;++i){modelSlope+=r[i]*dr[i];infinity=std::max(infinity,std::abs(d[i]));}if(!(modelSlope<0)){modelLog(modelIterations,"failure",residual,0,modelSlope,0,0,0,infinity,linearError,steps,"model-non-descent");break;}
                const double before=.5*residual*residual,roundoff=128*std::numeric_limits<double>::epsilon()*std::max(before,std::numeric_limits<double>::min());double step=1;std::vector<double> next(total),rr;bool valid=false;unsigned rejected=0;
                for(;;){for(unsigned i=0;i<total;++i)next[i]=q[i]+step*d[i];if(modelResidual(next,rr)&&.5*norm(rr)*norm(rr)<=before+1e-4*step*modelSlope+roundoff){valid=true;break;}if(rejected++==24)break;step*=.5;}
                double chosenEvent=0;
                // In this frozen scalar model the event lengths are affine in
                // q. Resolve the first return-map corner ahead of a truncated
                // step instead of asymptotically approaching it by halving.
                if(rejected){const double lower=valid?step:0,upper=valid?std::min(1.,2*step):step;const auto x=nodalDirection(q),dx=nodalDirection(d);double event=std::numeric_limits<double>::infinity(),advance=0;
                    for(const auto& beam:beams){const double length=beam.length+glm::dot(beam.n,x[beam.b]-x[beam.a]),dl=glm::dot(beam.n,dx[beam.b]-dx[beam.a]);if(dl==0)continue;
                        for(double corner:structure.ForceEvents(cook,beam.index)){const double a=(corner-length)/dl;if(a>=lower&&a<=upper&&a<event){event=a;const double gamma=64*std::numeric_limits<double>::epsilon()/(1-64*std::numeric_limits<double>::epsilon());advance=gamma*(std::abs(length)+std::abs(corner))/std::abs(dl);}}}
                    if(std::isfinite(event)){const double eventStep=std::min(upper,event+advance);std::vector<double> atEvent(total),eventResidual;for(unsigned i=0;i<total;++i)atEvent[i]=q[i]+eventStep*d[i];
                        if(modelResidual(atEvent,eventResidual)&&.5*norm(eventResidual)*norm(eventResidual)<=before+1e-4*eventStep*modelSlope+roundoff){next=std::move(atEvent);chosenEvent=eventStep;valid=true;}}}
                if(!valid){
                    // Bounded failure-only evidence for a material corner:
                    // retain actual model lengths and one-sided residuals.
                    if(modelTrace){const auto x=nodalDirection(q),dx=nodalDirection(d);
                        static unsigned modelWitnesses=0;
                        if(modelWitnesses<4){const std::string path=std::string(traceBase)+".affine-witness-"+std::to_string(modelWitnesses++)+".txt";FILE* witness=std::fopen(path.c_str(),"w");
                            if(witness){restoreCurrent();std::fprintf(witness,"dimension %u\ninitial",total);for(double v:initial.residual)std::fprintf(witness," %.17g",v);std::fputs("\ncurrent",witness);for(double v:q)std::fprintf(witness," %.17g",v);std::fputs("\nresidual",witness);for(double v:r)std::fprintf(witness," %.17g",v);std::fputc('\n',witness);
                                std::vector<std::vector<V>> basis(total);
                                for(unsigned column=0;column<total;++column){std::vector<double> unit(total,0),values;unit[column]=1;action(unit,values);basis[column]=nodalDirection(unit);
                                    std::fprintf(witness,"column %u",column);for(double v:values)std::fprintf(witness," %.17g",v);std::fputc('\n',witness);}
                                for(const auto& beam:beams){std::vector<V> nodal(positions.size(),V(0));nodal[beam.a]-=h*h*beam.n;nodal[beam.b]+=h*h*beam.n;std::vector<double> projected(total,0);project(nodal,projected);
                                    std::fprintf(witness,"beam %u %.17g %.17g %.17g\nlengthGradient",beam.index,beam.length,beam.force,beam.tangent);for(const auto& dx:basis)std::fprintf(witness," %.17g",glm::dot(beam.n,dx[beam.b]-dx[beam.a]));
                                    std::fputs("\nforceGradient",witness);for(double v:projected)std::fprintf(witness," %.17g",v);std::fputc('\n',witness);
                                    auto events=structure.ForceEvents(cook,beam.index);std::sort(events.begin(),events.end());std::fputs("events",witness);for(double e:events)std::fprintf(witness," %.17g",e);std::fputc('\n',witness);
                                    for(unsigned branch=0;branch<5;++branch){const double point=branch==0?events[0]-1:branch==4?events[3]+1:.5*(events[branch-1]+events[branch]);double value,tangent;structure.EvaluateAffineForce(cook,beam.index,beam.length,point,h,value,tangent);
                                        std::fprintf(witness,"piece %.17g %.17g\n",value,tangent);}
                                }std::fclose(witness);
                            }}
                        for(const auto& beam:beams){const double length=beam.length+glm::dot(beam.n,x[beam.b]-x[beam.a]),dl=glm::dot(beam.n,dx[beam.b]-dx[beam.a]);double f,k;unsigned branch;
                            structure.EvaluateAffineForce(cook,beam.index,length,length,h,f,k,&branch);
                            const auto events=structure.ForceEvents(cook,beam.index);double nearest=std::numeric_limits<double>::infinity();for(double e:events)nearest=std::min(nearest,std::abs(length-e));
                            if(nearest<1e-10)std::fprintf(modelTrace,"# nearEvent beam=%u length=%.17g dLength=%.17g branch=%u tangent=%.17g nearest=%.17g\n",beam.index,length,dl,branch,k,nearest);
                        }
                        for(double epsilon:{1e-7,1e-9,1e-11,1e-13}){std::vector<double> probe(total),rr;
                            for(unsigned i=0;i<total;++i)probe[i]=q[i]+epsilon*d[i];
                            if(!modelResidual(probe,rr))continue;
                            double difference=0;unsigned worst=0;double largest=0;
                            for(unsigned i=0;i<total;++i){const double e=(rr[i]-r[i])/epsilon-dr[i];difference+=e*e;if(std::abs(e)>largest){largest=std::abs(e);worst=i;}}
                            std::fprintf(modelTrace,"# derivative epsilon=%.17g error=%.17g worst=%u largest=%.17g merit=%.17g slope=%.17g\n",epsilon,std::sqrt(difference),worst,largest,.5*norm(rr)*norm(rr),(.5*norm(rr)*norm(rr)-before)/epsilon);
                        }
                    }
                    modelLog(modelIterations,"failure",residual,before,modelSlope,step,rejected,0,infinity,linearError,steps,"model-backtracking-failed");break;}
                modelResidual(next,rr);modelLog(modelIterations,"accepted",norm(rr),.5*norm(rr)*norm(rr),modelSlope,step,rejected,chosenEvent,infinity,linearError,steps,"");q=std::move(next);
            }
            JUDAS_PROFILE_COUNTER("Structural material model iterations",double(modelIterations),ProfileCounterMode::Sum);
            restoreCurrent();if(modelConverged){Proposal alternate=globalize(q);const bool better=alternate.valid&&(!selected.valid||alternate.trial.merit<selected.trial.merit);modelLog(modelIterations,"physical-comparison",0,alternate.trial.merit,alternate.slope,alternate.alpha,alternate.backtracks,0,0,0,0,better?"alternate-selected":"alternate-rejected");if(better)selected=std::move(alternate);}
            else modelLog(modelIterations,"terminal",0,0,0,0,0,0,0,0,0,"model-not-converged");
            if(modelTrace)std::fclose(modelTrace);
        }
        restoreCurrent();
        if(!selected.valid&&total<=512){
            // Crossing an unloading corner can make the full Newton inverse
            // point back across that same corner. A bounded least-squares
            // trust proposal avoids that inverse; ONLY an actual nonlinear
            // Armijo improvement can be published, under the same certificate.
            std::vector<double> jacobian(size_t(total)*total),unit(total,0),column;
            bool valid=true;for(unsigned j=0;j<total&&valid;++j){unit[j]=1;valid=action(unit,column)&&column.size()==total;unit[j]=0;
                if(valid)for(unsigned i=0;i<total;++i)jacobian[size_t(i)*total+j]=column[i];}
            if(valid)for(double regularization:{1e-3,1e-2,1e-1,1.,10.,100.,1000.,10000.}){std::vector<double> proposal;
                if(!StructuralLeastSquaresProposal(jacobian,initial.residual,regularization,proposal))continue;
                Proposal candidate=globalize(proposal);if(candidate.valid&&(!selected.valid||candidate.trial.merit<selected.trial.merit)){
                    selected=std::move(candidate);if(selected.alpha==1)break;
                }
            }
        }
        if(!selected.valid){error="structural physical Newton failed bounded globalization";diagnose(error.c_str(),direction);return false;}
        direction=std::move(selected.direction);alpha=selected.alpha;slope=selected.slope;backtracks=selected.backtracks;accepted=std::move(selected.trial);
    }
    if(structuralTraceNumericalRound==std::min<unsigned>(4096,2*total+8)&&!certificate(accepted,bound))diagnose("dimension-closure-exhausted",direction);
    else if(backtracks>=8)diagnose("bounded-stalled-proposal",direction);
    // Commit only accepted numerical trials. Publication reconciles requested
    // TOTAL owned wrench with the measured native total, carrying sub-ULP kick
    // remainder into subsequent proposals instead of losing it every round.
    for(unsigned b=0;b<bodies.size();++b){const auto& body=bodies[b];auto& owned=structuralOwnedBodies[body.owned];const unsigned j=body.base;
        owned.idealImpulse+=alpha*body.mass*V(direction[j],direction[j+1],direction[j+2])/h;owned.idealMoment+=alpha*(body.inertia*V(direction[j+3],direction[j+4],direction[j+5]))/h;
        const V requestedP=owned.idealImpulse-owned.impulse,requestedL=owned.idealMoment-owned.moment;const V v=physics.GetLinearVelocity(body.handle),w=physics.GetAngularVelocity(body.handle);
        if(requestedP!=V(0))physics.ApplyLinearImpulse(body.handle,glm::vec3(requestedP));
        if(requestedL!=V(0))physics.ApplyAngularImpulse(body.handle,glm::vec3(requestedL));
        owned.impulse+=(V(physics.GetLinearVelocity(body.handle))-v)/body.pose.inverseMass;owned.moment+=glm::inverse(body.pose.inverseInertiaWorld)*(V(physics.GetAngularVelocity(body.handle))-w);}
    positions=accepted.x;
    for(unsigned i=0;i<contacts.size();++i){auto& row=structuralContactRows[contacts[i].index];const auto& t=accepted.contact[i];row.normalNet=t.n*t.law.impulse[0];row.tangentLambda=t.t0*t.law.impulse[1]+t.t1*t.law.impulse[2];row.normalLambda=t.law.impulse[0];row.normal=t.n;row.worldPoint=t.point;row.gap=t.law.kinematics[0];
        if(contacts[i].collider>=0)row.bodyMoment=-glm::cross(t.point-accepted.pose[unsigned(contacts[i].collider)].centerOfMass,t.force);}
    for(const auto& beam:beams){const V delta=positions[beam.b]-positions[beam.a];double force,tangent;structure.Linearize(cook,beam.index,glm::length(delta),h,force,tangent);structure.beamLinearizationNormal[beam.index]=glm::normalize(delta);structure.appliedBeamImpulse[beam.index]=-h*h*force*structure.beamLinearizationNormal[beam.index];structure.multipliers[beam.index]=-h*h*force;}
    for(auto& impulse:attachmentImpulse)impulse=V(0);
    for(auto& moment:attachmentMoment)moment=V(0);
    for(unsigned n=0;n<pins.size();++n)if(pins[n].body>=0){const auto& pin=pins[n];const unsigned b=unsigned(pin.body);const V reaction=accepted.nodeResidual[n]/double(pin.owners.size());for(const auto& owner:pin.owners){const unsigned a=owner.first,p=owner.second;structuralPinMultipliers[a][p]=reaction;structuralPinMoments[a][p]=-glm::cross(positions[n]-accepted.pose[b].centerOfMass,reaction);attachmentImpulse[a]-=reaction/h;attachmentMoment[a]-=glm::cross(positions[n]-centres[a],reaction)/h;}}
    structure.linearIterations=std::max(structure.linearIterations,krylov);structure.linearResidual=std::max(structure.linearResidual,linearResidual);structure.nonlinearResidual=accepted.equilibrium;structure.nonlinearRoundoffBound=bound;structure.precisionLimited=converged&&accepted.equilibrium>1e-11;
    double finalBound=0;structuralRootCertified=certificate(accepted,finalBound);structure.nonlinearRoundoffBound=finalBound;structure.precisionLimited=converged;
    structuralPredictedEndpoints.clear();for(const auto& body:bodies){glm::vec3 linear,angular;
        if(!physics.PredictDynamicEndVelocities(body.handle,float(h),linear,angular)){error="structural finite body disappeared before endpoint prediction";return false;}
        structuralPredictedEndpoints.push_back({body.handle,physics.PredictTransform(body.handle,float(h)),linear,angular});}
    auto& trace=IterationTrace();if(structuralTraceActive&&trace.nonlinear){std::fprintf(trace.nonlinear,"%llu,%u,%u,%u,%.17g,%u,0,%.17g,%.17g,%.17g,%.17g,%.17g,%u,%u,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%d,%.17g,%u\n",(unsigned long long)generation,structuralTraceInterval,stats.substeps,structuralTraceRound,alpha,backtracks,initial.merit,accepted.merit,slope,accepted.gap,accepted.complementarity,krylov,total,accepted.equilibrium,accepted.nodeVelocity,accepted.bodyVelocity,accepted.bodyAngular,accepted.gap,accepted.complementarity,accepted.friction,int(structure.precisionLimited),finalBound,structuralTraceNumericalRound);std::fflush(trace.nonlinear);}
    return true;
}
bool DeformableInstance::StructuralBlock(double h,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    bool applicable=false;if(!StructuralPrimalBlock(h,physics,targets,applicable))return false;if(applicable)return true;
    if(!structuralContactRows.empty()){error="condensed structural contacts require an independent finite-pin system within 512 primal DOFs";return false;}
    struct Body{BodyHandle handle;V com;M inverseInertia;double inverseMass;V linear{0},angular{0};};
    struct Row{unsigned a=0,b=~0u,beam=~0u,attachment=~0u,pin=0,axis=0,body=~0u;V gradient{0},arm{0},point{0},centre{0};double compliance=0,rhs=0;};
    std::vector<Body> bodies;std::vector<Row> rows;std::vector<double> diagonal,rhs;
    std::vector<V> baseImpulse(positions.size(),V(0)),constantTargets(asset->structure->beams.size(),V(0));std::vector<uint8_t> constant(asset->structure->beams.size(),0);
    const auto bodyIndex=[&](BodyHandle handle){for(unsigned i=0;i<bodies.size();++i)if(bodies[i].handle.id==handle.id&&bodies[i].handle.world==handle.world)return i;
        const double m=physics.GetMass(handle);bodies.push_back({handle,V(physics.PredictCenterOfMass(handle,float(h))),M(physics.PredictedInverseInertiaWorld(handle,float(h))),m>0?1/m:0});return unsigned(bodies.size()-1);
    };
    // Prescribed targets remove their node DOFs. Finite targets retain both
    // sides of every pin in this same Schur system, including all six body DOFs.
    for(unsigned a=0;a<settings.attachments.size();++a){const auto& attachment=settings.attachments[a];
        if(released[a]||!attachment.enabled||a>=targets.size()||!targets[a].valid)continue;
        const auto& t=targets[a];const auto& group=asset->groups.at(attachment.group);
        if(!physics.IsDynamicBody(t.body)){for(auto n:group)positions[n]=target(t.current,asset->nodes[n]+attachment.offset);continue;}
        const unsigned body=bodyIndex(t.body);const auto pose=physics.PredictTransform(t.body,float(h));
        const glm::dquat rotation(pose.rotation);V centre(0);
        for(auto n:group)centre+=V(pose.position)+rotation*(asset->nodes[n]+attachment.offset);
        centre/=double(group.size());
        for(unsigned pin=0;pin<group.size();++pin){const unsigned n=group[pin];const V point=V(pose.position)+rotation*(asset->nodes[n]+attachment.offset),arm=point-bodies[body].com;
            for(unsigned axis=0;axis<3;++axis){V normal(0);normal[axis]=1;
                rows.push_back({n,~0u,~0u,a,pin,axis,body,normal,arm,point,centre,0,-(positions[n]-point)[axis]});
                const V angular=glm::cross(arm,normal);
                diagonal.push_back(inverseMass[n]+bodies[body].inverseMass+glm::dot(angular,bodies[body].inverseInertia*angular));rhs.push_back(rows.back().rhs);
            }
        }
    }
    const auto& cook=*asset->structure;
    for(unsigned i=0;i<cook.beams.size();++i){if(structure.broken[i])continue;const auto& b=cook.beams[i];const V delta=positions[b.b]-positions[b.a];const double length=glm::length(delta);double force=0,tangent=0;
        if(!structure.Linearize(cook,i,length,h,force,tangent)){error="invalid structural member length or constitutive state";return false;}
        const V n=delta/length;structure.beamLinearizationNormal[i]=n;
        const double oldParallel=glm::dot(n,structure.appliedBeamImpulse[i]);V rebase=n*oldParallel-structure.appliedBeamImpulse[i];
        if(tangent<=1e-20){constant[i]=1;constantTargets[i]=n*(-h*h*force);rebase=constantTargets[i]-structure.appliedBeamImpulse[i];}
        baseImpulse[b.a]-=rebase;baseImpulse[b.b]+=rebase;if(constant[i])continue;
        const double compliance=1/(h*h*tangent),residual=-force/tangent-compliance*oldParallel;
        rows.push_back({b.a,b.b,i,~0u,0,0,~0u,n,V(0),V(0),V(0),compliance,residual});
        diagonal.push_back(inverseMass[b.a]+inverseMass[b.b]+compliance);rhs.push_back(residual);
    }
    for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];
        if(row.beam!=~0u)rhs[i]-=glm::dot(row.gradient,inverseMass[row.b]*baseImpulse[row.b]-inverseMass[row.a]*baseImpulse[row.a]);
        else rhs[i]-=glm::dot(row.gradient,inverseMass[row.a]*baseImpulse[row.a]);}
    std::vector<V> nodal(positions.size());std::vector<double> solution;
    const auto distribute=[&](const std::vector<double>& values){std::fill(nodal.begin(),nodal.end(),V(0));for(auto& body:bodies){body.linear=body.angular=V(0);}
        for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];const V change=row.gradient*values[i];
            if(row.beam!=~0u){nodal[row.a]-=change;nodal[row.b]+=change;}
            else{nodal[row.a]+=change;auto& body=bodies[row.body];body.linear-=change;body.angular-=glm::cross(row.arm,change);}
        }
    };
    const auto multiply=[&](const std::vector<double>& values,std::vector<double>& output){distribute(values);output.resize(rows.size());
        for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];
            if(row.beam!=~0u)output[i]=glm::dot(row.gradient,inverseMass[row.b]*nodal[row.b]-inverseMass[row.a]*nodal[row.a])+row.compliance*values[i];
            else{const auto& body=bodies[row.body];const V response=body.linear*body.inverseMass+glm::cross(body.inverseInertia*body.angular,row.arm);
                output[i]=glm::dot(row.gradient,inverseMass[row.a]*nodal[row.a]-response);
            }
        }
    };
    unsigned rounds=0;double residual=0;
    if(!SolveStructuralSchur(diagonal,rhs,multiply,solution,rounds,residual)){error="structural body/member compatibility solve failed its dimension-bounded residual contract";return false;}
    structure.linearIterations=std::max(structure.linearIterations,rounds);structure.linearResidual=residual;distribute(solution);
    for(unsigned n=0;n<positions.size();++n)positions[n]+=inverseMass[n]*(nodal[n]+baseImpulse[n]);
    for(const auto& body:bodies){
        // Freeze and sum all six-DOF responses before applying either impulse.
        // Applying one row and then recomputing its future COM would change the
        // very lever used by the symmetric operator and inject coupling energy.
        physics.ApplyLinearImpulse(body.handle,glm::vec3(body.linear/h));
        physics.ApplyAngularImpulse(body.handle,glm::vec3(body.angular/h));
    }
    for(unsigned i=0;i<rows.size();++i){const auto& row=rows[i];
        if(row.beam!=~0u){const double next=glm::dot(row.gradient,structure.appliedBeamImpulse[row.beam])+solution[i];structure.multipliers[row.beam]=next;structure.appliedBeamImpulse[row.beam]=row.gradient*next;}
        else{structuralPinMultipliers[row.attachment][row.pin][row.axis]+=solution[i];const V reaction=-row.gradient*solution[i]/h;
            attachmentImpulse[row.attachment]+=reaction;attachmentMoment[row.attachment]+=glm::cross(row.point-row.centre,reaction);
        }
    }
    for(unsigned i=0;i<cook.beams.size();++i)if(constant[i]){structure.appliedBeamImpulse[i]=constantTargets[i];structure.multipliers[i]=glm::dot(constantTargets[i],structure.beamLinearizationNormal[i]);}
    return true;
}
bool DeformableInstance::BeginStructuralInterval(double h,PhysicsWorld& physics,const GravityField& gravity,const std::vector<DeformableTarget>& targets,bool beginMacro,bool predictive){
    structuralPredictiveCoupling=predictive;
    if(!Structural()){error="structural interval requires a structural network";return false;}
    if(!settings.enabled||!error.empty()||h<=0)return false;
    if(structuralIntervalOpen){error="structural interval already open; instance stopped";return false;}
    if(beginMacro){
        previous=positions;structuralMacroSeconds=0;stats={};stats.nodes=positions.size();stats.triangles=asset->triangles.size();stats.iterations=settings.iterations;
        contactObservations.clear();attachmentState.assign(settings.attachments.size(),{});attachmentPending.assign(settings.attachments.size(),0);
        std::fill(structure.stressDemand.begin(),structure.stressDemand.end(),0);
        structure.maximumPinDrift=0;
    }
    structuralMacroSeconds+=h;++stats.substeps;activeSubsteps=1;structuralContactRows.clear();
    structuralOwnedBodies.clear();structuralMeritPenalty=0;structuralRootCertified=false;structuralRootRequired=false;structuralRootDimension=0;structuralPredictedEndpoints.clear();
    ++structuralTraceInterval;structuralTraceRound=structuralTraceNumericalRound=0;const auto& diagnostic=IterationTrace();structuralTraceActive=diagnostic.network&&structuralTraceInterval>diagnostic.skip&&structuralTraceInterval<=diagnostic.skip+64;
    attachmentImpulse.assign(settings.attachments.size(),V(0));attachmentMoment.assign(settings.attachments.size(),V(0));
    structuralPinMultipliers.resize(settings.attachments.size());structuralPinMoments.resize(settings.attachments.size());structuralPinnedBodies.assign(settings.attachments.size(),{});
    for(unsigned a=0;a<settings.attachments.size();++a){structuralPinMultipliers[a].assign(asset->groups.at(settings.attachments[a].group).size(),V(0));structuralPinMoments[a].assign(structuralPinMultipliers[a].size(),V(0));if(a<targets.size()&&targets[a].valid)structuralPinnedBodies[a]=targets[a].body;}
    for(unsigned n=0;n<mass.size();++n)inverseMass[n]=1/mass[n];
    structuralIntervalTargetMoving=false;
    for(unsigned i=0;i<settings.attachments.size();++i){const auto& a=settings.attachments[i];if(released[i]||!a.enabled||i>=targets.size()||!targets[i].valid)continue;
        const auto& t=targets[i];const bool dynamic=t.body.IsValid()&&physics.IsDynamicBody(t.body);
        if((a.forceLimit>0||a.torqueLimit>0)&&!dynamic){error="finite attachment strength requires a dynamic body target";return false;}
        if(!dynamic){const auto found=asset->groups.find(a.group);if(found!=asset->groups.end())for(auto n:found->second)inverseMass[n]=0;}
        double movement=0;for(int k=0;k<4;++k)movement+=glm::length(t.current[k]-t.previous[k]);structuralIntervalTargetMoving|=dynamic||movement>1e-8;
    }
    start=positions;
    for(unsigned n=0;n<positions.size();++n){
        const V g=gravity.Sample(glm::vec3(positions[n]));
        if(glm::length(g-lastGravity[n])>1e-5)Wake();
        lastGravity[n]=g;
        velocities[n]+=(g+forces[n]/mass[n])*h;
        if(settings.material.airDrag>0)velocities[n]+=(1-std::exp(-settings.material.airDrag*h))*(settings.material.airVelocity-velocities[n]);
        // Structure uses only equal/opposite member damping below. Legacy
        // absolute material damping remains exclusive to legacy deformables.
        positions[n]+=velocities[n]*h;
    }
    structuralFreePositions=positions;
    // Prescribed pins have no free inertial DOF. Publish their prescribed
    // endpoint before contact discovery rather than briefly falling through a
    // collider and repairing that artificial prediction inside the block.
    for(unsigned a=0;a<settings.attachments.size();++a){if(released[a]||!settings.attachments[a].enabled||a>=targets.size()||!targets[a].valid||physics.IsDynamicBody(targets[a].body))continue;
        for(auto n:asset->groups.at(settings.attachments[a].group))positions[n]=target(targets[a].current,asset->nodes[n]+settings.attachments[a].offset);}
    structure.BeginInterval(*asset->structure,start);
    structuralIntervalOpen=true;structuralIntervalCompleted=false;return true;
}
void DeformableInstance::SolveStructuralIteration(double h,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    if(!structuralIntervalOpen||!error.empty())return;
    auto& trace=IterationTrace();const unsigned interval=structuralTraceInterval,iteration=++structuralTraceRound;const bool tracing=structuralTraceActive;
    try{
        if(structuralPredictiveCoupling){
            // Native coupling rounds exchange motion with ordinary rigid
            // contacts/joints. They are not the convergence budget of the
            // nonlinear material root. Close that SAME fixed-h system before
            // returning: no new discovery, time advance, gravity, forces or
            // irreversible material history is evaluated in this inner loop.
            structuralTraceNumericalRound=0;unsigned rootDimension=0;
            for(;;){
                ++structuralTraceNumericalRound;
                JUDAS_PROFILE_COUNTER("Structural numerical root iterations",1,ProfileCounterMode::Sum);
                if(!StructuralBlock(h,physics,targets))return;
                if(structuralTraceNumericalRound==1){
                    // The general Schur compatibility path retains exactly
                    // one solve per native round and its existing contract.
                    if(!structuralRootRequired)break;
                    rootDimension=structuralRootDimension;
                }else if(!structuralRootRequired||structuralRootDimension!=rootDimension){
                    error="structural numerical root changed its frozen supported dimension";return;
                }
                if(structuralRootCertified)break;
                // Explicit work guard for the supported numerical system;
                // this is not a nonlinear convergence theorem. Exhaustion
                // remains a failure, never permission to accept its residual.
                const unsigned bound=std::min<unsigned>(4096,2*rootDimension+8);
                if(structuralTraceNumericalRound>=bound){
                    error="structural numerical root exceeded its dimension-bounded closure policy; material history not accepted";return;
                }
            }
        }else{
            // Native standalone legacy callers have already advanced their
            // rigid world. Their prescribed fixtures still use the same global
            // member solve; live RuntimeWorld always uses predictive coupling.
            for(unsigned a=0;a<settings.attachments.size();++a){if(released[a]||!settings.attachments[a].enabled||a>=targets.size()||!targets[a].valid||physics.IsDynamicBody(targets[a].body))continue;
                for(auto n:asset->groups.at(settings.attachments[a].group))positions[n]=target(targets[a].current,asset->nodes[n]+settings.attachments[a].offset);
            }
            structure.Solve(*asset->structure,positions,inverseMass,h);
            RigidContacts(h,1,physics,targets);SurfaceContacts(*this,*this,h);Attach(h,1,physics,targets);
        }
    }catch(const std::exception& failure){error=failure.what();return;}
    if(tracing)TraceNetwork(trace,*this,start,h,interval,iteration,"post-coupled-block");
}
void DeformableInstance::RefreshStructuralPins(double h,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    if(!structuralPredictiveCoupling)return;
    std::vector<V> value=positions;std::vector<BodyHandle> owner(positions.size());std::vector<BodyHandle> bodies;
    for(unsigned a=0;a<settings.attachments.size();++a){const auto& attachment=settings.attachments[a];if(released[a]||!attachment.enabled||a>=targets.size()||!targets[a].valid)continue;
        const auto& target=targets[a];if(!physics.IsDynamicBody(target.body))continue;
        if(std::none_of(bodies.begin(),bodies.end(),[&](auto hnd){return hnd.id==target.body.id&&hnd.world==target.body.world;}))bodies.push_back(target.body);
        const auto pose=StructuralPrediction(physics,target.body,h);
        for(unsigned n:asset->groups.at(attachment.group)){const V point=V(pose.position)+glm::dquat(pose.rotation)*(asset->nodes[n]+attachment.offset);
            if(owner[n].IsValid()&&(owner[n].id!=target.body.id||owner[n].world!=target.body.world||glm::length(value[n]-point)>1e-9))return;
            owner[n]=target.body;value[n]=point;}}
    unsigned dimension=unsigned(bodies.size())*6;for(unsigned n=0;n<positions.size();++n)if(inverseMass[n]>0&&!owner[n].IsValid())dimension+=3;
    if(dimension>512)return;
    for(unsigned n=0;n<positions.size();++n)if(owner[n].IsValid())positions[n]=value[n];
}
void DeformableInstance::SolveStructuralContacts(double h,PhysicsWorld& physics,const std::vector<DeformableTarget>& targets){
    if(!structuralIntervalOpen||!structuralPredictiveCoupling||!error.empty())return;
    RefreshStructuralPins(h,physics,targets);
    RigidContacts(h,1,physics,targets);SurfaceContacts(*this,*this,h);
}
void DeformableInstance::EndStructuralInterval(double h,PhysicsWorld& physics,bool endMacro){
    if(!structuralIntervalOpen)return;
    const bool predictive=structuralPredictiveCoupling;
    structuralIntervalOpen=false;structuralPredictiveCoupling=false;
    if(!error.empty())return;
    if(predictive){
        for(const auto& owned:structuralOwnedBodies){structure.publicationLinearError=std::max(structure.publicationLinearError,glm::length(owned.idealImpulse-owned.impulse));structure.publicationAngularError=std::max(structure.publicationAngularError,glm::length(owned.idealMoment-owned.moment));}
        if(structuralRootRequired&&!structuralRootCertified){error="structural interval ended without a converged physical root; material history not accepted";return;}
        for(const auto& endpoint:structuralPredictedEndpoints){
            if(!physics.IsBodyEnabled(endpoint.body)){error="structural finite body disappeared before physical publication";return;}
            // A later participant/impulse can change actual velocity while the
            // whole pose still rounds to the same far-world position. Compare
            // motion to the native endpoint computed BEFORE advance, including
            // its angular transport; pose roundoff is not permission to accept
            // a stale physical root. There is no post-step motion correction.
            if(physics.GetLinearVelocity(endpoint.body)!=endpoint.linearVelocity||physics.GetAngularVelocity(endpoint.body)!=endpoint.angularVelocity){error="structural actual rigid endpoint changed motion after the last converged solve; material history not accepted";return;}
            const auto actual=physics.GetTransform(endpoint.body);
            // Compare with the SAME ordinary native endpoint, not the smooth
            // dependent-coordinate trial. Only forward binary32 publication
            // error is admitted here; an external impulse or CCD path change
            // must be solved rather than accepting the prior cached root.
            const double eps=std::numeric_limits<float>::epsilon(),gamma=8*eps/(1-8*eps);
            const double positionError=glm::length(V(actual.position)-V(endpoint.predicted.position));
            const double positionBound=gamma*(glm::length(V(actual.position))+glm::length(V(endpoint.predicted.position))+1);
            const glm::dquat qa(actual.rotation),qp(endpoint.predicted.rotation);
            const double rotationError=std::min(glm::length(glm::dvec4(qa.x-qp.x,qa.y-qp.y,qa.z-qp.z,qa.w-qp.w)),glm::length(glm::dvec4(qa.x+qp.x,qa.y+qp.y,qa.z+qp.z,qa.w+qp.w)));
            if(positionError>positionBound||rotationError>gamma*(glm::length(qa)+glm::length(qp))){error="structural actual rigid endpoint changed after the last converged solve; material history not accepted";return;}
        }
    }
    for(unsigned a=0;a<settings.attachments.size();++a){auto& state=attachmentState[a];state.force=attachmentImpulse[a]/h;state.moment=attachmentMoment[a]/h;
        const double force=glm::length(state.force),torque=glm::length(state.moment);if(!std::isfinite(force)||!std::isfinite(torque)){error="nonfinite structural attachment reaction; instance stopped";return;}
        state.peakForce=std::max(state.peakForce,force);state.peakTorque=std::max(state.peakTorque,torque);const auto& aSettings=settings.attachments[a];
        if((aSettings.forceLimit>0&&force>aSettings.forceLimit)||(aSettings.torqueLimit>0&&torque>aSettings.torqueLimit))attachmentPending[a]=1;
    }
    for(unsigned n=0;n<positions.size();++n){if(!finite(positions[n])){error="nonfinite structural solve; instance stopped";return;}velocities[n]=(positions[n]-start[n])/h;if(!finite(velocities[n])){error="nonfinite structural velocity; instance stopped";return;}}
    if(stats.capacityExceeded){error="deformable surface candidate capacity exceeded; instance stopped";return;}
    if(predictive){for(unsigned a=0;a<settings.attachments.size();++a){const auto& attachment=settings.attachments[a];const auto body=structuralPinnedBodies[a];
        if(released[a]||!attachment.enabled||!physics.IsBodyEnabled(body))continue;
        // Measure the ACTUAL CCD/contact-resolved rigid endpoint before
        // accepting material history. Prediction is not endpoint evidence.
        const auto pose=physics.GetTransform(body);const glm::dquat rotation(pose.rotation);
        for(auto n:asset->groups.at(attachment.group)){const V point=V(pose.position)+rotation*(asset->nodes[n]+attachment.offset);
            structure.maximumPinDrift=std::max(structure.maximumPinDrift,glm::length(positions[n]-point));}
    }}
    // All participants' contact rounds finish before this acceptance boundary.
    // Failed/incomplete contact must not publish irreversible material history.
    if(predictive)PublishStructuralContacts(h);
    structure.AcceptInterval(*asset->structure,positions,h);
    for(unsigned b=0;b<asset->structure->beams.size();++b){const auto& member=asset->structure->beams[b];if(structure.broken[b])continue;stats.maximumStrain=std::max(stats.maximumStrain,std::abs(glm::length(positions[member.b]-positions[member.a])-structure.restLengths[b])/member.restLength);}
    if(endMacro){
        structure.Commit(*asset->structure,positions);
        for(unsigned a=0;a<released.size();++a)if(attachmentPending[a])released[a]=1;
        std::fill(forces.begin(),forces.end(),V(0));double speed=0;for(auto v:velocities)speed=std::max(speed,glm::length(v));
        if(speed<.015&&!structuralIntervalTargetMoving&&settings.material.airDrag==0)quietSeconds+=structuralMacroSeconds;else quietSeconds=0;
        sleeping=quietSeconds>1;JUDAS_PROFILE_COUNTER("Structural nodes",double(stats.nodes),ProfileCounterMode::Sum);JUDAS_PROFILE_COUNTER("Structural beams",double(asset->structure->beams.size()),ProfileCounterMode::Sum);
    }
    structuralIntervalCompleted=true;structuralOwnedBodies.clear();structuralPredictedEndpoints.clear();
}

DeformableHit DeformableInstance::Raycast(V origin,V direction,double maximum)const{
    DeformableHit hit;
    if(!settings.enabled||!finite(origin)||!finite(direction)||!std::isfinite(maximum)||maximum<0||glm::length(direction)<1e-12)return hit;
    direction=glm::normalize(direction);
    double best=maximum;
    for(unsigned t=0;t<asset->triangles.size();++t){if(!FaceVisible(t))continue;auto f=asset->triangles[t];
        V a=positions[f.x],e1=positions[f.y]-a,e2=positions[f.z]-a,p=glm::cross(direction,e2);
        double det=glm::dot(e1,p);
        if(std::abs(det)<1e-12)continue;
        V s=origin-a;
        double u=glm::dot(s,p)/det;
        if(u<0||u>1)continue;
        V q=glm::cross(s,e1);
        double v=glm::dot(direction,q)/det;
        if(v<0||u+v>1)continue;
        double d=glm::dot(e2,q)/det;
        if(d<0||d>best)continue;
        best=d;
        hit.hit=true;
        hit.distance=d;
        hit.point=origin+direction*d;
        hit.normal=glm::normalize(glm::cross(e1,e2));
        if(glm::dot(hit.normal,direction)>0)hit.normal=-hit.normal;
        hit.location={generation,t,V(1-u-v,u,v),TopologyRevision()};
    }return hit;
}
void DeformableInstance::Persist(SaveArchive& ar,bool materialFrame,bool attachmentLimits,bool structuralState){
    ar.Require(!Structural()||structuralState,"structural save requires structural participant version");
    ar.Require(!Structural()||(!structuralIntervalOpen&&structuralIntervalCompleted),"structural save requires a successfully closed physical interval");
    if(asset->fracture)fracture.Persist(ar,*asset->fracture);
    ar(settings.enabled,sleeping,quietSeconds);
    settings.material.Save(ar);
    std::string validation;
    ar.Require(ValidDeformableSettings(settings,validation),"invalid saved deformable material");
    ar.Require(validMasses(*asset,settings.material.density),"invalid saved deformable derived mass");
    ar(settings.attachments,positions,velocities,plasticRest,released);
    // Attachment::Save deliberately retains its original field layout. Only
    // State.2 / participant.4 carries optional strength fields; legacy formats
    // keep unlimited connections rather than inventing historical strength.
    if(attachmentLimits)for(auto& attachment:settings.attachments)ar(attachment.forceLimit,attachment.torqueLimit);
    else if(ar.reading)for(auto& attachment:settings.attachments)attachment.forceLimit=attachment.torqueLimit=0;
    ar.Require(ValidDeformableSettings(settings,validation),"invalid saved deformable attachments");
    for(const auto& attachment:settings.attachments)ar.Require(asset->groups.count(attachment.group),"saved attachment group missing");
    ar.Require(positions.size()==asset->nodes.size()&&velocities.size()==positions.size()&&plasticRest.size()==asset->solids.size()&&released.size()==settings.attachments.size(),"deformable snapshot topology mismatch");
    for(auto m:plasticRest)ar.Require(glm::determinant(m)>1e-12,"saved deformable rest inversion");
    for(auto value:released)ar.Require(value<=1,"invalid saved attachment release state");
    ar.Require(quietSeconds>=0,"invalid saved deformable sleep time");
    // Logical owner transforms may move prescribed supports without replacing
    // the simulated material. Its original constitutive/plastic reference must
    // survive cold reconstruction from the CURRENT owner transform.
    if(materialFrame){M reference(initial);ar(reference);
        for(int a=0;a<3;++a)for(int b=0;b<3;++b)ar.Require(std::abs(glm::dot(reference[a],reference[b])-(a==b?1.:0.))<1e-5,"invalid saved deformable material frame");
        ar.Require(glm::determinant(reference)>0,"invalid saved deformable material orientation");
        if(ar.reading)for(int k=0;k<3;++k)initial[k]=glm::dvec4(reference[k],0);
    }
    if(Structural()){ar(settings.attachedBodyContact);structure.Persist(ar,*asset->structure,unsigned(positions.size()));}
    if(ar.reading){selfCandidatesValid=false;contactExclusionTopology=~uint64_t(0);previous=start=positions;
        structuralIntervalOpen=false;structuralIntervalTargetMoving=false;structuralPredictiveCoupling=false;structuralPrimalFactor.clear();structuralFactorTraversal.Clear();structuralContactRows.clear();structuralFreePositions.clear();structuralOwnedBodies.clear();structuralPinMoments.clear();structuralMeritPenalty=0;structuralRootCertified=false;structuralRootRequired=false;structuralRootDimension=0;structuralIntervalCompleted=true;structuralPredictedEndpoints.clear();structuralTraceNumericalRound=0;
        contactObservations.clear();stats={};
        attachmentState.assign(settings.attachments.size(),{});attachmentPending.clear();attachmentImpulse.clear();attachmentMoment.clear();
        forces.assign(positions.size(),V(0));
        lastGravity.assign(positions.size(),V(0));
        for(size_t i=0;i<mass.size();++i){mass[i]=asset->measures[i]*asset->massWeights[i]*settings.material.density;
            inverseMass[i]=1/mass[i];
            }std::fill(lambda.begin(),lambda.end(),0);
        std::fill(volumeLambda.begin(),volumeLambda.end(),0);
        error.clear();
        }
}
