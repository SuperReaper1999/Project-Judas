#include "WaterFragmentAdvance.h"
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <chrono>
#include <iostream>
#include <iomanip>
using namespace judas::volume_grid;
using H=boost::multiprecision::number<boost::multiprecision::cpp_dec_float<100>>;
H Exact(CutCompensated x){return H(x.hi)+H(x.lo);}
CutSpatialField Columns(){CutSpatialField f;f.chart.layout={{2,1,1},1.};f.parent={0,1};f.chart.regions={{{0.,0.,0.},{1.,1.,1.},0},{{1.,0.,0.},{2.,1.,1.},1}};f.geometry.startCapacity=f.geometry.endCapacity={1.,1.};f.geometry.faces={{0,1,0,{1.,0.,0.},{1.,1.,1.},1.,1.,1.,0.,1.}};f.water={.6,.4};f.gas={.4,.6};f.gasMass={.48,.72};f.flux={0.};return f;}
struct Sample {std::vector<H> rows,mass,volume,density;H norm=0;bool domain=true;};
int main(){std::cout<<std::setprecision(17);auto field=Columns();WaterMaterialState initial,state;std::string error;WaterGasSettings settings;WaterFragmentAdvanceStats stats;
 if(!ImportWaterMaterial(field,{},initial,error)||!AdvanceWaterFragments(field,initial,1000.,{0.,-9.81,0.},settings,state,stats,error)){std::cerr<<error;return 2;}
 WaterFragmentGeometry geometry;if(!PrepareWaterFragmentGeometry(field,state,1000.,{0.,-9.81,0.},settings,geometry,error)){std::cerr<<error;return 2;}
 auto& water=geometry.liquid;auto& gas=geometry.air;std::size_t nw=water.sharedFaces,ng=gas.volume.size(),n=nw+ng;
 std::cout<<"REFERENCE dimensions="<<n<<" pieces="<<state.fragments.size()<<" water="<<water.regions.size()<<" gas="<<ng<<"\n";
 if(n>200){std::cerr<<"bounded reference dimension exceeded";return 2;}
 H dt=settings.dt,p0=settings.referencePressure,c=H(settings.referenceDensity)/p0,datum=0;bool found=false;
 for(auto& r:water.regions)for(auto p:r.response.free)if(!found&&r.owners[p].gas!=SIZE_MAX){datum=Exact(r.potential[p]);found=true;}
 std::vector<H> tolerance(n,H(settings.massTolerance/settings.referenceDensity));
 for(std::size_t g=0;g<ng;++g)tolerance[nw+g]=std::min(tolerance[nw+g],H(settings.relativeTolerance)*Exact(gas.volume[g]));
 auto evaluate=[&](const std::vector<H>& x){Sample s;s.rows.resize(n);s.volume.resize(ng);s.mass.resize(ng);s.density.resize(ng);
  for(std::size_t g=0;g<ng;++g){s.volume[g]=Exact(gas.volume[g]);s.mass[g]=Exact(gas.mass[g]);s.density[g]=c*x[nw+g];if(s.density[g]<=0)s.domain=false;}
  if(!s.domain)return s;
  for(auto& r:water.regions){auto m=r.response.free.size();if(!m)continue;std::vector<H> head(m),q(m);
   for(std::size_t a=0;a<m;++a){auto p=r.response.free[a];auto o=r.owners[p];head[a]=o.shared!=SIZE_MAX?x[o.shared]:x[nw+o.gas]-p0+Exact(r.potential[p])-datum;}
   for(std::size_t a=0;a<m;++a)if(a!=r.response.reference){q[a]=Exact(r.response.predictor[a]);for(std::size_t b=0;b<m;++b)if(b!=r.response.reference)q[a]-=dt*Exact(r.response.mobility[a*m+b])*(head[b]-head[r.response.reference]);q[r.response.reference]-=q[a];}
   for(std::size_t a=0;a<m;++a){auto o=r.owners[r.response.free[a]];if(o.shared!=SIZE_MAX)s.rows[o.shared]-=dt*q[a];else s.volume[o.gas]-=dt*q[a];}
  }
  for(auto l:gas.links){H mass=dt*H(l.massConductance)*(x[nw+l.left]-x[nw+l.right]);s.mass[l.left]-=mass;s.mass[l.right]+=mass;}
  for(auto v:gas.vents)s.mass[v.node]-=dt*H(v.massConductance)*(x[nw+v.node]-p0-H(v.gaugePressure));
  for(std::size_t g=0;g<ng;++g){s.rows[nw+g]=s.volume[g]-s.mass[g]/s.density[g];if(s.mass[g]<=0)s.domain=false;}
  for(std::size_t i=0;i<n;++i){H normalized=s.rows[i]/tolerance[i];s.norm+=normalized*normalized;}
  return s;
 };
 std::vector<H> x(n);std::vector<bool> seeded(nw);
 for(auto& r:water.regions)for(auto p:r.response.free){auto o=r.owners[p];if(o.shared!=SIZE_MAX&&!seeded[o.shared]){x[o.shared]=Exact(r.potential[p])-datum;seeded[o.shared]=true;}}
 for(std::size_t g=0;g<ng;++g)x[nw+g]=p0;
 auto start=std::chrono::steady_clock::now();
 for(int iteration=0;iteration<40;++iteration){auto s=evaluate(x);H maximum=0;for(std::size_t i=0;i<n;++i)maximum=std::max(maximum,H(abs(s.rows[i])/tolerance[i]));
  std::cout<<"REFERENCE iteration="<<iteration<<" normalized="<<maximum<<" domain="<<s.domain<<std::endl;
  if(maximum<=1&&s.domain){for(std::size_t g=0;g<ng;++g)if(s.volume[g]<=0){std::cerr<<"nonpositive displaced volume";return 4;}
   H minimumMass=s.mass[0],minimumVolume=s.volume[0],maxPressureDiff=0;
   for(std::size_t g=0;g<ng;++g){minimumMass=std::min(minimumMass,s.mass[g]);minimumVolume=std::min(minimumVolume,s.volume[g]);}
   H maxRoundedMassError=0;std::vector<CutCompensated> rounded(n);for(std::size_t i=0;i<n;++i){rounded[i].hi=x[i].convert_to<double>();rounded[i].lo=(x[i]-H(rounded[i].hi)).convert_to<double>();}
   std::vector<H> roundedMass(ng);for(std::size_t g=0;g<ng;++g)roundedMass[g]=Exact(gas.mass[g]);
   for(auto l:gas.links){H actual=dt*H(l.massConductance)*(x[nw+l.left]-x[nw+l.right]);H roundedFlow=dt*H(l.massConductance)*Exact(rounded[nw+l.left]-rounded[nw+l.right]);roundedMass[l.left]-=roundedFlow;roundedMass[l.right]+=roundedFlow;maxPressureDiff=std::max(maxPressureDiff,H(abs((x[nw+l.left]-x[nw+l.right])-Exact(rounded[nw+l.left]-rounded[nw+l.right]))));(void)actual;}
   int negative=0;for(std::size_t g=0;g<ng;++g){maxRoundedMassError=std::max(maxRoundedMassError,H(abs(roundedMass[g]-s.mass[g])));if(roundedMass[g]<0)++negative;}
   std::cout<<"REFERENCE_PASS minMass="<<minimumMass<<" minVolume="<<minimumVolume<<" maxRoundedMassError="<<maxRoundedMassError<<" roundedNegative="<<negative<<" pressureDifferenceLoss="<<maxPressureDiff<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<std::endl;return 0;
  }
  std::vector<std::vector<H>> matrix(n,std::vector<H>(n+1));
  for(auto& r:water.regions){auto m=r.response.free.size();for(std::size_t a=0;a<m;++a)for(std::size_t b=0;b<m;++b){auto oa=r.owners[r.response.free[a]],ob=r.owners[r.response.free[b]];auto i=oa.shared!=SIZE_MAX?oa.shared:nw+oa.gas,j=ob.shared!=SIZE_MAX?ob.shared:nw+ob.gas;matrix[i][j]+=dt*dt*Exact(r.response.mobility[a*m+b]);}}
  for(std::size_t g=0;g<ng;++g)matrix[nw+g][nw+g]+=s.mass[g]*c/(s.density[g]*s.density[g]);
  for(auto l:gas.links){auto a=nw+l.left,b=nw+l.right;H ka=dt*H(l.massConductance)/s.density[l.left],kb=dt*H(l.massConductance)/s.density[l.right];matrix[a][a]+=ka;matrix[a][b]-=ka;matrix[b][b]+=kb;matrix[b][a]-=kb;}
  for(auto v:gas.vents)matrix[nw+v.node][nw+v.node]+=dt*H(v.massConductance)/s.density[v.node];
  for(std::size_t i=0;i<n;++i)matrix[i][n]=-s.rows[i];
  for(std::size_t a=0;a<n;++a){std::size_t pivot=a;for(std::size_t b=a+1;b<n;++b)if(abs(matrix[b][a])>abs(matrix[pivot][a]))pivot=b;std::swap(matrix[a],matrix[pivot]);if(matrix[a][a]==0){std::cerr<<"singular reference";return 5;}for(std::size_t b=a+1;b<n;++b){H ratio=matrix[b][a]/matrix[a][a];for(std::size_t j=a+1;j<=n;++j)matrix[b][j]-=ratio*matrix[a][j];matrix[b][a]=0;}}
  std::vector<H> delta(n);for(std::size_t a=n;a-->0;){H v=matrix[a][n];for(std::size_t j=a+1;j<n;++j)v-=matrix[a][j]*delta[j];delta[a]=v/matrix[a][a];}
  H line=1;bool accepted=false;for(int trial=0;trial<160;++trial){auto trialX=x;for(std::size_t i=0;i<n;++i)trialX[i]+=line*delta[i];auto next=evaluate(trialX);if(next.domain&&next.norm<s.norm*(1-H("0.0001")*line)){x=std::move(trialX);accepted=true;break;}line/=2;}
  if(!accepted){std::cerr<<"high precision line search exhausted";return 6;}
 }
 return 7;
}
