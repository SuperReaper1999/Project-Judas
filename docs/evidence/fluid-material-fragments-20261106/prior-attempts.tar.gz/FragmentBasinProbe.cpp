#include "BasinFixture.h"
#include "WaterFragmentFlux.h"
#include "CutOrthogonalField.h"
#include "CutTransparentGrid.h"
#include <chrono>
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <iostream>
using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;
using Real=CutCompensated;
bool BuildFixture(bool rotated, CutSpatialField& field, std::string& error) {
    const auto fixture = Fixture::Authored(rotated);
    CutRegionChart chart;
    CutRegionGeometry geometry;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
        {-.005,-.015,-.005}, {.005,.025,.005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error)) return false;
    CutDynamicState source;
    SeedImport imported;
    if (!WaterByRegion(fixture, chart, geometry, rotated, source.water, imported, error)) return false;
    std::vector<double> gas;
    for (std::size_t i = 0; i < source.water.size(); ++i) {
        gas.push_back(geometry.startCapacity[i] - source.water[i]);
        source.gasMass.push_back(1.2 * gas.back());
    }
    CutConnectedOwners owners;
    if (!BuildCutConnectedOwners(chart, geometry, .125, owners, error)) return false;
    std::vector<CutRegionWaterPlane> planes;
    if (!ReconstructCutRegionPhasePlanes(chart, geometry, 1, source.water, gas, {}, planes, error)) return false;
    auto vent = FullCutRegionGasVent(chart, 1, 1);
    std::vector<CutPhaseBoundary> ports;
    for (std::size_t i = 0; i < chart.regions.size(); ++i)
        if (MeasureCutRegionGasVent(chart.regions[i], geometry.motion, vent, planes[i]).mean > 0.)
            ports.push_back({i,1,1,0.,0.,true});
    return BuildCutSpatialField(chart, geometry, owners, source,
        std::vector<double>(geometry.faces.size()), ports, field, error, false);
}




int main(){std::cout<<std::setprecision(17);for(bool rotated:{false,true}){CutSpatialField original,orthogonal,field;CutOrthogonalRemap remap;CutTransparentGridReport compact;std::string error;
 if(!BuildFixture(rotated,original,error)||!BuildCutOrthogonalField(original,orthogonal,remap,error)||!CoarsenCutTransparentGrid(orthogonal,field,compact,error)){std::cerr<<error;return 2;}
 WaterMaterialState state;WaterFragmentGeometry geometry;WaterGasSettings settings;settings.dt=double(tick);auto start=std::chrono::steady_clock::now();
 bool ok=ImportWaterMaterial(field,{},state,error)&&PrepareWaterFragmentGeometry(field,state,1000.,{0.,-double(gravity),0.},settings,geometry,error);
 std::cout<<"FRAGMENTS rotated="<<rotated<<" ok="<<ok<<" pieces="<<state.fragments.size()<<" water="<<geometry.liquid.regions.size()<<" air="<<geometry.air.volume.size()<<" shared="<<geometry.liquid.sharedFaces<<" interfaces="<<geometry.interfaces.size()<<" importError="<<state.waterImportError.Value()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" error="<<error<<std::endl;
 if(!ok)return 1;
 WaterGasProjectionResult pressure;ok=ProjectWaterGasPressure(geometry.liquid,geometry.air,settings,pressure,error);
 std::cout<<"PRESSURE rotated="<<rotated<<" ok="<<ok<<" ms="<<pressure.elapsedMilliseconds<<" linear="<<pressure.linearApplications<<" error="<<error<<std::endl;if(!ok)return 1;

 WaterFragmentFlux balanced;std::vector<std::pair<std::size_t,Real>> fixed;WaterMaterialState after;bool applied=false;std::vector<Real> mass(state.fragments.size());for(std::size_t g=0;g<geometry.air.nodeCell.size();++g)mass[geometry.air.nodeCell[g]]=pressure.gasMass[g];
 for(int iteration=0;iteration<24;++iteration){start=std::chrono::steady_clock::now();ok=BalanceWaterFragmentFlux(state,geometry,pressure,settings,fixed,balanced,error);std::cout<<"BALANCE rotated="<<rotated<<" iteration="<<iteration<<" ok="<<ok<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" error="<<error<<std::endl;if(!ok)break;
 WaterInterfaceEventReport report;start=std::chrono::steady_clock::now();applied=ApplyWaterInterfaceEvents(field,state,balanced.sweeps,mass,after,report,error);std::cout<<"EVENT_APPLY rotated="<<rotated<<" iteration="<<iteration<<" ok="<<applied<<" pieces="<<after.fragments.size()<<" failed="<<report.failedInterface<<" available="<<report.availableVolume.Value()<<" deltaW="<<report.waterChange.Value()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" error="<<error<<std::endl;
 if(applied)break;
 if(report.failedInterface==SIZE_MAX)break;
 auto f=report.failedInterface;Real amount=Real(balanced.sweeps[f].volume.Value()>0.?1.:-1.)*report.availableVolume;bool found=false;for(auto& v:fixed)if(v.first==f){v.second=amount;found=true;}if(!found)fixed.push_back({f,amount});
 }
 if(!applied)std::cout<<"INTERVAL_REJECTED rotated="<<rotated<<std::endl;
}}
