#include "WaterFragmentAdvance.h"
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace judas::volume_grid;
using R=CutCompensated;
void Write(std::ostream& o,R r){o<<" "<<r.hi<<" "<<r.lo;}
CutSpatialField Columns(){CutSpatialField f;f.chart.layout={{2,1,1},1.};f.parent={0,1};f.chart.regions={{{0.,0.,0.},{1.,1.,1.},0},{{1.,0.,0.},{2.,1.,1.},1}};f.geometry.startCapacity=f.geometry.endCapacity={1.,1.};f.geometry.faces={{0,1,0,{1.,0.,0.},{1.,1.,1.},1.,1.,1.,0.,1.}};f.water={.6,.4};f.gas={1.-.6,1.-.4};f.gasMass={1.2*(1.-.6),1.2*(1.-.4)};f.flux={0.};return f;}
WaterFragmentGeometry captured;WaterGasSettings capturedSettings;bool haveCapture=false;
namespace judas::volume_grid {void CaptureWaterPressure(const WaterFragmentGeometry& g,const WaterGasSettings& s){captured=g;capturedSettings=s;haveCapture=true;}}
int main(int argc,char** argv){if(argc!=2)return 2;auto field=Columns();WaterMaterialState initial,state;std::string error;WaterGasSettings settings;WaterFragmentAdvanceStats stats;
 if(!ImportWaterMaterial(field,{},initial,error)||!AdvanceWaterFragments(field,initial,1000.,{0.,-9.81,0.},settings,state,stats,error)){std::cerr<<error;return 2;}
 settings.trace=true;WaterMaterialState second;bool advanced=AdvanceWaterFragments(field,state,1000.,{0.,-9.81,0.},settings,second,stats,error);
 std::cout<<"SECOND_INTERVAL ok="<<advanced<<" time="<<stats.advancedTime.Value()<<" error="<<error<<"\n";
 if(!haveCapture)return 3;
 auto geometry=std::move(captured);settings=capturedSettings;
 auto& water=geometry.liquid;auto& gas=geometry.air;
 std::ofstream out(argv[1]);out<<std::setprecision(17);
 out<<"HEADER "<<water.sharedFaces<<" "<<gas.volume.size()<<" "<<water.regions.size()<<" "<<settings.dt<<" "<<settings.referencePressure<<" "<<settings.referenceDensity<<"\n";
 for(std::size_t i=0;i<gas.volume.size();++i){out<<"G "<<i;Write(out,gas.volume[i]);Write(out,gas.mass[i]);out<<"\n";}
 for(auto l:gas.links)out<<"L "<<l.left<<" "<<l.right<<" "<<l.massConductance<<"\n";
 for(auto v:gas.vents)out<<"V "<<v.node<<" "<<v.massConductance<<" "<<v.gaugePressure<<"\n";
 for(std::size_t r=0;r<water.regions.size();++r){const auto& region=water.regions[r];const auto& response=region.response;auto m=response.free.size();out<<"W "<<r<<" "<<m<<" "<<response.reference<<"\n";
  for(std::size_t a=0;a<m;++a){auto p=response.free[a];auto owner=region.owners[p];out<<"P "<<a<<" "<<(owner.shared==SIZE_MAX?-1:static_cast<long long>(owner.shared))<<" "<<(owner.gas==SIZE_MAX?-1:static_cast<long long>(owner.gas));Write(out,region.potential[p]);Write(out,response.predictor[a]);for(int d=0;d<3;++d)Write(out,region.patches[p].Offset(d));out<<"\n";}
  for(std::size_t a=0;a<m;++a){out<<"H "<<a;for(std::size_t b=0;b<m;++b)Write(out,response.mobility[a*m+b]);out<<"\n";}
 }
 out.close();settings.trace=true;WaterGasProjectionResult projected;bool ok=ProjectWaterGasPressure(water,gas,settings,projected,error);
 std::cout<<"FROZEN_SECOND_STEP pieces="<<state.fragments.size()<<" shared="<<water.sharedFaces<<" gas="<<gas.volume.size()<<" water="<<water.regions.size()<<" pressure="<<ok<<" error="<<error<<"\n";return 0;
}
