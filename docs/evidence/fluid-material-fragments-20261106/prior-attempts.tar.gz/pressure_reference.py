import sys,decimal,time,json
D=decimal.Decimal
decimal.getcontext().prec=100
zero=D(0)
def val(s): return D.from_float(float(s))
def real(tokens,index): return val(tokens[index])+val(tokens[index+1])
regions=[];gas=[];links=[];vents=[]
for line in open(sys.argv[1],encoding='utf-8'):
 t=line.split()
 if t[0]=='HEADER': nw,ng,nr=map(int,t[1:4]);dt,p0,rho=map(val,t[4:7])
 elif t[0]=='G': gas.append((real(t,2),real(t,4)))
 elif t[0]=='L': links.append((int(t[1]),int(t[2]),val(t[3])))
 elif t[0]=='V': vents.append((int(t[1]),val(t[2]),val(t[3])))
 elif t[0]=='W': regions.append({'m':int(t[2]),'ref':int(t[3]),'patch':[],'H':[]})
 elif t[0]=='P': regions[-1]['patch'].append((int(t[2]),int(t[3]),real(t,4),real(t,6),[real(t,a) for a in (8,10,12)]))
 elif t[0]=='H': regions[-1]['H'].append([real(t,i) for i in range(2,len(t),2)])
n=nw+ng
if n>200: raise RuntimeError(f'Bounded diagnostic reference: {n} unknowns exceeds 200')
print('UNKNOWN',n,'REGIONS',len(regions),'GAS',ng,flush=True)
c=rho/p0
datum=next(p[2] for r in regions for p in r['patch'] if p[1]>=0)
tolerance=[D('1e-14')]*nw+[min(D('1e-14'),D('1e-10')*v) for v,m in gas]
def matrix_zeros(n):return [[zero for _ in range(n)] for _ in range(n)]
# The local flux derivative uses the SAME eliminated divergence row as C++.
water_matrix=matrix_zeros(n)
for r in regions:
 m,ref=r['m'],r['ref'];ids=[p[0] if p[0]>=0 else nw+p[1] for p in r['patch']]
 for a in range(m):
  if a==ref:continue
  for b in range(m):
   if b==ref:continue
   v=dt*dt*r['H'][a][b]
   water_matrix[ids[a]][ids[b]]+=v;water_matrix[ids[a]][ids[ref]]-=v
   water_matrix[ids[ref]][ids[b]]-=v;water_matrix[ids[ref]][ids[ref]]+=v

def evaluate(x):
 rows=[zero]*n;mass=[m for v,m in gas];volume=[v for v,m in gas];density=[c*x[nw+g] for g in range(ng)]
 if min(density)<=0:return None
 for r in regions:
  m,ref=r['m'],r['ref'];patch=r['patch'];q=[zero]*m;h=[]
  for shared,g,potential,predictor,offset in patch:h.append(x[shared] if shared>=0 else x[nw+g]-p0+potential-datum)
  delta=[h[b]-h[ref] for b in range(m)]
  if patch[ref][1]>=0:
   for b in range(m):
    if patch[b][1]>=0:delta[b]=x[nw+patch[b][1]]-x[nw+patch[ref][1]]+D.from_float(1000.*9.81)*(patch[b][4][1]-patch[ref][4][1])
  for a in range(m):
   if a==ref:continue
   q[a]=patch[a][3]-dt*sum((r['H'][a][b]*delta[b] for b in range(m) if b!=ref),zero);q[ref]-=q[a]
  for a,(shared,g,*_) in enumerate(patch):
   if shared>=0:rows[shared]-=dt*q[a]
   else:volume[g]-=dt*q[a]
 for a,b,k in links:
  amount=dt*k*(x[nw+a]-x[nw+b]);mass[a]-=amount;mass[b]+=amount
 for g,k,p in vents:mass[g]-=dt*k*(x[nw+g]-p0-p)
 if min(mass)<=0:return None
 for g in range(ng):rows[nw+g]=volume[g]-mass[g]/density[g]
 merit=sum(((rows[i]/tolerance[i])**2 for i in range(n)),zero)
 return rows,mass,volume,density,merit

def solve(a,b):
 a=[row[:]+[b[i]] for i,row in enumerate(a)]
 for i in range(n):
  p=max(range(i,n),key=lambda j:abs(a[j][i]));a[i],a[p]=a[p],a[i]
  if a[i][i]==0:raise ArithmeticError('singular frozen Jacobian')
  for j in range(i+1,n):
   ratio=a[j][i]/a[i][i]
   for k in range(i+1,n+1):a[j][k]-=ratio*a[i][k]
   a[j][i]=zero
 x=[zero]*n
 for i in reversed(range(n)):x[i]=(a[i][n]-sum((a[i][j]*x[j] for j in range(i+1,n)),zero))/a[i][i]
 return x
x=[zero]*nw+[p0]*ng;seeded=set()
for r in regions:
 for shared,g,potential,predictor,offset in r['patch']:
  if shared>=0 and shared not in seeded:x[shared]=potential-datum;seeded.add(shared)
started=time.monotonic()
for iteration in range(40):
 s=evaluate(x)
 if s is None:raise RuntimeError('reference initial state outside domain')
 rows,mass,volume,density,norm=s
 maximum=max(abs(rows[i])/tolerance[i] for i in range(n))
 print('ITERATION',iteration,'normalized',maximum,'minMass',min(mass),flush=True)
 if maximum<=1:
  if min(volume)<=0:raise RuntimeError('nonpositive physical gas volume')
  rounded=[D.from_float(float(p))+D.from_float(float(p-D.from_float(float(p)))) for p in x]
  rm=[m for v,m in gas]
  for a,b,k in links:
   amount=dt*k*(rounded[nw+a]-rounded[nw+b]);rm[a]-=amount;rm[b]+=amount
  for g,k,p in vents:rm[g]-=dt*k*(rounded[nw+g]-p0-p)
  print('PASS',json.dumps({'seconds':time.monotonic()-started,'minMass':str(min(mass)),'minVolume':str(min(volume)),'roundedNegativeMass':sum(m<0 for m in rm),'maxRoundedMassError':str(max(abs(rm[g]-mass[g]) for g in range(ng)))}),flush=True)
  sys.exit(0)
 jac=[row[:] for row in water_matrix]
 for g in range(ng):jac[nw+g][nw+g]+=mass[g]*c/(density[g]*density[g])
 for a,b,k in links:
  ka,kb=dt*k/density[a],dt*k/density[b]
  jac[nw+a][nw+a]+=ka;jac[nw+a][nw+b]-=ka;jac[nw+b][nw+b]+=kb;jac[nw+b][nw+a]-=kb
 for g,k,p in vents:jac[nw+g][nw+g]+=dt*k/density[g]
 delta=solve(jac,[-v for v in rows]);line=D(1)
 for trial in range(200):
  candidate=[x[i]+line*delta[i] for i in range(n)];next_s=evaluate(candidate)
  if next_s is not None and next_s[-1]<norm*(1-D('0.0001')*line):x=candidate;break
  line/=2
 else:raise RuntimeError('100-digit domain-preserving line search exhausted')
raise RuntimeError('100-digit Newton did not converge in 40 iterations')
