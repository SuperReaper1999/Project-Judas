# Small resident GPU pool: linked storage-block minimum

The initial CI artifact at accepted Experimental source 2cd2f6d5 reproduced locally under software Mesa. No shader, collision tolerance, numerical acceptance rule, or ComputeDevice validation was changed.

## Demonstrated mechanism

The native test compiles and links the **production `GpuDetail::ClearShader()`**, then queries `GL_BUFFER_DATA_SIZE` for its `FreeSlots` shader storage block. Software Mesa reports 16 bytes; the actual NVIDIA driver reports 4 bytes. Before correction the owner allocated exactly `capacity * sizeof(unsigned)` bytes: capacities 1/2/3 allocated 4/8/12 bytes and failed the unchanged linked-block validation on Mesa, while capacity 4 succeeded. The 100,000-slot and 16-slot controls also succeeded, explaining CI's characteristic failure pattern.

The correction rounds the free-stack allocation envelope up to a 16-byte boundary. Its std430 element stride remains four bytes, and its logical capacity, indices, lifecycle and physics are unchanged. The padding is included in the existing allocation budget. Other resident structs were already sized in complete 16-byte blocks.

## Verification

- `mesa-first-red.log`: independently reflected minimum 16; all three undersized capacities fail initialization with the exact linked-block diagnostic; capacity 4 succeeds. Earlier collision controls cascade as in CI. 47 checks / 9 failures. Preserved unchanged.
- `mesa-fixed.log`: all 63 checks pass, including production reflection, actual 1/2/3/4-capacity admission/readback/teardown, all original 100k trajectories, per-view rendering, finite-feature collision and final no-GL-error control.
- `nvidia-fixed.log`: all 63 checks pass; independently reflected minimum 4.
- The corrected production owner and test were compiled without warnings. `fixed-commands.json`, `fixed-source-hashes.json` and individual build logs record the isolated compilation against the current committed engine archive.
- A first manual link mistakenly included the generated ValidationMain wrapper alongside the unrenamed standalone main. `link-first-red.log` preserves that setup-only failure; `first-red-link.json` records its correction, removing the wrapper rather than changing any runtime source.

Commands (run from repository root, desktop access required):

```
timeout --kill-after=5s 90s env LIBGL_ALWAYS_SOFTWARE=1 __GLX_VENDOR_LIBRARY_NAME=mesa SDL_VIDEODRIVER=x11 LP_NUM_THREADS=2 .cache/particles-v2/mesa-minimum/tests-fixed --native
timeout --kill-after=5s 90s .cache/particles-v2/mesa-minimum/tests-fixed --native
```

Root owns the final integrated rebuild, commit and CI rerun. No Windows/Android runtime qualification is inferred from these Linux driver checks.

## Subsequent unexplained integrated NVIDIA failure

A later integrated NVIDIA run failed only the first one-slot admission assertion; the initial test did not print the operation/readback/teardown details, so its mechanism remains unknown. It is **not** classified as fixed or dismissed as a test problem. The preserved parent log is `integrated/nvidia.log`.

The tracked test now prints exact initialization/operation/shutdown errors, readiness, actual and sampled live counts, sample tick, particle identity/age/lifetime and an additional raw slot dump if the original assertion fails. The assertion is unchanged. Three complete diagnostic repeats each passed 63/63 (`nvidia-diagnostic-{0,1,2}.log`). A further bounded 100-cycle stress exercised capacities 1/2/3/4: 400 complete production owner allocate/spawn/readback/shutdown lifecycles from the current integrated archive, with 508/508 checks passing (`small-stress-nvidia.log`). It used no private owner overrides. `SmallStress.cpp`, `small-stress-commands.json` and `small-stress-archive-sha256.txt` preserve that exact experiment. These results establish the tested scope, not an explanation of the original one-off failure.
