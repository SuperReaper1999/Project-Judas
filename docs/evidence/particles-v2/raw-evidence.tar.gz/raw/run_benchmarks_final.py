import os,pathlib,subprocess,json,time,datetime,hashlib
root=pathlib.Path.cwd();out=root/'.cache/particles-v2/measurements-final';out.mkdir(exist_ok=True)
old='.cache/particles-v2/baseline/judas_particles_v2_benchmark';new='build/judas_particles_v2_benchmark'
cases=[('baseline-100k-1',old,'cpu','free',100000,1),('cpu-100k-1',new,'cpu','free',100000,1),('gpu-100k-1',new,'gpu','free',100000,1),('baseline-100k-2',old,'cpu','free',100000,2),('gpu-100k-2',new,'gpu','free',100000,2),('cpu-100k-2',new,'cpu','free',100000,2),('baseline-10k-1',old,'cpu','free',10000,1),('gpu-10k-1',new,'gpu','free',10000,1),('cpu-collision-1k',new,'cpu','collision',1000,1),('gpu-collision-1k',new,'gpu','collision',1000,1),('gpu-collision-100k',new,'gpu','collision',100000,1),('gpu-100k-2-repeat',new,'gpu','free',100000,2),('baseline-100k-2-repeat',old,'cpu','free',100000,2)]
rows=[];env=dict(os.environ,SDL_AUDIODRIVER='dummy')
for name,binary,backend,case,count,views in cases:
 cmd=[binary,'--backend',backend,'--case',case,'--count',str(count),'--views',str(views),'--frames','240','--warmup','60','--require-gpu-timers','--out',str(out/name)]
 row=dict(name=name,argv=cmd,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),binary_sha256=hashlib.file_digest(open(binary,'rb'),'sha256').hexdigest());t=time.monotonic()
 with(out/(name+'.log')).open('w') as log:
  try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=180);row['exit']=r.returncode
  except subprocess.TimeoutExpired:row['exit']='timeout'
 row['seconds']=time.monotonic()-t;rows.append(row);(out/'RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,row['exit'],round(row['seconds'],2),flush=True)
 if row['exit']!=0:break
