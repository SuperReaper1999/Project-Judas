#include "EngineHost.h"
#include "GraphicsApi.h"
#include "particles/GpuParticles.h"
#include "render/GpuParticlePass.h"
#include <chrono>
#include <cstdio>
#include <functional>
#include <glm/gtc/matrix_transform.hpp>

using Clock=std::chrono::steady_clock;
void Phase(unsigned count,const char* name,const std::function<bool()>& action){
 GLuint query=0;glGenQueries(1,&query);glBeginQuery(GL_TIME_ELAPSED,query);
 const auto start=Clock::now();const bool success=action();const auto submitted=Clock::now();glEndQuery(GL_TIME_ELAPSED);glFinish();
 const auto completed=Clock::now();GLuint64 gpu=0;glGetQueryObjectui64v(query,GL_QUERY_RESULT,&gpu);glDeleteQueries(1,&query);
 std::printf("%u,%s,%.6f,%.6f,%.6f,%u,%u\n",count,name,std::chrono::duration<double,std::milli>(submitted-start).count(),std::chrono::duration<double,std::milli>(completed-start).count(),double(gpu)/1e6,success?1u:0u,glGetError());std::fflush(stdout);
}
int main(){
 EngineHost host;std::string error;if(!host.Init("Bounded GPU birth phase probe",64,64,false,error)){std::fprintf(stderr,"%s\n",error.c_str());return 1;}
 std::printf("count,phase,submission_ms,completed_ms,gpu_ms,success,gl_error\n");
 GLuint white=0,fbo=0,colour=0;glGenTextures(1,&white);glBindTexture(GL_TEXTURE_2D,white);const unsigned char pixel[4]={255,255,255,255};glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,1,1,0,GL_RGBA,GL_UNSIGNED_BYTE,pixel);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
 glGenFramebuffers(1,&fbo);glBindFramebuffer(GL_FRAMEBUFFER,fbo);glGenTextures(1,&colour);glBindTexture(GL_TEXTURE_2D,colour);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,64,64,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,colour,0);glViewport(0,0,64,64);glDisable(GL_DEPTH_TEST);glDisable(GL_SCISSOR_TEST);glClearColor(0,0,0,1);glClear(GL_COLOR_BUFFER_BIT);
 JudasRender::GpuParticlePass pass;
 for(auto count:{1000u,10000u,100000u}){
  ParticleEmitterSettings settings;settings.backend=ParticleBackend::Gpu;settings.maxParticles=int(count);settings.lifetime=100;settings.size=settings.endSize=.025f;settings.spread={8,6,8};settings.velocity={0,.05f,0};settings.velocityVariation={.1f,.1f,.1f};
  JudasParticles::GpuParticles pool;
  Phase(count,"initialize",[&]{return pool.Initialize(host.GraphicsCaps(),settings,{},error);});
  JudasParticles::GpuParticleStepInputs input;input.tick=1;
  Phase(count,"empty_step",[&]{return pool.Step(settings,input,nullptr,error);});
  input.spawnCount=1;++input.tick;Phase(count,"warm_one_birth",[&]{return pool.Step(settings,input,nullptr,error);});
  Phase(count,"clear",[&]{return pool.Clear(error);});
  input.spawnCount=count;++input.tick;Phase(count,"full_birth",[&]{return pool.Step(settings,input,nullptr,error);});
  const auto view=glm::lookAt(glm::vec3(0,0,25),glm::vec3(0),glm::vec3(0,1,0));const auto projection=glm::ortho(-10.f,10.f,-10.f,10.f,.1f,100.f);
  Phase(count,"view_sort_only",[&]{return pool.PrepareView(view,projection,true,error);});
  Phase(count,"first_draw_including_sort",[&]{return pass.Draw(pool,view,projection,white,false,false,error);});
  Phase(count,"repeat_draw_including_sort",[&]{return pass.Draw(pool,view,projection,white,false,false,error);});
  Phase(count,"clear_reuse",[&]{return pool.Clear(error);});
  ++input.tick;Phase(count,"repeat_full_birth",[&]{return pool.Step(settings,input,nullptr,error);});
  if(!pool.Shutdown(error)){std::fprintf(stderr,"%s\n",error.c_str());return 1;}
 }
 pass.Shutdown(&error);glBindFramebuffer(GL_FRAMEBUFFER,0);glDeleteFramebuffers(1,&fbo);glDeleteTextures(1,&colour);glDeleteTextures(1,&white);host.Shutdown();
}
