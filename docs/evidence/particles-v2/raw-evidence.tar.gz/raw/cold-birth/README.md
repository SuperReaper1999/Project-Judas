# Resident particle cold-birth allocator diagnosis and correction

The preserved `pre-batch/probe` executable uses the previous production per-birth compare-and-swap free-stack loop. `probe-batch` uses exactly one batch reservation after retirements and before the birth dispatch. `Probe.cpp` separates initialization, empty Step, one birth, full birth, GPU sorting and first/repeated drawing with explicit completion and GPU timer queries. Completion waits are diagnostic only, not added to ordinary updates.

## Mechanism

100,000 birth invocations were contending on one free-count CAS loop. The superlinear cost occurs within the birth Step after an empty-step and one-birth warm-up; repeated full births have the same stall. Sorting and first drawing are separately about 2–3 ms, so neither first-use shader compilation nor GPU sorting explains the 340 ms birth spike.

The replacement uses the existing single-invocation finalize kernel twice: phase zero reserves a disjoint bounded interval `min(requested, freeCount)`, and the subsequent parallel births consume stable index/id pairs without global CAS or per-birth live-count atomics. Phase one publishes counters and recycles only exceptional invalid numeric births after all free-stack readers complete. Existing draw-record storage supplies the bounded invalid-index scratch space; no new per-particle GPU allocation was introduced. Deaths are still processed before birth reservation. Excess requests advance the requested birth-id sequence without overspawning.

## Results and limits

Three process pairs were run serially in alternating order with no concurrent compiler or GPU benchmark. These are phase diagnostic samples, not production whole-frame p95 distributions. `paired/*.csv` are immutable raw rows; `PAIRED-SUMMARY.json` contains all raw sample values, median and worst values.

100,000 full-birth GPU milliseconds: original median 341.589952 / worst 351.334080; batch median 0.080640 / worst 0.081024. Repeated full-birth original median 338.988736 / worst 344.580064; batch median 0.080064 / worst 0.082848. 10,000-birth median 12.976544 to 0.031776; 1,000-birth median 0.367584 to 0.028320. All calls succeeded and all sampled GL errors were zero. Root owns final end-to-end matched benchmarks and SDK integration qualification.

## Negative control and correctness qualification

`batch-first-red.log` and `batch-detailed.log` preserve the first failed strengthened test. All actual resident ids, ages and occupied slots were correct; the reported live count was stale (tick 10 versus requested tick 11) because all three asynchronous staging slots were occupied. The explicit blocking diagnostic/CPU-transition endpoint now retains and drains the latest uncopied bounded event/counter batch, in addition to already queued staging copies. Normal updates remain nonblocking and account overwritten cosmetic records as dropped. Reset now uses the previous finalized record count rather than clipping it against the next step's potentially changed event capacity.

`batch-final-native.log` passes 58/58 controls, including all original collision/trajectory/sidedness/ownership checks plus mixed expiry, saturation, partial reuse, invalid numerical births and slot recovery. The precise newest diagnostic sample tick is checked. `batch-pure.log` passes all six portable/no-context controls. `FINAL-SOURCE-HASHES.json`, `BATCH-BUILD.json` and `BATCH-COMMANDS.json` identify the compiled sources and exact commands. All changed GPU/compute/impact objects were rebuilt before qualification.
