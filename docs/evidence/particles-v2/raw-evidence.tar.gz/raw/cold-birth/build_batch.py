from pathlib import Path
import hashlib,json,shlex,subprocess,time
root=Path.cwd();out=root/'.cache/particles-v2/cold-birth'
template=(root/'.cache/particles-v2/early-collision/commands.txt').read_text().splitlines()
flags=shlex.split(template[0]);flags=flags[:flags.index('-c')]
base=shlex.split(template[2]);libs=base[base.index('-o')+2:]
sources=['src/render/ComputeDevice.cpp','src/particles/ParticleSettings.cpp','src/particles/ParticleImpacts.cpp','src/particles/CollisionSnapshot.cpp','src/particles/GpuParticleCollision.cpp','src/particles/GpuParticleShaders.cpp','src/particles/GpuParticles.cpp','src/render/GpuParticlePass.cpp','tests/GpuParticlesTests.cpp']
objects=[];rows=[];commands=[]
for source in sources:
 obj=out/(Path(source).stem+'-batch.o');objects.append(str(obj));command=[*flags,'-c',str(root/source),'-o',str(obj)];commands.append(command)
 with(out/(Path(source).stem+'-batch.log')).open('w')as log:
  start=time.time();result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 rows.append({'source':source,'sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'exit':result.returncode,'seconds':time.time()-start})
 print(source,result.returncode,flush=True)
 if result.returncode:break
if not result.returncode:
 for name,main in [('probe-batch',str(out/'Probe.cpp')),('gpu-batch-tests',objects[-1])]:
  command=[*flags,*objects[:-1],main,'-o',str(out/name),*libs];commands.append(command)
  with(out/(name+'-link.log')).open('w')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  print(name,result.returncode,flush=True)
  if result.returncode:break
(out/'BATCH-COMMANDS.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'BATCH-BUILD.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(result.returncode)
