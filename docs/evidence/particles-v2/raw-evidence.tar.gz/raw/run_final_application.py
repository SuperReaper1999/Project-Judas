import pathlib,subprocess,json,os
out=pathlib.Path('.cache/particles-v2/application-checkpoint');out.mkdir(exist_ok=True);rows=[]
for mode in ['--write','--read']:
 cmd=['build/judas_particle_workshop_tests',mode,str(out/'cold')]
 with(out/(mode[2:]+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,SDL_AUDIODRIVER='dummy'),timeout=90)
 rows.append(dict(argv=cmd,exit=r.returncode));print(mode,r.returncode,flush=True)
 if r.returncode:break
(out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
