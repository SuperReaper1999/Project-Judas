import pathlib,shutil,tempfile,subprocess,json,os,time,hashlib
repo=pathlib.Path.cwd();work=pathlib.Path(tempfile.mkdtemp(prefix='judas-particles-v2-delivery-'));out=repo/'.cache/particles-v2/delivery-final-source';out.mkdir(exist_ok=True)
sdk=work/'sdk';shutil.copytree(repo/'build/linux-sdk',sdk)
rows=[];env=dict(os.environ,SDL_AUDIODRIVER='dummy',JUDAS_WORLD_STATE='none',XDG_DATA_HOME=str(work/'user'))
empty=work/'empty';empty.mkdir()
def run(name,cmd,extra=None,timeout=90,cwd=None):
 e=dict(env);e.update(extra or {});t=time.monotonic()
 with(out/(name+'.log')).open('w')as f:r=subprocess.run([str(x) for x in cmd],stdout=f,stderr=subprocess.STDOUT,env=e,cwd=cwd or empty,timeout=timeout)
 rows.append(dict(name=name,argv=[str(x) for x in cmd],cwd=str(cwd or empty),exit=r.returncode,seconds=time.monotonic()-t));(out/'RESULTS.json').write_text(json.dumps(dict(work=str(work),rows=rows),indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(name+' failed')
run('verify-relocated-sdk',['python3',repo/'tools/package_sdk.py','verify',sdk])
run('new-project',[sdk/'judas_editor'],dict(JUDAS_EDITOR_AUTOTEST=str(out/'new-project'),JUDAS_EDITOR_AUTOTEST_NEW_PROJECT=str(work/'new-game')))
created=work/'new-game/SDK_First_Game.judasproj'
run('new-project-scripts',[sdk/'judas_script_check',created])
project=work/'consumer';shutil.copytree(sdk/'projects/particle_v2_lab',project)
originals={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (project/'Assets/collision').glob('*.judascollision')}
run('recook-sdk-collision',['python3',project/'Tools/cook_collision.py','--tool',sdk/'judas_collision_cook'])
assert originals=={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (project/'Assets/collision').glob('*.judascollision')},'collision cook is not deterministic'
run('validate-workshop',[sdk/'judas_scene_author','--validate','project',project/'particle_v2_lab.judasproj'])
run('check-workshop-script',[sdk/'judas_script_check',project/'particle_v2_lab.judasproj'])
run('export-workshop',[sdk/'judas_export',project/'particle_v2_lab.judasproj',work/'package',sdk/'judas'])
standalone=work/'relocated'/'SurfaceWorkshop';standalone.parent.mkdir();shutil.move(work/'package',standalone)
shutil.move(project,work/'source-hidden');shutil.move(sdk,work/'sdk-hidden')
runtime=standalone/'judas'
if not runtime.exists():
 candidates=[p for p in standalone.iterdir() if p.is_file() and os.access(p,os.X_OK)];assert len(candidates)==1,candidates;runtime=candidates[0]
script=out/'relocated-smoke.test';script.write_text((work/'source-hidden/Tests/smoke.test').read_text()+'\n')
run('relocated-runtime',[runtime],dict(JUDAS_TEST_SCRIPT=str(script)),timeout=120)
# Keep the deliverable on persistent SSD storage; temporary test roots are evidence only.
final=out/'SurfaceWorkshop-Linux';shutil.copytree(standalone,final)
(out/'DELIVERY.json').write_text(json.dumps(dict(work=str(work),standalone=str(final),created_project=str(created),sdk=str(work/'sdk-hidden'),collision_hashes=originals,checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()),indent=2)+'\n')
