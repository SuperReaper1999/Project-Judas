import pathlib,subprocess,os,time,json
out=pathlib.Path('.cache/particles-v2/regressions-checkpoint');out.mkdir(exist_ok=True)
cases=[['judas_visual_particle_tests','--output',str(out/'legacy-particles')],['judas_particle_application_tests','--output',str(out/'legacy-game')],['judas_particle_pass_tests','--native'],['judas_compute_infrastructure_tests'],['judas_compute_infrastructure_tests','--portable'],['judas_weather_world_tests'],['judas_weather_render_tests',str(out/'weather'),'--correctness-only'],['judas_script_module_acceptance_tests'],['judas_save_storage_tests'],['judas_mk2_rotation_tests'],['judas_render_pass_state_tests',str(out/'passes')]]
rows=[];env=dict(os.environ,SDL_AUDIODRIVER='dummy')
for i,case in enumerate(cases):
 c=['build/'+case[0],*case[1:]];t=time.monotonic()
 with(out/(str(i)+'-'+case[0]+'.log')).open('w')as f:
  try:r=subprocess.run(c,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=120);code=r.returncode
  except subprocess.TimeoutExpired:code='timeout'
 rows.append(dict(argv=c,exit=code,seconds=time.monotonic()-t));print(case[0],code,flush=True);(out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
