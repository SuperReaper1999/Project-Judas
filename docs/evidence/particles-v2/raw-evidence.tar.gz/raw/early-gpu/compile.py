from pathlib import Path
import hashlib,json,shlex,subprocess,time
root=Path.cwd();out=root/'.cache/particles-v2/early-gpu'
template=(root/'.cache/particles-v2/early-collision/commands.txt').read_text().splitlines()
flags=shlex.split(template[0]);flags=flags[:flags.index('-c')]
link=shlex.split(template[2]);libraries=link[link.index('-o')+2:]
sources=['src/render/ComputeDevice.cpp','src/particles/ParticleSettings.cpp','src/particles/ParticleImpacts.cpp','src/particles/CollisionSnapshot.cpp','src/particles/GpuParticleCollision.cpp','src/particles/GpuParticleShaders.cpp','src/particles/GpuParticles.cpp','src/render/GpuParticlePass.cpp','tests/GpuParticlesTests.cpp']
commands=[];objects=[];rows=[]
prior={r["source"]:r for r in json.loads((out/"RESULTS.json").read_text())} if (out/"RESULTS.json").exists() else {}
for source in sources:
 obj=out/(Path(source).stem+'.o');objects.append(str(obj))
 command=[*flags,'-c',str(root/source),'-o',str(obj)];commands.append(command)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if source in prior and prior[source]['exit']==0 and obj.exists() and prior[source]['sha256']==hashlib.sha256((root/source).read_bytes()).hexdigest():
  rows.append(prior[source]);print(source,'reused unchanged object',flush=True);continue
 with (out/(Path(source).stem+'.log')).open('w') as log:
  started=time.time();result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'source':source,'sha256':hashlib.sha256((root/source).read_bytes()).hexdigest(),'exit':result.returncode,'seconds':time.time()-started})
 (out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(source,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
command=[link[0],'-O3','-DNDEBUG',*objects,'-o',str(out/'gpu_particles_tests'),*libraries]
commands.append(command);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with(out/'link.log').open('w')as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print('link',result.returncode,flush=True)
raise SystemExit(result.returncode)
