#pragma once
#include "ImpactSolver.h"
#include "RigidBody.h"
#include <array>
#include <map>
#include <cmath>

// RESEARCH OVERLAY. Each actual contact feature has one immutable accepted
// solve epoch within the current fixed step. Registering an existing feature
// must NOT refresh its epoch or accept additional accumulated residual.
class StepContactReference {
    using Key=std::array<unsigned,4>;
    struct Point {
        glm::dvec3 anchorA,anchorB,normalA,normalB;
        RigidBody a,b;
        float defect;
    };
    std::map<Key,std::vector<Point>> points;
    static bool Matches(const Point& p,const glm::dvec3& aa,const glm::dvec3& ab,
                        const glm::dvec3& na,const glm::dvec3& nb) {
        return glm::distance(aa,p.anchorA)<.05 && glm::distance(ab,p.anchorB)<.05 &&
               glm::dot(na,p.normalA)>.9 && glm::dot(nb,p.normalB)>.9;
    }
public:
    void Add(const Key& key,const ContactConstraint& c,float dt) {
        if(c.signedSeparation>0)return; // speculative gap-closing is not solve error
        const auto a=ContactRotation(c.bodyA->orientation),b=ContactRotation(c.bodyB->orientation);
        const auto na=glm::transpose(a)*glm::dvec3(c.normal),nb=glm::transpose(b)*glm::dvec3(c.normal);
        auto& group=points[key];
        for(const auto& p:group)
            if(Matches(p,c.localAnchorA,c.localAnchorB,na,nb))return;
        const auto va=c.bodyA->linearVelocity+glm::cross(c.bodyA->angularVelocity,c.velocityOffsetA);
        const auto vb=c.bodyB->linearVelocity+glm::cross(c.bodyB->angularVelocity,c.velocityOffsetB);
        float defect=std::min(glm::dot(va-vb,c.normal),0.f);
        if(!std::isfinite(defect)||!(dt>0)||-double(defect)*dt>ContactSolver::kPenetrationSlop)defect=0;
        // Keep zero-defect records too: a later call cannot adopt a newly
        // introduced error merely because the first accepted state was exact.
        group.push_back({c.localAnchorA,c.localAnchorB,na,nb,*c.bodyA,*c.bodyB,defect});
    }
    float Defect(const Key& key,const ImpactContact& contact,float dt) const {
        const auto found=points.find(key);
        if(found==points.end()||!contact.geometry.hasLocalAnchors)return 0;
        const auto ra=ContactRotation(contact.a->orientation),rb=ContactRotation(contact.b->orientation);
        auto aa=contact.geometry.localAnchorA,ab=contact.geometry.localAnchorB;
        if(contact.geometry.anchorAInWorldFrame)aa=glm::transpose(ra)*aa;
        if(contact.geometry.anchorBInWorldFrame)ab=glm::transpose(rb)*ab;
        const auto na=glm::transpose(ra)*glm::dvec3(contact.geometry.normal);
        const auto nb=glm::transpose(rb)*glm::dvec3(contact.geometry.normal);
        const Point* match=nullptr;double best=.1;
        for(const auto&p:found->second)if(Matches(p,aa,ab,na,nb)) {
            const double distance=glm::distance(aa,p.anchorA)+glm::distance(ab,p.anchorB);
            if(distance<best){best=distance;match=&p;}
        }
        if(!match||match->defect==0)return 0;
        auto velocity=[](const RigidBody& initial,const RigidBody& current,glm::vec3 offset) {
            return initial.linearVelocity+glm::cross(
                TransportAngularVelocity(initial.inverseInertiaLocal,initial.orientation,
                                         current.orientation,initial.angularVelocity),offset);
        };
        const auto va=velocity(match->a,*contact.a,glm::vec3(ra*aa));
        const auto vb=velocity(match->b,*contact.b,glm::vec3(rb*ab));
        const float result=std::max(match->defect,std::min(glm::dot(va-vb,contact.geometry.normal),0.f));
        if(!std::isfinite(result)||!(dt>0)||-double(result)*dt>ContactSolver::kPenetrationSlop)return 0;
        return result;
    }
};
