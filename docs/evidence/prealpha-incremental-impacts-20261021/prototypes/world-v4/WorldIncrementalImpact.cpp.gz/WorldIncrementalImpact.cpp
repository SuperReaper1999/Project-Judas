#include "WorldInternal.h"
#include "WorldIncrementalImpact.h"
#include "StepContactReference.h"
using namespace JudasPhysicsDetail;

bool PhysicsWorld::Impl::TryIncrementalImpact(const std::array<unsigned,4>& selected,
        double now,float dt,const std::vector<unsigned char>& jointBodies,
        const StepContactReference& reference,IncrementalImpact& trial) {
    trial.Reset(bodies.size());
    const auto initialize=[&](unsigned slot) {
        if(trial.initialized[slot])return true;
        const auto& body=bodies[slot];
        if(body.isKinematic || !ContinuationPrimitive(body) || jointBodies[slot])return false;
        trial.initialized[slot]=1;trial.slots.push_back(slot);
        trial.bodies[slot]=trial.incoming[slot]=PoseAt(slot,now);
        trial.original[slot]={body.rigidBody.linearVelocity,trial.incoming[slot].angularVelocity};
        return true;
    };
    const auto pair=[&](unsigned first,unsigned second) {
        const auto key=std::minmax(first,second);
        if(!trial.visited.emplace(key.first,key.second).second)return true;
        auto& a=bodies[key.first];auto& b=bodies[key.second];
        for(int pa=0;pa<PrimitiveCount(a.shape);++pa)for(int pb=0;pb<PrimitiveCount(b.shape);++pb) {
            const auto manifold=PairAt(key.first,key.second,pa,pb,now,0);
            if(manifold.uncertain)return false;
            if(!manifold.count)continue;
            if(!initialize(key.first)||!initialize(key.second))return false;
            trial.pairs.push_back({key.first,key.second,unsigned(pa),unsigned(pb)});
            for(int point=0;point<manifold.count;++point) {
                trial.rows.push_back({&trial.bodies[key.first],&trial.bodies[key.second],
                    manifold.points[point],std::sqrt(std::max(0.f,a.friction)*std::max(0.f,b.friction)),
                    std::max(a.restitution,b.restitution),false});
                trial.keys.push_back({key.first,key.second,a.generation,b.generation,pa,pb});
            }
        }
        return true;
    };
    const auto expand=[&](unsigned slot) {
        if(!initialize(slot))return false;
        if(trial.expanded[slot])return true;
        trial.expanded[slot]=1;
        const auto& body=bodies[slot];
        if(body.isDynamic&&body.deferredAcceleration) {
            trial.incoming[slot].linearVelocity+=body.lastAcceleration*float(dt-now);
            trial.gravityConsumed[slot]=1;
        }
        if(body.rigidBody.IsStatic())return true;
        PhysicsWorkTimer timer(work.impactIslands,work.active);
        const auto& candidates=QuerySlots(ActualImpactBound(slot,ImpactPoseAt(slot,now)));
        for(auto other:candidates) {
            if(other==slot || !CanCollide(slot,other))continue;
            const auto& b=bodies[other];
            if(b.sensor||b.queryOnly||body.sensor||body.queryOnly||
               (body.rigidBody.IsStatic()&&b.rigidBody.IsStatic()))continue;
            // This participant is provisionally awake in the transaction.
            // World sleep flags must not hide its still-sleeping neighbours.
            if(!pair(slot,other))return false;
        }
        return true;
    };
    if(!pair(selected[0],selected[1])||trial.rows.empty()||
       !expand(selected[0])||!expand(selected[1]))return false;
    const auto hasSupport=[&](const auto& p) {
        return (trial.initialized[p[0]]&&!bodies[p[0]].rigidBody.IsStatic()) ||
               (trial.initialized[p[1]]&&!bodies[p[1]].rigidBody.IsStatic());
    };
    trial.capture=std::any_of(supportPairs.begin(),supportPairs.end(),hasSupport)||
                  std::any_of(spinningPairs.begin(),spinningPairs.end(),hasSupport);
    if(trial.rows.size()==1&&!trial.capture&&trial.rows.front().restitution!=0)return false;
    for(;;) {
        ++trial.rounds;
        // Every enlargement restarts the SAME physical event from its immutable
        // incoming state. No trial impulse enters the authoritative world.
        for(auto slot:trial.slots)trial.bodies[slot]=trial.incoming[slot];
        for(std::size_t i=0;i<trial.rows.size();++i) {
            const auto& k=trial.keys[i];
            const std::array<unsigned,4> identity{k.slotA,k.slotB,unsigned(k.partA),unsigned(k.partB)};
            trial.rows[i].normalVelocityDefect=identity==selected?0:reference.Defect(identity,trial.rows[i],dt);
        }
        trial.activated.clear();
        {
            PhysicsWorkTimer timer(work.impactSolve,work.active);
            trial.result=trial.solver.Solve(trial.rows,dt,trial.capture,nullptr,&trial.activated);
        }
        if(!trial.result.energyBudgetSatisfied||trial.result.safetyFallback)return false;
        std::vector<unsigned> next;
        for(auto* body:trial.activated) {
            const auto slot=unsigned(body-trial.bodies.data());
            if(!trial.expanded[slot])next.push_back(slot);
        }
        if(next.empty())return true;
        std::sort(next.begin(),next.end());next.erase(std::unique(next.begin(),next.end()),next.end());
        for(auto slot:next)if(!expand(slot))return false;
        // Each repeat expands at least one new body. There is no island cap,
        // impulse threshold, iteration-budget reduction or discarded contact.
    }
}
