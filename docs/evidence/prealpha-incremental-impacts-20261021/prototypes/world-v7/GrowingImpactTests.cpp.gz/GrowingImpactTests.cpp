#include "ImpactSolver.h"
#include "StepContactReference.h"
#include "RigidBody.h"
#include "third_party/nlohmann/json.hpp"
#include <iostream>
#include <cstring>
#include <algorithm>

namespace {
bool Bits(glm::vec3 a,glm::vec3 b){return !std::memcmp(&a,&b,sizeof(a));}
std::vector<RigidBody> Bodies(unsigned count){std::vector<RigidBody> b(count);for(unsigned i=0;i<count;++i){b[i].position={float(i),0,0};b[i].inverseMass=1;b[i].inverseInertiaLocal=SolidSphereInverseInertia(1,.5f);}return b;}
ImpactContact Row(RigidBody& a,RigidBody& b){Contact c;c.hit=true;c.hasLocalAnchors=true;c.signedSeparation=0;c.penetration=0;c.normal={-1,0,0};c.preciseNormal=c.normal;c.localAnchorA={.5,0,0};c.localAnchorB={-.5,0,0};c.point=(a.position+b.position)*.5f;c.separationState=SeparationState::Touching;return {&a,&b,c,0,0,false};}
}
int main(){unsigned checks=0,failures=0;nlohmann::json details=nlohmann::json::array();auto check=[&](bool condition,const char* name){++checks;if(!condition){++failures;std::cerr<<"FAIL "<<name<<'\n';}};
for(unsigned count:{2u,3u,32u,100u}){
 auto full=Bodies(count),growing=full;full[0].linearVelocity.x=growing[0].linearVelocity.x=1;
 std::vector<ImpactContact> all,front;for(unsigned i=0;i+1<count;++i)all.push_back(Row(full[i],full[i+1]));front.push_back(Row(growing[0],growing[1]));
 std::vector<unsigned char> expanded(count,0);expanded[0]=expanded[1]=1;
 ImpactSolver reference,incremental;const auto original=reference.Solve(all,1.f/60,true);ImpactResult result;
 const auto expand=[&](const std::vector<RigidBody*>& touched){for(auto* body:touched){unsigned i=unsigned(body-growing.data());if(i+1<count&&!expanded[i+1]){front.push_back(Row(growing[i],growing[i+1]));expanded[i+1]=1;}}return true;};
 bool accepted=incremental.SolveGrowing(front,1.f/60,expand,result),equal=true;for(unsigned i=0;i<count;++i)equal&=Bits(full[i].linearVelocity,growing[i].linearVelocity)&&Bits(full[i].angularVelocity,growing[i].angularVelocity);
 check(accepted,"growing chain accepted");check(equal,"appended contacts retain exact full-chain physical solve");check(front.size()==count-1,"no artificial propagation or island cap");check(original.energyBudgetSatisfied&&result.energyBudgetSatisfied,"chain energy guard");
 bool impulseEqual=incremental.Constraints().size()==reference.Constraints().size();if(impulseEqual)for(unsigned i=0;i<front.size();++i)impulseEqual&=incremental.Constraints()[i].normalImpulse==reference.Constraints()[i].normalImpulse;
 check(impulseEqual,"earlier impulses neither discarded nor applied twice");details.push_back({{"chain_bodies",count},{"equal",equal},{"far_velocity",growing.back().linearVelocity.x}});
}
{
 auto b=Bodies(3);b[0].linearVelocity.x=-1;b[2].linearVelocity.x=-.001f;const auto before=b;
 std::vector<ImpactContact> rows{Row(b[0],b[1]),Row(b[1],b[2])};rows[1].continuing=true;
 ImpactSolver s;ImpactResult result;auto nop=[](const auto&){return true;};check(s.SolveGrowing(rows,1.f/60,nop,result),"continuing residual admissible");
 bool unchanged=true;for(unsigned i=0;i<b.size();++i)unchanged&=Bits(b[i].linearVelocity,before[i].linearVelocity)&&Bits(b[i].angularVelocity,before[i].angularVelocity);
 check(unchanged,"zero-effect arrival does not reproject unrelated accepted rest defect");
 check(std::all_of(s.Constraints().begin(),s.Constraints().end(),[](const auto&c){return c.normalImpulse==0;}),"no hidden impact impulse on zero-effect arrival");
 b=before;rows={Row(b[0],b[1]),Row(b[1],b[2])};check(s.SolveGrowing(rows,1.f/60,nop,result),"new small contact accepted");check(b[1].linearVelocity.x<0,"same defect on NEW contact must produce physical response");
 b=Bodies(3);b[0].linearVelocity.x=1;b[2].linearVelocity.x=-1;rows={Row(b[0],b[1]),Row(b[1],b[2])};rows[1].continuing=true;
 check(s.SolveGrowing(rows,1.f/60,nop,result),"large old closure uses strict response");check(std::abs(b[1].linearVelocity.x-b[2].linearVelocity.x)<.00001f,"reject difference-projection 1m/s counterexample without weakening gate");
}
{
 auto b=Bodies(3);b[0].linearVelocity.x=.001f;auto row=Row(b[0],b[1]);ContactSolver c;c.AddContact(*row.a,*row.b,row.geometry,0,0);c.Prepare(0);
 StepContactReference reference;reference.Add({0,1,0,0},c.Constraints()[0],1.f/60);check(reference.Known({0,1,0,0},row),"known actual feature identified");
 auto changed=row;changed.geometry.normal=-row.geometry.normal;changed.geometry.preciseNormal=changed.geometry.normal;check(!reference.Known({0,1,0,0},changed),"opposite feature never inherits continuation");
 changed=row;changed.geometry.localAnchorA.x+=.1;check(!reference.Known({0,1,0,0},changed),"changed anchor never inherits continuation");
 StepContactReference speculative;auto gap=c.Constraints()[0];gap.signedSeparation=.001;speculative.Add({0,1,0,0},gap,1.f/60);check(!speculative.Known({0,1,0,0},row),"speculative gaps are not actual continuing features");
 StepContactReference nextStep;check(!nextStep.Known({0,1,0,0},row),"new fixed step has no stale feature ownership");
}
{
 RigidBody moving,stationary,body;moving.linearVelocity.x=1;body.inverseMass=1;body.inverseInertiaLocal=glm::mat3(0);Contact one;one.hit=true;one.normal={1,0,0};Contact two=one;two.normal={-1,0,0};ContactSolver s;s.AddContact(body,moving,one,0,0);s.AddContact(body,stationary,two,0,0);s.Prepare(0);std::vector<RigidBody*> touched;s.SolveTrackedVelocities(10,touched);
 check(body.linearVelocity==glm::vec3(0),"balanced transient impulse restores final velocity");check(std::find(touched.begin(),touched.end(),&body)!=touched.end(),"activation tracks transient response even when final velocity is unchanged");
}
std::cout<<nlohmann::json{{"checks",checks},{"failures",failures},{"details",details}}.dump(2)<<'\n';return failures?1:0;}
