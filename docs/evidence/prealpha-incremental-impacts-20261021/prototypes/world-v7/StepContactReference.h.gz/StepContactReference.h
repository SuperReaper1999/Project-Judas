#pragma once
#include "ImpactSolver.h"
#include "RigidBody.h"
#include <array>
#include <map>
#include <cmath>

// RESEARCH: step-local physical contact-feature identities only. No historical
// impulse, velocity, error or force is cached/replayed. The current event owns
// its immutable incoming momentum and accepted numerical-defect reference.
class StepContactReference {
    using Key=std::array<unsigned,4>;
    struct Point {glm::dvec3 anchorA,anchorB,normalA,normalB;};
    std::map<Key,std::vector<Point>> points;
    static bool Matches(const Point& p,const glm::dvec3& aa,const glm::dvec3& ab,
                        const glm::dvec3& na,const glm::dvec3& nb) {
        return glm::distance(aa,p.anchorA)<.05 && glm::distance(ab,p.anchorB)<.05 &&
               glm::dot(na,p.normalA)>.9 && glm::dot(nb,p.normalB)>.9;
    }
public:
    void Add(const Key& key,const ContactConstraint& c,float) {
        if(c.signedSeparation>0)return;
        const auto a=ContactRotation(c.bodyA->orientation),b=ContactRotation(c.bodyB->orientation);
        const auto na=glm::transpose(a)*glm::dvec3(c.normal),nb=glm::transpose(b)*glm::dvec3(c.normal);
        auto& group=points[key];
        for(const auto& p:group)if(Matches(p,c.localAnchorA,c.localAnchorB,na,nb))return;
        group.push_back({c.localAnchorA,c.localAnchorB,na,nb});
    }
    bool Known(const Key& key,const ImpactContact& contact) const {
        const auto found=points.find(key);
        if(found==points.end()||!contact.geometry.hasLocalAnchors)return false;
        const auto ra=ContactRotation(contact.a->orientation),rb=ContactRotation(contact.b->orientation);
        auto aa=contact.geometry.localAnchorA,ab=contact.geometry.localAnchorB;
        if(contact.geometry.anchorAInWorldFrame)aa=glm::transpose(ra)*aa;
        if(contact.geometry.anchorBInWorldFrame)ab=glm::transpose(rb)*ab;
        const auto na=glm::transpose(ra)*glm::dvec3(contact.geometry.normal);
        const auto nb=glm::transpose(rb)*glm::dvec3(contact.geometry.normal);
        for(const auto&p:found->second)if(Matches(p,aa,ab,na,nb))return true;
        return false;
    }
};
