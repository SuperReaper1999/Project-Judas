#pragma once
#include "ImpactSolver.h"
#include "RigidBody.h"
#include <array>
#include <map>
#include <cmath>

// RESEARCH OVERLAY. One immutable reference epoch per ordinary fixed-step
// support solve, never re-frozen after a TOI and never serialized or warm-started.
class StepContactReference {
    using Key=std::array<unsigned,4>;
    struct Point {glm::dvec3 anchorA,anchorB,normalA,normalB;};
    std::map<Key,std::vector<Point>> points;
    std::map<const RigidBody*,RigidBody> reference;
public:
    void Add(const Key& key,const ContactConstraint& c) {
        reference.emplace(c.bodyA,*c.bodyA);reference.emplace(c.bodyB,*c.bodyB);
        const auto a=ContactRotation(c.bodyA->orientation),b=ContactRotation(c.bodyB->orientation);
        points[key].push_back({c.localAnchorA,c.localAnchorB,
                              glm::transpose(a)*glm::dvec3(c.normal),
                              glm::transpose(b)*glm::dvec3(c.normal)});
    }
    float Defect(const Key& key,const ImpactContact& contact,float dt) const {
        const auto found=points.find(key);
        if(found==points.end() || !contact.geometry.hasLocalAnchors)return 0;
        const auto ia=reference.find(contact.a),ib=reference.find(contact.b);
        if(ia==reference.end() || ib==reference.end())return 0;
        const auto ra=ContactRotation(contact.a->orientation),rb=ContactRotation(contact.b->orientation);
        auto aa=contact.geometry.localAnchorA,ab=contact.geometry.localAnchorB;
        if(contact.geometry.anchorAInWorldFrame)aa=glm::transpose(ra)*aa;
        if(contact.geometry.anchorBInWorldFrame)ab=glm::transpose(rb)*ab;
        const auto na=glm::transpose(ra)*glm::dvec3(contact.geometry.normal);
        const auto nb=glm::transpose(rb)*glm::dvec3(contact.geometry.normal);
        bool matched=false;
        for(const auto&p:found->second) {
            if(glm::distance(aa,p.anchorA)<.05 && glm::distance(ab,p.anchorB)<.05 &&
               glm::dot(na,p.normalA)>.9 && glm::dot(nb,p.normalB)>.9){matched=true;break;}
        }
        if(!matched)return 0;
        auto velocity=[](const RigidBody& initial,const RigidBody& current,glm::vec3 offset) {
            return initial.linearVelocity + glm::cross(
                TransportAngularVelocity(initial.inverseInertiaLocal,initial.orientation,
                                         current.orientation,initial.angularVelocity),offset);
        };
        const auto va=velocity(ia->second,*contact.a,glm::vec3(ra*aa));
        const auto vb=velocity(ib->second,*contact.b,glm::vec3(rb*ab));
        const float result=std::min(glm::dot(va-vb,contact.geometry.normal),0.f);
        if(!std::isfinite(result) || !(dt>0) || -double(result)*dt>ContactSolver::kPenetrationSlop)return 0;
        return result;
    }
};
