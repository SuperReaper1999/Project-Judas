from pathlib import Path
import shlex,subprocess,json,sys
r=Path.cwd();b=r/'.cache/2d-stage1-build';o=r/'.cache/fluid-continuity-20261102/replay'
flags={}
for line in (b/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
args=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-I'+str(r)]
commands=[]
cmd=args+['-c',str(o/'FrozenReplay.cpp'),'-o',str(o/'FrozenReplay.o')];commands.append(cmd);subprocess.run(cmd,check=True)
link=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());link=[a for a in link if not a.startswith('-Wl,--dependency-file=')];link[link.index('CMakeFiles/judas_production_fluid_tests.dir/tests/ProductionFluidTests.cpp.o')]=str(o/'FrozenReplay.o')
for variant in (['baseline'] if len(sys.argv)==1 else sys.argv[1:]):
 command=link.copy();command[command.index('-o')+1]=str(o/variant)
 if variant!='baseline':
  cmd=args+['-c',str(o/(variant+'.cpp')),'-o',str(o/(variant+'.o'))];commands.append(cmd);subprocess.run(cmd,check=True);command.insert(command.index('libjudas_engine.a'),str(o/(variant+'.o')))
 commands.append(command);subprocess.run(command,cwd=b,check=True)
(o/'BUILD.json').write_text(json.dumps(commands,indent=2)+'\n')
