from pathlib import Path
r=Path.cwd();o=r/'.cache/fluid-continuity-20261102/replay'
s=(r/'src/FluidHydrostatics.cpp').read_text()
rootcuts=r'''        if(solid) {
            const auto addSpan=[&](double lo,double hi){
                if(lo> -halfHeight && lo<halfHeight)cuts.push_back(lo);
                if(hi> -halfHeight && hi<halfHeight)cuts.push_back(hi);
            };
            if(solid->volume.solidSphereRadius>0) {
                const auto delta=glm::dvec3(point)-glm::dvec3(solid->pose.position);
                const double b=glm::dot(delta,up),radius=solid->volume.solidSphereRadius;
                const double discriminant=b*b-glm::dot(delta,delta)+radius*radius;
                if(discriminant>0)addSpan(-b-std::sqrt(discriminant),-b+std::sqrt(discriminant));
            } else for(const auto& box:solid->volume.solidBoxes) {
                const auto inverse=glm::inverse(glm::dquat(solid->pose.rotation)*glm::dquat(box.rotation));
                const auto center=glm::dvec3(solid->pose.position)+glm::dquat(solid->pose.rotation)*glm::dvec3(box.localCenter);
                const auto p=inverse*(glm::dvec3(point)-center),d=inverse*up;
                double lo=-std::numeric_limits<double>::infinity(),hi=-lo;
                for(int k=0;k<3 && lo<=hi;++k) {
                    if(d[k]==0){if(std::abs(p[k])>box.halfExtents[k])hi=lo-1;continue;}
                    double a=(-box.halfExtents[k]-p[k])/d[k],b=(box.halfExtents[k]-p[k])/d[k];if(a>b)std::swap(a,b);
                    lo=std::max(lo,a);hi=std::min(hi,b);
                }
                if(lo<hi)addSpan(lo,hi);
            }
        }
'''
needle='''        std::sort(cuts.begin(),cuts.end());'''
assert s.count(needle)==1
(sout:=o/'root_cuts.cpp').write_text(s.replace(needle,rootcuts+needle))
(o/'point_slices.cpp').write_text(s.replace(needle,rootcuts+needle).replace('bandSolid.emplace(tangent,up,bitangent,columnWidth,bandHalf,*solid);','bandSolid.emplace(tangent,up,bitangent,columnWidth,0,*solid);'))
refine=r'''        const int subdivisions=std::getenv("JUDAS_BAND_SPLITS")?std::atoi(std::getenv("JUDAS_BAND_SPLITS")):1;
        if(subdivisions>1 && subdivisions<=64){
            auto original=cuts;
            for(std::size_t i=1;i<original.size();++i)for(int k=1;k<subdivisions;++k)
                cuts.push_back(original[i-1]+(original[i]-original[i-1])*double(k)/subdivisions);
            std::sort(cuts.begin(),cuts.end());
        }
'''
for name in ['root_cuts','point_slices']:
 text=(o/(name+'.cpp')).read_text().replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>')
 text=text.replace('''        // Keep the fallback integral''',refine+'''        // Keep the fallback integral''')
 (o/(name+'.cpp')).write_text(text)
(o/'bisection.cpp').write_text(s.replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>').replace('''        // Keep the fallback integral''',refine+'''        // Keep the fallback integral'''))
