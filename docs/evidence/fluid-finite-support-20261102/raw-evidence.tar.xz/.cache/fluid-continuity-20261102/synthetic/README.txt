Owner-centre frozen-column diagnostics, 2026-11-02
================================================

These are disposable diagnostics. No tracked production source or test was edited.
OwnerCentreProbe.cpp links the current judas_engine static library using the
recorded compiler flags and link command in COMMANDS.json. This is not an engine
integration or an Advanced Fluid unlock.

Reproduction from repository root:
  python3 - <<'PY'
  import json,subprocess
  for command in json.load(open('.cache/fluid-continuity-20261102/synthetic/COMMANDS.json')):
      subprocess.run(command['argv'],cwd=command['cwd'],check=True)
  PY
  python3 .cache/fluid-continuity-20261102/synthetic/classify.py

The collecting program exits zero when its output was written; classify.py exits
one for the retained known-answer failures. RESULTS.json records each result.
No physical acceptance threshold was weakened or replaced.

Known geometry
--------------
Captured solid is [-.5,.5]^3. Current solid translates upward with its orientation
held fixed. Query is at its current centre, uses half-height .5, and uses the
production volume bound radius. Each fixture is repeated in identity and oblique
global frames. These are direct local-column queries, NOT a claim about exact
whole-solid quadrature.

Bounded wet pocket: pre-cut water occupies [-.25,.25]^3. Captured solid removes
that entire local material field. An identical distant real water patch remains
in both the wet and dry twins; it is outside all local donor searches. Explicit
pre-cut metadata supplies the full known wet domain for the wet twin and only
the distant water for its dry twin. Native material particle arrays are identical.

For current centre y=.5+delta, query column is [delta,1+delta]. The exact local
wet length divided by its unit height is .25-delta for |delta| <= .001. It remains
finite as the centre crosses the captured upper face. Original implementation
reports approximately .25 below the face and exactly zero above it. Dry and
foreign-owner controls remain exactly zero. This holds at shrinking brackets
from .001 to .000001 in both global frames.

Broad reservoir: source water is [-1,1]^3. Cut material omits captured solid.
The positive wet-domain control stays continuous (~1 across the same face).
The explicit dry twin retains a real void [-.5,.5]^3. Correct local-column wet
fraction is ~.5 on both sides. Original implementation instead jumps from ~.5
to ~1 as its retained dry domain ceases to apply above the captured centre face.
The broad foreign-owner result is NOT expected zero: there is genuine nearby
exterior water, and it does not claim ownership of the missing pre-cut domain.

Mechanism and limit
-------------------
FluidBoundaryOwnership.cpp::BoundaryAt (lines56-57 at c27a7ec1) uses the query
centre to decide whether an entire finite-height query may use owned geometry.
When the centre leaves the captured solid, both RetainedFraction and
OwnedIntervals lose the owner, even though the query's finite vertical support
still overlaps. This demonstrates a pre-cut snapshot query inconsistency.

It does NOT establish the cause of the actual half_025 native-marker production
oscillation. Native production uses RetainDisplacementCells, not the full
RetainDisplacedBoundary API used here; its small between-fluid-step motion may
never cross the same centre gate. Root's actual-row probe is separate evidence.
No guard was removed. A correct repair must intersect finite owned support and
preserve dry/foreign-owner/shape/lifecycle safeguards, rather than borrowing an
unrestricted global pre-cut domain.

Preserved failed first assumption
--------------------------------
small-radius-first.csv used radius .25, which is shorter than this solid's
horizontal extent. It showed a false dramatic failure even for the broad wet
control, since local exterior fallback could not reach real surrounding water.
That is NOT a production-radius failure. The final source uses volume.boundRadius
instead. OwnerCentreProbeSmallRadius.cpp reconstructs that exact one-line prior
variant; its first raw log is build-run.log. The first executable was overwritten,
so no exact prior executable hash is claimed. The final executable is hashed.

No performance conclusions are drawn from these runs.
