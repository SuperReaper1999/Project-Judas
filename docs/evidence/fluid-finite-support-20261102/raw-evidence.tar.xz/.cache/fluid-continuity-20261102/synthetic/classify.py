#!/usr/bin/env python3
"""Classify direct finite-height column controls; not a full-body immersion oracle."""
import csv
import json
from pathlib import Path
import sys

base = Path(__file__).resolve().parent
rows = list(csv.DictReader((base / 'owner-centre.csv').open(encoding='utf-8')))
checks, failures = 0, []

def check(ok, row, label, actual, expected):
    global checks
    checks += 1
    if not ok:
        failures.append({'fixture': row['fixture'], 'frame': int(row['frame']),
                         'requested_y': float(row['requested_y']),
                         'label': label, 'actual': actual, 'expected': expected})

for row in rows:
    y = float(row['requested_y'])
    wet, dry, foreign = (float(row[k]) for k in ('wet_fraction', 'dry_fraction', 'foreign_fraction'))
    # Binary32 transformed geometry is admitted within 3e-6 fraction roundoff.
    # No fitted plane, native sampler or required body density enters answers.
    tolerance = 3e-6
    expected = float(row['expected_local_wet_fraction'])
    check(abs(wet - expected) <= tolerance, row, 'known-local-column-wet', wet, expected)
    if row['fixture'] == 'bounded-pocket':
        expected_dry = 0.
        check(foreign == 0., row, 'foreign-owner-cannot-borrow-pocket', foreign, 0.)
    else:
        lo, hi = max(-1., y - .5), min(1., y + .5)
        outer = max(0., hi - lo)
        empty = max(0., min(hi, .5) - max(lo, -.5))
        expected_dry = outer - empty
    check(abs(dry - expected_dry) <= tolerance, row, 'known-local-column-dry-twin', dry, expected_dry)

result = {'schema': 1, 'scope': 'direct finite-height local-column query; not exact whole-OBB immersion',
          'rows': len(rows), 'checks': checks, 'failures': len(failures),
          'failed_checks': failures,
          'expected_status': 'known failure retained; centre gate discards finite overlap',
          'native_production_root_cause': 'not established by this synthetic pre-cut-domain API fixture'}
(base / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(f'{checks} checks, {len(failures)} known failures')
sys.exit(1 if failures else 0)
