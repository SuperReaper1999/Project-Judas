#include "FluidHydrostatics.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <glm/gtc/quaternion.hpp>

namespace {
constexpr float spacing=.0625f;
const BodyHandle owner{37,901},foreign{38,901};
struct Frame {
    glm::quat q{1,0,0,0};
    glm::vec3 t{0};
    glm::vec3 Point(glm::vec3 p)const{return t+q*p;}
    glm::vec3 Vector(glm::vec3 p)const{return q*p;}
};
void Append(std::vector<FluidParticle>& out,glm::vec3 p,const Frame& f) {
    p=f.Point(p);
    out.push_back({p,p,{},1000*spacing*spacing*spacing,{}});
}
struct Fixture {std::vector<FluidParticle> source,cut,dry;};
Fixture Make(bool bounded,const Frame& frame) {
    Fixture f;
    // A distant real water patch ensures nonempty material field while remaining
    // outside every local query. It is identical in wet and dry metadata twins.
    for(int z=0;z<8;++z)for(int y=0;y<8;++y)for(int x=0;x<8;++x) {
        const glm::vec3 p(3+(x+.5f)*spacing,-.25f+(y+.5f)*spacing,
                          -.25f+(z+.5f)*spacing);
        Append(f.source,p,frame);Append(f.cut,p,frame);Append(f.dry,p,frame);
    }
    if(bounded) {
        // Known finite wet pocket with horizontal/vertical faces at +/- .25.
        // The captured body [-.5,.5]^3 removes exactly all of this local matter.
        for(int z=0;z<8;++z)for(int y=0;y<8;++y)for(int x=0;x<8;++x)
            Append(f.source,glm::vec3(-.25f)+glm::vec3(x+.5f,y+.5f,z+.5f)*spacing,frame);
    } else {
        // Broad flat reservoir, matching the original pre-cut ownership style.
        for(int z=0;z<32;++z)for(int y=0;y<32;++y)for(int x=0;x<32;++x) {
            const glm::vec3 p(-1+(x+.5f)*spacing,-1+(y+.5f)*spacing,
                             -1+(z+.5f)*spacing);
            Append(f.source,p,frame);
            if(glm::any(glm::greaterThanEqual(glm::abs(p),glm::vec3(.5f))))
                Append(f.cut,p,frame);
            // Explicit dry twin = same exterior particles but an actual void.
            if(glm::any(glm::greaterThanEqual(glm::abs(p),glm::vec3(.5f))))
                Append(f.dry,p,frame);
        }
    }
    return f;
}
}

int main(int argc,char**argv) {
    if(argc!=2){std::cerr<<"Expected output CSV path\n";return 2;}
    std::ofstream out(argv[1]);
    if(!out)return 2;
    out<<std::setprecision(17)<<"fixture,frame,epsilon,requested_y,actual_local_y,wet_fraction,dry_fraction,foreign_fraction,expected_local_wet_fraction\n";
    const Frame frames[]{Frame{},Frame{glm::angleAxis(.63f,glm::normalize(glm::vec3(1,-2,3))),{1,-2,3}}};
    const auto volume=MakeBoxFluidVolume(glm::vec3(.5f),1);
    for(bool bounded:{false,true})for(int frame=0;frame<2;++frame) {
        const auto& f=frames[frame];
        const auto data=Make(bounded,f);
        FluidHydrostaticField wet,dry;
        wet.Build(data.cut,1000);dry.Build(data.cut,1000);
        const BodyTransform captured{f.Point({}),f.q};
        wet.RetainDisplacedBoundary(owner,volume,captured,data.source);
        dry.RetainDisplacedBoundary(owner,volume,captured,data.dry);
        for(float epsilon:{.001f,.0001f,.00001f,.000001f})for(float side:{-1.f,1.f}) {
            const float y=.5f+side*epsilon;
            const BodyTransform current{f.Point({0,y,0}),f.q};
            const auto up=f.Vector({0,1,0});
            const auto tangent=wet.ReconstructionTangent(up,f.Vector({1,0,0}));
            const FluidSolidQuery own{volume,current,owner},other{volume,current,foreign};
            const auto query=[&](const FluidHydrostaticField& field,const FluidSolidQuery& solid) {
                return field.Query(current.position,up,.5f,.25f,tangent,&solid,true).fraction;
            };
            // Local *vertical column* overlap, not an exact whole-OBB volume.
            // The bounded pocket has uniform interval [-.25,.25] above x=z=0.
            const double bottom=bounded?-.25:-1,top=bounded?.25:1;
            const double expected=std::max(0.,std::min(top,double(y)+.5)-std::max(bottom,double(y)-.5));
            const double actual=glm::dot(glm::dvec3(current.position)-glm::dvec3(f.t),glm::normalize(glm::dvec3(up)));
            out<<(bounded?"bounded-pocket":"broad-pool")<<','<<frame<<','<<epsilon<<','<<y<<','<<actual<<','
               <<query(wet,own)<<','<<query(dry,own)<<','<<query(wet,other)<<','<<expected<<'\n';
        }
    }
    out.close();
    if(!out)return 2;
    std::cout<<"Completed diagnostic; inspect intervals and twin controls. No acceptance assertions substituted.\n";
    return 0;
}
