#include "FluidBoundaryGeometry.h"
#include <iostream>
#include <glm/gtc/quaternion.hpp>

namespace {
int checks=0,failures=0;
void Check(bool value,const char* name) {
    ++checks;if(!value){++failures;std::cout<<"FAIL "<<name<<'\n';}
}
void Span(const std::vector<std::pair<double,double>>& actual,
          std::vector<std::pair<double,double>> expected,double tolerance,const char* name) {
    bool match=actual.size()==expected.size();
    for(std::size_t i=0;i<actual.size()&&match;++i)
        match=std::abs(actual[i].first-expected[i].first)<=tolerance &&
              std::abs(actual[i].second-expected[i].second)<=tolerance;
    Check(match,name);
}
}
int main() {
    using FluidBoundaryDetail::SolidRayIntervals;
    const double infinity=std::numeric_limits<double>::infinity();
    const BodyTransform identity;
    const std::vector<CompoundBox> unit{{{},glm::vec3(1)}};
    const auto box=[&](glm::vec3 p,glm::dvec3 d,double lo=-10,double hi=10) {
        return SolidRayIntervals(p,d,identity,unit,0,lo,hi);
    };
    Span(box({},{0,1,0}),{{-1,1}},0,"box diameter");
    Span(box({0,2,0},{0,1,0}),{{-3,-1}},0,"outside ray points back into box");
    Span(box({2,0,0},{0,1,0}),{},0,"parallel exterior ray");
    Span(box({1,0,0},{0,1,0}),{{-1,1}},0,"parallel boundary ray");
    Span(box({},{0,2,0}),{{-.5,.5}},0,"ray parameter respects nonunit direction");
    Span(box({},{0,1,0},-.25,.5),{{-.25,.5}},0,"query clips exact support");
    Span(box({},{0,1,0},0,0),{{0,0}},0,"zero height inside");
    Span(box({0,2,0},{0,1,0},0,0),{},0,"zero height outside");
    Span(box({},{0,0,0}),{{-10,10}},0,"constant inside ray");
    Span(box({2,0,0},{0,0,0}),{},0,"constant outside ray");
    std::vector<CompoundBox> pair{{{0,-2,0},glm::vec3(.5f)},{{0,2,0},glm::vec3(.5f)}};
    Span(SolidRayIntervals({}, {0,1,0},identity,pair,0,-infinity,infinity),
         {{-2.5,-1.5},{1.5,2.5}},0,"disconnected compound preserves gap");
    std::reverse(pair.begin(),pair.end());
    Span(SolidRayIntervals({}, {0,1,0},identity,pair,0,-infinity,infinity),
         {{-2.5,-1.5},{1.5,2.5}},0,"compound order independent");
    pair={{{0,-.5f,0},glm::vec3(.5f)},{{0,.5f,0},glm::vec3(.5f)}};
    Span(SolidRayIntervals({}, {0,1,0},identity,pair,0,-infinity,infinity),
         {{-1,1}},0,"touching compound union");
    pair={{{0,-.25f,0},glm::vec3(.5f)},{{0,.25f,0},glm::vec3(.5f)}};
    Span(SolidRayIntervals({}, {0,1,0},identity,pair,0,-infinity,infinity),
         {{-.75,.75}},0,"overlapping compound union does not double count");
    const auto sphere=[&](glm::vec3 p,glm::dvec3 d,double lo=-10,double hi=10) {
        return SolidRayIntervals(p,d,identity,{},1,lo,hi);
    };
    Span(sphere({},{0,1,0}),{{-1,1}},0,"sphere diameter");
    const double edge=std::sqrt(.75);
    Span(sphere({.5,0,0},{0,1,0}),{{-edge,edge}},1e-15,"sphere chord");
    Span(sphere({1,0,0},{0,1,0}),{{0,0}},0,"sphere tangency");
    Span(sphere({2,0,0},{0,1,0}),{},0,"sphere misses");
    Span(sphere({0,2,0},{0,1,0}),{{-3,-1}},0,"outside sphere backward interval");
    Span(sphere({0,2,0},{0,-2,0}),{{.5,1.5}},0,"sphere nonunit inward ray");
    Span(sphere({},{0,1,0},.25,.5),{{.25,.5}},0,"sphere query clip");
    Span(sphere({},{0,0,0}),{{-10,10}},0,"constant inside sphere");
    Span(sphere({2,0,0},{0,0,0}),{},0,"constant outside sphere");
    for(float angle:{.2f,.63f,1.4f}) {
        const auto q=glm::angleAxis(angle,glm::normalize(glm::vec3(1,-2,3)));
        const BodyTransform frame{{1,-2,3},q};
        const auto p=frame.position+q*glm::vec3(.25,0,0);
        const auto d=glm::dvec3(q*glm::vec3(0,1,0));
        Span(SolidRayIntervals(p,d,frame,unit,0,-infinity,infinity),
             {{-1,1}},3e-6,"global frame covariance box");
        Span(SolidRayIntervals(frame.position,d,frame,{},1,-infinity,infinity),
             {{-1,1}},3e-6,"global frame covariance sphere");
        CompoundBox child;child.halfExtents=glm::vec3(1);child.rotation=q;
        Span(SolidRayIntervals(q*glm::vec3(.25,0,0),d,identity,{child},0,-infinity,infinity),
             {{-1,1}},3e-6,"child rotation covariance box");
    }
    std::cout<<checks<<" ray geometry checks, "<<failures<<" failures\n";
    return failures?1:0;
}
