Disposable finite-support ownership repair
=========================================

This variant retains matching identity/shape validation, then intersects exact
query-line intervals with BOTH captured and current solid unions. It does not
grant unbounded access to the old wet domain.

For a full-covered query, RetainedFraction takes exactly the old Query path.
For partial support, it integrates pre-cut domain inside owned intervals and
ordinary current material outside. The internal ordinary query keeps current
solid geometry but strips owner identity so it cannot recursively borrow the
same retained domain. Native birth-cell rays use the same support clipping and
select their actual captured connected component separately for each segment.
No damping, fluid settings, budgets or physical acceptance thresholds changed.

Results
-------
owner-centre.csv + classify.py: 80/80 known local-column controls pass, compared
with 16 failures in the preserved baseline one directory above.
ray-tests.log: 32/32 independent exact box/sphere/compound and frame controls pass.
build-run.log: original hydrostatics 217/217 pass with ownership-module override.

expanded-tests.log: 346/346 pass using the final new tests and existing tests.
This link happened after root rebuilt libjudas_engine.a with its separate
solid-entry band correction; it is a combined-library+ownership-override
diagnostic. Root's ordinary final CMake build/tests are authoritative combined
candidate validation. No timing/performance conclusion is drawn here.

Rejected additional native-cell oracle
-------------------------------------
rejected-native-material-union.log retains a new test's original mistaken
expected value .4583333. That model unioned actual material interval
[.40625,.65625] with retained birth interval [.3125,.5625]. The fixture's sole
material donor is occluded by the moved current solid, so its interval does not
contribute ordinary displaced volume. Only the proven birth interval clipped
to captured/current solid [.25,.5] contributes length .1875 in the .75-high query,
giving the corrected exact expectation .25.

The durable test adds a foreign-owner query that must be exactly zero, verifying
that ordinary material is not supplying an unaccounted volume. It also adds
separate negatives for birth geometry outside captured and current solids.
The first mistaken result was preserved; no pre-existing test was changed or
relaxed to obtain a pass.

Changes integrated by this subtask
--------------------------------
src/FluidBoundaryGeometry.h
src/FluidBoundaryOwnership.cpp
tests/FluidFiniteBoundaryChecks.h
tests/FluidHydrostaticsTests.cpp (include and call only; root separately added
its own header/include/call in the same driver)

Commands and hashes
-------------------
COMMANDS.json: initial override module, links and original tests.
RAY_COMMAND.json: analytic standalone helper build.
EXPANDED_COMMANDS.json: final expanded driver compile/link/run.
FINAL_HASHES.json: exact preserved candidate sources/results/binaries.

The independent research trees, main, release channels and Alpha fluid lock
were not modified by this subtask. No commit or push was performed by subtask.
