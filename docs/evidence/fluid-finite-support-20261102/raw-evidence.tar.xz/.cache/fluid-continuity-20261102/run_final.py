from pathlib import Path
import subprocess,json,time,datetime
r=Path.cwd();o=r/'.cache/fluid-continuity-20261102';b=r/'.cache/2d-stage1-build';out=o/'final';out.mkdir(exist_ok=True)
commands=[[str(b/name)] for name in ['judas_fluid_hydrostatics_tests','judas_fluid_vertical_support_tests','judas_fluid_wet_support_tests','judas_fluid_volume_drag_tests','judas_fluid_lifecycle_qualification_tests','judas_project_fluid_policy_tests','judas_project_water_tests','judas_fluid_container_integration_tests']]
commands += [[str(b/'judas_fluid_demo_integration_tests'),'--output',str(out/'demos')],[str(b/'judas_player_fluid_integration_tests'),'--output',str(out/'player')],[str(b/'judas_fluid_known_geometry_tests'),'--output',str(out/'known-geometry.csv')],[str(b/'judas_production_fluid_tests'),'--output',str(out/'production')]]
results=[]
for i,command in enumerate(commands):
 name=Path(command[0]).name;log=out/(name+'.log');t=time.monotonic()
 with log.open('w') as f:p=subprocess.run(command,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 row={'command':command,'cwd':str(r),'exit':p.returncode,'elapsedSeconds':time.monotonic()-t,'log':str(log),'completedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()};results.append(row)
 (out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
