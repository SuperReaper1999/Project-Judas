from pathlib import Path
p=Path('.cache/fluid-continuity-20261102')
s=(p/'ContinuityCoupling.cpp').read_text()
s=s.replace('static std::uint64_t row=0;', 'static std::uint64_t row=0;\n            static BodyTransform previous;\n            static bool havePrevious=false;')
s=s.replace('bfy,field_revision\\n','bfy,field_revision,previous_pose_fraction,previous_center_fraction,previous_rotation_fraction\\n')
s=s.replace("            trace<<row++",'''            auto oldCenter=pose,oldRotation=pose;
            oldCenter.position=previous.position;oldRotation.rotation=previous.rotation;
            const auto replay=[&](const BodyTransform& where){return EvaluateFluidHydrostatics(*field,body.volume,where,world.Gravity(),FluidVolumeGeometry::DisplacedSolid,body.handle).fraction;};
            const double previousPose=havePrevious?replay(previous):hydro.fraction;
            const double previousCenter=havePrevious?replay(oldCenter):hydro.fraction;
            const double previousRotation=havePrevious?replay(oldRotation):hydro.fraction;
            previous=pose;havePrevious=true;
            trace<<row++''')
s=s.replace("<<s.fieldRevision<<'\\n';","<<s.fieldRevision<<','<<previousPose<<','<<previousCenter<<','<<previousRotation<<'\\n';")
(p/'DecompositionCoupling.cpp').write_text(s)
b=(p/'make_probe.py').read_text();b=b[b.index('flags={}'):];b=b.replace("out/'continuity.o'","out/'decomposition.o'").replace("out/'continuity'","out/'decomposition'").replace("out/'BUILD.json'","out/'DECOMPOSITION_BUILD.json'")
exec('import shlex,subprocess,json,hashlib,datetime\nroot=Path.cwd();out=root/p;build=root/".cache/2d-stage1-build";source=out/"DecompositionCoupling.cpp"\n'+b)
