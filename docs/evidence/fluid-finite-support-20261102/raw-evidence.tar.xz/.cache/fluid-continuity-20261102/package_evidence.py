from pathlib import Path
import json,tarfile,hashlib,io,datetime
r=Path.cwd();o=r/'.cache/fluid-continuity-20261102';e=r/'docs/evidence/fluid-finite-support-20261102'
fingerprints=json.loads((e/'SOURCE_FINGERPRINTS.json').read_text());members={}
for p in o.rglob('*'):
 if p.is_file() and p.suffix in {'.json','.csv','.log','.cpp','.h','.py','.txt','.judas','.judasproj','.patch'}:
  members[str(p.relative_to(r))]=p.read_bytes()
for path,sha in fingerprints['files'].items():
 data=(r/path).read_bytes()
 if hashlib.sha256(data).hexdigest()!=sha:raise SystemExit('changed source '+path)
 members['candidate-src/'+path]=data
for path in ['SOURCE_FINGERPRINTS.json','BINARY_FINGERPRINTS.json']:
 members[path]=(e/path).read_bytes()
manifest={'schema':1,'archive':'raw-evidence.tar.xz','memberCount':len(members),'uncompressedBytes':sum(len(v) for v in members.values()),'members':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in sorted(members.items())}}
archive=e/'raw-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for name,data in sorted(members.items()):
  ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(data))
verified=0
with tarfile.open(archive,'r:xz') as t:
 for ti in t:
  expected=manifest['members'][ti.name];data=t.extractfile(ti).read()
  if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:raise SystemExit('bad archive '+ti.name)
  verified+=1
assert verified==len(members)
manifest['archiveBytes']=archive.stat().st_size;manifest['archiveSHA256']=hashlib.sha256(archive.read_bytes()).hexdigest();manifest['verifiedMembers']=verified
(e/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
(e/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(e.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
