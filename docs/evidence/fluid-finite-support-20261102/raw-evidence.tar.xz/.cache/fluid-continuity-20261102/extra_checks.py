from pathlib import Path
import subprocess,json,time,shlex,os,statistics,datetime
r=Path.cwd();o=r/'.cache/fluid-continuity-20261102';b=r/'.cache/2d-stage1-build';results=[]
def run(argv,log,cwd=r):
 t=time.monotonic()
 with log.open('w') as f:p=subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 z={'command':argv,'cwd':str(cwd),'exit':p.returncode,'elapsedSeconds':time.monotonic()-t,'log':str(log)};results.append(z);(o/'EXTRA_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(z),flush=True);return p.returncode
for cmd in json.loads((o/'negative/COMMANDS.json').read_text()):
 if run(cmd['argv'],o/('negative/build-'+str(len(results))+'.log'),Path(cmd['cwd'])):raise SystemExit('negative build failed')
run([str(o/'negative/old-physics-new-controls')],o/'negative/old-physics-new-controls.log')
run([str(b/'judas_fluid_container_integration_tests'),'--supported-only','--output',str(o/'final/containers-supported')],o/'final/containers-supported.log')
flags={}
for line in (b/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines():
 if line.startswith('CXX_') and ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
cmd=['/usr/bin/c++']+sum((flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])+['-I'+str(r),'-c',str(o/'replay/FrozenBench.cpp'),'-o',str(o/'replay/FrozenBench.o')]
if run(cmd,o/'replay/bench-build.log'):raise SystemExit('bench build failed')
base=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());base=[a for a in base if not a.startswith('-Wl,--dependency-file=')];base[base.index('CMakeFiles/judas_production_fluid_tests.dir/tests/ProductionFluidTests.cpp.o')]=str(o/'replay/FrozenBench.o')
for variant in ['before','after']:
 cmd=base.copy();cmd[cmd.index('-o')+1]=str(o/'replay'/('bench-'+variant))
 if variant=='before':
  i=cmd.index('libjudas_engine.a');cmd[i:i]=[str(o/'negative/FluidHydrostatics.o'),str(o/'negative/FluidBoundaryOwnership.o')]
 if run(cmd,o/('replay/bench-link-'+variant+'.log'),b):raise SystemExit('link failed')
raw=[]
for pair in range(7):
 for version in (['before','after'] if pair%2==0 else ['after','before']):
  cmd=[str(o/'replay'/('bench-'+version)),str(o/'frozen.json')];env=dict(os.environ,JUDAS_BENCH_LOOPS='300')
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True);z=json.loads(p.stdout);z.update(pair=pair,version=version,command=cmd);raw.append(z)
  (o/'replay/TIMING_RAW.json').write_text(json.dumps(raw,indent=2)+'\n')
summary={v:{'batches':7,'queriesPerBatch':300,'medianBatchMeanMicroseconds':statistics.median(z['seconds']/z['queries']*1e6 for z in raw if z['version']==v),'minBatchMeanMicroseconds':min(z['seconds']/z['queries']*1e6 for z in raw if z['version']==v),'maxBatchMeanMicroseconds':max(z['seconds']/z['queries']*1e6 for z in raw if z['version']==v),'checksums':sorted(set(z['checksum'] for z in raw if z['version']==v))} for v in ['before','after']}
(o/'replay/TIMING_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
