# Willow Town life expansion — Linux qualification

Experimental continuation of `fcd9b5d9d5f79b6a5179842d6c0771a35c0b2b56`,
1 November 2026. Main and the published engine remain unchanged.

## Implemented

- A persistent six-position job board with actual ownership and vacancies.
- Utility-driven job seeking: travel to the noticeboard, application dwell,
  exclusive vacancy lease and a final ownership check before hiring.
- Dismissal for missed working time, workplace closure and manager action.
- Work output follows the employee's current role, including after changing jobs.
- Sustained hunger/exhaustion health loss, care recovery, injuries and compressed
  town-day aging. Sam starts elderly; Ada starts unemployed.
- Death stops/disables the body, releases employment and leases, disposes the
  native brain and sensing, and preserves a selectable corpse/history.
- Selection shows age, health, employment and job changes. Manager controls can
  pause hiring, dismiss, close workplaces or deliberately injure a resident.
- Version-2 saves preserve this state. A distinct save identity leaves original
  town saves intact; unsupported old state is rejected before native construction.

These are ordinary game-side rules. No engine implementation or public API changed.
The scene, original pixel-art noticeboard, scripts, UI and generators are editable.

## Automated checks before the observation

| Check | Result |
| --- | --- |
| New life application | 147 checks, zero failures |
| Fresh-process life save | 70 checks, zero failures |
| Existing town application, unchanged assertions | 115 checks, zero failures |
| Existing town fresh-process save | 56 checks, zero failures |

The life application uses actual UI input, native decisions and physical arrivals.
It proves hiring rejection despite a real vacancy, resumed hiring, dismissal and
re-hiring, controlled-resident death, replacement into a different role, role-based
output and no post-death rewards. Cold checks compare actual physical endpoints,
job ownership, resident state and living native clocks before and after stepping.

The pure model also checks starvation grace and actual eventual starvation, plus
aging. These isolated controls do not stand in for the requested real-time run.

## Failures preserved and corrected

The first test tried clicking Dismiss in the same frame that fixed gameplay hired
Ada, before the next UI publication. The final test waits for the real enabled
button; it does not force state or weaken employment assertions.

The next native run caught genuine consumer misuse: disabling a corpse made later
kinematic commands invalid. Cleanup and stopping now happen while its body is
still enabled; dead residents receive no subsequent commands, including on load.
Existing native disabling already clears actual velocities and queued movement.
No exception suppression, corpse re-enable or engine patch was needed.

An initial observation smoke used a development executable from an isolated
working directory without its engine fonts. It exited clearly. The successful
smoke and long observation use the complete exported runtime. The observer now
reports early startup failures with a bounded diagnostic log tail.

## Twenty-minute visible observation

Status: the actual 1,200-second observation is in progress. Final measured results
will be added after it finishes; the short adapter smoke is not this qualification.

The observer uses the ordinary visible runtime with no frame harness or timestep
override. Only the copied coordinator's authored startSpeed=3 and observationRun
properties change. A monotonic timer controls the duration. Minute CPU/RSS/PSS
samples, periodic gameplay observations and owned-window screenshots are retained.
F10 pauses the game and requests an ordinary durable save at the end. No other
process, window or original project is closed or modified.

## Human acceptance and limits

Human acceptance of this expansion is pending. Windows, Android and browser
execution are not newly qualified. This is a compressed life game with fixed
population, authored routes, simple jobs and pedestrian passing. There are no
births, newcomers, universal crowd dynamics or automatic save migrations.

Try selecting an unemployed person, pausing/resuming hiring, dismissing an
employee, closing their workplace, changing needs and deliberately injuring a
resident. Check the cause/history after death, then save, quit and reload. The
final observation remains open and paused for inspection when successful.
