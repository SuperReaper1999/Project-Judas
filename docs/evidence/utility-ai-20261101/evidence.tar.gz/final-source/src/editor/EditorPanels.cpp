#include "SpriteSheetEditor.h"
#include "../PowertrainAuthoring.h"
#include "../SaveEvolution.h"
#include "../AssetCook.h"
#include <atomic>
#include "AuthoringDocument.h"
#include "ContentReferences.h"
#include "NamedAuthoring.h"
#include "CollisionAsset.h"
#include "ModelCook.h"
#include "PoseComposition.h"
#include "Project.h"
#include "../SkeletalAnimation.h"
#include "../../third_party/nlohmann/json.hpp"
#include "WorldStreaming.h"
#include "SceneSession.h"
#include "ProfilerView.h"
#include "Environment.h"
#include "ResourceManager.h"
#include "EditorPanels.h"
#include "EditorAssetActions.h"
#include "RenderPreview.h"
#include "RuntimeInspector.h"
#include "RegionRequests.h"
#include "RetargetPanel.h"
#include "Prefab.h"
#include "RuntimeUI.h"
#include "SceneSerialization.h"
#include <filesystem>
#include <set>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdio>
#include <functional>

#include <algorithm>
#include <cstring>

#include <glm/gtc/quaternion.hpp>

#include "imgui.h"
#include "imgui_internal.h"

#include "ComponentEditors.h"
#include "EditorWidgets.h"
#include "EditorCreationMenu.h"
#include "EditorScriptWorkflow.h"
#include "Project.h"
#include "RuntimeWorld.h"

struct AssetCookPanelTask {std::atomic<bool> ready{false};std::string root,source,destination,recipe,error;std::vector<uint8_t> bytes;JobHandle job;};

namespace {
void NextActionOnRow(const char* nextLabel) {
    const float right = ImGui::GetCursorScreenPos().x + ImGui::GetContentRegionAvail().x;
    const float needed = ImGui::CalcTextSize(nextLabel).x + 2 * ImGui::GetStyle().FramePadding.x;
    if (ImGui::GetItemRectMax().x + ImGui::GetStyle().ItemSpacing.x + needed <= right) ImGui::SameLine();
}
constexpr ImGuiWindowFlags kWorkspacePanelFlags = ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
    ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings;

void PlaceWorkspacePanel(const EditorWorkspaceRect& rectangle) {
    ImGui::SetNextWindowPos({rectangle.position.x, rectangle.position.y}, ImGuiCond_Always);
    ImGui::SetNextWindowSize({rectangle.size.x, rectangle.size.y}, ImGuiCond_Always);
}

void ToolbarHint(const char* hint) {
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", hint);
}

// Completion is independent of the visible browser tab. Publication still
// uses the existing project check and occurs only in Edit mode.
void PublishFinishedEditorImport(EditorPanelState& state, EditorRequests& requests) {
    if (!state.importTask || !state.importTask->done.load(std::memory_order_acquire)) return;
    auto& task = *state.importTask;
    if (task.job.IsValid() && state.importJobs && state.importJobs->IsFinished(task.job)) {
        state.importJobs->Forget(task.job);
        task.job = {};
    }
    if (!task.success) {
        if (!state.importPublished) state.status = "Import failed; last good model retained: " + task.error;
        state.importPublished = true;
        return;
    }
    if (state.mode != EditorMode::Edit || state.importPublished) return;
    std::string error;
    const auto relative = std::filesystem::path(task.output).lexically_relative(state.project->RootDir());
    if (relative.empty() || relative.is_absolute() || *relative.begin() == "..") {
        task.cancel = true;
        state.status = "Import belongs to previous project; publication cancelled";
    } else if (PublishModelImport(task, error)) {
        state.importAccepted = state.importTask;
        state.status = task.unchanged ? "Unchanged import; reused accepted model" : "Published complete model; sources retained";
        requests.rescanAssets = true;
        if (state.resources) state.resources->Invalidate(task.assetId);
        state.browserSelection = task.assetId;
    } else state.status = error;
    state.importPublished = true;
}

void WorkspaceSplitter(const char* id, const EditorWorkspaceRect& rectangle, bool vertical, float& dimension,
                       float direction, float minimum, float maximum) {
    if (rectangle.size.x <= 0 || rectangle.size.y <= 0) return;
    PlaceWorkspacePanel(rectangle);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowMinSize, ImVec2(0, 0));
    ImGui::Begin(id, nullptr, kWorkspacePanelFlags | ImGuiWindowFlags_NoTitleBar |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                 ImGuiWindowFlags_NoNavInputs | ImGuiWindowFlags_NoNavFocus);
    ImGui::InvisibleButton("##resize", {rectangle.size.x, rectangle.size.y});
    const bool active = ImGui::IsItemActive();
    if (active || ImGui::IsItemHovered()) {
        ImGui::SetMouseCursor(vertical ? ImGuiMouseCursor_ResizeEW : ImGuiMouseCursor_ResizeNS);
        const auto color = ImGui::GetColorU32(active ? ImGuiCol_SeparatorActive : ImGuiCol_SeparatorHovered);
        ImGui::GetWindowDrawList()->AddRectFilled(ImGui::GetItemRectMin(), ImGui::GetItemRectMax(), color);
    }
    if (active) {
        const auto delta = ImGui::GetIO().MouseDelta;
        dimension = std::clamp(dimension + direction * (vertical ? delta.x : delta.y), minimum, maximum);
    }
    ImGui::End();
    ImGui::PopStyleVar(3);
}

void CopyToBuffer(const std::string& s, char* buffer, std::size_t size) {
    std::strncpy(buffer, s.c_str(), size - 1);
    buffer[size - 1] = '\0';
}

bool ComponentHeader(EditorDocument& doc, const ComponentEditor& editor, SceneObject& o, EditorPanelState& state) {
    ImGui::PushID(editor.name);
    if(state.revealComponent==editor.name){ImGui::SetNextItemOpen(true);state.revealComponent.clear();}
    const bool common = std::string(editor.name)=="Scripts";
    const char* title=std::string(editor.name)=="Render"&&o.render&&o.render->shape==SceneShape::Sprite?"Sprite":editor.name;
    bool open = ImGui::CollapsingHeader(title, common?ImGuiTreeNodeFlags_DefaultOpen:ImGuiTreeNodeFlags_None);
    ImGui::SetItemTooltip("Expand to edit. Right-click for component actions.");
    if(ImGui::BeginPopupContextItem("Component actions")){
        if(ImGui::MenuItem("Remove component")){
            doc.BeginEdit();editor.remove(o);doc.CommitEdit();open=false;
        }
        ImGui::EndPopup();
    }
    ImGui::PopID();
    return open && editor.has(o);
}

void DrawAddComponentMenu(EditorDocument& doc, SceneObject& o, EditorPanelState& state) {
    ImGui::SetNextItemWidth(-1);
    ImGui::SetNextWindowSizeConstraints({260,0},{600,420});
    if (!ImGui::BeginCombo("##add", "Add component...")) return;
    static ImGuiTextFilter filter;
    if(ImGui::IsWindowAppearing()){filter.Clear();ImGui::SetKeyboardFocusHere();}
    filter.Draw("Find component",-1);
    std::vector<const ComponentEditor*> editors;
    for(const auto& editor:ComponentEditorRegistry())editors.push_back(&editor);
    std::sort(editors.begin(),editors.end(),[](const auto* a,const auto* b){return std::strcmp(a->name,b->name)<0;});
    for (const auto* entry : editors) {
        const auto& editor=*entry;
        if (editor.has(o)) continue;
        if(!filter.PassFilter(editor.name))continue;
        if (ImGui::Selectable(editor.name)) {
            doc.BeginEdit();
            editor.add(o);
            doc.CommitEdit();
            state.revealComponent=editor.name;
        }
    }
    ImGui::EndCombo();
}
}  // namespace

void UpdateEditorWorkspaceLayout(EditorPanelState& state, glm::vec2 displaySize) {
    const bool rails = state.mode == EditorMode::Edit || state.playPaused;
    state.workspace = CalculateEditorWorkspaceLayout(displaySize, state.hierarchyWidth, state.inspectorWidth,
        state.assetBrowserHeight, state.showAssetBrowser && state.mode == EditorMode::Edit, rails, ImGui::GetIO().FontGlobalScale);
}

void DrawEditorWorkspaceChrome(EditorDocument& doc, EditorPanelState& state, EditorRequests& requests) {
    const bool editing = state.mode == EditorMode::Edit;
    const auto display = ImGui::GetIO().DisplaySize;
    PlaceWorkspacePanel(state.workspace.toolbar);
    const float uiScale = ImGui::GetIO().FontGlobalScale;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10 * uiScale, 6 * uiScale));
    ImGui::Begin("##workspaceToolbar", nullptr, kWorkspacePanelFlags | ImGuiWindowFlags_NoTitleBar |
                 ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    if (ImGui::Button(editing ? "Play" : "Stop")) {
        if (editing) requests.play = true; else requests.stop = true;
    }
    ToolbarHint("F5: play this scene / restore the authored scene");
    ImGui::SameLine();
    ImGui::BeginDisabled(!editing);
    if (ImGui::Button("Save")) requests.save = true;
    ToolbarHint("Ctrl+S: save the scene");
    ImGui::SameLine();
    if (ImGui::Button("Create...")) ImGui::OpenPopup("toolbarCreate");
    ToolbarHint("Add objects, a first/third-person player, lights or a pause menu");
    if (ImGui::BeginPopup("toolbarCreate")) { DrawEditorCreationItems(state, requests); ImGui::EndPopup(); }
    const float logicalWidth = display.x / std::max(.85f, ImGui::GetIO().FontGlobalScale);
    if (logicalWidth >= 800) {
        ImGui::SameLine();
        ImGui::BeginDisabled(!doc.CanUndo()); if (ImGui::Button("Undo")) requests.undo = true; ImGui::EndDisabled();
        ToolbarHint("Ctrl+Z: undo the last scene edit");
        ImGui::SameLine();
        ImGui::BeginDisabled(!doc.CanRedo()); if (ImGui::Button("Redo")) requests.redo = true; ImGui::EndDisabled();
        ToolbarHint("Ctrl+Y: redo the scene edit");
    }
    ImGui::SameLine();
    if (logicalWidth >= 1000) {
        const auto tool = [&](const char* label, GizmoMode mode, const char* hint) {
            const bool selected = state.gizmoMode == mode;
            if (selected) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
            if (ImGui::Button(label)) state.gizmoMode = mode;
            if (selected) ImGui::PopStyleColor();
            ToolbarHint(hint); ImGui::SameLine();
        };
        tool("Move", GizmoMode::Translate, "W: move selected objects");
        tool("Rotate", GizmoMode::Rotate, "E: rotate selected objects");
        tool("Scale", GizmoMode::Scale, "R: scale selected objects");
    }
    if (ImGui::Button(logicalWidth >= 1000 ? "Options..." : "Transform...")) ImGui::OpenPopup("toolbarTransform");
    ToolbarHint("Transform tools, world/local axes and snapping; W / E / R / X shortcuts remain available");
    if (ImGui::BeginPopup("toolbarTransform")) {
        if (ImGui::MenuItem("Move", "W", state.gizmoMode == GizmoMode::Translate)) state.gizmoMode = GizmoMode::Translate;
        if (ImGui::MenuItem("Rotate", "E", state.gizmoMode == GizmoMode::Rotate)) state.gizmoMode = GizmoMode::Rotate;
        if (ImGui::MenuItem("Scale", "R", state.gizmoMode == GizmoMode::Scale)) state.gizmoMode = GizmoMode::Scale;
        ImGui::Separator();
        if (ImGui::MenuItem("Local axes", "X", state.gizmoSpace == GizmoSpace::Local))
            state.gizmoSpace = state.gizmoSpace == GizmoSpace::Local ? GizmoSpace::World : GizmoSpace::Local;
        ImGui::MenuItem("Snap", "hold Ctrl", &state.gizmoSnap);
        ImGui::EndPopup();
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("View...")) ImGui::OpenPopup("toolbarView");
    ImGui::SameLine();
    ImGui::BeginDisabled(!editing);
    if(ImGui::Button(state.view2D?"2D view":"3D view"))state.view2D=!state.view2D;
    ToolbarHint("Switch the editing view: 2D uses XY, middle-drag pan and wheel zoom. Gameplay cameras are unchanged.");
    ImGui::EndDisabled();
    if (ImGui::BeginPopup("toolbarView")) {
        ImGui::MenuItem("Scene settings", nullptr, &state.showSceneSettings, editing);
        ImGui::MenuItem("Asset Browser", nullptr, &state.showAssetBrowser);
        ImGui::MenuItem("Editor preferences / layouts", nullptr, &state.showEditorPreferences);
        ImGui::MenuItem("Navigation and shortcuts", nullptr, &state.showNavigationHelp);
        ImGui::EndPopup();
    }
    if (logicalWidth >= 1100) {
        ImGui::SameLine(); ImGui::TextDisabled("%s%s", doc.GetScene().Settings().name.c_str(), doc.IsDirty() ? " *" : "");
    }
    ImGui::End();
    ImGui::PopStyleVar();

    if (state.workspace.showRails) {
        WorkspaceSplitter("##hierarchySplitter", state.workspace.leftSplitter, true, state.hierarchyWidth,
                          1.0f, 150.0f, std::max(150.0f, display.x * 0.40f));
        WorkspaceSplitter("##inspectorSplitter", state.workspace.rightSplitter, true, state.inspectorWidth,
                          -1.0f, 220.0f, std::max(220.0f, display.x * 0.46f));
        WorkspaceSplitter("##assetsSplitter", state.workspace.bottomSplitter, false, state.assetBrowserHeight,
                          -1.0f, 80.0f, std::max(80.0f, display.y * 0.55f));
    }
    if (state.showNavigationHelp) {
        ImGui::SetNextWindowSize({440, 340}, ImGuiCond_FirstUseEver);
        if (ImGui::Begin("Editor help", &state.showNavigationHelp)) {
            ImGui::TextUnformatted("SCENE NAVIGATION");
            ImGui::Separator();
            ImGui::TextWrapped("Wheel: zoom in / out. Middle drag: pan. Right drag: look; hold WASD / Q / E to fly. Shift flies faster. F frames selection.");
            ImGui::Spacing();
            ImGui::TextWrapped("Start a camera drag inside the scene view. Release, Escape or leaving the app ends capture.");
            ImGui::Spacing();
            ImGui::TextUnformatted("AUTHORING");
            ImGui::Separator();
            ImGui::TextWrapped("Right-click hierarchy space to create an object, or a row to create a child. Player presets include an editable JavaScript controller and camera; V switches first/third person.");
            ImGui::TextWrapped("Select an object, then use Create script & attach or Attach existing script in the Inspector. Edit script opens its source. Save source and scene before Play.");
            ImGui::TextWrapped("W / E / R: move / rotate / scale. X: local / world axes. Ctrl: snap. Left click selects; Ctrl adds; Shift selects a range in the hierarchy.");
            ImGui::Spacing();
            ImGui::TextWrapped("Ctrl+S: save. Ctrl+Z / Ctrl+Y: undo / redo. Ctrl+D: duplicate. F5: Play / Stop. Drag the dividers to resize this workspace.");
            ImGui::Separator();
            if (ImGui::Button("JudasJS reference")) requests.openJudasJS = true;
            ImGui::SameLine();
            if (ImGui::Button("First project guide")) requests.openQuickStart = true;
            if (ImGui::Button("Ownership, readiness and saves")) requests.openWorkflowGuide = true;
        }
        ImGui::End();
    }
}

void DrawEditorMainMenu(EditorDocument& doc, EditorPanelState& state, EditorRequests& requests) {
    if(!doc.ValidationError().empty())state.status="Edit rejected; previous document restored: "+doc.ValidationError();
    if (!ImGui::BeginMainMenuBar()) return;
    const bool editing = state.mode == EditorMode::Edit;
    const bool hasProject = state.project && state.project->IsLoaded();
    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("New project...", nullptr, false, editing)) requests.newProject = true;
        if (ImGui::MenuItem("Open project...", nullptr, false, editing)) requests.openProject = true;
        if (ImGui::MenuItem("Project settings", nullptr, state.showProjectSettings, hasProject)) {
            state.showProjectSettings = !state.showProjectSettings;
        }
        if (state.experimentalBrowserSupport && ImGui::MenuItem("Export browser game (Experimental)...", nullptr, false, editing && hasProject)) {
            state.showBrowserExport=true;
        }
        ImGui::Separator();
        if (ImGui::MenuItem("New scene", nullptr, false, editing)) requests.newScene = true;
        if (ImGui::MenuItem("Open scene...", nullptr, false, editing)) requests.open = true;
        if (ImGui::MenuItem("Save scene", "Ctrl+S", false, editing)) requests.save = true;
        if (ImGui::MenuItem("Save scene as...", nullptr, false, editing)) requests.saveAs = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Quit")) requests.quit = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        if (ImGui::MenuItem("Undo", "Ctrl+Z", false, editing && doc.CanUndo())) requests.undo = true;
        if (ImGui::MenuItem("Redo", "Ctrl+Y", false, editing && doc.CanRedo())) requests.redo = true;
        ImGui::Separator();
        const bool selected = doc.Selected() != kInvalidSceneObjectId;
        if (ImGui::MenuItem("Duplicate", "Ctrl+D", false, editing && selected)) requests.duplicateId = doc.Selected();
        if (ImGui::MenuItem("Rename", "F2", false, editing && doc.Selection().size() == 1)) BeginEditorRename(doc, state);
        if (ImGui::MenuItem("Focus selection", "F", false, selected)) requests.focusSelection = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Translate gizmo", "W", state.gizmoMode == GizmoMode::Translate)) state.gizmoMode = GizmoMode::Translate;
        if (ImGui::MenuItem("Rotate gizmo", "E", state.gizmoMode == GizmoMode::Rotate)) state.gizmoMode = GizmoMode::Rotate;
        if (ImGui::MenuItem("Scale gizmo", "R", state.gizmoMode == GizmoMode::Scale)) state.gizmoMode = GizmoMode::Scale;
        if (ImGui::MenuItem("Local space", "X", state.gizmoSpace == GizmoSpace::Local)) {
            state.gizmoSpace = state.gizmoSpace == GizmoSpace::Local ? GizmoSpace::World : GizmoSpace::Local;
        }
        ImGui::MenuItem("Snap (hold Ctrl)", nullptr, &state.gizmoSnap);
        ImGui::Separator();
        ImGui::MenuItem("Editor preferences", nullptr, &state.showEditorPreferences);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Create", editing)) {
        DrawEditorCreationItems(state, requests);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("View")) {
        ImGui::MenuItem("Editor preferences (appearance / layouts)", nullptr, &state.showEditorPreferences);
        ImGui::Separator();
        ImGui::MenuItem("Asset Browser", nullptr, &state.showAssetBrowser);
        ImGui::MenuItem("Scene settings", nullptr, &state.showSceneSettings, editing);
        ImGui::MenuItem("JudasJS developer tools", nullptr, &state.showScriptTools);
        ImGui::MenuItem("AI actions and decisions", nullptr, &state.showUtilityAI);
        if (ImGui::BeginMenu("Terrain and world tools")) {
            ImGui::MenuItem("Terrain sculpt / paint", nullptr, &state.showTerrain);
            ImGui::MenuItem("Volumetric terrain - dig / build", nullptr, &state.showVolumeTerrain);
            ImGui::MenuItem("World building / named source", nullptr, &state.showWorldBuilding);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("2D authoring")) {
            ImGui::MenuItem("Tilemap painter",nullptr,&state.showTilemapEditor);
            ImGui::MenuItem("Sprite sheets and frame animation",nullptr,&state.showSpriteSheetEditor);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Animation tools")) {
            ImGui::MenuItem("Animation timeline", nullptr, &state.showAnimationTimeline);
            ImGui::MenuItem("Sprite sheets and frame animation",nullptr,&state.showSpriteSheetEditor);

            ImGui::MenuItem("Animation retargeting", nullptr, &state.showRetarget);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Diagnostics and extensions")) {
            ImGui::MenuItem("Profiler", nullptr, &state.showProfiler);
            ImGui::MenuItem("Runtime Inspector (ownership / readiness / saves)", nullptr, &state.showRuntimeInspector);
            ImGui::MenuItem("Local mods / game kits", nullptr, &state.showMods);
            ImGui::EndMenu();
        }
        ImGui::Separator();
        ImGui::MenuItem("Navigation and shortcuts", nullptr, &state.showNavigationHelp);
        if (ImGui::MenuItem("Check this channel for updates")) requests.checkMilestones = true;
        if (ImGui::MenuItem("JudasJS reference")) requests.openJudasJS = true;
        if (ImGui::MenuItem("Making your first project")) requests.openQuickStart = true;
        if (ImGui::MenuItem("Ownership, readiness and saves guide")) requests.openWorkflowGuide = true;
        if (ImGui::MenuItem("Reset workspace layout")) {
            state.hierarchyWidth = 250; state.inspectorWidth = 340; state.assetBrowserHeight = 200;
            state.showAssetBrowser = true;
        }
        ImGui::Separator();
        ImGui::TextDisabled("Scene navigation (press in the viewport)");
        ImGui::TextUnformatted("Mouse wheel: zoom toward / away from focus");
        ImGui::TextUnformatted("Middle drag: pan in the view plane");
        ImGui::TextUnformatted("Right drag: look; hold WASD / Q / E to fly");
        ImGui::TextUnformatted("Shift: faster flight; F: focus selection");
        ImGui::TextUnformatted("Release or Escape: finish camera drag");
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Debug")) {
        DebugViewOptions& d = state.debug;
        ImGui::MenuItem("Collision shapes", nullptr, &d.collisionShapes);
        ImGui::MenuItem("Player capsule + support", nullptr, &d.playerCapsule);
        ImGui::MenuItem("Contacts", nullptr, &d.contacts);
        ImGui::MenuItem("Gravity vectors + regions", nullptr, &d.gravity);
        ImGui::MenuItem("Frame axes", nullptr, &d.frameAxes);
        ImGui::MenuItem("Lights", nullptr, &d.lights);
        ImGui::MenuItem("Interaction ranges", nullptr, &d.interactionRanges);
        ImGui::MenuItem("Lifecycle / fidelity", nullptr, &d.lifecycle);
        ImGui::MenuItem("Terrain normals (sampled)", nullptr, &d.terrainNormals);
        ImGui::MenuItem("Fluid particles", nullptr, &d.fluidParticles);
        ImGui::MenuItem("Atmosphere radii", nullptr, &d.atmosphere);
        ImGui::MenuItem("Broadphase bounds", nullptr, &d.broadphase);
        ImGui::MenuItem("Navigation mesh / routes", nullptr, &d.navigation);
        ImGui::Separator();
        if (ImGui::MenuItem("All off")) d = DebugViewOptions{};
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("World", !editing)) {
        ImGui::TextDisabled("%s", state.worldStatePath.empty() ? "(no world-state path: save the scene first)"
                                                                : state.worldStatePath.c_str());
        if (ImGui::MenuItem("Save world state", "F6", false, !state.worldStatePath.empty())) requests.saveWorldState = true;
        if (ImGui::MenuItem("Delete world state (pristine baseline next Play)", "F7", false, !state.worldStatePath.empty())) requests.deleteWorldState = true;
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Play")) {
        if (ImGui::MenuItem(editing ? "Play scene" : "Stop", "F5")) {
            if (editing) requests.play = true; else requests.stop = true;
        }
        if (ImGui::MenuItem("Run project", nullptr, false, hasProject && editing)) requests.runProject = true;
        ImGui::EndMenu();
    }
    const char* projectName = hasProject ? state.project->Settings().name.c_str() : "No project";
    const std::string context = std::string(projectName) + "  /  " +
        (editing ? "EDIT" : state.playPaused ? "PLAY PAUSED" : "PLAY");
    const float contextWidth = ImGui::CalcTextSize(context.c_str()).x;
    if (ImGui::GetContentRegionAvail().x > contextWidth + 20) {
        ImGui::SameLine(ImGui::GetWindowWidth() - contextWidth - 14.0f);
        ImGui::TextDisabled("%s", context.c_str());
    }
    ImGui::EndMainMenuBar();
}

void DrawHierarchyPanel(EditorDocument& doc, EditorPanelState& state, EditorRequests& requests) {
    if (!state.workspace.showRails) return;
    PlaceWorkspacePanel(state.workspace.hierarchy);
    if (!ImGui::Begin("Hierarchy", nullptr, kWorkspacePanelFlags)) { ImGui::End(); return; }
    const bool editing = state.mode == EditorMode::Edit;
    Scene& scene = doc.GetScene();
    HandleHierarchyRenameShortcut(doc, state);
    char search[256]; CopyToBuffer(state.hierarchySearch, search, sizeof(search));
    ImGui::SetNextItemWidth(std::max(40.0f, ImGui::GetContentRegionAvail().x - 30.0f));
    if (ImGui::InputTextWithHint("##hierarchySearch", "Search names, tags, folders...", search, sizeof(search)))
        state.hierarchySearch = search;
    ImGui::SameLine();
    if (ImGui::SmallButton("X##clearSearch")) state.hierarchySearch.clear();
    ToolbarHint("Clear hierarchy search");
    ImGui::TextDisabled("%zu objects / %zu selected", scene.Objects().size(), doc.Selection().size());
    ImGui::Separator();
    SceneObjectId toDelete = kInvalidSceneObjectId;
    SceneObjectId reparentTo = kInvalidSceneObjectId;
    bool reparent = false;
    int move = 0;
    SceneObjectId moveId = kInvalidSceneObjectId;
    const float footerWidth = ImGui::CalcTextSize("Create...").x + ImGui::CalcTextSize("Actions").x +
        4 * ImGui::GetStyle().FramePadding.x + ImGui::GetStyle().ItemSpacing.x;
    const float footerRows = footerWidth > ImGui::GetContentRegionAvail().x ? 2.f : 1.f;
    ImGui::BeginChild("list", ImVec2(0.0f, -footerRows * ImGui::GetFrameHeightWithSpacing()));
    auto visible=doc.Search(state.hierarchySearch);
    if(state.project&&!state.hierarchySearch.empty()){std::set<SceneObjectId> matches(visible.begin(),visible.end());for(auto& o:doc.GetScene().Objects())for(auto& [id,name]:state.project->Settings().classification.tags.names)if((o.tags&CategoryBit(id))&&name.find(state.hierarchySearch)!=std::string::npos){matches.insert(o.id);for(auto p=o.parent;p;){matches.insert(p);auto* parent=doc.GetScene().Find(p);p=parent?parent->parent:0;}}visible.assign(matches.begin(),matches.end());}
    for (const SceneObject& o : scene.Objects()) {
        ImGui::PushID(static_cast<int>(o.id));
        const bool selected = doc.IsSelected(o.id);
        if(std::find(visible.begin(),visible.end(),o.id)==visible.end()){ImGui::PopID();continue;}
        if (editing && state.renamingId == o.id) {
            char buffer[256];
            CopyToBuffer(state.renameBuffer, buffer, sizeof(buffer));
            ImGui::SetKeyboardFocusHere();
            if (ImGui::InputText("##rename", buffer, sizeof(buffer), ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_AutoSelectAll)) {
                if (SceneObject* target = scene.Find(o.id)) {
                    doc.BeginEdit();
                    target->name = buffer;
                    doc.CommitEdit();
                }
                state.renamingId = kInvalidSceneObjectId;
            } else {
                state.renameBuffer = buffer;
                if (ImGui::IsItemDeactivated() || ImGui::IsKeyPressed(ImGuiKey_Escape)) state.renamingId = kInvalidSceneObjectId;
            }
            ImGui::PopID();
            continue;
        }
        std::string label = o.name.empty() ? "(unnamed)" : o.name;
        const std::string indicators = ComponentIndicators(o);
        if (state.runtime) {
            if (const EntityRecord* e = state.runtime->FindEntity(o.id)) {
                label += e->lifecycle == EntityLifecycle::Destroyed ? "  [destroyed]"
                                                                     : std::string("  [") + FidelityName(e->fidelity) + "]";
            }
        }
        // Problem indicator: a mesh render whose asset does not resolve.
        bool broken = false;
        if (o.render && o.render->shape == SceneShape::Mesh) {
            const AssetRecord* record = state.assets && !o.render->meshAsset.empty() ? state.assets->Find(o.render->meshAsset) : nullptr;
            broken = !record || record->missing;
        }
        if (broken) label += "  (!)";
        label += "##" + std::to_string(o.id);
        unsigned depth = 0;
        for (auto parent = o.parent; parent && depth < 16; ++depth) {
            const auto* ancestor = scene.Find(parent);
            if (!ancestor) break;
            parent = ancestor->parent;
        }
        const float indentation = float(std::min(depth, 8u)) * 12.0f * ImGui::GetIO().FontGlobalScale;
        if (indentation > 0) ImGui::Indent(indentation);
        if (broken) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.55f, 0.3f, 1.0f));
        if (ImGui::Selectable(label.c_str(), selected, ImGuiSelectableFlags_AllowDoubleClick, {0, ImGui::GetTextLineHeightWithSpacing()})) {
            if(ImGui::GetIO().KeyShift)doc.SelectRange(o.id,visible,ImGui::GetIO().KeyCtrl);else doc.Select(o.id,ImGui::GetIO().KeyCtrl);
            if (editing && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
                state.renamingId = o.id;
                state.renameBuffer = o.name;
            }
        }
        if (broken) ImGui::PopStyleColor();
        if (ImGui::IsItemHovered()) {
            ImGui::BeginTooltip();
            ImGui::TextUnformatted(o.name.empty() ? "(unnamed)" : o.name.c_str());
            ImGui::TextDisabled("ID %llu  /  %s", static_cast<unsigned long long>(o.id),
                               indicators.empty() ? "empty object" : indicators.c_str());
            if (!o.authoringFolder.empty()) ImGui::Text("Folder: %s", o.authoringFolder.c_str());
            if (const auto* parent = scene.Find(o.parent)) ImGui::Text("Parent: %s", parent->name.c_str());
            if (broken) ImGui::TextColored({1, .55f, .3f, 1}, "Mesh asset is missing or unknown");
            ImGui::TextDisabled("Ctrl: add selection   Shift: select range");
            ImGui::EndTooltip();
        }
        if (editing && ImGui::BeginPopupContextItem()) {
            if (!selected) doc.Select(o.id);
            if (ImGui::BeginMenu("Create child")) {
                DrawEditorCreationItems(state, requests, o.id);
                ImGui::EndMenu();
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Focus", "F")) requests.focusSelection = true;
            ImGui::Separator();
            if (ImGui::MenuItem("Rename", "F2", false, doc.Selection().size() == 1)) BeginEditorRename(doc, state);
            if (ImGui::MenuItem("Duplicate")) requests.duplicateId = o.id;
            if (ImGui::BeginMenu("Set parent")) {
                if (ImGui::MenuItem("Scene root")) { reparentTo = 0; reparent = true; }
                ImGui::Separator();
                static ImGuiTextFilter parentFilter;
                if (ImGui::IsWindowAppearing()) parentFilter.Clear();
                parentFilter.Draw("Find parent");
                for (const auto& candidate : scene.Objects()) {
                    if (doc.IsSelected(candidate.id) || !parentFilter.PassFilter(candidate.name.c_str())) continue;
                    ImGui::PushID(static_cast<int>(candidate.id));
                    if (ImGui::MenuItem(candidate.name.c_str())) { reparentTo = candidate.id; reparent = true; }
                    ImGui::PopID();
                }
                ImGui::EndMenu();
            }
            if (ImGui::MenuItem("Move up")) { move = -1; moveId = o.id; }
            if (ImGui::MenuItem("Move down")) { move = 1; moveId = o.id; }
            if (ImGui::MenuItem("Delete")) toDelete = o.id;
            ImGui::EndPopup();
        }
        if (indentation > 0) ImGui::Unindent(indentation);
        ImGui::PopID();
    }
    DrawHierarchyCreationPopup(state, requests);
    ImGui::EndChild();
    if (editing) {
        if (ImGui::Button("Create...")) ImGui::OpenPopup("hierarchyCreate");
        if (ImGui::BeginPopup("hierarchyCreate")) { DrawEditorCreationItems(state, requests); ImGui::EndPopup(); }
        NextActionOnRow("Actions");
        ImGui::BeginDisabled(doc.Selected() == kInvalidSceneObjectId);
        if (ImGui::Button("Actions")) ImGui::OpenPopup("##selectionActions");
        ToolbarHint("Duplicate, group or delete the selection");
        if (ImGui::BeginPopup("##selectionActions")) {
            if (ImGui::MenuItem("Focus selection", "F")) requests.focusSelection = true;
            if (ImGui::MenuItem("Duplicate selection", "Ctrl+D")) { std::string error; if (!doc.DuplicateSelection(error)) state.status = error; }
            if (ImGui::MenuItem("Group in folder")) { std::string error; if (!doc.GroupSelection(error)) state.status = error; }
            if (ImGui::MenuItem("Delete selection", "Delete")) toDelete = doc.Selected();
            ImGui::EndPopup();
        }
        ImGui::EndDisabled();
    }
    DrawHierarchyCreationPopup(state, requests);
    if (reparent) {
        std::string error;
        state.status = doc.ReparentSelection(reparentTo, error) ? "Parent changed; world placement preserved" : "Parent change rejected: " + error;
    }
    if (toDelete != kInvalidSceneObjectId) {std::string error;if(!doc.DeleteSelection(error))state.status="Deletion rejected: "+error;else state.status="Deleted selected hierarchies";}
    if (move != 0) {
        doc.BeginEdit();
        scene.MoveObject(moveId, move);
        doc.CommitEdit();
    }
    ImGui::End();
}

void DrawInspectorPanel(EditorDocument& doc, EditorPanelState& state) {
    if (!state.workspace.showRails) return;
    PlaceWorkspacePanel(state.workspace.inspector);
    if (!ImGui::Begin("Inspector", nullptr, kWorkspacePanelFlags)) { ImGui::End(); return; }
    doc.PruneSelection();
    if(state.mode==EditorMode::Edit&&doc.Selection().size()>1){
        ImGui::Text("%zu selected",doc.Selection().size());static glm::vec3 delta(0),angles(0),factor(1);static bool worldAxes=true,individual=true;
        ImGui::Checkbox("World axes",&worldAxes);ImGui::SameLine();ImGui::Checkbox("Individual origins",&individual);
        ImGui::DragFloat3("Translation delta",&delta.x,.05f);ImGui::DragFloat3("Rotation delta degrees",&angles.x,1);ImGui::DragFloat3("Scale multiplier",&factor.x,.01f);
        if(ImGui::Button("Apply transform delta")){std::string error;if(!doc.BatchTransform(delta,glm::quat(glm::radians(angles)),factor,error,individual,worldAxes))state.status=error;else{delta=angles=glm::vec3(0);factor=glm::vec3(1);}}
        if(ImGui::BeginCombo("Parent all (keep world pose)","Choose parent")){if(ImGui::Selectable("None")){std::string error;if(!doc.ReparentSelection(0,error))state.status=error;}for(auto& p:doc.GetScene().Objects())if(!doc.IsSelected(p.id)&&ImGui::Selectable((p.name+" ##"+std::to_string(p.id)).c_str())){std::string error;if(!doc.ReparentSelection(p.id,error))state.status=error;}ImGui::EndCombo();}
        if(ImGui::CollapsingHeader("Advanced batch properties")){
        auto common=ObjectProperties(*doc.SelectedObject());std::set<std::string> mixed;for(auto id:doc.Selection()){auto properties=ObjectProperties(*doc.GetScene().Find(id));for(auto it=common.begin();it!=common.end();){auto found=properties.find(it->first);if(found==properties.end())it=common.erase(it);else{if(found->second!=it->second)mixed.insert(it->first);++it;}}}
        ImGui::TextWrapped("Common authored fields: mixed values change only after Apply. Values use normal record notation.");
        static std::string field;static char value[2048]{};
        if(ImGui::BeginCombo("Common property",field.c_str())){for(auto& [key,v]:common)if(key!="_name"&&ImGui::Selectable((key+(mixed.count(key)?" (mixed)":"")).c_str(),field==key)){field=key;CopyToBuffer(mixed.count(key)?"":v,value,sizeof(value));}ImGui::EndCombo();}
        ImGui::InputText("New value",value,sizeof(value));if(ImGui::Button("Apply field")&&!field.empty()&&common.count(field)){std::string error;if(!doc.BatchProperties({{field,value}},error))state.status=error;}
        }
    }
    SceneObject* o = doc.SelectedObject();
    if (!o) {
        ImGui::Spacing();
        ImGui::TextUnformatted("Select an object");
        ImGui::TextWrapped("Right-click the hierarchy to create an object, then select it here. Use Add component for capabilities or Create script & attach for gameplay.");
        ImGui::Spacing();
        ImGui::BeginDisabled(state.mode != EditorMode::Edit);
        if (ImGui::Button("Scene settings")) state.showSceneSettings = true;
        ImGui::EndDisabled();
        ImGui::End();
        return;
    }
    if(state.mode==EditorMode::Play)DrawRuntimeRenderPreview(doc,o->id,state);
    if (state.mode == EditorMode::Play) {
        ImGui::TextDisabled("Authored values are read-only while playing.");
        ImGui::BeginDisabled();
    }
    TextField(doc, "Name", o->name);
    DrawTransformEditor(doc, *o);
    if (state.mode == EditorMode::Play && state.runtime) {
        ImGui::EndDisabled();
        if (ImGui::CollapsingHeader("Ownership & readiness")) {
            DrawRuntimeEntity(*state.runtime, o->id);
            if (ImGui::SmallButton("Open Runtime Inspector")) {
                state.runtimeInspectEntity=o->id;state.showRuntimeInspector=true;
            }
        }
        ImGui::BeginDisabled();
    }
    ImGui::SeparatorText("Components");
    DrawAddComponentMenu(doc, *o, state);
    for (const ComponentEditor& editor : ComponentEditorRegistry()) {
        if (!editor.has(*o)) continue;
        if (ComponentHeader(doc, editor, *o, state)) editor.draw(doc, *o, state);
    }
    if (ImGui::CollapsingHeader("Add gameplay script", o->scripts.empty() ? ImGuiTreeNodeFlags_DefaultOpen : ImGuiTreeNodeFlags_None))
        DrawEditorScriptWorkflow(doc, *o, state);
    ImGui::Spacing();
    if(ImGui::CollapsingHeader("Object settings")){
    ImGui::TextDisabled("Object ID: %llu",static_cast<unsigned long long>(o->id));
    Checkbox(doc,"Entity render visible",o->renderVisible);
    if(!o->prefabRoot){
        const auto* parent=doc.GetScene().Find(o->parent);
        ImGui::TextWrapped("Parent (local transform)");
        ImGui::SetNextItemWidth(-1);
        ImGui::PushOverrideID(ImGui::GetID("Parent (local transform)"));
        if(ImGui::BeginCombo("",parent?parent->name.c_str():"None")){
            if(ImGui::Selectable("None",!o->parent)){doc.BeginEdit();o->parent=0;doc.CommitEdit();}
            for(const auto& candidate:doc.GetScene().Objects())if(candidate.id!=o->id&&ImGui::Selectable(candidate.name.c_str(),candidate.id==o->parent)){
                const auto old=o->parent;doc.BeginEdit();o->parent=candidate.id;std::string error;
                if(!ValidateHierarchy(doc.GetScene(),error)){o->parent=old;state.status=error;}doc.CommitEdit();
            }
            ImGui::EndCombo();
        }
        ImGui::PopID();
    }
    if(state.project){const auto& c=state.project->Settings().classification;
        DrawCategoryMask(doc,"Tags",o->tags,c.tags,false);
        if(state.runtime)ImGui::Text("Runtime entities matching these tags: %zu",state.runtime->QueryEntities(o->tags).size());
        DrawCategoryLayer(doc,"Render layer",o->renderLayer,c.render);
    }
    }
    if(state.mode==EditorMode::Edit&&state.project&&state.assets&&ImGui::TreeNode("Prefab tools")){
    if(ImGui::Button("Create prefab from hierarchy")){
        Scene source;std::string error;
        if(CreatePrefab(doc.GetScene(),o->id,source,error)){
            auto path=std::filesystem::path(state.project->AssetsDir())/"prefabs"/("prefab-"+MintAssetId()+".judasprefab");
            std::filesystem::create_directories(path.parent_path());
            if(SaveSceneToFile(source,path.string(),error)){
                auto* db=const_cast<AssetDatabase*>(state.assets);AssetRecord record;
                if(db->Track(path.string(),record,error))state.status="Created prefab asset "+record.id;
            }
        }
        if(!error.empty())state.status=error;
    }
    ImGui::TreePop();
    }
    if(state.mode==EditorMode::Edit&&doc.SelectedObject()&&ImGui::CollapsingHeader("Component clipboard")){
        static int component=0;const char* names[]={"render","body","animation","socket","motor","audio","particle","joint","ragdoll","scripts"};
        ImGui::TextWrapped("Component clipboard");
        ImGui::SetNextItemWidth(-1);
        // Keep the original control identity while its visible label moves
        // above the full-width selector in the narrow inspector rail.
        ImGui::PushOverrideID(ImGui::GetID("Component clipboard"));
        ImGui::Combo("",&component,names,10);
        ImGui::PopID();
        if(ImGui::Button("Copy component"))doc.CopyComponent(names[component]);
        ImGui::SameLine();if(ImGui::Button("Paste to selection")){std::string error;if(!doc.PasteComponent(error))state.status=error;}
    }
    ImGui::Separator();
    if (state.mode == EditorMode::Play) ImGui::EndDisabled();
    if(o->prefabRoot&&ImGui::CollapsingHeader("Prefab instance")){
        const auto* root=doc.GetScene().Find(o->prefabRoot);
        ImGui::Text("Prefab member %llu / instance %llu",(unsigned long long)o->prefabSource,(unsigned long long)o->prefabRoot);
        if(root)ImGui::TextWrapped("Source asset: %s",root->prefabAsset.c_str());
        ImGui::Text("Property overrides: %zu",o->prefabOverrides.size());
        if(state.mode==EditorMode::Edit&&state.assets){
            std::string revert;
            for(const auto& pair:o->prefabOverrides){
                ImGui::PushID(pair.first.c_str());ImGui::TextWrapped("%s = %s",pair.first.c_str(),pair.second.c_str());
                if(ImGui::SmallButton("Revert property"))revert=pair.first;
                ImGui::PopID();
            }
            if(!revert.empty()){
                doc.BeginEdit();std::string error;
                if(!RevertPrefabProperty(doc.GetScene(),o->id,revert,*state.assets,error))state.status=error;
                doc.CommitEdit(false);o=doc.SelectedObject();root=doc.GetScene().Find(o->prefabRoot);
            }
            if(root&&o->id==o->prefabRoot&&ImGui::Button("Apply this hierarchy to prefab source")){
                const auto id=o->id;doc.BeginEdit();std::string error;
                if(!ApplyPrefabSource(doc.GetScene(),id,*state.assets,error))state.status=error;
                else state.status="Saved prefab source; non-overridden instances refreshed";
                doc.CommitEdit(false);o=doc.SelectedObject();root=doc.GetScene().Find(o->prefabRoot);
            }
            if(ImGui::Button("Reload prefab sources")){
                Scene resolved;std::string error;doc.BeginEdit();
                if(ResolvePrefabs(doc.GetScene(),state.assets,resolved,error)){doc.GetScene()=std::move(resolved);state.status="Reloaded prefab sources";}else state.status=error;
                doc.CommitEdit(false);o=doc.SelectedObject();root=doc.GetScene().Find(o->prefabRoot);
            }
        }
        if(state.mode==EditorMode::Play&&state.runtime&&root&&o->id==o->prefabRoot){
            if(ImGui::Button("Spawn independent prefab")){
                std::string error;auto placement=o->transform;placement.position+=glm::vec3(0,2,3);
                const auto id=state.runtime->SpawnPrefab(root->prefabAsset,placement,error);
                state.lastPrefabSpawn=id;
                state.status=id?"Spawned root "+std::to_string(id):error;
            }
            if(state.lastPrefabSpawn&&ImGui::Button("Destroy last spawned hierarchy")){
                std::string error;
                state.status=state.runtime->DestroyHierarchy(state.lastPrefabSpawn,error)?"Destroyed spawned hierarchy":error;
                state.lastPrefabSpawn=0;
            }
        }
    }
    if (state.mode == EditorMode::Play && state.runtime) {
        // Milestone 29: the runtime entity behind the selected object.
        if (ImGui::CollapsingHeader("Runtime diagnostics")) {
            const EntityRecord* e = state.runtime->FindEntity(o->id);
            if (!e) {
                ImGui::TextDisabled("Not a persistent entity (static content or no body).");
            } else {
                ImGui::Text("Persistent id: %llu (%s)", static_cast<unsigned long long>(e->id), e->authored ? "authored" : "runtime-created");
                ImGui::Text("Lifecycle: %s", LifecycleName(e->lifecycle));
                ImGui::Text("Fidelity: %s%s", FidelityName(e->fidelity), e->forcedFidelity ? " (forced)" : "");
                ImGui::Text("Managed by policy: %s | reduced form: %s", e->managed ? "yes" : "no",
                            e->requiresFull ? "none (Full-only)" : "coarse/dormant");
                if (e->fidelity == SimulationFidelity::Coarse) {
                    ImGui::Text("Coarse motion: %s | coarse steps: %llu",
                                e->coarseMotion == CoarseMotion::Settled ? "settled" : "inertial",
                                static_cast<unsigned long long>(e->coarseStepsSimulated));
                }
                ImGui::Text("Reconstructions: %u", e->reconstructions);
                EntityPhysicalState live;
                if (state.runtime->GetEntityState(e->id, live)) {
                    ImGui::Text("Position: %.3f %.3f %.3f", live.position.x, live.position.y, live.position.z);
                    ImGui::Text("Velocity: %.3f %.3f %.3f", live.linearVelocity.x, live.linearVelocity.y, live.linearVelocity.z);
                }
                if (e->lifecycle != EntityLifecycle::Destroyed) {
                    ImGui::TextDisabled("Debug override:");
                    std::string error;
                    if (ImGui::SmallButton("Force Full")) state.runtime->ForceEntityFidelity(e->id, SimulationFidelity::Full, &error);
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Force Coarse")) state.runtime->ForceEntityFidelity(e->id, SimulationFidelity::Coarse, &error);
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Force Dormant")) state.runtime->ForceEntityFidelity(e->id, SimulationFidelity::Dormant, &error);
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Clear")) state.runtime->ForceEntityFidelity(e->id, std::nullopt, &error);
                    if (!error.empty()) state.status = error;
                }
            }
        }
        ImGui::Separator();
    }
    ImGui::End();
}

void DrawSceneSettingsPanel(EditorDocument& doc, EditorPanelState& state) {
    if (!state.showSceneSettings) return;
    const auto display = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowSize({std::min(430.0f, display.x - 40), std::min(540.0f, display.y - 110)}, ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("Scene settings", &state.showSceneSettings)) { ImGui::End(); return; }
    if(state.mode==EditorMode::Play)DrawRuntimeAppearance(doc,state);
    if (state.mode == EditorMode::Play) ImGui::BeginDisabled();
    SceneSettings& s = doc.GetScene().Settings();
    if(state.project)DrawCategoryMask(doc,"Main/editor camera render mask",s.mainCameraRenderMask,state.project->Settings().classification.render);
    TextField(doc, "Name##scene", s.name);
    double origin[3] = {s.worldOrigin.x, s.worldOrigin.y, s.worldOrigin.z};
    if (ImGui::InputScalarN("World origin (m)", ImGuiDataType_Double, origin, 3, nullptr, nullptr, "%.6g")) {
        s.worldOrigin = glm::dvec3(origin[0], origin[1], origin[2]);
    }
    TrackEdit(doc);
    DragVec3(doc, "Sun direction", s.sunDirection, 0.01f);
    ImGui::TextDisabled("World direction toward the sun; independent of gravity and world up.");
    Checkbox(doc,"Sun enabled",s.sunEnabled);
    DragScalar(doc,"Sun intensity",s.sunIntensity,.05f,0,10000);
    ColorEdit(doc, "Sun color", s.sunColor);
    ColorEdit(doc, "Ambient", s.ambientColor);
    Checkbox(doc,"Linear HDR world rendering",s.linearRendering);DragScalar(doc,"Manual exposure",s.exposure,.01f,.001f,10000);
    std::vector<std::string> names,ids;if(state.assets)for(const auto& [id,a]:state.assets->Records())if(a.type==AssetType::Environment){names.push_back(a.relativePath);ids.push_back(id);}LabelledCombo(doc,"Environment lighting",s.environmentAsset,names,ids,true);
    DragScalar(doc,"Environment intensity",s.environmentIntensity,.01f,0,10000);Checkbox(doc,"Environment background",s.environmentBackground);ColorEdit(doc,"Background colour (linear in HDR)",s.backgroundColor);
    auto angles=glm::degrees(glm::eulerAngles(s.environmentRotation));if(ImGui::DragFloat3("Environment rotation degrees",&angles.x,.5f)){doc.BeginEdit();s.environmentRotation=glm::quat(glm::radians(angles));doc.CommitEdit();}
    ImGui::TextDisabled("Background is independent of lighting. Colour factors are linear; UI ignores world exposure.");
    if(!state.project || state.project->Settings().advancedFluidDynamics){
    DragScalar(doc, "Fluid scale", s.fluidScale, 0.1f, 0.01f, 1000.0f);
    DragScalar(doc, "Fluid updates (Hz)", s.fluidUpdateRateHz, 1.0f, 0.1f, 1000.0f);
    DragScalar(doc, "Fluid drag (1/s)", s.fluidHydrostaticDragRate, 0.05f, 0.0f, 1000.0f);
    }else ImGui::TextDisabled("Advanced fluid controls disabled in Project Settings > Experimental.");
    static const char* const kPolicyNames[] = {"none (everything Full)", "distance"};
    Combo(doc, "Fidelity policy", s.fidelityPolicy, kPolicyNames, 2);
    if (s.fidelityPolicy == SceneFidelityPolicy::Distance) {
        DragScalar(doc, "Full radius (m)", s.fidelityFullRadius, 0.5f, 0.0f, 1.0e7f);
        DragScalar(doc, "Coarse radius (m)", s.fidelityCoarseRadius, 0.5f, 0.0f, 1.0e7f);
        ImGui::TextDisabled("Applies to bodies marked 'Managed'.");
    }
    if (state.mode == EditorMode::Play) ImGui::EndDisabled();
    ImGui::End();
}

namespace {
void DrawUILayoutEditor(const AssetRecord& record,EditorPanelState& state){
    static AuthoringDocument document;static UIDocument source;static std::string error;static int selected=0;static bool loaded=false,pending=false;static std::vector<char> text(4*1024*1024+1);static uint64_t textGeneration=~uint64_t(0);static bool sourceDirty=false;static std::set<std::string> selection;static UIElement clipboard;static bool hasClipboard=false;
    auto reloadTyped=[&]{sourceDirty=false;loaded=ParseUIDocument(document.Source(),source,error);selected=0;pending=false;selection.clear();state.uiPreviewDocument=source;++state.uiPreviewRevision;textGeneration=~uint64_t(0);};
    if(document.Path()!=record.path){if(loaded&&(document.Dirty()||pending||sourceDirty)){ImGui::TextWrapped("Unsaved UI %s. Save or discard before opening another document.",document.Path().c_str());if(ImGui::Button("Discard previous UI changes")){loaded=false;pending=false;}return;}loaded=document.Load("ui",record.path,error);if(loaded)reloadTyped();}
    if(!loaded){ImGui::TextWrapped("UI: %s",error.c_str());return;}
    auto flush=[&]{if(!pending)return true;std::string named;if(!LegacyToNamed(SerializeUIDocument(source),"ui",named,error)||!document.Replace(named,error))return false;pending=false;return true;};
    if(!ImGui::BeginTable("UI authoring columns",2,ImGuiTableFlags_Resizable))return;
    ImGui::TableSetupColumn("Properties / source",ImGuiTableColumnFlags_WidthFixed,440);
    ImGui::TableSetupColumn("Canvas",ImGuiTableColumnFlags_WidthStretch);
    ImGui::TableNextColumn();ImGui::BeginChild("UI properties and source",{0,0},true);
    ImGui::Text("%s%s",record.relativePath.c_str(),document.Dirty()||pending?" *":"");
    if(document.ExternalChanged())ImGui::TextColored({1,.6f,.2f,1},"External edit detected; saving is blocked until reviewed reload.");
    if(ImGui::Button("Save UI source")){if(sourceDirty)state.status="Apply or discard the named source draft before saving";else if(flush()&&document.Save(error))state.status="Saved named UI source; restart Play to reload";else state.status=error;}
    ImGui::SameLine();if(ImGui::Button("Reload (discard dirty UI)")){if(document.Load("ui",record.path,error))reloadTyped();}
    ImGui::SameLine();if(ImGui::Button("Undo UI")){if(sourceDirty)state.status="Apply or explicitly discard the named source draft before visual undo";else if(flush()&&document.Undo())reloadTyped();}
    ImGui::SameLine();if(ImGui::Button("Redo UI")){if(sourceDirty)state.status="Apply or explicitly discard the named source draft before visual redo";else if(document.Redo())reloadTyped();}
    if(selected<0||selected>=int(source.elements.size()))selected=0;
    if(!state.uiCanvasSelected.empty()){for(size_t i=0;i<source.elements.size();++i)if(source.elements[i].id==state.uiCanvasSelected)selected=int(i);state.uiCanvasSelected.clear();}
    auto before=SerializeUIDocument(source);
    ImGui::Checkbox("Document visible",&source.visible);ImGui::SameLine();ImGui::Checkbox("Document enabled",&source.enabled);ImGui::Checkbox("Modal (pause gameplay)",&source.modal);
    ImGui::BeginChild("UI hierarchy",{0,130},true);for(size_t i=0;i<source.elements.size();++i){ImGui::PushID(int(i));auto& e=source.elements[i];if(ImGui::Selectable((e.parent.empty()?e.id:e.parent+" / "+e.id).c_str(),selected==int(i)||selection.count(e.id))){selected=int(i);if(!ImGui::GetIO().KeyCtrl)selection.clear();if(selection.count(e.id))selection.erase(e.id);else selection.insert(e.id);}ImGui::PopID();}ImGui::EndChild();
    if(ImGui::Button("Add child panel")){UIElement e;e.id="element_"+std::to_string(source.elements.size()+1);while(std::any_of(source.elements.begin(),source.elements.end(),[&](const auto& x){return x.id==e.id;}))e.id+="_";e.parent=source.elements[selected].id;source.elements.push_back(e);selected=int(source.elements.size())-1;}
    ImGui::SameLine();if(selected&&ImGui::Button("Duplicate subtree")){auto root=source.elements[selected].id;std::set<std::string> members{root};std::map<std::string,std::string> ids;bool more=true;while(more){more=false;for(auto& e:source.elements)if(members.count(e.parent))more|=members.insert(e.id).second;}for(auto& key:members){auto copy=key+"_copy";while(std::any_of(source.elements.begin(),source.elements.end(),[&](const auto& e){return e.id==copy;}))copy+="_";ids[key]=copy;}std::vector<UIElement> copies;for(auto e:source.elements)if(members.count(e.id)){auto id=e.id;e.id=ids.at(id);if(ids.count(e.parent))e.parent=ids.at(e.parent);if(id==root)e.offset+=glm::vec2(12);copies.push_back(e);}source.elements.insert(source.elements.end(),copies.begin(),copies.end());}
    auto& e=source.elements[selected];auto str=[](const char* label,std::string& s){char b[16385];std::snprintf(b,sizeof(b),"%s",s.c_str());if(ImGui::InputText(label,b,sizeof(b)))s=b;};
    ImGui::TextDisabled("Stable ID: %s",e.id.c_str());
    if(selected){if(ImGui::BeginCombo("Parent",e.parent.c_str())){for(auto& parent:source.elements)if(parent.id!=e.id&&ImGui::Selectable(parent.id.c_str(),e.parent==parent.id))e.parent=parent.id;ImGui::EndCombo();}}
    int kind=int(e.kind);if(selected&&ImGui::Combo("Element type",&kind,"Canvas\0Panel\0Text\0Image\0Button\0Slider\0Toggle\0Text input\0Scroll container\0Virtual list\0"))e.kind=UIKind(kind);
    int flow=int(e.flow);if(ImGui::Combo("Child layout",&flow,"Free\0Horizontal\0Vertical\0"))e.flow=UIFlow(flow);
    for(auto& parent:source.elements)if(parent.id==e.parent&&parent.flow!=UIFlow::Free)ImGui::TextWrapped("%s owns this element's %s placement; offsets and margins still contribute.",parent.id.c_str(),parent.flow==UIFlow::Horizontal?"horizontal":"vertical");
    if(auto it=state.uiPreviewLayout.find(e.id);it!=state.uiPreviewLayout.end())ImGui::TextDisabled("Effective rectangle %.1f %.1f / %.1f %.1f px",it->second.rect.position.x,it->second.rect.position.y,it->second.rect.size.x,it->second.rect.size.y);
    ImGui::Checkbox("Visible",&e.visible);ImGui::SameLine();ImGui::Checkbox("Enabled",&e.enabled);ImGui::Checkbox("Clip children",&e.clip);
    ImGui::InputFloat2("Anchor min",&e.anchorMin.x);ImGui::InputFloat2("Anchor max",&e.anchorMax.x);ImGui::InputFloat2("Offset (reference px)",&e.offset.x);ImGui::InputFloat2("Fixed size",&e.size.x);ImGui::InputFloat2("Relative size",&e.relativeSize.x);ImGui::InputFloat2("Pivot alignment",&e.align.x);ImGui::InputFloat4("Margins L T R B",&e.margin.x);ImGui::InputFloat4("Padding L T R B",&e.padding.x);ImGui::InputFloat("Spacing",&e.spacing);
    ImGui::ColorEdit4("Background",&e.background.x);ImGui::ColorEdit4("Tint",&e.color.x);str("Text",e.text);str("Localization key",e.textKey);int direction=int(e.direction);if(ImGui::Combo("Text direction",&direction,"Auto\0LTR\0RTL\0"))e.direction=TextDirection(direction);int alignment=e.textLogicalAlign+1;if(ImGui::Combo("Text alignment",&alignment,"Legacy\0Left\0Right\0Center\0Start\0End\0"))e.textLogicalAlign=alignment-1;ImGui::Checkbox("Mirror horizontal children for RTL",&e.mirrorRow);auto assetPick=[&](const char* label,AssetType type,std::string& id){if(!state.assets)return;if(ImGui::BeginCombo(label,id.empty()?"(default / none)":id.c_str())){if(ImGui::Selectable("(default / none)",id.empty()))id.clear();for(auto& [key,asset]:state.assets->Records())if(asset.type==type&&!asset.missing&&ImGui::Selectable(asset.relativePath.c_str(),id==key))id=key;ImGui::EndCombo();}};assetPick("Font",AssetType::Font,e.font);assetPick("Image",AssetType::Texture,e.texture);ImGui::InputFloat("Font size",&e.fontSize);ImGui::InputFloat2("Text alignment legacy",&e.textAlign.x);ImGui::Checkbox("Wrap",&e.wrap);ImGui::Checkbox("Fit image",&e.fit);
    if(ImGui::Button("Copy style")){clipboard=e;hasClipboard=true;}ImGui::SameLine();if(hasClipboard&&ImGui::Button("Paste style to selected")){if(selection.empty())selection.insert(e.id);for(auto& target:source.elements)if(selection.count(target.id)){target.background=clipboard.background;target.color=clipboard.color;target.font=clipboard.font;target.fontSize=clipboard.fontSize;target.textLogicalAlign=clipboard.textLogicalAlign;}}
    str("Accessible label",e.accessibleLabel);str("Accessible description",e.description);ImGui::ColorEdit4("Focus indicator",&e.focusColor.x);
    if(e.kind==UIKind::TextInput){str("Placeholder",e.placeholder);ImGui::Checkbox("Read only",&e.readOnly);int maxBytes=int(e.maxBytes);if(ImGui::InputInt("Maximum UTF-8 bytes",&maxBytes))e.maxBytes=unsigned(std::clamp(maxBytes,1,16384));ImGui::TextWrapped("Single-line UTF-8; runtime selection uses extended grapheme indices. IME composition is transient.");}
    if(e.kind==UIKind::List||e.kind==UIKind::Scroll){ImGui::InputFloat("Row / scroll step",&e.rowHeight);ImGui::TextWrapped("Children of a Scroll container clip automatically. Virtual List rows come from JS setItems; only visible rows are shaped/drawn.");}
    ImGui::InputFloat("Value",&e.value);ImGui::InputFloat("Minimum",&e.minimum);ImGui::InputFloat("Maximum",&e.maximum);
    if(selected&&ImGui::Button("Delete element subtree")){std::set<std::string> remove{e.id};bool more=true;while(more){more=false;for(const auto& x:source.elements)if(remove.count(x.parent))more|=remove.insert(x.id).second;}source.elements.erase(std::remove_if(source.elements.begin(),source.elements.end(),[&](const auto& x){return remove.count(x.id);}),source.elements.end());selected=0;}
    auto after=SerializeUIDocument(source);if(after!=before)pending=true;
    if(!ImGui::IsAnyItemActive())flush();
    if(!source.Validate(error)){ImGui::TextWrapped("Last-good source retained: %s",error.c_str());if(ImGui::Button("Discard invalid visual draft"))reloadTyped();}else if(state.uiPreviewRevision==0||after!=before){state.uiPreviewDocument=source;++state.uiPreviewRevision;}
    if(ImGui::CollapsingHeader("Named UI source")){if(textGeneration!=document.Generation()&&!sourceDirty){CopyToBuffer(document.Source(),text.data(),text.size());textGeneration=document.Generation();}if(ImGui::InputTextMultiline("##ui-source",text.data(),text.size(),{0,250}))sourceDirty=true;if(ImGui::Button("Discard named draft")){sourceDirty=false;textGeneration=~uint64_t(0);}if(ImGui::Button("Validate / apply UI source")){if(flush()&&document.Replace(text.data(),error))reloadTyped();else state.status=error;}}
    ImGui::EndChild();ImGui::TableNextColumn();
    ImGui::TextUnformatted("Canvas - normal runtime layout / shaping");
    ImGui::Checkbox("Runtime canvas preview",&state.uiCanvasPreview);ImGui::InputInt2("Preview resolution",&state.uiPreviewResolution.x);state.uiPreviewResolution=glm::clamp(state.uiPreviewResolution,glm::ivec2(160,90),glm::ivec2(2560,1440));
    if(state.project){auto& c=state.project->Settings().localization;if(state.previewLocale.empty())state.previewLocale=c.defaultLocale;if(ImGui::BeginCombo("Preview locale",state.previewLocale.c_str())){for(auto& [tag,entry]:c.locales){(void)entry;if(ImGui::Selectable(tag.c_str(),tag==state.previewLocale))state.previewLocale=tag;}ImGui::EndCombo();}}
    if(state.uiCanvasPreview&&state.uiPreviewToken){float width=std::max(160.f,ImGui::GetContentRegionAvail().x),height=width*state.uiPreviewResolution.y/state.uiPreviewResolution.x;auto origin=ImGui::GetCursorScreenPos();ImGui::Image(ImTextureID(state.uiPreviewToken),{width,height},{0,1},{1,0});if(ImGui::IsItemHovered()&&ImGui::IsMouseClicked(0)){auto mouse=ImGui::GetMousePos();state.uiCanvasPick={(mouse.x-origin.x)/width*state.uiPreviewResolution.x,(mouse.y-origin.y)/height*state.uiPreviewResolution.y};}}
    ImGui::EndTable();
}

}
bool BakeEditorCollision(EditorDocument& doc,SceneObjectId target,EditorPanelState& state,
                         const AssetId& sourceId,const CollisionCookSettings& settings,
                         const std::string& output){
    auto fail=[&](const std::string& error){state.status=error;return false;};
    if(!state.assets||state.mode!=EditorMode::Edit)return fail("Collision cooking requires an edit project");
    auto* object=doc.GetScene().Find(target);
    if(!object||!object->body)return fail("Select an object with a Body to assign collision");
    if(!settings.convex&&(object->body->motion==SceneBodyMotion::Dynamic||object->body->sensor))return fail("Triangle surfaces require a static non-sensor body");
    if(object->transform.scale!=glm::vec3(1))return fail("Bake scale into source; rigid instance scale must be one");
    const auto* source=state.assets->Find(sourceId);
    if(!source||source->missing||source->type!=AssetType::Mesh)return fail("Select a registered source model");
    auto relative=std::filesystem::path(output).lexically_normal();
    if(relative.empty()||relative.is_absolute()||relative.extension()!=".judascollision")return fail("Output must be an assets-relative .judascollision path");
    for(auto& part:relative)if(part=="..")return fail("Output cannot escape project assets");
    auto destination=std::filesystem::path(state.assets->AssetsDir())/relative;
    std::error_code ec;std::filesystem::create_directories(destination.parent_path(),ec);
    if(ec)return fail(ec.message());
    CollisionAsset asset;std::string error;
    ModelCollisionCleanupReport cleanupReport;if(!CookImportedCollisionFile(source->path,sourceId,settings,state.collisionCleanup,destination.string(),asset,cleanupReport,state.collisionDiagnostic,error))return fail(error);
    AssetRecord record;auto* existing=state.assets->FindByRelativePath(std::filesystem::relative(destination,state.project->RootDir()).generic_string());
    if(existing)record=*existing;else if(!state.assets->Track(destination.string(),record,error))return fail(error);
    if(state.resources)state.resources->Invalidate(record.id);
    doc.BeginEdit();object->body->shape=settings.convex?SceneShape::ConvexHull:SceneShape::TriangleMesh;
    object->body->collisionAsset=record.id;doc.CommitEdit();
    state.status="Cooked and assigned physical geometry (undo restores authored Body)";
    return true;
}

void DrawAssetBrowserPanel(EditorDocument& doc, EditorPanelState& state, EditorRequests& requests) {
    // Imports may be initiated by the timeline while the browser is closed.
    if(state.project&&state.project->IsLoaded()&&state.assets)PublishFinishedEditorImport(state,requests);
    if (!state.workspace.showAssets) return;
    PlaceWorkspacePanel(state.workspace.assets);
    if (!ImGui::Begin("Asset Browser", &state.showAssetBrowser, kWorkspacePanelFlags)) { ImGui::End(); return; }
    const bool hasProject = state.project && state.project->IsLoaded() && state.assets;
    if (!hasProject) {
        ImGui::TextDisabled("No project open. File > New project / Open project.");
        ImGui::End();
        return;
    }
    if(auto task=state.assetCookTask;task&&task->ready.load(std::memory_order_acquire)&&state.mode==EditorMode::Edit){
        if(task->root!=state.project->RootDir())state.status="Cook belongs to previous project; result discarded";
        else if(!task->error.empty())state.status=task->error;
        else{std::string error;if(PublishAssetCook(task->destination,task->bytes,task->recipe,error)){auto relative=std::filesystem::path(task->destination).lexically_relative(state.project->RootDir()).generic_string();if(auto* existing=state.assets->FindByRelativePath(relative)){if(state.resources)state.resources->Invalidate(existing->id);state.status="Updated cooked generation; stable ID retained";}else requests.trackAssetPath=task->destination;}else state.status=error;}
        state.assetCookTask.reset();
    }
    const AssetDatabase& db = *state.assets;
    if (ImGui::BeginTabBar("##assetBrowserTabs")) {
        if (ImGui::BeginTabItem("Assets")) {
    ImGui::BeginChild("assets", ImVec2(0.0f, 0.0f), ImGuiChildFlags_None);
    char assetSearch[256]; CopyToBuffer(state.assetSearch, assetSearch, sizeof(assetSearch));
    ImGui::SetNextItemWidth(-1);
    if (ImGui::InputTextWithHint("##assetSearch", "Find assets by name, folder, ID or source...", assetSearch, sizeof(assetSearch)))
        state.assetSearch = assetSearch;
    ImGuiTextFilter searchFilter(assetSearch);
    ImGui::BeginDisabled(state.mode != EditorMode::Edit);
    if (ImGui::Button("Import assets...")) requests.browseImport = true;
    ImGui::EndDisabled();
    NextActionOnRow("Filters...");
    if (ImGui::Button("Filters...")) ImGui::OpenPopup("assetFilters");
    if (ImGui::BeginPopup("assetFilters")) {
    const char* assetTypes[]={"All types","Mesh","Texture","Font","Audio","Prefab","Script","UI","Navigation","Liquid","Material","Environment","Catalog","World","Audio effect","Deformable","Collision","Physical material"};
    int selectedType = state.assetTypeFilter + 1;
    ImGui::SetNextItemWidth(120.0f);
    if (ImGui::Combo("##assetType", &selectedType, assetTypes, 18)) state.assetTypeFilter = selectedType - 1;
    ImGui::Checkbox("Missing", &state.assetMissingOnly);
        ImGui::EndPopup();
    }
    NextActionOnRow("Rescan");
    if (ImGui::SmallButton("Rescan")) requests.rescanAssets = true;
    ToolbarHint("Refresh imported, missing and untracked project files");
    if (const auto* selected = db.Find(state.browserSelection); selected && selected->type == AssetType::Script) {
        ImGui::BeginDisabled(selected->missing || selected->readOnly);
        if (ImGui::Button("Edit script")) RequestEditorScriptEdit(*selected, state);
        ImGui::EndDisabled();
        NextActionOnRow("Attach to selected object");
        ImGui::BeginDisabled(state.mode != EditorMode::Edit || doc.Selection().size() != 1 || selected->missing);
        if (ImGui::Button("Attach to selected object")) {
            std::string error;
            state.status = AttachEditorScript(doc, doc.Selected(), db, selected->id, error) ? "Script attached; save scene, then Play" : error;
        }
        ImGui::EndDisabled();
        ToolbarHint("Select one scene object, then attach this script. This is a normal undoable scene edit.");
    }
    if (ImGui::BeginTable("assetTable", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV |
                         ImGuiTableFlags_Resizable | ImGuiTableFlags_ScrollY,
                         {0, std::max(35.0f, ImGui::GetContentRegionAvail().y)})) {
        ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthFixed, 90.0f);
        ImGui::TableSetupColumn("State", ImGuiTableColumnFlags_WidthFixed, 95.0f);
        ImGui::TableSetupScrollFreeze(0, 1);
        ImGui::TableHeadersRow();
        for (const auto& [id, record] : db.Records()) {
            const auto searchable = record.relativePath + " " + id + " " + record.source;
            if (!searchFilter.PassFilter(searchable.c_str())) continue;
            if(state.assetTypeFilter>=0&&int(record.type)!=state.assetTypeFilter)continue;
            if(state.assetMissingOnly&&!record.missing)continue;
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::PushID(id.c_str());
            const bool selected = state.browserSelection == id;
            const auto selectAsset = [&] {
                state.browserSelection = id;
                state.moveAssetInput = record.path.size() > db.AssetsDir().size() + 1 &&
                    record.path.compare(0, db.AssetsDir().size(), db.AssetsDir()) == 0
                    ? record.path.substr(db.AssetsDir().size() + 1) : record.relativePath;
            };
            const auto name = std::filesystem::path(record.relativePath).filename().string();
            if (ImGui::Selectable(name.c_str(), selected, ImGuiSelectableFlags_SpanAllColumns | ImGuiSelectableFlags_AllowDoubleClick)) {
                selectAsset();
                if (ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
                    if(record.type==AssetType::SpriteSheet){state.spriteSheetEdit=id;state.showSpriteSheetEditor=true;}
                    const bool aiDefinition=record.type==AssetType::Script&&name.size()>=6&&name.compare(name.size()-6,6,".ai.js")==0;
                    if(aiDefinition){state.utilityAIEdit=id;state.showUtilityAI=true;}
                    else if (!RequestEditorScriptEdit(record, state)) state.selectAssetDetails = true;
                }
            }
            if (!record.missing && ImGui::BeginDragDropSource()) {
                ImGui::SetDragDropPayload(kAssetDragPayload, id.data(), id.size());
                ImGui::Text("%s (%s)", record.relativePath.c_str(), AssetTypeName(record.type));
                ImGui::TextDisabled(record.type == AssetType::Mesh ? "Drop on the viewport to place, or on a Mesh field."
                                                                    : "Drop on a matching inspector field.");
                ImGui::EndDragDropSource();
            }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s\nID %s\nSource %s\n%s", record.path.c_str(), id.c_str(), record.source.c_str(),
                record.type == AssetType::Script ? "Double-click to edit script; right-click for details." : "Double-click to inspect; drag to a matching field.");
            if (ImGui::BeginPopupContextItem("##assetActions")) {
                if(record.type==AssetType::Texture&&ImGui::MenuItem("Create/edit sprite sheet",nullptr,false,state.mode==EditorMode::Edit&&!record.missing&&!record.readOnly)){
                    AssetRecord sheet;std::string error;if(CreateSpriteSheetAsset(*state.assets,id,sheet,error)){state.spriteSheetEdit=sheet.id;state.showSpriteSheetEditor=true;}else state.status=error;
                }
                if(record.type==AssetType::SpriteSheet&&ImGui::MenuItem("Paint tilemap from this sheet",nullptr,false,state.mode==EditorMode::Edit&&!record.missing)){state.tilemapPalette=id;state.showTilemapEditor=true;}
                if(record.type==AssetType::SpriteSheet&&ImGui::MenuItem("Edit frames and animation")){state.spriteSheetEdit=id;state.showSpriteSheetEditor=true;}
                if(record.type==AssetType::Script&&ImGui::MenuItem("Open as AI definition",nullptr,false,!record.missing)){state.utilityAIEdit=id;state.showUtilityAI=true;}

                if(record.type==AssetType::Texture&&ImGui::MenuItem("Create sprite in scene",nullptr,false,state.mode==EditorMode::Edit&&!record.missing)){
                    std::string error;const auto id=CreateEditorSpriteFromImage(doc,db,record.id,state.cameraFocus,0,error);
                    state.status=id?"Sprite created at 32 pixels per world unit; edit size, pivot and sorting in Sprite.":error;
                }
                if (record.type == AssetType::Script && ImGui::MenuItem("Edit script", nullptr, false,
                    !record.missing && !record.readOnly)) RequestEditorScriptEdit(record, state);
                if (record.type == AssetType::Script && ImGui::MenuItem("Attach to selected object", nullptr, false,
                    state.mode == EditorMode::Edit && doc.Selection().size() == 1 && !record.missing)) {
                    std::string error;
                    state.status = AttachEditorScript(doc, doc.Selected(), db, id, error) ? "Script attached; save scene, then Play" : error;
                }
                if (ImGui::MenuItem("Inspect asset")) { selectAsset(); state.selectAssetDetails = true; }
                if (ImGui::MenuItem("Open file externally", nullptr, false, !record.missing)) requests.openExternalPath = record.path;
                if (ImGui::MenuItem("Copy file path")) ImGui::SetClipboardText(record.path.c_str());
                if (ImGui::MenuItem("Copy stable ID")) ImGui::SetClipboardText(id.c_str());
                ImGui::EndPopup();
            }
            ImGui::PopID();
            ImGui::TableSetColumnIndex(1);
            ImGui::TextUnformatted(AssetTypeName(record.type));
            ImGui::TableSetColumnIndex(2);
            if (record.missing) {
                ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.2f, 1.0f), "MISSING");
            } else if (state.resources) {
                // Milestone 31: the live resource state behind the asset.
                const ResourceState rs = state.resources->StateOf(id);
                switch (rs) {
                    case ResourceState::Queued:
                    case ResourceState::Loading:
                    case ResourceState::CpuReady:
                        ImGui::TextColored(ImVec4(1.0f, 0.85f, 0.3f, 1.0f), "loading");
                        break;
                    case ResourceState::Ready:
                        ImGui::TextColored(ImVec4(0.4f, 0.9f, 0.4f, 1.0f), "ready");
                        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Resident %.1f KB", static_cast<double>(state.resources->BytesOf(id)) / 1024.0);
                        break;
                    case ResourceState::Failed:
                        ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.3f, 1.0f), "FAILED");
                        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", state.resources->ErrorOf(id).c_str());
                        break;
                    default:
                        ImGui::TextDisabled("registered");
                        break;
                }
            } else {
                ImGui::TextDisabled("ok");
            }
        }
        ImGui::EndTable();
    }
            ImGui::EndChild();
            ImGui::EndTabItem();
        }
        const bool inspectRequested = state.selectAssetDetails;
        state.selectAssetDetails = false;
        if (ImGui::BeginTabItem("Selected asset", nullptr, inspectRequested ? ImGuiTabItemFlags_SetSelected : 0)) {
            ImGui::BeginChild("assetDetails", {0, 0});
            if (state.browserSelection.empty()) ImGui::TextWrapped("Select an asset to inspect its source, dependencies and editing actions.");
    if (!state.browserSelection.empty()) {
        if (const AssetRecord* record = db.Find(state.browserSelection)) {
            ImGui::Separator();
            ImGui::TextWrapped("Selected: %s", record->relativePath.c_str());
            ImGui::BeginDisabled(record->missing);
            if (ImGui::Button("Open file")) requests.openExternalPath = record->path;
            ImGui::EndDisabled();
            ToolbarHint("Open this file with your desktop's associated application");
            ImGui::SameLine();
            if (ImGui::Button("Copy path")) ImGui::SetClipboardText(record->path.c_str());
            ImGui::TextWrapped("Provenance: %s",record->source.empty()?"project-owned":record->source.c_str());
            if((record->type==AssetType::Mesh||record->type==AssetType::Texture)&&ImGui::TreeNode("Cook / LOD / residency")){
                static int maxSize=2048,levels=4,semantic=0;static float error=.1f,pixels=.5f;static bool lossless=false;
                auto ext=std::filesystem::path(record->path).extension();bool cooked=ext==".judasmesh"||ext==".judastex";
                static std::string recipeSelection;if(recipeSelection!=record->id){recipeSelection=record->id;if(cooked)try{std::ifstream f(record->path+".judascook");nlohmann::json j;f>>j;maxSize=j.at("textureMax");levels=j.at("levels");semantic=j.at("semantic");error=j.at("error");pixels=j.at("pixels");lossless=j.at("textureMode").get<unsigned>()!=0;}catch(...){}}
                ImGui::TextWrapped("Cooked resources are separate assets. Source files and existing scene references remain intact. Drag the cooked asset onto a normal mesh/texture field.");
                if(record->type==AssetType::Texture){ImGui::InputInt("Maximum dimension",&maxSize);ImGui::Combo("Texture role",&semantic,"sRGB colour\0Linear data\0Tangent normal\0");ImGui::Checkbox("Lossless RGBA (no BC)",&lossless);}else{ImGui::SliderInt("LOD levels",&levels,1,8);ImGui::DragFloat("Maximum object-space error",&error,.005f,0,10);ImGui::DragFloat("Screen error pixels",&pixels,.1f,0,32);}
                ImGui::BeginDisabled(record->missing||record->readOnly||state.mode!=EditorMode::Edit||bool(state.assetCookTask)||!state.importJobs);
                if(ImGui::Button(cooked?"Recook recorded source":"Cook optimized copy")){
                    auto task=std::make_shared<AssetCookPanelTask>();task->root=state.project->RootDir();task->source=record->path;
                    if(cooked){try{std::ifstream f(record->path+".judascook");nlohmann::json j;f>>j;task->source=(std::filesystem::path(record->path).parent_path()/j.at("source").get<std::string>()).lexically_normal().string();task->destination=record->path;}catch(...){state.status="No authoring cook recipe; use the original source asset";}}
                    else{auto path=std::filesystem::path(record->path);task->destination=(path.parent_path()/(path.stem().string()+".packed"+(record->type==AssetType::Mesh?".judasmesh":".judastex"))).string();}
                    if(!task->destination.empty()){AssetCookSettings settings;settings.maxTextureSize=unsigned(std::max(1,maxSize));settings.lodLevels=unsigned(levels);settings.lodMaxError=error;settings.lodPixels=pixels;settings.textureSemantic=unsigned(semantic);settings.textureMode=lossless?1:0;task->job=state.importJobs->Submit([task,settings](JobContext& context){if(!context.CancelRequested())PrepareAssetCook(task->source,task->destination,settings,task->bytes,task->recipe,task->error);else task->error="Cook cancelled";task->ready.store(true,std::memory_order_release);},JobPriority::Normal,"Asset pipeline cook");if(task->job.IsValid())state.assetCookTask=task;else state.status="Cook worker unavailable";}
                }
                ImGui::EndDisabled();if(state.assetCookTask)ImGui::TextDisabled("Cooking on a worker; publication waits for Edit mode.");
                if(cooked&&ImGui::Button("Verify cook source/generation")){std::string reason;bool fresh=CookedAssetFresh(record->path,reason);state.status=fresh?"Cook generation current (or runtime-only asset without authoring recipe)":reason;}
                ImGui::TreePop();
            }

            static uint64_t usersGeneration=~uint64_t(0);static std::string usersAsset;static std::vector<SceneObjectId> users;
            if(usersGeneration!=doc.Generation()||usersAsset!=record->id){users.clear();usersGeneration=doc.Generation();usersAsset=record->id;for(auto& o:doc.GetScene().Objects())for(auto& [key,value]:ObjectProperties(o))if(value.find(record->id)!=std::string::npos){users.push_back(o.id);break;}}
            if(ImGui::TreeNode("Current scene users")){for(auto id:users)if(auto* user=doc.GetScene().Find(id))if(ImGui::Selectable((user->name+" ##asset-user"+std::to_string(id)).c_str()))doc.Select(id);ImGui::TreePop();}
            if(ImGui::TreeNode("Asset dependencies")){
                static std::string dependencyKey,dependencyError;static std::set<AssetId> dependencies;
                auto key=record->id+record->path;
                if(dependencyKey!=key){dependencyKey=key;DirectAssetDependencies(*record,dependencies,dependencyError);}
                if(ImGui::SmallButton("Refresh dependency source"))DirectAssetDependencies(*record,dependencies,dependencyError);
                for(auto& id:dependencies){auto* target=db.Find(id);ImGui::TextWrapped("%s / %s",id.c_str(),target?target->relativePath.c_str():"MISSING");}
                if(!dependencyError.empty())ImGui::TextWrapped("%s",dependencyError.c_str());
                ImGui::TextWrapped("Typed prefab/UI/material/model/collision references. Dynamic script IDs use the registered-asset export policy.");
                ImGui::TreePop();
            }
            if(record->type==AssetType::Mesh&&state.resources){if(auto model=state.resources->TryGetSkeletal(record->id)){if(ImGui::TreeNode("Shared skeleton")){for(auto& name:model->skeleton.names)ImGui::TextUnformatted(name.c_str());ImGui::TreePop();}}}

            if(record->type==AssetType::Collision&&state.mode==EditorMode::Edit){CollisionAsset asset;std::string error;if(LoadCollisionAsset(record->path,asset,error)){ImGui::Text("Physical %s: %zu vertices / %zu faces",asset.convex?"hull":"triangle surface",asset.vertices.size(),asset.faces.size());auto source=db.Find(asset.sourceAsset);bool stale=!source||source->missing||CollisionAssetStale(asset,source->path,error);ImGui::TextWrapped("%s",stale?error.c_str():"Source/settings fingerprint current");if(ImGui::Button("Rebake saved source/settings")&&source){CollisionCookSettings settings;settings.convex=asset.convex;settings.twoSided=asset.twoSided;settings.primitive=asset.selectedPrimitive;settings.transform=asset.sourceTransform;ModelCollisionCleanup cleanup;ModelCollisionCleanupReport cleanupReport;CollisionDiagnostic diagnostic;if(ReadModelCollisionCleanup(record->path,cleanup,error)&&CookImportedCollisionFile(source->path,source->id,settings,cleanup,record->path,asset,cleanupReport,diagnostic,error)){if(state.resources)state.resources->Invalidate(record->id);state.status="Rebaked physical collider";}else state.status=error;}for(auto& warning:asset.warnings)ImGui::TextWrapped("%s",warning.c_str());}else ImGui::TextWrapped("%s",error.c_str());}
            if(record->type==AssetType::Material&&state.mode==EditorMode::Edit){
                static std::string selected,error;static MaterialDefinition draft;if(selected!=record->id){selected=record->id;LoadMaterial(record->path,draft,error);}
                if(ImGui::CollapsingHeader("Edit SHARED material source",ImGuiTreeNodeFlags_DefaultOpen)){int model=int(draft.model),alpha=int(draft.alpha);const char* models[]={"Legacy","PBR metallic / roughness","Unlit"};const char* modes[]={"Opaque","Alpha cutout","Alpha blend"};if(ImGui::Combo("Model",&model,models,3))draft.model=MaterialModel(model);if(ImGui::Combo("Alpha mode",&alpha,modes,3))draft.alpha=MaterialAlpha(alpha);ImGui::ColorEdit4("Base colour factor (linear)",&draft.baseColor.x);ImGui::SliderFloat("Metallic",&draft.metallic,0,1);ImGui::SliderFloat("Roughness",&draft.roughness,0,1);ImGui::ColorEdit3("Emission (linear)",&draft.emissive.x);ImGui::DragFloat("Emission intensity",&draft.emissiveIntensity,.05f,0,100000);ImGui::SliderFloat("Normal strength",&draft.normalStrength,0,8);ImGui::SliderFloat("Occlusion strength",&draft.occlusionStrength,0,1);ImGui::SliderFloat("Alpha cutoff",&draft.alphaCutoff,0,1);ImGui::Checkbox("Double sided",&draft.doubleSided);ImGui::Checkbox("Flip texture V",&draft.flipV);ImGui::DragFloat2("UV tiling",&draft.uvScale.x,.01f);ImGui::DragFloat2("UV offset",&draft.uvOffset.x,.01f);
                    const char* labels[]={"Base colour sRGB","Metallic B / roughness G linear","Normal linear","Occlusion R linear","Emission sRGB"};for(size_t i=0;i<5;++i){auto& map=draft.maps[i];std::string label=map.asset.empty()?"(none)":map.asset;if(ImGui::BeginCombo(labels[i],label.c_str())){if(ImGui::Selectable("(none)",map.asset.empty()))map.asset.clear();for(const auto& [id,a]:db.Records())if(a.type==AssetType::Texture&&ImGui::Selectable(a.relativePath.c_str(),map.asset==id))map.asset=id;ImGui::EndCombo();}ImGui::PushID(int(i));const char* wrap[]={"Repeat","Clamp","Mirror"};int values[]={10497,33071,33648};int ws=map.sampler.wrapS==33071?1:map.sampler.wrapS==33648?2:0,wt=map.sampler.wrapT==33071?1:map.sampler.wrapT==33648?2:0;if(ImGui::Combo("Wrap U",&ws,wrap,3))map.sampler.wrapS=values[ws];if(ImGui::Combo("Wrap V",&wt,wrap,3))map.sampler.wrapT=values[wt];ImGui::PopID();}
                    ImGui::TextWrapped("In-scene preview: assign this asset to a render slot. Saving intentionally updates all non-overridden users.");if(ImGui::Button("Save shared material")){if(SaveMaterial(record->path,draft,error)){if(state.resources)state.resources->Invalidate(record->id);state.status="Saved shared material; instances reload normally";}else state.status=error;}ImGui::SameLine();if(ImGui::Button("Reload source"))LoadMaterial(record->path,draft,error);if(!error.empty())ImGui::TextWrapped("%s",error.c_str());
                }
            }
            if(record->type==AssetType::AudioEffect&&state.mode==EditorMode::Edit&&ImGui::CollapsingHeader("Edit shared reverb settings",ImGuiTreeNodeFlags_DefaultOpen)){
                static std::string selected,error;static AudioEnvironmentSettings draft;if(selected!=record->id){selected=record->id;LoadAudioEnvironment(record->path,draft,error);}
                ImGui::SliderFloat("Room feedback",&draft.roomSize,0,1);ImGui::SliderFloat("High frequency damping",&draft.damping,0,1);ImGui::SliderFloat("Stereo width",&draft.width,0,1);ImGui::SliderFloat("Wet level",&draft.wet,0,1);
                if(ImGui::Button("Save shared reverb")){std::ofstream f(record->path);f<<SerializeAudioEnvironment(draft);if(f){if(state.resources)state.resources->Invalidate(record->id);state.status="Saved reverb settings";error.clear();}else error="Cannot write reverb settings";}ImGui::SameLine();if(ImGui::Button("Reload reverb"))LoadAudioEnvironment(record->path,draft,error);if(!error.empty())ImGui::TextWrapped("%s",error.c_str());
            }
            if(record->type==AssetType::World&&state.mode==EditorMode::Edit&&ImGui::CollapsingHeader("World manifest source",ImGuiTreeNodeFlags_DefaultOpen)){
                ImGui::TextWrapped("Edit this registered manifest through the shared named document editor. Validation, undo and external-change protection use the same service as the CLI.");
                if(ImGui::Button("Open world/source authoring tools"))state.showWorldBuilding=true;
                ImGui::TextWrapped("Path: %s",record->path.c_str());
            }
            if(record->type==AssetType::Catalog&&state.mode==EditorMode::Edit&&ImGui::CollapsingHeader("Catalog UTF-8 source")){
                static std::string catalogPath;static std::vector<char> buffer(2*1024*1024+1);if(catalogPath!=record->path){catalogPath=record->path;std::ifstream f(catalogPath);std::string text(std::istreambuf_iterator<char>(f),{});std::snprintf(buffer.data(),buffer.size(),"%s",text.c_str());}
                ImGui::InputTextMultiline("ICU messages",buffer.data(),buffer.size(),{0,220});
                if(ImGui::Button("Validate and save catalog")){Catalog parsed;std::string error;if(ParseCatalog(buffer.data(),parsed,error)){std::ofstream f(record->path,std::ios::binary);f<<buffer.data();state.status=f?"Saved UTF-8 catalog":"Catalog write failed";state.textReload=true;if(state.resources)state.resources->Invalidate(record->id);}else state.status=error;}
                ImGui::SameLine();if(ImGui::Button("Reload preview catalog"))state.textReload=true;
            }
            if(record->type==AssetType::UI&&state.mode==EditorMode::Edit){
                if(ImGui::Button("Edit UI document"))state.showUIDocument=true;
                if(state.showUIDocument){
                    ImGui::SetNextWindowPos({120,45},ImGuiCond_FirstUseEver);
                    ImGui::SetNextWindowSize({1040,700},ImGuiCond_FirstUseEver);
                    if(ImGui::Begin("UI document",&state.showUIDocument))DrawUILayoutEditor(*record,state);
                    ImGui::End();
                }
            }
            if(record->type==AssetType::Prefab&&state.mode==EditorMode::Edit&&ImGui::Button("Place prefab instance")){
                Scene source;std::string error;SceneObjectId root=0;
                if(LoadPrefab(db,record->id,source,error)){
                    doc.BeginEdit();
                    if(InstantiatePrefab(doc.GetScene(),source,record->id,SceneTransform{},root,error))doc.Select(root);
                    doc.CommitEdit(false);
                }
                state.status=error.empty()?"Placed linked prefab instance":error;
            }
            if (ImGui::CollapsingHeader("Organize asset (rename / move / remove)")) {
            char moveTo[256];
            CopyToBuffer(state.moveAssetInput, moveTo, sizeof(moveTo));
            if (ImGui::InputText("Rename / move to (in assets)", moveTo, sizeof(moveTo))) state.moveAssetInput = moveTo;
            if (ImGui::Button("Apply move") && !state.moveAssetInput.empty()) {
                requests.moveAssetId = state.browserSelection;
                requests.moveAssetTo = state.moveAssetInput;
            }
            ImGui::SameLine();
            if (ImGui::Button("Remove asset")) requests.removeAssetId = state.browserSelection;
            ImGui::SameLine();
            ImGui::TextDisabled("Scene references use the id, so a move keeps them valid.");
            }
        }
    }
            ImGui::EndChild();
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Import & tools")) {
            ImGui::BeginChild("assetTools", {0, 0});
            if(ImGui::Button("Animation retargeting: map / preview / bake"))OpenRetargetPanel(state,{},state.modelRecipe);
    if(ImGui::CollapsingHeader("Model import / reimport",ImGuiTreeNodeFlags_DefaultOpen)){
        auto text=[](const char* label,std::string& value){std::vector<char> buffer(std::max(size_t(4096),value.size()+256),0);std::copy(value.begin(),value.end(),buffer.begin());if(ImGui::InputText(label,buffer.data(),buffer.size()))value=buffer.data();};
        ImGui::TextWrapped("FBX / glTF / GLB / OBJ to an ordinary cooked model. Sources and recipes are author-owned; the game loads only cooked content. Reimport publishes only in Edit mode.");
        text("Original source file",state.modelSource);text("Project-relative runtime output",state.modelOutput);
        if(state.mode==EditorMode::Edit&&ImGui::Button("Copy source and create import recipe")){std::string error;if(CreateModelRecipe(state.project->RootDir(),state.modelSource,state.modelOutput,state.modelRecipe,error))state.status="Recipe created; review settings then Import";else state.status=error;}
        text("Import recipe (.judasimport)",state.modelRecipe);
        if(!state.modelRecipe.empty()&&std::filesystem::is_regular_file(state.modelRecipe))try{
            using Json=nlohmann::json;std::ifstream file(state.modelRecipe);if(std::filesystem::file_size(state.modelRecipe)>4*1024*1024)throw std::runtime_error("Recipe exceeds 4 MiB");auto recipe=Json::parse(file,[](int depth,Json::parse_event_t,const Json&){if(depth>=48)throw std::runtime_error("Recipe nesting bound");return true;});bool changed=false;auto& settings=recipe["settings"];
            double units=settings.value("unitMeters",0.0),rate=settings.value("sampleRate",60.0);bool base=settings.value("allowBaseMesh",false);
            if(ImGui::InputDouble("Source metres per unit (0 = metadata)",&units)){settings["unitMeters"]=units;changed=true;}if(ImGui::InputDouble("Nonlinear bake samples / second",&rate)){settings["sampleRate"]=rate;changed=true;}if(ImGui::Checkbox("Explicit base mesh only (lossy)",&base)){settings["allowBaseMesh"]=base;changed=true;}
            text("Compatible motion source",state.modelMotionSource);text("Source take",state.modelMotionTake);text("Clip name",state.modelMotionName);
            if(state.mode==EditorMode::Edit&&ImGui::Button("Copy / add compatible motion")){auto root=std::filesystem::path(state.project->RootDir());auto directory=(root/recipe.at("source").get<std::string>()).parent_path();auto source=std::filesystem::path(state.modelMotionSource);auto owned=directory/source.filename();if(std::filesystem::weakly_canonical(source)!=std::filesystem::weakly_canonical(owned))std::filesystem::copy_file(source,owned,std::filesystem::copy_options::overwrite_existing);recipe["motions"].push_back({{"source",owned.lexically_relative(root).generic_string()},{"take",state.modelMotionTake},{"name",state.modelMotionName},{"jointRemaps",Json::object()}});changed=true;}
            glm::vec4 basis(0,0,0,1);if(settings.contains("basisRotation")){auto q=settings.at("basisRotation").get<std::vector<float>>();if(q.size()==4)basis={q[0],q[1],q[2],q[3]};}if(ImGui::InputFloat4("Explicit post-metadata basis rotation x/y/z/w",&basis.x)){settings["basisRotation"]={basis.x,basis.y,basis.z,basis.w};changed=true;}
            text("Remap source name/path",state.modelMapSource);text("Project-relative file or stable alias",state.modelMapTarget);
            const char* maps[]={"dependencyRemaps","materialAliases","nodeAliases"};for(auto field:maps){ImGui::PushID(field);if(ImGui::Button(field)&&!state.modelMapSource.empty()){settings[field][state.modelMapSource]=state.modelMapTarget;changed=true;}ImGui::PopID();}
            if(state.importAccepted&&state.importAccepted->preview){auto& preview=*state.importAccepted->preview;
                if(ImGui::TreeNode("Import part selection (empty = all)")){auto parts=settings.value("selectedParts",std::vector<std::string>{});bool all=parts.empty();if(ImGui::Checkbox("All source parts",&all)&&all){settings["selectedParts"]=Json::array();changed=true;}for(auto& part:preview.primitives){bool selected=all||std::find(parts.begin(),parts.end(),part.part)!=parts.end();if(ImGui::Checkbox(part.part.c_str(),&selected)){if(all){for(auto& p:preview.primitives)parts.push_back(p.part);}if(selected){if(std::find(parts.begin(),parts.end(),part.part)==parts.end())parts.push_back(part.part);}else parts.erase(std::remove(parts.begin(),parts.end(),part.part),parts.end());settings["selectedParts"]=parts;changed=true;}}ImGui::TreePop();}
                if(ImGui::TreeNode("Source material slots")){for(size_t i=0;i<preview.materialKeys.size();++i)ImGui::BulletText("%zu: %s",i,preview.materialKeys[i].c_str());ImGui::TextWrapped("Author material overrides in the normal Render inspector; imported defaults are separate.");ImGui::TreePop();}
            }
            if(recipe.contains("clips"))for(auto& clip:recipe["clips"]){ImGui::PushID(clip.at("sourceClip").get<std::string>().c_str());std::string name=clip.value("name",clip.at("sourceClip").get<std::string>());text("Clip output name",name);if(clip.value("name",std::string())!=name){clip["name"]=name;changed=true;}bool loop=clip.value("loop",false);if(ImGui::Checkbox("Loop metadata",&loop)){clip["loop"]=loop;changed=true;}auto& root=clip["rootMotion"];std::string policy=root.value("policy",std::string("preserve")),node=root.value("node",std::string());if(ImGui::BeginCombo("Root policy",policy.c_str())){for(auto value:{"preserve","inPlace","extract"})if(ImGui::Selectable(value,policy==value)){root["policy"]=value;changed=true;}ImGui::EndCombo();}auto rig=state.importTask&&state.importPublished?state.resources->TryGetSkeletal(state.importTask->assetId):nullptr;if(rig&&ImGui::BeginCombo("Motion node",node.c_str())){for(size_t i=0;i<rig->skeleton.names.size();++i){auto key=SkeletonJointKey(rig->skeleton,int(i));if(ImGui::Selectable(key.c_str(),node==key)){root["node"]=key;changed=true;}}ImGui::EndCombo();}auto axes=root.value("translation",std::vector<bool>{true,false,true});if(axes.size()==3)for(int k=0;k<3;++k){bool axis=axes[k];ImGui::PushID(k);if(ImGui::Checkbox(k==0?"Model X":k==1?"Model Y":"Model Z",&axis)){axes[k]=axis;root["translation"]=axes;changed=true;}ImGui::PopID();ImGui::SameLine();}ImGui::NewLine();glm::vec3 rotationAxis(0);if(root.contains("rotationAxis")){auto v=root["rotationAxis"].get<std::vector<float>>();if(v.size()==3)rotationAxis={v[0],v[1],v[2]};}if(ImGui::InputFloat3("Extract twist around model axis (zero = none)",&rotationAxis.x)){if(glm::length(rotationAxis)>1e-6f)root["rotationAxis"]={rotationAxis.x,rotationAxis.y,rotationAxis.z};else root.erase("rotationAxis");changed=true;}glm::vec2 trim(0,1);if(clip.contains("trim"))trim={clip["trim"][0],clip["trim"][1]};if(ImGui::InputFloat2("Trim begin/end seconds",&trim.x)){clip["trim"]={trim.x,trim.y};changed=true;}ImGui::PopID();}
            if(state.importTask&&state.importTask->preview&&state.importTask->preview->skeletal&&ImGui::Button("Populate editable clip selections")){recipe["clips"]=Json::array();for(auto& clip:state.importTask->preview->skeletal->clips)recipe["clips"].push_back({{"sourceClip",clip.name},{"name",clip.name},{"loop",clip.loop},{"rootMotion",{{"policy","preserve"}}}});changed=true;}
            if(changed&&state.mode==EditorMode::Edit){std::ofstream out(state.modelRecipe);out<<recipe.dump(2)<<'\n';state.status="Import recipe saved; accepted runtime content is unchanged until reimport";}
            if(ImGui::TreeNode("Named recipe / selections / remaps")){auto pretty=recipe.dump(2);ImGui::TextUnformatted(pretty.c_str());ImGui::TreePop();}
        }catch(const std::exception& e){ImGui::TextWrapped("Recipe: %s",e.what());}
        bool busy=state.importTask&&!state.importTask->done.load();
        if(state.mode==EditorMode::Edit&&!busy&&!state.modelRecipe.empty()&&ImGui::Button("Import / reimport / retry")){state.importTask=QueueModelImport(*state.importJobs,state.modelRecipe);state.importPublished=false;}
        if(busy){ImGui::ProgressBar(float(state.importTask->progress.load())/100);if(ImGui::Button("Cancel import"))state.importTask->cancel=true;}
        if (state.importTask && state.importTask->done.load(std::memory_order_acquire)) {
            if (!state.importTask->success) ImGui::TextWrapped("Import failed; last good model retained: %s", state.importTask->error.c_str());
            else if (!state.importPublished) ImGui::TextWrapped("Cook ready. Stop Play to publish; live skeleton buffers remain unchanged.");
        }
        if(state.importAccepted){auto& t=*state.importAccepted;{
                ImGui::Text("Source bones: %zu; hierarchy nodes: %zu; palette entries: %zu; parts: %zu",t.report.sourceBones,t.report.hierarchyNodes,t.report.skinJoints,t.report.parts);
                if(ImGui::Button("Place accepted model"))requests.dropMeshAssetId=t.assetId;
                auto rig=state.resources->TryGetSkeletal(t.assetId);
                if(rig){
                    ImGui::Text("Runtime hierarchy: %zu nodes",rig->skeleton.names.size());
                    if(!rig->clips.empty()){int clip=int(std::min(size_t(state.modelPreviewClip),rig->clips.size()-1));if(ImGui::BeginCombo("Preview clip",rig->clips[clip].name.c_str())){for(size_t i=0;i<rig->clips.size();++i)if(ImGui::Selectable(rig->clips[i].name.c_str(),i==size_t(clip))){state.modelPreviewClip=unsigned(i);state.modelPreviewTime=0;}ImGui::EndCombo();}ImGui::Checkbox("Preview playback",&state.modelPreviewPlaying);ImGui::SliderFloat("Scrub seconds",&state.modelPreviewTime,0,rig->clips[state.modelPreviewClip].duration);}
                    ImGui::Checkbox("Skeleton overlay",&state.modelPreviewSkeleton);ImGui::SliderFloat("Orbit view",&state.modelPreviewYaw,-3.14f,3.14f);
                    if(ImGui::TreeNode("Hierarchy / stable joint identities")){for(size_t i=0;i<rig->skeleton.names.size();++i)ImGui::BulletText("%s",SkeletonJointKey(rig->skeleton,int(i)).c_str());ImGui::TreePop();}
                }
                if(auto parts=state.resources->TryGetModelParts(t.assetId))for(auto& p:*parts){bool visible=std::find(state.modelPreviewHidden.begin(),state.modelPreviewHidden.end(),p.part)==state.modelPreviewHidden.end();if(ImGui::Checkbox(p.part.c_str(),&visible)){if(visible)state.modelPreviewHidden.erase(std::remove(state.modelPreviewHidden.begin(),state.modelPreviewHidden.end(),p.part),state.modelPreviewHidden.end());else state.modelPreviewHidden.push_back(p.part);}}
                ImGui::TextWrapped("White ruler = one metre; RGB axes = import model basis; green = hierarchy; orange = extracted root track. These are preview axes, not simulation gravity.");
                if(state.modelPreviewToken)ImGui::Image((ImTextureID)(intptr_t)state.modelPreviewToken,ImVec2(std::min(600.f,ImGui::GetContentRegionAvail().x),360),ImVec2(0,1),ImVec2(1,0));
                for(auto& diagnostic:t.report.diagnostics)ImGui::TextWrapped("%s [%s]: %s. %s",diagnostic.severity.c_str(),diagnostic.code.c_str(),diagnostic.message.c_str(),diagnostic.action.c_str());
            }
        }
    }

    if(state.mode==EditorMode::Edit&&ImGui::Button("Create material")){auto directory=std::filesystem::path(db.AssetsDir())/"materials";std::filesystem::create_directories(directory);auto path=directory/"material.judasmat";unsigned n=2;while(std::filesystem::exists(path))path=directory/("material"+std::to_string(n++)+".judasmat");std::string error;if(SaveMaterial(path.string(),MaterialDefinition{},error))requests.trackAssetPath=path.string();else state.status=error;}
    if(state.mode==EditorMode::Edit&&ImGui::Button("Create reverb settings")){auto directory=std::filesystem::path(db.AssetsDir())/"audio";std::filesystem::create_directories(directory);auto path=directory/"environment.judasreverb";unsigned n=2;while(std::filesystem::exists(path))path=directory/("environment"+std::to_string(n++)+".judasreverb");std::ofstream f(path);f<<SerializeAudioEnvironment({});if(f)requests.trackAssetPath=path.string();else state.status="Cannot write reverb settings";}
    if(state.mode==EditorMode::Edit&&ImGui::CollapsingHeader("Bake HDR environment")){static char source[1024]{};static int width=128,samples=128;ImGui::InputText("Radiance .hdr source",source,sizeof(source));ImGui::InputInt("Bake width (power of two)",&width);ImGui::InputInt("Bake samples",&samples);ImGui::TextWrapped("Offline bake; may briefly block editor. Derived data is exported, never regenerated during play.");if(ImGui::Button("Bake and register environment")){auto directory=std::filesystem::path(db.AssetsDir())/"environments";std::filesystem::create_directories(directory);auto path=directory/(std::filesystem::path(source).stem().string()+".judasenv");unsigned n=2;while(std::filesystem::exists(path))path=directory/(std::filesystem::path(source).stem().string()+std::to_string(n++)+".judasenv");EnvironmentData data;std::string error;if(BakeEnvironment(source,unsigned(width),unsigned(samples),data,error)&&SaveEnvironment(path.string(),data,error))requests.trackAssetPath=path.string();else state.status=error;}}

    if(state.mode==EditorMode::Edit&&ImGui::CollapsingHeader("Cook physical collider")){
        static std::string sourceId;static char output[256]="collision/physical.judascollision";static int primitive=0,kind=0;static bool twoSided=false;static glm::vec3 scale(1),offset(0),angles(0);
        const auto selected=db.Find(sourceId);if(ImGui::BeginCombo("Registered source",selected?selected->relativePath.c_str():"Select OBJ/glTF/GLB")){for(auto& [id,a]:db.Records())if(a.type==AssetType::Mesh&&ImGui::Selectable(a.relativePath.c_str(),id==sourceId))sourceId=id;ImGui::EndCombo();}
        ImGui::InputInt("Object/group or node/primitive ordinal",&primitive);const char* kinds[]={"Static triangle surface","Convex hull (fills recesses)"};ImGui::Combo("Cook kind",&kind,kinds,2);ImGui::Checkbox("Two-sided triangle surface",&twoSided);ImGui::DragFloat3("Baked positive scale",&scale.x,.01f);ImGui::DragFloat3("Baked translation",&offset.x,.01f);ImGui::DragFloat3("Baked rotation degrees",&angles.x,.5f);ImGui::InputText("Output relative to assets",output,sizeof(output));
        ImGui::Checkbox("Explicit removal of true degenerates",&state.collisionCleanup.removeDegenerates);ImGui::Checkbox("Explicit orient connected patches",&state.collisionCleanup.orientPatches);ImGui::InputDouble("Collision-only weld metres (0..0.001)",&state.collisionCleanup.weldTolerance);
        if(!state.collisionDiagnostic.code.empty()){auto& d=state.collisionDiagnostic;ImGui::TextWrapped("%s: %s / source face %u / point %.4f %.4f %.4f",d.code.c_str(),d.node.c_str(),d.sourceFace,d.point.x,d.point.y,d.point.z);if(ImGui::Button("Highlight diagnostic on selected model"))state.modelDiagnosticVisible=true;}
        ImGui::TextWrapped("Explicit single source selection; glTF node transform is included. Failed cooks preserve the previous file. Use a low-detail physical model where appropriate. Convex mass sums child volumes, including overlaps.");
        if(ImGui::Button("Cook / replace and register")){std::string error;CollisionAsset asset;ModelCollisionCleanupReport cleanupReport;state.collisionDiagnosticAsset=sourceId;CollisionCookSettings settings;settings.convex=kind==1;settings.twoSided=twoSided;settings.primitive=unsigned(std::max(primitive,0));settings.transform=glm::translate(glm::dmat4(1),glm::dvec3(offset))*glm::mat4_cast(glm::dquat(glm::radians(glm::dvec3(angles))))*glm::scale(glm::dmat4(1),glm::dvec3(scale));auto relative=std::filesystem::path(output).lexically_normal();bool valid=!relative.empty()&&!relative.is_absolute();for(auto& part:relative)if(part=="..")valid=false;auto destination=std::filesystem::path(db.AssetsDir())/relative;
            if(!selected||selected->missing)error="select an available registered model";else if(!valid||relative.extension()!=".judascollision")error="destination must be an assets-relative .judascollision path";else{std::error_code ec;std::filesystem::create_directories(destination.parent_path(),ec);if(ec)error=ec.message();else if(CookImportedCollisionFile(selected->path,sourceId,settings,state.collisionCleanup,destination.string(),asset,cleanupReport,state.collisionDiagnostic,error)){requests.trackAssetPath=destination.string();for(auto& [id,a]:db.Records())if(a.path==destination.string()&&state.resources)state.resources->Invalidate(id);}}
            state.status=error.empty()?"Cooked collision; assign it in Body / Cooked geometry":error;
        }
        if(ImGui::Button("Cook and assign selected Body")){CollisionCookSettings settings;settings.convex=kind==1;settings.twoSided=twoSided;settings.primitive=unsigned(std::max(primitive,0));settings.transform=glm::translate(glm::dmat4(1),glm::dvec3(offset))*glm::mat4_cast(glm::dquat(glm::radians(glm::dvec3(angles))))*glm::scale(glm::dmat4(1),glm::dvec3(scale));BakeEditorCollision(doc,doc.Selected(),state,sourceId,settings,output);}
    }

    if(state.mode==EditorMode::Edit&&ImGui::Button("Create UI document")){
        UIDocument d;UIElement root;root.id="canvas";root.kind=UIKind::Canvas;d.elements.push_back(root);UIElement panel;panel.id="panel";panel.parent="canvas";panel.background={.1f,.12f,.18f,.95f};d.elements.push_back(panel);
        auto directory=std::filesystem::path(db.AssetsDir())/"ui";std::filesystem::create_directories(directory);auto path=directory/"layout.judasui";int n=2;while(std::filesystem::exists(path))path=directory/("layout"+std::to_string(n++)+".judasui");std::string error;
        if(SaveUIDocument(path.string(),d,error))requests.trackAssetPath=path.string();else state.status=error;
    }
    if (ImGui::CollapsingHeader("Import", ImGuiTreeNodeFlags_DefaultOpen)) {
        char source[512], destination[256];
        CopyToBuffer(state.importSourceInput, source, sizeof(source));
        CopyToBuffer(state.importDestinationInput, destination, sizeof(destination));
        if (ImGui::InputTextWithHint("Source file", "/path/to/model.obj | texture.png | font.ttf | sound.wav", source, sizeof(source))) state.importSourceInput = source;
        if (ImGui::InputTextWithHint("Destination (in assets)", "models/model.obj (empty keeps the file name)", destination, sizeof(destination))) state.importDestinationInput = destination;
        if (ImGui::Button("Import") && !state.importSourceInput.empty()) {
            requests.importSource = state.importSourceInput;
            requests.importDestination = state.importDestinationInput;
        }
        ImGui::SameLine();
        if(ImGui::Button("Browse source..."))requests.browseImport=true;
        ImGui::TextDisabled("Import copies and tracks the source. Cook when a platform/runtime format is needed.");
    }

    if (!db.Untracked().empty()) {
        ImGui::Separator();
        ImGui::TextDisabled("Untracked files (no .judasmeta; not referenceable until tracked):");
        for (const std::string& path : db.Untracked()) {
            ImGui::PushID(path.c_str());
            ImGui::BulletText("%s", path.c_str());
            ImGui::SameLine();
            if (ImGui::SmallButton("Track")) requests.trackAssetPath = path;
            ImGui::PopID();
        }
    }
    if (!db.Problems().empty()) {
        ImGui::Separator();
        ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.2f, 1.0f), "Problems:");
        for (const AssetProblem& problem : db.Problems()) ImGui::BulletText("%s: %s", problem.path.c_str(), problem.message.c_str());
    }
            ImGui::EndChild();
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}


void DrawProfilerPanel(EditorPanelState& state) {
    if (!state.showProfiler) return;
    const auto display = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos({20, 76}, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize({std::min(850.0f, display.x - 40), std::min(700.0f, display.y - 110)}, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin("Profiler", &state.showProfiler)) { ImGui::End(); return; }
    ImGui::Checkbox("Inspect live Play (F8: release cursor)", &state.profilerInspect);
    DrawIntegratedProfilerView();
    if(ImGui::CollapsingHeader("Specialized diagnostics (last observation, legacy timers)")){
    const ProfilerData& p = state.profiler;
    ImGui::Text("Frame: %.2f ms  (%.0f FPS, rolling)", p.frameMilliseconds, p.framesPerSecond);
    if (!p.playing) ImGui::TextDisabled("Edit mode: no simulation stepping.");
    ImGui::Text("Fixed steps this frame: %d", p.fixedStepsThisFrame);
    ImGui::Text("Last fixed step: %.3f ms (whole StepPlayedWorld)", p.fixedStepMilliseconds);
    ImGui::Separator();
    ImGui::Text("Physics bodies: %zu live (%zu dynamic)", p.physicsBodies, p.dynamicBodies);
    ImGui::Text("Contacts (last step's manifold points): %zu", p.contacts);
    ImGui::Text("Broadphase: %zu candidate pairs of %zu possible (%.3f%%)", p.physics.candidatePairs,
                p.physics.possiblePairs,
                p.physics.possiblePairs > 0 ? 100.0 * p.physics.candidatePairs / p.physics.possiblePairs : 0.0);
    ImGui::Text("  %zu colliding pairs, tree height %d, %zu proxy reinsertions", p.physics.collidingPairs,
                p.physics.treeHeight, p.physics.proxyReinsertions);
    ImGui::Text("  PhysicsWorld::Step %.3f ms (broadphase %.3f, narrowphase %.3f, solver %.3f)",
                p.physics.totalMilliseconds, p.physics.broadphaseMilliseconds, p.physics.narrowphaseMilliseconds,
                p.physics.solverMilliseconds);
    ImGui::Text("CCD holds: %zu operations (body limit %zu, step limit %zu, response %zu)",
                p.physics.impactSafetyFallback, p.physics.impactBodyCapHolds,
                p.physics.impactStepCapHolds, p.physics.impactResponseHolds);
    ImGui::Text("CCD responses: %zu / %zu applied; missing manifold %zu, energy rejection %zu",
                p.physics.impactResponsesApplied, p.physics.impactResponseAttempts,
                p.physics.impactMissingManifolds, p.physics.impactEnergyRejections);
    ImGui::TextDisabled("A hold truncates remaining travel, keeping physical velocity. Counts are not unique bodies.");
    ImGui::Text("Entities: %zu full / %zu coarse / %zu dormant / %zu destroyed", p.entitiesFull, p.entitiesCoarse,
                p.entitiesDormant, p.entitiesDestroyed);
    ImGui::Separator();
    ImGui::Text("Draw calls: %u  (incl. shadow passes)", p.drawCalls);
    ImGui::Text("Triangles submitted: %u", p.triangles);
    ImGui::Text("Visibility (all passes): %u visible / %u culled meshes",p.meshesVisible,p.meshesCulled);
    ImGui::Text("Emitters: %u visible / %u culled; particles submitted: %u",p.emittersVisible,p.emittersCulled,p.particlesSubmitted);
    ImGui::Text("Shadow passes: %u   Dynamic lights: %u", p.shadowPasses, p.dynamicLights);
    ImGui::Text("Debug lines: %u", p.debugLines);
    ImGui::Text("Scene submission: %.2f ms", p.sceneMilliseconds);
    ImGui::Separator();
    ImGui::Text("Fluid particles: %zu", p.fluidParticles);
    ImGui::Text("Fluid solve (in step): %s", p.fluidMilliseconds > 0.0f ? "" : "not measured");
    if (p.fluidMilliseconds > 0.0f) { ImGui::SameLine(); ImGui::Text("%.3f ms", p.fluidMilliseconds); }
    ImGui::Text("Fluid surface rebuild: %.2f ms", p.surfaceMilliseconds);
    ImGui::Separator();
    ImGui::Text("Resources: %zu ready (%zu meshes, %zu textures), %zu loading, %zu failed, %zu terrain meshes",
                p.resources.ready, p.resources.loadedMeshes, p.resources.loadedTextures, p.resources.loading,
                p.resources.failed, p.resources.loadedTerrainMeshes);
    ImGui::Text("  resident %.1f MB of %.0f MB budget (peak %.1f MB)", p.resources.bytesResident / 1048576.0,
                p.resources.budgetBytes / 1048576.0, p.resources.peakBytesResident / 1048576.0);
    ImGui::Text("  GPU payload %.1f MB / prepared CPU %.1f MB / pinned %.1f MB / over budget %.1f MB",
                p.resources.gpuBytesResident / 1048576.0, p.resources.preparedBytes / 1048576.0,
                p.resources.pinnedBytes / 1048576.0, p.resources.overBudgetBytes / 1048576.0);
    ImGui::Text("  hits %llu / loads %llu / uploads %llu / evictions %llu / cancelled %llu / stale %llu",
                p.resources.hits, p.resources.misses, p.resources.uploads, p.resources.evictions, p.resources.cancelled,
                p.resources.staleDiscarded);
    ImGui::Separator();
    const double utilization = p.jobs.workers > 0 && p.jobs.elapsedSeconds > 0.0
                                   ? 100.0 * p.jobs.workerBusySeconds / (p.jobs.workers * p.jobs.elapsedSeconds)
                                   : 0.0;
    ImGui::Text("Jobs: %u workers, %zu queued, %zu running", p.jobs.workers, p.jobs.queued, p.jobs.running);
    ImGui::Text("  %llu completed / %llu failed / %llu cancelled of %llu submitted", p.jobs.completed, p.jobs.failed,
                p.jobs.cancelled, p.jobs.submitted);
    ImGui::Text("  worker utilization since start: %.1f%%", utilization);
    ImGui::TextDisabled("Specialized measurements above retain their original observation cadence; resource bytes are estimates, not driver VRAM.");
    }
    ImGui::End();
}

void DrawStatusBar(EditorDocument& doc, EditorPanelState& state) {
    PlaceWorkspacePanel(state.workspace.status);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 4));
    ImGui::Begin("##status", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings);
    const std::string message = std::string(doc.IsDirty() ? "Unsaved edits  |  " : "") + state.status;
    ImGui::TextUnformatted(message.c_str());
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s\n%s", doc.Path().empty() ? "Unsaved scene" : doc.Path().c_str(), state.status.c_str());
    if (!state.runtimeInfo.empty() && state.workspace.status.size.x - ImGui::CalcTextSize(message.c_str()).x > 480) {
        ImGui::SameLine(); ImGui::TextDisabled("%s", state.runtimeInfo.c_str());
    }
    ImGui::End();
    ImGui::PopStyleVar();
}


SceneObjectId DuplicateObject(EditorDocument& doc, SceneObjectId id) {
    if(doc.Selection().size()>1){std::string error;return doc.DuplicateSelection(error)?doc.Selected():kInvalidSceneObjectId;}
    Scene& scene = doc.GetScene();
    const SceneObject* source = scene.Find(id);
    if (!source) return kInvalidSceneObjectId;
    if(source->prefabRoot){
        if(source->prefabRoot!=id)return kInvalidSceneObjectId;
        const auto asset=source->prefabAsset;const auto placement=source->transform;
        Scene prefab;std::string error;
        if(!CreatePrefab(scene,id,prefab,error))return kInvalidSceneObjectId;
        auto ids=source->prefabIds;std::map<SceneObjectId,SceneObjectId> reverse;
        for(const auto& pair:ids)reverse[pair.second]=pair.first;
        for(auto& o:prefab.Objects()){
            o.id=reverse.at(o.id);if(o.parent)o.parent=reverse.at(o.parent);
            if(o.gravitySelection&&o.gravitySelection->source)o.gravitySelection->source=reverse.at(o.gravitySelection->source);
            if(o.wheel)o.wheel->chassis=reverse.at(o.wheel->chassis);
            if(o.powertrain)RemapPowertrainReferences(*o.powertrain,[&](uint64_t id){return reverse.at(id);});
            if(o.render&&o.render->textureCamera)o.render->textureCamera=reverse.at(o.render->textureCamera);
        }
        prefab.SetNextId(1);doc.BeginEdit();SceneObjectId root=0;
        if(!InstantiatePrefab(scene,prefab,asset,placement,root,error)){doc.CancelEdit();return 0;}
        // The duplicate remains linked and carries only the same explicit overrides.
        for(auto& o:scene.Objects())if(o.prefabRoot==root){auto old=ids.find(o.prefabSource);
            if(old!=ids.end())o.prefabOverrides=scene.Find(old->second)->prefabOverrides;}
        doc.CommitEdit(false);doc.Select(root);return root;
    }
    doc.BeginEdit();
    SceneObject copy = *source;  // by value: CreateObject may reallocate
    SceneObject& created = scene.CreateObject(copy.name + " copy");
    const SceneObjectId newId = created.id;
    const std::string newName = created.name;
    created = copy;
    created.id = newId;
    created.name = newName;
    // A scene has at most one player start; the copy must not carry it.
    created.playerStart.reset();
    // Place the copy right after the original (order is authored data).
    std::vector<SceneObject>& objects = scene.Objects();
    std::size_t sourceIndex = 0, copyIndex = objects.size() - 1;
    for (std::size_t i = 0; i < objects.size(); ++i) if (objects[i].id == id) sourceIndex = i;
    while (copyIndex > sourceIndex + 1) {
        std::swap(objects[copyIndex], objects[copyIndex - 1]);
        --copyIndex;
    }
    doc.CommitEdit();
    doc.Select(newId);
    return newId;
}

void DrawStreamingPanel(EditorDocument& doc,EditorPanelState& state,EditorRequests& requests){
    if(!state.project||state.project->Settings().worldManifest.empty())return;
    if(!ImGui::Begin("World regions")){ImGui::End();return;}
    auto* asset=state.assets?state.assets->Find(state.project->Settings().worldManifest):nullptr;WorldManifest manifest;std::string error;
    if(!asset||!LoadWorldManifest(asset->path,manifest,error)){ImGui::TextWrapped("%s",error.c_str());ImGui::End();return;}
    if(state.mode==EditorMode::Edit){
        ImGui::Checkbox("Read-only additive preview",&state.worldPreview);ImGui::SameLine();if(ImGui::Button("Refresh preview"))++state.worldPreviewRevision;
        ImGui::TextWrapped("Choose an edit target to open its original source. Save writes only that document; other preview regions are read-only.");
        for(auto& [id,r]:manifest.regions){ImGui::PushID(id.c_str());ImGui::Text("%s (%s) / priority %d",id.c_str(),r.policy.c_str(),r.priority);ImGui::SameLine();if(ImGui::Button("Edit source"))requests.openSceneRelative=r.scene;ImGui::PopID();}
    }else if(state.runtime&&state.runtime->SceneControl()){
        auto* stream=state.runtime->SceneControl()->Streaming(*state.runtime,error);
        if(stream){auto stats=stream->Stats();ImGui::Text("%zu active / %zu preparing",stats.active,stats.pending);ImGui::Text("pending %zu / live estimate %zu / retained %zu bytes",stats.pendingBytes,stats.liveBytes,stats.retainedBytes);ImGui::Text("cache %zu / %zu bytes; boundary %.3f ms; largest unit %.3f ms",stats.resourceResidentBytes,stats.resourceCacheBudget,stats.integrationMs,stats.largestUnitMs);
            static EditorRegionRequests demand;for(auto& r:stream->Regions()){ImGui::PushID(r.id.c_str());ImGui::Text("%s: %s (%zu/%zu)",r.id.c_str(),r.state.c_str(),r.installed,r.entities);ImGui::BeginDisabled(demand.Owns(*stream,r.id));if(ImGui::Button("Request"))demand.Request(*stream,r.id,error);ImGui::EndDisabled();ImGui::SameLine();if(ImGui::Button("Release")){demand.Release(*stream,r.id);stream->Unload(r.id);}for(auto& pin:r.pins)ImGui::BulletText("Pinned: %s",pin.c_str());if(!r.error.empty())ImGui::TextWrapped("%s",r.error.c_str());ImGui::PopID();}}
        if(!error.empty())ImGui::TextWrapped("%s",error.c_str());
    }
    (void)doc;ImGui::End();
}
