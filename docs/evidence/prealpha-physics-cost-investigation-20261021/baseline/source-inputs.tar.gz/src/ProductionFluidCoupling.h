#pragma once
#include <memory>
#include <vector>
#include "PhysicsWorld.h"
#include "FluidHydrostatics.h"
class RuntimeWorld;
class PlayerController;
struct PlayerFluidSample;
struct FluidBodyCouplingMeasurement {
    BodyHandle body;
    float fraction = 0, displacedVolume = 0, containedMass = 0;
    glm::vec3 buoyancyForce{0}, dragForce{0}, containedImpulse{0};
};
struct ProductionFluidMeasurements {
    bool executed = false;
    unsigned long long executedSteps = 0;
    float lastFluidDeltaTime = 0;
    double particleMilliseconds = 0, totalMilliseconds = 0;
    double hydrostaticMilliseconds = 0, playerMilliseconds = 0; // passive phase timings
    glm::vec3 exteriorReactionNotApplied{0};
    glm::vec3 containedStaticSupportImpulse{0}; // external impulse on coupled rigid island
    // Aggregated over every auxiliary batch in this rigid tick; hold ticks are zero.
    std::size_t contactBatches = 0, contactIterations = 0, normalMatrixProducts = 0;
    std::size_t normalAccelerations = 0, contactIterationCaps = 0, normalBreakdowns = 0;
    std::size_t normalAccelerationRejections = 0, normalAccelerationBoundaryDeclines = 0;
    float maximumContactRelativeResidual = 0;
    std::size_t motionFrames = 0, motionSegments = 0, motionStorageBytes = 0, motionResets = 0;
    std::vector<FluidBodyCouplingMeasurement> bodies;
};
// Production approximation only. No research pressure solver is integrated.
// Owns transient cadence, geometry-keyed quadrature and particle-field caches.
class ProductionFluidCoupling {
public:
    ProductionFluidCoupling();
    ~ProductionFluidCoupling();
    void Reset();
    // Called once around the ordinary rigid step: forces use the latest liquid
    // field; particle advancement consumes only the subsequently resolved path.
    void PrepareRigidStep(RuntimeWorld& world, float rigidDeltaTime);
    void AdvanceResolvedLiquid(RuntimeWorld& world, float rigidDeltaTime);
    PlayerFluidSample SamplePlayer(const RuntimeWorld& world, const PlayerController& player) const;
    FluidFieldSample SampleField(glm::vec3 point,glm::vec3 up,float halfHeight,float radius,glm::vec3 tangent) const;
    const ProductionFluidMeasurements& Measurements() const;
private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};
