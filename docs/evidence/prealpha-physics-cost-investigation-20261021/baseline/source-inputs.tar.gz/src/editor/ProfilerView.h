#pragma once
void DrawIntegratedProfilerView();
