// Scratch velocity projection. Inverse mass weights are eliminated using
// momentum coordinates, making the velocity projection an ordinary Euclidean
// projection onto the density and prescribed wall halfspaces.
struct PressureCoefficient {
    std::size_t particle;
    glm::dvec3 gradient;
};
struct PressureRow {
    std::size_t begin, end;
    double maximum;
    std::size_t contact;
};
constexpr std::size_t kDensityRow=std::numeric_limits<std::size_t>::max();

glm::dvec3 ExactPoly6Gradient(const glm::vec3& displacement, const FluidKernel& kernel) {
    const glm::dvec3 d(displacement);
    const double remaining=double(kernel.radiusSquared)-glm::dot(d,d);
    if(remaining<=0)return glm::dvec3(0);
    return (-6*double(kernel.poly6)*remaining*remaining)*d;
}

struct PressureProjectionResult {
    std::vector<glm::vec3> velocities;
    std::vector<glm::vec3> contactImpulses;
    double residual=0;
    int sweeps=0;
};
PressureProjectionResult ImplicitPressureProjection(
    const std::vector<FluidParticle>& particles,
    const std::vector<glm::vec3>& positions,const NeighborLists& neighbors,
    const std::vector<FluidVelocityContact>& contacts,const FluidKernel& kernel,
    float restDensity,float step,float smoothing) {
    const std::size_t count=particles.size();
    double referenceMass=0;
    for(const auto& p:particles)referenceMass+=p.mass;
    referenceMass/=count;
    std::vector<double> inverseRoots(count);
    std::vector<float> densities(count);
    std::vector<glm::dvec3> free(count),absoluteColumnSum(count);
    for(std::size_t i=0;i<count;++i) {
        inverseRoots[i]=std::sqrt(referenceMass/particles[i].mass);
        densities[i]=DensityAt(i,positions,particles,neighbors,kernel);
    }
    std::vector<PressureRow> rows;
    std::vector<PressureCoefficient> coefficients;
    rows.reserve(count+contacts.size());
    coefficients.reserve(neighbors.indices.size()+count+contacts.size());
    const auto add=[&](std::size_t start,double rhs,std::size_t contact) {
        double normSquared=0;
        for(std::size_t e=start;e<coefficients.size();++e)
            normSquared+=glm::dot(coefficients[e].gradient,coefficients[e].gradient);
        if(!(normSquared>0)) {coefficients.resize(start);return;}
        const double inverseNorm=1/std::sqrt(normSquared);
        for(std::size_t e=start;e<coefficients.size();++e) {
            auto& item=coefficients[e];
            item.gradient*=inverseNorm;
            absoluteColumnSum[item.particle]+=glm::abs(item.gradient);
        }
        rows.push_back({start,coefficients.size(),rhs*inverseNorm,contact});
    };
    for(std::size_t i=0;i<count;++i) {
        const auto start=coefficients.size();
        glm::dvec3 own(0),xsph(0);
        for(std::size_t j:neighbors[i]) {
            const auto delta=positions[i]-positions[j];
            const auto g=(double(particles[j].mass)/restDensity)*ExactPoly6Gradient(delta,kernel);
            own+=g;
            coefficients.push_back({j,-inverseRoots[j]*g});
            if(smoothing>0)xsph+=(double(particles[j].mass)/std::max(densities[i],densities[j])*
                                  Poly6(glm::dot(delta,delta),kernel))*
                (glm::dvec3(particles[j].velocity)-glm::dvec3(particles[i].velocity));
        }
        free[i]=(glm::dvec3(particles[i].velocity)+double(smoothing)*xsph)/inverseRoots[i];
        coefficients.push_back({i,inverseRoots[i]*own});
        add(start,(1.0-double(densities[i])/restDensity)/step,kDensityRow);
    }
    for(std::size_t i=0;i<contacts.size();++i) {
        const auto& contact=contacts[i];
        const auto start=coefficients.size();
        coefficients.push_back({contact.particleIndex,-inverseRoots[contact.particleIndex]*glm::dvec3(contact.normal)});
        add(start,-double(contact.minimumNormalVelocity),i);
    }
    // Deterministic block Gauss-Seidel on the normalized dual. Each coordinate
    // is the exact unilateral line minimizer. Its update can release pressure
    // and wall support, unlike a one-way corrective impulse loop.
    std::vector<glm::dvec3> solution=free;
    std::vector<double> lambda(rows.size());
    PressureProjectionResult result;
    double rateScale=1;
    for(const auto& velocity:free)rateScale=std::max(rateScale,glm::length(velocity));
    const double tolerance=1e-5*rateScale;
    const auto error=[&](const auto& row) {
        double value=-row.maximum;
        for(std::size_t e=row.begin;e<row.end;++e) {
            const auto& c=coefficients[e];
            value+=glm::dot(c.gradient,solution[c.particle]);
        }
        return value;
    };
    constexpr int maxSweeps=64; // prototype diagnostic work guard, never claims convergence
    for(;result.sweeps<maxSweeps;++result.sweeps) {
        for(std::size_t j=0;j<rows.size();++j) {
            const auto& row=rows[j];
            const double next=std::max(0.0,lambda[j]+error(row));
            const double change=next-lambda[j];
            if(change==0)continue;
            lambda[j]=next;
            for(std::size_t e=row.begin;e<row.end;++e) {
                const auto& c=coefficients[e];
                solution[c.particle]-=change*c.gradient;
            }
        }
        result.residual=0;
        for(std::size_t j=0;j<rows.size();++j) {
            const double residual=error(rows[j]);
            result.residual=std::max(result.residual,lambda[j]>0?std::abs(residual):residual);
        }
        if(result.residual<=tolerance){++result.sweeps;break;}
    }
    for(std::size_t i=0;i<count;++i)result.velocities.push_back(glm::vec3(inverseRoots[i]*solution[i]));
    result.contactImpulses.resize(contacts.size());
    for(std::size_t j=0;j<rows.size();++j) {
        const auto& row=rows[j];
        if(row.contact==kDensityRow)continue;
        const auto& contact=contacts[row.contact];
        result.contactImpulses[row.contact]=glm::vec3(
            lambda[j]*double(particles[contact.particleIndex].mass)*inverseRoots[contact.particleIndex]*
            glm::dvec3(contact.normal));
    }
    return result;
}

