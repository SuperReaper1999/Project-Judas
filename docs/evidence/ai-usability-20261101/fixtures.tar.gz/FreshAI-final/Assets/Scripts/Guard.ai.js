export default {
  "actions": [
    {
      "considerations": [
        {
          "curve": "inverse",
          "exponent": 2.0,
          "fact": "health",
          "max": 1.0,
          "min": 0.0,
          "weight": 1.0
        }
      ],
      "cooldown": 0.2,
      "id": "hide",
      "interruptible": true,
      "minCommitment": 0.4,
      "mode": "product",
      "requiredFacts": [],
      "weight": 2.0
    },
    {
      "considerations": [],
      "cooldown": 0.0,
      "id": "patrol",
      "interruptible": true,
      "minCommitment": 0.0,
      "mode": "product",
      "requiredFacts": [],
      "weight": 0.2
    }
  ],
  "initialDelay": 0.0,
  "interval": 0.2,
  "name": "Patrol and hide",
  "switchAdvantage": 0.05,
  "version": 1
};
