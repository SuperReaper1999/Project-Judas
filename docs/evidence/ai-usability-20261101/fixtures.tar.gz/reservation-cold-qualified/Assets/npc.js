
import {AITargetReservations} from 'judas';
export const properties={name:{type:'string',default:'NPC'}};
export default class {
 constructor({properties}){this.name=properties.name;this.state={command:'',initial:false,available:false,result:false,sameSlotDenied:false,restoreAvailable:false};}
 make(){this.targets=new AITargetReservations();}
 start(){this.make();this.state.initial=this.targets.acquire('last-meal',1);
  const other=new AITargetReservations();
  this.state.sameSlotDenied=this.state.initial&&!other.acquire('last-meal',1);
  other.dispose();
  let coercions=0,rejections=0;
  const hostileTarget={toString:()=>{coercions++;this.targets.dispose();return 'last-meal';}};
  const hostileDuration={valueOf:()=>{coercions++;this.targets.dispose();return 1;}};
  for(const operation of [()=>this.targets.acquire(hostileTarget,1),()=>this.targets.release(hostileTarget),()=>this.targets.acquire('last-meal',hostileDuration)]) {
   try{operation();}catch(error){rejections++;}
  }
  this.state.coercions=coercions;this.state.rejections=rejections;
  this.state.available=this.targets.available('last-meal');
 }
 restore(){this.make();const independent=new AITargetReservations();
  this.state.restoreAvailable=independent.available('last-meal');independent.dispose();
 }
 fixedUpdate(){
  if(this.state.command==='acquire')this.state.result=this.targets.acquire('last-meal',1);
  else if(this.state.command==='release')this.state.result=this.targets.release('last-meal');
  else if(this.state.command==='renew')this.state.result=this.targets.acquire('last-meal',1);
  else if(this.state.command==='dispose')this.targets.dispose();
  else if(this.state.command==='fault')throw new Error('intentional reservation owner fault');
  this.state.command='';
  this.state.available=this.targets.available('last-meal');
 }
}
