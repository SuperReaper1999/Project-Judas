
import {AITargetReservations} from 'judas';
export default class {
 constructor(){this.targets=new AITargetReservations();
  this.bootAvailable=this.targets.available('last-meal');this.state={available:false,bootAvailable:false};}
 start(){this.state.bootAvailable=this.bootAvailable;}
 restore(){this.state.bootAvailable=this.bootAvailable;}
 fixedUpdate(){this.state.available=this.targets.available('last-meal');}
}
