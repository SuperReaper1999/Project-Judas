#define main ExistingBasinMain
#include "WaterBulkBasinProbe.cpp"
#undef main
#include "WaterGasGeometry.h"
int main(){for(bool rotated:{false,true}){CutSpatialField original,orthogonal,field;CutOrthogonalRemap remap;CutTransparentGridReport compact;std::string error;
if(!BuildFixture(rotated,original,error)||!BuildCutOrthogonalField(original,orthogonal,remap,error)||!CoarsenCutTransparentGrid(orthogonal,field,compact,error)){std::cerr<<error;return 1;}
std::vector<CutRegionWaterPlane> planes;WaterGasGeometry gas;WaterGasSettings settings;
if(!ReconstructCutRegionPhasePlanes(field.chart,field.geometry,1,field.water,field.gas,{},planes,error)||!PrepareWaterGasGeometry(field,planes,settings,1.8e-5,gas,error)){std::cerr<<error;return 1;}
std::vector<std::size_t> parent(gas.mass.size());std::iota(parent.begin(),parent.end(),0);
auto root=[&](std::size_t i){while(parent[i]!=i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
auto wide=[&](int axis,const GridVec& lo,const GridVec& hi,double area){int a=(axis+1)%3;if(a==1&&axis!=1)a=(axis+2)%3;double w=hi[a]-lo[a],h=area/w;return std::min(w,h)>=field.chart.layout.h/8.;};
std::size_t edge=0,merged=0;for(auto face:field.geometry.faces){auto l=gas.cellNode[face.left],r=gas.cellNode[face.right];if(l==SIZE_MAX||r==SIZE_MAX)continue;double a=MeasureCutRegionSharedPhase(face,{},planes[face.left],planes[face.right],false,false).start;if(a==0.)continue;if(edge>=gas.links.size()){std::cerr<<"edge map";return 1;}
if(wide(face.axis,face.lo,face.hi,a)){auto x=root(l),y=root(r);if(x!=y){parent[y]=x;++merged;}}++edge;}
if(edge!=gas.links.size()){std::cerr<<"missing edge";return 1;}
std::vector<bool> open(parent.size());std::size_t vi=0;for(auto b:field.boundaries){auto node=gas.cellNode[b.fragment];if(node==SIZE_MAX)continue;auto box=field.chart.regions[b.fragment];auto lo=box.lo,hi=box.hi;lo[b.axis]=hi[b.axis]=b.sign>0?box.hi[b.axis]:box.lo[b.axis];double area=MeasureCutRegionGasVent(box,{},CutRegionGasVent{b.axis,b.sign,lo,hi},planes[b.fragment]).start;if(area==0.)continue;if(wide(b.axis,lo,hi,area))open[root(node)]=true;++vi;}
std::size_t roots=0,opened=0;Real trapped,openVolume;for(std::size_t i=0;i<parent.size();++i){if(root(i)==i){++roots;if(open[i])++opened;}if(open[root(i)])openVolume=openVolume+gas.volume[i];else trapped=trapped+gas.volume[i];}
std::cout<<std::setprecision(17)<<"AIR_REGIONS rotated="<<rotated<<" originalGasCells="<<parent.size()<<" regions="<<roots<<" atmospheric="<<opened<<" trapped="<<roots-opened<<" openVolume="<<openVolume.Value()<<" trappedVolume="<<trapped.Value()<<" vents="<<vi<<" merged="<<merged<<std::endl;
}return 0;}
