#include "WaterBulkProjection.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <numeric>

namespace judas::volume_grid {
namespace {
using Real=CutCompensated;
bool Fail(std::string& e,const char* s){e=s;return false;}
struct Link {std::size_t l,r; double c;};
struct Vent {std::size_t i; double c;};
struct Local {Real w,g,m,p;double d=0.,s=0.,rank=0.,storage=0.;};
double Dot(const std::vector<double>& a,const std::vector<double>& b){Real sum;for(std::size_t i=0;i<a.size();++i)sum=sum+Real(a[i])*Real(b[i]);return sum.Value();}
struct System {
    System(const WaterBulkGeometry& g, const WaterBulkState& s, const WaterGasSettings& c) : geom(g),source(s),settings(c) {}
    const WaterBulkGeometry& geom; const WaterBulkState& source; const WaterGasSettings& settings;
    std::vector<Real> head;std::vector<double> initialPressure,inertance,predictor;
    std::vector<Link> water,gas;std::vector<Vent> vents;std::vector<bool> air, liquid;
    std::vector<Local> local;std::vector<double> q,z,v,residual,diagonal;
    bool Evaluate(const std::vector<double>& x,std::string& error){
        const auto n=geom.capacity.size();local.resize(n);residual.assign(2*n,0.);diagonal.assign(2*n,0.);
        std::vector<Real> rw(n),rm(n);
        for(std::size_t i=0;i<n;++i){
            auto& l=local[i];const double increment=air[i]?std::expm1(x[n+i]/settings.referencePressure):0.;
            if(!std::isfinite(increment)||increment<=-1.)return Fail(error,"bulk gas potential outside representable range");
            l.p=Real(initialPressure[i])+Real(initialPressure[i])*Real(increment);
            Real raw=source.gas[i]+(l.p-Real(initialPressure[i])-Real(x[i]))/Real(geom.potentialSlope[i]);
            Real capacity(geom.capacity[i]);l.rank=0.;
            if(raw.Value()<0.){l.g=Real();l.w=capacity;}
            else if((raw-capacity).Value()>0.){l.g=capacity;l.w=Real();}
            else{l.g=raw;l.w=source.water[i]+source.gas[i]-raw;l.rank=1./geom.potentialSlope[i];}
            if(!liquid[i]){l.w=source.water[i];l.g=source.gas[i];l.rank=0.;}
            l.d=l.p.Value()/settings.referencePressure;
            l.m=l.g*l.p/Real(settings.referencePressure/settings.referenceDensity);
            l.storage=l.m.Value()/(settings.referenceDensity*settings.referencePressure);
            rw[i]=l.w-source.water[i];rm[i]=(l.m-source.gasMass[i])/Real(settings.referenceDensity);
            diagonal[i]=l.rank;diagonal[n+i]=l.d*l.d*l.rank+l.storage;
        }
        q.resize(water.size());z.resize(gas.size());v.resize(vents.size());
        for(std::size_t f=0;f<water.size();++f){auto e=water[f];
            Real amount=Real(predictor[f])+Real(e.c)*(head[e.l]-head[e.r]+Real(x[e.l])-Real(x[e.r]));q[f]=amount.Value();
            rw[e.l]=rw[e.l]+amount;rw[e.r]=rw[e.r]-amount;diagonal[e.l]+=e.c;diagonal[e.r]+=e.c;
        }
        for(std::size_t f=0;f<gas.size();++f){auto e=gas[f];
            double initial=settings.referencePressure*std::log(initialPressure[e.l]/initialPressure[e.r]);
            z[f]=e.c*(initial+x[n+e.l]-x[n+e.r]);rm[e.l]=rm[e.l]+Real(z[f]);rm[e.r]=rm[e.r]-Real(z[f]);
            diagonal[n+e.l]+=e.c;diagonal[n+e.r]+=e.c;
        }
        for(std::size_t f=0;f<vents.size();++f){auto e=vents[f];
            v[f]=e.c*(settings.referencePressure*std::log(initialPressure[e.i]/settings.referencePressure)+x[n+e.i]);
            rm[e.i]=rm[e.i]+Real(v[f]);diagonal[n+e.i]+=e.c;
        }
        for(std::size_t i=0;i<n;++i){residual[i]=rw[i].Value();residual[n+i]=rm[i].Value();
            if(!std::isfinite(residual[i])||!std::isfinite(residual[n+i]))return Fail(error,"nonfinite bulk residual");}
        return true;
    }
    double Norm()const{double result=0.;const auto n=geom.capacity.size();for(std::size_t i=0;i<n;++i)for(auto j:{i,n+i})result=std::max(result,std::abs(residual[j])/geom.capacity[i]);return result;}
    void Multiply(const std::vector<double>& x,std::vector<double>& y)const{
        const auto n=geom.capacity.size();y.assign(2*n,0.);
        for(std::size_t i=0;i<n;++i){auto l=local[i];double d=l.rank*(x[i]-l.d*x[n+i]);y[i]=d;y[n+i]=-l.d*d+l.storage*x[n+i];}
        for(auto e:water){double d=e.c*(x[e.l]-x[e.r]);y[e.l]+=d;y[e.r]-=d;}
        for(auto e:gas){double d=e.c*(x[n+e.l]-x[n+e.r]);y[n+e.l]+=d;y[n+e.r]-=d;}
        for(auto e:vents)y[n+e.i]+=e.c*x[n+e.i];
    }
    bool Linear(std::vector<double>& dx,std::size_t& iterations,std::string& error)const{
        const auto n=residual.size();std::vector<double> r(n),z(n),p(n),ap;dx.assign(n,0.);
        for(std::size_t i=0;i<n;++i){r[i]=-residual[i];if(diagonal[i]>0.)z[i]=r[i]/diagonal[i];else if(r[i]!=0.) { error="bulk pressure has unanchored storage row="+std::to_string(i)+" diagonal="+std::to_string(diagonal[i])+" localRank="+std::to_string(local[i%geom.capacity.size()].rank)+" residual="+std::to_string(r[i])+" W0="+std::to_string(source.water[i%geom.capacity.size()].Value())+" G="+std::to_string(local[i%geom.capacity.size()].g.Value()); return false; }}
        p=z;double rz=Dot(r,z),initial=rz;if(rz==0.)return true;
        for(std::size_t it=0;it<4*n+64;++it){Multiply(p,ap);double pap=Dot(p,ap);if(!(pap>0.&&std::isfinite(pap)))return Fail(error,"bulk pressure tangent lost positive definiteness");double alpha=rz/pap;
            for(std::size_t i=0;i<n;++i){dx[i]+=alpha*p[i];r[i]-=alpha*ap[i];z[i]=diagonal[i]>0.?r[i]/diagonal[i]:0.;}
            ++iterations;double next=Dot(r,z);if(next<=initial*1e-24)return true;double beta=next/rz;
            for(std::size_t i=0;i<n;++i)p[i]=z[i]+beta*p[i];
            rz=next;
        }
        return Fail(error,"bulk pressure Krylov budget exhausted");
    }
};
double LogMean(double a,double b){if(a==b)return a;return (a-b)/(std::log(a)-std::log(b));}
}
bool ProjectWaterBulk(const WaterBulkGeometry& geom,const WaterBulkState& source,const WaterGasSettings& settings,
    WaterBulkState& output,WaterBulkProjectionStats& stats,std::string& error){
    auto started=std::chrono::steady_clock::now();WaterBulkAudit before;
    if(!(settings.dt>0.&&std::isfinite(settings.dt))||!AuditWaterBulkStorage(geom,source,settings,before,error))return false;
    const auto n=geom.capacity.size();const auto nf=geom.field.geometry.faces.size();
    System s(geom,source,settings);
    s.air.assign(n,false);s.liquid.assign(n,false);s.initialPressure.resize(n);s.head.resize(n);s.inertance.resize(nf);s.predictor.resize(nf);
    std::vector<double> baseGas;std::vector<double> baseVent;
    // Below-resolution support is a cell fraction, not a set of ever thinner
    // pressure domains. Hydraulic inertia contains WATER ONLY. Dry/dry links
    // carry no liquid, and no material can cross a solid or absent connection.
    for(std::size_t f=0;f<nf;++f){const auto& face=geom.field.geometry.faces[f];auto l=face.left,r=face.right;int a=face.axis;
        double length=.5*((geom.field.chart.regions[l].hi[a]-geom.field.chart.regions[l].lo[a])+(geom.field.chart.regions[r].hi[a]-geom.field.chart.regions[r].lo[a]));
        double wet=.5*(source.water[l].Value()/geom.capacity[l]+source.water[r].Value()/geom.capacity[r]);
        double area=face.meanArea*wet;double inertance=area>0.?geom.density*length/area:0.;s.inertance[f]=inertance;
        s.water.push_back({l,r,inertance>0.?settings.dt*settings.dt/inertance:0.});
        if(inertance>0.) s.liquid[l]=s.liquid[r]=true;
        // A momentum metric change is exposed to the final cold-energy audit.
        s.predictor[f]=source.faceRate[f]*settings.dt;
        double dry=.5*(source.gas[l].Value()/geom.capacity[l]+source.gas[r].Value()/geom.capacity[r]);
        if(dry>0.){double conductance=0.;double width=std::sqrt(face.meanArea*dry);
            if(!RectangularGasMassConductance(width,width,length,settings.referenceDensity,settings.referencePressure,1.8e-5,conductance,error))return false;
            s.gas.push_back({l,r,settings.dt*conductance/settings.referenceDensity});baseGas.push_back(s.gas.back().c);s.air[l]=s.air[r]=true;}
    }
    for(auto b:geom.field.boundaries){auto i=b.fragment;auto region=geom.field.chart.regions[i];int a=b.axis;
        double area=(region.hi[(a+1)%3]-region.lo[(a+1)%3])*(region.hi[(a+2)%3]-region.lo[(a+2)%3])*source.gas[i].Value()/geom.capacity[i];
        if(area>0.){double conductance=0.,width=std::sqrt(area);
            if(!RectangularGasMassConductance(width,width,.5*(region.hi[a]-region.lo[a]),settings.referenceDensity,settings.referencePressure,1.8e-5,conductance,error))return false;
            s.vents.push_back({i,settings.dt*conductance/settings.referenceDensity});baseVent.push_back(s.vents.back().c);s.air[i]=true;}
    }
    for(std::size_t i=0;i<n;++i){s.air[i]=s.air[i]||source.gasMass[i].Value()>0.;
        double p=source.gasMass[i].Value()>0.?(source.gasMass[i]/source.gas[i]).Value()*settings.referencePressure/settings.referenceDensity:(s.air[i]?settings.referencePressure:0.);
        s.initialPressure[i]=p;s.head[i]=Real(geom.potentialBase[i])+Real(geom.potentialSlope[i])*source.water[i]+Real(p)-Real(settings.referencePressure);
    }
    WaterBulkProjectionStats result;std::vector<double> x(2*n);
    bool convergedGas=false;
    for(std::size_t outer=0;outer<32;++outer){
        for(std::size_t iteration=0;iteration<80;++iteration){
            if(!s.Evaluate(x,error))return false;
            double norm=s.Norm();
            if(norm<1e-11)break;
            std::vector<double> dx;if(!s.Linear(dx,result.linearIterations,error))return false;
            auto old=x;bool accepted=false;
            for(int backtrack=0;backtrack<48;++backtrack){double fraction=std::ldexp(1.,-backtrack);for(std::size_t i=0;i<x.size();++i)x[i]=old[i]+fraction*dx[i];
                std::string trial;if(s.Evaluate(x,trial)&&s.Norm()<norm*(1.-1e-4*fraction)){accepted=true;break;}}
            if(!accepted)return Fail(error,"bulk pressure line search stagnated");
            ++result.newtonIterations;
            if(iteration==79)return Fail(error,"bulk pressure nonlinear budget exhausted");
        }
        double change=0.;
        for(std::size_t j=0;j<s.gas.size();++j){auto& e=s.gas[j];double mean=LogMean(s.local[e.l].d,s.local[e.r].d);double c=baseGas[j]*mean;change=std::max(change,std::abs(c-e.c)/std::max(c,e.c));e.c=c;}
        for(std::size_t j=0;j<s.vents.size();++j){auto& e=s.vents[j];double c=baseVent[j]*LogMean(s.local[e.i].d,1.);change=std::max(change,std::abs(c-e.c)/std::max(c,e.c));e.c=c;}
        ++result.gasIterations;
        if(change<1e-10){convergedGas=true;break;}
    }
    if(!convergedGas)return Fail(error,"bulk finite gas conductance iteration exhausted");
    if(!s.Evaluate(x,error))return false;
    result.maximumVolumeResidual=s.Norm();
    if(result.maximumVolumeResidual>1e-10)return Fail(error,"bulk original pressure/volume residual failed");
    WaterBulkState next=source;next.faceInertance=s.inertance;
    for(std::size_t i=0;i<n;++i){next.water[i]=source.water[i];next.gas[i]=source.gas[i];next.gasMass[i]=source.gasMass[i];}
    for(std::size_t f=0;f<nf;++f){auto e=s.water[f];Real q(s.q[f]);next.water[e.l]=next.water[e.l]-q;next.water[e.r]=next.water[e.r]+q;next.gas[e.l]=next.gas[e.l]+q;next.gas[e.r]=next.gas[e.r]-q;next.faceRate[f]=q.Value()/settings.dt;}
    for(std::size_t j=0;j<s.gas.size();++j){auto e=s.gas[j];Real m=Real(settings.referenceDensity)*Real(s.z[j]);next.gasMass[e.l]=next.gasMass[e.l]-m;next.gasMass[e.r]=next.gasMass[e.r]+m;result.gasDissipation+=s.z[j]*(settings.referencePressure*std::log(s.initialPressure[e.l]/s.initialPressure[e.r])+x[n+e.l]-x[n+e.r]);}
    for(std::size_t j=0;j<s.vents.size();++j){auto e=s.vents[j];Real m=Real(settings.referenceDensity)*Real(s.v[j]);next.gasMass[e.i]=next.gasMass[e.i]-m;next.externalGasMass=next.externalGasMass+m;result.gasDissipation+=s.v[j]*(settings.referencePressure*std::log(s.initialPressure[e.i]/settings.referencePressure)+x[n+e.i]);}
    WaterBulkAudit after;if(!AuditWaterBulkStorage(geom,next,settings,after,error))return false;
    result.sourceEnergy=before.potentialEnergy+before.kineticEnergy;result.endEnergy=after.potentialEnergy+after.kineticEnergy;
    for(std::size_t f=0;f<nf;++f){double delta=next.faceRate[f]-source.faceRate[f];result.inertialLoss+=.5*s.inertance[f]*delta*delta;}
    result.elapsedMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count();
    output=std::move(next);stats=result;error.clear();return true;
}
} // namespace judas::volume_grid
