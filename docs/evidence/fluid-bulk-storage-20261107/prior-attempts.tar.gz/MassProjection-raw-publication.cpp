#include "WaterBulkProjection.h"
#include "WaterGasGeometry.h"
#include "CutCoupledKrylov.h"
#include "WaterPressureILU.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <limits>
#include <map>

namespace judas::volume_grid {
namespace {
using Real = CutCompensated;
bool Fail(std::string& e, const char* why) { e = why; return false; }
struct Link { std::size_t l, r; double c; };
struct Vent { std::size_t i; double c; };
struct Local {
    Real water, gas, mass, pressure;
    double wh = 0., wm = 0., ph = 0., pm = 0.;
};
Real Root(Real a) {
    Real x(std::sqrt(a.Value()));
    if (x.Value() > 0.) x = x + (a-x*x)/(Real(2.)*x);
    return x;
}
struct System {
    const WaterBulkGeometry& geometry;
    const WaterBulkState& source;
    const WaterGasSettings& settings;
    std::vector<Real> head;
    std::vector<double> inertance, predictor;
    std::vector<Link> liquid, air;
    std::vector<Vent> vents;
    std::vector<bool> activeWater, activeAir;
    std::vector<Local> local;
    std::vector<Real> q, z, vent;
    std::vector<double> residual;
    std::vector<std::array<double,4>> airDerivative;
    std::vector<std::array<double,2>> ventDerivative;
    System(const WaterBulkGeometry& g, const WaterBulkState& s, const WaterGasSettings& c)
        : geometry(g), source(s), settings(c) {}

    bool Evaluate(const std::vector<Real>& x, std::string& error) {
        const auto n = geometry.capacity.size(); const double rt = settings.referencePressure/settings.referenceDensity;
        local.resize(n); std::vector<Real> water(n), mass(n);
        for (std::size_t i=0; i<n; ++i) {
            auto& l=local[i]; const Real c(geometry.capacity[i]), k(geometry.potentialSlope[i]);
            l.mass=source.gasMass[i]+Real(settings.referenceDensity)*Real(x[n+i]);
            if (l.mass.Value()<0. || !std::isfinite(l.mass.Value())) return Fail(error,"negative or nonfinite bulk air mass iterate");
            Real b=head[i]+Real(x[i])+Real(settings.referencePressure-geometry.potentialBase[i])-k*c;
            l.wh=l.wm=l.ph=l.pm=0.;
            if (!activeWater[i]) {
                l.water=source.water[i]; l.gas=source.gas[i];
                l.pressure=l.gas.Value()>0.?Real(rt)*l.mass/l.gas:Real();
                if (l.gas.Value()>0.) l.pm=settings.referencePressure/l.gas.Value();
            } else {
                // Solve the local EOS for positive gas volume directly from
                // independently owned mass. No subtraction of large pressure
                // heads to reconstruct a microscopic air layer is required.
                Real discriminant=Root(b*b+Real(4.)*k*Real(rt)*l.mass);
                if (l.mass.Value()>0.) {
                    l.gas=b.Value()>=0.?Real(2.*rt)*l.mass/(b+discriminant):(discriminant-b)/(Real(2.)*k);
                    l.pressure=Real(rt)*l.mass/l.gas;
                } else {
                    l.gas=b.Value()<0.?Real()-b/k:Real();
                    l.pressure=b.Value()>0.?b:Real();
                }
                if ((l.gas-c).Value()>=0.) {
                    l.gas=c; l.water=Real(); l.pressure=Real(rt)*l.mass/c;
                    l.pm=settings.referencePressure/c.Value();
                } else {
                    l.water=c-l.gas;
                    double d=discriminant.Value();
                    if (!(d>0. && std::isfinite(d))) return Fail(error,"degenerate bulk vacuum/front tangent");
                    l.wh=l.gas.Value()/d; l.wm=-settings.referencePressure/d;
                    l.ph=l.pressure.Value()/d; l.pm=geometry.potentialSlope[i]*settings.referencePressure/d;
                }
            }
            water[i]=l.water-source.water[i]; mass[i]=Real(x[n+i]);
        }
        q.resize(liquid.size()); z.resize(air.size()); vent.resize(vents.size());
        airDerivative.resize(air.size());ventDerivative.resize(vents.size());
        for (std::size_t f=0; f<liquid.size(); ++f) {
            auto e=liquid[f]; q[f]=Real(predictor[f])+Real(e.c)*(head[e.l]-head[e.r]+Real(x[e.l])-Real(x[e.r]));
            water[e.l]=water[e.l]+q[f]; water[e.r]=water[e.r]-q[f];
        }
        for (std::size_t f=0; f<air.size(); ++f) {
            auto e=air[f];double left=(local[e.l].gas/source.gas[e.l]).Value(),right=(local[e.r].gas/source.gas[e.r]).Value();
            double factor=std::min({1.,left,right});Real difference=local[e.l].pressure-local[e.r].pressure;
            double dl=left<1.&&left<=right?e.c*difference.Value()/source.gas[e.l].Value():0.;
            double dr=right<1.&&right<left?e.c*difference.Value()/source.gas[e.r].Value():0.;
            z[f]=Real(e.c*factor)*difference;
            airDerivative[f]={e.c*factor*local[e.l].ph-dl*local[e.l].wh,e.c*factor*local[e.l].pm-dl*local[e.l].wm,
                -e.c*factor*local[e.r].ph-dr*local[e.r].wh,-e.c*factor*local[e.r].pm-dr*local[e.r].wm};
            mass[e.l]=mass[e.l]+z[f]; mass[e.r]=mass[e.r]-z[f];
        }
        for (std::size_t f=0; f<vents.size(); ++f) {
            auto e=vents[f];double ratio=(local[e.i].gas/source.gas[e.i]).Value(),factor=std::min(1.,ratio);
            Real difference=local[e.i].pressure-Real(settings.referencePressure);
            double d=ratio<1.?e.c*difference.Value()/source.gas[e.i].Value():0.;vent[f]=Real(e.c*factor)*difference;
            ventDerivative[f]={e.c*factor*local[e.i].ph-d*local[e.i].wh,e.c*factor*local[e.i].pm-d*local[e.i].wm};
            mass[e.i]=mass[e.i]+vent[f];
        }
        residual.resize(2*n);
        for (std::size_t i=0; i<n; ++i) {
            residual[i]=water[i].Value()/geometry.capacity[i]; residual[n+i]=mass[i].Value()/geometry.capacity[i];
            if (!std::isfinite(residual[i]) || !std::isfinite(residual[n+i])) return Fail(error,"nonfinite bulk pressure residual");
        }
        return true;
    }
    double Norm() const { double result=0.; for(double r:residual) result=std::max(result,std::abs(r)); return result; }
    double Merit() const { Real sum; for(double r:residual) sum=sum+Real(r)*Real(r); return sum.Value(); }
    bool Linear(std::vector<double>& dx, std::size_t& applications, std::string& error) const {
        const auto n=geometry.capacity.size(); const auto count=2*n;
        std::vector<std::map<std::size_t,Real>> matrix(count);
        auto index=[&](std::size_t i){return i<n?2*i:2*(i-n)+1;};
        auto add=[&](std::size_t row,std::size_t column,Real value){
            auto& entry=matrix[index(row)][index(column)]; entry=entry+value/Real(geometry.capacity[row%n]);
        };
        for (std::size_t i=0; i<n; ++i) {
            add(i,i,Real(local[i].wh)); add(i,n+i,Real(local[i].wm)); add(n+i,n+i,Real(1.));
        }
        for (auto e:liquid) if(e.c>0.) {
            add(e.l,e.l,Real(e.c)); add(e.r,e.r,Real(e.c)); add(e.l,e.r,Real(-e.c)); add(e.r,e.l,Real(-e.c));
        }
        auto gasRow=[&](std::size_t row,std::size_t cell,double c){add(n+row,cell,Real(c*local[cell].ph));add(n+row,n+cell,Real(c*local[cell].pm));};
        // Freeze opening area only in the accelerator. The Krylov operator
        // below differentiates the actual changing aperture and checks J*x.
        for(auto e:air){double factor=std::min({1.,(local[e.l].gas/source.gas[e.l]).Value(),(local[e.r].gas/source.gas[e.r]).Value()});double c=e.c*factor;
            gasRow(e.l,e.l,c);gasRow(e.r,e.r,c);gasRow(e.l,e.r,-c);gasRow(e.r,e.l,-c);}
        for(auto e:vents){double c=e.c*std::min(1.,(local[e.i].gas/source.gas[e.i]).Value());gasRow(e.i,e.i,c);}
        for(std::size_t i=0;i<count;++i)if(matrix[i][i].Value()==0.)matrix[i][i]=Real(1.); // accelerator gauge only
        WaterPressureILU preconditioner; if(!preconditioner.Build(matrix,error))return false;
        auto precondition=[&](const std::vector<double>& rhs,std::vector<double>& result){
            std::vector<double> ordered(count),solved;for(std::size_t i=0;i<count;++i)ordered[index(i)]=rhs[i];
            if(!preconditioner.Apply(ordered,solved,error))return false;
            result.resize(count);for(std::size_t i=0;i<count;++i)result[i]=solved[index(i)];return true;
        };
        auto multiply=[&](const std::vector<double>& x,std::vector<double>& y){
            y.assign(count,0.);
            for(std::size_t i=0;i<n;++i){y[i]=local[i].wh*x[i]+local[i].wm*x[n+i];y[n+i]=x[n+i];}
            for(auto e:liquid){double q=e.c*(x[e.l]-x[e.r]);y[e.l]+=q;y[e.r]-=q;}
            for(std::size_t f=0;f<air.size();++f){auto e=air[f];auto d=airDerivative[f];double q=d[0]*x[e.l]+d[1]*x[n+e.l]+d[2]*x[e.r]+d[3]*x[n+e.r];y[n+e.l]+=q;y[n+e.r]-=q;}
            for(std::size_t f=0;f<vents.size();++f){auto e=vents[f];auto d=ventDerivative[f];y[n+e.i]+=d[0]*x[e.i]+d[1]*x[n+e.i];}
            for(std::size_t i=0;i<count;++i)y[i]/=geometry.capacity[i%n];
            return true;
        };
        std::vector<double> rhs=residual;for(double& r:rhs)r=-r;
        std::vector<Real> solution;CutKrylovStats stats;
        bool ok=SolveCutCoupledKrylov(rhs,multiply,precondition,solution,stats,error,40,8,1e-8);
        applications+=stats.applications;if(!ok)return false;
        dx.resize(count);for(std::size_t i=0;i<count;++i){dx[i]=solution[i].Value();if(i>=n&&!activeAir[i-n])dx[i]=0.;}
        return true;
    }
};
}
bool ProjectWaterBulk(const WaterBulkGeometry& geometry,const WaterBulkState& source,const WaterGasSettings& settings,
    WaterBulkState& output,WaterBulkProjectionStats& stats,std::string& error) {
    auto started=std::chrono::steady_clock::now();WaterBulkProjectionStats work;
    struct Diagnostic { WaterBulkProjectionStats& out; WaterBulkProjectionStats& work; std::chrono::steady_clock::time_point start;
        ~Diagnostic(){work.elapsedMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();out=work;}
    } diagnostic{stats,work,started};
    WaterBulkAudit before;if(!(settings.dt>0.&&std::isfinite(settings.dt))||!AuditWaterBulkStorage(geometry,source,settings,before,error))return false;
    const auto n=geometry.capacity.size();const auto nf=geometry.field.geometry.faces.size();System s(geometry,source,settings);
    s.head.resize(n);s.inertance.resize(nf);s.predictor.resize(nf);s.activeWater.assign(n,false);s.activeAir.assign(n,false);
    auto field=geometry.field;
    for(std::size_t i=0;i<n;++i){field.water[i]=source.water[i].Value();field.gas[i]=source.gas[i].Value();field.gasMass[i]=source.gasMass[i].Value();}
    std::vector<CutRegionWaterPlane> planes;WaterGasGeometry gas;
    if(!ReconstructCutRegionPhasePlanes(field.chart,field.geometry,geometry.upAxis,field.water,field.gas,{},planes,error)||
        !PrepareWaterGasGeometry(field,planes,settings,1.8e-5,gas,error))return false;
    for(std::size_t f=0;f<nf;++f){auto face=field.geometry.faces[f];auto l=face.left,r=face.right;int a=face.axis;
        double length=.5*(field.chart.regions[l].hi[a]-field.chart.regions[l].lo[a]+field.chart.regions[r].hi[a]-field.chart.regions[r].lo[a]);
        auto phase=MeasureCutRegionFacePhase(face,{},planes[l],planes[r]);
        double area=.5*(phase.wet[0].start+phase.wet[1].start);
        double inertance=area>0.?geometry.density*length/area:0.;
        s.inertance[f]=inertance;s.liquid.push_back({l,r,inertance>0.?settings.dt*settings.dt/inertance:0.});
        s.predictor[f]=source.faceRate[f]*settings.dt;if(inertance>0.)s.activeWater[l]=s.activeWater[r]=true;
    }
    for(auto link:gas.links){auto l=gas.nodeCell[link.left],r=gas.nodeCell[link.right];s.air.push_back({l,r,settings.dt*link.massConductance/settings.referenceDensity});s.activeAir[l]=s.activeAir[r]=true;}
    for(auto vent:gas.vents){auto i=gas.nodeCell[vent.node];s.vents.push_back({i,settings.dt*vent.massConductance/settings.referenceDensity});s.activeAir[i]=true;}
    std::vector<Real> x(2*n);double wetHead=-std::numeric_limits<double>::infinity();
    for(std::size_t i=0;i<n;++i){double p=source.gasMass[i].Value()>0.?(source.gasMass[i]/source.gas[i]).Value()*settings.referencePressure/settings.referenceDensity:0.;
        s.head[i]=Real(geometry.potentialBase[i])+Real(geometry.potentialSlope[i])*source.water[i]+Real(p)-Real(settings.referencePressure);
        if(source.water[i].Value()>0.)wetHead=std::max(wetHead,geometry.potentialBase[i]+geometry.potentialSlope[i]*source.water[i].Value());}
    for(std::size_t i=0;i<n;++i)if(source.gas[i].Value()==0.&&source.water[i].Value()>0.)x[i]=Real(wetHead)-s.head[i];
    for(std::size_t iteration=0;iteration<48;++iteration){
        if(!s.Evaluate(x,error))return false;
        double norm=s.Norm();work.maximumVolumeResidual=norm;
        if(settings.trace)std::cerr<<"BULK_MASS_ITER iteration="<<iteration<<" residual="<<norm<<" linear="<<work.linearIterations<<std::endl;
        if(norm<1e-11)break;
        std::vector<double> dx;if(!s.Linear(dx,work.linearIterations,error))return false;
        auto previous=x;double merit=s.Merit();bool accepted=false;
        for(int j=0;j<48;++j){double fraction=std::ldexp(1.,-j);for(std::size_t i=0;i<x.size();++i)x[i]=previous[i]+Real(fraction)*Real(dx[i]);
            std::string trial;if(s.Evaluate(x,trial)&&s.Merit()<merit*(1.-1e-4*fraction)){accepted=true;break;}}
        if(!accepted)return Fail(error,"bulk mass/head line search stagnated");
        ++work.newtonIterations;if(iteration==47)return Fail(error,"bulk mass/head nonlinear budget exhausted");
    }
    WaterBulkState next=source;next.faceInertance=s.inertance;
    for(std::size_t f=0;f<nf;++f){auto e=s.liquid[f];auto q=s.q[f];next.water[e.l]=next.water[e.l]-q;next.water[e.r]=next.water[e.r]+q;next.gas[e.l]=next.gas[e.l]+q;next.gas[e.r]=next.gas[e.r]-q;next.faceRate[f]=q.Value()/settings.dt;}
    for(std::size_t f=0;f<s.air.size();++f){auto e=s.air[f];Real m=Real(settings.referenceDensity)*s.z[f];next.gasMass[e.l]=next.gasMass[e.l]-m;next.gasMass[e.r]=next.gasMass[e.r]+m;}
    for(std::size_t f=0;f<s.vents.size();++f){auto e=s.vents[f];Real m=Real(settings.referenceDensity)*s.vent[f];next.gasMass[e.i]=next.gasMass[e.i]-m;next.externalGasMass=next.externalGasMass+m;}
    WaterBulkAudit after;if(!AuditWaterBulkStorage(geometry,next,settings,after,error))return false;
    work.sourceEnergy=before.potentialEnergy+before.kineticEnergy;work.endEnergy=after.potentialEnergy+after.kineticEnergy;
    output=std::move(next);error.clear();return true;
}
}
