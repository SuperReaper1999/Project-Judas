from pathlib import Path
import subprocess,time,json
c=Path(__file__).resolve().parent;r=c.parents[1];out=c/'baseline';out.mkdir(exist_ok=True);results=[]
for case in ['half_020','half_025','rotated_half','light_80kg']:
 command=[str(c/'baseline-window'),'--case',case,'--output',str(out/case)];start=time.monotonic()
 with (out/(case+'.log')).open('w') as log:code=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 results.append({'case':case,'command':command,'exit_code':code,'seconds':time.monotonic()-start});(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(case,code,flush=True)
