from pathlib import Path
p=Path('tests/ProductionFluidTests.cpp');s=p.read_text();s=s.replace('#include "Project.h"','#include "Project.h"\n#include "FluidSettlingContract.h"',1)
s=s.replace('bool strictDiagnostics=false;std::string selectedCase;','bool strictDiagnostics=false,legacyFourSecond=false,strictLegacySettling=false;int legacyComparisons=0,legacyFailures=0;std::string selectedCase;',1)
s=s.replace('<<" steps="<<totalSteps<<\'\\n\';}', '<<" steps="<<totalSteps<<" settling_mode="<<(legacyFourSecond?"legacy_four_second":"window_decay")<<" legacy_comparisons="<<legacyComparisons<<" legacy_failures="<<legacyFailures<<\'\\n\';}',1)
needle='Result result;std::vector<double> executed,particleTimes;double totalMs=0,mean=0,observedMean=0;int meanCount=0;const int count=240;'
replacement='''std::optional<FluidTest::SettlingContract> settling;
 if(densityRatio==.5f && !observationalScale && !legacyFourSecond)
  settling=FluidTest::SettlingContract::Make(world.FluidSettingsUsed().hydrostaticDragRate,densityRatio,dt);
 FluidTest::WindowMotion earlyMotion,lateMotion;
 float legacyV4=0,legacyY4=0;
 Result result;std::vector<double> executed,particleTimes;double totalMs=0,mean=0,observedMean=0;int meanCount=0;
 const int count=settling?static_cast<int>(settling->late.end):240;'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
a=s.index('  if(step>=180){');b=s.index('  if(m.executed)',a)
s=s[:a]+'''  const bool originalMean=step>=180 && step<240;
  const bool lateSample=settling && settling->late.Contains(static_cast<std::size_t>(step));
  std::optional<double> observedFraction;
  if(originalMean || lateSample){
   // Independent exterior surface and dense rectangular quadrature. Keep the
   // original 3-4 second oracle and also cover every late-window observation.
   const auto observedSurface=ObservedSurface(world.Fluid().Particles(),q,local,half,spacing,nx);
   if(observedSurface){
    int wet=0;constexpr int n=32;
    for(int z=0;z<n;++z)for(int y=0;y<n;++y)for(int x=0;x<n;++x){
     const glm::vec3 offset=half*(glm::vec3(2*x+1,2*y+1,2*z+1)/float(n)-1.0f);
     const glm::vec3 point=glm::conjugate(q)*(pose.position+pose.rotation*offset);
     if(point.y<*observedSurface)++wet;
    }
    observedFraction=static_cast<double>(wet)/(n*n*n);
   }
  }
  if(originalMean){mean+=d->fraction;++meanCount;if(observedFraction)observedMean+=*observedFraction;}
  if(settling && settling->early.Contains(static_cast<std::size_t>(step)))earlyMotion.Add(local.y,localV.y,d->fraction);
  if(lateSample)lateMotion.Add(local.y,localV.y,d->fraction,observedFraction.has_value(),observedFraction.value_or(0));
  if(step==239){legacyV4=localV.y;legacyY4=local.y;}
'''+s[b:]
s=s.replace('if(step==9||step==239)snapshot(', 'if(step==9||step==239||(settling&&step==count-1))snapshot(',1)
needle='  expectation(std::abs(result.finalV)<.5f,name+" settles rather than passing through desired immersion");'
replacement='''  const bool legacyPass=std::abs(legacyV4)<.5f;
  ++legacyComparisons;if(!legacyPass)++legacyFailures;
  std::cout<<std::setprecision(17)<<"LEGACY_SETTLING "<<name<<" status="<<(legacyPass?"PASS":"FAIL")<<" time=4 limit=0.5 y="<<legacyY4<<" vy="<<legacyV4<<'\\n';
  if(!settling || strictLegacySettling)
   expectation(legacyPass,name+" settles rather than passing through desired immersion");
  if(settling){
   const auto verdict=FluidTest::Assess(*settling,earlyMotion,lateMotion,std::sqrt(std::abs(g)*half.y));
   Check(verdict.coverage,name+" complete valid early/late settling observations");
   Check(verdict.peak,name+" peak vertical speed below 0.5 m/s over the late window");
   Check(verdict.rmsDecay,name+" late RMS vertical speed decays by at least half");
   Check(verdict.rangeDecay,name+" late vertical travel range decays by at least half");
   Check(verdict.immersion,name+" late sampled equilibrium immersion within 10 percentage points");
   Check(verdict.independentImmersion,name+" late independent equilibrium immersion within 10 percentage points");
   std::cout<<"SETTLING_WINDOW "<<name<<" tau="<<settling->timeConstant
    <<" early_begin="<<settling->early.first*double(dt)<<" early_end="<<settling->early.end*double(dt)
    <<" late_begin="<<settling->late.first*double(dt)<<" late_end="<<settling->late.end*double(dt)
    <<" early_rms="<<earlyMotion.Rms()<<" late_rms="<<lateMotion.Rms()<<" late_peak="<<lateMotion.peakSpeed
    <<" early_range="<<earlyMotion.Range()<<" late_range="<<lateMotion.Range()
    <<" sampled_fraction="<<lateMotion.MeanImmersion()<<" observed_fraction="<<lateMotion.MeanIndependent()<<'\\n';
   std::ofstream report(out/(name+"_settling.json"));report<<std::setprecision(17)<<std::boolalpha
    <<"{\\n  \\"schema\\": 1,\\n  \\"time_constant_seconds\\": "<<settling->timeConstant
    <<",\\n  \\"legacy_four_second_pass\\": "<<legacyPass<<",\\n  \\"legacy_v4\\": "<<legacyV4
    <<",\\n  \\"early_rms\\": "<<earlyMotion.Rms()<<",\\n  \\"late_rms\\": "<<lateMotion.Rms()
    <<",\\n  \\"early_range\\": "<<earlyMotion.Range()<<",\\n  \\"late_range\\": "<<lateMotion.Range()
    <<",\\n  \\"late_peak\\": "<<lateMotion.peakSpeed<<",\\n  \\"coverage_pass\\": "<<verdict.coverage
    <<",\\n  \\"peak_pass\\": "<<verdict.peak<<",\\n  \\"rms_decay_pass\\": "<<verdict.rmsDecay
    <<",\\n  \\"range_decay_pass\\": "<<verdict.rangeDecay<<",\\n  \\"immersion_pass\\": "<<verdict.immersion
    <<",\\n  \\"independent_immersion_pass\\": "<<verdict.independentImmersion<<"\\n}\\n";
  }'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('else if(std::string(argv[i])=="--strict-diagnostics")strictDiagnostics=true;', 'else if(std::string(argv[i])=="--strict-diagnostics")strictDiagnostics=true;else if(std::string(argv[i])=="--legacy-four-second")legacyFourSecond=true;else if(std::string(argv[i])=="--strict-legacy-settling")strictLegacySettling=true;',1)
p.write_text(s)
