from pathlib import Path
import hashlib,json,gzip,shutil,subprocess,datetime,platform
r=Path.cwd();c=r/'.cache/fluid-window-contract-20261101';e=r/'docs/evidence/fluid-window-contract-20261101';e.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,dest):
 dest.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix in {'.json'}:shutil.copyfile(p,dest)
 else:dest.with_name(dest.name+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in c.rglob('*'):
 if p.is_file() and p.name not in {'baseline-window'}:copy(p,e/'run'/p.relative_to(c))
source=['tests/FluidSettlingContract.h','tests/FluidSettlingContractTests.cpp','tests/FluidSettlingReferenceTests.cpp','tests/ProductionFluidTests.cpp','CMakeLists.txt','tools/validation/suites.json','docs/FLUID_WINDOW_DECAY_CONTRACT.md','docs/FLUID_SETTLING_CAUSE_REVIEW.md','docs/FLUID_VERTICAL_GEOMETRY_CANDIDATE.md']
for name in source:copy(r/name,e/'source'/name)
# Preserve the substituted baseline source as well as its exact object fingerprint.
base=r/'.cache/fluid-vertical-support-20261101/baseline'
for name in ['FluidHydrostatics.cpp','FluidHydrostatics.h','FluidSolidSupport.h','FluidWetFootprint.h']:copy(base/name,e/'baseline-source'/name)
prev=json.loads((r/'.cache/fluid-settling-cause-20261101/FINAL_PROVENANCE.json').read_text())['unchanged_physics_sha256'];unchanged={}
for name,h in prev.items():
 if name.startswith('src/'):
  assert digest(r/name)==h,name
  unchanged[name]=h
pre=json.loads((c/'SOURCE_UNCHANGED_DURING_QUALIFICATION.json').read_text())
for name,h in pre.items():assert digest(r/name)==h,name
bins={n:digest(r/'.cache/2d-stage1-build'/n) for n in ['judas_production_fluid_tests','judas_fluid_settling_contract_tests','judas_fluid_settling_reference_tests','judas_fluid_vertical_support_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests']}
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
p={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'main':git('rev-parse','main'),'origin_experimental':git('rev-parse','origin/Experimental'),'origin_main':git('rev-parse','origin/main'),'index_empty':not bool(git('diff','--cached','--name-only')),'status':'Uncommitted, six new-contract mandatory failures. No fluid unlock.','source_sha256':{n:digest(r/n) for n in source},'unchanged_production_source_sha256':unchanged,'binary_sha256':bins,'baseline_object_sha256':digest(r/'.cache/fluid-vertical-support-20261101/baseline-hydro.o'),'baseline_binary_sha256':digest(c/'baseline-window'),'compiler':subprocess.check_output(['c++','--version'],text=True).splitlines()[0],'platform':platform.platform(),'reference_log':'run/reference-final.log.gz','reference_note':'Final 81-check reference supersedes initial 69-check run; both logs preserved.'}
assert p['index_empty'];(e/'FINAL_PROVENANCE.json').write_text(json.dumps(p,indent=2)+'\n')
(e/'README.txt').write_text('Fluid window/decay contract — 2026-11-01\n\nRead ../../FLUID_WINDOW_DECAY_CONTRACT.md for interpretation.\nrun/DECLARED_CONTRACT.json predates fresh qualification.\nrun/qualification/RESULTS.json records expected failures and binary hashes.\nrun/qualification contains complete raw per-step observations and snapshots.\nrun/baseline contains the diagnostic reconstruction-substitution comparison.\nrun/BASELINE_LINK_RECIPE.json describes that limited baseline, not a full old build.\nrun/LEGACY_EQUIVALENCE.json and run/STRICT_FLAG_EQUIVALENCE.json preserve replay evidence.\nrun/before retains the original production driver and 69-check reference source.\nrun/reference-final.log.gz records final 81-check native/reference result.\nrun/*.py.gz preserve executable qualification/comparison scripts; decompress before running.\nsource/ preserves final test, registration and report sources.\nFINAL_PROVENANCE.json identifies unchanged production code and tested binaries.\nAll non-JSON text snapshots are gzip with mtime=0. No binaries are bundled.\nSHA256SUMS.json covers all files except itself.\n\nExpected remaining failures: four late independent-immersion mismatches,\nplus coarse half_025 late peak and range decay. Original four-second\nfailures remain reproducible. No tolerances retuned after observing results.\nNo main changes, commit, push, unlock, publication or research modifications.\n')
manifest={str(p.relative_to(e)):digest(p) for p in sorted(e.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(e/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,h in manifest.items():assert digest(e/name)==h,name
print('Archived and verified',len(manifest),'files;',sum(p.stat().st_size for p in e.rglob('*') if p.is_file()),'bytes')
print('Head:',p if False else git('rev-parse','HEAD'))
