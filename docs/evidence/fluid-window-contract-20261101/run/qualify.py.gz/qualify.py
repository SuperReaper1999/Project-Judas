from pathlib import Path
import subprocess,json,time,hashlib
c=Path(__file__).resolve().parent;r=c.parents[1];b=r/'.cache/2d-stage1-build';out=c/'qualification';out.mkdir(exist_ok=True)
source={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ['tests/ProductionFluidTests.cpp','tests/FluidSettlingContract.h','tests/FluidSettlingContractTests.cpp','src/FluidHydrostatics.cpp','src/ProductionFluidCoupling.cpp']};(c/'PRE_RUN_SOURCE_HASHES.json').write_text(json.dumps(source,indent=2)+'\n')
checks=[('window-full','judas_production_fluid_tests',['--output',str(out/'window-full')]),('legacy-full','judas_production_fluid_tests',['--legacy-four-second','--output',str(out/'legacy-full')]),('strict-legacy','judas_production_fluid_tests',['--strict-legacy-settling','--case','half_020','--output',str(out/'strict-legacy')]),('strict-subparticle','judas_production_fluid_tests',['--strict-diagnostics','--case','small_mass_125x','--output',str(out/'strict-subparticle')]),('contract-controls','judas_fluid_settling_contract_tests',[]),('physical-reference','judas_fluid_settling_reference_tests',[]),('vertical','judas_fluid_vertical_support_tests',[]),('hydrostatics','judas_fluid_hydrostatics_tests',[]),('lateral','judas_fluid_wet_support_tests',[])]
results=[]
for name,target,args in checks:
 command=[str(b/target),*args];start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((b/target).read_bytes()).hexdigest()});(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True)
for n,h in source.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
(c/'SOURCE_UNCHANGED_DURING_QUALIFICATION.json').write_text(json.dumps(source,indent=2)+'\n')
