from pathlib import Path
import csv,json,hashlib,re
c=Path(__file__).resolve().parent;r=c.parents[1];q=c/'qualification';old=r/'.cache/fluid-vertical-support-20261101/qualification/production'
cases=['half_020','neutral_020','dense_020','half_025','neutral_025','dense_025','rotated_half','zero_gravity','common_freefall','small_mass_125x','light_80kg']
timing={'fluid_step_ms','total_coupling_ms'};comparisons={}
for name in cases:
 def read(p):return list(csv.DictReader(p.open()))
 a=read(old/(name+'.csv'));b=read(q/'legacy-full'/(name+'.csv'));d=read(q/'window-full'/(name+'.csv'));keys=[k for k in a[0] if k not in timing]
 legacy_exact=len(a)==len(b) and all(all(x[k]==y[k] for k in keys) for x,y in zip(a,b))
 prefix_exact=len(d)>=len(b) and all(all(x[k]==y[k] for k in keys) for x,y in zip(b,d))
 snapshots={}
 for suffix in ['release_body','release_particles','step10_body','step10_particles','step240_body','step240_particles']:
  paths=[p/(name+'_'+suffix+'.csv') for p in [old,q/'legacy-full',q/'window-full']];assert all(p.exists() for p in paths),paths
  snapshots[suffix]=len({hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})==1
 comparisons[name]={'legacy_rows':len(b),'window_rows':len(d),'legacy_matches_old_physics':legacy_exact,'window_prefix_matches_legacy':prefix_exact,'snapshot_bytes_exact':snapshots}
 assert legacy_exact and prefix_exact and all(snapshots.values()),name
(c/'LEGACY_EQUIVALENCE.json').write_text(json.dumps({'excluded_timing_columns':sorted(timing),'compared_fields':keys,'cases':comparisons},indent=2)+'\n')
settling={}
for name in ['half_020','half_025','rotated_half','light_80kg']:
 metrics=json.loads((q/'window-full'/(name+'_settling.json')).read_text());assert metrics['early_samples']==120 and metrics['late_samples']==metrics['late_independent_samples']==240
 settling[name]=metrics
(c/'WINDOW_RESULTS.json').write_text(json.dumps(settling,indent=2)+'\n')
a=read(q/'window-full/half_020.csv');b=read(q/'strict-legacy/half_020.csv');assert all(all(x[k]==y[k] for k in keys) for x,y in zip(a,b)) and len(a)==len(b)
default_failures=int(re.search(r'CASE half_020 failures=(\d+)',(q/'window-full.log').read_text())[1]);strict_failures=int(re.search(r'CASE half_020 failures=(\d+)',(q/'strict-legacy.log').read_text())[1]);assert strict_failures==default_failures+1
(c/'STRICT_FLAG_EQUIVALENCE.json').write_text(json.dumps({'rows':len(a),'all_physical_fields_exact':True,'default_case_failures':default_failures,'strict_case_failures':strict_failures,'additional_failure_due_to_original_legacy_comparison':True,'note':'Both runs still exit nonzero because the candidate also fails the new independent-immersion check.'},indent=2)+'\n')
print('Legacy and prefix equivalence verified for',len(cases),'cases and',sum(len(v['snapshot_bytes_exact']) for v in comparisons.values()),'snapshot triplets')
for name,m in settling.items():print(name,{k:v for k,v in m.items() if k.endswith('_pass')})
