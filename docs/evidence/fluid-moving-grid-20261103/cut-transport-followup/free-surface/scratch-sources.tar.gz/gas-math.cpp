#include "GasPocketMath.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
using namespace judas::volume_grid;
int main() {
    std::cout << std::setprecision(17);
    for (double initial : {.534,.168}) {
        const double finish = initial-.006;
        const auto p=MeanGasPressure(initial,finish,101325.,101325.);
        const auto high=MeanGasPressure(initial,finish+1e-7,101325.,101325.);
        const auto low=MeanGasPressure(initial,finish-1e-7,101325.,101325.);
        const double fd=(high.gauge-low.gauge)/2e-7;
        const long double end = 101325.L * std::pow((long double)initial/finish, 1.4L);
        const long double potential = (end*finish-101325.L*initial)/.4L + 101325.L*(finish-initial);
        const auto work = p.gauge*(initial-finish);
        const auto relativeDerivative = std::abs(fd-p.slope)/std::abs(p.slope);
        std::cout << initial << ' ' << p.gauge << ' ' << p.slope << " relative_diff " << relativeDerivative
            << " work_error " << double(potential-work) << '\n';
        if (!(std::abs(potential-work)<1e-9 && relativeDerivative < 1e-5)) return 1;
    }
}
