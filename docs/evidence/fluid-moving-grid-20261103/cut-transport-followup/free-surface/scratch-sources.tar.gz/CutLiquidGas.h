#pragma once

#include "CutLiquid.h"
#include "VentTopology.h"

namespace judas::volume_grid {

bool TrialCutLiquidGas(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                       const CutLiquidState& state, double dt, int up, double gravity,
                       const VentTopology* topology, CutLiquidTrial& result,
                       std::vector<double>& meanGauge, std::string& error);

} // namespace judas::volume_grid
