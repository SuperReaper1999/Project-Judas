#include "BasinFixture.h"
#include "CutLiquid.h"

#include <chrono>
#include <iostream>
#include <string_view>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

std::pair<double, double> Energy(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                                const CutLiquidState& state) {
    std::vector<double> planes;
    std::string error;
    if (!ReconstructCutRegionWaterPlanes(chart, geometry, 1, state.water, planes, error))
        throw std::runtime_error(error);
    long double potential = 0., kinetic = 0.;
    for (std::size_t i = 0; i < chart.regions.size(); ++i) {
        const auto& r = chart.regions[i];
        const double height = std::clamp(planes[i], r.lo[1], r.hi[1]);
        const double area = (r.hi[0] - r.lo[0]) * (r.hi[2] - r.lo[2]);
        double moment = (height - r.lo[1]) * (.5 * (height + r.lo[1])) * area;
        if (geometry.motion) {
            const auto& solid = *geometry.motion;
            const double lower = std::max(r.lo[1], solid.lo[1]);
            const double upper = std::max(lower, std::min(height, solid.hi[1]));
            const auto areaOn = [&](int axis) {
                return std::max(0., std::min(r.hi[axis], solid.hi[axis]) - std::max(r.lo[axis], solid.lo[axis]));
            };
            moment -= (upper - lower) * (.5 * (upper + lower)) * areaOn(0) * areaOn(2);
        }
        potential += 1000. * double(gravity) * moment;
    }
    for (std::size_t i = 0; i < geometry.faces.size(); ++i) {
        const auto& face = geometry.faces[i];
        const double velocity = state.faceSpeed[i];
        if (velocity == 0.)
            continue;
        const auto phase = MeasureCutRegionFacePhase(face, geometry.motion, 1, planes[face.left], planes[face.right]);
        const double area = phase.wet[velocity > 0. ? 0 : 1].mean;
        kinetic += .5 * (1000. * face.length * area) * velocity * velocity;
    }
    return {static_cast<double>(potential), static_cast<double>(kinetic)};
}

int main(int argc, char** argv) {
    bool rotated = false, equilibrium = false;
    int steps = 1;
    double dt = double(tick);
    for (int i = 1; i < argc; ++i) {
        const std::string_view option(argv[i]);
        if (option == "--rotated") rotated = true;
        else if (option == "--equilibrium") equilibrium = true;
        else if (option == "--substep") dt *= .25;
        else if (option == "--steps" && i + 1 < argc) steps = std::stoi(argv[++i]);
        else return 2;
    }
    const auto fixture = Fixture::Authored(rotated);
    const auto box = fixture.InitialBox();
    CutRegionChart chart;
    CutRegionGeometry geometry;
    std::string error;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), box,
                               {-.005, -.015, -.005}, {.005, .025, .005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error)) {
        std::cerr << "FAIL " << error << '\n';
        return 1;
    }
    CutLiquidState state;
    if (equilibrium) {
        for (const auto& region : chart.regions) {
            auto upper = region.hi;
            upper[1] = std::min(upper[1], 2.2);
            state.water.push_back(CutRegionClippedVolume(region, geometry.motion, region.lo, upper));
        }
    } else {
        SeedImport seed;
        if (!WaterByRegion(fixture, chart, geometry, rotated, state.water, seed, error)) {
            std::cerr << "FAIL " << error << '\n';
            return 1;
        }
    }
    state.faceSpeed.resize(geometry.faces.size());
    std::cout << std::setprecision(17);
    std::cout << "BEGIN level=" << !rotated << " equilibrium=" << equilibrium << " dt=" << dt
        << " volume=" << double(std::accumulate(state.water.begin(), state.water.end(), 0.L))
        << " cuts=" << chart.regions.size() << " faces=" << geometry.faces.size() << '\n';
    const auto initial = Energy(chart, geometry, state);
    for (int i = 0; i < steps; ++i) {
        CutLiquidTrial result;
        const auto start = std::chrono::steady_clock::now();
        const bool ok = TrialCutLiquid(chart, geometry, state, dt, 1, double(gravity), result, error);
        const auto elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start);
        if (!ok) {
            std::cerr << "FAIL step=" << i << " ms=" << elapsed.count() << " " << error << '\n';
            return 1;
        }
        const auto energy = Energy(chart, geometry, result.state);
        std::cout << "PASS step=" << i << " residual=" << result.residual
                  << " water_drift=" << result.waterDrift
                  << " speed=" << result.maximumFaceSpeed
                  << " iterations=" << result.iterations << '/' << result.linearIterations
                  << " dP=" << energy.first - initial.first << " dK=" << energy.second - initial.second
                  << " total_energy_change=" << (energy.first - initial.first) + (energy.second - initial.second)
                  << " ms=" << elapsed.count() << '\n';
        state = std::move(result.state);
    }
}
