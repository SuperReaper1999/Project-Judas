#include "AnchoredDry.h"
#include "BasinFixture.h"
#include "CutLiquidGas.h"

#include <chrono>
#include <iostream>
#include <string_view>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

std::pair<double, double> Energy(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                                const CutLiquidState& state) {
    std::vector<double> planes;
    std::string error;
    if (!ReconstructCutRegionWaterPlanes(chart, geometry, 1, state.water, planes, error))
        throw std::runtime_error(error);
    long double potential = 0., kinetic = 0.;
    for (std::size_t i = 0; i < chart.regions.size(); ++i) {
        const auto& r = chart.regions[i];
        const double height = std::clamp(planes[i], r.lo[1], r.hi[1]);
        const double area = (r.hi[0] - r.lo[0]) * (r.hi[2] - r.lo[2]);
        double moment = (height - r.lo[1]) * (.5 * (height + r.lo[1])) * area;
        if (geometry.motion) {
            const auto& solid = *geometry.motion;
            const double lower = std::max(r.lo[1], solid.lo[1]);
            const double upper = std::max(lower, std::min(height, solid.hi[1]));
            const auto areaOn = [&](int axis) {
                return std::max(0., std::min(r.hi[axis], solid.hi[axis]) - std::max(r.lo[axis], solid.lo[axis]));
            };
            moment -= (upper - lower) * (.5 * (upper + lower)) * areaOn(0) * areaOn(2);
        }
        potential += 1000. * double(gravity) * moment;
    }
    for (std::size_t i = 0; i < geometry.faces.size(); ++i) {
        const auto& face = geometry.faces[i];
        const double velocity = state.faceSpeed[i];
        if (velocity == 0.)
            continue;
        const auto phase = MeasureCutRegionFacePhase(face, geometry.motion, 1, planes[face.left], planes[face.right]);
        const double area = phase.wet[velocity > 0. ? 0 : 1].mean;
        kinetic += .5 * (1000. * face.length * area) * velocity * velocity;
    }
    return {static_cast<double>(potential), static_cast<double>(kinetic)};
}

VentTopology ExtendGasFrontier(const CutRegionGeometry& geometry, const VentTopology& initial) {
    auto extended = initial;
    std::vector<bool> contested(initial.regionComponent.size());
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.) continue;
        const auto left = initial.regionComponent[face.left], right = initial.regionComponent[face.right];
        if ((left == NoDryComponent) == (right == NoDryComponent))
            continue;
        const auto target = left == NoDryComponent ? face.left : face.right;
        const auto label = left == NoDryComponent ? right : left;
        const auto phase = MeasureCutRegionFacePhase(face, geometry.motion, 1,
                                                     initial.waterPlane[face.left], initial.waterPlane[face.right]);
        if (phase.dry[left == NoDryComponent ? 1 : 0].start == 0.)
            continue;
        auto& assigned = extended.regionComponent[target];
        if (assigned != NoDryComponent && assigned != label)
            contested[target] = true;
        assigned = label;
    }
    for (std::size_t region = 0; region < extended.regionComponent.size(); ++region) {
        if (initial.regionComponent[region] != NoDryComponent)
            continue;
        auto& component = extended.regionComponent[region];
        if (contested[region]) component = NoDryComponent;
        if (component != NoDryComponent)
            extended.components[component].regions.push_back(region);
    }
    return extended;
}

int main(int argc, char** argv) {
    bool rotated = false, equilibrium = false, allVented = false;
    int steps = 1;
    double dt = double(tick);
    for (int i = 1; i < argc; ++i) {
        const std::string_view option(argv[i]);
        if (option == "--rotated") rotated = true;
        else if (option == "--equilibrium") equilibrium = true;
        else if (option == "--all-vented") allVented = true;
        else if (option == "--substep") dt *= .25;
        else if (option == "--divisor" && i + 1 < argc) dt /= std::stod(argv[++i]);
        else if (option == "--steps" && i + 1 < argc) steps = std::stoi(argv[++i]);
        else return 2;
    }
    const auto fixture = Fixture::Authored(rotated);
    const auto box = fixture.InitialBox();
    CutRegionChart chart;
    CutRegionGeometry geometry;
    std::string error;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), box,
                               {-.005, -.015, -.005}, {.005, .025, .005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error)) {
        std::cerr << "FAIL " << error << '\n';
        return 1;
    }
    CutLiquidState state;
    if (equilibrium) {
        for (const auto& region : chart.regions) {
            auto upper = region.hi;
            upper[1] = std::min(upper[1], 2.2);
            state.water.push_back(CutRegionClippedVolume(region, geometry.motion, region.lo, upper));
        }
    } else {
        SeedImport seed;
        if (!WaterByRegion(fixture, chart, geometry, rotated, state.water, seed, error)) {
            std::cerr << "FAIL " << error << '\n';
            return 1;
        }
    }
    state.faceSpeed.resize(geometry.faces.size());
    std::cout << std::setprecision(17);
    std::cout << "BEGIN level=" << !rotated << " equilibrium=" << equilibrium << " dt=" << dt
        << " volume=" << double(std::accumulate(state.water.begin(), state.water.end(), 0.L))
        << " cuts=" << chart.regions.size() << " faces=" << geometry.faces.size() << '\n';
    const auto initial = Energy(chart, geometry, state);
    for (int i = 0; i < steps; ++i) {
        CutLiquidTrial result;
        VentTopology initialVents;
        const std::vector<VentBoundary> vents{FullChartVent(chart, 1, 1)};
        if (!allVented && !BuildVentTopology(chart, geometry, 1, state.water, vents, initialVents, error)) {
            std::cerr << "VENT FAIL " << error << '\n';
            return 1;
        }
        double largestChamber = 0.;
        std::size_t largestID = 0;
        for (std::size_t j = 1; j < initialVents.components.size(); ++j) {
            if (initialVents.components[j].volume > largestChamber) {
                largestChamber = initialVents.components[j].volume;
                largestID = j;
            }
        }
        const auto pressureVents = allVented ? VentTopology{} : ExtendGasFrontier(geometry, initialVents);
        std::vector<double> meanGauge;
        const auto start = std::chrono::steady_clock::now();
        const bool ok = TrialCutLiquidGas(chart, geometry, state, dt, 1, double(gravity),
                                          allVented ? nullptr : &pressureVents, result, meanGauge, error);
        const auto elapsed = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start);
        if (!ok) {
            std::cerr << "FAIL step=" << i << " ms=" << elapsed.count() << " " << error << '\n';
            return 1;
        }
        const auto energy = Energy(chart, geometry, result.state);
        std::cout << "PASS step=" << i << " residual=" << result.residual
                  << " water_drift=" << result.waterDrift
                  << " speed=" << result.maximumFaceSpeed
                  << " iterations=" << result.iterations << '/' << result.linearIterations
                  << " dP=" << energy.first - initial.first << " dK=" << energy.second - initial.second
                  << " total_energy_change=" << (energy.first - initial.first) + (energy.second - initial.second)
                  << " ms=" << elapsed.count() << '\n';
        if (!allVented) {
            VentTopology endingVents;
            if (!BuildVentTopology(chart, geometry, 1, result.state.water, vents, endingVents, error)) {
                std::cout << "REJECT ending topology: " << error << '\n';
                return 1;
            }
            std::cout << "GAS initial_closed=" << initialVents.components.size() - 1
                << " ending_closed=" << endingVents.components.size() - 1
                << " initial_largest_m3=" << largestChamber
                << " largest_initial_owner_mean_Pa=" << meanGauge[largestID] << '\n';
            for (std::size_t j = 1; j < endingVents.components.size() && j < 10; ++j)
                std::cout << "COMPONENT id=" << j << " volume=" << endingVents.components[j].volume
                    << " unresolved=" << endingVents.components[j].unresolvedVolume
                    << " regions=" << endingVents.components[j].regions.size() << '\n';
            std::vector<std::size_t> endingLabel(initialVents.components.size(), NoDryComponent);
            std::vector<std::size_t> startingLabel(endingVents.components.size(), NoDryComponent);
            bool joinedOrSplit = false;
            double newUnownedGas = 0.;
            for (std::size_t j = 0; j < state.water.size(); ++j) {
                const auto from = pressureVents.regionComponent[j], to = endingVents.regionComponent[j];
                if (from == NoDryComponent && to != NoDryComponent)
                    newUnownedGas += endingVents.regionVolume[j];
                if (from != NoDryComponent && from > 0 &&
                    initialVents.components[from].volume == initialVents.components[from].unresolvedVolume)
                    continue;
                if (to != NoDryComponent && to > 0 &&
                    endingVents.components[to].volume == endingVents.components[to].unresolvedVolume)
                    continue;
                if (from == NoDryComponent || to == NoDryComponent)
                    continue;
                if (to != 0 && endingVents.components[to].regions.front() == j)
                    std::cout << "LINEAGE from=" << from << " to=" << to << " root=" << j
                        << " bounds=" << chart.regions[j].lo[0] << "," << chart.regions[j].lo[1] << "," << chart.regions[j].lo[2] << '\n';
                if ((endingLabel[from] != NoDryComponent && endingLabel[from] != to) ||
                    (startingLabel[to] != NoDryComponent && startingLabel[to] != from))
                    joinedOrSplit = true;
                endingLabel[from] = to;
                startingLabel[to] = from;
            }
            std::cout << "GAS unowned_new_m3=" << newUnownedGas << " join_or_split=" << joinedOrSplit << '\n';
            if (!ReportAnchoredDry(chart, geometry, initialVents, pressureVents, endingVents, error))
                std::cout << "ANCHOR REJECT " << error << "\n";
            if (newUnownedGas != 0. || joinedOrSplit) {
                std::cout << "REJECT initial gas owners do not describe final geometry\n";
                return 1;
            }
        }
        state = std::move(result.state);
    }
}
