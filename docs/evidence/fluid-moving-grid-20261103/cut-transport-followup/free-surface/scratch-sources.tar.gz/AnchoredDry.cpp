#include "AnchoredDry.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>

namespace judas::volume_grid {
namespace {

struct DryBox {
    GridVec lo{}, hi{};
    double volume = 0.;
};

struct Inlet {
    double area = 0.;
    int axis = 1;
    bool lower = false;
};

bool Touches(const DryBox& dry, int axis, double face, bool fromLower) {
    return dry.volume > 0. && (fromLower ? dry.lo[axis] < face && dry.hi[axis] >= face
                                        : dry.hi[axis] > face && dry.lo[axis] <= face);
}

struct FacePhases {
    // Index bit 0 means the left side is dry, bit 1 the right side is dry.
    std::array<double, 4> area{};
};

FacePhases PartitionFace(const CutRegionFace& face, const std::optional<BoxMotion>& motion,
                         const DryBox& left, const DryBox& right) {
    const int a = (face.axis + 1) % 3, b = (face.axis + 2) % 3;
    const bool hasLeft = Touches(left, face.axis, face.lo[face.axis], true);
    const bool hasRight = Touches(right, face.axis, face.lo[face.axis], false);
    const auto cuts = [&](int axis) {
        std::array<double, 6> values{face.lo[axis], face.hi[axis],
                                    face.lo[axis], face.lo[axis], face.lo[axis], face.lo[axis]};
        if (hasLeft) {
            values[2] = std::clamp(left.lo[axis], face.lo[axis], face.hi[axis]);
            values[3] = std::clamp(left.hi[axis], face.lo[axis], face.hi[axis]);
        }
        if (hasRight) {
            values[4] = std::clamp(right.lo[axis], face.lo[axis], face.hi[axis]);
            values[5] = std::clamp(right.hi[axis], face.lo[axis], face.hi[axis]);
        }
        std::sort(values.begin(), values.end());
        return values;
    };
    const auto ac = cuts(a), bc = cuts(b);
    const auto contains = [&](const DryBox& box, const GridVec& lo, const GridVec& hi) {
        // The cuts already include every phase edge. Test the interval
        // directly so an unrepresentable midpoint cannot change a thin trace.
        return box.lo[a] <= lo[a] && hi[a] <= box.hi[a] &&
            box.lo[b] <= lo[b] && hi[b] <= box.hi[b];
    };
    FacePhases result;
    for (std::size_t i = 1; i < ac.size(); ++i) {
        if (ac[i] == ac[i - 1]) continue;
        for (std::size_t j = 1; j < bc.size(); ++j) {
            if (bc[j] == bc[j - 1]) continue;
            GridVec lo = face.lo, hi = face.hi;
            lo[a] = ac[i - 1];
            hi[a] = ac[i];
            lo[b] = bc[j - 1];
            hi[b] = bc[j];
            const unsigned bitLeft = hasLeft && contains(left, lo, hi);
            const unsigned bitRight = hasRight && contains(right, lo, hi);
            result.area[bitLeft | (bitRight << 1u)] +=
                MeasureCutRegionAperture(face, motion, lo, hi).start;
        }
    }
    return result;
}

} // namespace

bool ReportAnchoredDry(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                        const VentTopology& start, const VentTopology& expected,
                        const VentTopology& end, std::string& error) {
    const std::size_t count = chart.regions.size();
    std::vector<Inlet> inlets(count);
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.)
            continue;
        const auto left = start.regionComponent[face.left], right = start.regionComponent[face.right];
        if ((left == NoDryComponent) == (right == NoDryComponent))
            continue;
        const bool intoRight = right == NoDryComponent;
        const auto target = intoRight ? face.right : face.left;
        const auto source = intoRight ? face.left : face.right;
        if (end.regionVolume[target] == 0. || expected.regionComponent[target] != start.regionComponent[source])
            continue;
        const auto phase = MeasureCutRegionFacePhase(face, geometry.motion, 1,
                                                    start.waterPlane[face.left], start.waterPlane[face.right]);
        const double area = phase.dry[intoRight ? 0 : 1].start;
        if (area > inlets[target].area)
            inlets[target] = {area, face.axis, intoRight};
    }
    std::vector<DryBox> dry;
    dry.reserve(count);
    std::size_t anchored = 0;
    double shifted = 0., maxMismatch = 0.;
    for (std::size_t i = 0; i < count; ++i) {
        const auto& region = chart.regions[i];
        auto box = DryBox{region.lo, region.hi, end.regionVolume[i]};
        if (box.volume == 0.) {
            dry.push_back(box);
            continue;
        }
        const auto inlet = inlets[i];
        if (inlet.area == 0.) {
            box.lo[1] = std::max(box.lo[1], end.waterPlane[i]);
        } else {
            ++anchored;
            shifted += box.volume;
            const int axis = inlet.axis;
            double a = region.lo[axis], b = region.hi[axis];
            for (int iteration = 0; iteration < 64; ++iteration) {
                const double midpoint = a + .5 * (b - a);
                if (inlet.lower)
                    box.hi[axis] = midpoint;
                else
                    box.lo[axis] = midpoint;
                const double volume = CutRegionClippedVolume(region, geometry.motion, box.lo, box.hi);
                if ((volume < box.volume) == inlet.lower)
                    a = midpoint;
                else
                    b = midpoint;
            }
            if (inlet.lower)
                box.hi[axis] = a + .5 * (b - a);
            else
                box.lo[axis] = a + .5 * (b - a);
        }
        const double volume = CutRegionClippedVolume(region, geometry.motion, box.lo, box.hi);
        maxMismatch = std::max(maxMismatch, std::abs(volume - box.volume));
        if (volume == 0.) {
            // Inventories whose clipped support cannot be represented stay in
            // their original region, with no face path.
            if (end.regionComponent[i] == NoDryComponent ||
                end.components[end.regionComponent[i]].unresolvedVolume == 0.) {
                error = "anchored dry reconstruction lost represented geometry";
                return false;
            }
        }
        dry.push_back(box);
    }
    std::vector<std::size_t> parent(count + 1);
    std::iota(parent.begin(), parent.end(), 0);
    const auto root = [&](std::size_t i) {
        while (i != parent[i]) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    };
    double apertureClosure = 0., originalContactArea = 0., anchoredContactArea = 0.;
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.) continue;
        const auto phases = PartitionFace(face, geometry.motion, dry[face.left], dry[face.right]);
        apertureClosure = std::max(apertureClosure, std::abs(face.startArea -
            std::accumulate(phases.area.begin(), phases.area.end(), 0.)));
        const auto originalLeft = DryBox{
            {chart.regions[face.left].lo[0], end.waterPlane[face.left], chart.regions[face.left].lo[2]},
            chart.regions[face.left].hi, end.regionVolume[face.left]};
        const auto originalRight = DryBox{
            {chart.regions[face.right].lo[0], end.waterPlane[face.right], chart.regions[face.right].lo[2]},
            chart.regions[face.right].hi, end.regionVolume[face.right]};
        const auto originalPhases = PartitionFace(face, geometry.motion, originalLeft, originalRight);
        if (start.regionComponent[face.left] != start.regionComponent[face.right] &&
            expected.regionComponent[face.left] == 1 && expected.regionComponent[face.right] == 1) {
            originalContactArea += originalPhases.area[3];
            anchoredContactArea += phases.area[3];
        }
        if (phases.area[3] > 0.)
            parent[root(face.left)] = root(face.right);
    }
    std::cout << "ANCHOR shared_aperture_residual_m2=" << apertureClosure
        << " original_pocket_extension_area_m2=" << originalContactArea
        << " anchored_pocket_extension_area_m2=" << anchoredContactArea << '\n';
    const auto top = FullChartVent(chart, 1, 1).hi[1];
    for (std::size_t i = 0; i < count; ++i)
        if (Touches(dry[i], 1, top, true))
            parent[root(i)] = root(count);
    const auto atmosphere = root(count);
    std::map<std::size_t, double> volumes;
    std::map<std::size_t, std::map<std::size_t, double>> origin;
    for (std::size_t i = 0; i < count; ++i) {
        if (dry[i].volume == 0.)
            continue;
        const auto group = root(i);
        if (group == atmosphere)
            continue;
        volumes[group] += dry[i].volume;
        origin[group][expected.regionComponent[i]] += dry[i].volume;
    }
    std::cout << std::setprecision(17) << "ANCHOR changed=" << anchored
        << " moved_dry_geometry_m3=" << shifted << " max_capacity_mismatch=" << maxMismatch
        << " closed_components=" << volumes.size() << '\n';
    for (const auto& [group, volume] : volumes) {
        if (volume < 1e-12) continue;
        std::cout << "ANCHOR group=" << group << " volume_m3=" << volume << " inherited";
        for (const auto& [owner, amount] : origin[group])
            std::cout << ' ' << owner << ':' << amount;
        std::cout << '\n';
    }
    error.clear();
    return true;
}

} // namespace judas::volume_grid
