#include "AnchoredDry.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>

namespace judas::volume_grid {
namespace {

struct DryBox {
    GridVec lo{}, hi{};
    double volume = 0.;
};

struct Inlet {
    double area = 0.;
    int axis = 1;
    bool lower = false;
};

bool Touches(const DryBox& dry, int axis, double face, bool fromLower) {
    return dry.volume > 0. && (fromLower ? dry.lo[axis] < face && dry.hi[axis] >= face
                                        : dry.hi[axis] > face && dry.lo[axis] <= face);
}

} // namespace

bool ReportAnchoredDry(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                        const VentTopology& start, const VentTopology& expected,
                        const VentTopology& end, std::string& error) {
    const std::size_t count = chart.regions.size();
    std::vector<Inlet> inlets(count);
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.)
            continue;
        const auto left = start.regionComponent[face.left], right = start.regionComponent[face.right];
        if ((left == NoDryComponent) == (right == NoDryComponent))
            continue;
        const bool intoRight = right == NoDryComponent;
        const auto target = intoRight ? face.right : face.left;
        const auto source = intoRight ? face.left : face.right;
        if (end.regionVolume[target] == 0. || expected.regionComponent[target] != start.regionComponent[source])
            continue;
        const auto phase = MeasureCutRegionFacePhase(face, geometry.motion, 1,
                                                    start.waterPlane[face.left], start.waterPlane[face.right]);
        const double area = phase.dry[intoRight ? 0 : 1].start;
        if (area > inlets[target].area)
            inlets[target] = {area, face.axis, intoRight};
    }
    std::vector<DryBox> dry;
    dry.reserve(count);
    std::size_t anchored = 0;
    double shifted = 0., maxMismatch = 0.;
    for (std::size_t i = 0; i < count; ++i) {
        const auto& region = chart.regions[i];
        auto box = DryBox{region.lo, region.hi, end.regionVolume[i]};
        if (box.volume == 0.) {
            dry.push_back(box);
            continue;
        }
        const auto inlet = inlets[i];
        if (inlet.area == 0.) {
            box.lo[1] = std::max(box.lo[1], end.waterPlane[i]);
        } else {
            ++anchored;
            shifted += box.volume;
            const int axis = inlet.axis;
            double a = region.lo[axis], b = region.hi[axis];
            for (int iteration = 0; iteration < 64; ++iteration) {
                const double midpoint = a + .5 * (b - a);
                if (inlet.lower)
                    box.hi[axis] = midpoint;
                else
                    box.lo[axis] = midpoint;
                const double volume = CutRegionClippedVolume(region, geometry.motion, box.lo, box.hi);
                if ((volume < box.volume) == inlet.lower)
                    a = midpoint;
                else
                    b = midpoint;
            }
            if (inlet.lower)
                box.hi[axis] = a + .5 * (b - a);
            else
                box.lo[axis] = a + .5 * (b - a);
        }
        const double volume = CutRegionClippedVolume(region, geometry.motion, box.lo, box.hi);
        maxMismatch = std::max(maxMismatch, std::abs(volume - box.volume));
        if (volume == 0.) {
            // Inventories whose clipped support cannot be represented stay in
            // their original region, with no face path.
            if (end.regionComponent[i] == NoDryComponent ||
                end.components[end.regionComponent[i]].unresolvedVolume == 0.) {
                error = "anchored dry reconstruction lost represented geometry";
                return false;
            }
        }
        dry.push_back(box);
    }
    std::vector<std::size_t> parent(count + 1);
    std::iota(parent.begin(), parent.end(), 0);
    const auto root = [&](std::size_t i) {
        while (i != parent[i]) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    };
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0. || !Touches(dry[face.left], face.axis, face.lo[face.axis], true) ||
            !Touches(dry[face.right], face.axis, face.lo[face.axis], false))
            continue;
        GridVec lo = face.lo, hi = face.hi;
        for (int a = 0; a < 3; ++a) {
            if (a == face.axis) continue;
            lo[a] = std::max({lo[a], dry[face.left].lo[a], dry[face.right].lo[a]});
            hi[a] = std::min({hi[a], dry[face.left].hi[a], dry[face.right].hi[a]});
        }
        if (MeasureCutRegionAperture(face, geometry.motion, lo, hi).start > 0.)
            parent[root(face.left)] = root(face.right);
    }
    const auto top = FullChartVent(chart, 1, 1).hi[1];
    for (std::size_t i = 0; i < count; ++i)
        if (Touches(dry[i], 1, top, true))
            parent[root(i)] = root(count);
    const auto atmosphere = root(count);
    std::map<std::size_t, double> volumes;
    std::map<std::size_t, std::map<std::size_t, double>> origin;
    for (std::size_t i = 0; i < count; ++i) {
        if (dry[i].volume == 0.)
            continue;
        const auto group = root(i);
        if (group == atmosphere)
            continue;
        volumes[group] += dry[i].volume;
        origin[group][expected.regionComponent[i]] += dry[i].volume;
    }
    std::cout << std::setprecision(17) << "ANCHOR changed=" << anchored
        << " moved_dry_geometry_m3=" << shifted << " max_capacity_mismatch=" << maxMismatch
        << " closed_components=" << volumes.size() << '\n';
    for (const auto& [group, volume] : volumes) {
        if (volume < 1e-12) continue;
        std::cout << "ANCHOR group=" << group << " volume_m3=" << volume << " inherited";
        for (const auto& [owner, amount] : origin[group])
            std::cout << ' ' << owner << ':' << amount;
        std::cout << '\n';
    }
    error.clear();
    return true;
}

} // namespace judas::volume_grid
