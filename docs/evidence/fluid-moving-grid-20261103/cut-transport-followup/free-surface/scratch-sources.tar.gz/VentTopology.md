# Start-of-step dry topology

`BuildVentTopology` shares the current cut-region chart and its oriented face indices. It reconstructs the water plane in each cut, intersects both one-sided dry face traces, and joins only positive physical dry apertures. Boundary vents are explicitly authored rectangles on a chart side. A vent opens only on a dry portion of its declared rectangle that is unobstructed by the solids.

Output component zero represents the common exterior reservoir. Each remaining index identifies a closed dry component, ordered deterministically by the first chart region it owns. A wet or solid region has the `NoDryComponent` label. The region graph remains accessible through `sharedDryArea` in input face order, and geometric boundary support through `boundaryDryArea` in region order. The scratch API computes topology at the start of the interval. Call it on rebuilt endpoint geometry and endpoint water to obtain the actual final topology.

An axis-aligned moving box can divide the dry part of a region even when its full free volume is connected below the water plane. The function rejects when the box spans two axes of the dry prism and splits its third axis. The current one-label-per-region contract cannot represent the two pockets.

The module preserves the exact dry inventory difference `capacity − water` separately from dry face support. A material remainder smaller than a representable absolute water-plane step stays in an isolated component with matching `unresolvedVolume`. It has no pressure aperture. A discrepancy larger than the coordinate ULP times the local cross-section plus bounded binary64 arithmetic error rejects. No aperture is enlarged or snapped. A genuine phase film below the absolute coordinate spacing requires a future anchor-plus-relative-depth clipping representation.

## Reproduction

From the Judas checkout root, where the authored fixture harness has been copied to /tmp/judas-cut-basin:

```bash
d=/tmp/judas-vented-cut-3d
g=tools/prototypes/fluid_volume_grid
c++ -std=c++17 -O3 -Wall -Wextra -Werror -I"$g" -I/tmp/judas-cut-basin \
  "$d/VentTopologyTests.cpp" "$d/VentTopology.cpp" "$g/CutRegionGeometry.cpp" \
  -o "$d/vent-topology-tests"
"$d/vent-topology-tests"
```

For address and undefined-behaviour sanitizers, replace `-O3` with `-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer` and run with `ASAN_OPTIONS=detect_leaks=0` in the development environment.

Both runs passed 16 controls. These include exact 22.3517 nm vent support versus exact wall contact, wet and moving-solid vent occlusion, one-ULP phase distinction, unsupported dry splits, deterministic labels, and volume inventory for the original level and rotated basins. The level cavity has 0.53399997425079249 m³ of resolved dry volume. The rotated main cavity has 0.16799997037900125 m³. The rotated case retains 483 isolated coordinate-roundoff remainders totaling 1.0300598270301533e−16 m³ and a further resolved micro-component.

This topology helper neither solves pressure nor transfers gas across topology events. A future gas-pressure solve must consume only supported volume and give conserved material an owner when regions open, vent, merge or split.
