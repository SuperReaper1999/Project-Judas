#include "VentTopology.h"
#include "BasinFixture.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

unsigned checks = 0, failures = 0;

void Check(bool result, const std::string& label) {
    ++checks;
    failures += !result;
    std::cout << (result ? "PASS " : "FAIL ") << label << '\n';
}

double Sum(const std::vector<double>& values) {
    return static_cast<double>(std::accumulate(values.begin(), values.end(), 0.L));
}

bool Prepare(const GridLayout& layout, const std::vector<BoxMotion>& walls,
             const std::optional<BoxMotion>& moving, CutRegionChart& chart,
             CutRegionGeometry& geometry, std::string& error) {
    return PrepareCutRegionChart(layout, walls, moving, {}, {}, chart, error) &&
        BuildCutRegionGeometry(chart, {}, geometry, error);
}

void PartialPort() {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    VentTopology vents;
    std::string error;
    if (!Prepare({{2, 1, 1}, 1.}, {}, {}, chart, geometry, error)) {
        Check(false, "partial chart " + error);
        return;
    }
    const bool built = BuildVentTopology(chart, geometry, 1, {.2, .6}, {}, vents, error);
    Check(built && vents.components.size() == 2 && vents.sharedDryArea.size() == 1 &&
          std::abs(vents.sharedDryArea.front() - .4) < 1e-14 &&
          std::abs(vents.components[1].volume - 1.2) < 1e-14 &&
          vents.regionComponent == std::vector<std::size_t>{1, 1},
          "overlapping one-sided dry traces own only their common area " + error);
}

void CoordinateResolution() {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    VentTopology vents;
    std::string error;
    if (!Prepare({{1, 2, 1}, 1.}, {}, {}, chart, geometry, error)) {
        Check(false, "coordinate resolution chart " + error);
        return;
    }
    const auto top = FullChartVent(chart, 1, 1);
    const double nearFull = std::nextafter(1., 0.);
    const bool unresolved = BuildVentTopology(chart, geometry, 1, {1., nearFull}, {top}, vents, error);
    Check(unresolved && vents.regionComponent == std::vector<std::size_t>{NoDryComponent, 1} &&
          vents.components.size() == 2 && vents.components[1].volume == 1. - nearFull &&
          vents.components[1].unresolvedVolume == vents.components[1].volume &&
          Sum(vents.boundaryDryArea) == 0. && Sum(vents.sharedDryArea) == 0.,
          "sub-coordinate dry inventory is conserved without a fictitious vent " + error);
    const double representable = std::nextafter(nearFull, 0.);
    const bool resolved = BuildVentTopology(chart, geometry, 1, {1., representable}, {top}, vents, error);
    Check(resolved && vents.regionComponent == std::vector<std::size_t>{NoDryComponent, 0} &&
          vents.components.size() == 1 && vents.components[0].volume == 1. - representable &&
          vents.components[0].unresolvedVolume == 0. && Sum(vents.boundaryDryArea) == 1.,
          "next representable dry layer owns the actual vent " + error);
}

void WallAndBoundary() {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    VentTopology vents;
    std::string error;
    const BoxMotion wall{1, {1., 0., 0.}, {2., 2., 2.}, {}};
    if (!Prepare({{3, 2, 2}, 1.}, {wall}, {}, chart, geometry, error)) {
        Check(false, "partitioned chart " + error);
        return;
    }
    auto top = FullChartVent(chart, 1, 1);
    top.hi[0] = 1.5; // Half a meter sits over static solid and offers no vent.
    const std::vector<double> dry(chart.regions.size());
    const bool built = BuildVentTopology(chart, geometry, 1, dry, {top}, vents, error);
    Check(built && vents.components.size() == 2 && vents.components[0].volume == 4. &&
          vents.components[1].volume == 4. && Sum(vents.boundaryDryArea) == 2.,
          "explicit partial top vent leaves the wall's far side closed " + error);
    const auto previous = vents.regionComponent;
    Check(!BuildVentTopology(chart, geometry, 1, dry, {top, top}, vents, error) &&
          vents.regionComponent == previous,
          "overlapping vent rectangles reject without publication");

    auto capped = dry;
    for (std::size_t i = 0; i < chart.regions.size(); ++i)
        if (chart.regions[i].lo[1] == 1.)
            capped[i] = geometry.startCapacity[i];
    top = FullChartVent(chart, 1, 1);
    const bool cappedBuilt = BuildVentTopology(chart, geometry, 1, capped, {top}, vents, error);
    Check(cappedBuilt && vents.components.size() == 3 && vents.components[0].volume == 0. &&
          vents.components[1].volume == 2. && vents.components[2].volume == 2. &&
          Sum(vents.boundaryDryArea) == 0.,
          "wet top prevents a geometrically open boundary from venting gas " + error);
}

void ThinPhysicalOpening() {
    const double apertureWidth = double(1.1f) - double(.1f) - 1.;
    for (const bool open : {false, true}) {
        CutRegionChart chart;
        CutRegionGeometry geometry;
        VentTopology vents;
        std::string error;
        const double wallEnd = open ? 1. - apertureWidth : 1.;
        const BoxMotion wall{1, {.9, 0., 0.}, {1.1, 1., wallEnd}, {}};
        if (!Prepare({{2, 1, 1}, 1.}, {wall}, {}, chart, geometry, error)) {
            Check(false, "thin-opening chart " + error);
            continue;
        }
        const auto left = FullChartVent(chart, 0, -1);
        const bool built = BuildVentTopology(chart, geometry, 1,
            std::vector<double>(chart.regions.size()), {left}, vents, error);
        double portalArea = 0.;
        if (built)
            for (std::size_t f = 0; f < geometry.faces.size(); ++f) {
                const auto& face = geometry.faces[f];
                if (face.axis == 0 && face.lo[0] == 1.)
                    portalArea += vents.sharedDryArea[f];
            }
        Check(built && portalArea == 1. - wallEnd && vents.components.size() == (open ? 1u : 2u),
              open ? "native-scale 22 nm aperture connects gas without widening"
                   : "exact contact keeps far-side gas sealed");
    }
}

void MovingBoundaryAndDrySplit() {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    VentTopology vents;
    std::string error;
    const BoxMotion body{1, {.2, .5, .2}, {.8, 1., .8}, {}};
    chart.layout = {{1, 1, 1}, 1.};
    chart.regions.push_back({{}, {1., 1., 1.}, 0});
    geometry.motion = body;
    geometry.startCapacity = {CutRegionClippedVolume(chart.regions[0], body, {}, {1., 1., 1.})};
    const std::vector<double> water(chart.regions.size());
    const VentBoundary covered{1, 1, {.3, 1., .3}, {.7, 1., .7}};
    const bool coveredBuilt = BuildVentTopology(chart, geometry, 1, water, {covered}, vents, error);
    Check(coveredBuilt && vents.components.size() == 2 && vents.components[0].volume == 0. &&
          Sum(vents.boundaryDryArea) == 0.,
          "moving body on chart boundary physically seals the explicit vent " + error);
    const VentBoundary partlyOpen{1, 1, {.1, 1., .3}, {.7, 1., .7}};
    const bool openBuilt = BuildVentTopology(chart, geometry, 1, water, {partlyOpen}, vents, error);
    Check(openBuilt && vents.components.size() == 1 &&
          std::abs(Sum(vents.boundaryDryArea) - .04) < 1e-14,
          "uncovered portion of an obstructed vent retains exact support " + error);

    // Deliberately hold one larger retained control volume, as can happen
    // away from chart-construction positions with a translating obstacle.
    chart = {};
    chart.layout = {{1, 1, 1}, 1.};
    chart.regions.push_back({{}, {1., 1., 1.}, 0});
    geometry = {};
    geometry.motion = BoxMotion{1, {.45, .5, 0.}, {.55, 1., 1.}, {}};
    geometry.startCapacity = {.95};
    Check(!BuildVentTopology(chart, geometry, 1, {.5}, {}, vents, error) &&
          error == "moving solid divides the dry part of a control volume",
          "a connected full volume cannot silently connect a split dry complement");
}

void AuthoredBasin(bool rotated) {
    const auto fixture = Fixture::Authored(rotated);
    CutRegionChart chart;
    CutRegionGeometry geometry;
    SeedImport seed;
    std::string error;
    std::vector<double> water;
    const auto body = fixture.InitialBox();
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), body, {-.005, -.015, -.005},
                               {.005, .025, .005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error) ||
        !WaterByRegion(fixture, chart, geometry, rotated, water, seed, error)) {
        Check(false, "authored basin " + error);
        return;
    }
    const std::vector<VentBoundary> boundary{FullChartVent(chart, 1, 1)};
    VentTopology vents, repeated;
    const bool built = BuildVentTopology(chart, geometry, 1, water, boundary, vents, error);
    if (!built) {
        Check(false, std::string(rotated ? "rotated" : "level") + " topology " + error);
        return;
    }
    Check(BuildVentTopology(chart, geometry, 1, water, boundary, repeated, error) &&
          vents.regionComponent == repeated.regionComponent &&
          vents.sharedDryArea == repeated.sharedDryArea,
          std::string(rotated ? "rotated" : "level") + " topology deterministic " + error);
    double maximumClosed = 0.;
    long double unresolved = 0.;
    std::size_t unresolvedCount = 0, firstUnresolved = NoDryComponent, greatestUnresolved = NoDryComponent;
    std::size_t maximumComponent = 0;
    for (std::size_t i = 1; i < vents.components.size(); ++i) {
        unresolved += vents.components[i].unresolvedVolume;
        if (vents.components[i].unresolvedVolume > 0.) {
            ++unresolvedCount;
            const auto region = vents.components[i].regions.front();
            if (firstUnresolved == NoDryComponent)
                firstUnresolved = region;
            if (greatestUnresolved == NoDryComponent ||
                vents.regionVolume[greatestUnresolved] < vents.regionVolume[region])
                greatestUnresolved = region;
        }
        if (vents.components[i].volume > maximumClosed) {
            maximumClosed = vents.components[i].volume;
            maximumComponent = i;
        }
    }
    const double expected = rotated ? .16799997037900124 : .53399997425079243;
    const auto expectedRegions = rotated ? 1024u : 1052u;
    const auto expectedClosed = rotated ? 485u : 1u;
    Check(vents.components.size() == expectedClosed + 1 && maximumComponent > 0 &&
          std::abs(maximumClosed - expected) < 1e-13 &&
          vents.components[maximumComponent].regions.size() == expectedRegions &&
          vents.components[0].volume > 19. &&
          std::abs(Sum(vents.regionVolume) + Sum(water) - Sum(geometry.startCapacity)) < 1e-13,
          std::string(rotated ? "rotated" : "level") + " original sealed pocket and exterior");
    std::cout << std::setprecision(17) << "BASIN rotated=" << rotated
              << " closed=" << vents.components.size() - 1
              << " exterior_m3=" << vents.components[0].volume
              << " largest_closed_m3=" << maximumClosed
              << " max_reconstruction_m3=" << vents.maximumDryVolumeError
              << " unresolved=" << unresolvedCount << " unresolved_m3=" << unresolved << '\n';
    if (rotated) {
        Check(unresolvedCount == 483 && unresolved > 0. && unresolved < 1.1e-16L &&
              vents.components[maximumComponent].unresolvedVolume == 0.,
              "rotated rounding remainders are retained separately from the physical pocket");
        for (auto i : {firstUnresolved, greatestUnresolved}) {
            if (i == NoDryComponent)
                continue;
            const auto& r = chart.regions[i];
            std::cout << "UNRESOLVED region=" << i << " lo=(" << r.lo[0] << ',' << r.lo[1] << ',' << r.lo[2]
                      << ") hi=(" << r.hi[0] << ',' << r.hi[1] << ',' << r.hi[2] << ")"
                      << " capacity_m3=" << geometry.startCapacity[i] << " water_m3=" << water[i]
                      << " dry_m3=" << vents.regionVolume[i] << " plane=" << vents.waterPlane[i] << '\n';
        }
    }

}

} // namespace

int main() {
    PartialPort();
    CoordinateResolution();
    WallAndBoundary();
    ThinPhysicalOpening();
    MovingBoundaryAndDrySplit();
    AuthoredBasin(false);
    AuthoredBasin(true);
    std::cout << "CHECKS " << checks << " FAILURES " << failures << '\n';
    return failures != 0;
}
