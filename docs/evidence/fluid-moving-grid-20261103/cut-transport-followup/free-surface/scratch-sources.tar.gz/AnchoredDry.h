#pragma once

#include "VentTopology.h"

namespace judas::volume_grid {

bool ReportAnchoredDry(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                        const VentTopology& start, const VentTopology& expected,
                        const VentTopology& end, std::string& error);

} // namespace judas::volume_grid
