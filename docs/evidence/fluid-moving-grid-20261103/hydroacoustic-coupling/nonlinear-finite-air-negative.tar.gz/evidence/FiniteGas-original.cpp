#include "FiniteGas.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace judas::volume_grid {
namespace {

bool Factor(std::vector<double>& matrix, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j <= i; ++j) {
            double m = matrix[i * n + j];
            for (std::size_t k = 0; k < j; ++k)
                m -= matrix[i * n + k] * matrix[j * n + k];
            if (j == i) {
                if (!(m > 0. && std::isfinite(m)))
                    return false;
                matrix[i * n + j] = std::sqrt(m);
            } else {
                matrix[i * n + j] = m / matrix[j * n + j];
            }
        }
    }
    return true;
}

void Solve(const std::vector<double>& factor, std::vector<double>& values) {
    const auto n = values.size();
    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j < i; ++j)
            values[i] -= factor[i * n + j] * values[j];
        values[i] /= factor[i * n + i];
    }
    for (std::size_t i = n; i-- > 0;) {
        for (std::size_t j = i + 1; j < n; ++j)
            values[i] -= factor[j * n + i] * values[j];
        values[i] /= factor[i * n + i];
    }
}

double Conductance(double dt, const PneumaticPort& port) {
    return .5 * dt * dt * (port.area / port.length) / pneumaticDensity;
}

} // namespace

double GasPortVolume(double dt, const PneumaticPort& port, double leftGauge, double rightGauge) {
    return dt * port.area * port.predictedSpeed + Conductance(dt, port) * (leftGauge - rightGauge);
}

bool SolveFiniteGas(double dt, double scale, const std::vector<double>& initialVolume,
                    const std::vector<double>& absolutePressure, const std::vector<PneumaticPort>& ports,
                    const GasStorage& storage, GasMidpoint& result) {
    GasMidpoint next;
    const auto count = initialVolume.size();
    if (absolutePressure.size() != count || !(dt > 0. && scale > 0.))
        return false;
    next.index.assign(count, count);
    for (const auto& port : ports) {
        if (port.left == port.right || port.left >= count || port.right >= count ||
            !(port.area > 0. && port.length > 0.) || !std::isfinite(port.predictedSpeed))
            return false;
        for (const auto i : {port.left, port.right}) {
            if (i == 0 || next.index[i] != count)
                continue;
            if (!(initialVolume[i] > 0. && absolutePressure[i] > 0.))
                return false;
            next.index[i] = next.owners.size();
            next.owners.push_back(i);
        }
    }
    const auto n = next.owners.size();
    if (n > 32)
        return false;
    next.head.resize(n);
    next.capacitance.resize(n);
    next.volumes.resize(n);
    std::vector<double> predicted(n), initialHead(n), base(n * n), r(n), factor;
    for (std::size_t i = 0; i < n; ++i) {
        const auto owner = next.owners[i];
        initialHead[i] = (absolutePressure[owner] - ambientPressure) / scale;
        next.head[i] = initialHead[i];
        next.capacitance[i] = initialVolume[owner] / (gasExponent * absolutePressure[owner]);
        base[i * n + i] = 2. * scale * next.capacitance[i];
    }
    for (const auto& port : ports) {
        const double k = scale * Conductance(dt, port), q = dt * port.area * port.predictedSpeed;
        const auto a = next.index[port.left], b = next.index[port.right];
        if (a < n) {
            predicted[a] += q;
            base[a * n + a] += k;
            if (b < n) base[a * n + b] -= k;
        }
        if (b < n) {
            predicted[b] -= q;
            base[b * n + b] += k;
            if (a < n) base[b * n + a] -= k;
        }
    }

    const auto measure = [&] {
        factor = base;
        double worst = 0.;
        for (std::size_t i = 0; i < n; ++i) {
            const auto owner = next.owners[i];
            const auto [volume, area] = storage(owner, next.head[i]);
            next.volumes[i] = volume;
            r[i] = volume - initialVolume[owner] + predicted[i] -
                2. * scale * next.capacitance[i] * initialHead[i];
            for (std::size_t j = 0; j < n; ++j)
                r[i] += base[i * n + j] * next.head[j];
            factor[i * n + i] += area;
            if (!std::isfinite(r[i]))
                return std::numeric_limits<double>::infinity();
            worst = std::max(worst, std::abs(r[i]));
        }
        return worst;
    };
    double norm = measure();
    const double tolerance = 2e-15;
    for (int iteration = 0; norm > tolerance && iteration < 48; ++iteration) {
        if (!Factor(factor, n))
            return false;
        auto direction = r, previous = next.head;
        Solve(factor, direction);
        bool accepted = false;
        for (double step = 1.; step >= std::ldexp(1., -18); step *= .5) {
            for (std::size_t i = 0; i < n; ++i)
                next.head[i] = previous[i] - step * direction[i];
            const double candidate = measure();
            if (candidate < norm) {
                norm = candidate;
                accepted = true;
                break;
            }
        }
        if (!accepted)
            return false;
    }
    if (!(norm <= tolerance) || !Factor(factor, n))
        return false;
    next.inverse.resize(n * n);
    std::vector<double> column(n);
    for (std::size_t i = 0; i < n; ++i) {
        std::fill(column.begin(), column.end(), 0.);
        column[i] = 1.;
        Solve(factor, column);
        for (std::size_t j = 0; j < n; ++j)
            next.inverse[j * n + i] = column[j];
    }
    next.residual = norm;
    result = std::move(next);
    return true;
}

} // namespace judas::volume_grid
