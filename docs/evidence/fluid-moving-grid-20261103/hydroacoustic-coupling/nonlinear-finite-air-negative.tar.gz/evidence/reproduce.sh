#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
out=$(mktemp -d /tmp/judas-finite-gas-coupled-repro.XXXXXX)
flags=(-std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror)
geometry=(CutRegionGeometry.cpp CutRegionGasTopology.cpp)
case=${1:-first}
c++ "${flags[@]}" FiniteGasTests.cpp FiniteGas.cpp -o "$out/finite-tests"
"$out/finite-tests" | tee "$out/finite-tests.log"
driver=ContinueGas-first.cpp
water=CutLiquidGas-first.cpp
gas=FiniteGas-original.cpp
mode=--finite
case "$case" in
  first) ;;
  shift) driver=ContinueGas-shift.cpp ;;
  coordinate) water=CutLiquidGas-coordinate.cpp ;;
  tangent) water=CutLiquidGas-tangent.cpp ;;
  lagged) driver=ContinueGas-lagged.cpp; mode=--lagged ;;
  stable) driver=ContinueGas.cpp; water=CutLiquidGas.cpp; gas=FiniteGas.cpp ;;
  *) exit 2 ;;
esac
c++ "${flags[@]}" "$driver" "$water" "$gas" "${geometry[@]}" -o "$out/basin"
status=0
"$out/basin" --steps 6 --strict-water-donor --split-at-endpoint "$mode" >"$out/$case.log" 2>&1 || status=$?
printf '%s exit=%s\n' "$case" "$status"
grep -E '^(STAGE|SOLVE|FINITE|FAIL)' "$out/$case.log"
printf 'Raw logs in %s\n' "$out"
test "$status" -eq 1
