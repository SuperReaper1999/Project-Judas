#include "BasinFixture.h"
#include "CutLiquidGas.h"
#include "GasPocketMath.h"

#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string_view>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

struct Basin {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    CutLiquidState state;
    std::vector<CutRegionInterface> sides;
    std::vector<CutRegionWaterPlane> slabs;
    CutRegionGasTopology graph;
    CutRegionGasVent vent;
    std::vector<double> gasPressure;
    std::vector<double> gasMass, gasVelocity;
};

constexpr double ambient = 101325., exponent = 1.4;

bool Build(const Fixture& fixture, Basin& basin, std::string& error) {
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                               {-.005, -.015, -.005}, {.005, .025, .005}, basin.chart, error) ||
        !BuildCutRegionGeometry(basin.chart, {}, basin.geometry, error))
        return false;
    SeedImport seed;
    if (!WaterByRegion(fixture, basin.chart, basin.geometry, fixture.spacing == .20f,
                       basin.state.water, seed, error))
        return false;
    basin.state.faceSpeed.resize(basin.geometry.faces.size());
    basin.gasVelocity.resize(basin.geometry.faces.size());
    basin.sides.resize(basin.chart.regions.size());
    basin.vent = FullCutRegionGasVent(basin.chart, 1, 1);
    if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, basin.state.water, basin.sides,
                                          basin.slabs, error) ||
        !BuildCutRegionGasTopology(basin.chart, basin.geometry, basin.slabs, {basin.vent}, basin.graph, error))
        return false;
    basin.gasPressure.assign(basin.graph.components.size(), ambient);
    basin.gasMass.assign(basin.graph.components.size(), 0.);
    for (std::size_t i = 1; i < basin.graph.components.size(); ++i)
        basin.gasMass[i] = 1.2 * basin.graph.components[i].volume;
    return true;
}

struct FrontierClaim {
    std::size_t owner = NoCutRegionGas;
    double area = 0.;
    CutRegionInterface phase;
    bool contested = false;
};

std::vector<FrontierClaim> ProposeFrontier(const CutRegionGeometry& geometry,
                                         const std::vector<CutRegionWaterPlane>& slabs,
                                         const CutRegionGasTopology& graph) {
    std::vector<FrontierClaim> claims(slabs.size());
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.) continue;
        const auto left = graph.regionOwner[face.left], right = graph.regionOwner[face.right];
        if ((left == NoCutRegionGas) == (right == NoCutRegionGas)) continue;
        const bool intoRight = right == NoCutRegionGas;
        const double area = MeasureCutRegionSharedPhase(face, geometry.motion, slabs[face.left],
                                                         slabs[face.right], !intoRight, intoRight).start;
        if (area == 0.) continue;
        const auto owner = intoRight ? left : right;
        auto& claim = claims[intoRight ? face.right : face.left];
        claim.contested |= claim.owner != NoCutRegionGas && claim.owner != owner;
        if (area > claim.area) {
            claim.owner = owner;
            claim.area = area;
            claim.phase = {face.axis, intoRight};
        }
    }
    return claims;
}

CutRegionGasTopology ExtendFrontier(const CutRegionGasTopology& initial,
                                    const std::vector<FrontierClaim>& claims) {
    auto next = initial;
    for (std::size_t i = 0; i < claims.size(); ++i) {
        const auto& claim = claims[i];
        if (claim.owner == NoCutRegionGas || claim.contested) continue;
        next.regionOwner[i] = claim.owner;
        next.components[claim.owner].regions.push_back(i);
    }
    return next;
}

bool PreserveOwners(const CutRegionGasTopology& from, const CutRegionGasTopology& to,
                    const CutRegionGasTopology& pressure, const std::vector<double>& priorPressure,
                    const std::vector<double>& priorMass, const std::vector<double>& meanGauge,
                    bool splitAtEndpoint, std::vector<double>& nextPressure, std::vector<double>& nextMass,
                    std::string& error) {
    std::vector<std::vector<std::size_t>> children(from.components.size());
    std::vector<std::size_t> origin(to.components.size(), NoCutRegionGas);
    double unsupported = 0.;
    bool split = false, merge = false, vented = false;
    for (std::size_t i = 0; i < to.regionOwner.size(); ++i) {
        const auto prev = pressure.regionOwner[i], next = to.regionOwner[i];
        if (next == NoCutRegionGas)
            continue;
        if (prev == NoCutRegionGas) {
            unsupported += to.regionVolume[i];
            continue;
        }
        vented |= (prev == ExteriorCutRegionGas) != (next == ExteriorCutRegionGas);
        if (origin[next] == NoCutRegionGas) {
            split |= !children[prev].empty();
            children[prev].push_back(next);
            origin[next] = prev;
        } else {
            merge |= origin[next] != prev;
        }
    }
    std::cout << "TOPOLOGY previous_components=" << from.components.size() - 1
              << " next_components=" << to.components.size() - 1 << " unsupported=" << unsupported
              << " split=" << split << " merge=" << merge << " vented=" << vented << '\n';
    if ((split && !splitAtEndpoint) || merge || vented || unsupported != 0.) {
        error = "resolved gas lineage change requires conservative transfer";
        return false;
    }
    nextPressure.assign(to.components.size(), ambient);
    nextMass.assign(to.components.size(), 0.);
    for (std::size_t i = 1; i < from.components.size(); ++i) {
        const auto& next = children[i];
        if (next.empty()) {
            error = "previous resolved gas chamber vanished";
            return false;
        }
        const long double v0 = from.components[i].volume;
        long double v1 = 0.;
        for (const auto j : next)
            v1 += to.components[j].volume;
        const long double p0 = priorPressure[i];
        const long double logarithmicVolumeChange = std::log1p((v1 - v0) / v0);
        const long double p1 = p0 * std::exp(-exponent * logarithmicVolumeChange);
        const long double gasEnergyChange = p0 * v0 * std::expm1((1. - exponent) * logarithmicVolumeChange) /
            (exponent - 1.);
        const long double work = -(static_cast<long double>(meanGauge[i]) + ambient) * (v1 - v0);
        const long double residual = work - gasEnergyChange;
        if (!std::isfinite(p1) || std::abs(residual) > 1e-8 * (1. + std::abs(work))) {
            error = "gas endpoint thermodynamic work does not close";
            return false;
        }
        long double assignedMass = 0., childEnergy = 0.;
        for (const auto j : next) {
            const auto volume = to.components[j].volume;
            nextPressure[j] = static_cast<double>(p1);
            nextMass[j] = static_cast<double>(priorMass[i] * (volume / v1));
            assignedMass += nextMass[j];
            childEnergy += static_cast<long double>(nextPressure[j]) * volume / (exponent - 1.);
        }
        const long double massResidual = assignedMass - priorMass[i];
        const long double internalResidual = childEnergy - p1 * v1 / (exponent - 1.);
        if (std::abs(massResidual) > 4. * std::numeric_limits<double>::epsilon() * priorMass[i] ||
            std::abs(internalResidual) > 4. * std::numeric_limits<double>::epsilon() * std::abs(childEnergy)) {
            error = "gas endpoint descendants do not conserve mass and internal energy";
            return false;
        }
        std::cout << "GAS old=" << i << " children=" << next.size() << " v0=" << v0 << " v1=" << v1
                  << " p0=" << p0 << " p1=" << p1 << " mean_gauge=" << meanGauge[i]
                  << " gas_work=" << work << " error_J=" << residual << " mass_error_kg=" << massResidual
                  << " internal_error_J=" << internalResidual << '\n';
    }
    return true;
}

bool RebuildEndpoint(const Basin& basin, const std::vector<FrontierClaim>& claims,
                     const std::vector<double>& water, std::vector<CutRegionInterface>& sides,
                     std::vector<CutRegionWaterPlane>& slabs, CutRegionGasTopology& graph,
                     std::string& error) {
    sides = basin.sides;
    for (std::size_t cell = 0; cell < sides.size(); ++cell)
        if (basin.graph.regionOwner[cell] == NoCutRegionGas &&
            water[cell] < basin.geometry.startCapacity[cell] && claims[cell].area > 0. &&
            !claims[cell].contested)
            sides[cell] = claims[cell].phase;
    return ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, water, sides, slabs, error) &&
        BuildCutRegionGasTopology(basin.chart, basin.geometry, slabs, {basin.vent}, graph, error);
}

bool MeasurePneumatic(const Basin& basin, const CutRegionGasTopology& pressure,
                      const CutRegionGasTopology& endGraph, const std::vector<double>& endWater,
                      const std::vector<CutRegionInterface>& orientations,
                      std::vector<PneumaticPort>& result, std::string& error) {
    std::vector<PneumaticPort> links;
    for (std::size_t f = 0; f < basin.geometry.faces.size(); ++f) {
        if (basin.graph.sharedDryArea[f] == 0. && endGraph.sharedDryArea[f] == 0.)
            continue;
        const auto& face = basin.geometry.faces[f];
        const auto a = pressure.regionOwner[face.left], b = pressure.regionOwner[face.right];
        if (a == b || a == NoCutRegionGas || b == NoCutRegionGas)
            continue;
        links.push_back({f, a, b, face.length, 0., basin.gasVelocity[f]});
    }
    if (links.empty()) {
        result.clear();
        return true;
    }
    const auto count = endWater.size();
    std::vector<double> water(count);
    std::vector<CutRegionWaterPlane> slabs;
    constexpr int samples = 16;
    for (int sample = 0; sample < samples; ++sample) {
        const double t = (sample + .5) / samples;
        for (std::size_t i = 0; i < count; ++i)
            water[i] = std::clamp(basin.state.water[i] + t * (endWater[i] - basin.state.water[i]),
                                  0., basin.geometry.startCapacity[i]);
        if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, water, orientations,
                                             slabs, error))
            return false;
        for (auto& link : links) {
            const auto& face = basin.geometry.faces[link.face];
            const double area = MeasureCutRegionSharedPhase(face, basin.geometry.motion,
                                                           slabs[face.left], slabs[face.right], false, false).start;
            link.area += area / samples;
        }
    }
    links.erase(std::remove_if(links.begin(), links.end(), [](const auto& link) { return link.area == 0.; }),
                links.end());
    result = std::move(links);
    return true;
}

std::vector<PneumaticPort> InitialPneumatic(const Basin& basin, const CutRegionGasTopology& pressure) {
    std::vector<PneumaticPort> ports;
    for (std::size_t f = 0; f < basin.geometry.faces.size(); ++f) {
        const double area = basin.graph.sharedDryArea[f];
        if (area == 0.)
            continue;
        const auto& face = basin.geometry.faces[f];
        const auto a = pressure.regionOwner[face.left], b = pressure.regionOwner[face.right];
        if (a == b || a == NoCutRegionGas || b == NoCutRegionGas)
            continue;
        ports.push_back({f, a, b, face.length, area, basin.gasVelocity[f]});
    }
    return ports;
}

bool HasMerge(const CutRegionGasTopology& end, const CutRegionGasTopology& pressure) {
    std::vector<std::size_t> origins(end.components.size(), NoCutRegionGas);
    for (std::size_t i = 0; i < end.regionOwner.size(); ++i) {
        const auto a = pressure.regionOwner[i], b = end.regionOwner[i];
        if (a == NoCutRegionGas || b == NoCutRegionGas)
            continue;
        if (origins[b] == NoCutRegionGas)
            origins[b] = a;
        else if (origins[b] != a)
            return true;
    }
    return false;
}

double MaxPortDifference(const std::vector<PneumaticPort>& a, const std::vector<PneumaticPort>& b) {
    std::size_t i = 0, j = 0;
    double relative = 0.;
    while (i < a.size() && j < b.size()) {
        if (a[i].face < b[j].face || b[j].face < a[i].face)
            return std::numeric_limits<double>::infinity();
        const double scale = std::max(a[i].area, b[j].area);
        relative = std::max(relative, std::abs(a[i].area - b[j].area) / scale);
        ++i; ++j;
    }
    return i == a.size() && j == b.size() ? relative : std::numeric_limits<double>::infinity();
}

std::vector<PneumaticPort> RelaxApertures(const std::vector<PneumaticPort>& old,
                                          const std::vector<PneumaticPort>& actual) {
    std::vector<PneumaticPort> result;
    const auto admittance = [](const auto& ports) {
        double sum = 0.;
        for (const auto& port : ports) sum += port.area / port.length;
        return sum;
    };
    const double from = admittance(old), to = admittance(actual);
    const double scale = std::max(from, to);
    const double fraction = std::min(.5, .15 * from / std::max(std::abs(to - from),
                                                                std::numeric_limits<double>::epsilon() * scale));
    std::size_t i = 0, j = 0;
    while (i < old.size() || j < actual.size()) {
        if (j == actual.size() || (i < old.size() && old[i].face < actual[j].face)) {
            auto port = old[i++];
            port.area *= 1. - fraction;
            result.push_back(port);
        } else if (i == old.size() || actual[j].face < old[i].face) {
            auto port = actual[j++];
            port.area *= fraction;
            result.push_back(port);
        } else {
            auto port = actual[j++];
            port.area = fraction * port.area + (1. - fraction) * old[i++].area;
            result.push_back(port);
        }
    }
    return result;
}

std::vector<double> PneumaticPressureSeed(const Basin& basin, const CutRegionGasTopology& pressure,
                                          const std::vector<PneumaticPort>& ports,
                                          const CutLiquidTrial& trial, const std::vector<double>& oldGauge,
                                          double dt) {
    std::vector<double> initialVolume(pressure.components.size()), finalVolume(pressure.components.size());
    for (std::size_t i = 0; i < initialVolume.size(); ++i)
        initialVolume[i] = pressure.components[i].volume;
    for (std::size_t cell = 0; cell < trial.state.water.size(); ++cell) {
        const auto owner = pressure.regionOwner[cell];
        if (owner != NoCutRegionGas)
            finalVolume[owner] += basin.geometry.startCapacity[cell] - trial.state.water[cell];
    }
    const auto fixedStorage = [&](std::size_t owner, double) { return std::pair{finalVolume[owner], 0.}; };
    constexpr double scale = 1000. * gravity;
    GasMidpoint shifted;
    auto seed = trial.head;
    if (!SolveFiniteGas(dt, scale, initialVolume, basin.gasPressure, ports, fixedStorage, shifted))
        return seed;
    for (std::size_t j = 0; j < shifted.owners.size(); ++j) {
        const auto owner = shifted.owners[j];
        const double change = shifted.head[j] - oldGauge[owner] / scale;
        for (const auto cell : pressure.components[owner].regions)
            seed[cell] += change;
    }
    return seed;
}

bool ContinuePressureOwners(const Basin& basin, const CutRegionGasTopology& pressure,
                            const CutRegionGasTopology& geometric, const std::vector<PneumaticPort>& ports,
                            const GasMidpoint& linked, const std::vector<double>& meanGauge, double dt,
                            CutRegionGasTopology& result, std::vector<double>& absolutePressure,
                            std::vector<double>& gasMass, std::vector<double>& nextVelocity, std::string& error) {
    auto next = geometric;
    next.components.assign(basin.graph.components.size(), {});
    std::vector<long double> byOwner(next.components.size());
    double unsupported = 0.;
    for (std::size_t i = 0; i < next.regionOwner.size(); ++i) {
        if (next.regionOwner[i] == NoCutRegionGas)
            continue;
        const auto owner = pressure.regionOwner[i];
        if (owner == NoCutRegionGas) {
            unsupported += next.regionVolume[i];
            continue;
        }
        next.regionOwner[i] = owner;
        next.components[owner].regions.push_back(i);
        byOwner[owner] += next.regionVolume[i];
    }
    if (unsupported != 0.) {
        error = "finite gas endpoint has newly exposed dry material with no pressure owner";
        return false;
    }
    for (std::size_t i = 0; i < next.components.size(); ++i)
        next.components[i].volume = static_cast<double>(byOwner[i]);
    const auto count = next.components.size();
    absolutePressure.assign(count, ambient);
    gasMass = basin.gasMass;
    nextVelocity.assign(basin.geometry.faces.size(), 0.);
    std::vector<long double> out(count);
    long double pressureWork = 0., gasEnergy = 0., kineticChange = 0.;
    for (const auto& port : ports) {
        const double a = meanGauge[port.left], b = meanGauge[port.right];
        const double q = GasPortVolume(dt, port, a, b);
        out[port.left] += q;
        out[port.right] -= q;
        const double u = port.predictedSpeed + dt * (a - b) / (pneumaticDensity * port.length);
        const double portMass = pneumaticDensity * port.area * port.length;
        kineticChange += .5L * portMass * (u + port.predictedSpeed) * (u - port.predictedSpeed);
        nextVelocity[port.face] = u;
    }
    double maximum = 0.;
    for (std::size_t owner = 1; owner < count; ++owner) {
        const long double v0 = basin.graph.components[owner].volume, v1 = byOwner[owner];
        const long double p0 = basin.gasPressure[owner], mean = meanGauge[owner];
        if (!(v1 > 0.)) {
            error = "finite gas endpoint lost a pressure owner";
            return false;
        }
        const auto i = linked.index.empty() ? count : linked.index[owner];
        if (i >= linked.owners.size()) {
            const long double p1 = p0 * std::pow(v0 / v1, exponent);
            const long double energy = (p1 * v1 - p0 * v0) / (exponent - 1.);
            const long double work = -(mean + ambient) * (v1 - v0);
            if (std::abs(energy - work) > 1e-8 * (1. + std::abs(work))) {
                error = "closed gas endpoint work failed inside finite stage";
                return false;
            }
            absolutePressure[owner] = static_cast<double>(p1);
            continue;
        }
        const long double gauge0 = p0 - ambient, gauge1 = 2. * mean - gauge0;
        const long double capacitance = linked.capacitance[i];
        const long double residual = (v1 - v0) + out[owner] + capacitance * (gauge1 - gauge0);
        maximum = std::max(maximum, static_cast<double>(std::abs(residual)));
        if (!(gauge1 + ambient > 0.)) {
            error = "finite gas midpoint cannot own nonpositive endpoint absolute pressure";
            return false;
        }
        absolutePressure[owner] = static_cast<double>(gauge1 + ambient);
        gasMass[owner] -= pneumaticDensity * static_cast<double>(out[owner]);
        if (!(gasMass[owner] > 0.)) {
            error = "finite gas midpoint overdrew a pressure owner's gas mass";
            return false;
        }
        pressureWork -= mean * (v1 - v0);
        gasEnergy += .5L * capacitance * (gauge1 + gauge0) * (gauge1 - gauge0);
        std::cout << "FINITE_OWNER id=" << owner << " volume=" << v1 << " initial_Pa=" << p0
                  << " midpoint_gauge_Pa=" << mean << " endpoint_Pa=" << absolutePressure[owner]
                  << " out_m3=" << out[owner] << " ledger_m3=" << residual << '\n';
    }
    const long double massResidual = std::accumulate(gasMass.begin(), gasMass.end(), 0.L) -
        std::accumulate(basin.gasMass.begin(), basin.gasMass.end(), 0.L) + pneumaticDensity * (-out[0]);
    const long double workResidual = pressureWork - gasEnergy - kineticChange;
    if (!(maximum <= 2e-13 && std::abs(workResidual) <= 1e-8L * (1. + std::abs(pressureWork)) &&
          std::abs(massResidual) < 1e-13)) {
        error = "finite gas independent mass, volume or midpoint work ledger failed";
        return false;
    }
    std::cout << "FINITE_LEDGER geometric_closed=" << geometric.components.size() - 1
              << " pressure_owners=" << count - 1 << " ports=" << ports.size()
              << " volume_error_m3=" << maximum << " mass_error_kg=" << massResidual
              << " work_error_J=" << workResidual << " work_J=" << pressureWork << '\n';
    result = std::move(next);
    return true;
}

double Total(const std::vector<double>& values) {
    return static_cast<double>(std::accumulate(values.begin(), values.end(), 0.L));
}

} // namespace

int main(int argc, char** argv) {
    int steps = 1;
    double dt = double(tick);
    bool rotated = false, originalAperture = false, strictWaterDonor = false, budgetWater = true, splitAtEndpoint = false, finite = false, lagged = false;
    for (int i = 1; i < argc; ++i) {
        const std::string_view flag(argv[i]);
        if (flag == "--rotated") rotated = true;
        else if (flag == "--original-aperture") originalAperture = true;
        else if (flag == "--unbudgeted") budgetWater = false;
        else if (flag == "--finite") finite = true;
        else if (flag == "--lagged") lagged = true;
        else if (flag == "--split-at-endpoint") splitAtEndpoint = true;
        else if (flag == "--strict-water-donor") strictWaterDonor = true;
        else if (flag == "--steps" && i + 1 < argc) steps = std::stoi(argv[++i]);
        else if (flag == "--divisor" && i + 1 < argc) dt /= std::stod(argv[++i]);
        else return 2;
    }
    Basin basin;
    std::string error;
    std::cout << std::setprecision(17);
    if (!Build(Fixture::Authored(rotated), basin, error)) {
        std::cout << "FAIL setup " << error << '\n';
        return 1;
    }
    const double initialWater = Total(basin.state.water);
    std::cout << "BEGIN rotated=" << rotated << " dt=" << dt << " water=" << initialWater
              << " regions=" << basin.chart.regions.size() << " faces=" << basin.geometry.faces.size() << '\n';
    for (int i = 0; i < steps; ++i) {
        const auto claims = ProposeFrontier(basin.geometry, basin.slabs, basin.graph);
        auto pressure = ExtendFrontier(basin.graph, claims);
        CutLiquidTrial trial;
        std::vector<double> meanGauge;
        GasMidpoint linked;
        auto ports = lagged ? InitialPneumatic(basin, pressure) : std::vector<PneumaticPort>{};
        const auto begin = std::chrono::steady_clock::now();
        if (!TrialCutLiquidGas(basin.chart, basin.geometry, basin.state, dt, 1, double(gravity),
                               &pressure, originalAperture ? nullptr : &basin.slabs, basin.gasPressure,
                               budgetWater, trial, meanGauge, error, ports,
                               ports.empty() ? nullptr : &basin.state.pressureHead, &linked)) {
            std::cout << "FAIL solve step=" << i << " " << error << '\n';
            return 1;
        }
        auto sides = basin.sides;
        std::vector<CutRegionWaterPlane> slabs;
        CutRegionGasTopology graph;
        if (!RebuildEndpoint(basin, claims, trial.state.water, sides, slabs, graph, error)) {
            std::cout << "FAIL provisional endpoint step=" << i << ' ' << error << '\n';
            return 1;
        }
        if (finite && !MeasurePneumatic(basin, pressure, graph, trial.state.water, sides, ports, error)) {
            std::cout << "FAIL pneumatic geometry step=" << i << ' ' << error << '\n';
            return 1;
        }
        if (finite && !ports.empty()) {
            bool accepted = false;
            for (int outer = 0; outer < 56; ++outer) {
                auto seed = outer == 0 ? trial.head :
                    PneumaticPressureSeed(basin, pressure, ports, trial, meanGauge, dt);
                if (!TrialCutLiquidGas(basin.chart, basin.geometry, basin.state, dt, 1, double(gravity),
                                       &pressure, originalAperture ? nullptr : &basin.slabs, basin.gasPressure,
                                       budgetWater, trial, meanGauge, error, ports, &seed, &linked) ||
                    !RebuildEndpoint(basin, claims, trial.state.water, sides, slabs, graph, error)) {
                    std::cout << "FAIL linked pressure step=" << i << " outer=" << outer << ' ' << error << '\n';
                    return 1;
                }
                std::vector<PneumaticPort> nextPorts;
                if (!MeasurePneumatic(basin, pressure, graph, trial.state.water, sides, nextPorts, error)) {
                    std::cout << "FAIL linked aperture step=" << i << " outer=" << outer << ' ' << error << '\n';
                    return 1;
                }
                const double change = MaxPortDifference(ports, nextPorts);
                const auto aperture = [](const auto& values) {
                    double total = 0.;
                    for (const auto& port : values) total += port.area / port.length;
                    return total;
                };
                std::cout << "FINITE_OUTER step=" << i << " outer=" << outer << " old_ports=" << ports.size()
                          << " new_ports=" << nextPorts.size() << " area_change=" << change
                          << " old_admittance=" << aperture(ports) << " new_admittance=" << aperture(nextPorts)
                          << " local_water_error=" << trial.residual << " local_gas_error=" << linked.residual << '\n';
                if (change <= 2e-5) {
                    accepted = true;
                    break;
                }
                if (nextPorts.empty())
                    break;
                ports = RelaxApertures(ports, nextPorts);
            }
            if (!accepted) {
                std::cout << "FAIL linked aperture feedback did not converge step=" << i << '\n';
                return 1;
            }
        }
        const double elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - begin).count();
        std::vector<double> waterOut(basin.chart.regions.size());
        for (std::size_t f = 0; f < trial.flux.size(); ++f) {
            const auto& face = basin.geometry.faces[f];
            const double amount = trial.flux[f];
            waterOut[amount >= 0. ? face.left : face.right] += std::abs(amount);
        }
        double worstDonor = 0.;
        for (std::size_t cell = 0; cell < waterOut.size(); ++cell)
            worstDonor = std::max(worstDonor, waterOut[cell] - basin.state.water[cell]);
        std::cout << "SOLVE step=" << i << " ms=" << elapsed << " iterations=" << trial.iterations << '/'
                  << trial.linearIterations << " residual=" << trial.residual << " water_drift="
                  << Total(trial.state.water) - initialWater << " max_speed=" << trial.maximumFaceSpeed
                  << " donors_limited=" << trial.donorsLimited << " water_donor_excess=" << worstDonor << '\n';
        if (strictWaterDonor && worstDonor > 0.) {
            std::cout << "FAIL local water donor overspend\n";
            return 1;
        }
        std::vector<double> gasPressure, gasMass, gasVelocity(basin.gasVelocity.size());
        if (!ports.empty() || (lagged && HasMerge(graph, pressure))) {
            CutRegionGasTopology owners;
            if (!ContinuePressureOwners(basin, pressure, graph, ports, linked, meanGauge, dt,
                                        owners, gasPressure, gasMass, gasVelocity, error)) {
                std::cout << "FAIL linked endpoint step=" << i << ' ' << error << '\n';
                return 1;
            }
            graph = std::move(owners);
        } else if (!PreserveOwners(basin.graph, graph, pressure, basin.gasPressure, basin.gasMass,
                                   meanGauge, splitAtEndpoint, gasPressure, gasMass, error)) {
            std::cout << "FAIL endpoint gas step=" << i << " " << error << '\n';
            return 1;
        }
        basin.state = std::move(trial.state);
        basin.slabs = std::move(slabs);
        basin.sides = std::move(sides);
        basin.graph = std::move(graph);
        basin.gasPressure = std::move(gasPressure);
        basin.gasMass = std::move(gasMass);
        basin.gasVelocity = std::move(gasVelocity);
        std::cout << "STAGE step=" << i << '\n';
    }
}
