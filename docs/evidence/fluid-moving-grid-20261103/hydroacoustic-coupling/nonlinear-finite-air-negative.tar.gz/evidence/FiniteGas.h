#pragma once

#include <cstddef>
#include <functional>
#include <utility>
#include <vector>

namespace judas::volume_grid {

struct PneumaticPort {
    std::size_t face, left, right;
    double length, area, predictedSpeed;
};

struct GasMidpoint {
    std::vector<std::size_t> owners, index;
    std::vector<double> head, inverse, capacitance, volumes;
    double residual = 0.;
};

constexpr double pneumaticDensity = 1.2;
constexpr double ambientPressure = 101325.;
constexpr double gasExponent = 1.4;

using GasStorage = std::function<std::pair<double, double>(std::size_t owner, double gasHead)>;

bool SolveFiniteGas(double dt, double scale, const std::vector<double>& initialVolume,
                    const std::vector<double>& absolutePressure, const std::vector<PneumaticPort>& ports,
                    const GasStorage& storage, GasMidpoint& result);

double GasPortVolume(double dt, const PneumaticPort& port, double leftGauge, double rightGauge);

} // namespace judas::volume_grid
