# Coupled water and finite pneumatic pressure in the original level basin

This disposable experiment uses the preserved cut geometry from the
interface-ownership checkpoint. It runs the original 9.25 m³ level
seed at the original 60 Hz cadence with stationary solids. The four
initial staged intervals and earlier endpoint split policy are kept.
The experiment does not publish moving-body or runtime state.

Run `./reproduce.sh first` with a C++17 compiler and GLM. This is the
strongest measured partial result. The optional cases `shift`,
`coordinate`, `tangent`, `lagged`, and `stable` reproduce the distinct
failed experiments. Each run preserves rejection. The archive contains
no build artifacts.

## Finite chamber model

Dry pressure ownership is separate from geometric connectivity. The
old resolved chamber domains keep their pressures when a dry path opens.
For this experiment each linked chamber has one pressure and linearized
adiabatic storage `C=V0/(gamma * p_abs0)`. Nonlinked chambers retain
their previous finite-volume adiabatic work relation.

The linked pressure projection uses midpoint pressure in the gas
volume balance. The terms are `2C(p_mid-p_old)`, the actual gas-volume
change from water storage, and one paired gas transfer per physical
shared aperture. The transfer law is
`q=dt A u_old + dt^2 A (p_left-p_right)/(2 rho L)`.
Each aperture is measured from the dry traces of the same phase
geometry. This trial estimates mean area with 16 midpoint samples of
the interpolated old and trial water volumes. It checks the resulting
endpoint area again and refuses to publish a mismatched pressure path.

For a fixed water-head iterate, a small positive gas Schur block
eliminates the linked gas pressures. Its water derivative is applied
to the outer constrained wet-storage Newton solve. The water outflow
active-set preserves the previous exact donor inventory gate.
An independent two-chamber suite passes 7/7 checks, including
a closed-form pressure oracle, shared mass, pressure work and
link kinetic energy, and the water-volume derivative of the gas
pressure block. The standalone work residual is 1.07e-14 J.

## Basin evidence

The fifth interval forms a dry connection between two of four pressure
owners through 32 apertures. At its first finite solve, the old state
and proposed gas apertures produce water and gas residuals of
1.93e-15 and 7.98e-16 m³. The resulting water and dry geometry changes
the aggregate aperture/length from 0.008286 to 0.062166 m, a factor of
7.50. Some individual areas change by more than 95%. Re-solving with
the updated physical apertures stalls at a water residual of
1.32e-10 m³ in fully saturated ordinary region 12234, below the
volume scale of that cut but above the preserved acceptance tolerance.
There is no fifth publication. A frozen first aperture solve does not
qualify geometry feedback.

A gas pressure-seed shift with an under-relaxed aperture update also
rejects. Exact local gas pressure re-elimination during coordinate
smoothing stalls on the first linked solve. Detecting and anchoring
singular tangent subgraphs changes the inherited active-set trajectory
and stalls even on the provisional solve. These are separate negative
controls rather than runtime alternatives.

A separate first-order lagged geometry control preserves four pressure
owners while allowing the fifth interval's geometric merge. It opens
finite connections only on the next step. This delays actual gas
transfer through the newly opening apertures for one step and is
outside the stronger swept-aperture model. Its first finite linked
interval rejects at a 2.02e-5 m³ water residual, so it does not stage
a finite linked endpoint.

An intermediate tighter gas-residual run exposed a scratch invalid
iterate fault when gas evaluation returned without populated arrays.
The correction preserves rejected trial state. The corrected tighter
variant rejects at 4.52e-10 m³ water residual on its first linked solve.
Both source and the terminal log are retained. No test criterion was
relaxed to accept any of these outcomes.

This result isolates coupled aperture and wet-storage active-set
convergence. It does not qualify gas advection, changes in per-port
momentum support, rigid pressure reactions, or the original rotated
and settling fixtures.
