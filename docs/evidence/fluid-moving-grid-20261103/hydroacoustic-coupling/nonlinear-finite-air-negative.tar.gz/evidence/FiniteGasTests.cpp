#include "FiniteGas.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>

using namespace judas::volume_grid;

int main() {
    int tests = 0, failures = 0;
    const auto check = [&](bool ok, const char* label) {
        ++tests;
        failures += !ok;
        std::cout << (ok ? "PASS " : "FAIL ") << label << '\n';
    };
    std::cout << std::setprecision(17);
    const double dt = 1. / 60., scale = 9810.;
    const std::vector<double> initial{0., .168, .11}, pressure{ambientPressure, 110000., 104000.};
    const std::vector<double> delta{0., -.001, .0004};
    const auto prescribed = [&](std::size_t owner, double) { return std::pair{initial[owner] + delta[owner], 0.}; };
    const std::vector<PneumaticPort> ports{{0, 1, 2, .1, .001, .15}};
    GasMidpoint gas;
    const bool solved = SolveFiniteGas(dt, scale, initial, pressure, ports, prescribed, gas);
    check(solved && gas.owners == std::vector<std::size_t>{1, 2}, "coupled gas owners solve independently");
    if (!solved)
        return 1;
    const double p0 = gas.head[0] * scale, p1 = gas.head[1] * scale;
    const double c0 = initial[1] / (gasExponent * pressure[1]);
    const double c1 = initial[2] / (gasExponent * pressure[2]);
    const auto& face = ports[0];
    const double k = .5 * dt * dt * face.area / (pneumaticDensity * face.length);
    const double pred = dt * face.area * face.predictedSpeed;
    const double h0 = pressure[1] - ambientPressure, h1 = pressure[2] - ambientPressure;
    const double lhs0 = 2. * c0 + k, lhs1 = 2. * c1 + k;
    const double rhs0 = 2. * c0 * h0 - delta[1] - pred;
    const double rhs1 = 2. * c1 * h1 - delta[2] + pred;
    const double determinant = lhs0 * lhs1 - k * k;
    const double expected0 = (rhs0 * lhs1 + rhs1 * k) / determinant;
    const double expected1 = (rhs1 * lhs0 + rhs0 * k) / determinant;
    check(std::abs(p0 - expected0) < 1e-10 && std::abs(p1 - expected1) < 1e-10,
          "midpoint pressure matches independently inverted two-chamber system");
    const double end0 = 2. * p0 - h0, end1 = 2. * p1 - h1;
    const double q = GasPortVolume(dt, face, p0, p1);
    const double u = face.predictedSpeed + dt * (p0 - p1) / (pneumaticDensity * face.length);
    const double mass0 = c0 * (end0 - h0) + delta[1];
    const double mass1 = c1 * (end1 - h1) + delta[2];
    check(std::abs(mass0 + q) < 1e-15 && std::abs(mass1 - q) < 1e-15 &&
          std::abs(mass0 + mass1) < 1e-15, "shared face transfer conserves linearized gas mass");
    const double work = -p0 * delta[1] - p1 * delta[2];
    const double energy = .5 * (c0 * (end0 + h0) * (end0 - h0) + c1 * (end1 + h1) * (end1 - h1));
    const double kinetic = .5 * pneumaticDensity * face.area * face.length *
        (u + face.predictedSpeed) * (u - face.predictedSpeed);
    check(std::abs(work - energy - kinetic) < 1e-11, "midpoint gas storage and pneumatic inertia close work");

    const auto deformableStorage = [&](std::size_t owner, double head) {
        const double area = .009 + owner * .003;
        return std::pair{initial[owner] + delta[owner] + head * area, area};
    };
    GasMidpoint coupled, perturbed;
    const bool nonlinear = SolveFiniteGas(dt, scale, initial, pressure, ports, deformableStorage, coupled);
    const auto perturb = [&](std::size_t owner, double head) {
        auto pair = deformableStorage(owner, head);
        if (owner == 1) pair.first -= 1e-7;
        return pair;
    };
    const bool perturbedOkay = SolveFiniteGas(dt, scale, initial, pressure, ports, perturb, perturbed);
    check(nonlinear && perturbedOkay &&
          std::abs((perturbed.head[0] - coupled.head[0]) / 1e-7 - coupled.inverse[0]) < 1e-6 &&
          std::abs((perturbed.head[1] - coupled.head[1]) / 1e-7 - coupled.inverse[2]) < 1e-6,
          "gas Schur inverse gives the water-volume derivative on both linked regions");

    auto narrow = ports;
    narrow[0].area = 2.168404344971007e-18;
    narrow[0].predictedSpeed = 0.;
    GasMidpoint nearSealed;
    const bool narrowOkay = SolveFiniteGas(dt, scale, initial, pressure, narrow, prescribed, nearSealed);
    check(narrowOkay && std::abs(nearSealed.head[0] * scale - (h0 - delta[1] / (2. * c0))) < 1e-9 &&
          std::abs(GasPortVolume(dt, narrow[0], nearSealed.head[0] * scale, nearSealed.head[1] * scale)) < 1e-15,
          "actual sub-coordinate neck has finite transfer and approaches sealed pressure continuously");

    auto invalid = ports;
    invalid[0].length = 0.;
    check(!SolveFiniteGas(dt, scale, initial, pressure, invalid, prescribed, gas) &&
          gas.head[0] * scale == p0, "invalid length rejects without replacing prior trial");
    std::cout << "CHECKS " << tests << " FAILURES " << failures << " work_error_J=" << (work - energy - kinetic) << '\n';
    return failures != 0;
}
