#include "CutHydroacousticPressure.h"
#include "CutRegionGeometry.h"
#include "PhysicsConstraintBatch.h"
#include "PhysicsWorld.h"

#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

using namespace judas;
using namespace judas::volume_grid;

constexpr double g = 9.81, rhoW = 1000., rhoG = 1.2, c = 343.;
constexpr double scale = rhoW * g, bulk = rhoG * c * c;
constexpr double endArea = .125, storageArea = 1.;
constexpr float tick = 1.f / 60.f;
constexpr glm::vec3 half(.125f, .125f, .25f);
using Heads = std::array<double, 4>;
using Matrix = std::array<Heads, 4>;
using Capacity = std::array<std::array<double, 2>, 2>;

void Require(bool condition, const std::string& error) {
    if (!condition)
        throw std::runtime_error(error);
}

double AbsMax(glm::dvec3 x) {
    return std::max({std::abs(x.x), std::abs(x.y), std::abs(x.z)});
}

double HalfUlp(float x) {
    return .5 * std::max(double(std::nextafter(x, INFINITY)) - x,
                         double(x) - std::nextafter(x, -INFINITY));
}

Heads Solve(Matrix m, Heads rhs) {
    for (std::size_t k = 0; k < rhs.size(); ++k) {
        for (std::size_t i = k + 1; i < rhs.size(); ++i) {
            const double multiplier = m[i][k] / m[k][k];
            for (std::size_t j = k + 1; j < rhs.size(); ++j)
                m[i][j] -= multiplier * m[k][j];
            rhs[i] -= multiplier * rhs[k];
        }
    }
    for (std::size_t i = rhs.size(); i-- > 0;) {
        for (std::size_t j = i + 1; j < rhs.size(); ++j)
            rhs[i] -= m[i][j] * rhs[j];
        rhs[i] /= m[i][i];
    }
    return rhs;
}

struct Anchor {
    float x = 0., speed = 0.;
    double begin = 0.;
    bool valid = false;
};

struct Forecast {
    float x, speed;
    Anchor anchor;
};

Forecast Predict(Anchor anchor, float start, float speed, double begin, double h) {
    if (!anchor.valid || anchor.speed != speed ||
        anchor.x + anchor.speed * float(begin - anchor.begin) != start)
        anchor = {start, speed, begin, true};
    return {anchor.x + anchor.speed * float(h - (anchor.begin - begin)), speed, anchor};
}

struct State {
    std::array<double, 2> mass{};
    std::array<double, 2> head{};
    std::array<double, 2> speed{};
};

struct Fixture {
    bool waterBody;
    CutRegionChart chart;

    explicit Fixture(bool wet) : waterBody(wet) {
        std::string error;
        const double y = Y();
        const BoxMotion solid{1, {.875, y - .125, .25}, {1.125, y + .125, .75}, {}};
        const bool okay = PrepareCutRegionChart({{2, 1, 1}, 1.}, {}, solid,
                                                {-.0625, 0., 0.}, {.0625, 0., 0.}, chart, error);
        Require(okay, error);
        Require(chart.layout.CellCount() == 2 && chart.regions.size() > 2 && !chart.faces.empty(),
                "not the intended two-chamber geometry");
    }

    float Y() const { return waterBody ? .25f : .75f; }

    CutRegionGeometry Geometry(double x, double dx = 0.) const {
        CutRegionGeometry geometry;
        std::string error;
        const bool okay = BuildCutRegionGeometry(chart, {x, 0., 0.}, {dx, 0., 0.}, geometry, error);
        Require(okay, error);
        return geometry;
    }

    Capacity Volumes(const CutRegionGeometry& geometry, const State& state) const {
        Capacity volumes{};
        for (const auto& region : chart.regions) {
            const auto measured = MeasureCutRegionPhaseVolumes(region, geometry.motion,
                region.lo, region.hi, {{1, false}, .5, state.head[region.parent]});
            for (std::size_t phase = 0; phase < measured.size(); ++phase)
                volumes[region.parent][phase] += measured[phase];
        }
        return volumes;
    }
};

struct Staged {
    Forecast forecast{};
    CutHydroacousticResult result;
    std::vector<CutHydroacousticRegion> regions;
    std::vector<CutHydroacousticPort> ports;
    glm::dvec3 force{0.}, torque{0.};
    double sourceError = 0., forceError = 0., workError = 0., referenceError = 0.;
};

Staged Stage(const Fixture& fixture, const State& state, float start, Forecast end, double h) {
    Staged stage;
    stage.forecast = end;
    const double dx = double(end.x) - start;
    const auto geometry = fixture.Geometry(start, dx);
    const auto before = fixture.Volumes(geometry, state);
    const auto fixed = fixture.Volumes(fixture.Geometry(end.x), state);
    // Collapse only the manufactured chamber pressure DOFs. The aperture and
    // phase capacities still come from all true locally partitioned cut cells.
    constexpr double chamberLength = 1.;
    double aw = 0., ag = 0.;
    for (std::size_t i = 0; i < before.size(); ++i) {
        stage.regions.push_back({before[i][0], before[i][1], state.mass[i],
                                 fixed[i][0], fixed[i][1], storageArea, state.head[i]});
        for (std::size_t phase = 0; phase < 2; ++phase) {
            const double expected = fixture.waterBody == (phase == 0) ?
                (i == 0 ? -endArea : endArea) * dx : 0.;
            stage.sourceError = std::max(stage.sourceError,
                std::abs((before[i][phase] - fixed[i][phase]) - expected));
        }
    }
    const CutRegionWaterPlane left{{1, false}, .5, state.head[0]};
    const CutRegionWaterPlane right{{1, false}, .5, state.head[1]};
    for (const auto& face : geometry.faces) {
        const auto chamberLeft = fixture.chart.regions[face.left].parent;
        const auto chamberRight = fixture.chart.regions[face.right].parent;
        if (chamberLeft == chamberRight)
            continue;
        Require(face.axis == 0 && chamberLeft == 0 && chamberRight == 1, "unexpected chamber face");
        aw += MeasureCutRegionSharedPhase(face, geometry.motion, left, right, true, true).mean;
        ag += MeasureCutRegionSharedPhase(face, geometry.motion, left, right, false, false).mean;
    }
    stage.ports = {{0, 1, CutFluidPhase::Water, aw, chamberLength, state.speed[0]},
                   {0, 1, CutFluidPhase::Gas, ag, chamberLength, state.speed[1]}};
    std::string error;
    const bool okay = SolveCutHydroacousticPressure(stage.regions, stage.ports, {h}, stage.result, error);
    Require(okay, error);

    Matrix matrix{};
    Heads rhs{};
    const double gw = h * h * aw * g / (2. * chamberLength);
    const double gg = h * h * ag * scale / (2. * rhoG * chamberLength);
    const double q0w = h * aw * state.speed[0], q0g = h * ag * state.speed[1];
    for (std::size_t i = 0; i < 2; ++i) {
        const std::size_t w = 2*i, a = w + 1;
        const double capacitance = scale * before[i][1] / bulk;
        const double excess = state.mass[i] / rhoG - before[i][1];
        const double sign = i == 0 ? 1. : -1.;
        matrix[w][w] = 2. * storageArea + gw;
        matrix[w][2-w] = -gw;
        matrix[a][a] = 2. * (storageArea + capacitance) + gg;
        matrix[a][4-a] = -gg;
        matrix[w][a] = matrix[a][w] = -2. * storageArea;
        rhs[w] = before[i][0] - fixed[i][0] + 2. * storageArea * state.head[i] - sign * q0w;
        rhs[a] = before[i][1] - fixed[i][1] + 2. * excess -
                 2. * storageArea * state.head[i] - sign * q0g;
    }
    const auto p = Solve(matrix, rhs);
    for (std::size_t i = 0; i < 2; ++i) {
        stage.referenceError = std::max(stage.referenceError,
            std::max(std::abs(scale * p[2*i] - stage.result.waterPressure[i]),
                     std::abs(scale * p[2*i+1] - stage.result.gasPressure[i])));
    }
    const auto& traction = fixture.waterBody ? stage.result.waterPressure : stage.result.gasPressure;
    const glm::dvec3 center(1. + .5 * (double(start) + end.x), fixture.Y(), .5);
    for (const auto& patch : geometry.patches) {
        Require(patch.owner == 1 && patch.cell < fixture.chart.regions.size(), "unowned pressure patch");
        const auto chamber = fixture.chart.regions[patch.cell].parent;
        Require(fixture.waterBody ? patch.centroid[1] < .5 + state.head[chamber] :
                                   patch.centroid[1] > .5 + state.head[chamber],
                "body left intended phase");
        glm::dvec3 force(0.);
        force[patch.axis] = -patch.sign * patch.area * traction[chamber];
        const glm::dvec3 point(patch.centroid[0], patch.centroid[1], patch.centroid[2]);
        stage.force += force;
        stage.torque += glm::cross(point - center, force);
    }
    stage.forceError = AbsMax(stage.force - glm::dvec3(endArea * (traction[0] - traction[1]), 0., 0.));
    stage.workError = stage.result.wallWork + stage.force.x * dx;
    return stage;
}

double IndependentFluidEnergyChange(const Staged& stage, const State& old) {
    double change = 0.;
    for (std::size_t i = 0; i < 2; ++i) {
        const auto& r = stage.regions[i];
        const double capacitance = scale * r.gasVolume / bulk;
        const double oldCompression = old.mass[i] / rhoG - r.gasVolume;
        const double newCompression = stage.result.gasMass[i] / rhoG - stage.result.gasVolume[i];
        const double endHead = stage.result.surfaceHead[i];
        change += .5 * scale * (storageArea * (endHead - old.head[i]) * (endHead + old.head[i]) +
            (newCompression - oldCompression) * (newCompression + oldCompression) / capacitance);
        const auto& port = stage.ports[i];
        const double newSpeed = stage.result.portSpeed[i];
        change += .5 * (i == 0 ? rhoW : rhoG) * port.area * port.length *
            (newSpeed - port.speed) * (newSpeed + port.speed);
    }
    return change;
}

// Independent two-dimensional antisymmetric pressure result for the initial
// rest-fluid state. This uses the *actual represented* moving-box distance.
double InitialAntisymmetricError(const Staged& stage, bool wet, double dx, double h) {
    const double wetDiagonal = 2. * storageArea +
        h * h * stage.ports[0].area * g / stage.ports[0].length;
    const double gasDiagonal = 2. * (storageArea + scale * stage.regions[0].gasVolume / bulk) +
        h * h * stage.ports[1].area * scale / (rhoG * stage.ports[1].length);
    const double coupling = 2. * storageArea;
    const double det = wetDiagonal * gasDiagonal - coupling * coupling;
    const double source = -endArea * dx;
    const double pw = scale * source * (wet ? gasDiagonal : coupling) / det;
    const double pg = scale * source * (wet ? coupling : wetDiagonal) / det;
    return std::max({std::abs(pw - stage.result.waterPressure[0]), std::abs(-pw - stage.result.waterPressure[1]),
                     std::abs(pg - stage.result.gasPressure[0]), std::abs(-pg - stage.result.gasPressure[1])});
}

struct PathTrial {
    float speed, response, endpoint;
    double impulse, rawResponse;
};

struct RepresentableBracket {
    float chosen;
    double requestedImpulse, impulseBudget, extraBudget;
};

std::optional<RepresentableBracket> SelectRepresentableMomentum(PathTrial a, PathTrial b,
                                                               float initial, double inverseMass) {
    if (a.speed > b.speed)
        std::swap(a, b);
    if (!(std::isfinite(a.speed) && std::isfinite(b.speed) && std::isfinite(a.rawResponse) &&
          std::isfinite(b.rawResponse) && std::isfinite(a.impulse) && std::isfinite(b.impulse) &&
          std::isfinite(a.endpoint) && std::isfinite(b.endpoint) && std::isfinite(initial) &&
          std::isfinite(inverseMass) && inverseMass > 0.))
        return {};
    if (a.response != b.speed || b.response != a.speed ||
        float(a.rawResponse) != a.response || float(b.rawResponse) != b.response ||
        std::nextafter(a.speed, b.speed) != b.speed || !(a.speed < b.speed) ||
        !(a.endpoint < b.endpoint) || a.rawResponse < b.rawResponse)
        return {};

    const double ulp = double(b.speed) - a.speed;
    const double span = a.rawResponse - b.rawResponse;
    if (!(span <= ulp))
        return {};
    const auto measured = [=](float speed) { return (double(speed) - initial) / inverseMass; };
    const double residualA = measured(a.speed) - a.impulse;
    const double residualB = measured(b.speed) - b.impulse;
    if (!(residualA < 0. && residualB > 0.))
        return {};
    const float chosen = -residualA <= residualB ? a.speed : b.speed;
    // The two representable momenta bracket the monotone continuous solution.
    // The closer residual is bounded by half their gap. The extra term beyond
    // ordinary half-ULP rounding measures physical response across one pose ULP.
    const double extra = .5 * span / inverseMass;
    return RepresentableBracket{chosen, measured(chosen), .5 * ulp / inverseMass + extra, extra};
}

void TestBracketNegatives() {
    const float lo = .05f;
    const float hi = std::nextafter(lo, INFINITY);
    const float beyond = std::nextafter(hi, INFINITY);
    const double mass = 10.;
    const auto trial = [=](float speed, float response, float x, double raw) {
        return PathTrial{speed, response, x, mass * (raw - double(lo)), raw};
    };
    const double mid = .5 * (double(lo) + hi);
    const double ulp = double(hi) - lo;
    const auto a = trial(lo, hi, .001f, mid + .125 * ulp);
    const auto b = trial(hi, lo, .00101f, mid - .0625 * ulp);
    const auto positive = SelectRepresentableMomentum(a, b, lo, .1);
    Require(positive && positive->chosen == hi, "valid represented bracket did not select minimum residual");
    const auto badDistanceA = trial(lo, beyond, .001f, double(beyond));
    const auto badDistance = trial(beyond, lo, .00101f, double(lo));
    auto badResponse = b;
    badResponse.rawResponse = mid + .125 * ulp;
    auto invalid = b;
    invalid.impulse = INFINITY;
    const auto expandingA = trial(lo, hi, .001f, double(hi) + .25 * ulp);
    const auto expanding = trial(hi, lo, .00101f, double(lo) - .25 * ulp);
    const auto sameEndpoint = trial(hi, lo, .001f, mid - .0625 * ulp);
    Require(!SelectRepresentableMomentum(badDistanceA, badDistance, lo, .1) &&
            !SelectRepresentableMomentum(a, badResponse, lo, .1) &&
            !SelectRepresentableMomentum(a, invalid, lo, .1) &&
            !SelectRepresentableMomentum(expandingA, expanding, lo, .1) &&
            !SelectRepresentableMomentum(a, sameEndpoint, lo, .1),
            "unqualified represented bracket was accepted");
    std::cout << "bracket_positive=1 rejected_nonadjacent_inconsistent_nonfinite_expanding_same_pose=5\n";
}

void Run(bool wet, bool omitImpulse, unsigned outerTicks, bool outsideEnvelope = false) {
    const Fixture fixture(wet);
    PhysicsWorld world;
    Require(world.Init(), "cannot initialize native MK2");
    Shape shape;
    shape.type = ShapeType::Box;
    shape.halfExtents = half;
    const float startingX = outsideEnvelope ? .0625f : 0.f;
    const auto body = world.CreateShape(shape, {{startingX, fixture.Y(), .5f}, glm::quat(1, 0, 0, 0)},
                                        true, 10.f, 0.f, 0.f);
    Require(body.IsValid(), "cannot create native MK2 box");
    world.SetLinearVelocity(body, glm::vec3(.05f, 0.f, 0.f));
    const auto initialRotation = world.GetTransform(body).rotation;
    State state;
    const auto volumes = fixture.Volumes(fixture.Geometry(startingX), state);
    for (std::size_t i = 0; i < 2; ++i)
        state.mass[i] = rhoG * volumes[i][1];
    const double initialWater = volumes[0][0] + volumes[1][0];
    const double initialGasMass = state.mass[0] + state.mass[1];
    Anchor anchor;
    Staged pending;
    unsigned accepted = 0, published = 0, trials = 0, maxTrials = 0;
    float v0 = 0., x0 = 0., invMass = 0.;
    double h = 0., request = 0., pressureImpulse = 0.;
    unsigned snapped = 0;
    std::optional<RepresentableBracket> bracket;
    PhysicsConstraintParticipant participant;
    participant.bodies = {body};
    participant.maximumBodies = participant.maximumContacts = participant.maximumJointRows = 1;
    participant.propose = [&](const PhysicsConstraintBatch& batch, PhysicsConstraintProposal& proposal) {
        Require(batch.bodies.size() == 1 && batch.contacts.empty() && batch.joints.empty(),
                "unexpected native contact or joint");
        const auto& native = batch.bodies.front();
        Require(native.angularVelocity == glm::vec3(0) && native.orientation == initialRotation,
                "unexpected starting angular movement");
        Require(native.center.y == fixture.Y() && native.center.z == .5f &&
                native.linearVelocity.y == 0.f && native.linearVelocity.z == 0.f,
                "unexpected starting transverse movement");
        const double begin = double(batch.context.stepDeltaTime) * batch.context.index / batch.context.count;
        h = batch.context.deltaTime;
        x0 = native.center.x;
        v0 = native.linearVelocity.x;
        invMass = native.inverseMass;
        bracket.reset();
        std::optional<PathTrial> previous;
        float speed = v0;
        constexpr unsigned maxIterations = 16;
        for (trials = 1; trials <= maxIterations; ++trials) {
            pending = Stage(fixture, state, x0, Predict(anchor, x0, speed, begin, h), h);
            const double impulse = h * pending.force.x;
            const double raw = double(v0) + double(invMass) * impulse;
            const float response = float(raw);
            const PathTrial current{speed, response, pending.forecast.x, impulse, raw};
            if (response == speed)
                break;
            if (previous && previous->speed == response) {
                bracket = SelectRepresentableMomentum(*previous, current, v0, invMass);
                Require(bracket.has_value(), "native represented path has no qualified adjacent momentum bracket");
                std::cout << "bracket_step=" << accepted+1 << " lower_or_upper_trial=" << previous->speed
                          << " other_trial=" << current.speed << " trial_span=" << std::abs(previous->rawResponse - raw)
                          << " x_span=" << std::abs(double(previous->endpoint) - current.endpoint) << '\n';
                pending = Stage(fixture, state, x0, Predict(anchor, x0, bracket->chosen, begin, h), h);
                const double rawRequest = double(v0) + double(invMass) * bracket->requestedImpulse;
                Require(float(rawRequest) == bracket->chosen &&
                        std::abs(bracket->requestedImpulse - h * pending.force.x) <=
                            bracket->impulseBudget + 8. * std::numeric_limits<double>::epsilon(),
                        "representable impulse or re-evaluated pressure exceeded bracket");
                break;
            }
            previous = current;
            speed = response;
        }
        Require(trials <= maxIterations, "native represented path did not close within bounded search");
        pressureImpulse = h * pending.force.x;
        request = bracket ? bracket->requestedImpulse : pressureImpulse;
        maxTrials = std::max(maxTrials, trials);
        Require(pending.sourceError < 2e-16 && pending.forceError < 1e-12 &&
                AbsMax(pending.torque) < 1e-12 && std::abs(pending.workError) < 1e-13 &&
                pending.referenceError < 1e-10, "geometric adjoint or independent pressure check failed");
        if (accepted == 0) {
            const auto& pressures = wet ? pending.result.waterPressure : pending.result.gasPressure;
            const double error = InitialAntisymmetricError(pending, wet, double(pending.forecast.x) - x0, h);
            Require(error < 1e-10 && pending.force.x < 0. && pending.forecast.speed < v0 &&
                    std::abs(pending.result.waterPressure[0]) > 1e-4 &&
                    std::abs(pending.result.gasPressure[0]) > 1e-4 &&
                    std::abs(pending.ports[0].area - (wet ? .375 : .5)) < 1e-14 &&
                    std::abs(pending.ports[1].area - (wet ? .5 : .375)) < 1e-14,
                    "initial independent pressure, aperture or movement sign failed");
            std::cout << "initial wet_port=" << pending.ports[0].area
                      << " gas_port=" << pending.ports[1].area
                      << " pressurized_left=" << pressures[0] << " pressurized_right=" << pressures[1]
                      << " antisymmetric_oracle_error_pa=" << error << '\n';
        }
        proposal.linearImpulses = {omitImpulse ? glm::dvec3(0.) : glm::dvec3(request, 0., 0.)};
        proposal.angularImpulses = {glm::dvec3(0.)};
        return true;
    };
    participant.published = [&](const auto&) noexcept { ++published; };
    PhysicsWorld::VelocityCoupling coupling;
    coupling.physicalBatch = &participant;
    coupling.afterSubstep = [&](const auto&) {
        Require(published == accepted + 1, "impulse did not publish before endpoint");
        const auto pose = world.GetTransform(body);
        const auto v = world.GetLinearVelocity(body);
        Require(pose.position == glm::vec3(pending.forecast.x, fixture.Y(), .5f) &&
                v == glm::vec3(pending.forecast.speed, 0.f, 0.f) &&
                pose.rotation == initialRotation && world.GetAngularVelocity(body) == glm::vec3(0.f),
                "native velocity or pose changed after phase impulse proposal");
        const double dx = double(pose.position.x) - x0;
        const double dv = double(v.x) - v0;
        const double measured = dv / invMass;
        const double fluidEnergy = IndependentFluidEnergyChange(pending, state);
        const double rigidEnergy = .5 * dv * (double(v.x) + v0) / invMass;
        const double schemeDissipation = .5 * dv * dv / invMass;
        const double quantizedImpulseError = request - pressureImpulse;
        const double quantizedWork = quantizedImpulseError * v.x;
        const double rounding = (measured - request) * v.x + pending.force.x * (h * v.x - dx);
        const double closure = fluidEnergy + rigidEnergy + schemeDissipation - rounding - quantizedWork;
        if (bracket) {
            const double workBudget = bracket->impulseBudget * std::abs(v.x);
            Require(std::abs(measured - request) < 1e-14 &&
                    std::abs(measured - pressureImpulse) <= bracket->impulseBudget + 1e-14 &&
                    std::abs(quantizedWork) <= workBudget + 1e-14,
                    "actual native represented momentum or work exceeded derived bracket");
            std::cout << "snapped_step=" << accepted+1 << " chosen_velocity=" << v.x
                      << " requested=" << request << " pressure_impulse=" << pressureImpulse
                      << " measured=" << measured << " impulse_error=" << quantizedImpulseError
                      << " impulse_budget=" << bracket->impulseBudget
                      << " extra_over_half_ulp_budget=" << bracket->extraBudget
                      << " extra_work=" << quantizedWork << " work_budget=" << workBudget << '\n';
            ++snapped;
        }
        const double totalWater = pending.result.waterVolume[0] + pending.result.waterVolume[1];
        const double totalGas = pending.result.gasMass[0] + pending.result.gasMass[1];
        Require(std::abs(measured - request) <= HalfUlp(v.x) / invMass + 1e-14 &&
                std::abs(fluidEnergy - pending.result.energyChange) < 1e-12 &&
                std::abs(closure) < 1e-12 && std::abs(totalWater - initialWater) < 1e-14 &&
                std::abs(totalGas - initialGasMass) < 1e-14,
                "native impulse, fluid energy or independent inventories failed closure");
        std::cout << "accepted=" << accepted + 1 << " x=" << pose.position.x << " dx=" << dx
                  << " vx=" << v.x << " trials=" << trials << " force=" << pending.force.x
                  << " torque_max=" << AbsMax(pending.torque)
                  << " proposed_impulse=" << request << " measured_impulse=" << measured
                  << " water_error=" << totalWater - initialWater << " gas_error=" << totalGas - initialGasMass
                  << " source_error=" << pending.sourceError << " adjoint_error_J=" << pending.workError
                  << " pressure_error_pa=" << pending.referenceError << " fluid_energy_J=" << fluidEnergy
                  << " body_energy_J=" << rigidEnergy << " post_impulse_scheme_J=" << schemeDissipation
                  << " represented_rounding_J=" << rounding << " joint_work_closure_J=" << closure << '\n';
        for (std::size_t i = 0; i < 2; ++i) {
            state.head[i] = pending.result.surfaceHead[i];
            state.mass[i] = pending.result.gasMass[i];
            state.speed[i] = pending.result.portSpeed[i];
        }
        anchor = pending.forecast.anchor;
        ++accepted;
    };
    std::cout << "case=" << (wet ? "water" : "gas") << " omit_impulse=" << omitImpulse
              << " outside_envelope=" << outsideEnvelope << " cut_regions=" << fixture.chart.regions.size() << " cut_faces=" << fixture.chart.faces.size() << '\n';
    std::string failure;
    try {
        for (unsigned i = 0; i < outerTicks; ++i) {
            anchor = {};
            world.Step(tick, &coupling);
        }
    } catch (const std::exception& e) {
        failure = e.what();
    }
    std::cout << "result accepted=" << accepted << " published=" << published
              << " max_trials=" << maxTrials << " snapped=" << snapped << " reason=" << failure << '\n';
    if (outsideEnvelope)
        Require(accepted == 0 && published == 0 &&
                failure == "cut region path exceeds the compiled travel envelope",
                "out-of-envelope control published material or physical impulse");
    else if (omitImpulse)
        Require(accepted == 0 && published == 1 &&
                failure == "native velocity or pose changed after phase impulse proposal",
                "missing-pressure-impulse negative did not fail at native observation");
    else
        Require(accepted == outerTicks * 4 && failure.empty(), failure.empty() ? "missing native substeps" : failure);
}

} // namespace

int main(int argc, char** argv) {
    try {
        std::cout << std::setprecision(17);
        TestBracketNegatives();
        const unsigned ticks = argc > 1 ? std::stoul(argv[1]) : 1;
        const std::string mode = argc > 2 ? argv[2] : "all";
        if (mode == "all" || mode == "water")
            Run(true, false, ticks);
        if (mode == "all" || mode == "gas")
            Run(false, false, ticks);
        if (mode == "all") {
            Run(true, true, 1);
            Run(false, true, 1);
            Run(true, false, 1, true);
        }
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL " << e.what() << '\n';
        return 1;
    }
}
