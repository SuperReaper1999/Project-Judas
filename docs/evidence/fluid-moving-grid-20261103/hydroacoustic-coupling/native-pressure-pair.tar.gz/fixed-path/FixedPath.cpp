#include "CutHydroacousticStep.h"

#include <iomanip>
#include <iostream>
#include <numeric>

using namespace judas::volume_grid;

int main() {
    std::cout << std::setprecision(17);
    for (double y : {.25, .75}) {
        for (double startX : {0., 1./256., -1./256.}) {
            constexpr double dx = 1./4096.;
            constexpr double dt = 1./240.;
            const BoxMotion solid{1, {.875, y - .125, .25}, {1.125, y + .125, .75}, {}};
            CutRegionChart chart;
            CutRegionGeometry geometry;
            std::string error;
            if (!PrepareCutRegionChart({{2, 1, 1}, 1.}, {}, solid, {-.0625, 0., 0.},
                                       {.0625, 0., 0.}, chart, error) ||
                !BuildCutRegionGeometry(chart, {startX, 0., 0.}, {dx, 0., 0.}, geometry, error)) {
                std::cerr << error << '\n';
                return 1;
            }
            CutHydroacousticState state;
            unsigned opened = 0;
            for (std::size_t i = 0; i < chart.regions.size(); ++i) {
                const auto& region = chart.regions[i];
                const auto phase = MeasureCutRegionPhaseVolumes(region, geometry.motion,
                    region.lo, region.hi, {{1, false}, .5});
                state.waterVolume.push_back(phase[0]);
                state.gasMass.push_back(1.2 * phase[1]);
                opened += geometry.startCapacity[i] == 0. && geometry.endCapacity[i] > 0.;
            }
            const double initialWater = std::accumulate(state.waterVolume.begin(), state.waterVolume.end(), 0.);
            const double initialGas = std::accumulate(state.gasMass.begin(), state.gasMass.end(), 0.);
            CutHydroacousticStep step;
            const bool okay = AdvanceCutHydroacoustic(chart, geometry, state, {}, 1, .5, {dt}, step, error);
            std::cout << "wet=" << (y < .5) << " x0=" << startX << " dx=" << dx << " newly_open_cut_count="
                      << opened << " accepted=" << okay << " error=" << error << '\n';
            if (okay) {
                const double finalWater = std::accumulate(step.state.waterVolume.begin(), step.state.waterVolume.end(), 0.);
                const double finalGas = std::accumulate(step.state.gasMass.begin(), step.state.gasMass.end(), 0.);
                double force = 0.;
                for (const auto& material : step.loads)
                    for (const auto& load : material)
                        force += load.force[0];
                std::cout << "force_x=" << force << " wall_work=" << step.pressure.wallWork
                          << " internal_work_residual=" << step.pressure.workError
                          << " reaction_work_residual=" << step.reactionWorkError
                          << " total_water_error=" << finalWater - initialWater
                          << " total_gas_error=" << finalGas - initialGas << '\n';
            }
        }
    }
}
