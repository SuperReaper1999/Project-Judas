# Native moving-box hydroacoustic controls

The exact engine entry points were compiled from the accepted native source at
NATIVE-CHECKPOINT.txt. A local Linux CMake SDK build supplied the native archive
and command-line flags. See the recorded input and executable fingerprints.

The two-chamber manufactured pressure cases use 72 real cut subregions and 159
faces. They aggregate those cut measurements to two pressure chambers to retain
an independent analytic antisymmetric initial condition. Both phase volumes,
openings and pressure-traction integrals use the same cut geometry. The actual
full cut adapter is exercised separately by the fixed-path controls, where no
chamber aggregation is used. The pair exercises one-axis translation, without
native contacts/joints or rotation. Force is the dynamic pressure perturbation;
there is no vertical gravitational load on the constrained benchmark body.

The phase source is initial minus final capacity at the frozen interface.
A shared phase port couples its midpoint flux to its signed pressure gradient.
Wall force is the negative transpose of the same occupied-volume derivative.
The test compares the pressure with an independent dense four-by-four system
and its first step with an independent antisymmetric two-by-two formula. MK2's
body endpoint and velocity must exactly match the proposed geometric path
before committing material. A deliberately omitted pressure impulse must fail
the real native endpoint check. Water and gas inventories and work are measured
from independent physical state. MK2 post-impulse drift adds the known body
energy term 0.5 mass times squared delta-v, distinguished from float rounding.

Strict exact pressure traction passes the first four actual native substeps in
water and gas. In the eight-tick case gas passes all 32 substeps and water
publishes six, then rejects an adjacent binary32 two-cycle. Current grounded
graph independently reproduces this exact native representation failure.

A separate diagnostic chooses the adjacent representable native velocity with
smallest residual |mass*(velocity-initialVelocity) - pressureImpulse(path)|.
It applies that representable momentum and reevaluates the fluid on exactly the
observed native path. The candidate requires a real adjacent monotone two-cycle
with physical response variation no larger than one velocity ULP. Its maximum
permitted momentum difference is half the gap between residual endpoints,
mass*(velocityULP + physicalResponseSpan)/2. The work contribution is the
measured difference times post-impulse velocity and reported separately. In the
water case it publishes all 32 substeps, with one qualified snap at step 7.
Gas passes all 32 with zero snaps. Invalid envelopes and malformed, same-pose,
expanding or nonadjacent bracket controls still reject. The strict reproduction
remains unchanged. This scalar control does not establish generic snapping for
native orientation, constrained bodies, simultaneous contact, or large motion.

The full geometry binding fixed-path comparison uses the same box, waterline
and 72-region chart, with prescribed displacement. The water case at x=0
uncovers one zero-capacity cut and is explicitly rejected as a shared-face
phase event. Nearby positive/negative offsets preserve phase topology and pass.
The resulting much stronger wet pressure response is a separate inertial metric
diagnostic. Neither prescribed geometry case is an original basin replay.

## Reproduce

From the native Judas checkout with the production fluid CMake target already
configured/built in .cache/2d-stage1-build, run the following once for each of
strict-old, quantized-old, strict-grounded or quantized-grounded.

```sh
case_dir=/absolute/path/to/evidence/strict-grounded
bash "$case_dir/build-and-run.sh"
"$case_dir/native-pair"
"$case_dir/native-pair" 8 water
"$case_dir/native-pair" 8 gas
```

The strict variants exit 1 only for the expected eight-tick water failure.
The representable bracket variants pass every command above. The first command
uses the local CMake target's compiler and link library record. Set
JUDAS_BASIN_CMAKE_BUILD if using a different matching build directory.

To reproduce the geometry-adapter-only cases, run from the evidence directory.

```sh
p=fixed-path
c++ -std=c++17 -O3 -Wall -Wextra -Werror -I"$p/src" "$p/FixedPath.cpp" \
  "$p/src/"{CutHydroacousticStep,CutHydroacousticPressure,CutHydroacousticGraph,CutRegionGeometry,CutRegionGasTopology}.cpp \
  -o "$p/fixed-path"
"$p/fixed-path"
```

Build helpers omit prebuilt executable archives to keep the packet portable.
SHA256SUMS.txt covers the exact included files. Symlinks share pinned copies
between strict and representable tests. No tracked engine or gate was edited
for these controls.
