#!/usr/bin/env bash
set -euo pipefail
p=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
d="$p/tools/prototypes/fluid_volume_grid"
sources=("$p/NativeHydroPair.cpp")
for base in CutRegionGeometry CutRegionPressure CutHydroacousticPressure MovingVolumeGrid GridConservativeRemap GridGeometricMomentum GridPhaseFluxRepair HalfDualVolumeMomentum GridHalfCellGeometry; do
    sources+=("$d/$base.cpp")
done
args=()
for source in "${sources[@]}"; do args+=(--source "$source"); done
python3 "$p/build.py" --exact --output "$p/native-pair" "${args[@]}" "$@"
