#include "CutHydroacousticPressure.h"
#include "CutRegionGeometry.h"
#include "PhysicsConstraintBatch.h"
#include "PhysicsWorld.h"

#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

using namespace judas;
using namespace judas::volume_grid;

constexpr double g = 9.81, rhoW = 1000., rhoG = 1.2, c = 343.;
constexpr double scale = rhoW * g, bulk = rhoG * c * c;
constexpr double endArea = .125, storageArea = 1.;
constexpr float tick = 1.f / 60.f;
constexpr glm::vec3 half(.125f, .125f, .25f);
using Heads = std::array<double, 4>;
using Matrix = std::array<Heads, 4>;
using Capacity = std::array<std::array<double, 2>, 2>;

void Require(bool condition, const std::string& error) {
    if (!condition)
        throw std::runtime_error(error);
}

double AbsMax(glm::dvec3 x) {
    return std::max({std::abs(x.x), std::abs(x.y), std::abs(x.z)});
}

double HalfUlp(float x) {
    return .5 * std::max(double(std::nextafter(x, INFINITY)) - x,
                         double(x) - std::nextafter(x, -INFINITY));
}

Heads Solve(Matrix m, Heads rhs) {
    for (std::size_t k = 0; k < rhs.size(); ++k) {
        for (std::size_t i = k + 1; i < rhs.size(); ++i) {
            const double multiplier = m[i][k] / m[k][k];
            for (std::size_t j = k + 1; j < rhs.size(); ++j)
                m[i][j] -= multiplier * m[k][j];
            rhs[i] -= multiplier * rhs[k];
        }
    }
    for (std::size_t i = rhs.size(); i-- > 0;) {
        for (std::size_t j = i + 1; j < rhs.size(); ++j)
            rhs[i] -= m[i][j] * rhs[j];
        rhs[i] /= m[i][i];
    }
    return rhs;
}

struct Anchor {
    float x = 0., speed = 0.;
    double begin = 0.;
    bool valid = false;
};

struct Forecast {
    float x, speed;
    Anchor anchor;
};

Forecast Predict(Anchor anchor, float start, float speed, double begin, double h) {
    if (!anchor.valid || anchor.speed != speed ||
        anchor.x + anchor.speed * float(begin - anchor.begin) != start)
        anchor = {start, speed, begin, true};
    return {anchor.x + anchor.speed * float(h - (anchor.begin - begin)), speed, anchor};
}

struct State {
    std::array<double, 2> mass{};
    std::array<double, 2> head{};
    std::array<double, 2> speed{};
};

struct Fixture {
    bool waterBody;
    CutRegionChart chart;

    explicit Fixture(bool wet) : waterBody(wet) {
        std::string error;
        const double y = Y();
        const BoxMotion solid{1, {.875, y - .125, .25}, {1.125, y + .125, .75}, {}};
        const bool okay = PrepareCutRegionChart({{2, 1, 1}, 1.}, {}, solid,
                                                {-.0625, 0., 0.}, {.0625, 0., 0.}, chart, error);
        Require(okay, error);
        Require(chart.regions.size() == 2 && chart.faces.size() == 1 &&
                chart.regions[0].parent == 0 && chart.regions[1].parent == 1,
                "not the intended two-cell geometry");
    }

    float Y() const { return waterBody ? .25f : .75f; }

    CutRegionGeometry Geometry(double x, double dx = 0.) const {
        CutRegionGeometry geometry;
        std::string error;
        const bool okay = BuildCutRegionGeometry(chart, {x, 0., 0.}, {dx, 0., 0.}, geometry, error);
        Require(okay, error);
        return geometry;
    }

    Capacity Volumes(const CutRegionGeometry& geometry, const State& state) const {
        Capacity volumes{};
        for (std::size_t i = 0; i < volumes.size(); ++i) {
            const auto& region = chart.regions[i];
            volumes[i] = MeasureCutRegionPhaseVolumes(region, geometry.motion,
                region.lo, region.hi, {{1, false}, .5, state.head[i]});
        }
        return volumes;
    }
};

struct Staged {
    Forecast forecast{};
    CutHydroacousticResult result;
    std::vector<CutHydroacousticRegion> regions;
    std::vector<CutHydroacousticPort> ports;
    glm::dvec3 force{0.}, torque{0.};
    double sourceError = 0., forceError = 0., workError = 0., referenceError = 0.;
};

Staged Stage(const Fixture& fixture, const State& state, float start, Forecast end, double h) {
    Staged stage;
    stage.forecast = end;
    const double dx = double(end.x) - start;
    const auto geometry = fixture.Geometry(start, dx);
    const auto before = fixture.Volumes(geometry, state);
    const auto fixed = fixture.Volumes(fixture.Geometry(end.x), state);
    const auto& face = geometry.faces.front();
    Require(face.axis == 0 && face.left == 0 && face.right == 1, "unexpected chamber face");
    for (std::size_t i = 0; i < before.size(); ++i) {
        stage.regions.push_back({before[i][0], before[i][1], state.mass[i],
                                 fixed[i][0], fixed[i][1], storageArea, state.head[i]});
        for (std::size_t phase = 0; phase < 2; ++phase) {
            const double expected = fixture.waterBody == (phase == 0) ?
                (i == 0 ? -endArea : endArea) * dx : 0.;
            stage.sourceError = std::max(stage.sourceError,
                std::abs((before[i][phase] - fixed[i][phase]) - expected));
        }
    }
    const CutRegionWaterPlane left{{1, false}, .5, state.head[0]};
    const CutRegionWaterPlane right{{1, false}, .5, state.head[1]};
    const double aw = MeasureCutRegionSharedPhase(face, geometry.motion, left, right, true, true).mean;
    const double ag = MeasureCutRegionSharedPhase(face, geometry.motion, left, right, false, false).mean;
    stage.ports = {{0, 1, CutFluidPhase::Water, aw, face.length, state.speed[0]},
                   {0, 1, CutFluidPhase::Gas, ag, face.length, state.speed[1]}};
    std::string error;
    const bool okay = SolveCutHydroacousticPressure(stage.regions, stage.ports, {h}, stage.result, error);
    Require(okay, error);

    Matrix matrix{};
    Heads rhs{};
    const double gw = h * h * aw * g / (2. * face.length);
    const double gg = h * h * ag * scale / (2. * rhoG * face.length);
    const double q0w = h * aw * state.speed[0], q0g = h * ag * state.speed[1];
    for (std::size_t i = 0; i < 2; ++i) {
        const std::size_t w = 2*i, a = w + 1;
        const double capacitance = scale * before[i][1] / bulk;
        const double excess = state.mass[i] / rhoG - before[i][1];
        const double sign = i == 0 ? 1. : -1.;
        matrix[w][w] = 2. * storageArea + gw;
        matrix[w][2-w] = -gw;
        matrix[a][a] = 2. * (storageArea + capacitance) + gg;
        matrix[a][4-a] = -gg;
        matrix[w][a] = matrix[a][w] = -2. * storageArea;
        rhs[w] = before[i][0] - fixed[i][0] + 2. * storageArea * state.head[i] - sign * q0w;
        rhs[a] = before[i][1] - fixed[i][1] + 2. * excess -
                 2. * storageArea * state.head[i] - sign * q0g;
    }
    const auto p = Solve(matrix, rhs);
    for (std::size_t i = 0; i < 2; ++i) {
        stage.referenceError = std::max(stage.referenceError,
            std::max(std::abs(scale * p[2*i] - stage.result.waterPressure[i]),
                     std::abs(scale * p[2*i+1] - stage.result.gasPressure[i])));
    }
    const auto& traction = fixture.waterBody ? stage.result.waterPressure : stage.result.gasPressure;
    const glm::dvec3 center(1. + .5 * (double(start) + end.x), fixture.Y(), .5);
    for (const auto& patch : geometry.patches) {
        Require(patch.owner == 1 && patch.cell < 2, "unowned pressure patch");
        Require(fixture.waterBody ? patch.centroid[1] < .5 + state.head[patch.cell] :
                                   patch.centroid[1] > .5 + state.head[patch.cell],
                "body left intended phase");
        glm::dvec3 force(0.);
        force[patch.axis] = -patch.sign * patch.area * traction[patch.cell];
        const glm::dvec3 point(patch.centroid[0], patch.centroid[1], patch.centroid[2]);
        stage.force += force;
        stage.torque += glm::cross(point - center, force);
    }
    stage.forceError = AbsMax(stage.force - glm::dvec3(endArea * (traction[0] - traction[1]), 0., 0.));
    stage.workError = stage.result.wallWork + stage.force.x * dx;
    return stage;
}

double IndependentFluidEnergyChange(const Staged& stage, const State& old) {
    double change = 0.;
    for (std::size_t i = 0; i < 2; ++i) {
        const auto& r = stage.regions[i];
        const double capacitance = scale * r.gasVolume / bulk;
        const double oldCompression = old.mass[i] / rhoG - r.gasVolume;
        const double newCompression = stage.result.gasMass[i] / rhoG - stage.result.gasVolume[i];
        const double endHead = stage.result.surfaceHead[i];
        change += .5 * scale * (storageArea * (endHead - old.head[i]) * (endHead + old.head[i]) +
            (newCompression - oldCompression) * (newCompression + oldCompression) / capacitance);
        const auto& port = stage.ports[i];
        const double newSpeed = stage.result.portSpeed[i];
        change += .5 * (i == 0 ? rhoW : rhoG) * port.area * port.length *
            (newSpeed - port.speed) * (newSpeed + port.speed);
    }
    return change;
}

// Independent two-dimensional antisymmetric pressure result for the initial
// rest-fluid state. This uses the *actual represented* moving-box distance.
double InitialAntisymmetricError(const Staged& stage, bool wet, double dx, double h) {
    const double wetDiagonal = 2. * storageArea +
        h * h * stage.ports[0].area * g / stage.ports[0].length;
    const double gasDiagonal = 2. * (storageArea + scale * stage.regions[0].gasVolume / bulk) +
        h * h * stage.ports[1].area * scale / (rhoG * stage.ports[1].length);
    const double coupling = 2. * storageArea;
    const double det = wetDiagonal * gasDiagonal - coupling * coupling;
    const double source = -endArea * dx;
    const double pw = scale * source * (wet ? gasDiagonal : coupling) / det;
    const double pg = scale * source * (wet ? coupling : wetDiagonal) / det;
    return std::max({std::abs(pw - stage.result.waterPressure[0]), std::abs(-pw - stage.result.waterPressure[1]),
                     std::abs(pg - stage.result.gasPressure[0]), std::abs(-pg - stage.result.gasPressure[1])});
}

void Run(bool wet, bool omitImpulse, unsigned outerTicks) {
    const Fixture fixture(wet);
    PhysicsWorld world;
    Require(world.Init(), "cannot initialize native MK2");
    Shape shape;
    shape.type = ShapeType::Box;
    shape.halfExtents = half;
    const auto body = world.CreateShape(shape, {{0.f, fixture.Y(), .5f}, glm::quat(1, 0, 0, 0)},
                                        true, 10.f, 0.f, 0.f);
    Require(body.IsValid(), "cannot create native MK2 box");
    world.SetLinearVelocity(body, glm::vec3(.05f, 0.f, 0.f));
    const auto initialRotation = world.GetTransform(body).rotation;
    State state;
    const auto volumes = fixture.Volumes(fixture.Geometry(0.), state);
    for (std::size_t i = 0; i < 2; ++i)
        state.mass[i] = rhoG * volumes[i][1];
    const double initialWater = volumes[0][0] + volumes[1][0];
    const double initialGasMass = state.mass[0] + state.mass[1];
    Anchor anchor;
    Staged pending;
    unsigned accepted = 0, published = 0, trials = 0, maxTrials = 0;
    float v0 = 0., x0 = 0., invMass = 0.;
    double h = 0.;
    PhysicsConstraintParticipant participant;
    participant.bodies = {body};
    participant.maximumBodies = participant.maximumContacts = participant.maximumJointRows = 1;
    participant.propose = [&](const PhysicsConstraintBatch& batch, PhysicsConstraintProposal& proposal) {
        Require(batch.bodies.size() == 1 && batch.contacts.empty() && batch.joints.empty(),
                "unexpected native contact or joint");
        const auto& native = batch.bodies.front();
        Require(native.angularVelocity == glm::vec3(0) && native.orientation == initialRotation,
                "unexpected starting angular movement");
        Require(native.center.y == fixture.Y() && native.center.z == .5f &&
                native.linearVelocity.y == 0.f && native.linearVelocity.z == 0.f,
                "unexpected starting transverse movement");
        const double begin = double(batch.context.stepDeltaTime) * batch.context.index / batch.context.count;
        h = batch.context.deltaTime;
        x0 = native.center.x;
        v0 = native.linearVelocity.x;
        invMass = native.inverseMass;
        float speed = v0;
        for (trials = 1; trials <= 16; ++trials) {
            pending = Stage(fixture, state, x0, Predict(anchor, x0, speed, begin, h), h);
            const float response = float(double(v0) + double(invMass) * h * pending.force.x);
            if (response == speed)
                break;
            speed = response;
        }
        Require(trials <= 16, "native represented path and midpoint pressure did not close");
        maxTrials = std::max(maxTrials, trials);
        Require(pending.sourceError < 2e-16 && pending.forceError < 1e-12 &&
                AbsMax(pending.torque) < 1e-12 && std::abs(pending.workError) < 1e-13 &&
                pending.referenceError < 1e-10, "geometric adjoint or independent pressure check failed");
        if (accepted == 0) {
            const auto& pressures = wet ? pending.result.waterPressure : pending.result.gasPressure;
            const double error = InitialAntisymmetricError(pending, wet, double(pending.forecast.x) - x0, h);
            Require(error < 1e-10 && pending.force.x < 0. && pending.forecast.speed < v0 &&
                    std::abs(pending.result.waterPressure[0]) > 1e-4 &&
                    std::abs(pending.result.gasPressure[0]) > 1e-4 &&
                    std::abs(pending.ports[0].area - (wet ? .375 : .5)) < 1e-14 &&
                    std::abs(pending.ports[1].area - (wet ? .5 : .375)) < 1e-14,
                    "initial independent pressure, aperture or movement sign failed");
            std::cout << "initial wet_port=" << pending.ports[0].area
                      << " gas_port=" << pending.ports[1].area
                      << " pressurized_left=" << pressures[0] << " pressurized_right=" << pressures[1]
                      << " antisymmetric_oracle_error_pa=" << error << '\n';
        }
        proposal.linearImpulses = {omitImpulse ? glm::dvec3(0.) : glm::dvec3(h * pending.force.x, 0., 0.)};
        proposal.angularImpulses = {glm::dvec3(0.)};
        return true;
    };
    participant.published = [&](const auto&) noexcept { ++published; };
    PhysicsWorld::VelocityCoupling coupling;
    coupling.physicalBatch = &participant;
    coupling.afterSubstep = [&](const auto&) {
        Require(published == accepted + 1, "impulse did not publish before endpoint");
        const auto pose = world.GetTransform(body);
        const auto v = world.GetLinearVelocity(body);
        Require(pose.position == glm::vec3(pending.forecast.x, fixture.Y(), .5f) &&
                v == glm::vec3(pending.forecast.speed, 0.f, 0.f) &&
                pose.rotation == initialRotation && world.GetAngularVelocity(body) == glm::vec3(0.f),
                "native velocity or pose changed after phase impulse proposal");
        const double dx = double(pose.position.x) - x0;
        const double dv = double(v.x) - v0;
        const double impulse = h * pending.force.x;
        const double measured = dv / invMass;
        const double fluidEnergy = IndependentFluidEnergyChange(pending, state);
        const double rigidEnergy = .5 * dv * (double(v.x) + v0) / invMass;
        const double schemeDissipation = .5 * dv * dv / invMass;
        const double rounding = (measured - impulse) * v.x + pending.force.x * (h * v.x - dx);
        const double closure = fluidEnergy + rigidEnergy + schemeDissipation - rounding;
        const double totalWater = pending.result.waterVolume[0] + pending.result.waterVolume[1];
        const double totalGas = pending.result.gasMass[0] + pending.result.gasMass[1];
        Require(std::abs(measured - impulse) <= HalfUlp(v.x) / invMass + 1e-14 &&
                std::abs(fluidEnergy - pending.result.energyChange) < 1e-12 &&
                std::abs(closure) < 1e-12 && std::abs(totalWater - initialWater) < 1e-14 &&
                std::abs(totalGas - initialGasMass) < 1e-14,
                "native impulse, fluid energy or independent inventories failed closure");
        std::cout << "accepted=" << accepted + 1 << " x=" << pose.position.x << " dx=" << dx
                  << " vx=" << v.x << " trials=" << trials << " force=" << pending.force.x
                  << " torque_max=" << AbsMax(pending.torque)
                  << " proposed_impulse=" << impulse << " measured_impulse=" << measured
                  << " water_error=" << totalWater - initialWater << " gas_error=" << totalGas - initialGasMass
                  << " source_error=" << pending.sourceError << " adjoint_error_J=" << pending.workError
                  << " pressure_error_pa=" << pending.referenceError << " fluid_energy_J=" << fluidEnergy
                  << " body_energy_J=" << rigidEnergy << " post_impulse_scheme_J=" << schemeDissipation
                  << " represented_rounding_J=" << rounding << " joint_work_closure_J=" << closure << '\n';
        for (std::size_t i = 0; i < 2; ++i) {
            state.head[i] = pending.result.surfaceHead[i];
            state.mass[i] = pending.result.gasMass[i];
            state.speed[i] = pending.result.portSpeed[i];
        }
        anchor = pending.forecast.anchor;
        ++accepted;
    };
    std::cout << "case=" << (wet ? "water" : "gas") << " omit_impulse=" << omitImpulse << '\n';
    std::string failure;
    try {
        for (unsigned i = 0; i < outerTicks; ++i) {
            anchor = {};
            world.Step(tick, &coupling);
        }
    } catch (const std::exception& e) {
        failure = e.what();
    }
    std::cout << "result accepted=" << accepted << " published=" << published
              << " max_trials=" << maxTrials << " reason=" << failure << '\n';
    if (omitImpulse)
        Require(accepted == 0 && published == 1 &&
                failure == "native velocity or pose changed after phase impulse proposal",
                "missing-pressure-impulse negative did not fail at native observation");
    else
        Require(accepted == outerTicks * 4 && failure.empty(), failure.empty() ? "missing native substeps" : failure);
}

} // namespace

int main(int argc, char** argv) {
    try {
        std::cout << std::setprecision(17);
        const unsigned ticks = argc > 1 ? std::stoul(argv[1]) : 1;
        Run(true, false, ticks);
        Run(false, false, ticks);
        Run(true, true, 1);
        Run(false, true, 1);
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAIL " << e.what() << '\n';
        return 1;
    }
}
