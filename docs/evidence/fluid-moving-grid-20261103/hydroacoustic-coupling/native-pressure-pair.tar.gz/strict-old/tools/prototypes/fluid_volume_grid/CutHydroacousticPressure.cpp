#include "CutHydroacousticPressure.h"
#include "CutRegionPressure.h"

#include <algorithm>
#include <cmath>
#include <utility>

namespace judas::volume_grid {
namespace {

bool Fail(std::string& error, const char* message) {
    error = message;
    return false;
}

bool Positive(double v) { return v > 0. && std::isfinite(v); }
bool Nonnegative(double v) { return v >= 0. && std::isfinite(v); }

struct Sum {
    double value = 0., correction = 0.;

    void Add(double term) {
        const double next = value + term;
        correction += std::abs(value) >= std::abs(term) ? (value - next) + term : (term - next) + value;
        value = next;
    }

    double Value() const { return value + correction; }
};

struct RegionLinks {
    std::size_t surface = CutHydroacousticAmbient;
    std::size_t compression = CutHydroacousticAmbient;
    double gasHead = 0., gasCapacitance = 0.;
};

} // namespace

bool SolveCutHydroacousticPressure(const std::vector<CutHydroacousticRegion>& regions,
                                  const std::vector<CutHydroacousticPort>& ports,
                                  const CutHydroacousticSettings& settings,
                                  CutHydroacousticResult& output, std::string& error) {
    const auto count = regions.size();
    const double scale = settings.waterDensity * settings.gravity;
    const double bulk = settings.gasDensity * settings.soundSpeed * settings.soundSpeed;
    if (count == 0 || count > (CutHydroacousticAmbient - 1) / 2 ||
        !Positive(settings.dt) || !Positive(settings.volumeTolerance) ||
        !Positive(settings.waterDensity) || !Positive(settings.gasDensity) ||
        !Positive(settings.gravity) || !Positive(settings.soundSpeed) ||
        !Positive(scale) || !Positive(bulk))
        return Fail(error, "invalid hydroacoustic dimensions or material parameters");

    const auto ground = 2 * count;
    const auto wetNode = [](std::size_t region) { return 2 * region; };
    const auto gasNode = [&](std::size_t region) {
        return region == CutHydroacousticAmbient ? ground : 2 * region + 1;
    };
    std::vector<double> sources(ground + 1);
    std::vector<CutRegionPressureFace> edges;
    edges.reserve(ports.size() + 2 * count);
    std::vector<RegionLinks> links(count);
    Sum groundSource;
    double cellVolume = 0.;
    for (std::size_t i = 0; i < count; ++i) {
        const auto& r = regions[i];
        if (!Nonnegative(r.waterVolume) || !Nonnegative(r.gasVolume) || !Nonnegative(r.gasMass) ||
            !Nonnegative(r.fixedWaterVolume) || !Nonnegative(r.fixedGasVolume) ||
            !Nonnegative(r.interfaceArea) || !std::isfinite(r.surfaceHead) ||
            (r.gasVolume == 0. && r.gasMass != 0.) ||
            (r.gasVolume > 0. && r.gasMass == 0.) ||
            (r.interfaceArea > 0. && !(r.waterVolume > 0. && r.gasVolume > 0.)))
            return Fail(error, "invalid hydroacoustic phase inventory or interface");
        const double waterSource = r.waterVolume - r.fixedWaterVolume;
        const double gasSource = r.gasVolume - r.fixedGasVolume;
        sources[wetNode(i)] = waterSource;
        sources[gasNode(i)] = gasSource;
        groundSource.Add(-waterSource);
        groundSource.Add(-gasSource);
        cellVolume = std::max({cellVolume, r.waterVolume + r.gasVolume,
                              r.fixedWaterVolume + r.fixedGasVolume});
        auto& owned = links[i];
        if (r.interfaceArea > 0.) {
            const double storage = 2. * r.interfaceArea;
            owned.surface = edges.size();
            edges.push_back({wetNode(i), gasNode(i), storage, -storage * r.surfaceHead});
        }
        if (r.gasVolume > 0.) {
            const double excess = std::fma(-settings.gasDensity, r.gasVolume, r.gasMass) / settings.gasDensity;
            owned.gasCapacitance = scale * r.gasVolume / bulk;
            owned.gasHead = excess / owned.gasCapacitance;
            owned.compression = edges.size();
            edges.push_back({gasNode(i), ground, 2. * owned.gasCapacitance, -2. * excess});
        }
    }
    sources[ground] = groundSource.Value();
    for (const auto& port : ports) {
        const bool isWater = port.phase == CutFluidPhase::Water;
        const bool isGas = port.phase == CutFluidPhase::Gas;
        if ((!isWater && !isGas) || port.left >= count || port.left == port.right ||
            (port.right >= count && !(isGas && port.right == CutHydroacousticAmbient)) ||
            !Positive(port.area) || !Positive(port.length) || !std::isfinite(port.speed))
            return Fail(error, "invalid hydroacoustic phase port");
        const double density = isWater ? settings.waterDensity : settings.gasDensity;
        const double conductance = settings.dt * settings.dt * port.area * scale / (2. * density * port.length);
        edges.push_back({isWater ? wetNode(port.left) : gasNode(port.left),
                         isWater ? wetNode(port.right) : gasNode(port.right),
                         conductance, settings.dt * port.area * port.speed});
    }

    CutRegionPressure pressure;
    if (!ProjectCutRegionPressure(sources, edges, cellVolume, settings.volumeTolerance, pressure, error, ground))
        return false;

    CutHydroacousticResult next;
    next.waterPressure.resize(count);
    next.gasPressure.resize(count);
    next.waterVolume.resize(count);
    next.gasVolume.resize(count);
    next.gasMass.resize(count);
    next.surfaceHead.resize(count);
    next.portVolume.resize(ports.size());
    next.portSpeed.resize(ports.size());
    next.pressureIterations = pressure.iterations;
    Sum kinetic, storage, wall, exterior, waterError, gasError;
    std::vector<Sum> waterOut(count), gasOut(count);
    const auto portOffset = edges.size() - ports.size();
    for (std::size_t i = 0; i < ports.size(); ++i) {
        const auto& port = ports[i];
        const bool isWater = port.phase == CutFluidPhase::Water;
        const double density = isWater ? settings.waterDensity : settings.gasDensity;
        const double mass = density * port.area * port.length;
        const double impulse = settings.dt * port.area * scale * pressure.pressureJump[portOffset + i];
        const double velocityChange = impulse / mass;
        const double endSpeed = port.speed + velocityChange;
        const double volume = settings.dt * port.area * (port.speed + .5 * velocityChange);
        if (!Positive(mass) || !std::isfinite(endSpeed) || !std::isfinite(volume))
            return Fail(error, "nonfinite hydroacoustic port response");
        next.portVolume[i] = volume;
        next.portSpeed[i] = endSpeed;
        auto& phaseOut = isWater ? waterOut : gasOut;
        phaseOut[port.left].Add(volume);
        if (port.right == CutHydroacousticAmbient)
            exterior.Add(settings.gasDensity * volume);
        else
            phaseOut[port.right].Add(-volume);
        kinetic.Add(mass * velocityChange * (port.speed + .5 * velocityChange));
    }

    for (std::size_t i = 0; i < count; ++i) {
        const auto& r = regions[i];
        const auto& owned = links[i];
        const double surface = owned.surface == CutHydroacousticAmbient ? 0. : pressure.volumeFlux[owned.surface];
        const double compression = owned.compression == CutHydroacousticAmbient ? 0. : pressure.volumeFlux[owned.compression];
        next.waterPressure[i] = scale * pressure.pressure[wetNode(i)];
        next.gasPressure[i] = scale * pressure.pressure[gasNode(i)];
        next.waterVolume[i] = r.fixedWaterVolume + surface;
        next.gasVolume[i] = r.fixedGasVolume - surface;
        // Face transport, rather than a re-evaluation of a linearized
        // equation of state at a different volume, owns the gas inventory.
        next.gasMass[i] = std::fma(-settings.gasDensity, gasOut[i].Value(), r.gasMass);
        next.surfaceHead[i] = r.interfaceArea > 0. ? r.surfaceHead + surface / r.interfaceArea : r.surfaceHead;
        if (!Nonnegative(next.waterVolume[i]) || !Nonnegative(next.gasVolume[i]) ||
            !Nonnegative(next.gasMass[i]) || !std::isfinite(next.surfaceHead[i]) ||
            (next.gasVolume[i] == 0. && next.gasMass[i] != 0.))
            return Fail(error, "hydroacoustic response exceeds available phase volume or gas mass");

        const double volumeError = (surface - sources[wetNode(i)]) + waterOut[i].Value();
        const double massError = (compression - surface - sources[gasNode(i)]) + gasOut[i].Value();
        next.maximumVolumeError = std::max({next.maximumVolumeError, std::abs(volumeError), std::abs(massError)});
        waterError.Add(next.waterVolume[i] - r.waterVolume);
        gasError.Add(next.gasMass[i] - r.gasMass);
        if (r.interfaceArea > 0.)
            storage.Add(scale * surface * (r.surfaceHead + .5 * surface / r.interfaceArea));
        if (owned.gasCapacitance > 0.)
            storage.Add(scale * compression * (owned.gasHead + .5 * compression / owned.gasCapacitance));
        wall.Add(next.waterPressure[i] * sources[wetNode(i)]);
        wall.Add(next.gasPressure[i] * sources[gasNode(i)]);
    }
    next.exteriorGasMass = exterior.Value();
    gasError.Add(next.exteriorGasMass);
    next.waterError = waterError.Value();
    next.gasMassError = gasError.Value();
    next.energyChange = kinetic.Value() + storage.Value();
    next.wallWork = wall.Value();
    next.workError = next.energyChange - next.wallWork;
    const double volumeBudget = settings.volumeTolerance + 128. * std::numeric_limits<double>::epsilon() * cellVolume;
    const double workBudget = 1e-10 * (1. + std::abs(next.energyChange) + std::abs(next.wallWork));
    if (!(next.maximumVolumeError <= volumeBudget &&
          std::abs(next.waterError) <= volumeBudget * double(count) &&
          std::abs(next.gasMassError) <= volumeBudget * double(count) * settings.gasDensity &&
          std::abs(next.workError) <= workBudget))
        return Fail(error, "hydroacoustic phase, mass or pressure work ledger did not close");
    output = std::move(next);
    error.clear();
    return true;
}

} // namespace judas::volume_grid
