# Negative control for fixed-geometry endpoint bounds

For each local water/air interface, let q = h_w - h_a in metres of water
head and D = 2A be the midpoint storage coefficient in square metres.
The authored equilibrium has zero old relative surface head in this
fixture. The unconstrained endpoint volume change is D q. In this
experiment the local change is instead s(q) = clamp(D q, -V_w, +V_a),
where V_w and V_a are the fixed-endpoint geometry volumes. A saturated
branch has zero tangent conductance, and its signed storage change moves
to the two balance sources. A free branch keeps the original positive
interface conductance. All other ports and gas capacitance are unchanged.

CoupledBounded.cpp applies undamped active-state switching. It cycles on
all four rotated pulses. CoupledBoundedGlobal.cpp chooses the update step
by exact convex line minimization. The quadratic fixed graph contributes
the linear slope and curvature. Each interface contributes
(q_direction) s(q_current + step q_direction) to the line derivative.
The solver accepts only when an independent nonlinear original-row audit
closes within 1e-19 m³. No physical threshold changed.

The independently reconstructed storage energy is
rho_w g s²/(2A), and complementary endpoint work is
rho_w g s (q - s/(2A)). The latter is an explicit work term for this
fixed-graph variational inequality. It cannot be erased from the energy
ledger or treated as a justified law for moving across interfaces.
The globalization separates endpoint-model insufficiency from nonlinear
iteration failure. CoupledBoundedAudit.cpp adds strict donor ownership
and gas endpoint volume/mass tests; the expected nonzero exit is preserved.

All variants use exact authored rotated static geometry, with the same
interior-face-only scope and the same paired pulses and time steps as
the graph comparator. No body simulation, topology event traversal, new
wet aperture or pressure publication occurs in this diagnostic.

Compile in the extracted src directory:

```bash
common=(CutRegionGeometry.cpp CutRegionGasTopology.cpp VentTopology.cpp CutRegionPressure.cpp MovingVolumeGrid.cpp GridConservativeRemap.cpp GridGeometricMomentum.cpp GridPhaseFluxRepair.cpp GridHalfCellGeometry.cpp MovingVolumeMomentum.cpp HalfDualVolumeMomentum.cpp CutHydroacousticGraph.cpp)
for variant in CoupledBounded CoupledBoundedGlobal CoupledBoundedAudit; do
  g++ -std=c++20 -O3 -DNDEBUG "$variant.cpp" CutHydroacousticPressure.tracked.cpp "${common[@]}" -o "../$variant"
  "../$variant" --tracked
done
```

The first and third runs are deliberate negatives. The middle run
passes the phase-bound model's algebraic controls, which is insufficient
to pass the physical tests. No sources here are production changes.
