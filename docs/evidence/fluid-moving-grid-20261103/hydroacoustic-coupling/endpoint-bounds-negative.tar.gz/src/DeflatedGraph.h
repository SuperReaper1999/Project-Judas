#pragma once

#include "GraphMultigrid.h"

class DeflatedGraph {
    std::vector<std::size_t> group_;
    std::vector<double> factor_, diag_, work_;
    std::size_t groups_=0;

public:
    bool Build(const std::vector<double>& storage, const std::vector<double>& diagonal,
               const std::vector<GraphEdge>& edges) {
        const auto n=storage.size();
        group_.resize(n);
        std::iota(group_.begin(),group_.end(),0);
        std::vector<std::size_t> sizes(n,1);
        const auto root = [&](std::size_t i) {
            while (group_[i]!=i) {
                group_[i]=group_[group_[i]];
                i=group_[i];
            }
            return i;
        };
        // This is a preconditioner grouping only. All other edges remain in
        // both the fine matrix and the exact Galerkin coarse matrix.
        for (const auto& [a,b,k]:edges) {
            if (k < std::sqrt(diagonal[a]*diagonal[b])/64.)
                continue;
            const auto i=root(a), j=root(b);
            if (i==j) continue;
            if (sizes[i]<sizes[j]) {
                group_[i]=j;
                sizes[j]+=sizes[i];
            } else {
                group_[j]=i;
                sizes[i]+=sizes[j];
            }
        }
        std::vector<std::size_t> label(n,n);
        for (std::size_t i=0;i<n;++i)
            if (diagonal[i]>0.) {
                const auto g=root(i);
                if (label[g]==n)
                    label[g]=groups_++;
            }
        for (std::size_t i=0;i<n;++i)
            if (diagonal[i]>0.)
                group_[i]=label[root(i)];
        for (std::size_t i=0;i<n;++i)
            if (diagonal[i]==0.)
                group_[i]=n;
        if (groups_ == 0 || groups_ > 1000)
            return false;
        diag_.resize(groups_);
        work_.resize(groups_);
        factor_.resize(groups_*groups_);
        for (std::size_t i=0;i<n;++i)
            if (group_[i]!=n)
                diag_[group_[i]]+=storage[i];
        for (const auto& [a,b,k]:edges) {
            const auto i=group_[a],j=group_[b];
            if (i==j) continue;
            diag_[i]+=k;
            diag_[j]+=k;
            factor_[std::max(i,j)*groups_+std::min(i,j)]-=k;
        }
        for (std::size_t i=0;i<groups_;++i) {
            if (!(diag_[i]>0. && std::isfinite(diag_[i])))
                return false;
            diag_[i]=std::sqrt(diag_[i]);
            factor_[i*groups_+i]=1.;
            for (std::size_t j=0;j<i;++j)
                factor_[i*groups_+j]/=(diag_[i]*diag_[j]);
        }
        for (std::size_t i=0;i<groups_;++i)
            for (std::size_t j=0;j<=i;++j) {
                double x=factor_[i*groups_+j];
                for (std::size_t k=0;k<j;++k)
                    x-=factor_[i*groups_+k]*factor_[j*groups_+k];
                if (i==j) {
                    if (!(x>0. && std::isfinite(x)))
                        return false;
                    factor_[i*groups_+i]=std::sqrt(x);
                } else {
                    factor_[i*groups_+j]=x/factor_[j*groups_+j];
                }
            }
        return true;
    }

    void Add(const std::vector<double>& r,std::vector<double>& z) {
        const auto n=r.size();
        std::fill(work_.begin(),work_.end(),0.);
        for (std::size_t i=0;i<n;++i)
            if (group_[i]!=n)
                work_[group_[i]]+=r[i];
        for (std::size_t i=0;i<groups_;++i) {
            double x=work_[i]/diag_[i];
            for (std::size_t j=0;j<i;++j)
                x-=factor_[i*groups_+j]*work_[j];
            work_[i]=x/factor_[i*groups_+i];
        }
        for (std::size_t i=groups_;i-- > 0;) {
            work_[i]/=factor_[i*groups_+i];
            for (std::size_t j=0;j<i;++j)
                work_[j]-=factor_[i*groups_+j]*work_[i];
        }
        for (std::size_t i=0;i<groups_;++i)
            work_[i]/=diag_[i];
        for (std::size_t i=0;i<n;++i)
            if (group_[i]!=n)
                z[i]+=work_[group_[i]];
    }

    std::size_t Groups() const { return groups_; }
};
