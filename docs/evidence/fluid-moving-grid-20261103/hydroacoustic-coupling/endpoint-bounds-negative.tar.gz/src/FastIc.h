#pragma once

#include <cstdint>
#include <limits>
#include <stdexcept>

class FastIc {
    using Index = std::uint32_t;
    static constexpr auto absent = std::numeric_limits<Index>::max();
    struct Pair { Index a,b; double k; };
    struct Lower { Index i,j; double k; };
    std::vector<Index> compact_, expanded_, offsets_, lowerIndex_;
    std::vector<double> storage_, pivots_, lowerValues_, rhs_;
    std::vector<Pair> internal_;

    void Multiply(const std::vector<double>& x, std::vector<double>& y) const {
        for (std::size_t i=0;i<x.size();++i)
            y[i]=storage_[i]*x[i];
        for (const auto& [a,b,k]:internal_) {
            const double flux=k*(x[a]-x[b]);
            y[a]+=flux;
            y[b]-=flux;
        }
    }

    void Precondition(const std::vector<double>& r,std::vector<double>& z) const {
        for (std::size_t i=0;i<r.size();++i) {
            double x=r[i];
            for (std::size_t j=offsets_[i];j<offsets_[i+1];++j)
                x-=lowerValues_[j]*z[lowerIndex_[j]];
            z[i]=x*pivots_[i];
        }
        for (std::size_t i=r.size();i-- > 0;) {
            z[i]*=pivots_[i];
            for (std::size_t j=offsets_[i];j<offsets_[i+1];++j)
                z[lowerIndex_[j]]-=lowerValues_[j]*z[i];
        }
    }

    static double DotProduct(const std::vector<double>& a,const std::vector<double>& b) {
        // Grouped binary64 sums reduce per-element recurrence. The solution
        // still passes the independently recomputed physical residuals.
        std::array<double,4> sums{};
        std::size_t i=0;
        for (;i+4<=a.size();i+=4)
            for (std::size_t lane=0;lane<4;++lane)
                sums[lane]+=a[i+lane]*b[i+lane];
        for (;i<a.size();++i)
            sums[0]+=a[i]*b[i];
        return (sums[0]+sums[1])+(sums[2]+sums[3]);
    }

public:
    template<class System>
    bool Build(const System& s) {
        const auto n=s.c.size();
        if (n>=absent || s.links.size()>=absent)
            return false;
        compact_.assign(n,absent);
        std::vector<double> diagonal;
        for (std::size_t i=0;i<n;++i) {
            if (!(s.diagonal[i]>0.)) continue;
            compact_[i]=static_cast<Index>(expanded_.size());
            expanded_.push_back(static_cast<Index>(i));
            storage_.push_back(2.*s.c[i]);
            diagonal.push_back(s.diagonal[i]);
            rhs_.push_back(s.rhs[i]);
        }
        std::vector<Lower> lower;
        lower.reserve(s.links.size());
        internal_.reserve(s.links.size());
        for (const auto& l:s.links) {
            const auto a=compact_[l.geometry.left];
            if (a==absent)
                return false;
            if (l.geometry.right==n) {
                storage_[a]+=l.conductance;
            } else {
                const auto b=compact_[l.geometry.right];
                if (b==absent)
                    return false;
                lower.push_back({std::max(a,b),std::min(a,b),-l.conductance});
                internal_.push_back({a,b,l.conductance});
            }
        }
        std::sort(lower.begin(),lower.end(),[](const auto& a,const auto& b){
            return std::tie(a.i,a.j)<std::tie(b.i,b.j);
        });
        offsets_.resize(expanded_.size()+1);
        for (std::size_t i=0;i<lower.size();++i) {
            if (i>0 && lower[i-1].i==lower[i].i && lower[i-1].j==lower[i].j) {
                lowerValues_.back()+=lower[i].k;
            } else {
                ++offsets_[lower[i].i+1];
                lowerValues_.push_back(lower[i].k);
                lowerIndex_.push_back(lower[i].j);
            }
        }
        std::partial_sum(offsets_.begin(),offsets_.end(),offsets_.begin());
        pivots_.resize(diagonal.size());
        for (std::size_t i=0;i<diagonal.size();++i) {
            double pivot=diagonal[i];
            for (std::size_t entry=offsets_[i];entry<offsets_[i+1];++entry) {
                const auto j=lowerIndex_[entry];
                double value=lowerValues_[entry];
                auto x=offsets_[i], y=offsets_[j];
                while (x<entry && y<offsets_[j+1]) {
                    if (lowerIndex_[x]<lowerIndex_[y]) ++x;
                    else if (lowerIndex_[x]>lowerIndex_[y]) ++y;
                    else {
                        value-=lowerValues_[x]*lowerValues_[y];
                        ++x;
                        ++y;
                    }
                }
                value*=pivots_[j];
                lowerValues_[entry]=value;
                pivot-=value*value;
            }
            if (!(pivot>0. && std::isfinite(pivot)))
                return false;
            pivots_[i]=1./std::sqrt(pivot);
        }
        return true;
    }

    bool Solve(const std::vector<double>& expandedBase,std::vector<double>& expandedSolution,
               int limit,int& iterations,double& relative,std::string& error) const {
        const auto n=expanded_.size();
        std::vector<double> base(n),x(n),rhs(n),r(n),z(n),d(n),a(n);
        for (std::size_t i=0;i<n;++i)
            base[i]=expandedBase[expanded_[i]];
        Multiply(base,a);
        for (std::size_t i=0;i<n;++i)
            rhs[i]=r[i]=rhs_[i]-a[i];
        Precondition(r,z);
        d=z;
        double product=DotProduct(r,z);
        const double initial=product;
        if (!(initial>=0. && std::isfinite(initial))) {
            error="invalid compact IC initial residual";
            return false;
        }
        const double target=initial*1e-22;
        for (iterations=0;iterations<limit && product>target;++iterations) {
            Multiply(d,a);
            const double curvature=DotProduct(d,a);
            if (!(curvature>0. && std::isfinite(curvature))) {
                error="compact IC lost positive CG curvature";
                return false;
            }
            const double step=product/curvature;
            for (std::size_t i=0;i<n;++i) {
                x[i]+=step*d[i];
                r[i]-=step*a[i];
            }
            const bool refresh=(iterations+1)%256==0;
            if (refresh) {
                Multiply(x,a);
                for (std::size_t i=0;i<n;++i) r[i]=rhs[i]-a[i];
            }
            Precondition(r,z);
            const double next=DotProduct(r,z);
            const double ratio=refresh?0.:next/product;
            for (std::size_t i=0;i<n;++i)
                d[i]=z[i]+ratio*d[i];
            product=next;
        }
        Multiply(x,a);
        for (std::size_t i=0;i<n;++i)
            r[i]=rhs[i]-a[i];
        Precondition(r,z);
        relative=initial>0.?std::sqrt(DotProduct(r,z)/initial):0.;
        if (!(relative<=1e-9)) {
            error="compact IC failed fresh residual";
            return false;
        }
        expandedSolution.assign(expandedBase.size(),0.);
        for (std::size_t i=0;i<n;++i)
            expandedSolution[expanded_[i]]=x[i];
        return true;
    }

    std::size_t Rows() const { return expanded_.size(); }
};
