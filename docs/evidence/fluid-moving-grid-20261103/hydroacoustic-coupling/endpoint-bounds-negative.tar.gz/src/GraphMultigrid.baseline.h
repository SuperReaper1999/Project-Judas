#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <numeric>
#include <tuple>
#include <vector>

struct GraphEdge {
    std::size_t a, b;
    double k;
};

class GraphMultigrid {
    struct Neighbor {
        std::size_t to;
        double k;
    };

    struct Level {
        std::vector<double> storage, diagonal;
        std::vector<GraphEdge> edges;
        std::vector<std::size_t> offsets, parent;
        std::vector<Neighbor> neighbors;
        std::vector<double> solution, rhs, residual, factor;
        std::size_t Count() const { return storage.size(); }

        void BuildAdjacency() {
            const auto count = Count();
            offsets.resize(count+1);
            diagonal = storage;
            for (const auto& [a,b,k] : edges) {
                ++offsets[a+1];
                ++offsets[b+1];
                diagonal[a] += k;
                diagonal[b] += k;
            }
            std::partial_sum(offsets.begin(), offsets.end(), offsets.begin());
            neighbors.resize(offsets.back());
            auto place = offsets;
            for (const auto& [a,b,k] : edges) {
                neighbors[place[a]++] = {b,k};
                neighbors[place[b]++] = {a,k};
            }
            solution.resize(count);
            rhs.resize(count);
            residual.resize(count);
        }

        void Multiply(const std::vector<double>& x, std::vector<double>& y) const {
            for (std::size_t i = 0; i < Count(); ++i)
                y[i] = storage[i]*x[i];
            for (const auto& [a,b,k] : edges) {
                const double flux = k*(x[a]-x[b]);
                y[a] += flux;
                y[b] -= flux;
            }
        }

        void Sweep(bool reverse) {
            const auto n = Count();
            for (std::size_t row=0; row<n; ++row) {
                const std::size_t i = reverse ? n-1-row : row;
                double b = rhs[i];
                for (std::size_t j = offsets[i]; j < offsets[i+1]; ++j) {
                    const auto& edge = neighbors[j];
                    b += edge.k * solution[edge.to];
                }
                solution[i] = b/diagonal[i];
            }
        }

        void JacobiSweep() {
            Multiply(solution,residual);
            for (std::size_t i=0; i<Count(); ++i)
                solution[i] += (2./3.)*(rhs[i]-residual[i])/diagonal[i];
        }

        bool Factor() {
            const auto n = Count();
            factor.resize(n*n);
            for (std::size_t i = 0; i < n; ++i)
                factor[i*n+i] = 1.;
            for (const auto& [a,b,k] : edges)
                factor[std::max(a,b)*n+std::min(a,b)] -= k/std::sqrt(diagonal[a]*diagonal[b]);
            for (std::size_t i=0; i<n; ++i)
                for (std::size_t j=0; j<=i; ++j) {
                    double p = factor[i*n+j];
                    for (std::size_t k=0; k<j; ++k)
                        p -= factor[i*n+k]*factor[j*n+k];
                    if (i == j) {
                        if (!(p > 0. && std::isfinite(p)))
                            return false;
                        factor[i*n+i] = std::sqrt(p);
                    } else {
                        factor[i*n+j] = p/factor[j*n+j];
                    }
                }
            return true;
        }

        void SolveCoarse() {
            const auto n = Count();
            if (factor.empty()) {
                for (std::size_t i=0; i<n; ++i)
                    solution[i] = rhs[i]/diagonal[i];
                return;
            }
            for (std::size_t i=0; i<n; ++i) {
                double x = rhs[i]/std::sqrt(diagonal[i]);
                for (std::size_t j=0; j<i; ++j)
                    x -= factor[i*n+j]*solution[j];
                solution[i] = x/factor[i*n+i];
            }
            for (std::size_t i=n; i-- > 0;) {
                solution[i] /= factor[i*n+i];
                for (std::size_t j=0; j<i; ++j)
                    solution[j] -= factor[i*n+j]*solution[i];
            }
            for (std::size_t i=0; i<n; ++i)
                solution[i] /= std::sqrt(diagonal[i]);
        }
    };

    std::vector<std::size_t> fineIndex_;
    std::vector<Level> levels_;
    bool jacobi_ = false;
    std::size_t edges_ = 0, nodes_ = 0;

    static bool Coarsen(Level& fine, Level& coarse) {
        const auto n = fine.Count();
        fine.parent.assign(n,n);
        std::vector<std::size_t> counts;
        const auto bestNeighbor = [&](std::size_t i, bool assigned) {
            double best = 0.;
            std::size_t choice = n;
            for (std::size_t j=fine.offsets[i]; j<fine.offsets[i+1]; ++j) {
                const auto& edge = fine.neighbors[j];
                const auto group = fine.parent[edge.to];
                if (assigned ? (group == n || counts[group] >= 4) : (group != n))
                    continue;
                const double strength = edge.k/std::sqrt(fine.diagonal[i]*fine.diagonal[edge.to]);
                if (strength > best) {
                    best = strength;
                    choice = edge.to;
                }
            }
            return choice;
        };

        for (std::size_t i=0; i<n; ++i) {
            if (fine.parent[i] != n)
                continue;
            const std::size_t neighbor = bestNeighbor(i,false);
            if (neighbor == n)
                continue;
            fine.parent[i] = fine.parent[neighbor] = counts.size();
            counts.push_back(2);
        }
        for (std::size_t i=0; i<n; ++i) {
            if (fine.parent[i] != n)
                continue;
            const std::size_t neighbor = bestNeighbor(i,true);
            if (neighbor == n) {
                fine.parent[i] = counts.size();
                counts.push_back(1);
            } else {
                fine.parent[i] = fine.parent[neighbor];
                ++counts[fine.parent[i]];
            }
        }
        if (counts.size() >= n*3/4)
            return false;
        coarse.storage.resize(counts.size());
        for (std::size_t i=0; i<n; ++i)
            coarse.storage[fine.parent[i]] += fine.storage[i];
        coarse.edges.reserve(fine.edges.size());
        for (const auto& [i,j,k] : fine.edges) {
            const auto a = fine.parent[i], b = fine.parent[j];
            if (a != b)
                coarse.edges.push_back({std::min(a,b),std::max(a,b),k});
        }
        std::sort(coarse.edges.begin(),coarse.edges.end(),[](const auto& a,const auto& b){
            return std::tie(a.a,a.b) < std::tie(b.a,b.b);
        });
        std::size_t unique = 0;
        for (const auto& edge : coarse.edges) {
            if (unique > 0 && coarse.edges[unique-1].a == edge.a && coarse.edges[unique-1].b == edge.b)
                coarse.edges[unique-1].k += edge.k;
            else
                coarse.edges[unique++] = edge;
        }
        coarse.edges.resize(unique);
        return true;
    }

    void Visit(std::size_t index) {
        auto& level = levels_[index];
        if (index+1 == levels_.size()) {
            level.SolveCoarse();
            return;
        }
        std::fill(level.solution.begin(),level.solution.end(),0.);
        if (jacobi_)
            level.JacobiSweep();
        else
            level.Sweep(false);
        level.Multiply(level.solution,level.residual);
        auto& coarse = levels_[index+1];
        std::fill(coarse.rhs.begin(),coarse.rhs.end(),0.);
        for (std::size_t i=0; i<level.Count(); ++i)
            coarse.rhs[level.parent[i]] += level.rhs[i]-level.residual[i];
        Visit(index+1);
        for (std::size_t i=0; i<level.Count(); ++i)
            level.solution[i] += coarse.solution[level.parent[i]];
        if (jacobi_)
            level.JacobiSweep();
        else
            level.Sweep(true);
    }

public:
    bool Build(const std::vector<double>& storage, const std::vector<GraphEdge>& edges, bool jacobi) {
        jacobi_ = jacobi;
        const auto n = storage.size();
        std::vector<std::size_t> active(n,n);
        Level fine;
        for (std::size_t i=0; i<n; ++i) {
            // Positive capacitance or a vent provides an owned pressure row.
            // A separate incompressible row can be incident to physical edges.
            if (storage[i] > 0.)
                active[i] = 0;
        }
        for (const auto& edge : edges)
            active[edge.a] = active[edge.b] = 0;
        for (std::size_t i=0; i<n; ++i) {
            if (active[i] == n)
                continue;
            active[i] = fineIndex_.size();
            fineIndex_.push_back(i);
            fine.storage.push_back(storage[i]);
        }
        if (fineIndex_.empty())
            return false;
        fine.edges.reserve(edges.size());
        for (const auto& [a,b,k] : edges)
            fine.edges.push_back({active[a],active[b],k});
        levels_.push_back(std::move(fine));
        for (;;) {
            auto& level = levels_.back();
            level.BuildAdjacency();
            nodes_ += level.Count();
            edges_ += level.edges.size();
            if (level.Count() <= 48)
                return level.Factor();
            Level coarse;
            if (!Coarsen(level,coarse))
                return true;
            levels_.push_back(std::move(coarse));
        }
    }

    void Apply(const std::vector<double>& r, std::vector<double>& z) {
        auto& fine = levels_.front();
        for (std::size_t i=0; i<fineIndex_.size(); ++i)
            fine.rhs[i] = r[fineIndex_[i]];
        Visit(0);
        std::fill(z.begin(),z.end(),0.);
        for (std::size_t i=0; i<fineIndex_.size(); ++i)
            z[fineIndex_[i]] = fine.solution[i];
    }

    std::size_t Levels() const { return levels_.size(); }
    std::size_t Nodes() const { return nodes_; }
    std::size_t Edges() const { return edges_; }
};
