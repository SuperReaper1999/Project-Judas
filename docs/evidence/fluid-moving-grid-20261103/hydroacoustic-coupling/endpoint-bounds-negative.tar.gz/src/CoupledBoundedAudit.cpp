#define main AcousticAuditMain
#include "Pneumatic.cpp"
#undef main
#include "CutHydroacousticPressure.h"
#include "CutHydroacousticGraph.h"

namespace {

bool useTracked = false;
constexpr double rhoW=1000.;
constexpr double grav=9.81;
constexpr double pressureScale=rhoW*grav;

enum class Form { GasPulse, CounterPulse };

struct CoupledFixture {
    std::vector<CutHydroacousticRegion> regions;
    std::vector<CutHydroacousticPort> ports;
    std::vector<GraphCoordinate> coordinates;
    std::size_t gasCell=0,mixedCell=0;
    std::size_t interfaceCount=0;
};

double InterfaceArea(const CutRegion& r, const std::optional<BoxMotion>& motion,
                     const CutRegionWaterPlane& plane) {
    const int up=plane.orientation.axis;
    const int a=(up+1)%3,b=(up+2)%3;
    if (!(plane.RelativeTo(r.lo[up])>0. && plane.RelativeTo(r.hi[up])<0.))
        return 0.;
    const double area=(r.hi[a]-r.lo[a])*(r.hi[b]-r.lo[b]);
    if (!motion || plane.RelativeTo(motion->lo[up])<0. || plane.RelativeTo(motion->hi[up])>0.)
        return area;
    const double blocked=std::max(0.,std::min(r.hi[a],motion->hi[a])-std::max(r.lo[a],motion->lo[a]))*
        std::max(0.,std::min(r.hi[b],motion->hi[b])-std::max(r.lo[b],motion->lo[b]));
    return std::max(0.,area-blocked);
}

bool BuildCoupled(bool rotated, CoupledFixture& output, std::string& error) {
    const auto fixture=Fixture::Authored(rotated);
    FixtureGraph pneumatic;
    if (!Assemble(rotated,pneumatic,error))
        return false;
    const auto count=pneumatic.volume.size();
    CutRegionChart chart;
    CutRegionGeometry geometry;
    SeedImport seed;
    std::vector<double> water;
    std::vector<CutRegionWaterPlane> planes;
    CutRegionGasTopology gas;
    if (!PrepareCutRegionChart(fixture.layout,fixture.Walls(),fixture.InitialBox(),
                              {-.005,-.015,-.005},{.005,.025,.005},chart,error) ||
        !BuildCutRegionGeometry(chart,{},geometry,error) ||
        !WaterByRegion(fixture,chart,geometry,rotated,water,seed,error) ||
        !ReconstructCutRegionWaterPlanes(chart,geometry,1,water,{},planes,error) ||
        !BuildCutRegionGasTopology(chart,geometry,planes,{FullCutRegionGasVent(chart,1,1)},gas,error))
        return false;
    output.regions.resize(count);
    output.gasCell=pneumatic.largestCell;
    output.mixedCell=count;
    double bestMixed=0.;
    for (std::size_t i=0;i<count;++i) {
        auto& r=output.regions[i];
        r.waterVolume=r.fixedWaterVolume=water[i];
        r.gasVolume=r.fixedGasVolume=gas.regionVolume[i];
        r.gasMass=density*r.gasVolume;
        if (r.waterVolume>0. && r.gasVolume>0.)
            r.interfaceArea=InterfaceArea(chart.regions[i],geometry.motion,planes[i]);
        if (r.interfaceArea>0.) {
            ++output.interfaceCount;
            const double overlap=std::min(r.waterVolume,r.gasVolume);
            if (pneumatic.pocket[i] && overlap>bestMixed) {
                bestMixed=overlap;
                output.mixedCell=i;
            }
        }
        output.coordinates.push_back(pneumatic.coordinates[i]);
        output.coordinates.push_back(pneumatic.coordinates[i]);
    }
    for (const auto& f:pneumatic.ports)
        output.ports.push_back({f.left,f.right==count?CutHydroacousticAmbient:f.right,
                               CutFluidPhase::Gas,f.area,f.length,0.});
    std::size_t wetPorts=0;
    for (const auto& f:geometry.faces) {
        const auto a=MeasureCutRegionSharedPhase(f,geometry.motion,planes[f.left],planes[f.right],true,true).start;
        if (a>0. && water[f.left]>0. && water[f.right]>0.) {
            output.ports.push_back({f.left,f.right,CutFluidPhase::Water,a,f.length,0.});
            ++wetPorts;
        }
    }
    std::cout<<"COUPLED_GEOMETRY cells="<<count<<" gas_ports="<<pneumatic.ports.size()
             <<" wet_ports="<<wetPorts<<" interior_interfaces="<<output.interfaceCount
             <<" pressure_source="<<output.gasCell<<" mixed_source="<<output.mixedCell<<'\n';
    return true;
}

bool AssembleMatrix(const std::vector<CutHydroacousticRegion>& r,
                    const std::vector<CutHydroacousticPort>& ports,double dt,
                    const std::vector<GraphCoordinate>& coordinates,System& system) {
    const auto count=r.size();
    const auto ground=2*count;
    system.c.resize(ground);
    system.rhs.resize(ground);
    system.diagonal.resize(ground);
    system.coordinates=coordinates;
    std::vector<std::size_t> root(ground);
    std::iota(root.begin(),root.end(),0);
    const auto find=[&](std::size_t i) {
        while (root[i]!=i) {
            root[i]=root[root[i]];
            i=root[i];
        }
        return i;
    };
    const auto add=[&](std::size_t a,std::size_t b,double k) {
        system.links.push_back({{a,b,0.,0.},k});
        system.diagonal[a]+=k;
        if (b<ground) {
            system.diagonal[b]+=k;
            const auto i=find(a),j=find(b);
            if (i!=j) root[j]=i;
        }
    };
    for (std::size_t i=0;i<count;++i) {
        const auto wet=2*i,air=wet+1;
        system.c[air]=pressureScale*r[i].gasVolume/(density*acousticSpeed*acousticSpeed);
        system.diagonal[air]+=2.*system.c[air];
        system.rhs[wet]=r[i].waterVolume-r[i].fixedWaterVolume;
        system.rhs[air]=r[i].gasVolume-r[i].fixedGasVolume;
        if (r[i].interfaceArea>0.) add(wet,air,2.*r[i].interfaceArea);
    }
    for (const auto& port:ports) {
        const bool isGas=port.phase==CutFluidPhase::Gas;
        const double materialDensity=isGas?density:rhoW;
        const auto a=2*port.left+isGas,b=port.right==CutHydroacousticAmbient?ground:2*port.right+isGas;
        add(a,b,dt*dt*pressureScale*port.area/(2.*materialDensity*port.length));
    }
    std::vector<bool> live(ground);
    for (std::size_t i=0;i<ground;++i)
        if (system.c[i]>0.) live[find(i)]=true;
    for (std::size_t i=0;i<ground;++i) {
        if (!live[find(i)]) {
            if (system.rhs[i]!=0.) return false;
            system.diagonal[i]=0.;
        }
    }
    const auto end=std::remove_if(system.links.begin(),system.links.end(),[&](const Link& l){
        return !live[find(l.geometry.left)];
    });
    system.links.erase(end,system.links.end());
    return true;
}

bool BoundedStorage(const System& system,
                    const std::vector<CutHydroacousticRegion>& regions,
                    std::vector<double>& pressure, std::vector<long double>& surface,
                    int& solves, int& iterations, std::string& error) {
    const auto count = regions.size();
    std::vector<double> storage(system.c.size());
    std::transform(system.c.begin(), system.c.end(), storage.begin(), [](double c) { return 2*c; });
    std::vector<CutHydroacousticGraphLink> fixed;
    for (const auto& l : system.links) {
        const auto left = l.geometry.left, right = l.geometry.right;
        if (right == storage.size())
            storage[left] += l.conductance;
        else if (left / 2 != right / 2)
            fixed.push_back({left,right,l.conductance});
    }

    std::vector<int> active(count);
    pressure.assign(2*count,0.);
    std::vector<long double> direction(2*count), area(count), unbounded(count);
    for (std::size_t i=0; i<count; ++i)
        area[i]=2.L*regions[i].interfaceArea;
    surface.resize(count);
    for (int attempt=0; attempt<20; ++attempt) {
        auto links = fixed;
        auto rhs = system.rhs;
        for (std::size_t i=0; i<count; ++i) {
            if (!(area[i]>0.))
                continue;
            if (active[i] == 0) {
                links.push_back({2*i,2*i+1,static_cast<double>(area[i])});
            } else {
                const double v = active[i]<0 ? -regions[i].fixedWaterVolume : regions[i].fixedGasVolume;
                rhs[2*i]-=v;
                rhs[2*i+1]+=v;
            }
        }
        CutHydroacousticGraphResult result;
        ++solves;
        if (!SolveCutHydroacousticGraph(storage,links,rhs,1e-19,result,error))
            return false;
        iterations+=result.iterations;
        long double slope=0., curvature=0.;
        for (std::size_t i=0; i<2*count; ++i) {
            direction[i]=static_cast<long double>(result.pressure[i])-pressure[i];
            slope+=direction[i]*(storage[i]*pressure[i]-system.rhs[i]);
            curvature+=storage[i]*direction[i]*direction[i];
        }
        for (const auto& l:fixed) {
            const auto a=l.left,b=l.right;
            const auto step=direction[a]-direction[b];
            slope+=l.conductance*(static_cast<long double>(pressure[a])-pressure[b])*step;
            curvature+=l.conductance*step*step;
        }
        const auto derivative=[&](long double alpha) {
            long double d=slope+alpha*curvature;
            for (std::size_t i=0; i<count; ++i) {
                if (!(area[i]>0.))
                    continue;
                const auto step=direction[2*i]-direction[2*i+1];
                const auto q=static_cast<long double>(pressure[2*i])-pressure[2*i+1]+alpha*step;
                const long double lo=-regions[i].fixedWaterVolume,hi=regions[i].fixedGasVolume;
                d+=step*std::clamp(area[i]*q,lo,hi);
            }
            return d;
        };
        long double alpha=1.;
        if (derivative(1.)>0.) {
            long double lo=0.,hi=1.;
            for (int j=0; j<50; ++j) {
                const auto mid=(lo+hi)/2.;
                if (derivative(mid)>0.)
                    hi=mid;
                else
                    lo=mid;
            }
            alpha=(lo+hi)/2.;
        }
        std::vector<long double> balance(2*count);
        for (std::size_t i=0; i<2*count; ++i) {
            pressure[i]=static_cast<double>(static_cast<long double>(pressure[i])+alpha*direction[i]);
            balance[i]=storage[i]*static_cast<long double>(pressure[i])-system.rhs[i];
        }
        for (const auto& l:fixed) {
            const auto flux=l.conductance*(static_cast<long double>(pressure[l.left])-pressure[l.right]);
            balance[l.left]+=flux;
            balance[l.right]-=flux;
        }
        std::array<std::size_t,3> classes{};
        for (std::size_t i=0; i<count; ++i) {
            const auto& r=regions[i];
            if (!(area[i]>0.))
                continue;
            const auto predicted = area[i]*(static_cast<long double>(pressure[2*i])-pressure[2*i+1]);
            const long double lo=-r.fixedWaterVolume, hi=r.fixedGasVolume;
            active[i]=predicted<lo ? -1 : predicted>hi ? 1 : 0;
            surface[i]=std::clamp(predicted,lo,hi);
            balance[2*i]+=surface[i];
            balance[2*i+1]-=surface[i];
            ++classes[active[i]+1];
        }
        long double maxRow=0.;
        for (const auto b:balance)
            maxRow=std::max(maxRow,std::abs(b));
        std::cout<<"ACTIVE_STAGE attempt="<<attempt+1<<" free="<<classes[1]
                 <<" dry="<<classes[0]<<" filled="<<classes[2]
                 <<" nonlinear_row="<<maxRow<<" cg_iterations="<<result.iterations
                 <<" alpha="<<alpha<<'\n';
        if (maxRow<=1e-19L)
            return true;
    }
    error="active-set work limit";
    return false;
}

bool RunCoupled(const CoupledFixture& scene,double dt,Form form) {
    auto r=scene.regions;
    const auto count=r.size();
    const auto source=form==Form::GasPulse?scene.gasCell:scene.mixedCell;
    if (source>=count) {
        std::cout<<"COUPLED_FORM missing mixed cavity interface\n";
        return true;
    }
    const double shift=std::min(1e-7,1e-4*r[source].gasVolume);
    r[source].fixedGasVolume-=shift;
    if (form==Form::CounterPulse)
        r[source].fixedWaterVolume+=shift;
    const std::string_view label=form==Form::GasPulse?"gas":"counter";
    CutHydroacousticResult core;
    std::string coreError;
    const auto coreStart=std::chrono::steady_clock::now();
    const bool coreOK=SolveCutHydroacousticPressure(r,scene.ports,{dt,grav,rhoW,density,acousticSpeed,1e-15},
                                                  core,coreError);
    const double coreMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-coreStart).count();
    System system;
    if (!AssembleMatrix(r,scene.ports,dt,scene.coordinates,system))
        return false;
    std::vector<double> p;
    int iterations=0;

    std::string error;
    const auto start=std::chrono::steady_clock::now();
    std::vector<long double> boundedSurface;
    int solves = 0;
    const bool solved = BoundedStorage(system,r,p,boundedSurface,solves,iterations,error);
    const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    if (!solved) {
        std::cout<<"COUPLED_FAIL method="<<(useTracked?"tracked-compact":Method())<<" form="<<label<<" dt="<<dt
                 <<" ms="<<ms<<" reason="<<error<<" core_ok="<<coreOK<<" core_ms="<<coreMs
                 <<" core_reason="<<coreError<<'\n';
        return false;
    }

    const auto node=[&](std::size_t i,bool isGas){
        return i==CutHydroacousticAmbient?0.L:static_cast<long double>(p[2*i+isGas]);
    };
    long double waterVolumeChange=0.,gasStorage=0.,atmosphere=0.,kinetic=0.,energy=0.,work=0.;
    long double waterSource=0.,gasSource=0.,constraintWork=0.;
    std::size_t negativeDonor=0, gasDonor=0, waterDonor=0, zeroWithMass=0;
    long double maxWaterOver=0.,maxGasOver=0.;
    double maxCorePressureDelta=0.,maxCoreFluxDelta=0.;
    long double minWater=0.,minGas=0.,minMass=0.;
    std::size_t minWaterRegion=0,minGasRegion=0,minMassRegion=0;
    std::vector<long double> gasOut(count),waterDeparture(count),gasDeparture(count);
    std::vector<long double> imbalance(2*count);
    for (std::size_t i=0;i<count;++i) {
        const long double wet=node(i,false),air=node(i,true);
        const long double surfaceVolume=boundedSurface[i];
        const long double surfaceMove=r[i].interfaceArea>0. ? surfaceVolume/r[i].interfaceArea : 0.;
        constraintWork+=pressureScale*surfaceVolume*((wet-air)-surfaceMove/2.);

        const long double compression=2.*system.c[2*i+1]*air;
        if (const auto endpoint=r[i].fixedWaterVolume+surfaceVolume;endpoint<minWater) {
            minWater=endpoint; minWaterRegion=i;
        }
        if (const auto endpoint=r[i].fixedGasVolume-surfaceVolume;endpoint<minGas) {
            minGas=endpoint; minGasRegion=i;
        }
        const long double bWet=system.rhs[2*i],bGas=system.rhs[2*i+1];
        imbalance[2*i]=surfaceVolume-bWet;
        imbalance[2*i+1]=compression-surfaceVolume-bGas;
        waterVolumeChange+=surfaceVolume;
        gasStorage+=compression;
        waterSource+=bWet;
        gasSource+=bGas;
        const long double pEnd=2.*pressureScale*air;
        energy+=.5L*pressureScale*r[i].interfaceArea*surfaceMove*surfaceMove+
                r[i].gasVolume*pEnd*pEnd/(2.*density*acousticSpeed*acousticSpeed);
        work+=pressureScale*(wet*bWet+air*bGas);
        if (coreOK) {
            maxCorePressureDelta=std::max({maxCorePressureDelta,
                std::abs(core.waterPressure[i]-pressureScale*p[2*i]),
                std::abs(core.gasPressure[i]-pressureScale*p[2*i+1])});
        }
    }
    for (std::size_t i=0;i<scene.ports.size();++i) {
        const auto& port=scene.ports[i];
        const bool air=port.phase==CutFluidPhase::Gas;
        const double materialDensity=air?density:rhoW;
        const long double endVelocity=dt*pressureScale*(node(port.left,air)-node(port.right,air))/
                                     (materialDensity*port.length);
        const long double volume=dt*port.area*endVelocity/2.;
        imbalance[2*port.left+air]+=volume;
        if (air) {
            gasOut[port.left]+=volume;
            if (port.right!=CutHydroacousticAmbient) gasOut[port.right]-=volume;
        }
        const auto donor=volume>=0. ? port.left : port.right;
        if (donor!=CutHydroacousticAmbient)
            (air ? gasDeparture : waterDeparture)[donor]+=std::abs(volume);
        if (port.right==CutHydroacousticAmbient)
            atmosphere+=volume;
        else
            imbalance[2*port.right+air]-=volume;
        kinetic+=.5L*materialDensity*port.area*port.length*endVelocity*endVelocity;
        if (coreOK)
            maxCoreFluxDelta=std::max(maxCoreFluxDelta,std::abs(static_cast<double>(volume)-core.portVolume[i]));
    }
    for (std::size_t i=0;i<count;++i)
        if (const auto endpoint=r[i].gasMass-density*gasOut[i];endpoint<minMass) {
            minMass=endpoint; minMassRegion=i;
        }
    for (std::size_t i=0;i<count;++i) {
        const long double gasEndpoint=r[i].gasMass-density*gasOut[i];
        if (r[i].fixedGasVolume==boundedSurface[i] && gasEndpoint>0.)
            ++zeroWithMass;
        const long double waterInventory=r[i].waterVolume, gasInventory=r[i].gasMass/density;
        const long double waterOver=waterDeparture[i]-waterInventory, gasOver=gasDeparture[i]-gasInventory;
        constexpr auto roundoff=128.*std::numeric_limits<double>::epsilon();
        const bool badWater=waterOver>roundoff*waterInventory,badGas=gasOver>roundoff*gasInventory;
        negativeDonor+=badWater||badGas;
        waterDonor+=badWater;
        gasDonor+=badGas;
        maxWaterOver=std::max(maxWaterOver,waterOver);
        maxGasOver=std::max(maxGasOver,gasOver);
    }
    long double maxRow=0.;
    for (const auto value:imbalance)
        maxRow=std::max(maxRow,std::abs(value));
    const long double waterError=waterVolumeChange-waterSource;
    const long double gasError=gasStorage+atmosphere-waterVolumeChange-gasSource;
    const long double energyError=kinetic+energy+constraintWork-work;
    std::cout<<"COUPLED_RESULT method="<<(useTracked?"tracked-compact":Method())<<" form="<<label<<" dt="<<dt<<" iterations="<<iterations
             <<" ms="<<ms<<" solves="<<solves<<" source_volume_m3="<<shift
             <<" constraint_work_J="<<constraintWork<<" capacity_donor_failures="<<negativeDonor
             <<" water_donor_failures="<<waterDonor<<" gas_donor_failures="<<gasDonor
             <<" max_water_overdraw_m3="<<maxWaterOver<<" max_gas_overdraw_m3="<<maxGasOver
             <<" zero_gas_positive_mass="<<zeroWithMass
             <<" water_error_m3="<<waterError<<" gas_error_m3="<<gasError
             <<" max_row_error_m3="<<maxRow<<" energy_error_J="<<energyError<<" work_J="<<work
             <<" local_gas_pressure_Pa="<<pressureScale*node(source,true)
             <<" local_wet_pressure_Pa="<<pressureScale*node(source,false)
             <<" core_ok="<<coreOK<<" core_ms="<<coreMs<<" core_iterations="<<core.pressureIterations
             <<" core_pressure_delta_Pa="<<maxCorePressureDelta<<" core_flux_delta_m3="<<maxCoreFluxDelta
             <<" min_water_m3="<<minWater<<" min_water_region="<<minWaterRegion
             <<" min_water_start_m3="<<r[minWaterRegion].waterVolume
             <<" min_gas_m3="<<minGas<<" min_gas_region="<<minGasRegion
             <<" min_gas_start_m3="<<r[minGasRegion].gasVolume
             <<" min_mass_kg="<<minMass<<" min_mass_region="<<minMassRegion
             <<" min_mass_start_kg="<<r[minMassRegion].gasMass
             <<" core_reason="<<coreError<<'\n';
    return maxRow<1e-9L*shift && std::abs(waterError)<1e-9L*shift &&
           std::abs(gasError)<1e-9L*shift && std::abs(energyError)<1e-8L*std::abs(work) &&
           negativeDonor==0 && zeroWithMass==0;
}

} // namespace

int main(int argc,char** argv) {
    std::cout<<std::setprecision(17);
    if (argc != 2) return 2;
    const std::string_view flag(argv[1]);
    if (flag=="--ic0") method=Preconditioner::Ic;
    else if (flag=="--amg") method=Preconditioner::Amg;
    else if (flag=="--geometric") method=Preconditioner::Geometric;
    else if (flag=="--tracked") useTracked=true;
    else if (flag=="--ic0-compact") method=Preconditioner::Fast;
    else if (flag=="--ic0-deflated") method=Preconditioner::IcDeflated;
    else return 2;
    bool ok=true;
    for (bool rotated:{true}) {
        CoupledFixture scene;
        std::string error;
        if (!BuildCoupled(rotated,scene,error)) {
            std::cerr<<"FAIL "<<error<<'\n';
            return 1;
        }
        for (double dt:{double(tick),double(tick)/4.})
            for (auto form:{Form::GasPulse,Form::CounterPulse})
                ok&=RunCoupled(scene,dt,form);
    }
    return ok?0:1;
}
