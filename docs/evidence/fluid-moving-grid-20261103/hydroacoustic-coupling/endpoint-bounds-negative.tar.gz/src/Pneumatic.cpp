#include "CutRegionGasTopology.h"
#include "VentTopology.h"
#include "BasinFixture.h"
#include "GraphMultigrid.h"
#include "DeflatedGraph.h"
#include "FastIc.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <string_view>
#include <vector>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

constexpr double density = 1.2;
constexpr double acousticSpeed = 343.;
constexpr double compressVolume = 1e-5;
constexpr int iterationLimit = 6000;
enum class Preconditioner { Jacobi, Ic, Amg, JacobiAmg, Geometric, IcDeflated, Fast };
Preconditioner method=Preconditioner::Jacobi;
std::string_view Method() {
    if (method == Preconditioner::Ic) return "ic0";
    if (method == Preconditioner::IcDeflated) return "ic0-deflated";
    if (method == Preconditioner::Fast) return "ic0-compact";
    if (method == Preconditioner::Amg) return "amg-sgs";
    if (method == Preconditioner::JacobiAmg) return "amg-jacobi";
    if (method == Preconditioner::Geometric) return "amg-geometric";
    return "jacobi";
}

struct Port {
    std::size_t left, right;
    double area, length;
};

struct FixtureGraph {
    std::vector<double> volume;
    std::vector<GraphCoordinate> coordinates;
    std::vector<Port> ports;
    std::vector<bool> pocket;
    double pocketVolume = 0., widestArea = 0., cutArea = 0., cutAreaByLength = 0.;
    std::size_t pocketCells = 0, cutPorts = 0, largestCell = 0;
};

bool Assemble(bool rotated, FixtureGraph& out, std::string& error) {
    const auto fixture = Fixture::Authored(rotated);
    CutRegionChart chart;
    CutRegionGeometry geometry;
    SeedImport seed;
    std::vector<double> water;
    std::vector<CutRegionWaterPlane> planes;
    CutRegionGasTopology gas;
    VentTopology old;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                               {-.005, -.015, -.005}, {.005, .025, .005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error) ||
        !WaterByRegion(fixture, chart, geometry, rotated, water, seed, error) ||
        !ReconstructCutRegionWaterPlanes(chart, geometry, 1, water, {}, planes, error) ||
        !BuildCutRegionGasTopology(chart, geometry, planes, {FullCutRegionGasVent(chart, 1, 1)}, gas, error) ||
        !BuildVentTopology(chart, geometry, 1, water, {FullChartVent(chart, 1, 1)}, old, error)) {
        return false;
    }
    const auto largest = std::max_element(old.components.begin() + 1, old.components.end(),
        [](const auto& a, const auto& b) { return a.volume < b.volume; });
    if (largest == old.components.end() || largest->regions.empty()) {
        error = "authored fixture lost its pocket reference seed";
        return false;
    }
    const auto root = largest->regions.front();
    const auto count = chart.regions.size();
    out.volume = gas.regionVolume;
    out.coordinates.reserve(count);
    const auto nx=static_cast<std::size_t>(fixture.layout.cells[0]);
    const auto ny=static_cast<std::size_t>(fixture.layout.cells[1]);
    for (const auto& r : chart.regions)
        out.coordinates.push_back({static_cast<int>(r.parent%nx),static_cast<int>((r.parent/nx)%ny),
                                   static_cast<int>(r.parent/(nx*ny))});
    std::vector<std::vector<std::pair<std::size_t, double>>> adjacency(count);
    for (std::size_t i = 0; i < geometry.faces.size(); ++i) {
        const auto& face = geometry.faces[i];
        const double area = gas.sharedDryArea[i];
        if (area <= 0.)
            continue;
        if (!(out.volume[face.left] > 0. && out.volume[face.right] > 0.)) {
            error = "positive shared gas aperture lacks volume on an endpoint";
            return false;
        }
        out.ports.push_back({face.left, face.right, area, face.length});
        adjacency[face.left].push_back({face.right, area});
        adjacency[face.right].push_back({face.left, area});
    }
    auto widest = gas.ventArea;
    std::priority_queue<std::pair<double, std::size_t>> pending;
    for (std::size_t i = 0; i < count; ++i) {
        if (widest[i] <= 0.)
            continue;
        if (!(out.volume[i] > 0.)) {
            error = "positive gas vent aperture lacks local volume";
            return false;
        }
        const double length = .5 * (chart.regions[i].hi[1] - chart.regions[i].lo[1]);
        out.ports.push_back({i, count, widest[i], length});
        pending.emplace(widest[i], i);
    }
    while (!pending.empty()) {
        const auto [area, i] = pending.top();
        pending.pop();
        if (area != widest[i])
            continue;
        for (const auto& [j, aperture] : adjacency[i]) {
            const double candidate = std::min(area, aperture);
            if (candidate > widest[j]) {
                widest[j] = candidate;
                pending.emplace(candidate, j);
            }
        }
    }

    // The strict widest-path cut is used only to report the selected chamber
    // and construct the sealed comparator. Actual solves retain every link.
    out.widestArea = widest[root];
    out.pocket.resize(count);
    out.pocket[root] = true;
    std::vector<std::size_t> flood{root};
    long double pocketVolume = 0.;
    out.largestCell = root;
    for (std::size_t i = 0; i < flood.size(); ++i) {
        const auto node = flood[i];
        pocketVolume += out.volume[node];
        if (out.volume[node] > out.volume[out.largestCell])
            out.largestCell = node;
        for (const auto& [j, aperture] : adjacency[node]) {
            if (aperture > out.widestArea && !out.pocket[j]) {
                out.pocket[j] = true;
                flood.push_back(j);
            }
        }
    }
    out.pocketVolume = static_cast<double>(pocketVolume);
    out.pocketCells = flood.size();
    for (const auto& f : out.ports) {
        if (out.pocket[f.left] != (f.right < count && out.pocket[f.right])) {
            ++out.cutPorts;
            out.cutArea += f.area;
            out.cutAreaByLength += f.area / f.length;
        }
    }
    std::cout << "GEOMETRY rotated=" << rotated << " cells=" << count << " gas_ports=" << out.ports.size()
              << " pocket_cells=" << out.pocketCells << " pocket_m3=" << out.pocketVolume
              << " previous_m3=" << largest->volume << " widest_m2=" << out.widestArea
              << " cut_ports=" << out.cutPorts << " cut_area_m2=" << out.cutArea
              << " cut_area_by_length_m=" << out.cutAreaByLength << '\n';
    return true;
}

enum class Mode { Actual, Sealed, Open };

std::string_view Label(Mode mode) {
    if (mode == Mode::Actual) return "actual";
    if (mode == Mode::Sealed) return "sealed-control";
    return "open-control";
}

struct Link {
    Port geometry;
    double conductance;
};

struct System {
    std::vector<double> c, rhs, diagonal;
    std::vector<Link> links;
    std::vector<GraphCoordinate> coordinates;

    void Apply(const std::vector<double>& x, std::vector<double>& y) const {
        const auto count = c.size();
        for (std::size_t i = 0; i < count; ++i)
            y[i] = 2. * c[i] * x[i];
        for (const auto& l : links) {
            const auto [a, b, area, length] = l.geometry;
            const double flow = l.conductance * (x[a] - (b < count ? x[b] : 0.));
            y[a] += flow;
            if (b < count)
                y[b] -= flow;
        }
    }
};

double Dot(const std::vector<double>& a, const std::vector<double>& b) {
    double sum = 0., error = 0.;
    for (std::size_t i = 0; i < a.size(); ++i) {
        const double t = std::fma(a[i], b[i], -error);
        const double next = sum + t;
        error = (next - sum) - t;
        sum = next;
    }
    return sum;
}

struct IncompleteCholesky {
    std::vector<std::vector<std::pair<std::size_t,double>>> lower;
    std::vector<double> diagonal;

    bool Build(const System& system) {
        const auto count = system.c.size();
        lower.resize(count);
        diagonal.resize(count);
        for (const auto& l : system.links) {
            const auto [a, b, area, length] = l.geometry;
            if (b == count)
                continue;
            lower[std::max(a,b)].emplace_back(std::min(a,b), -l.conductance);
        }
        for (std::size_t i = 0; i < count; ++i) {
            auto& row = lower[i];
            std::sort(row.begin(), row.end());
            std::size_t unique = 0;
            for (const auto& [j, value] : row) {
                if (unique > 0 && row[unique-1].first == j)
                    row[unique-1].second += value;
                else
                    row[unique++] = {j, value};
            }
            row.resize(unique);
            double pivot = system.diagonal[i];
            for (auto it = row.begin(); it != row.end(); ++it) {
                const auto j = it->first;
                auto& value = it->second;
                auto x = row.begin();
                auto y = lower[j].begin();
                while (x != it && y != lower[j].end()) {
                    if (x->first < y->first)
                        ++x;
                    else if (x->first > y->first)
                        ++y;
                    else {
                        value = std::fma(-x->second, y->second, value);
                        ++x;
                        ++y;
                    }
                }
                value /= diagonal[j];
                pivot = std::fma(-value, value, pivot);
            }
            if (system.diagonal[i] == 0.)
                pivot = 1.;
            if (!(pivot > 0. && std::isfinite(pivot)))
                return false;
            diagonal[i] = std::sqrt(pivot);
        }
        return true;
    }

    void Apply(const std::vector<double>& r, std::vector<double>& z) const {
        for (std::size_t i = 0; i < r.size(); ++i) {
            double x = r[i];
            for (const auto& [j, l] : lower[i])
                x -= l * z[j];
            z[i] = x / diagonal[i];
        }
        for (std::size_t i = r.size(); i-- > 0;) {
            z[i] /= diagonal[i];
            for (const auto& [j, l] : lower[i])
                z[j] -= l * z[i];
        }
    }
};

bool Solve(const System& system, const std::vector<double>& base, std::vector<double>& correction,
           int& iterations, double& relativeResidual, std::string& error) {
    if (method==Preconditioner::Fast) {
        FastIc ic;
        if (!ic.Build(system)) {
            error="compact IC lost positive pivot";
            return false;
        }
        std::cout<<"COMPACT rows="<<ic.Rows()<<" original="<<system.c.size()<<'\n';
        return ic.Solve(base,correction,iterationLimit,iterations,relativeResidual,error);
    }
    const auto count = system.c.size();
    std::vector<double> applied(count), residual(count), rhs(count), scaled(count), direction(count);
    IncompleteCholesky ic;
    const bool withIc = method==Preconditioner::Ic || method==Preconditioner::IcDeflated;
    const bool withDeflation = method==Preconditioner::IcDeflated;
    if (withIc && !ic.Build(system)) {
        error = "IC(0) lost positive preconditioner pivot";
        return false;
    }
    GraphMultigrid amg;
    DeflatedGraph deflated;
    const bool multigrid = method == Preconditioner::Amg || method == Preconditioner::JacobiAmg || method == Preconditioner::Geometric;
    if (multigrid || withDeflation) {
        std::vector<double> storage(count);
        for (std::size_t i=0; i<count; ++i)
            storage[i] = 2.*system.c[i];
        std::vector<GraphEdge> edges;
        edges.reserve(system.links.size());
        for (const auto& l : system.links) {
            const auto [a,b,area,length] = l.geometry;
            if (b == count)
                storage[a] += l.conductance;
            else
                edges.push_back({a,b,l.conductance});
        }
        if (withDeflation) {
            if (!deflated.Build(storage,system.diagonal,edges)) {
                error = "deflation lost SPD coarse solve";
                return false;
            }
            std::cout << "DEFLATION groups=" << deflated.Groups() << '\n';
        } else {
            if (!amg.Build(storage,edges,method==Preconditioner::JacobiAmg,
                           method==Preconditioner::Geometric ? system.coordinates : std::vector<GraphCoordinate>{})) {
                error = "multigrid lost SPD coarse solve";
                return false;
            }
            std::cout << "HIERARCHY levels=" << amg.Levels()
                      << " active_nodes_total=" << amg.Nodes()
                      << " edges_total=" << amg.Edges() << '\n';
        }
    }
    const auto precondition = [&](const auto& input, auto& output) {
        if (multigrid) {
            amg.Apply(input,output);
        } else if (withIc) {
            ic.Apply(input, output);
            if (withDeflation)
                deflated.Add(input,output);
        } else {
            for (std::size_t i = 0; i < count; ++i)
                output[i] = system.diagonal[i] > 0. ? input[i] / system.diagonal[i] : 0.;
        }
    };
    system.Apply(base, applied);
    for (std::size_t i = 0; i < count; ++i)
        rhs[i] = residual[i] = system.rhs[i] - applied[i];
    precondition(residual, scaled);
    direction = scaled;
    correction.assign(count, 0.);
    double product = Dot(residual, scaled);
    const double initial = product;
    if (!(initial >= 0. && std::isfinite(initial))) {
        error = "invalid initial Jacobi residual";
        return false;
    }
    const double target = initial * 1e-22;
    for (iterations = 0; iterations < iterationLimit && product > target; ++iterations) {
        system.Apply(direction, applied);
        const double curvature = Dot(direction, applied);
        if (!(curvature > 0. && std::isfinite(curvature))) {
            error = "acoustic system lost positive CG curvature";
            return false;
        }
        const double step = product / curvature;
        for (std::size_t i = 0; i < count; ++i) {
            correction[i] += step * direction[i];
            residual[i] -= step * applied[i];
        }
        const bool refresh = (iterations + 1) % 256 == 0;
        if (refresh) {
            system.Apply(correction, applied);
            for (std::size_t i = 0; i < count; ++i)
                residual[i] = rhs[i] - applied[i];
        }
        precondition(residual, scaled);
        const double next = Dot(residual, scaled);
        const double ratio = refresh ? 0. : next / product;
        for (std::size_t i = 0; i < count; ++i)
            direction[i] = scaled[i] + ratio * direction[i];
        product = next;
    }
    system.Apply(correction, applied);
    for (std::size_t i = 0; i < count; ++i)
        residual[i] = rhs[i] - applied[i];
    precondition(residual, scaled);
    const double actual = Dot(residual, scaled);
    relativeResidual = initial > 0. ? std::sqrt(actual / initial) : 0.;
    if (!(relativeResidual <= 1e-9)) {
        error = "acoustic solve exceeded its independent Jacobi residual check";
        return false;
    }
    return true;
}

bool Run(const FixtureGraph& fixture, Mode mode, double dt, bool localized) {
    const auto count = fixture.volume.size();
    const double displacement = localized ? std::min(compressVolume, 1e-4 * fixture.volume[fixture.largestCell]) :
                                            compressVolume;
    const double inputMass = density * displacement;
    const double pSealed = inputMass * acousticSpeed * acousticSpeed / fixture.pocketVolume;
    const double midpointSealed = .5 * pSealed;
    constexpr double openArea = .1, openLength = .05;
    const double openK = dt * dt * openArea / (2. * openLength);
    const double expectedOpen = inputMass / (2. * fixture.pocketVolume / (acousticSpeed * acousticSpeed) + openK);
    System system;
    system.coordinates=fixture.coordinates;
    system.c.resize(count);
    system.rhs.resize(count);
    system.diagonal.resize(count);
    std::vector<double> base(count);
    long double rhsTotal = 0.;
    for (std::size_t i = 0; i < count; ++i) {
        system.c[i] = fixture.volume[i] / (acousticSpeed * acousticSpeed);
        system.diagonal[i] = 2. * system.c[i];
        if (fixture.pocket[i]) {
            system.rhs[i] = localized ? (i == fixture.largestCell ? inputMass : 0.) :
                                        inputMass * fixture.volume[i] / fixture.pocketVolume;
            base[i] = mode == Mode::Open ? expectedOpen : midpointSealed;
            rhsTotal += system.rhs[i];
        }
    }
    const auto add = [&](const Port& f) {
        const auto k = dt * dt * f.area / (2. * f.length);
        system.links.push_back({f, k});
        system.diagonal[f.left] += k;
        if (f.right < count)
            system.diagonal[f.right] += k;
    };
    for (const auto& f : fixture.ports) {
        const bool across = fixture.pocket[f.left] != (f.right < count && fixture.pocket[f.right]);
        if (across && mode != Mode::Actual)
            continue;
        add(f);
    }
    if (mode == Mode::Open) {
        // Positive control only. The same gas volume/forcing is connected
        // directly to manufactured vents, with conductance proportional to C.
        for (std::size_t i = 0; i < count; ++i)
            if (fixture.pocket[i])
                add({i, count, openArea * fixture.volume[i] / fixture.pocketVolume, openLength});
    }

    double massDiagonalRatio = 1.;
    for (std::size_t i = 0; i < count; ++i)
        if (system.c[i] > 0.)
            massDiagonalRatio = std::min(massDiagonalRatio, 2. * system.c[i] / system.diagonal[i]);
    std::vector<double> correction;
    int iterations = 0;
    double relativeResidual = 0.;
    std::string error;
    const auto begin = std::chrono::steady_clock::now();
    const bool solved = Solve(system, base, correction, iterations, relativeResidual, error);
    const auto end = std::chrono::steady_clock::now();
    const double elapsed = std::chrono::duration<double, std::milli>(end - begin).count();

    long double pAverage = 0., addedMass = 0., leakedMass = 0., escapedMass = 0.;
    long double gasEnergy = 0., kineticEnergy = 0., work = 0.;
    double maxSpeed = 0., maxPressure = 0., worstRowMass = 0.;
    std::vector<long double> imbalance(count);
    for (std::size_t i = 0; i < count; ++i) {
        const long double pMid = static_cast<long double>(base[i]) + correction[i];
        const long double pEnd = 2. * pMid;
        maxPressure = std::max(maxPressure, static_cast<double>(std::abs(pEnd)));
        const long double mass = system.c[i] * pEnd;
        addedMass += mass;
        imbalance[i] = mass - system.rhs[i];
        gasEnergy += .5L * system.c[i] * pEnd * pEnd / density;
        work += pMid * system.rhs[i] / density;
        if (fixture.pocket[i])
            pAverage += fixture.volume[i] * pEnd;
    }
    for (const auto& l : system.links) {
        const auto [a, b, area, length] = l.geometry;
        const auto bBase = b < count ? base[b] : 0.;
        const auto bCorrection = b < count ? correction[b] : 0.;
        const long double pressureJump = (static_cast<long double>(base[a]) - bBase) +
            (static_cast<long double>(correction[a]) - bCorrection);
        // Independent mass from the midpoint velocity, rather than use G.
        const long double velocityEnd = dt * pressureJump / (density * length);
        const long double transfer = .5L * density * dt * area * velocityEnd;
        imbalance[a] += transfer;
        if (b < count)
            imbalance[b] -= transfer;
        else
            escapedMass += transfer;
        if (fixture.pocket[a] && (b == count || !fixture.pocket[b]))
            leakedMass += transfer;
        else if (!fixture.pocket[a] && b < count && fixture.pocket[b])
            leakedMass -= transfer;
        kineticEnergy += .5L * density * area * length * velocityEnd * velocityEnd;
        maxSpeed = std::max(maxSpeed, static_cast<double>(std::abs(velocityEnd)));
    }
    for (long double row : imbalance)
        worstRowMass = std::max(worstRowMass, static_cast<double>(std::abs(row)));
    const double energyError = static_cast<double>(gasEnergy + kineticEnergy - work);
    const double massError = static_cast<double>(addedMass + escapedMass - rhsTotal);
    const double average = static_cast<double>(pAverage / fixture.pocketVolume);
    const double upperLeak = midpointSealed * dt * dt * .5 * fixture.cutAreaByLength;
    std::cout << "RESULT mode=" << Label(mode) << " dt=" << dt << " local=" << localized
              << " solved=" << solved << " iterations=" << iterations << " elapsed_ms=" << elapsed
              << " preconditioner=" << Method()
              << " pcg_relative=" << relativeResidual << " minimum_storage_ratio=" << massDiagonalRatio
              << " p_mean_Pa=" << average << " p_sealed_Pa=" << pSealed
              << " p_open_control_Pa=" << 2. * expectedOpen << " peak_p_Pa=" << maxPressure
              << " cut_mass_kg=" << leakedMass << " cut_bound_kg=" << upperLeak
              << " vent_mass_kg=" << escapedMass << " peak_speed_m_s=" << maxSpeed
              << " source_mass_kg=" << rhsTotal << " mass_error_kg=" << massError
              << " max_row_mass_kg=" << worstRowMass << " energy_error_J=" << energyError
              << " work_J=" << work << " reason=" << error << '\n';

    const double toleranceMass = 1e-8 * inputMass, toleranceEnergy = 1e-8 * std::abs(work);
    if (!solved || std::abs(massError) > toleranceMass || worstRowMass > toleranceMass ||
        std::abs(energyError) > toleranceEnergy || maxSpeed >= acousticSpeed)
        return false;
    if (!localized) {
        if (mode == Mode::Actual)
            return leakedMass >= -1e-25L && leakedMass <= upperLeak * 1.00001 + 1e-25L;
        const double expected = mode == Mode::Open ? 2. * expectedOpen : pSealed;
        return std::abs(average - expected) <= 1e-10 * expected;
    }
    return true;
}

} // namespace

int main(int argc, char** argv) {
    if (argc > 2)
        return 2;
    if (argc == 2) {
        const std::string_view flag(argv[1]);
        if (flag == "--ic0")
            method=Preconditioner::Ic;
        else if (flag == "--ic0-compact")
            method=Preconditioner::Fast;
        else if (flag == "--ic0-deflated")
            method=Preconditioner::IcDeflated;
        else if (flag == "--amg")
            method=Preconditioner::Amg;
        else if (flag == "--amg-geometric")
            method=Preconditioner::Geometric;
        else if (flag == "--amg-jacobi")
            method=Preconditioner::JacobiAmg;
        else
            return 2;
    }
    std::cout << std::setprecision(17);
    bool ok = true;
    for (const bool rotated : {false, true}) {
        FixtureGraph fixture;
        std::string error;
        if (!Assemble(rotated, fixture, error)) {
            std::cerr << "FAILED " << error << '\n';
            return 1;
        }
        for (const double dt : {double(tick), double(tick) / 4.}) {
            for (const auto mode : {Mode::Actual, Mode::Sealed, Mode::Open})
                ok &= Run(fixture, mode, dt, false);
            ok &= Run(fixture, Mode::Actual, dt, true);
        }
    }
    return ok ? 0 : 1;
}
