# Rotated basin hydroacoustic graph diagnostics

The underlying finite-volume cut chart is the original authored rotated
basin at the existing liquid-initialization seed. The matrix comparator
has 35,840 regions, 65,801 gas ports, 33,249 wet ports and 1,489 interior
free surfaces. It deliberately omits free surfaces that coincide with a
shared face. It prescribes static-graph volume pulses, with no native
MK2 body update, no moving geometry, and no phase-capacity acceptance.

The graph stores exact positive face conductances. The compact variant
uses the same matrix, a symmetric incomplete Cholesky preconditioner,
and a per-original-row volume residual of at most 1e-19 m³. Legacy
scratch IC0 used an L2 residual target of 1e-11 relative to its RHS.
The recorded matched runs use four independent solves. They are not a
timing distribution or a complete substep performance measurement.
Each logged run independently reconstructs flux, storage, pressure work
and phase-volume closure from the pressure solution. The old prototype
prototype common-ground solver's separate outcome appears as core_ok.

The newer compact core comparison uses its public 1e-15 m³ configuration.
The offline strict graph cross-check remains at 1e-19 m³ and independently
reports any negative phase volume or transported gas inventory.

From the extracted directory, reproduce with GCC:

```bash
set -e
mkdir -p reproduced
cd src
g++ -std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror HydroGraphControls.cpp CutHydroacousticGraph.cpp -o ../reproduced/graph-controls
../reproduced/graph-controls
common=(CutRegionGeometry.cpp CutRegionGasTopology.cpp VentTopology.cpp CutRegionPressure.cpp MovingVolumeGrid.cpp GridConservativeRemap.cpp GridGeometricMomentum.cpp GridPhaseFluxRepair.cpp GridHalfCellGeometry.cpp MovingVolumeMomentum.cpp HalfDualVolumeMomentum.cpp CutHydroacousticGraph.cpp)
g++ -std=c++20 -O3 -DNDEBUG CoupledTracked.cpp CutHydroacousticPressure.cpp "${common[@]}" -o ../reproduced/coupled-tracked
../reproduced/coupled-tracked --ic0
../reproduced/coupled-tracked --tracked
g++ -std=c++20 -O3 -DNDEBUG CoupledCore.cpp CutHydroacousticPressure.tracked.cpp "${common[@]}" -o ../reproduced/coupled-core
../reproduced/coupled-core --tracked
```

The old geometry sources are snapshot-specific. The two core source
copies share the same public low-level interface in this packet. Other
scratch source variants preserve previously rejected preconditioners
and are included to avoid mistaking the compact solver for the only
approach examined. No result qualifies native moving-basin publication.
