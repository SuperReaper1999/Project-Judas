#include "CutRegionGeometry.h"
#include "BasinFixture.h"

#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <vector>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

struct Footprint {
    std::size_t ports = 0;
    double area = 0.;
};

double Section(const CutRegion& cut, const std::optional<BoxMotion>& solid, bool below) {
    auto lo = cut.lo, hi = cut.hi;
    const double side = below ? hi[1] : lo[1];
    double width = .25 * (hi[1] - lo[1]);
    if (solid) {
        for (double edge : {solid->lo[1], solid->hi[1]}) {
            const double distance = below ? side - edge : edge - side;
            if (distance > 0.) width = std::min(width, .5 * distance);
        }
    }
    if (below) lo[1] = side - width;
    else hi[1] = side + width;
    if (!(lo[1] < hi[1]))
        return -1.;
    return CutRegionClippedVolume(cut, solid, lo, hi) / (hi[1] - lo[1]);
}

bool Report(bool rotated) {
    const auto fixture = Fixture::Authored(rotated);
    CutRegionChart chart;
    CutRegionGeometry geometry;
    std::vector<double> water;
    std::vector<CutRegionWaterPlane> planes;
    SeedImport seed;
    std::string error;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                               {-.005, -.015, -.005}, {.005, .025, .005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error) ||
        !WaterByRegion(fixture, chart, geometry, rotated, water, seed, error) ||
        !ReconstructCutRegionWaterPlanes(chart, geometry, 1, water, {}, planes, error)) {
        std::cout << "FAIL rotated=" << rotated << " " << error << '\n';
        return false;
    }
    std::size_t coincident = 0, matched = 0, interiorBlocked = 0;
    double activeArea = 0.;
    std::array<std::vector<Footprint>, 2> recipients{
        std::vector<Footprint>(chart.regions.size()), std::vector<Footprint>(chart.regions.size())
    };
    for (const auto& face : geometry.faces) {
        if (face.axis != 1 || geometry.startCapacity[face.left] <= 0. ||
            geometry.startCapacity[face.right] <= 0. ||
            water[face.left] != geometry.startCapacity[face.left] || water[face.right] != 0. ||
            planes[face.left].RelativeTo(face.lo[1]) != 0. ||
            planes[face.right].RelativeTo(face.lo[1]) != 0.)
            continue;
        const double area = MeasureCutRegionSharedPhase(face, geometry.motion,
            planes[face.left], planes[face.right], true, false).start;
        if (!(area > 0.)) {
            ++interiorBlocked;
            continue;
        }
        ++coincident;
        activeArea += area;
        auto& below = recipients[0][face.left];
        auto& above = recipients[1][face.right];
        ++below.ports; ++above.ports;
        below.area += area; above.area += area;
        const double leftArea = Section(chart.regions[face.left], geometry.motion, true);
        const double rightArea = Section(chart.regions[face.right], geometry.motion, false);
        if (std::abs(leftArea - area) <= 1e-12 * area &&
            std::abs(rightArea - area) <= 1e-12 * area)
            ++matched;
    }
    std::cout << "BASIN rotated=" << rotated << " wet_m3=" << std::accumulate(water.begin(), water.end(), 0.L)
              << " coincident_full_wet_to_full_dry_faces=" << coincident
              << " all_open_area_m2=" << activeArea << " blocked_faces=" << interiorBlocked
              << " individually_full_both=" << matched << '\n';
    for (std::size_t side = 0; side < recipients.size(); ++side) {
        std::size_t singleFull = 0, multiFull = 0, partial = 0, unresolved = 0;
        for (std::size_t i = 0; i < recipients[side].size(); ++i) {
            const auto& footprint = recipients[side][i];
            if (footprint.ports == 0) continue;
            const double section = Section(chart.regions[i], geometry.motion, side == 0);
            if (!(section > 0.)) {
                ++unresolved;
                continue;
            }
            const double relative = std::abs(section - footprint.area) / section;
            if (relative > 1e-12) ++partial;
            else if (footprint.ports > 1) ++multiFull;
            else ++singleFull;
        }
        std::cout << "RECIPIENT " << (side == 0 ? "gas" : "wet") << " single_full=" << singleFull
                  << " multiple_collectively_full=" << multiFull << " partial=" << partial
                  << " unresolved_local_section=" << unresolved << '\n';
    }
    return true;
}

} // namespace

int main() {
    std::cout << std::setprecision(17);
    const bool aligned = Report(false);
    const bool rotated = Report(true);
    return !aligned || !rotated;
}
