#include "CutRegionGeometry.h"
#include "CutRegionPressure.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace judas::volume_grid;

namespace {

constexpr double dt = 1. / 60.;
constexpr double rho = 1000.;
constexpr double gasDensity = 1.2;
constexpr double sound = 343.;
constexpr double gravity = 9.81;
constexpr double scale = rho * gravity;
constexpr double bulk = gasDensity * sound * sound;
constexpr double boundary = 1.;
constexpr double initialPiston = .2;

enum { Wall, Wet, Gas, Ground };

struct Result {
    double area = 0., shift = 0., compression = 0., midpointVelocity = 0., endVelocity = 0.;
    double waterMomentumTransfer = 0., gasMassTransfer = 0., gasMomentumTransfer = 0.;
    double storageWork = 0., pressureWork = 0., waterPotential = 0., gasEnergy = 0.;
    double waterKinetic = 0., wallPressure = 0., wallForce = 0., wallWork = 0., workResidual = 0.;
    std::array<double, 2> water{}, gas{}, gasMass{}, waterMomentum{}, gasMomentum{};
    std::array<double, 3> pressure{};
    CutRegionAperture wetSupport, gasSupport;
};

bool Fail(std::string& error, const char* message) {
    error = message;
    return false;
}

double Capacity(const CutRegion& region, const BoxMotion& piston) {
    return CutRegionClippedVolume(region, piston, region.lo, region.hi);
}

bool Advance(double move, double initialSpeed, double gasTangentialSpeed,
             double ceiling, Result& output, std::string& error) {
    CutRegionChart chart;
    CutRegionGeometry empty;
    if (!PrepareCutRegionChart({{1, 2, 1}, 1.}, {}, {}, {}, {}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, empty, error))
        return false;
    if (chart.regions.size() != 2 || empty.faces.size() != 1 ||
        empty.faces[0].left != 0 || empty.faces[0].right != 1)
        return Fail(error, "two-cell chart changed unexpectedly");
    const auto& face = empty.faces[0];
    const double finalPiston = initialPiston + move;
    if (!(0. <= finalPiston && finalPiston < boundary && boundary < ceiling && ceiling <= 2.))
        return Fail(error, "piston or roof lies outside its declared pressure corridor");
    const BoxMotion oldSolid{1, {0., -1., 0.}, {1., initialPiston, 1.}, {}};
    const BoxMotion endSolid{1, {0., -1., 0.}, {1., finalPiston, 1.}, {}};
    auto upper = chart.regions[1];
    upper.hi[1] = ceiling;
    const auto& lower = chart.regions[0];
    const double water0 = Capacity(lower, oldSolid);
    const double gas0 = Capacity(upper, oldSolid);
    const double waterFixed = Capacity(lower, endSolid);
    const CutRegionWaterPlane lowWet{{1, false}, boundary}, highDry{{1, false}, boundary};
    const double area = MeasureCutRegionSharedPhase(face, oldSolid, lowWet, highDry,
                                                    true, false).start;
    if (!(area > 0. && gas0 > 0. && water0 > 0.))
        return Fail(error, "initial cross-face interface has no fluid support");
    // This control has one prismatic pressure-owned corridor on each
    // side of the interface. A partial footprint would need its own cut.
    if (water0 != area * (boundary - initialPiston) ||
        gas0 != area * (ceiling - boundary))
        return Fail(error, "interface footprint does not own both corridor cross-sections");

    const double waterSource = water0 - waterFixed;
    const double waterLength = water0 / area;
    const double gasComplianceHead = scale * gas0 / bulk;
    const double inertial = dt * dt * area * scale / (2. * rho * waterLength);
    const std::vector<CutRegionPressureFace> pressureEdges{
        {Wall, Wet, inertial, dt * area * initialSpeed},
        {Wet, Gas, 2. * area, 0.},
        {Gas, Ground, 2. * gasComplianceHead, 0.}
    };
    CutRegionPressure projection;
    if (!ProjectCutRegionPressure({waterSource, 0., 0., -waterSource}, pressureEdges,
                                   std::max(water0, gas0), 1e-14, projection, error, Ground))
        return false;

    Result next;
    next.area = area;
    next.shift = projection.volumeFlux[1];
    next.compression = projection.volumeFlux[2];
    const double nextSurface = boundary + next.shift / area;
    if (!(nextSurface > finalPiston && nextSurface < ceiling))
        return Fail(error, "surface reaches a corridor boundary and requires a phase event");
    for (int i = 0; i < 3; ++i)
        next.pressure[i] = scale * projection.pressure[i];
    next.endVelocity = initialSpeed + dt * scale * projection.pressureJump[0] / (rho * waterLength);
    next.midpointVelocity = .5 * (initialSpeed + next.endVelocity);
    const double transfer = projection.volumeFlux[0];
    if (std::abs(transfer - next.shift) > 1e-14)
        return Fail(error, "wall and material surface transfers disagree");

    next.water = {waterFixed + std::min(0., next.shift), std::max(0., next.shift)};
    next.gas = {std::max(0., -next.shift), gas0 - std::max(0., next.shift)};
    // No gas enters or leaves the closed pressure owner. Partition its
    // actual mass at the common endpoint density only after geometry resolves.
    const double gasMass0 = gasDensity * gas0;
    const double endpointGasVolume = next.gas[0] + next.gas[1];
    next.gasMass[0] = gasMass0 * (next.gas[0] / endpointGasVolume);
    next.gasMass[1] = gasMass0 - next.gasMass[0];
    next.gasMassTransfer = -next.gasMass[0];
    next.gasMomentumTransfer = gasTangentialSpeed * next.gasMassTransfer;
    next.gasMomentum = {-next.gasMomentumTransfer,
                         gasMass0 * gasTangentialSpeed + next.gasMomentumTransfer};

    // Uniform plug acceleration. The midpoint product rule splits the pressure
    // impulse across actual time-averaged water mass and advects the same mass
    // at the interface velocity through the chart cut when it has a wet layer.
    const double waterMoved = rho * next.water[1];
    const double velocityChange = next.endVelocity - initialSpeed;
    next.waterMomentumTransfer = waterMoved * next.midpointVelocity;
    next.waterMomentum[0] = rho * water0 * initialSpeed +
        .5 * rho * (water0 + next.water[0]) * velocityChange - next.waterMomentumTransfer;
    next.waterMomentum[1] = .5 * waterMoved * velocityChange + next.waterMomentumTransfer;

    const CutRegionWaterPlane endpoint{{1, false}, nextSurface};
    const auto lowerParts = MeasureCutRegionPhaseVolumes(lower, endSolid, lower.lo, lower.hi, endpoint);
    const auto upperParts = MeasureCutRegionPhaseVolumes(upper, endSolid, upper.lo, upper.hi, endpoint);
    if (!(std::abs(lowerParts[0] - next.water[0]) <= 1e-14 &&
          std::abs(upperParts[0] - next.water[1]) <= 1e-14 &&
          std::abs(lowerParts[1] - next.gas[0]) <= 1e-14 &&
          std::abs(upperParts[1] - next.gas[1]) <= 1e-14))
        return Fail(error, "endpoint phase capacity disagrees with displaced chart geometry");
    next.wetSupport = MeasureCutRegionSharedPhase(face, endSolid, endpoint, endpoint, true, true);
    next.gasSupport = MeasureCutRegionSharedPhase(face, endSolid, endpoint, endpoint, false, false);

    next.storageWork = (next.pressure[Wet] - next.pressure[Gas]) * next.shift;
    next.pressureWork = next.pressure[Wall] * waterSource;
    const auto moment = [&](double surface, double piston) {
        const double liquidTop = surface - boundary, liquidBottom = piston - boundary;
        return .5 * area * (liquidTop * liquidTop - liquidBottom * liquidBottom);
    };
    next.waterPotential = scale * (moment(nextSurface, finalPiston) - moment(boundary, initialPiston));
    next.gasEnergy = bulk * next.compression * next.compression / (2. * gas0);
    next.waterKinetic = .5 * rho * water0 * (next.endVelocity + initialSpeed) * velocityChange;
    next.wallPressure = next.pressure[Wall] + scale * (boundary - .5 * (initialPiston + finalPiston));
    next.wallForce = -area * next.wallPressure;
    next.wallWork = next.wallPressure * waterSource;
    next.workResidual = next.wallWork - next.waterPotential - next.gasEnergy - next.waterKinetic;
    if (!(std::abs(next.workResidual) <= 1e-10 * (1. + std::abs(next.wallWork))))
        return Fail(error, "actual moving-wall work and phase storage disagree");
    output = next;
    error.clear();
    return true;
}

struct LedgeMeasurements {
    double area = 0., positiveSlope = 0., negativeSlope = 0.;
    double naiveUpperWater = 0., unsupportedUpperWater = 0.;
};

bool MeasureLedge(LedgeMeasurements& result, std::string& error) {
    CutRegionChart chart;
    CutRegionGeometry empty;
    // Fixed half-width shelf ends precisely at the interface from below.
    // The upper region is open above it and can only wet there by lateral flow.
    const BoxMotion ledge{2, {.5, .75, 0.}, {1., 1., 1.}, {}};
    if (!PrepareCutRegionChart({{1, 2, 1}, 1.}, {ledge}, {}, {}, {}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, empty, error))
        return false;
    const auto face = std::find_if(empty.faces.begin(), empty.faces.end(), [](const auto& candidate) {
        return candidate.axis == 1 && candidate.lo[1] == boundary;
    });
    if (face == empty.faces.end())
        return Fail(error, "ledge cut geometry lacks the crossing face");
    const auto& lower = chart.regions[face->left];
    const auto& upper = chart.regions[face->right];
    const CutRegionWaterPlane initial{{1, false}, boundary};
    result.area = MeasureCutRegionSharedPhase(*face, {}, initial, initial, true, false).start;
    const double increment = 1. / 1024.;
    const CutRegionWaterPlane raised{{1, false}, boundary + increment};
    const CutRegionWaterPlane lowered{{1, false}, boundary - increment};
    const auto volume = [&](const CutRegion& cut, const CutRegionWaterPlane& plane, bool wet) {
        return MeasureCutRegionPhaseVolumes(cut, {}, cut.lo, cut.hi, plane)[wet ? 0 : 1];
    };
    result.positiveSlope = volume(upper, raised, true) / increment;
    result.negativeSlope = volume(lower, lowered, false) / increment;
    const CutRegionWaterPlane naive{{1, false}, boundary + increment / result.area};
    result.naiveUpperWater = volume(upper, naive, true);
    auto unsupported = upper;
    unsupported.lo[0] = .5;
    result.unsupportedUpperWater = volume(unsupported, raised, true);
    return true;
}

} // namespace

int main() {
    std::cout << std::setprecision(17);
    int total = 0, failed = 0;
    const auto check = [&](bool good, const std::string& label) {
        ++total;
        failed += !good;
        std::cout << (good ? "PASS " : "FAIL ") << label << '\n';
    };
    Result last;
    std::string error;
    for (const double move : {0., .002, -.002}) {
        const double u0 = 30. * move, gasSpeed = .25;
        const bool ok = Advance(move, u0, gasSpeed, 2., last, error);
        check(ok, "shared phase interface and moving source admit, move=" + std::to_string(move) + " " + error);
        if (!ok)
            continue;
        const double w0 = 1. - initialPiston;
        const double expectedU = 2. * move / dt - u0;
        const double gasMean = .5 * bulk * move;
        const double wetMean = gasMean + .5 * scale * move;
        const double wallMean = wetMean + rho * w0 * (expectedU - u0) / dt;
        check(std::abs(last.shift - move) < 1e-14 && std::abs(last.compression - move) < 1e-14 &&
              std::abs(last.pressure[Gas] - gasMean) < 1e-8 &&
              std::abs(last.pressure[Wet] - wetMean) < 1e-8 &&
              std::abs(last.pressure[Wall] - wallMean) < 1e-8,
              "midpoint pressure, compliance and actual wall reaction match analytical source");
        check(std::abs(last.endVelocity - expectedU) < 1e-12 &&
              std::abs(last.water[0] + last.water[1] - w0) < 1e-14 &&
              std::abs(last.gasMass[0] + last.gasMass[1] - gasDensity) < 1e-14,
              "water volume, gas mass and accelerated liquid plug velocity are conservative");
        check(std::abs(last.waterMomentum[0] - rho * last.water[0] * expectedU) < 1e-10 &&
              std::abs(last.waterMomentum[1] - rho * last.water[1] * expectedU) < 1e-10 &&
              std::abs(last.gasMomentum[0] + last.gasMomentum[1] - gasDensity * gasSpeed) < 1e-13,
              "new water and gas endpoint material carry their actual shared momentum provenance");
        check(std::abs(last.storageWork - scale * move * move / 2.) < 1e-11 &&
              std::abs(last.workResidual) < 1e-10 &&
              std::abs(last.wallForce * move + last.wallWork) < 1e-10,
              "solid reaction, kinetic, gas compression and gravitational work close");
        if (move > 0.)
            check(last.water[1] > 0. && last.gas[0] == 0. && last.wetSupport.start == 1. &&
                  last.gasSupport.start == 0. && last.waterMomentumTransfer > 0. &&
                  last.gasMomentumTransfer == 0., "rising surface wets the physical upper recipient");
        else if (move < 0.)
            check(last.water[1] == 0. && last.gas[0] > 0. && last.wetSupport.start == 0. &&
                  last.gasSupport.start == 1. && last.waterMomentumTransfer == 0. &&
                  last.gasMomentumTransfer < 0., "falling surface exposes actual lower gas and carries gas momentum");
        else
            check(last.shift == 0. && last.compression == 0. && last.endVelocity == 0. &&
                  last.water[1] == 0. && last.gas[0] == 0. && last.wallWork == 0.,
                  "exact cut-face rest has zero transport or dynamic wall work");
        std::cout << "MEASURE move=" << move << " shift_m3=" << last.shift
                  << " water_new_m3=" << last.water[1] << " gas_new_m3=" << last.gas[0]
                  << " gas_mass_cross_kg=" << last.gasMassTransfer
                  << " water_momentum_cross_kgms=" << last.waterMomentumTransfer
                  << " gas_momentum_cross_kgms=" << last.gasMomentumTransfer
                  << " wall_work_J=" << last.wallWork << " work_residual_J=" << last.workResidual << '\n';
    }
    const auto saved = last;
    check(!Advance(.02, .6, .25, 1.01, last, error) && last.shift == saved.shift &&
          last.water == saved.water && last.gasMass == saved.gasMass,
          "sweeping past a dry-region end rejects and preserves published phase state");
    LedgeMeasurements ledge;
    check(MeasureLedge(ledge, error) && ledge.area == .5 && ledge.positiveSlope == 1. &&
          ledge.negativeSlope == .5, "ledge has different one-sided occupancy slopes despite one common aperture");
    check(ledge.naiveUpperWater == 1. / 512., "symmetric edge area and whole-region plane double rising liquid volume");
    check(ledge.unsupportedUpperWater == 1. / 2048.,
          "mass-conserving whole-region plane still wets beyond the receiving face footprint without lateral flux");
    std::cout << "LEDGE face_area=" << ledge.area << " positive_volume_slope=" << ledge.positiveSlope
              << " negative_volume_slope=" << ledge.negativeSlope
              << " naive_water_m3=" << ledge.naiveUpperWater
              << " unsupported_water_m3=" << ledge.unsupportedUpperWater << '\n';
    std::cout << "CHECKS " << total << " FAILURES " << failed << '\n';
    return failed != 0;
}
