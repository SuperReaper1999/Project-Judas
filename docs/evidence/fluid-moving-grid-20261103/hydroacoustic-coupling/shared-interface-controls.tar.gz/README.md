# Shared-face phase storage control

This disposable standalone control used copies of the Experimental cut geometry
and pressure sources at HEAD f41545df297e61f6a7f6ececebf0e844e52a5527 plus the
then-current prototype edits (the exact source snapshots are included).
No tracked files or engine fluid paths were modified.

## Positive model

Two unit cells stack along y. Initially the lower region is filled by
incompressible liquid above a full-width piston and the upper region contains
gas. The free surface sits exactly on their shared chart face. This control
treats the external piston as a prescribed physical boundary source, using the
real cut volume routine to obtain its exact signed swept volume ε. It uses a
linear compressible sealed gas with initial volume G0 and bulk modulus B, and a
single liquid plug of mass ρW0. Let A be the common horizontal face aperture,
k = ρg, L = W0/A, and s = A(h1 − h0) be the signed liquid interface sweep.
Pressures P use hydraulic head metres, with midpoint gravity correction at the
piston and initial atmospheric pressure as datum.

    wet–gas interface storage    s = 2A(P_w − P_g)
    sealed-gas compression       c = 2kG0 P_g / B
    wall-to-wet liquid update    q = dt A u0 + dt² A k(P_wall − P_w)/(2ρL)
    graph balances              q = ε, s = q, c = s
    midpoint piston velocity     u_bar = ε/(A dt)
    endpoint liquid velocity     u1 = 2 u_bar − u0

The existing pressure graph solves these three signed edges. Interface storage
is a pressure-volume work coordinate. It is not independent water and gas flow
through a face. The old wet and gas pressure nodes own storage over the interval.
A positive s gives real upper-cell water s. A negative s gives real lower-cell
gas −s. The geometry clips both endpoints at their actual elevation. Only the
phase moving into a new cell transfers ownership across the old face. Total
water volume and sealed gas mass are constant. The newly opened lower gas volume
receives gas at the owner's final density M/(G0−s) and carries its tangential
momentum. The midpoint liquid transfer uses ρs u_bar on rise, and the midpoint
product rule splits plug pressure impulse according to each endpoint cell's
time-averaged liquid mass.

    liquid interface potential work     k s²/(2A)
    gas acoustic storage energy          B c²/(2 G0)
    actual piston work                  ε [kP_wall + k(h0 − y_piston,mid)]

Piston work equals the independently integrated change of liquid gravitational
first moment plus gas acoustic energy and plug kinetic energy. Solid reaction
does the opposite work. The three signed cases test exact rest and ±2 mm in
1/60 s with moving starting momentum. The shallow roof case must reject without
publishing partially changed state. This is a lumped linear gas control; it
does not model gas normal inertia, finite-speed equalization, or thermal
evolution. The piston is a test boundary, not a claim that the chart builder
supports moving bodies through domain walls.

## Ledge negative control

An actual stationary half-width ledge ends at the shared face from below. The
initial common opening area is 0.5 m². The lower newly gas-filled slice has
section 0.5 m², whereas the whole upper cut spans 1 m². Moving a whole-cell
water plane by the head from a symmetric 0.5 m² compliance doubles upper
liquid volume on rise. Inverting the whole-cell plane to conserve volume
instead places half the new liquid beyond the receiving footprint without any
lateral flux. Whole-cell elevation equality is a separate equilibration
assumption and does not follow from the storage edge.

## Integration recommendation

Reuse the midpoint pressure edge for a matched, connected corridor with real
clearance on both sides. Remap occupancy, mass and momentum conservatively at
the physical endpoint, and recalculate wet and gas ports for the next interval.
An explicit geometric branch or phase event is needed when the interface
crosses an exhausted support, the one-sided receiving footprints differ, or
finite local transport cannot reconstruct its occupancy. A local subcut that
preserves the actual wetting footprint can avoid an event in some of those
cases. A sign-aware law for volume s must integrate gravitational work against
the resulting physical h(s), and requires conservative routing to real
recipients. A small numeric floor on conductance cannot justify support across
a solid or dry seam. No authored basin, MK2 coupling, runtime, or Alpha
qualification is claimed by this control.

## Build and run

    c++ -std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror         -ffunction-sections -fdata-sections -MMD SharedInterfaceControl.cpp         CutRegionGeometry.cpp CutRegionPressure.cpp MovingVolumeGrid.cpp         -Wl,--gc-sections -o controls
    ./controls

The sanitizer comparison uses the same translation units and linker flag with
-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer.

The sandbox reports a ptrace restriction on LeakSanitizer (the original output
is preserved). The ASan + UBSan checks pass with
`ASAN_OPTIONS=detect_leaks=0 ./controls-sanitized`.

## Authored seed diagnostic

`BasinFaceCoverage.cpp` reproduces the original exact parcel import for both
authored rotations using the included prior basin fixture source. It counts
strict full-liquid/empty-liquid neighboring cuts with both reconstructed
interfaces exactly coinciding with the shared chart plane, and measures the
immediate section in each incident cut. It does not count near faces,
sub-coordinate liquid or dry layers, or noncoincident mixed planes. All
sections are measured at the initial geometry. This is static support
inventory, not dynamic basin validation or a numerical pressure test.

    c++ -std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror         BasinFaceCoverage.cpp CutRegionGeometry.cpp -o coverage
    ./coverage

The coverage diagnostic needs GLM headers, as the original fixture uses the
native rounded quaternion to reconstruct chart positions.
