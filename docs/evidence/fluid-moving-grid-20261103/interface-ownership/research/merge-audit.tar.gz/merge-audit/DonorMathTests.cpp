#include "CutLiquidGas.cpp"

#include <cmath>
#include <iostream>

namespace judas::volume_grid {
int DonorMathControls() {
    int count = 0, failed = 0;
    const auto check = [&](bool pass, const char* name) {
        ++count;
        failed += !pass;
        std::cout << (pass ? "PASS " : "FAIL ") << name << '\n';
    };
    const auto near = [](double a, double b) { return std::abs(a - b) < 1e-12; };

    // Fixed donor 0 supplies two independent oriented faces, one reversed.
    const std::vector<Port> ports{{0,0,1,2.,0.,3.}, {1,2,0,0.,1.,-1.}};
    std::vector<double> pressure(3), weights(2);
    DonorProjection projection;
    ProjectWaterDonors(ports, {8.,0.,0.}, pressure, true, weights, projection);
    check(projection.limited == 0 && projection.flux[0] == 6. && projection.flux[1] == -1.,
          "uncapped flux preserves signed pressure response");

    ProjectWaterDonors(ports, {5.,0.,0.}, pressure, true, weights, projection);
    check(projection.limited == 1 && near(projection.flux[0],14./3.) && near(projection.flux[1],-1./3.) &&
          projection.flux[0]-projection.flux[1] <= 5., "weighted cap preserves conservative signed donor ledger");

    pressure[0] = 10.;
    ProjectWaterDonors(ports, {5.,0.,0.}, pressure, true, weights, projection);
    check(near(projection.flux[0],14./3.) && near(projection.flux[1],-1./3.),
          "fully capped group removes common donor head");

    pressure = {0.,-.1,.1};
    ProjectWaterDonors(ports, {5.,0.,0.}, pressure, true, weights, projection);
    check(near(projection.flux[0],14./3. + (2./3.)*.2) && near(projection.flux[1],-1./3. + (2./3.)*.2),
          "active cap derivative is a positive recipient-to-recipient pressure edge");

    pressure = {0.,0.,0.};
    ProjectWaterDonors(ports, {3.,0.,0.}, pressure, true, weights, projection);
    check(projection.flux[0] == 3. && projection.flux[1] == 0. && weights[1] == 0. &&
          projection.activeOutlets[0].size() == 1, "insufficient head closes second active-set outlet");

    ProjectWaterDonors(ports, {0.,0.,0.}, pressure, true, weights, projection);
    check(projection.flux[0] == 0. && projection.flux[1] == 0., "empty inventory sends no water");

    pressure = {1e10,0.,0.};
    ProjectWaterDonors(ports, {1e-19,0.,0.}, pressure, true, weights, projection);
    check(projection.flux[0] == 1e-19 && projection.flux[1] == 0.,
          "thin donor retains representable volume despite large head gauge");

    std::cout << "SUMMARY " << count - failed << '/' << count << '\n';
    return failed != 0;
}
}
int main() { return judas::volume_grid::DonorMathControls(); }
