#pragma once

#include <cmath>
#include <limits>

namespace judas::volume_grid {

struct GasMeanPressure {
    double gauge, slope;
};

// Reversible adiabatic gas. Return the work-conjugate interval pressure and
// its derivative with respect to final volume. Pressure is relative to ambient.
inline GasMeanPressure MeanGasPressure(double startingVolume, double endVolume,
                                       double startingAbsolute, double ambient,
                                       double exponent = 1.4) {
    if (!(endVolume > 0.))
        return {std::numeric_limits<double>::infinity(), -std::numeric_limits<double>::infinity()};
    const double change = (endVolume - startingVolume) / startingVolume;
    if (std::abs(change) < 1e-4) {
        const double half = .5 * exponent;
        const double second = exponent * (exponent + 1.) / 6.;
        const double third = exponent * (exponent + 1.) * (exponent + 2.) / 24.;
        const double relative = change * (-half + change * (second - third * change));
        const double derivative = -half + change * (2. * second - 3. * third * change);
        return {(startingAbsolute - ambient) + startingAbsolute * relative,
                startingAbsolute / startingVolume * derivative};
    }
    const double logRatio = std::log(endVolume / startingVolume);
    const double normalized = std::expm1((1. - exponent) * logRatio) / ((1. - exponent) * change);
    const double endpoint = std::exp(-exponent * logRatio);
    return {startingAbsolute * normalized - ambient,
            startingAbsolute / startingVolume * ((endpoint - normalized) / change)};
}

} // namespace judas::volume_grid
