#pragma once

#include "CutRegionGeometry.h"

namespace judas::volume_grid {

struct CutLiquidState {
    std::vector<double> water;
    std::vector<double> faceSpeed;
    std::vector<double> pressureHead;
};

struct CutLiquidTrial {
    CutLiquidState state;
    std::vector<double> head;
    std::vector<double> flux;
    int iterations = 0, linearIterations = 0;
    std::size_t donorsLimited = 0;
    double residual = 0., waterDrift = 0., maximumFaceSpeed = 0.;
};

// Wet-only first-step pressure/storage trial. Assumes all dry cut regions vent
// freely. A sealed-gas geometry must use a separate gas-owner pressure law.
bool TrialCutLiquid(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                    const CutLiquidState& state, double dt, int up, double gravity,
                    CutLiquidTrial& result, std::string& error);

} // namespace judas::volume_grid
