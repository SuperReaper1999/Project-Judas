# Level basin fifth-interval merge diagnostic

The pressure/transport trial uses the previous tracked-geometry
experimental source and original 9.25 m³ level basin, 60 Hz cadence,
and stationary original solids. The optional endpoint split policy
stages four intervals. The fifth pressure solve finds an admissible
water transfer and then rejects a merge from four gas owners to three.
No fifth material state is published.

Build and run from this directory:

```sh
c++ -std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror \
  ContinueGas.cpp CutLiquidGas.cpp CutRegionGeometry.cpp CutRegionGasTopology.cpp -o /tmp/judas-gas-merge
/tmp/judas-gas-merge --steps 5 --strict-water-donor --split-at-endpoint > /tmp/judas-gas-merge.log 2>&1
# The basin control deliberately exits with failure at the unmodeled merge.
python3 two_chamber.py /tmp/judas-gas-merge.log
```

The measured contact is between closed owners 2 and 3. Their independently
computed endpoint volumes are 0.2140 and 0.07433 m³ and the pressure jump
is 8.23 kPa. Thirty-two actual dry apertures open with a combined 0.002072 m².
The largest has area 0.0001030 m² and its actual link length is 0.125 m.
The summed aperture area divided by link length is 0.01657 m.

Interpolating the conserved water amounts between the accepted old
state and rejected endpoint trial, while using the same persistent phase
orientations, yields dry apertures that grow approximately linearly.
The first positive interpolation sample is at fraction 1/64, and
the uncoupled adiabatic pressure jump grows from zero to 8.23 kPa.
The interpolated curve is a comparator. It does not supply the actual
trajectory of a coupled pressure and water solve.

The uncoupled inertial integration gives 0.0031913 m³ of gas transfer.
A two-chamber linear acoustic comparator applies that geometry curve
with finite gas storage. If x is transported gas volume and w is
the pressure-driven impulse divided by density, the comparison uses

    x' = sum(A / L) * w
    w' = (uncoupled_pressure_jump - x / C_effective) / rho

The combined differential compliance is 3.0864e-7 m³/Pa. Using endpoint
densities spanning 1.3985 to 1.4634 kg/m³, midpoint integration reaches
0.00228–0.00235 m³ transfer and a residual pressure difference of
608–846 Pa. The 1,024- and 4,096-step integrations agree within 0.006 Pa
for each density. The comparator uses linearized compliance and
fixed prescribed water/volume history. It establishes a finite
pressure difference for this modeled opening, so instant endpoint
pressure averaging would be a separate and unqualified approximation.
Gas momentum, topology splitting in real time, and the native moving
body remain outside this test.
