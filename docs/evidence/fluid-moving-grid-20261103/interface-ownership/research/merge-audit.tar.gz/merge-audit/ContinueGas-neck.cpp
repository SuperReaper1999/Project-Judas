#include "BasinFixture.h"
#include "CutLiquidGas.h"
#include "GasPocketMath.h"

#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <map>
#include <string_view>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

struct Basin {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    CutLiquidState state;
    std::vector<CutRegionInterface> sides;
    std::vector<CutRegionWaterPlane> slabs;
    CutRegionGasTopology graph;
    CutRegionGasVent vent;
    std::vector<double> gasPressure;
    std::vector<double> gasMass;
};

constexpr double ambient = 101325., exponent = 1.4;

bool Build(const Fixture& fixture, Basin& basin, std::string& error) {
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                               {-.005, -.015, -.005}, {.005, .025, .005}, basin.chart, error) ||
        !BuildCutRegionGeometry(basin.chart, {}, basin.geometry, error))
        return false;
    SeedImport seed;
    if (!WaterByRegion(fixture, basin.chart, basin.geometry, fixture.spacing == .20f,
                       basin.state.water, seed, error))
        return false;
    basin.state.faceSpeed.resize(basin.geometry.faces.size());
    basin.sides.resize(basin.chart.regions.size());
    basin.vent = FullCutRegionGasVent(basin.chart, 1, 1);
    if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, basin.state.water, basin.sides,
                                          basin.slabs, error) ||
        !BuildCutRegionGasTopology(basin.chart, basin.geometry, basin.slabs, {basin.vent}, basin.graph, error))
        return false;
    basin.gasPressure.assign(basin.graph.components.size(), ambient);
    basin.gasMass.assign(basin.graph.components.size(), 0.);
    for (std::size_t i = 1; i < basin.graph.components.size(); ++i)
        basin.gasMass[i] = 1.2 * basin.graph.components[i].volume;
    return true;
}

struct FrontierClaim {
    std::size_t owner = NoCutRegionGas;
    double area = 0.;
    CutRegionInterface phase;
    bool contested = false;
};

std::vector<FrontierClaim> ProposeFrontier(const CutRegionGeometry& geometry,
                                         const std::vector<CutRegionWaterPlane>& slabs,
                                         const CutRegionGasTopology& graph) {
    std::vector<FrontierClaim> claims(slabs.size());
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.) continue;
        const auto left = graph.regionOwner[face.left], right = graph.regionOwner[face.right];
        if ((left == NoCutRegionGas) == (right == NoCutRegionGas)) continue;
        const bool intoRight = right == NoCutRegionGas;
        const double area = MeasureCutRegionSharedPhase(face, geometry.motion, slabs[face.left],
                                                         slabs[face.right], !intoRight, intoRight).start;
        if (area == 0.) continue;
        const auto owner = intoRight ? left : right;
        auto& claim = claims[intoRight ? face.right : face.left];
        claim.contested |= claim.owner != NoCutRegionGas && claim.owner != owner;
        if (area > claim.area) {
            claim.owner = owner;
            claim.area = area;
            claim.phase = {face.axis, intoRight};
        }
    }
    return claims;
}

CutRegionGasTopology ExtendFrontier(const CutRegionGasTopology& initial,
                                    const std::vector<FrontierClaim>& claims) {
    auto next = initial;
    for (std::size_t i = 0; i < claims.size(); ++i) {
        const auto& claim = claims[i];
        if (claim.owner == NoCutRegionGas || claim.contested) continue;
        next.regionOwner[i] = claim.owner;
        next.components[claim.owner].regions.push_back(i);
    }
    return next;
}

void AuditPotentialMerge(const CutRegionGeometry& geometry,
                         const CutRegionGasTopology& from, const CutRegionGasTopology& to,
                         const CutRegionGasTopology& pressure, const std::vector<double>& priorPressure,
                         const std::vector<double>& priorMass, double dt) {
    std::vector<long double> dryByParent(from.components.size());
    std::vector<long double> largestArea(from.components.size()), pressureEnd(from.components.size()),
        densityEnd(from.components.size());
    for (std::size_t i = 0; i < to.regionOwner.size(); ++i) {
        const auto old = pressure.regionOwner[i];
        if (old != NoCutRegionGas && to.regionOwner[i] != NoCutRegionGas)
            dryByParent[old] += to.regionVolume[i];
    }
    for (std::size_t i = 1; i < dryByParent.size(); ++i) {
        if (dryByParent[i] > 0.) {
            pressureEnd[i] = priorPressure[i] * std::pow(from.components[i].volume / dryByParent[i], exponent);
            densityEnd[i] = priorMass[i] / dryByParent[i];
        }
    }
    struct Neck {
        std::size_t count = 0, face = 0;
        double largest = 0.;
        long double total = 0., admittance = 0.;
    };
    std::map<std::pair<std::size_t, std::size_t>, Neck> necks;
    for (std::size_t face = 0; face < geometry.faces.size(); ++face) {
        const double area = to.sharedDryArea[face];
        if (area == 0.) continue;
        const auto& aperture = geometry.faces[face];
        const auto a = pressure.regionOwner[aperture.left], b = pressure.regionOwner[aperture.right];
        if (a == b || a == ExteriorCutRegionGas || b == ExteriorCutRegionGas ||
            a == NoCutRegionGas || b == NoCutRegionGas) continue;
        auto& neck = necks[std::minmax(a, b)];
        ++neck.count;
        neck.total += area;
        neck.admittance += area / aperture.length;
        if (area > neck.largest) {
            neck.largest = area;
            neck.face = face;
        }
    }
    for (const auto& [owners, neck] : necks) {
        const auto [a, b] = owners;
        const long double pa = pressureEnd[a], pb = pressureEnd[b];
        const long double ca = dryByParent[a] / (exponent * pa), cb = dryByParent[b] / (exponent * pb);
        const long double compliance = ca * cb / (ca + cb);
        const long double density = std::min(densityEnd[a], densityEnd[b]);
        const long double volumeDrive = dt * dt * neck.admittance * std::abs(pa - pb) / (2. * density);
        const long double equilibration = compliance * std::abs(pa - pb);
        const long double frequency = std::sqrt(neck.admittance / (density * compliance));
        const auto& opening = geometry.faces[neck.face];
        std::cout << "MERGE_NECK parents=" << a << ',' << b << " count=" << neck.count
                  << " max_area_m2=" << neck.largest << " sum_area_m2=" << neck.total
                  << " sum_area_over_length_m=" << neck.admittance << " length_m=" << opening.length
                  << " region_pair=" << opening.left << ',' << opening.right << " axis=" << opening.axis
                  << " parent_volumes_m3=" << dryByParent[a] << ',' << dryByParent[b]
                  << " parent_endpoint_pressure_Pa=" << pa << ',' << pb
                  << " parent_densities_kgm3=" << densityEnd[a] << ',' << densityEnd[b]
                  << " compliance_m3Pa=" << compliance << " dt_omega=" << dt * frequency
                  << " optimistic_inertial_transfer_m3=" << volumeDrive
                  << " equilibration_volume_m3=" << equilibration << '\n';
    }
}

bool PreserveOwners(const CutRegionGasTopology& from, const CutRegionGasTopology& to,
                    const CutRegionGasTopology& pressure, const std::vector<double>& priorPressure,
                    const std::vector<double>& priorMass, const std::vector<double>& meanGauge,
                    bool splitAtEndpoint, std::vector<double>& nextPressure, std::vector<double>& nextMass,
                    std::string& error) {
    std::vector<std::vector<std::size_t>> children(from.components.size());
    std::vector<std::size_t> origin(to.components.size(), NoCutRegionGas);
    double unsupported = 0.;
    bool split = false, merge = false, vented = false;
    for (std::size_t i = 0; i < to.regionOwner.size(); ++i) {
        const auto prev = pressure.regionOwner[i], next = to.regionOwner[i];
        if (next == NoCutRegionGas)
            continue;
        if (prev == NoCutRegionGas) {
            unsupported += to.regionVolume[i];
            continue;
        }
        vented |= (prev == ExteriorCutRegionGas) != (next == ExteriorCutRegionGas);
        if (origin[next] == NoCutRegionGas) {
            split |= !children[prev].empty();
            children[prev].push_back(next);
            origin[next] = prev;
        } else {
            merge |= origin[next] != prev;
        }
    }
    std::cout << "TOPOLOGY previous_components=" << from.components.size() - 1
              << " next_components=" << to.components.size() - 1 << " unsupported=" << unsupported
              << " split=" << split << " merge=" << merge << " vented=" << vented << '\n';
    if ((split && !splitAtEndpoint) || merge || vented || unsupported != 0.) {
        error = "resolved gas lineage change requires conservative transfer";
        return false;
    }
    nextPressure.assign(to.components.size(), ambient);
    nextMass.assign(to.components.size(), 0.);
    for (std::size_t i = 1; i < from.components.size(); ++i) {
        const auto& next = children[i];
        if (next.empty()) {
            error = "previous resolved gas chamber vanished";
            return false;
        }
        const long double v0 = from.components[i].volume;
        long double v1 = 0.;
        for (const auto j : next)
            v1 += to.components[j].volume;
        const long double p0 = priorPressure[i];
        const long double logarithmicVolumeChange = std::log1p((v1 - v0) / v0);
        const long double p1 = p0 * std::exp(-exponent * logarithmicVolumeChange);
        const long double gasEnergyChange = p0 * v0 * std::expm1((1. - exponent) * logarithmicVolumeChange) /
            (exponent - 1.);
        const long double work = -(static_cast<long double>(meanGauge[i]) + ambient) * (v1 - v0);
        const long double residual = work - gasEnergyChange;
        if (!std::isfinite(p1) || std::abs(residual) > 1e-8 * (1. + std::abs(work))) {
            error = "gas endpoint thermodynamic work does not close";
            return false;
        }
        long double assignedMass = 0., childEnergy = 0.;
        for (const auto j : next) {
            const auto volume = to.components[j].volume;
            nextPressure[j] = static_cast<double>(p1);
            nextMass[j] = static_cast<double>(priorMass[i] * (volume / v1));
            assignedMass += nextMass[j];
            childEnergy += static_cast<long double>(nextPressure[j]) * volume / (exponent - 1.);
        }
        const long double massResidual = assignedMass - priorMass[i];
        const long double internalResidual = childEnergy - p1 * v1 / (exponent - 1.);
        if (std::abs(massResidual) > 4. * std::numeric_limits<double>::epsilon() * priorMass[i] ||
            std::abs(internalResidual) > 4. * std::numeric_limits<double>::epsilon() * std::abs(childEnergy)) {
            error = "gas endpoint descendants do not conserve mass and internal energy";
            return false;
        }
        std::cout << "GAS old=" << i << " children=" << next.size() << " v0=" << v0 << " v1=" << v1
                  << " p0=" << p0 << " p1=" << p1 << " mean_gauge=" << meanGauge[i]
                  << " gas_work=" << work << " error_J=" << residual << " mass_error_kg=" << massResidual
                  << " internal_error_J=" << internalResidual << '\n';
    }
    return true;
}

double Total(const std::vector<double>& values) {
    return static_cast<double>(std::accumulate(values.begin(), values.end(), 0.L));
}

} // namespace

int main(int argc, char** argv) {
    int steps = 1;
    double dt = double(tick);
    bool rotated = false, originalAperture = false, strictWaterDonor = false, budgetWater = true, splitAtEndpoint = false;
    for (int i = 1; i < argc; ++i) {
        const std::string_view flag(argv[i]);
        if (flag == "--rotated") rotated = true;
        else if (flag == "--original-aperture") originalAperture = true;
        else if (flag == "--unbudgeted") budgetWater = false;
        else if (flag == "--split-at-endpoint") splitAtEndpoint = true;
        else if (flag == "--strict-water-donor") strictWaterDonor = true;
        else if (flag == "--steps" && i + 1 < argc) steps = std::stoi(argv[++i]);
        else if (flag == "--divisor" && i + 1 < argc) dt /= std::stod(argv[++i]);
        else return 2;
    }
    Basin basin;
    std::string error;
    std::cout << std::setprecision(17);
    if (!Build(Fixture::Authored(rotated), basin, error)) {
        std::cout << "FAIL setup " << error << '\n';
        return 1;
    }
    const double initialWater = Total(basin.state.water);
    std::cout << "BEGIN rotated=" << rotated << " dt=" << dt << " water=" << initialWater
              << " regions=" << basin.chart.regions.size() << " faces=" << basin.geometry.faces.size() << '\n';
    for (int i = 0; i < steps; ++i) {
        const auto claims = ProposeFrontier(basin.geometry, basin.slabs, basin.graph);
        auto pressure = ExtendFrontier(basin.graph, claims);
        CutLiquidTrial trial;
        std::vector<double> meanGauge;
        const auto begin = std::chrono::steady_clock::now();
        if (!TrialCutLiquidGas(basin.chart, basin.geometry, basin.state, dt, 1, double(gravity),
                               &pressure, originalAperture ? nullptr : &basin.slabs, basin.gasPressure,
                               budgetWater, trial, meanGauge, error)) {
            std::cout << "FAIL solve step=" << i << " " << error << '\n';
            return 1;
        }
        const double elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - begin).count();
        std::vector<double> waterOut(basin.chart.regions.size());
        for (std::size_t f = 0; f < trial.flux.size(); ++f) {
            const auto& face = basin.geometry.faces[f];
            const double amount = trial.flux[f];
            waterOut[amount >= 0. ? face.left : face.right] += std::abs(amount);
        }
        double worstDonor = 0.;
        for (std::size_t cell = 0; cell < waterOut.size(); ++cell)
            worstDonor = std::max(worstDonor, waterOut[cell] - basin.state.water[cell]);
        std::cout << "SOLVE step=" << i << " ms=" << elapsed << " iterations=" << trial.iterations << '/'
                  << trial.linearIterations << " residual=" << trial.residual << " water_drift="
                  << Total(trial.state.water) - initialWater << " max_speed=" << trial.maximumFaceSpeed
                  << " donors_limited=" << trial.donorsLimited << " water_donor_excess=" << worstDonor << '\n';
        if (strictWaterDonor && worstDonor > 0.) {
            std::cout << "FAIL local water donor overspend\n";
            return 1;
        }
        auto sides = basin.sides;
        std::vector<CutRegionWaterPlane> slabs;
        CutRegionGasTopology graph;
        for (std::size_t cell = 0; cell < sides.size(); ++cell)
            if (basin.graph.regionOwner[cell] == NoCutRegionGas &&
                trial.state.water[cell] < basin.geometry.startCapacity[cell] && claims[cell].area > 0. &&
                !claims[cell].contested)
                sides[cell] = claims[cell].phase;
        if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, trial.state.water, sides, slabs, error) ||
            !BuildCutRegionGasTopology(basin.chart, basin.geometry, slabs, {basin.vent}, graph, error)) {
            std::cout << "FAIL endpoint geometry step=" << i << " " << error << '\n';
            return 1;
        }
        std::vector<double> gasPressure, gasMass;
        AuditPotentialMerge(basin.geometry, basin.graph, graph, pressure, basin.gasPressure, basin.gasMass, dt);
        if (!PreserveOwners(basin.graph, graph, pressure, basin.gasPressure, basin.gasMass,
                            meanGauge, splitAtEndpoint, gasPressure, gasMass, error)) {
            std::cout << "FAIL endpoint gas step=" << i << " " << error << '\n';
            return 1;
        }
        basin.state = std::move(trial.state);
        basin.slabs = std::move(slabs);
        basin.sides = std::move(sides);
        basin.graph = std::move(graph);
        basin.gasPressure = std::move(gasPressure);
        basin.gasMass = std::move(gasMass);
        std::cout << "STAGE step=" << i << '\n';
    }
}
