#include "BasinFixture.h"
#include "CutLiquidGas.h"
#include "GasPocketMath.h"

#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string_view>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

namespace {

struct Basin {
    CutRegionChart chart;
    CutRegionGeometry geometry;
    CutLiquidState state;
    std::vector<CutRegionInterface> sides;
    std::vector<CutRegionWaterPlane> slabs;
    CutRegionGasTopology graph;
    CutRegionGasVent vent;
    std::vector<double> gasPressure;
};

constexpr double ambient = 101325., exponent = 1.4;

bool Build(const Fixture& fixture, Basin& basin, std::string& error) {
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                               {-.005, -.015, -.005}, {.005, .025, .005}, basin.chart, error) ||
        !BuildCutRegionGeometry(basin.chart, {}, basin.geometry, error))
        return false;
    SeedImport seed;
    if (!WaterByRegion(fixture, basin.chart, basin.geometry, fixture.spacing == .20f,
                       basin.state.water, seed, error))
        return false;
    basin.state.faceSpeed.resize(basin.geometry.faces.size());
    basin.sides.resize(basin.chart.regions.size());
    basin.vent = FullCutRegionGasVent(basin.chart, 1, 1);
    if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, basin.state.water, basin.sides,
                                          basin.slabs, error) ||
        !BuildCutRegionGasTopology(basin.chart, basin.geometry, basin.slabs, {basin.vent}, basin.graph, error))
        return false;
    basin.gasPressure.assign(basin.graph.components.size(), ambient);
    return true;
}

struct FrontierClaim {
    std::size_t owner = NoCutRegionGas;
    double area = 0.;
    CutRegionInterface phase;
    bool contested = false;
};

std::vector<FrontierClaim> ProposeFrontier(const CutRegionGeometry& geometry,
                                         const std::vector<CutRegionWaterPlane>& slabs,
                                         const CutRegionGasTopology& graph) {
    std::vector<FrontierClaim> claims(slabs.size());
    for (const auto& face : geometry.faces) {
        if (face.startArea == 0.) continue;
        const auto left = graph.regionOwner[face.left], right = graph.regionOwner[face.right];
        if ((left == NoCutRegionGas) == (right == NoCutRegionGas)) continue;
        const bool intoRight = right == NoCutRegionGas;
        const double area = MeasureCutRegionSharedPhase(face, geometry.motion, slabs[face.left],
                                                         slabs[face.right], !intoRight, intoRight).start;
        if (area == 0.) continue;
        const auto owner = intoRight ? left : right;
        auto& claim = claims[intoRight ? face.right : face.left];
        claim.contested |= claim.owner != NoCutRegionGas && claim.owner != owner;
        if (area > claim.area) {
            claim.owner = owner;
            claim.area = area;
            claim.phase = {face.axis, intoRight};
        }
    }
    return claims;
}

CutRegionGasTopology ExtendFrontier(const CutRegionGasTopology& initial,
                                    const std::vector<FrontierClaim>& claims) {
    auto next = initial;
    for (std::size_t i = 0; i < claims.size(); ++i) {
        const auto& claim = claims[i];
        if (claim.owner == NoCutRegionGas || claim.contested) continue;
        next.regionOwner[i] = claim.owner;
        next.components[claim.owner].regions.push_back(i);
    }
    return next;
}

bool PreserveOwners(const CutRegionGasTopology& from, const CutRegionGasTopology& to, const CutRegionGasTopology& pressure,
                    const std::vector<double>& priorPressure, const std::vector<double>& meanGauge,
                    std::vector<double>& nextPressure, std::string& error) {
    std::vector<std::size_t> ending(from.components.size(), NoCutRegionGas);
    std::vector<std::size_t> origin(to.components.size(), NoCutRegionGas);
    const auto resolved = [](const CutRegionGasTopology& graph, std::size_t owner) {
        return owner != NoCutRegionGas &&
            graph.components[owner].volume > 0.;
    };
    double unsupported = 0.;
    bool split = false, merge = false, vented = false;
    for (std::size_t i = 0; i < to.regionOwner.size(); ++i) {
        const auto prev = pressure.regionOwner[i], next = to.regionOwner[i];
        if (!resolved(to, next))
            continue;
        if (!resolved(from, prev)) {
            unsupported += to.regionVolume[i];
            continue;
        }
        vented |= (prev == ExteriorCutRegionGas) != (next == ExteriorCutRegionGas);
        split |= ending[prev] != NoCutRegionGas && ending[prev] != next;
        merge |= origin[next] != NoCutRegionGas && origin[next] != prev;
        ending[prev] = next;
        origin[next] = prev;
    }
    std::cout << "TOPOLOGY previous_components=" << from.components.size() - 1
              << " next_components=" << to.components.size() - 1 << " unsupported=" << unsupported
              << " split=" << split << " merge=" << merge << " vented=" << vented << '\n';
    if (split || merge || vented || unsupported != 0.) {
        error = "resolved gas lineage change requires conservative transfer";
        return false;
    }
    nextPressure.assign(to.components.size(), ambient);
    for (std::size_t i = 1; i < from.components.size(); ++i) {
        if (!resolved(from, i))
            continue;
        const auto j = ending[i];
        if (j == NoCutRegionGas) {
            error = "previous resolved gas chamber vanished";
            return false;
        }
        const long double v0 = from.components[i].volume, v1 = to.components[j].volume;
        const long double p0 = priorPressure[i];
        const long double logarithmicVolumeChange = std::log1p((v1 - v0) / v0);
        const long double p1 = p0 * std::exp(-exponent * logarithmicVolumeChange);
        const long double gasEnergyChange = p0 * v0 * std::expm1((1. - exponent) * logarithmicVolumeChange) /
            (exponent - 1.);
        const long double work = -(static_cast<long double>(meanGauge[i]) + ambient) * (v1 - v0);
        const long double residual = work - gasEnergyChange;
        if (!std::isfinite(p1) || std::abs(residual) > 1e-8 * (1. + std::abs(work))) {
            error = "gas endpoint thermodynamic work does not close";
            return false;
        }
        nextPressure[j] = static_cast<double>(p1);
        std::cout << "GAS old=" << i << " new=" << j << " v0=" << v0 << " v1=" << v1
                  << " p0=" << p0 << " p1=" << p1 << " mean_gauge=" << meanGauge[i]
                  << " gas_work=" << work << " error_J=" << residual << '\n';
    }
    return true;
}

double Total(const std::vector<double>& values) {
    return static_cast<double>(std::accumulate(values.begin(), values.end(), 0.L));
}

} // namespace

int main(int argc, char** argv) {
    int steps = 1;
    double dt = double(tick);
    bool rotated = false, originalAperture = false, strictWaterDonor = false, budgetWater = true;
    for (int i = 1; i < argc; ++i) {
        const std::string_view flag(argv[i]);
        if (flag == "--rotated") rotated = true;
        else if (flag == "--original-aperture") originalAperture = true;
        else if (flag == "--unbudgeted") budgetWater = false;
        else if (flag == "--strict-water-donor") strictWaterDonor = true;
        else if (flag == "--steps" && i + 1 < argc) steps = std::stoi(argv[++i]);
        else if (flag == "--divisor" && i + 1 < argc) dt /= std::stod(argv[++i]);
        else return 2;
    }
    Basin basin;
    std::string error;
    std::cout << std::setprecision(17);
    if (!Build(Fixture::Authored(rotated), basin, error)) {
        std::cout << "FAIL setup " << error << '\n';
        return 1;
    }
    const double initialWater = Total(basin.state.water);
    std::cout << "BEGIN rotated=" << rotated << " dt=" << dt << " water=" << initialWater
              << " regions=" << basin.chart.regions.size() << " faces=" << basin.geometry.faces.size() << '\n';
    for (int i = 0; i < steps; ++i) {
        const auto claims = ProposeFrontier(basin.geometry, basin.slabs, basin.graph);
        auto pressure = ExtendFrontier(basin.graph, claims);
        CutLiquidTrial trial;
        std::vector<double> meanGauge;
        const auto begin = std::chrono::steady_clock::now();
        if (!TrialCutLiquidGas(basin.chart, basin.geometry, basin.state, dt, 1, double(gravity),
                               &pressure, originalAperture ? nullptr : &basin.slabs, basin.gasPressure,
                               budgetWater, trial, meanGauge, error)) {
            std::cout << "FAIL solve step=" << i << " " << error << '\n';
            return 1;
        }
        const double elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - begin).count();
        std::vector<double> waterOut(basin.chart.regions.size());
        for (std::size_t f = 0; f < trial.flux.size(); ++f) {
            const auto& face = basin.geometry.faces[f];
            const double amount = trial.flux[f];
            waterOut[amount >= 0. ? face.left : face.right] += std::abs(amount);
        }
        double worstDonor = 0.;
        for (std::size_t cell = 0; cell < waterOut.size(); ++cell)
            worstDonor = std::max(worstDonor, waterOut[cell] - basin.state.water[cell]);
        std::cout << "SOLVE step=" << i << " ms=" << elapsed << " iterations=" << trial.iterations << '/'
                  << trial.linearIterations << " residual=" << trial.residual << " water_drift="
                  << Total(trial.state.water) - initialWater << " max_speed=" << trial.maximumFaceSpeed
                  << " donors_limited=" << trial.donorsLimited << " water_donor_excess=" << worstDonor << '\n';
        if (strictWaterDonor && worstDonor > 0.) {
            std::cout << "FAIL local water donor overspend\n";
            return 1;
        }
        auto sides = basin.sides;
        std::vector<CutRegionWaterPlane> slabs;
        CutRegionGasTopology graph;
        for (std::size_t cell = 0; cell < sides.size(); ++cell)
            if (basin.graph.regionOwner[cell] == NoCutRegionGas &&
                trial.state.water[cell] < basin.geometry.startCapacity[cell] && claims[cell].area > 0. &&
                !claims[cell].contested)
                sides[cell] = claims[cell].phase;
        if (!ReconstructCutRegionWaterPlanes(basin.chart, basin.geometry, 1, trial.state.water, sides, slabs, error) ||
            !BuildCutRegionGasTopology(basin.chart, basin.geometry, slabs, {basin.vent}, graph, error)) {
            std::cout << "FAIL endpoint geometry step=" << i << " " << error << '\n';
            return 1;
        }
        std::vector<double> gasPressure;
        if (!PreserveOwners(basin.graph, graph, pressure, basin.gasPressure, meanGauge, gasPressure, error)) {
            std::cout << "FAIL endpoint gas step=" << i << " " << error << '\n';
            return 1;
        }
        basin.state = std::move(trial.state);
        basin.slabs = std::move(slabs);
        basin.sides = std::move(sides);
        basin.graph = std::move(graph);
        basin.gasPressure = std::move(gasPressure);
        std::cout << "STAGE step=" << i << '\n';
    }
}
