#pragma once

#include "CutLiquid.h"
#include "CutRegionGasTopology.h"

namespace judas::volume_grid {

bool TrialCutLiquidGas(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                       const CutLiquidState& state, double dt, int up, double gravity,
                       const CutRegionGasTopology* topology, const std::vector<CutRegionWaterPlane>* slabs,
                       const std::vector<double>& gasPressure, bool budgetWater, CutLiquidTrial& result,
                       std::vector<double>& meanGauge, std::string& error);

} // namespace judas::volume_grid
