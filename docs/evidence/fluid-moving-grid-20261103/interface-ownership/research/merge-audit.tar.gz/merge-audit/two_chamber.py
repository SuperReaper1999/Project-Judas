#!/usr/bin/env python3
"""Linear acoustic two-chamber comparison driven by interpolated cut apertures."""
import argparse
import math
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("log", type=Path)
args = parser.parse_args()

def values(line):
    return dict(field.split("=", 1) for field in line.split()[1:])

lines = args.log.read_text().splitlines()
neck = values(next(line for line in lines if line.startswith("MERGE_NECK ")))
samples = [values(line) for line in lines if line.startswith("MERGE_INTERPOLATION ")]
samples = [tuple(map(float, (s["fraction"], s["sum_area_over_length"], s["uncoupled_pressure_jump_Pa"])))
           for s in samples]
compliance = float(neck["compliance_m3Pa"])
rho_range = list(map(float, neck["parent_densities_kgm3"].split(",")))
dt = 0.01666666753590107
assert len(samples) == 65
assert samples[0][1] == 0.0 and samples[-1][1] > 0.0

for rho in (*rho_range, sum(rho_range) / len(rho_range)):
    for slices in (1, 4, 16, 64):
        transfer = inertia = 0.0
        for lower, upper in zip(samples, samples[1:]):
            h = dt * (upper[0] - lower[0]) / slices
            for i in range(slices):
                t = (i + 0.5) / slices
                admittance = lower[1] + t * (upper[1] - lower[1])
                prescribed = lower[2] + t * (upper[2] - lower[2])
                a = h * admittance * 0.5
                b = h / (2.0 * rho * compliance)
                # x' = (A/L) * w, w' = (drive - x/C) / rho.
                # Solve the midpoint pair directly on this sampled geometry.
                next_inertia = (inertia * (1.0 - a*b) +
                                h * prescribed / rho - 2.0 * b * transfer) / (1.0 + a*b)
                transfer += a * (inertia + next_inertia)
                inertia = next_inertia
        pressure = samples[-1][2] - transfer / compliance
        assert math.isfinite(pressure)
        print(f"rho={rho:.9f} integration_steps={64*slices} transfer_m3={transfer:.12g} "
              f"remaining_pressure_jump_Pa={pressure:.12g}")
