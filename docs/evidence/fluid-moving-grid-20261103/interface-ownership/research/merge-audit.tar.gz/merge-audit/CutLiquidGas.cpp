#include "CutLiquidGas.h"
#include "GasPocketMath.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <iostream>

namespace judas::volume_grid {
namespace {

struct Storage {
    double lower, upper, solidLower, solidUpper;
    double openSection, solidSection, capacity;

    double Water(double head) const {
        if (head <= lower)
            return 0.;
        if (head >= upper)
            return capacity;
        return openSection * (head - lower) -
            solidSection * std::clamp(head - solidLower, 0., solidUpper - solidLower);
    }

    double Slope(double head) const {
        if (head < lower || head > upper)
            return 0.;
        return openSection - (head > solidLower && head < solidUpper ? solidSection : 0.);
    }
};

Storage MeasureStorage(const CutRegion& region, const std::optional<BoxMotion>& motion,
                       int up, double endCapacity) {
    const int a = (up + 1) % 3, b = (up + 2) % 3;
    const double section = (region.hi[a] - region.lo[a]) * (region.hi[b] - region.lo[b]);
    Storage storage{region.lo[up], region.hi[up], 0., 0., section, 0., endCapacity};
    if (motion) {
        const auto bounds = [&](int axis) {
            const double lo = std::max(region.lo[axis], motion->lo[axis] + motion->translation[axis]);
            const double hi = std::min(region.hi[axis], motion->hi[axis] + motion->translation[axis]);
            return std::pair{lo, std::max(lo, hi)};
        };
        const auto [lo, hi] = bounds(up);
        const auto [alo, ahi] = bounds(a);
        const auto [blo, bhi] = bounds(b);
        storage.solidLower = lo;
        storage.solidUpper = hi;
        storage.solidSection = (ahi - alo) * (bhi - blo);
    }
    return storage;
}

struct Port {
    std::size_t i, left, right;
    double forward, reverse, prediction;
};

double MaxNorm(const std::vector<double>& values) {
    double result = 0.;
    for (double value : values) {
        if (!std::isfinite(value))
            return std::numeric_limits<double>::infinity();
        result = std::max(result, std::abs(value));
    }
    return result;
}

double Dot(const std::vector<double>& a, const std::vector<double>& b) {
    return std::inner_product(a.begin(), a.end(), b.begin(), 0.);
}

struct GasLinearization {
    std::vector<double> shiftedHead, area, headByArea, meanGauge;
};

double ChamberHead(const CutRegionGasComponent& chamber, const std::vector<Storage>& storage,
                   const std::vector<double>& head, double waterPressureScale,
                   double startingAbsolute, double& pressureSlope) {
    constexpr double ambient = 101325.;
    double lower = -ambient / waterPressureScale, upper = 1.;
    double capacity = 0.;
    for (const std::size_t region : chamber.regions) {
        const auto& cell = storage[region];
        lower = std::min(lower, head[region] - cell.upper);
        upper = std::max(upper, head[region] - cell.lower);
        capacity += cell.capacity;
    }
    upper = std::max(upper, MeanGasPressure(chamber.volume, capacity, startingAbsolute, ambient).gauge / waterPressureScale);
    double offset = std::clamp(0., lower, upper);
    GasMeanPressure pressure{};
    for (int iter = 0; iter < 96; ++iter) {
        double volume = 0., area = 0.;
        for (const std::size_t region : chamber.regions) {
            const auto& cell = storage[region];
            const double h = head[region] - offset;
            volume += cell.capacity - cell.Water(h);
            area += cell.Slope(h);
        }
        pressure = MeanGasPressure(chamber.volume, volume, startingAbsolute, ambient);
        const double residual = offset - pressure.gauge / waterPressureScale;
        pressureSlope = pressure.slope / waterPressureScale;
        if (std::abs(residual) < 4e-14 * (1. + std::abs(offset)))
            return offset;
        if (residual > 0.) upper = offset;
        else lower = offset;
        const double correction = residual / (1. - pressureSlope * area);
        const double proposal = offset - correction;
        if (proposal > lower && proposal < upper)
            offset = proposal;
        else {
            const double middle = lower + .5 * (upper - lower);
            if (middle == offset)
                return offset;
            offset = middle;
        }
    }
    return std::numeric_limits<double>::quiet_NaN();
}

struct DonorProjection {
    std::vector<double> flux;
    std::vector<std::vector<std::size_t>> activeOutlets;
    std::vector<double> thresholdWeight;
    std::vector<bool> forward;
    std::size_t limited = 0;
};

void ProjectWaterDonors(const std::vector<Port>& ports, const std::vector<double>& water,
                        const std::vector<double>& head, bool budgetWater,
                        std::vector<double>& weight, DonorProjection& output) {
    output.flux.assign(ports.size(), 0.);
    output.forward.resize(ports.size());
    output.thresholdWeight.assign(water.size(), 0.);
    output.activeOutlets.resize(water.size());
    for (auto& outlets : output.activeOutlets)
        outlets.clear();
    output.limited = 0;

    std::vector<double> drive(ports.size()), outflow(water.size());
    for (std::size_t i = 0; i < ports.size(); ++i) {
        const auto& port = ports[i];
        const double difference = head[port.left] - head[port.right] + port.prediction;
        output.forward[i] = difference > 0. || (difference == 0. && port.forward >= port.reverse);
        const auto source = output.forward[i] ? port.left : port.right;
        weight[i] = output.forward[i] ? port.forward : port.reverse;
        drive[i] = std::abs(difference);
        output.flux[i] = weight[i] * difference;
        if (budgetWater && weight[i] > 0. && drive[i] > 0.) {
            outflow[source] += std::abs(output.flux[i]);
            output.activeOutlets[source].push_back(i);
        }
    }
    if (!budgetWater)
        return;
    for (std::size_t source = 0; source < water.size(); ++source) {
        auto& outlets = output.activeOutlets[source];
        if (!(outflow[source] > water[source])) {
            outlets.clear();
            continue;
        }
        ++output.limited;
        std::sort(outlets.begin(), outlets.end(), [&](std::size_t a, std::size_t b) {
            return drive[a] > drive[b] || (drive[a] == drive[b] && a < b);
        });
        // Express all differences relative to the largest drive. A nearly
        // exhausted donor need not subtract two large, nearly equal heads.
        const double pivot = drive[outlets.front()];
        long double totalWeight = 0., moment = 0., headLoss = 0.;
        std::size_t use = 0;
        for (const auto outlet : outlets) {
            const double offset = drive[outlet] - pivot;
            if (use && offset <= headLoss)
                break;
            totalWeight += weight[outlet];
            moment += static_cast<long double>(weight[outlet]) * offset;
            headLoss = (moment - water[source]) / totalWeight;
            ++use;
        }
        double remaining = water[source];
        for (std::size_t j = 0; j < outlets.size(); ++j) {
            const auto outlet = outlets[j];
            if (j >= use) {
                output.flux[outlet] = weight[outlet] = 0.;
                continue;
            }
            const long double offset = drive[outlet] - pivot;
            const double amount = std::clamp(static_cast<double>(weight[outlet] * (offset - headLoss)),
                                             0., remaining);
            remaining -= amount;
            output.flux[outlet] = output.forward[outlet] ? amount : -amount;
        }
        outlets.resize(use);
        std::sort(outlets.begin(), outlets.end());
        double accumulated = 0.;
        for (const auto outlet : outlets) {
            // Enforce the budget in shared-face publication order as well.
            // Rounding a set of exact weighted amounts independently can
            // otherwise report an outflow one ulp above the old inventory.
            double amount = std::min(std::abs(output.flux[outlet]), water[source] - accumulated);
            if (accumulated + amount > water[source])
                amount = std::nextafter(amount, 0.);
            accumulated += amount;
            output.flux[outlet] = output.forward[outlet] ? amount : -amount;
        }
        output.thresholdWeight[source] = static_cast<double>(totalWeight);
    }
}

double Evaluate(const std::vector<Storage>& storage, const std::vector<Port>& ports,
                const std::vector<double>& startingWater, const std::vector<double>& head,
                std::vector<double>& residual, std::vector<double>& weight,
                const CutRegionGasTopology* topology, const std::vector<double>& gasPressure,
                double pressureScale, GasLinearization& gas, bool budgetWater, DonorProjection& donors) {
    gas.shiftedHead = head;
    gas.area.resize(head.size());
    if (topology) {
        gas.headByArea.assign(topology->components.size(), 0.);
        gas.meanGauge.assign(topology->components.size(), 0.);
        for (std::size_t i = 1; i < topology->components.size(); ++i) {
            const auto& chamber = topology->components[i];
            if (chamber.volume == 0.)
                continue;
            double slope = 0.;
            const double offset = ChamberHead(chamber, storage, head, pressureScale, gasPressure[i], slope);
            if (!std::isfinite(offset) || !(slope < 0.))
                return std::numeric_limits<double>::infinity();
            double area = 0.;
            for (const auto region : chamber.regions) {
                gas.shiftedHead[region] -= offset;
                area += storage[region].Slope(gas.shiftedHead[region]);
            }
            gas.headByArea[i] = 1. / (area - 1. / slope);
            gas.meanGauge[i] = offset * pressureScale;
        }
    }
    for (std::size_t i = 0; i < head.size(); ++i)
        gas.area[i] = storage[i].Slope(gas.shiftedHead[i]);
    for (std::size_t i = 0; i < head.size(); ++i)
        residual[i] = storage[i].Water(gas.shiftedHead[i]) - startingWater[i];
    ProjectWaterDonors(ports, startingWater, head, budgetWater, weight, donors);
    for (std::size_t i = 0; i < ports.size(); ++i) {
        const auto& port = ports[i];
        const double flux = donors.flux[i];
        residual[port.left] += flux;
        residual[port.right] -= flux;
    }
    return MaxNorm(residual);
}

struct Incident {
    std::size_t other;
    double forward, reverse, offset;
};

struct PortDrive {
    double drive, weight;
    std::size_t target;
};

class BudgetCoordinates {
public:
    BudgetCoordinates(const std::vector<Storage>& storage,
                      const std::vector<std::vector<Incident>>& incident,
                      const std::vector<double>& water)
        : storage_(storage), incident_(incident), water_(water) {}

    void Update(std::size_t node, double gasHead, std::vector<double>& head) {
        const double original = head[node];
        const double r0 = Residual(node, gasHead, head);
        if (r0 == 0. || !std::isfinite(r0))
            return;
        double low = original, high = original;
        double span = storage_[node].upper - storage_[node].lower;
        bool bracketed = false;
        for (int i = 0; i < 24; ++i) {
            head[node] = original + (r0 < 0. ? span : -span);
            const double r = Residual(node, gasHead, head);
            if ((r >= 0.) == (r0 < 0.)) {
                if (r0 < 0.) high = head[node];
                else low = head[node];
                bracketed = true;
                break;
            }
            span *= 2.;
        }
        if (!bracketed) {
            head[node] = original;
            return;
        }
        for (int i = 0; i < 48; ++i) {
            const double middle = low + .5 * (high - low);
            if (middle == low || middle == high)
                break;
            head[node] = middle;
            const double r = Residual(node, gasHead, head);
            if (r > 0.) high = middle;
            else if (r < 0.) low = middle;
            else return;
        }
        head[node] = low + .5 * (high - low);
    }

private:
    double Outgoing(std::size_t source, std::size_t receiver, const std::vector<double>& head) {
        if (water_[source] == 0.)
            return 0.;
        double preferred = 0., wanted = 0.;
        candidates_.clear();
        for (const auto& port : incident_[source]) {
            const double drive = head[source] - head[port.other] + port.offset;
            if (!(port.forward > 0. && drive > 0.))
                continue;
            const double q = drive * port.forward;
            preferred += q;
            if (receiver == port.other) wanted += q;
            candidates_.push_back({drive, port.forward, port.other});
        }
        if (receiver == NoCutRegionGas)
            return std::min(preferred, water_[source]);
        if (preferred <= water_[source] || wanted == 0.)
            return wanted;
        std::sort(candidates_.begin(), candidates_.end(), [](const PortDrive& a, const PortDrive& b) {
            return a.drive > b.drive;
        });
        const double pivot = candidates_.front().drive;
        long double weight = 0., moment = 0., shift = 0.;
        std::size_t active = 0;
        for (const auto& c : candidates_) {
            const double offset = c.drive - pivot;
            if (active && offset <= shift)
                break;
            weight += c.weight;
            moment += static_cast<long double>(c.weight) * offset;
            shift = (moment - water_[source]) / weight;
            ++active;
        }
        wanted = 0.;
        for (std::size_t j = 0; j < active; ++j) {
            const auto& c = candidates_[j];
            if (c.target == receiver)
                wanted += static_cast<double>(c.weight * ((c.drive - pivot) - shift));
        }
        return wanted;
    }

    double Residual(std::size_t i, double gasHead, const std::vector<double>& head) {
        double balance = storage_[i].Water(head[i] - gasHead) - water_[i];
        balance += Outgoing(i, NoCutRegionGas, head);
        neighbors_.clear();
        for (const auto& port : incident_[i])
            if (port.reverse > 0. && head[port.other] - head[i] - port.offset > 0.)
                neighbors_.push_back(port.other);
        std::sort(neighbors_.begin(), neighbors_.end());
        neighbors_.erase(std::unique(neighbors_.begin(), neighbors_.end()), neighbors_.end());
        for (const auto j : neighbors_)
            balance -= Outgoing(j, i, head);
        return balance;
    }

    const std::vector<Storage>& storage_;
    const std::vector<std::vector<Incident>>& incident_;
    const std::vector<double>& water_;
    std::vector<PortDrive> candidates_;
    std::vector<std::size_t> neighbors_;
};

void SmoothComplementarity(const std::vector<Storage>& storage,
                           const std::vector<std::vector<Incident>>& incident,
                           const std::vector<bool>& boundary, const std::vector<double>& water,
                           std::vector<double>& head) {
    std::vector<double> knots;
    for (std::size_t i = 0; i < head.size(); ++i) {
        if (!boundary[i] || incident[i].empty())
            continue;
        const auto& cell = storage[i];
        knots.assign({cell.lower, cell.upper, cell.solidLower, cell.solidUpper});
        for (const auto& port : incident[i])
            knots.push_back(head[port.other] - port.offset);
        std::sort(knots.begin(), knots.end());
        const auto residual = [&](double h) {
            double r = cell.Water(h) - water[i];
            for (const auto& port : incident[i]) {
                const double difference = h - head[port.other] + port.offset;
                r += difference * (difference > 0. ? port.forward : port.reverse);
            }
            return r;
        };
        double left = knots.front(), lowerResidual = residual(left);
        if (lowerResidual >= 0.) {
            if (lowerResidual == 0.) {
                head[i] = std::min(head[i], left);
            } else {
                double slope = 0.;
                for (const auto& port : incident[i]) slope += port.reverse;
                if (slope > 0.) head[i] = left - lowerResidual / slope;
            }
            continue;
        }
        bool solved = false;
        for (const double right : knots) {
            if (right == left)
                continue;
            const double upperResidual = residual(right);
            if (upperResidual >= 0.) {
                head[i] = left + (right - left) * (-lowerResidual / (upperResidual - lowerResidual));
                solved = true;
                break;
            }
            left = right;
            lowerResidual = upperResidual;
        }
        if (!solved) {
            double slope = 0.;
            for (const auto& port : incident[i]) slope += port.forward;
            if (slope > 0.) head[i] = left - lowerResidual / slope;
        }
    }
}

double ObjectiveChange(const std::vector<Storage>& storage, const std::vector<Port>& ports,
                       const std::vector<double>& water, const std::vector<double>& head,
                       const std::vector<double>& trial) {
    long double sum = 0.;
    for (std::size_t i = 0; i < storage.size(); ++i) {
        const double lo = std::min(head[i], trial[i]);
        const double hi = std::max(head[i], trial[i]);
        if (lo == hi)
            continue;
        const auto& s = storage[i];
        std::array<double, 6> knots{lo, hi, std::clamp(s.lower, lo, hi),
            std::clamp(s.upper, lo, hi), std::clamp(s.solidLower, lo, hi),
            std::clamp(s.solidUpper, lo, hi)};
        std::sort(knots.begin(), knots.end());
        const double sign = trial[i] > head[i] ? 1. : -1.;
        for (std::size_t k = 1; k < knots.size(); ++k) {
            const double x = knots[k - 1], y = knots[k];
            if (x != y)
                sum += sign * (y - x) * .5 * (s.Water(x) - water[i] + s.Water(y) - water[i]);
        }
    }
    for (const auto& port : ports) {
        const double before = head[port.left] - head[port.right] + port.prediction;
        const double after = trial[port.left] - trial[port.right] + port.prediction;
        if ((before >= 0.) == (after >= 0.)) {
            sum += .5 * (after >= 0. ? port.forward : port.reverse) *
                (after - before) * (after + before);
        } else {
            const auto work = [&](double x) { return .5 * (x >= 0. ? port.forward : port.reverse) * x * x; };
            sum += work(after) - work(before);
        }
    }
    return static_cast<double>(sum);
}

bool SolveDirection(const std::vector<Storage>& storage, const std::vector<Port>& ports,
                    const std::vector<double>& weight, const std::vector<double>& head,
                    const std::vector<double>& startingWater, const std::vector<double>& residual,
                    const std::vector<bool>& boundary, const CutRegionGasTopology* topology,
                    const GasLinearization& gas, const DonorProjection& donors, bool budgetWater, double trust, double tolerance,
                    std::vector<double>& correction, int& steps) {
    const std::size_t count = head.size();
    struct Link { std::size_t a, b; double conductance; };
    std::vector<Link> links;
    links.reserve(ports.size());
    std::vector<bool> limitedPort(ports.size());
    for (std::size_t source = 0; source < count; ++source) {
        const auto& active = donors.activeOutlets[source];
        for (const auto i : active)
            limitedPort[i] = true;
        // Eliminate the donor multiplier analytically. Its supported
        // outflow is constant, so only recipient differences enter J.
        for (std::size_t i = 0; i < active.size(); ++i) {
            const auto a = active[i];
            const auto x = donors.forward[a] ? ports[a].right : ports[a].left;
            for (std::size_t j = i + 1; j < active.size(); ++j) {
                const auto b = active[j];
                const auto y = donors.forward[b] ? ports[b].right : ports[b].left;
                if (x != y)
                    links.push_back({x, y, (weight[a] / donors.thresholdWeight[source]) * weight[b]});
            }
        }
    }
    for (std::size_t i = 0; i < ports.size(); ++i)
        if (!limitedPort[i] && weight[i] > 0.)
            links.push_back({ports[i].left, ports[i].right, weight[i]});

    std::vector<double> local(count), diagonal(count), direction(count), product(count), r(count);
    for (std::size_t i = 0; i < count; ++i) {
        local[i] = gas.area[i] +
            ((budgetWater || boundary[i]) && storage[i].capacity > 0. ? trust * storage[i].openSection : 0.);
        diagonal[i] = local[i];
        if (topology) {
            const auto owner = topology->regionOwner[i];
            if (owner != NoCutRegionGas && owner != 0)
                diagonal[i] -= gas.headByArea[owner] * gas.area[i] * gas.area[i];
        }
    }
    for (const auto& link : links) {
        diagonal[link.a] += link.conductance;
        diagonal[link.b] += link.conductance;
    }
    correction.assign(count, 0.);
    for (std::size_t i = 0; i < count; ++i) {
        r[i] = -residual[i];
        if (diagonal[i] == 0. && std::abs(r[i]) > tolerance) {
            // A dry one-sided port can deactivate after an overshoot while
            // its storage is clamped. The current derivative is then zero
            // despite a valid segment in the direction of decreasing
            // storage error. Use a secant to that segment.
            const auto& cell = storage[i];
            if (!(startingWater[i] <= cell.capacity) || cell.capacity == 0.)
                return false;
            double low = cell.lower, high = cell.upper;
            if (startingWater[i] == 0.) high = low;
            for (int iteration = 0; iteration < 54; ++iteration) {
                const double middle = low + (high - low) * .5;
                if (cell.Water(middle) < startingWater[i]) low = middle;
                else high = middle;
            }
            const double distance = low + (high - low) * .5 - head[i];
            if (!(r[i] * distance > 0.))
                return false;
            local[i] = diagonal[i] = r[i] / distance;
        }
        if (diagonal[i] > 0.)
            direction[i] = r[i] / diagonal[i];
    }
    double energy = Dot(r, direction);
    for (int iteration = 0; iteration < 2048 && MaxNorm(r) > tolerance; ++iteration) {
        ++steps;
        for (std::size_t i = 0; i < count; ++i)
            product[i] = local[i] * direction[i];
        if (topology) {
            for (std::size_t i = 1; i < topology->components.size(); ++i) {
                double common = 0.;
                for (const auto region : topology->components[i].regions)
                    common += gas.area[region] * direction[region];
                common *= gas.headByArea[i];
                for (const auto region : topology->components[i].regions)
                    product[region] -= gas.area[region] * common;
            }
        }
        for (const auto& link : links) {
            const double impulse = link.conductance * (direction[link.a] - direction[link.b]);
            product[link.a] += impulse;
            product[link.b] -= impulse;
        }
        const double denominator = Dot(direction, product);
        if (!(denominator > 0.) || !std::isfinite(denominator))
            return false;
        const double alpha = energy / denominator;
        double nextEnergy = 0.;
        for (std::size_t i = 0; i < count; ++i) {
            correction[i] += alpha * direction[i];
            r[i] -= alpha * product[i];
            if (diagonal[i] > 0.)
                nextEnergy += r[i] * (r[i] / diagonal[i]);
        }
        for (std::size_t i = 0; i < count; ++i)
            direction[i] = diagonal[i] == 0. ? 0. :
                r[i] / diagonal[i] + (nextEnergy / energy) * direction[i];
        energy = nextEnergy;
    }
    if (MaxNorm(r) > tolerance)
        std::cerr << "LINEAR norm=" << MaxNorm(r) << " tolerance=" << tolerance << " iterations=" << steps << '\n';
    return MaxNorm(r) <= tolerance;
}

} // namespace

bool TrialCutLiquidGas(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                    const CutLiquidState& state, double dt, int up, double gravity,
                       const CutRegionGasTopology* topology, const std::vector<CutRegionWaterPlane>* slabs,
                       const std::vector<double>& gasPressure, bool budgetWater, CutLiquidTrial& result,
                       std::vector<double>& meanGauge, std::string& error) {
    if (!(dt > 0.) || !(gravity > 0.) || up < 0 || up > 2 ||
        state.water.size() != chart.regions.size() || state.faceSpeed.size() != geometry.faces.size() ||
        geometry.endCapacity.size() != state.water.size() ||
        (slabs && slabs->size() != state.water.size()) ||
        (topology && gasPressure.size() != topology->components.size())) {
        error = "invalid cut liquid dimensions, timestep or gravity";
        return false;
    }
    CutLiquidTrial next;
    if (!ReconstructCutRegionWaterPlanes(chart, geometry, up, state.water, next.head, error))
        return false;
    const std::size_t count = chart.regions.size();
    const std::size_t faceCount = geometry.faces.size();
    std::vector<Storage> storage;
    std::vector<Port> ports;
    std::vector<std::size_t> parent(count);
    std::iota(parent.begin(), parent.end(), 0);
    const auto root = [&](std::size_t i) {
        while (i != parent[i]) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    };
    storage.reserve(count);
    ports.reserve(faceCount);
    for (std::size_t i = 0; i < count; ++i)
        storage.push_back(MeasureStorage(chart.regions[i], geometry.motion, up, geometry.endCapacity[i]));
    for (std::size_t i = 0; i < faceCount; ++i) {
        const auto& f = geometry.faces[i];
        if (f.meanArea == 0.)
            continue;
        double forward = 0., reverse = 0.;
        if (slabs) {
            const auto aperture = MeasureCutRegionFacePhase(f, geometry.motion,
                                                             (*slabs)[f.left], (*slabs)[f.right]);
            forward = aperture.wet[0].mean;
            reverse = aperture.wet[1].mean;
        } else {
            const auto aperture = MeasureCutRegionFacePhase(f, geometry.motion, up, next.head[f.left], next.head[f.right]);
            forward = aperture.wet[0].mean;
            reverse = aperture.wet[1].mean;
        }
        if (state.water[f.left] == 0.) forward = 0.;
        if (state.water[f.right] == 0.) reverse = 0.;
        if (forward > 0. || reverse > 0.) {
            const double scale = dt * dt * gravity / f.length;
            const double prediction = state.faceSpeed[i] * f.length / (dt * gravity);
            ports.push_back({i, f.left, f.right, scale * forward, scale * reverse, prediction});
            if (forward > 0. && reverse > 0.)
                parent[root(f.left)] = root(f.right);
        }
    }
    std::vector<double> maximumPlane(count, -std::numeric_limits<double>::infinity());
    for (std::size_t i = 0; i < count; ++i)
        maximumPlane[root(i)] = std::max(maximumPlane[root(i)], next.head[i]);
    for (std::size_t i = 0; i < count; ++i)
        if (state.water[i] > 0. && state.water[i] == geometry.startCapacity[i])
            next.head[i] = maximumPlane[root(i)];
    std::vector<std::vector<Incident>> incident(count);
    std::vector<bool> boundary(count);
    for (const auto& port : ports) {
        incident[port.left].push_back({port.right, port.forward, port.reverse, port.prediction});
        incident[port.right].push_back({port.left, port.reverse, port.forward, -port.prediction});
        if (port.forward == 0. || port.reverse == 0.) {
            boundary[port.left] = true;
            boundary[port.right] = true;
        }
    }
    for (std::size_t i = 0; i < count; ++i)
        if (storage[i].capacity < 1e-4 * chart.layout.h * chart.layout.h * chart.layout.h)
            boundary[i] = true;
    if (budgetWater) {
        CutLiquidTrial initial;
        std::vector<double> initialGas;
        std::string initialError;
        if (TrialCutLiquidGas(chart, geometry, state, dt, up, gravity, topology, slabs,
                              gasPressure, false, initial, initialGas, initialError))
            next.head = std::move(initial.head);
    }
    BudgetCoordinates coordinate(storage, incident, state.water);
    std::vector<double> residual(count), weight(ports.size()), trialHead(count);
    std::vector<double> trialResidual(count), trialWeight(ports.size()), correction;
    const double cellVolume = chart.layout.h * chart.layout.h * chart.layout.h;
    const double tolerance = 1e-12 * cellVolume;
    GasLinearization gas, trialGas;
    DonorProjection donors, trialDonors;
    const double pressureScale = 1000. * gravity;
    double norm = Evaluate(storage, ports, state.water, next.head, residual, weight, topology, gasPressure, pressureScale, gas, budgetWater, donors);
    if (state.pressureHead.size() == count) {
        const double previousNorm = Evaluate(storage, ports, state.water, state.pressureHead,
                                             trialResidual, trialWeight, topology, gasPressure, pressureScale,
                                             trialGas, budgetWater, trialDonors);
        if (previousNorm < norm) {
            norm = previousNorm;
            next.head = state.pressureHead;
            residual.swap(trialResidual);
            weight.swap(trialWeight);
            std::swap(gas, trialGas);
            std::swap(donors, trialDonors);
        }
    }
    while (norm > tolerance && next.iterations < 80) {
        ++next.iterations;
        if (topology)
            for (std::size_t i = 0; i < count; ++i) {
                const auto owner = topology->regionOwner[i];
                if (owner != NoCutRegionGas && owner != 0)
                    boundary[i] = false;
            }
        auto smooth = boundary;
        if (budgetWater)
            for (std::size_t source = 0; source < count; ++source) {
                if (donors.thresholdWeight[source] == 0.)
                    continue;
                smooth[source] = false;
                for (const auto i : donors.activeOutlets[source])
                    smooth[donors.forward[i] ? ports[i].right : ports[i].left] = false;
            }
        if (!budgetWater) {
            SmoothComplementarity(storage, incident, smooth, state.water, next.head);
        } else {
            for (std::size_t i = 0; i < count; ++i) {
                if (!incident[i].empty() && std::abs(residual[i]) > norm * .125)
                    coordinate.Update(i, next.head[i] - gas.shiftedHead[i], next.head);
            }
        }
        norm = Evaluate(storage, ports, state.water, next.head, residual, weight, topology, gasPressure, pressureScale, gas, budgetWater, donors);
        if (norm <= tolerance)
            break;
        bool accepted = false;
        const std::array<double, 6> trustOptions = budgetWater
            ? std::array<double, 6>{0., 1e-7, 1e-5, .001, .1, 10.}
            : std::array<double, 6>{0., 1e-5, 1e-3, .01, .1, 1.};
        for (const double trust : trustOptions) {
            if (!SolveDirection(storage, ports, weight, next.head, state.water, residual, boundary,
                                topology, gas, donors, budgetWater, trust, std::max(tolerance * .05, norm * .01), correction, next.linearIterations))
                continue;
            const double slope = Dot(residual, correction);
            if (!(slope < 0.))
                continue;
            for (double alpha = 1.; alpha >= std::ldexp(1., budgetWater ? -25 : -11); alpha *= .5) {
                for (std::size_t i = 0; i < count; ++i)
                    trialHead[i] = next.head[i] + alpha * correction[i];
                const double nextNorm = Evaluate(storage, ports, state.water, trialHead, trialResidual, trialWeight, topology, gasPressure, pressureScale, trialGas, budgetWater, trialDonors);
                const bool descent = topology ? ((!budgetWater && nextNorm < norm) || Dot(trialResidual, correction) <= 0.) :
                    ObjectiveChange(storage, ports, state.water, next.head, trialHead) <= .0001 * alpha * slope;
                if (std::isfinite(nextNorm) && (nextNorm <= tolerance || descent)) {
                    next.head.swap(trialHead);
                    residual.swap(trialResidual);
                    weight.swap(trialWeight);
                    std::swap(gas, trialGas);
                    std::swap(donors, trialDonors);
                    norm = nextNorm;
                    accepted = true;
                    break;
                }
            }
            if (accepted) break;
        }
        if (!accepted) {
            std::cerr << "stalled norm=" << norm << " nonlinear=" << next.iterations << " linear=" << next.linearIterations << '\n';
            error = "wet storage pressure search cannot reduce physical balance";
            return false;
        }
    }
    if (!(norm <= tolerance)) {
        const auto worst = std::max_element(residual.begin(), residual.end(), [](double a, double b) {
            return std::abs(a) < std::abs(b);
        });
        const auto idx = static_cast<std::size_t>(worst - residual.begin());
        std::cerr << "limit norm=" << norm << " nonlinear=" << next.iterations << " linear=" << next.linearIterations
            << " idx=" << idx << " r=" << *worst << " cap=" << storage[idx].capacity
            << " water=" << state.water[idx] << " head=" << next.head[idx] << " shifted=" << gas.shiftedHead[idx]
            << " active_area=" << gas.area[idx] << " limits=" << donors.limited
            << " owner=" << (topology ? topology->regionOwner[idx] : NoCutRegionGas) << '\n';
        error = "wet storage pressure exceeded nonlinear work limit";
        return false;
    }
    next.residual = norm;
    next.donorsLimited = donors.limited;
    next.flux.resize(faceCount);
    next.state.faceSpeed.resize(faceCount);
    next.state.water.resize(count);
    next.state.pressureHead = next.head;
    long double waterDrift = 0.;
    for (std::size_t i = 0; i < count; ++i) {
        next.state.water[i] = storage[i].Water(gas.shiftedHead[i]);
        waterDrift += static_cast<long double>(next.state.water[i]) - state.water[i];
    }
    for (std::size_t i = 0; i < ports.size(); ++i) {
        const auto& port = ports[i];
        next.flux[port.i] = donors.flux[i];
        const auto& face = geometry.faces[port.i];
        if (weight[i] > 0.) {
            next.state.faceSpeed[port.i] = (dt * gravity / face.length) * (donors.flux[i] / weight[i]);
            next.maximumFaceSpeed = std::max(next.maximumFaceSpeed, std::abs(next.state.faceSpeed[port.i]));
        }
    }
    next.waterDrift = static_cast<double>(waterDrift);
    meanGauge = std::move(gas.meanGauge);
    result = std::move(next);
    error.clear();
    return true;
}

} // namespace judas::volume_grid
