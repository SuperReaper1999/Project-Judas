#include "VentTopology.h"

#include <algorithm>
#include <cmath>
#include <numeric>

namespace judas::volume_grid {
namespace {

bool Fail(std::string& error, const char* message) {
    error = message;
    return false;
}

bool ValidVent(const CutRegionChart& chart, const VentBoundary& vent) {
    if (vent.axis < 0 || vent.axis > 2 || (vent.sign != -1 && vent.sign != 1))
        return false;
    for (int axis = 0; axis < 3; ++axis) {
        const double chartEnd = chart.layout.cells[axis] * chart.layout.h;
        if (axis == vent.axis) {
            const double side = vent.sign > 0 ? chartEnd : 0.;
            if (vent.lo[axis] != side || vent.hi[axis] != side)
                return false;
        } else if (!(0. <= vent.lo[axis] && vent.lo[axis] < vent.hi[axis] && vent.hi[axis] <= chartEnd)) {
            return false;
        }
    }
    return true;
}

bool OverlappingVents(const VentBoundary& a, const VentBoundary& b) {
    if (a.axis != b.axis || a.sign != b.sign)
        return false;
    for (int d = 0; d < 3; ++d)
        if (d != a.axis && std::min(a.hi[d], b.hi[d]) <= std::max(a.lo[d], b.lo[d]))
            return false;
    return true;
}

bool SplitDryComplement(const GridVec& lo, const GridVec& hi, const BoxMotion& solid) {
    for (int d = 0; d < 3; ++d) {
        const int a = (d + 1) % 3, b = (d + 2) % 3;
        if (lo[d] < solid.lo[d] && solid.hi[d] < hi[d] &&
            solid.lo[a] <= lo[a] && hi[a] <= solid.hi[a] &&
            solid.lo[b] <= lo[b] && hi[b] <= solid.hi[b])
            return true;
    }
    return false;
}

double SharedDryArea(const CutRegionFace& face, const std::optional<BoxMotion>& solid,
                     int up, double leftPlane, double rightPlane) {
    if (face.axis == up)
        return face.lo[up] > leftPlane && face.lo[up] >= rightPlane ? face.startArea : 0.;
    const double plane = std::max(leftPlane, rightPlane);
    if (plane <= face.lo[up])
        return face.startArea;
    if (plane >= face.hi[up])
        return 0.;
    auto lo = face.lo;
    lo[up] = plane;
    return MeasureCutRegionAperture(face, solid, lo, face.hi).start;
}

double BoundaryDryArea(const CutRegion& region, const std::optional<BoxMotion>& solid,
                       const VentBoundary& vent, int up, double plane) {
    const int normal = vent.axis;
    const double boundary = vent.lo[normal];
    const double side = vent.sign > 0 ? region.hi[normal] : region.lo[normal];
    if (side != boundary)
        return 0.;
    if (normal == up && (boundary < plane || (vent.sign > 0 && boundary == plane)))
        return 0.;
    CutRegionFace face{};
    face.axis = normal;
    for (int d = 0; d < 3; ++d) {
        if (d == normal) {
            face.lo[d] = face.hi[d] = boundary;
        } else {
            face.lo[d] = std::max(region.lo[d], vent.lo[d]);
            face.hi[d] = std::min(region.hi[d], vent.hi[d]);
        }
    }
    if (up != normal)
        face.lo[up] = std::max(face.lo[up], plane);
    return MeasureCutRegionAperture(face, solid, face.lo, face.hi).start;
}

class DryGraph {
public:
    explicit DryGraph(std::size_t count) : parents_(count), rank_(count) {
        std::iota(parents_.begin(), parents_.end(), 0);
    }

    std::size_t Root(std::size_t node) {
        while (parents_[node] != node) {
            parents_[node] = parents_[parents_[node]];
            node = parents_[node];
        }
        return node;
    }

    void Join(std::size_t a, std::size_t b) {
        a = Root(a);
        b = Root(b);
        if (a == b)
            return;
        if (rank_[a] < rank_[b])
            std::swap(a, b);
        parents_[b] = a;
        if (rank_[a] == rank_[b])
            ++rank_[a];
    }

private:
    std::vector<std::size_t> parents_;
    std::vector<unsigned char> rank_;
};

} // namespace

VentBoundary FullChartVent(const CutRegionChart& chart, int axis, int sign) {
    if (axis < 0 || axis > 2 || (sign != -1 && sign != 1))
        return {};
    VentBoundary vent{axis, sign};
    for (int d = 0; d < 3; ++d)
        vent.hi[d] = chart.layout.cells[d] * chart.layout.h;
    if (sign < 0)
        vent.hi[axis] = 0.;
    else
        vent.lo[axis] = vent.hi[axis];
    return vent;
}

bool BuildVentTopology(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                       int up, const std::vector<double>& water, const std::vector<VentBoundary>& vents,
                       VentTopology& output, std::string& error) {
    const auto count = chart.regions.size();
    if (count == 0 || geometry.startCapacity.size() != count || water.size() != count ||
        geometry.faces.size() != chart.faces.size() || up < 0 || up > 2)
        return Fail(error, "invalid dry chart, phase or volume dimensions");
    for (std::size_t i = 0; i < vents.size(); ++i) {
        if (!ValidVent(chart, vents[i]))
            return Fail(error, "dry vent is not a valid outward chart rectangle");
        for (std::size_t j = 0; j < i; ++j)
            if (OverlappingVents(vents[i], vents[j]))
                return Fail(error, "dry vent rectangles overlap");
    }

    VentTopology next;
    if (!ReconstructCutRegionWaterPlanes(chart, geometry, up, water, next.waterPlane, error))
        return false;
    next.regionComponent.assign(count, NoDryComponent);
    next.regionVolume.resize(count);
    next.boundaryDryArea.resize(count);
    next.sharedDryArea.resize(geometry.faces.size());
    std::vector<double> unresolved(count);
    for (std::size_t i = 0; i < count; ++i) {
        const auto& region = chart.regions[i];
        auto dryLo = region.lo;
        dryLo[up] = next.waterPlane[i];
        const double volume = std::max(0., geometry.startCapacity[i] - water[i]);
        const double geometric = CutRegionClippedVolume(region, geometry.motion, dryLo, region.hi);
        if (!std::isfinite(geometric))
            return Fail(error, "dry region volume is nonfinite");
        const double mismatch = std::abs(volume - geometric);
        next.maximumDryVolumeError = std::max(next.maximumDryVolumeError, mismatch);
        const int a = (up + 1) % 3, b = (up + 2) % 3;
        const double section = (region.hi[a] - region.lo[a]) * (region.hi[b] - region.lo[b]);
        const double heightUlp = std::nextafter(dryLo[up], std::numeric_limits<double>::infinity()) - dryLo[up];
        const double representationError = 2. * heightUlp * section +
            128. * std::numeric_limits<double>::epsilon() * geometry.startCapacity[i];
        if (!(mismatch <= representationError))
            return Fail(error, "dry geometry and phase inventory disagree beyond coordinate precision");
        if (volume == 0.)
            continue;
        next.regionVolume[i] = volume;
        if (geometric == 0.) {
            unresolved[i] = volume;
            continue;
        }
        if (geometry.motion && SplitDryComplement(dryLo, region.hi, *geometry.motion))
            return Fail(error, "moving solid divides the dry part of a control volume");
        for (const auto& vent : vents)
            next.boundaryDryArea[i] += BoundaryDryArea(region, geometry.motion, vent, up, next.waterPlane[i]);
    }

    DryGraph graph(count + 1);
    const auto exterior = count;
    for (std::size_t i = 0; i < count; ++i)
        if (next.boundaryDryArea[i] > 0.)
            graph.Join(i, exterior);
    for (std::size_t i = 0; i < geometry.faces.size(); ++i) {
        const auto& face = geometry.faces[i];
        if (face.left >= count || face.right >= count || face.left == face.right || face.axis < 0 ||
            face.axis > 2 || !(face.startArea >= 0.) || !std::isfinite(face.startArea))
            return Fail(error, "invalid dry shared aperture");
        if (face.startArea == 0. || next.regionVolume[face.left] == 0. || next.regionVolume[face.right] == 0. ||
            unresolved[face.left] > 0. || unresolved[face.right] > 0.)
            continue;
        const double area = SharedDryArea(face, geometry.motion, up, next.waterPlane[face.left],
                                         next.waterPlane[face.right]);
        next.sharedDryArea[i] = area;
        if (area > 0.)
            graph.Join(face.left, face.right);
    }

    std::vector<std::size_t> componentForRoot(count + 1, NoDryComponent);
    componentForRoot[graph.Root(exterior)] = ExteriorDryComponent;
    std::vector<long double> totals(1), unresolvedTotals(1);
    next.components.emplace_back();
    for (std::size_t i = 0; i < count; ++i) {
        if (next.regionVolume[i] == 0.)
            continue;
        auto& component = componentForRoot[graph.Root(i)];
        if (component == NoDryComponent) {
            component = next.components.size();
            next.components.emplace_back();
            totals.push_back(0.);
            unresolvedTotals.push_back(0.);
        }
        next.regionComponent[i] = component;
        next.components[component].regions.push_back(i);
        totals[component] += next.regionVolume[i];
        unresolvedTotals[component] += unresolved[i];
    }
    for (std::size_t i = 0; i < next.components.size(); ++i) {
        next.components[i].volume = static_cast<double>(totals[i]);
        next.components[i].unresolvedVolume = static_cast<double>(unresolvedTotals[i]);
    }
    output = std::move(next);
    error.clear();
    return true;
}

} // namespace judas::volume_grid
