#pragma once

#include "CutRegionGeometry.h"

#include <limits>

namespace judas::volume_grid {

constexpr std::size_t ExteriorDryComponent = 0;
constexpr std::size_t NoDryComponent = std::numeric_limits<std::size_t>::max();

// A rectangle on an explicitly vented exterior side of the chart.
struct VentBoundary {
    int axis = -1, sign = 0;
    GridVec lo{}, hi{};
};

struct DryComponent {
    double volume = 0.;
    // Inventory whose dry interval is below the chart's coordinate precision.
    // A component with volume == unresolvedVolume has no pressure aperture.
    double unresolvedVolume = 0.;
    std::vector<std::size_t> regions;
};

struct VentTopology {
    std::vector<double> waterPlane;
    std::vector<std::size_t> regionComponent;
    std::vector<double> regionVolume;
    std::vector<double> sharedDryArea;
    std::vector<double> boundaryDryArea;
    // Index zero is the exterior reservoir, including every dry region with
    // a real path to a declared vent. Closed components follow in region order.
    std::vector<DryComponent> components;
    double maximumDryVolumeError = 0.;
};

VentBoundary FullChartVent(const CutRegionChart& chart, int axis, int sign);

// Builds the start-of-step dry graph. Areas refer to actual shared dry
// apertures, never to a pressure interpolation or a mean over motion time.
// Declared vents must be disjoint rectangles on the chart boundary. A split
// dry complement that cannot be represented by one region owner is rejected.
bool BuildVentTopology(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                       int upAxis, const std::vector<double>& water,
                       const std::vector<VentBoundary>& vents, VentTopology& output,
                       std::string& error);

} // namespace judas::volume_grid
