#include "CutRegionGasTopology.h"
#include "VentTopology.h"
#include "BasinFixture.h"
#include <iomanip>
#include <iostream>
#include <numeric>
#include <queue>

using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;

int main() {
    std::cout << std::setprecision(17);
    for (bool rotated : {false, true}) {
        const auto fixture = Fixture::Authored(rotated);
        CutRegionChart chart;
        CutRegionGeometry geometry;
        SeedImport seed;
        std::vector<double> water;
        std::vector<CutRegionWaterPlane> planes;
        CutRegionGasTopology gas;
        std::string error;
        if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
                                   {-.005, -.015, -.005}, {.005, .025, .005}, chart, error) ||
            !BuildCutRegionGeometry(chart, {}, geometry, error) ||
            !WaterByRegion(fixture, chart, geometry, rotated, water, seed, error) ||
            !ReconstructCutRegionWaterPlanes(chart, geometry, 1, water, {}, planes, error) ||
            !BuildCutRegionGasTopology(chart, geometry, planes, {FullCutRegionGasVent(chart, 1, 1)}, gas, error)) {
            std::cout << "FAIL rotated=" << rotated << " " << error << '\n';
            return 1;
        }
        double largest = 0., maxCellError = 0.;
        std::size_t largestRegions = 0;
        for (std::size_t i = 1; i < gas.components.size(); ++i) {
            const auto& pocket = gas.components[i];
            if (pocket.volume > largest) {
                largest = pocket.volume;
                largestRegions = pocket.regions.size();
            }
        }
        for (std::size_t i = 0; i < water.size(); ++i)
            maxCellError = std::max(maxCellError, std::abs(gas.regionVolume[i] -
                (geometry.startCapacity[i] - water[i])));
        const auto total = [](const std::vector<double>& x) {
            return std::accumulate(x.begin(), x.end(), 0.L);
        };
        const auto closure = total(water) + total(gas.regionVolume) - total(geometry.startCapacity);
        std::cout << "BASIN rotated=" << rotated << " wet_m3=" << total(water)
                  << " gas_m3=" << total(gas.regionVolume) << " closed=" << gas.components.size() - 1
                  << " largest_m3=" << largest << " largest_regions=" << largestRegions
                  << " exterior_m3=" << gas.components[0].volume << " max_cell_error_m3=" << maxCellError
                  << " total_closure_m3=" << closure << '\n';
        VentTopology previous;
        if (!BuildVentTopology(chart, geometry, 1, water, {FullChartVent(chart, 1, 1)}, previous, error))
            return 1;
        const auto pocket = std::max_element(previous.components.begin() + 1, previous.components.end(),
             [](const DryComponent& a, const DryComponent& b) { return a.volume < b.volume; });
        const auto first = pocket->regions.front();
        std::cout << "PREVIOUS largest_m3=" << pocket->volume << " tracked_owner=" << gas.regionOwner[first] << '\n';
        if (!rotated) continue;
        const auto count = chart.regions.size();
        std::vector<std::vector<std::pair<std::size_t, std::size_t>>> links(count);
        for (std::size_t i = 0; i < geometry.faces.size(); ++i) {
            if (gas.sharedDryArea[i] == 0.) continue;
            const auto& f = geometry.faces[i];
            links[f.left].push_back({f.right, i});
            links[f.right].push_back({f.left, i});
        }
        std::priority_queue<std::pair<double, std::size_t>> frontier;
        auto bottleneck = gas.ventArea;
        std::vector<std::size_t> parent(count, count), connection(count, geometry.faces.size());
        for (std::size_t i = 0; i < count; ++i)
            if (bottleneck[i] > 0.) frontier.emplace(bottleneck[i], i);
        while (!frontier.empty()) {
            const auto [width, index] = frontier.top();
            frontier.pop();
            if (width != bottleneck[index]) continue;
            for (const auto& [next, face] : links[index]) {
                const double candidate = std::min(width, gas.sharedDryArea[face]);
                if (candidate <= bottleneck[next]) continue;
                bottleneck[next] = candidate;
                parent[next] = index;
                connection[next] = face;
                frontier.emplace(candidate, next);
            }
        }
        std::cout << "WIDEST pocket_bottleneck_area_m2=" << bottleneck[first] << '\n';
        std::size_t tiny = 0;
        for (std::size_t i = first; parent[i] != count; i = parent[i]) {
            const auto area = gas.sharedDryArea[connection[i]];
            if (area > 1e-10) continue;
            const auto print = [&](std::size_t region) {
                const auto& box = chart.regions[region];
                const auto& phase = planes[region];
                std::cout << " region=" << region << " lo=(" << box.lo[0] << ',' << box.lo[1] << ',' << box.lo[2]
                          << ") hi=(" << box.hi[0] << ',' << box.hi[1] << ',' << box.hi[2] << ")"
                          << " dry_m3=" << gas.regionVolume[region] << " interface=" << phase.coordinate
                          << " remainder=" << phase.remainder;
            };
            std::cout << "THROAT area_m2=" << area;
            print(i);
            print(parent[i]);
            std::cout << '\n';
            ++tiny;
        }
        std::cout << "WIDEST tiny_throats=" << tiny << '\n';
    }
}
