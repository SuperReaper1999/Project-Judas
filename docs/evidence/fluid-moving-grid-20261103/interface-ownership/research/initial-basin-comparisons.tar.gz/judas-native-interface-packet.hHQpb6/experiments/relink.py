import shlex
import subprocess
import sys
from pathlib import Path

d=Path(__file__).resolve().parent
build=Path('.cache/2d-stage1-build').resolve()
target=build / 'CMakeFiles/judas_production_fluid_tests.dir'
case=sys.argv[1]
source=d/'src'/sys.argv[2]
obj=d/'out'/f'{case}-CutRegionStep.o'
flags=[]
for line in (target / 'flags.make').read_text().splitlines():
    key, _, value=line.partition(" = ")
    if key in {"CXX_DEFINES", "CXX_INCLUDES", "CXX_FLAGS"}:
        flags.extend(shlex.split(value))
flags += ['-Werror', '-I'+str(d/'src'), '-I'+str(d/'native')]
link=[arg for arg in shlex.split((target/'link.txt').read_text()) if not arg.startswith('-Wl,--dependency-file=')]
subprocess.run([link[0], *flags, '-c', str(source), '-o', str(obj)], cwd=build, check=True)
idx=next(i for i, arg in enumerate(link) if arg.endswith("ProductionFluidTests.cpp.o"))
objects=sorted(p for p in (d/'out').glob('baseline-*.o') if not p.name.endswith('-CutRegionStep.o'))
link[idx:idx+1]=[str(p) for p in objects] + [str(obj)]
link[link.index('-o')+1]=str(d/'out'/case)
subprocess.run(link, cwd=build, check=True)
