#include "CutRegionGeometry.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <string>

using namespace judas::volume_grid;
#include "characteristic-fragment.cpp"

int main() {
    CutRegionFace fromX{}, fromY{}, toX{}, toY{}, toZ{};
    fromX.axis = toX.axis = 0;
    fromY.axis = toY.axis = 1;
    toZ.axis = 2;
    AffineCell straight;
    straight.width = {1., 1., 1.};
    straight.lowerVelocity = {2., 0., 0.};
    straight.upperVelocity = straight.lowerVelocity;
    AffineCell elbow;
    elbow.width = straight.width;
    elbow.lowerVelocity = {2., 0., 0.};
    elbow.upperVelocity = {0., 2., 0.};
    AffineCell split;
    split.width = straight.width;
    split.lowerVelocity = {1., 1., 0.};
    split.upperVelocity = {0., 0., 2.};
    const double phi = 1. + std::exp(-2.);
    bool good = true;
    const auto check = [&](const char* label, double got, double expected) {
        std::cout.precision(17);
        std::cout << label << " got=" << got << " expected=" << expected
                  << " abs_error=" << std::abs(got - expected) << '\n';
        good &= std::abs(got - expected) <= 2e-14;
    };
    check("straight", AffineTransfer(straight, fromX, toX, false, 2., 2., 1.), 1.);
    check("later-inlet", AffineTransfer(straight, fromX, toX, false, 2., 2., .75), .5);
    check("too-late", AffineTransfer(straight, fromX, toX, false, 2., 2., .49), 0.);
    check("orthogonal", AffineTransfer(elbow, fromX, toY, false, 2., 2., 1.), phi);
    check("two-inlets-x", AffineTransfer(split, fromX, toZ, false, 1., 2., 1.), phi/2.);
    check("two-inlets-y", AffineTransfer(split, fromY, toZ, false, 1., 2., 1.), phi/2.);
    return good ? 0 : 1;
}
