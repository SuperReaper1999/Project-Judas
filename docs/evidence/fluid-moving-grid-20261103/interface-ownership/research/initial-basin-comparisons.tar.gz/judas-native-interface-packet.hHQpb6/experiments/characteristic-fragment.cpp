struct AffineCell {
    std::array<double, 3> width{}, lowerVelocity{}, upperVelocity{};
    std::array<unsigned, 6> seen{};
    bool valid = true;

    double Growth(int axis) const {
        return (upperVelocity[axis] - lowerVelocity[axis]) / width[axis];
    }
    double SideInlet(int axis, bool upper) const {
        const double speed = upper ? -upperVelocity[axis] : lowerVelocity[axis];
        return std::max(0., speed) / width[axis];
    }
    double Inlet(int axis) const { return SideInlet(axis, false) + SideInlet(axis, true); }
};

double FillTime(double rate, double growth) {
    if (rate <= 0. || growth <= -rate)
        return std::numeric_limits<double>::infinity();
    return growth == 0. ? 1. / rate : std::log1p(growth / rate) / growth;
}

double FilledFraction(double rate, double growth, double time) {
    if (rate == 0.)
        return 0.;
    const double fraction = growth == 0. ? rate * time : rate * (std::expm1(growth * time) / growth);
    return std::clamp(fraction, 0., 1.);
}

long double ExponentialMoment(unsigned power, long double exponent) {
    if (std::abs(exponent) < 1.5L) {
        long double term = 1., sum = 1.L / (power + 1);
        for (unsigned order = 1; order < 32; ++order) {
            term *= exponent / order;
            sum += term / (power + order + 1);
        }
        return sum;
    }
    const long double endpoint = std::exp(exponent);
    long double moment = std::expm1(exponent) / exponent;
    for (unsigned order = 1; order <= power; ++order)
        moment = (endpoint - order * moment) / exponent;
    return moment;
}

long double TravelMoment(unsigned power, long double rate, long double limit,
                         long double available) {
    const long double exponent = rate * limit;
    return std::pow(limit, power + 1) *
        (available * ExponentialMoment(power, exponent) -
         limit * ExponentialMoment(power + 1, exponent));
}

double AffineTransfer(const AffineCell& cell, const CutRegionFace& entry, const CutRegionFace& exit,
                      bool enteredFromUpper, double inVolume, double outVolume, double duration) {
    const int n = exit.axis;
    const double normal = FillTime(cell.Inlet(n), cell.Growth(n));
    if (entry.axis == n) {
        if (!(normal < duration))
            return 0.;
        double fraction = duration - normal;
        for (int axis = 0; axis < 3; ++axis)
            if (axis != n)
                fraction *= 1. - FilledFraction(cell.Inlet(axis), cell.Growth(axis), normal);
        return std::min(inVolume, outVolume * fraction);
    }
    const int a = entry.axis, b = 3 - n - a;
    const double rateA = cell.SideInlet(a, enteredFromUpper), rateB = cell.Inlet(b);
    const double growthA = cell.Growth(a), growthB = cell.Growth(b);
    const double limit = std::min({duration, normal, FillTime(cell.Inlet(a), growthA),
                                   FillTime(rateB, growthB)});
    if (rateA == 0. || limit <= 0.)
        return 0.;
    long double volume = TravelMoment(0, growthA, limit, duration);
    if (rateB > 0.) {
        long double overlap;
        if (std::abs(growthB * limit) < 1e-5) {
            overlap = TravelMoment(1, growthA, limit, duration) +
                .5L * growthB * TravelMoment(2, growthA, limit, duration) +
                (growthB * growthB / 6.L) * TravelMoment(3, growthA, limit, duration);
        } else {
            overlap = (TravelMoment(0, growthA + growthB, limit, duration) - volume) / growthB;
        }
        volume -= rateB * overlap;
    }
    const double transfer = outVolume * rateA * static_cast<double>(volume);
    return std::clamp(transfer, 0., std::min(inVolume, outVolume));
}

