struct MaterialPort {
    std::array<double, 2> budget{}, share{};
};

struct MaterialVolume {
    double total = 0., water = 0., slope = 0., primitive = 0.;
};

MaterialVolume EvaluateMaterial(double raw, double conductance, const MaterialPort& port) {
    MaterialVolume r;
    const double direction = std::signbit(raw) ? -1. : 1.;
    for (int phase = 0; phase < 2; ++phase) {
        const double budget = port.budget[phase], share = port.share[phase];
        if (budget == 0. || share == 0.)
            continue;
        const double x = std::abs(raw) * share / budget;
        const double magnitude = std::hypot(1., x);
        const double flow = direction * budget * (x / magnitude);
        if (phase == 0) r.water = flow;
        r.total += flow;
        r.slope += conductance * share / magnitude / magnitude / magnitude;
        r.primitive += (budget / (conductance * share)) * budget * (x * (x / (1. + magnitude)));
    }
    return r;
}

bool ProjectInventoryPressure(const CutRegionChart& chart, const CutRegionGeometry& geometry,
                              const CutRegionState& state,
                              const std::vector<CutRegionPressureFace>& links,
                              const std::vector<std::size_t>& faces,
                              const std::vector<CutRegionFacePhase>& trace,
                              double tolerance, double cellVolume, CutRegionPressure& output,
                              std::vector<double>& waterFlow, std::string& error) {
    const auto count = chart.regions.size();
    std::vector<std::array<double, 2>> area(count);
    for (std::size_t i = 0; i < links.size(); ++i) {
        const auto& f = geometry.faces[faces[i]];
        for (int side = 0; side < 2; ++side) {
            const std::size_t donor = side == 0 ? f.left : f.right;
            area[donor][0] += trace[i].wet[side].start;
            area[donor][1] += trace[i].dry[side].start;
        }
    }
    std::vector<std::array<MaterialPort, 2>> ports(links.size());
    for (std::size_t i = 0; i < links.size(); ++i) {
        const auto& f = geometry.faces[faces[i]];
        for (int side = 0; side < 2; ++side) {
            const std::size_t donor = side == 0 ? f.left : f.right;
            const double volume = state.water[donor], capacity = geometry.startCapacity[donor];
            const std::array<double,2> inventory{volume, capacity - volume};
            const std::array<double,2> opening{trace[i].wet[side].start,trace[i].dry[side].start};
            for (int phase=0;phase<2;++phase) {
                if (opening[phase] > 0. && inventory[phase] > 0.) {
                    ports[i][side].budget[phase] = inventory[phase] * (opening[phase] / area[donor][phase]);
                    ports[i][side].share[phase] = opening[phase] / f.startArea;
                }
            }
        }
    }
    std::vector<double> pressure(count), testPressure(count), residual(count);
    std::vector<CutRegionPressureFace> linear = links;
    const auto measure = [&](const std::vector<double>& p, bool update, double& energy) {
        std::fill(residual.begin(), residual.end(), 0.);
        energy = 0.;
        for (std::size_t i = 0; i < links.size(); ++i) {
            const auto& f = links[i];
            const double raw = f.predictedVolume + f.conductance * (p[f.left] - p[f.right]);
            const auto volume = EvaluateMaterial(raw, f.conductance, ports[i][raw >= 0. ? 0 : 1]);
            residual[f.left] -= volume.total;
            residual[f.right] += volume.total;
            energy += volume.primitive;
            if (update) {
                linear[i].predictedVolume = volume.total;
                // A direction with a phase-inventory kink can have zero
                // conductance. The finite line search retains the actual law.
                linear[i].conductance = std::max(volume.slope, 1e-8 * f.conductance);
            }
        }
        return MaxAbs(residual);
    };
    const auto actualTolerance = std::max(tolerance, 1e-16);
    double energy;
    double imbalance = measure(pressure, true, energy);
    int solveCount = 0, iteration = 0;
    while (imbalance > actualTolerance && iteration < 24) {
        CutRegionPressure direction;
        if (!ProjectCutRegionPressure(std::vector<double>(count), linear, cellVolume,
                                      actualTolerance, direction, error)) {
            error = "inventory pressure linearization: " + error;
            return false;
        }
        solveCount += direction.iterations;
        double gradient = std::inner_product(residual.begin(), residual.end(), direction.pressure.begin(), 0.);
        bool success = false;
        for (double alpha = 1.; alpha >= 1. / 512.; alpha *= .5) {
            for (std::size_t i = 0; i < count; ++i)
                testPressure[i] = pressure[i] + alpha * direction.pressure[i];
            double nextEnergy;
            const double trial = measure(testPressure, false, nextEnergy);
            if (trial <= actualTolerance || nextEnergy <= energy - 1e-4 * alpha * gradient) {
                pressure.swap(testPressure);
                imbalance = measure(pressure, true, energy);
                success = true;
                break;
            }
        }
        ++iteration;
        std::cerr << "INVENTORY step=" << iteration << " imbalance_m3=" << imbalance
                  << " potential=" << energy << " gradient=" << gradient << '\n';
        if (!success) {
            error = "inventory pressure line search failed";
            return false;
        }
    }
    if (!(imbalance <= actualTolerance)) {
        error = "inventory pressure iteration budget exhausted";
        return false;
    }
    output.pressure = std::move(pressure);
    output.iterations = solveCount;
    output.maximumBalanceError = imbalance;
    waterFlow.resize(links.size());
    output.volumeFlux.resize(links.size());
    output.pressureJump.resize(links.size());
    for (std::size_t i = 0; i < links.size(); ++i) {
        const auto& f = links[i];
        const double delta = output.pressure[f.left] - output.pressure[f.right];
        const double raw = f.predictedVolume + f.conductance * delta;
        const auto volume = EvaluateMaterial(raw, f.conductance, ports[i][raw >= 0. ? 0 : 1]);
        output.volumeFlux[i] = volume.total;
        waterFlow[i] = volume.water;
        output.pressureJump[i] = delta;
        output.pressureWork += delta * volume.total;
        output.pressureCorrectionEnergy += .5 * delta * (volume.total - f.predictedVolume);
    }
    return true;
}

