double SlitResistance(const CutRegionChart& chart, const CutRegionFace& f,
                      const CutRegionFacePhase& phase) {
    const int axis = f.axis;
    const auto& left = chart.regions[f.left];
    const auto& right = chart.regions[f.right];
    const double begin = f.lo[axis] - .5 * (left.hi[axis] - left.lo[axis]);
    const double end = f.hi[axis] + .5 * (right.hi[axis] - right.lo[axis]);
    const double wet = .5 * (phase.wet[0].mean + phase.wet[1].mean) / f.meanArea;
    const double dynamicViscosity = 1.81e-5 + (1.00e-3 - 1.81e-5) * wet;
    double resistance = 0.;
    for (int t = 0; t < 3; ++t) {
        if (t == axis)
            continue;
        const int s = 3 - axis - t;
        const double gap = f.hi[t] - f.lo[t];
        // Leading parallel-plate model only where the actual wall-bounded
        // passage is shallow. Computational faces do not count as walls.
        if (!(gap > 0. && 10. * gap <= f.hi[s] - f.lo[s]))
            continue;
        for (const auto& lower : chart.stationary) {
            if (lower.hi[t] != f.lo[t] || lower.lo[s] > f.lo[s] || lower.hi[s] < f.hi[s])
                continue;
            for (const auto& upper : chart.stationary) {
                if (upper.lo[t] != f.hi[t] || upper.lo[s] > f.lo[s] || upper.hi[s] < f.hi[s])
                    continue;
                const double lowerBound = std::max({begin, lower.lo[axis], upper.lo[axis]});
                const double upperBound = std::min({end, lower.hi[axis], upper.hi[axis]});
                if (lowerBound < upperBound)
                    resistance = std::max(resistance, 12. * dynamicViscosity * (upperBound - lowerBound) /
                                                        (gap * gap));
            }
        }
    }
    return f.meanArea * resistance;
}

