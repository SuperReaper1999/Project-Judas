#!/usr/bin/env bash
set -euo pipefail
d=$(cd "$(dirname "$0")" && pwd)
exe=$1
shift
sources=()
for s in CutRegionGeometry CutRegionStep CutRegionPressure CutRegionPhase CutRegionMomentum MovingVolumeGrid GridPhaseFluxRepair GridConservativeRemap GridHalfCellGeometry GridGeometricMomentum HalfDualVolumeMomentum MovingVolumeMomentum; do
    sources+=(--source "$d/src/$s.cpp")
done
python3 "$d/native/build.py" --repo "$PWD" --output "$d/out/$exe" --source "$d/native/BasinSharedStep.cpp" "${sources[@]}" "$@"
