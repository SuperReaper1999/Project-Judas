# Exact native basin interface and pressure alternatives

These controls retain the authored level and rotated basin, exact cut chart,
original water inventory, actual MK2 fixed steps and walls. The rotated case
uses the existing conservative seed import documented by the shared-cut
checkpoint. Existing production gates are outside these scratch controls.

## Shared interface continuation

The comparison baseline is `508bf41e3f9dca1fe2b0ba664275db2573dbe3ee`. Level dry
completes all four MK2 substeps. Exact level and rotated wet warmup and direct
proposals reject the phase inventory before publication.

An intermediate compensated-coordinate reconstruction gave a purely dry
region a false wet plane at the first free slab, when the moving body occupied
lower slabs. The first dry reaction remained the same. A later substep saw
a large spurious wet-pressure contribution and requested a displacement
outside the actual geometry envelope. The pure dry shortcut places the plane
at the proper region boundary for either orientation, so future solid motion
cannot expose phantom water. Rebuilding the final source snapshot restored
all four real MK2 substeps. All 13 pressure proposal rows, final vertical
velocity and maximum impulse discrepancy are byte-identical to the baseline.
All four wet exact outputs also match byte for byte. The final native binary
identity and source hashes are included.

## Scratch alternatives

The affine characteristic relay assumes a stationary rectangular free
region with at most one nonzero opening on each side, each covering the
entire physical side. Its velocity component varies linearly between the
two face-normal speeds on that axis. The area-weighted first-entry
characteristics for opposite and orthogonal faces give explicit finite
transit support. The independent straight, elbow and two-inlet controls
agree within 2.22e-16 m³. The projection and all phase gates are held
constant. The affine relay eliminates every independent local initial
overfill in the level fixture (60→0 warmup, 204→0 direct), and removes
many rotated local failures (66→17 warmup, 126→24 direct). The global
phase flow still has no feasible split. Its unmet level phase supply is
1.56510e-6 m³ in warmup and 9.37069e-8 m³ in the native direct proposal.
A further diagnostic permits sub-cell-throughput transit in otherwise
ordinary donors only if the same geometric path gives positive phase
support. All wet original cases still reject.

The parallel-plate trial applies an implicit laminar resistance only
where two stationary walls physically bound the passage across a face
tangent, accounting for the actual overlapping channel length along the
normal pressure link. The retained aperture is exact. The trial uses
the leading shallow parallel-plate resistance 12 μ length / gap² for
ambient air/water and measures positive fluid dissipation. This is a
model for actual narrow channels rather than arbitrary computational
slivers. It affects 244 level and 458 rotated physical faces. Original
wet failures remain, and some open/sliver face speeds still exceed
5.47/6.80 km/s during the level/rotated warmup. These are projection
speeds from the incompressible mixed model and remain unpublished.

Transactional fluid subdivision holds the original outer 1/60 s
warmup interval and updates the actual material state at each accepted
inner step. The level fixture admits the first two inner intervals at
both 64 and 256 subdivisions, then rejects without committing the
outer state. The rotated fixture rejects the first inner step even at
256 subdivisions. Reducing only the global step size does not resolve
the physical routing issue.

The last stationary diagnostic places separate wet/air donor-volume
limits in the pressure operator itself. Geometric start phase support
distributes exact phase stocks over physically open ports. Each phase
transfer is a monotone saturating function of the common pressure drop.
The projection uses a dual line search and audits the same constituent
ledger. This model deliberately introduces explicit inventory capacity
resistance, so it is an architecture probe separate from physical
parallel-plate drag. The first linearization does not converge within the
existing pressure work budget on either authored basin. A second candidate
uses a more conservative linearized Hessian and line search. The approximate
Hessian leaves the nonlinear flux law unchanged. It reaches 48 iterations
but still has 3.58e-5 m³ level and 3.75e-5 m³ rotated volume imbalance and
commits no state. The capped constitutive law therefore remains unqualified.

## Reproduce

Run from the Judas checkout root against the already-built native
production fluid target. `--build` selects a compatible GNU Make Release
build tree. Exact reproduction compiles the current authoritative MK2
source files and snapshots the prototype source against the chosen mode.

```sh
bash path/to/packet/reproduce.sh baseline
bash path/to/packet/reproduce.sh interface
bash path/to/packet/reproduce.sh affine
bash path/to/packet/reproduce.sh affine-causal
bash path/to/packet/reproduce.sh plates
bash path/to/packet/reproduce.sh substeps
bash path/to/packet/reproduce.sh inventory
```

The wet rejections are expected. Each experiment source and raw result is
preserved. The diagnostic pressure law, drag and alternate transport
aren't included in the current tracked solver.
