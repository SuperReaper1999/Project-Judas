#!/usr/bin/env bash
set -u
d=$(cd "$(dirname "$0")" && pwd)
exe=$1
run(){
  local key=$1 code=0; shift
  "$d/out/$exe" "$@" >"$d/out/$exe-$key.log" 2>&1 || code=$?
  printf '%s %s %s\n' "$exe" "$key" "$code"
  tail -1 "$d/out/$exe-$key.log"
}
run level
run rotated --rotated --conservative-seed
run level-direct --warmup 0
run rotated-direct --rotated --conservative-seed --warmup 0
run level-dry --dry-control --warmup 0
