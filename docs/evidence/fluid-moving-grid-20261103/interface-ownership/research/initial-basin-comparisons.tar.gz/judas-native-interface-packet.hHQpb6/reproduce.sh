#!/usr/bin/env bash
set -euo pipefail
packet=$(cd "$(dirname "$0")" && pwd)
root=$PWD
mode=${1:?choose baseline, interface, affine, affine-causal, plates, substeps, inventory, or inventory-trust}
shift
d=$(mktemp -d /tmp/judas-native-interface-replay.XXXXXX)
mkdir "$d"/{native,src,out}
git archive 508bf41e tools/prototypes/fluid_volume_grid | tar -x -C "$d/src" --strip-components=3
cp "$packet/native/"* "$d/native/"
cp "$packet"/{rebuild.sh,run.sh} "$d/"
case "$mode" in
    baseline) ;;
    interface) cp "$packet"/interface-source/* "$d/src/" ;;
    affine|affine-causal)
        step=$mode
        [[ "$step" != affine ]] || step=affine-port
        cp "$packet/experiments/CutRegionStep.$step.cpp" "$d/src/CutRegionStep.cpp"
        cp "$packet/experiments/GridPhaseFluxRepair.network-diag.cpp" "$d/src/GridPhaseFluxRepair.cpp"
        ;;
    plates)
        cp "$packet/experiments/CutRegionStep.plates.cpp" "$d/src/CutRegionStep.cpp"
        sed -i '/std::optional<BoxMotion> moving;/a\    std::vector<BoxMotion> stationary;' "$d/src/CutRegionGeometry.h"
        sed -i '/chart.moving = moving;/a\    chart.stationary = stationary;' "$d/src/CutRegionGeometry.cpp"
        ;;
    substeps) cp "$packet/experiments/BasinSharedStep.substeps.cpp" "$d/native/BasinSharedStep.cpp" ;;
    inventory|inventory-trust) cp "$packet/experiments/CutRegionStep.$mode.cpp" "$d/src/CutRegionStep.cpp" ;;
    *) exit 2 ;;
esac
bash "$d/rebuild.sh" "$mode" --exact "$@"
if [[ "$mode" == substeps ]]; then
    for n in 16 64 256; do
        "$d/out/$mode" --subdivisions "$n" --warmup 1 --steps 0 >"$d/out/$mode-level-$n.log" 2>&1 || :
        "$d/out/$mode" --rotated --conservative-seed --subdivisions "$n" --warmup 1 --steps 0 >"$d/out/$mode-rotated-$n.log" 2>&1 || :
    done
elif [[ "$mode" == inventory || "$mode" == inventory-trust ]]; then
    "$d/out/$mode" --warmup 1 --steps 0 >"$d/out/$mode-level.log" 2>&1 || :
    "$d/out/$mode" --rotated --conservative-seed --warmup 1 --steps 0 >"$d/out/$mode-rotated.log" 2>&1 || :
else
    bash "$d/run.sh" "$mode"
    if [[ "$mode" == baseline || "$mode" == interface ]]; then
        "$d/out/$mode" --dry-control --warmup 0 --trace-proposals >"$d/out/$mode-level-dry-proposals.log" 2>&1
    fi
fi
printf 'Evidence in %s\n' "$d/out"
