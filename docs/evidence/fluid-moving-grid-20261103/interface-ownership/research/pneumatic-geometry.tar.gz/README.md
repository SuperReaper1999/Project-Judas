# Finite pneumatic impedance on authored cut regions

This scratch experiment uses the same physical gas volumes and shared dry
apertures as the current cut-region gas-topology prototype. The untouched
level and rotated authored basin fixtures supply the start geometry. The
existing conservative import supplies the rotated 9.21600041198731 m³
water inventory. The original static and MK2 gates retain their separate
qualification status.

## Acoustic model and independent ledgers

The gas law is linearized around density 1.2 kg/m³ and sound speed 343 m/s.
Pressure is a gauge increment relative to the ambient vent. Region gas
storage has mass capacitance C = V/c². A face with actual shared dry
aperture A and centre-to-centre normal distance L has linearized gas
momentum. Its mass conductance over a midpoint interval is
G = dt² A / (2 L). A vent length is the local half-depth to the specified
chart boundary. For an initially stationary, unpressurized gas and
prescribed compression source b = ρ δV, the pressure equation is

```text
(2 C + B G Bᵀ) p_mid = b
p_end = 2 p_mid
u_end = dt (p_mid,left − p_mid,right) / (ρ L)
m_face = ρ dt A u_end / 2
```

Every internal signed mass transfer appears once at each endpoint with
opposite sign. The audit recomputes m_face from velocity and geometry
rather than reusing G. The final total gas mass change plus exterior
mass loss equals the imposed volume source in mass units. The separate
quadratic gas compression energy and edge kinetic energies sum to the
source work ∑ p_mid b / ρ. These are linearized acoustic energies with
pressure and velocity fields, independent of the original nonlinear fluid
or rigid body ledgers.

The actual graph retains every positive physical shared dry aperture,
including those below a coordinate ULP. The rotated test's cavity is
selected by flooding from the original pocket seed through edges whose
area exceeds its exact widest-path bottleneck. This selection only
identifies where forcing is applied and which edges form the reported
leakage cut. It does not modify the actual operator. The sealed control
removes the crossing edges. The open control replaces those edges with
a distributed, manufactured 0.1 m² total vent over the same gas volumes
and 0.05 m inertial length, which gives an independent scalar result
p_end = 2 b_total/(2 C_total + G_vent).

## Geometry and pressure response

The level cavity is sealed, with 1,052 cells and 0.53399997425079249 m³.
The rotated cavity contains 1,024 cells and 0.16799997037900125 m³.
The rotated graph has a positive atmospheric path with widest
bottleneck 2.1684043449710069e-18 m². Its 15 cut ports sum to
1.7347234759768052e-17 m², with Σ A/L = 1.779203617698019e-16 m.

The same prescribed uniform cavity compression of 1e−5 m³ produces the
following end pressures and mass transfers. The intervals use the
actual fixture's binary32 60 Hz tick and its four native substeps.

| Rotated uniform control | Actual end pressure | Sealed end pressure | Open end pressure | Actual cut leakage |
| --- | ---: | ---: | ---: | ---: |
| 60 Hz | 8.403501481667300 Pa | 8.403501481667304 Pa | 0.085520715949460 Pa | 4.58417e-21 kg |
| 240 Hz | 8.403501481667304 Pa | 8.403501481667304 Pa | 1.187115916653081 Pa | 4.62882e-22 kg |

The forcing is 1.2e−5 kg in mass units. Independently of the sparse
solver, the maximum principle bounds uniform-compression leakage by
p_sealed dt² Σ(A/L) / 4. The bounds are 1.0383e−19 kg and
6.4894e−21 kg. This includes physical throat lengths. The positive
geometry path barely relieves pressure over either step. The manufactured
open vent relieves it strongly.

Localized compression is a separate spatial control. The same selected
rotated cavity averages 0.07983327 Pa at both intervals. Its peak
pressure is 0.11004829 Pa at 60 Hz and 0.49519924 Pa at 240 Hz.
A uniform chamber approximation would reproduce the integral pressure
response in this control but not the spatial peak. The pulse is an
independent volume forcing on fixed start geometry. It does not exercise
topology changes, nonlinear gas pressure, water/gas evolution,
solid forces, or runtime MK2 coupling.

## Sparse solve

The assembled graph is symmetric positive definite on positive-volume
nodes. Its minimum local storage-to-diagonal ratio is 9.60e−14 at
60 Hz and 1.54e−12 at 240 Hz. A pressure correction about the
independent sealed reference avoids losing extremely small pressure
jumps in the common gauge. Both Jacobi and IC(0) use the exact same
equations and run a freshly evaluated residual check. Independent mass
and work audits are checked in every mode. IC(0) includes its build cost
in elapsed solve measurements and uses no fill or operator changes.

For the localized rotated case, Jacobi used 1237/887 iterations
(roughly 440/320 ms) at 60/240 Hz. IC(0) used 91/80 iterations
(roughly 63/55 ms). These are diagnostic single-process timings with
independent checks enabled. Full acoustic resolution remains costly for
multiple gameplay substeps even after this exact preconditioner.
The absolute mass and work errors for the rotated localized IC(0)
cases are below 6e−21 kg and 2e−22 J, with maximum row mass error
below 2.7e−19 kg. No positivity or energy test was relaxed.

## Reproduction

Compile from this directory with GCC or an equivalent C++17 compiler
and the repository's existing glm dependency.

```sh
bash reproduce.sh
```

The 16 cases include sealed and open controls in each orientation at
both cadences and localized actual-graph forcing. Both preconditioners
must pass. The scratch archive retains source snapshots and raw outputs,
with no binaries.
