#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
out=$(mktemp -d /tmp/judas-pneumatic-replay.XXXXXX)
c++ -std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror     "$root/src/"{Pneumatic,CutRegionGeometry,CutRegionGasTopology,VentTopology}.cpp     -o "$out/pneumatic"
"$out/pneumatic" | tee "$out/jacobi.log"
"$out/pneumatic" --ic0 | tee "$out/ic0.log"
printf 'Replay results in %s\n' "$out"
