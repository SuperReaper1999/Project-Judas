#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
out=$(mktemp -d /tmp/judas-gas-track-replay.XXXXXX)
flags=(-std=c++17 -O3 -Wall -Wextra -Wpedantic -Werror)
geometry=(CutRegionGeometry.cpp CutRegionGasTopology.cpp)
c++ "${flags[@]}" DonorMathTests.cpp "${geometry[@]}" -o "$out/donor-math"
c++ "${flags[@]}" CutRegionGasTopologyTests.cpp "${geometry[@]}" -o "$out/topology"
c++ "${flags[@]}" ContinueGas.cpp CutLiquidGas.cpp "${geometry[@]}" -o "$out/gas"
c++ "${flags[@]}" TrackedBasinGas.cpp VentTopology.cpp "${geometry[@]}" -o "$out/topology-basin"
"$out/donor-math" | tee "$out/donor-math.log"
"$out/topology" | tee "$out/topology.log"
"$out/topology-basin" >"$out/topology-basin.log"
run() {
    local name=$1
    shift
    local status=0
    "$out/gas" "$@" >"$out/$name.log" 2>&1 || status=$?
    printf '%s exit=%s\n' "$name" "$status"
    grep -E '^(BEGIN|STAGE|SOLVE|GAS|TOPOLOGY|FAIL)' "$out/$name.log"
}
run level --steps 5 --strict-water-donor
run split --steps 5 --strict-water-donor --split-at-endpoint
printf 'Raw logs in %s\n' "$out"
