# Donor-safe pressure and gas ownership in the level basin

This isolated test uses the original level basin, original 9.25 m³
water inventory, and 60 Hz cadence with stationary walls and solid. It
uses the same geometry APIs and phase planes as the tracked cut prototype.
It does not stage native body motion, swimming, or the original settling
acceptance and has no runtime integration.

Run `./reproduce.sh` on Linux with a C++17 compiler and GLM installed.
The directory includes a snapshot of the chart and gas topology inputs.
Output named `split` takes around twenty seconds on the original host.
The case without split handling should reject the fourth interval after
three stages. The split-enabled case should reject the fifth interval
after four stages.

## Shared water and gas geometry

The hydraulic solver uses one signed volume transfer for a physical
aperture, with each direction drawing its wet support from the same
two-sided phase planes used to build the gas graph. Each ordinary
donor constrains total outflow to its old water volume. This is a
pressure constraint, not a correction after calculating endpoint storage.
Positive directed flows have the form `q_i=K_i max(D_i−lambda,0)`,
where `lambda` is the nonnegative common multiplier determined by the
donor's available volume. Capped pressure derivatives connect each pair
of accepting receivers with `K_i K_j/sum(K)`.

Head iterates are seeded from the preceding solve or an unconstrained
pressure result, then iterated until constrained local volume balance
passes. The unconstrained state is never published. The original wet
pressure and observed topology tests still reject if constraints fail.

A gas frontier associates newly dewatered regions with a unique connected
dry owner using geometric aperture support. Local orientation persists in
each newly mixed cell and the next pressure solve uses its clipped area.
This diagnostic still chooses its geometry from the largest eligible
inlet. The pressure/volume curve is a monotone hydrostatic column proxy
even when the interface points sideways or downward. The solver also
carries face velocity across a changing aperture without qualified
momentum ownership. These approximations require physical follow-up.

## Gas state and topology

A resolved closed chamber has one uniform pressure unknown over a pressure
trial. It uses the exact volume-average pressure for the ideal adiabatic
law `pV^1.4=const`. The measured gas internal-energy change agrees with
absolute pressure work. For comparison with gauge water work, subtract
the ambient-pressure volume work.

The optional endpoint split model is first-order in event timing. The
interval pressure solve retains the old gas owner, then assigns each
disconnected child an amount of gas proportional to its endpoint volume
at the common pressure, with conserved mass and internal energy.
Unsupported topology merge, new dry material without a source, and
vent connections reject. This is not a continuous split event solver.

Three level intervals stage without split handling. With the optional
policy, the fourth also stages when the resolved graph splits from
one chamber into four. The four-step water drift stays within
5.16e-14 m³ and local donor overspend remains exactly zero in the
face publication order. The maximum resolved speed is 3.642 m/s.
The split has zero measured gas mass error, 3.18e-12 J of gas internal
energy partition error and 2.38e-12 J of gas work error. The fifth pressure
solve reaches the local residual but rejects a merge of old gas owners.
It costs 16.87 s with roughly 136k linear iterations in the preserved run.
This does not meet runtime performance.

The tracked geometry preserves relative-depth gas films. On the original
rotated inventory the nominal 0.168 m³ chamber has an exterior graph path
whose widest bottleneck is only 2.1684e-18 m². The level model here assigns
a common pressure to connected gas and therefore cannot represent the
rotated chamber with the correct finite pneumatic impedance. The
separate tracked-basin executable preserves the exact path observation.
No rotated solver acceptance is claimed.
