#include "PhysicsConstraintBatch.h"
#include "PhysicsWorld.h"
#include "OrientedMovingVolume.h"
#include "RigidMotion.h"

#include <iomanip>
#include <iostream>
#include <numeric>
#include <string_view>

namespace {

using namespace judas::volume_grid;

constexpr GridLayout layout{{6,6,6}, .25};
constexpr float outerDt = 1.f / 60.f;
constexpr float initialSpin = .35f;
constexpr float bodyMass = 1000.f;
constexpr glm::vec3 center(.75f), half(.30f);
constexpr glm::vec3 axis(0.f,0.f,1.f);
constexpr std::uint32_t owner = 1;

GridVec Array(glm::dvec3 v) { return {v.x,v.y,v.z}; }

GridOrientedBox NativeBox(glm::quat q) {
    GridOrientedBox box{owner,Array(center),Array(half)};
    const auto m=glm::mat3_cast(glm::normalize(glm::dquat(q)));
    for(int i=0;i<3;++i) box.axes[i]=Array(m[i]);
    return box;
}

glm::quat PredictOrientation(const PhysicsConstraintBatch::Body& body,float spin,float dt) {
    RigidBody rigid;
    rigid.position=body.center;
    rigid.orientation=body.orientation;
    rigid.angularVelocity=spin*axis;
    rigid.inverseMass=body.inverseMass;
    rigid.inverseInertiaLocal=SolidBoxInverseInertia(bodyMass,half);
    std::vector<RigidMotionSegment> segments;
    AppendDynamicRigidMotion(segments,body.handle.id,rigid,0.,dt);
    return segments.back().EvaluateGeometry(dt).orientation;
}

GridOrientedMotion Path(glm::quat start,glm::quat finish) {
    const auto displacement=glm::normalize(glm::dquat(finish))*glm::conjugate(glm::normalize(glm::dquat(start)));
    GridOrientedMotion motion{NativeBox(start)};
    motion.rotationAxis={0.,0.,1.};
    motion.angle=2.*std::atan2(displacement.z,displacement.w);
    return motion;
}

struct Trial {
    float proposed=0., response=0.;
    glm::quat end{1,0,0,0};
    glm::vec3 responseLinear{0};
    OrientedMovingVolumeStep material;
    GridOrientedMotion motion;
};

bool Evaluate(const PhysicsConstraintBatch::Body& body,const MovingVolumeState& water,
              float dt,float proposed,Trial& trial,std::string& error) {
    trial={};
    trial.proposed=proposed;
    trial.end=PredictOrientation(body,proposed,dt);
    trial.motion=Path(body.orientation,trial.end);
    if (!AdvanceOrientedMovingVolume(layout,trial.motion,water,dt,{},trial.material,error)) return false;
    const auto& load=trial.material.load;
    const double orthogonal=std::max(std::abs(load.torque[0]),std::abs(load.torque[1]));
    const glm::dvec3 force(load.force[0],load.force[1],load.force[2]);
    trial.responseLinear=glm::vec3(glm::dvec3(body.linearVelocity)+double(body.inverseMass)*double(dt)*force);
    if (body.center+trial.responseLinear*dt!=body.center){
        error="this known principal-axis control requires a translation path";
        return false;
    }
    if (orthogonal > 1e-10*(1.+std::abs(load.torque[2]))) {
        std::cout<<"LATERAL trial_spin="<<proposed<<" force="<<load.force[0]<<','<<load.force[1]<<','<<load.force[2]
                 <<" torque="<<load.torque[0]<<','<<load.torque[1]<<','<<load.torque[2]
                 <<" tolerance="<<1e-10*(1.+std::abs(load.torque[2]))<<'\n';
        error="reflection control has resolved off-axis wrench";
        return false;
    }
    trial.response=float(double(body.angularVelocity.z)+double(body.inverseInertia[2][2])*double(dt)*load.torque[2]);
    return true;
}

bool Solve(const PhysicsConstraintBatch::Body& body,const MovingVolumeState& water,float dt,
           Trial& result,std::string& error) {
    Trial low,high;
    const float spin=body.angularVelocity.z;
    float a=spin-.5f,b=spin+.5f;
    if(!Evaluate(body,water,dt,a,low,error)||!Evaluate(body,water,dt,b,high,error)) return false;
    if(!(low.response>=a && high.response<=b)) {
        error="physical pressure response did not bracket a native rate";
        return false;
    }
    for (int i=0;i<32;++i) {
        // Solve the represented rate. Each force is evaluated against the
        // actual MK2-integrated orientation for this candidate rate.
        float rate = float(double(a)+(double(b)-a)*(double(low.response)-a)/
            ((double(low.response)-a)-(double(high.response)-b)));
        if (!(rate>a&&rate<b)) rate=float((double(a)+b)*.5);
        if(!Evaluate(body,water,dt,rate,result,error)) return false;
        if (result.response==rate) return true;
        if (rate==a||rate==b) {
            const auto& endpoint= rate==a ? high : low;
            if(endpoint.response==endpoint.proposed){ result=endpoint;return true; }
            error="adjacent binary32 rates have no fixed point";
            return false;
        }
        if(result.response>rate) {a=rate;low=result;}
        else {b=rate;high=result;}
    }
    error="pressure-driven orientation did not converge";
    return false;
}

double HalfUlp(float value) {
    return .5*std::max(double(value)-std::nextafter(value,-std::numeric_limits<float>::infinity()),
        std::nextafter(value,std::numeric_limits<float>::infinity())-double(value));
}

double Sum(const std::vector<double>& values) {
    return double(std::accumulate(values.begin(), values.end(),0.L));
}

bool CheckWork(const MovingVolumeState& before,const Trial& trial,
               const PhysicsConstraintBatch::Body& body,float dt,double density,
               double& endpointCut,double& dEnergy,std::string& error) {
    GridOrientedSweep sweep;
    GridOrientedGeometry endGeometry;
    if(!BuildGridOrientedSweep(layout,trial.motion,sweep,error) ||
       !BuildGridOrientedGeometry(layout,{NativeBox(trial.end)},endGeometry,error)) return false;
    endpointCut=0.;
    for (std::size_t i=0;i<endGeometry.capacity.size();++i)
        endpointCut=std::max(endpointCut,std::abs(sweep.end.capacity[i]-endGeometry.capacity[i]));
    if (endpointCut > 1e-15) {
        error="swept fluid endpoint does not reconstruct actual MK2 pose";
        return false;
    }
    if (std::abs(Sum(trial.material.fluid.state.water)-Sum(before.water))>1e-13) {
        error="native rotational water inventory changed";
        return false;
    }
    if (density==1000.)
        for(std::size_t i=0;i<endGeometry.capacity.size();++i)
            if(std::abs(trial.material.fluid.state.water[i]-endGeometry.capacity[i])>1e-13){
                error="wet phase endpoint did not occupy the native cut";return false;
            }
    long double dFluid=0., fluidCorrection=0.;
    for(int axisIndex=0;axisIndex<3;++axisIndex) {
        const auto& area=sweep.averageAperture[axisIndex];
        for (std::size_t i=0;i<area.size();++i) {
            if(area[i]==0.) continue;
            const double v0=sweep.start.aperture[axisIndex][i]>0.?before.velocity[axisIndex][i]:0.;
            const double v1=trial.material.fluid.flux[axisIndex][i]/(double(dt)*area[i]);
            const double mass=density*area[i]*layout.h;
            dFluid+=.5L*mass*(v1-v0)*(v1+v0);
            fluidCorrection+=.5L*mass*(v1-v0)*(v1-v0);
        }
    }
    const double spin0=body.angularVelocity.z,spin1=trial.response,inertia=1./body.inverseInertia[2][2];
    const auto linearBefore=glm::dvec3(body.linearVelocity),linearAfter=glm::dvec3(trial.responseLinear);
    const double dRigid=.5*inertia*(spin1-spin0)*(spin1+spin0)+
        .5*glm::dot(linearAfter-linearBefore,linearAfter+linearBefore)/double(body.inverseMass);
    const double rigidCorrection=.5*inertia*(spin1-spin0)*(spin1-spin0);
    const double mechanical=trial.material.load.torque[2]*trial.motion.angle;
    const double wallResidual=double(dFluid+fluidCorrection)+mechanical;
    dEnergy=dRigid+double(dFluid);
    const double closure=dEnergy+rigidCorrection+double(fluidCorrection);
    const double rigidRoundoff=std::abs(mechanical-dt*trial.material.load.torque[2]*spin1)+
        inertia*std::abs(spin1)*HalfUlp(trial.response)+
        std::abs(glm::dot(linearAfter,linearAfter-linearBefore)/double(body.inverseMass));
    std::cout<<"WORK sweep_m3="<<trial.material.maximumSweepResidual<<" native_cut_m3="<<endpointCut
             <<" independent_wall_residual_J="<<wallResidual<<" code_wall_residual_J="<<trial.material.pressureWorkResidual
             <<" fluid_delta_J="<<double(dFluid)<<" rigid_delta_J="<<dRigid
             <<" total_J="<<dEnergy<<" discrete_energy_residual_J="<<closure
             <<" rigid_roundoff_bound_J="<<rigidRoundoff<<'\n';
    if(std::abs(wallResidual)>1e-10 || std::abs(closure)>rigidRoundoff+1e-10 || dEnergy>rigidRoundoff) {
        error="native rotational pressure work or energy did not close";
        return false;
    }
    return true;
}

bool Run(bool wet,bool mismatch,unsigned ticks) {
    PhysicsWorld world;
    if(!world.Init()) return false;
    const auto orientation=glm::angleAxis(.13f,axis);
    Shape shape;
    shape.type=ShapeType::Box;
    shape.halfExtents=half;
    const auto body=world.CreateShape(shape,{center,orientation},true,bodyMass,0,0);
    if(!body.IsValid()) return false;
    world.SetAngularVelocity(body,axis*initialSpin);
    MovingVolumeState water;
    GridOrientedGeometry geometry;
    std::string error;
    if(!BuildGridOrientedGeometry(layout,{NativeBox(orientation)},geometry,error)) return false;
    water.water=geometry.capacity;
    if(!wet) std::fill(water.water.begin(),water.water.end(),0.);
    for(int d=0;d<3;++d) water.velocity[d].resize(layout.FaceCount(d));
    const double inventory=Sum(water.water);
    Trial staged;
    glm::vec3 oldSpin;
    double inverseInertia=0., angularImpulse=0.;
    unsigned published=0,verified=0,steps=0;
    PhysicsConstraintParticipant participant;
    participant.bodies={body};
    participant.propose=[&](const auto& batch,auto& proposal){
        if(batch.bodies.size()!=1||!batch.contacts.empty()||!batch.joints.empty())
            throw std::runtime_error("oriented native test encountered rigid constraint");
        const auto& snapshot=batch.bodies.front();
        oldSpin=snapshot.angularVelocity;
        inverseInertia=snapshot.inverseInertia[2][2];
        if(snapshot.center!=center||oldSpin.x!=0.f||oldSpin.y!=0.f)
            throw std::runtime_error("oriented native test left symmetry subspace");
        if(!Solve(snapshot,water,batch.context.deltaTime,staged,error))
            throw std::runtime_error(error);
        double endpointCut=0.,dEnergy=0.;
        if(!CheckWork(water,staged,snapshot,batch.context.deltaTime,wet?1000.:1.,endpointCut,dEnergy,error))
            throw std::runtime_error(error);
        const double torque=staged.material.load.torque[2];
        if (verified==0 && !(torque*oldSpin.z < -.001))
            throw std::runtime_error("resolved initial rotational pressure did not resist the spin");
        const auto& force=staged.material.load.force;
        proposal.linearImpulses={double(batch.context.deltaTime)*glm::dvec3(force[0],force[1],force[2])};
        angularImpulse=double(batch.context.deltaTime)*torque;
        proposal.angularImpulses={glm::dvec3(0,0,mismatch?0.:angularImpulse)};
        std::cout<<"PROPOSAL substep="<<batch.context.index<<" angular_impulse_N_m_s="
                 <<batch.context.deltaTime*torque<<" torque_N_m="<<torque<<" angle_rad="<<staged.motion.angle
                 <<" native_old_rad_s="<<oldSpin.z<<" native_expected_rad_s="<<staged.response<<'\n';
        return true;
    };
    participant.published=[&](const auto&){++published;};
    PhysicsWorld::VelocityCoupling coupling;
    coupling.physicalBatch=&participant;
    coupling.afterSubstep=[&](const auto&){
        const auto transform=world.GetTransform(body);
        const auto actual=world.GetAngularVelocity(body);
        if(transform.position!=center || transform.rotation!=staged.end || actual!=axis*staged.response ||
           world.GetLinearVelocity(body)!=staged.responseLinear ||
           published!=verified+1)
            throw std::runtime_error("native orientation or momentum differed from the swept pressure proposal");
        const double actualImpulse=(double(actual.z)-oldSpin.z)/inverseInertia;
        const double impulseError=std::abs(actualImpulse-angularImpulse);
        const double impulseBound=HalfUlp(actual.z)/inverseInertia+1e-14*(1.+std::abs(angularImpulse));
        if(impulseError>impulseBound)
            throw std::runtime_error("native angular momentum does not match pressure impulse");
        water=std::move(staged.material.fluid.state);
        ++verified;
        std::cout<<"VERIFIED q_z="<<transform.rotation.z<<" actual_spin_rad_s="<<actual.z
                 <<" volume_drift_m3="<<Sum(water.water)-inventory<<" angular_impulse_error_N_m_s="<<impulseError
                 <<" angular_impulse_bound_N_m_s="<<impulseBound<<'\n';
    };
    try {
        for(;steps<ticks;++steps) world.Step(outerDt,&coupling);
    } catch(const std::exception& e) { error=e.what(); }
    std::cout<<"END wet="<<wet<<" mismatch="<<mismatch<<" ticks="<<steps
             <<" published="<<published<<" verified="<<verified<<" reason="<<error<<'\n';
    return mismatch ? verified==0&&error.find("native orientation")!=std::string::npos :
        steps==ticks&&verified==4*ticks&&error.empty();
}

} // namespace

int main(int argc,char** argv) {
    std::cout<<std::setprecision(17);
    const std::string_view mode=argc>1?argv[1]:"wet";
    const unsigned ticks=argc>2?std::stoul(argv[2]):1;
    return Run(mode!="air",mode=="mismatch",ticks)?0:1;
}
