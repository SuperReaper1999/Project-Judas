#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
repo=$(git rev-parse --show-toplevel)
out=$(mktemp -d /tmp/judas-native-wrench-repro.XXXXXX)
for file in "$here"/*.cpp "$here"/*.h "$here"/build.py; do cp -- "$file" "$out"/; done
git -C "$repo" archive 508bf41e3f9dca1fe2b0ba664275db2573dbe3ee tools/prototypes/fluid_volume_grid | tar -x -C "$out"
s="$out/tools/prototypes/fluid_volume_grid"
common=()
for name in MovingVolumeGrid GridPhaseFluxRepair GridConservativeRemap GridHalfCellGeometry GridGeometricMomentum HalfDualVolumeMomentum MovingVolumeMomentum; do
    common+=(--source "$s/$name.cpp")
done
oriented=(--source "$out/NativeOrientedWrench.cpp" --source "$repo/src/RigidBody.cpp" --source "$repo/src/RigidRotation.cpp")
for name in OrientedMovingVolume GridOrientedGeometry GridOrientedSweep; do oriented+=(--source "$s/$name.cpp"); done
parity=(--source "$out/NativeParityProbe.cpp" --source "$out/CutRegionStep-rows.cpp")
for name in CutRegionGeometry CutRegionPressure CutRegionPhase CutRegionMomentum; do parity+=(--source "$s/$name.cpp"); done
python3 "$out/build.py" --repo "$repo" --exact --output "$out/oriented" "${oriented[@]}" "${common[@]}" "$@"
python3 "$out/build.py" --repo "$repo" --exact --output "$out/parity" "${parity[@]}" "${common[@]}" "$@"
run() {
    local label=$1 status=0
    shift
    "$@" >"$out/$label.log" 2>&1 || status=$?
    printf '%s\t%s\n' "$label" "$status" | tee -a "$out/results.tsv"
}
run water "$out/oriented" wet
run air "$out/oriented" air
run suppressed-torque "$out/oriented" mismatch
run water-8 "$out/oriented" wet 8
run air-8 "$out/oriented" air 8
run unreflected "$out/parity" --geometry-after-first
run mirrored-flux "$out/parity" --geometry-after-first --reflected-routing
run symmetric-flux "$out/parity" --geometry-after-first --symmetric-routing
for mode in parity-velocity zero-velocity reseed-water; do
    run "$mode" "$out/parity" --geometry-after-first --symmetric-routing "--$mode"
done
sha256sum "$out"/{oriented,parity} >"$out/binary-sha256.txt"
printf 'Reproduction results saved in %s\n' "$out"
