# Native MK2 pressure wrench and hydrostatic symmetry controls

The fluid source used here is Experimental
`508bf41e3f9dca1fe2b0ba664275db2573dbe3ee`. The mixed basin diagnostics reuse
the archived continuous-root driver and change only diagnostics or the
explicitly labeled probe input. They are separate from the original authored
wet seed and its settling gates.

## Fully wet angular pressure control

A centered cube with half extents 0.30 m and mass 1000 kg starts at
0.35 rad/s around a principal axis. Its closed chart has 6³ cells of width
0.25 m. No native contact, joint or gravitational load is applied. The test
samples each candidate represented spin through the actual MK2 rigid
integrator, then solves the existing oriented pressure operator on the
resulting sweep. A candidate closes when its pressure torque reproduces
the same native rate and orientation. The full computed linear impulse
is applied and native position and velocity are independently checked.
The known axial reflection control admits only unresolved transverse torque.
This keeps the geometric path a single principal-axis sweep.

The first water substep applies −0.52253958 N·m·s of pressure angular impulse.
Its actual angular speed falls to 0.34129101 rad/s. An independent recomputation
from the signed flux, physical face inertia and rigid angular motion closes
pressure work to 1.52e−14 J. Combined mechanical energy drops 0.09144442 J.
All four native water substeps in one 60 Hz tick pass with exact predicted
quaternion and native velocities. Maximum measured water inventory drift is
3.55e−15 m³. Angular momentum discrepancy is bounded by half of one
representable binary32 angular velocity after applying the measured native
inverse inertia.

The air control completes one tick and eight repeated ticks. The extended
wet run reaches 17 verified native substeps before the independent wall
work gate rejects at 1.031e−10 J against 1e−10 J. Its earlier steps remain
verified. The deliberate zero-torque negative control publishes the omitted
wrench to an isolated native world, detects the wrong endpoint after the
first substep and commits zero material states. This tests the observer and
provides no whole-tick native rollback claim.

These runs qualify a uniform phase, principal-axis rotation and no native
constraints. Mixed water and gas rotation, anisotropic rigid drift and native
contact coupling remain outside this control.

## Mixed hydrostatic torque trace

All 20,344 cuts pair under X and Z reflections. The first physical pressure
solutions are symmetric at the level of their numerical solve. The ordered
geometry rounding remap introduces an asymmetric velocity of up to
3.875e−4 m/s while retaining symmetric water to 8.67e−19 m³. Averaging the
remap over both reflections reduces that velocity difference to 7.44e−12 m/s
and keeps all phase and momentum checks. The next pressure evaluation
still produces 2.58665 N·m of torque and 3662.57 Pa of mirrored pressure
difference. Reflecting the route once also preserves the dominant torque.
Forcing exact velocity parity in a diagnostic copy does not remove it.

Two mirrored lower-body cuts have the same 1.1852014224267322e−6 m³ starting
capacity and same swept capacity change. One cut contains a trace air
remainder of about 1.49e−19 m³. Its reconstructed liquid plane is at the
edge of its free slab, 0.9002106785774231 m. The exactly full reflected cut
uses its entire enclosing region height of 0.92499997615814211 m, inside the
solid. This artificial discontinuity changes the vertical face inertia
and predicted volume on corresponding 0.0056250014901161327 m² ports.
Conductance changes from 1.26448777e−8 to 4.88281430e−9 m³/Pa and predicted
volume changes from 2.98407e−6 to 1.91115e−5 m³. The solution reports
2170.51 and 5833.08 Pa for the two cuts. With zero fluid predictor velocity
a 0.06780 N·m torque remains. Diagnostic hydrostatic re-seeding restores
reflection parity and allows the next scalar pressure root while keeping
the preceding fluid velocities. The modified state is deliberately never
published.

The measurements implicate reconstruction across the occupied solid in the
dominant torque. The remap's directional bias is a separate defect. The
pressure operator needs phase geometry with continuous support through exact
saturation and no extrapolation into the solid.

## Reproduction

Run `bash run.sh` by its full path from the repository root. The script
extracts the pinned prototype from git into a fresh temporary directory,
then compiles the actual native MK2 implementation and rigid rotation
modules using an existing CMake Release GNU Make build. Its default build
directory is `.cache/2d-stage1-build`. Use `--build PATH` to select another.
The oriented one-tick controls return success. The captured mixed diagnostic
returns failure because it preserves the known prepublication rejection.
