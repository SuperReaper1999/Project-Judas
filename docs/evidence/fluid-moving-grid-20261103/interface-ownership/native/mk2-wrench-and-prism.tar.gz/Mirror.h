#pragma once

#include <map>

using BoxKey = std::array<long long, 6>;
constexpr double mirrorSpan = 3.;
constexpr double keyScale = 1e12;

BoxKey MirrorKey(const CutRegion& region, int axis) {
    BoxKey key{};
    for (int d = 0; d != 3; ++d) {
        key[d] = std::llround((d == axis ? mirrorSpan - region.hi[d] : region.lo[d]) * keyScale);
        key[3+d] = std::llround((d == axis ? mirrorSpan - region.lo[d] : region.hi[d]) * keyScale);
    }
    return key;
}

void MeasureMirror(const CutRegionChart& chart, const CutRegionState& state,
                   const std::vector<double>* pressure, const char* label, unsigned substep) {
    std::map<BoxKey,std::size_t> index;
    for (std::size_t i=0;i<chart.regions.size();++i)
        index.emplace(MirrorKey(chart.regions[i], -1),i);
    for (int axis : {0, 2}) {
        std::size_t unpaired=0,worstPressure=0,worstSpeed=0;
        double waterDiff=0.,pressureDiff=0.,speedDiff=0.;
        long double l1Momentum=0.;
        for (std::size_t i=0;i<chart.regions.size();++i) {
            const auto& r=chart.regions[i];
            const auto paired = index.find(MirrorKey(r,axis));
            if (paired==index.end()) { ++unpaired; continue; }
            const auto j=paired->second;
            auto mirrored=state.velocity[j];
            mirrored[axis] *= -1.;
            const auto diff = glm::length(Vector(state.velocity[i])-Vector(mirrored));
            const double measure=(r.hi[0]-r.lo[0])*(r.hi[1]-r.lo[1])*(r.hi[2]-r.lo[2]);
            waterDiff = std::max(waterDiff,std::abs(state.water[i]-state.water[j]));
            if (diff>speedDiff) { speedDiff=diff; worstSpeed=i; }
            l1Momentum += (measure + 999. * std::max(state.water[i],state.water[j]))*diff;
            if (pressure && std::abs((*pressure)[i]-(*pressure)[j])>pressureDiff) {
                worstPressure=i;
                pressureDiff=std::abs((*pressure)[i]-(*pressure)[j]);
            }
        }
        std::cout << "MIRROR label=" << label << " substep=" << substep << " axis=" << axis
          << " unpaired=" << unpaired << " unique=" << index.size()
          << " water_m3=" << waterDiff << " pressure_Pa=" << pressureDiff
          << " speed_m_s=" << speedDiff << " l1_momentum_kg_m_s=" << double(l1Momentum)
          << " max_pressure_region=" << worstPressure << " max_speed_region=" << worstSpeed << '\n';
    }
}

bool ReflectFlux(const CutRegionGeometry& geometry, std::vector<double>& flux, int axes,
                 std::string& error) {
    std::map<std::pair<int,BoxKey>,std::size_t> index;
    for (std::size_t i=0;i<geometry.faces.size();++i) {
        const auto& f = geometry.faces[i];
        const auto [it, inserted] = index.emplace(std::make_pair(f.axis,MirrorKey({f.lo,f.hi,0},-1)), i);
        if (!inserted) { error = "face symmetry map is ambiguous"; return false; }
    }
    const auto snapshot=flux;
    for (std::size_t i=0;i<geometry.faces.size();++i) {
        if (snapshot[i] == 0.) continue;
        const auto& f = geometry.faces[i];
        for (int bits=1;bits<4;++bits) {
            if ((bits & axes) != bits) continue;
            auto lo=f.lo, hi=f.hi;
            int sign=1;
            for (int bit=0;bit<2;++bit) {
                if (!(bits&(1<<bit))) continue;
                const int axis=2*bit;
                lo[axis]=mirrorSpan-f.hi[axis];
                hi[axis]=mirrorSpan-f.lo[axis];
                if (axis == f.axis) sign *= -1;
            }
            const auto mate=index.find({f.axis,MirrorKey({lo,hi,0},-1)});
            if (mate==index.end() || !(geometry.faces[mate->second].startArea>0.)) {
                error = "face mirror not an admitted aperture";
                return false;
            }
            flux[mate->second] += sign*snapshot[i];
        }
    }
    const double divisor=axes==3?4.:2.;
    for (double& value : flux) value /= divisor;
    return true;
}
