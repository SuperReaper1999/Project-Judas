# Connected half-prism inertia and native basin qualification

These runs use the current connected half-prism implementation with the
same phase closure as the prior reconstruction probe. The exact frozen
source changes relative to `508bf41e` are in `source.patch` with their
file fingerprints. The existing native fixture, region topology, release
clock and pressure/transport gates were preserved.

## Identical second-trial pressure replay

The saved native trial includes the original box pose, velocities, cut
water inventories and all 20,344 interface orientations. Its two measured
ports have the same area of 0.004280945180282943 m². The earlier pressure
operator responds to their tiny difference in water inventory by
selecting incompatible inertia approximations. The connected half-prism
version measures both sides from physical wet and dry volume.

| Quantity | Earlier operator | Connected half prisms |
| --- | ---: | ---: |
| Right masses at the two ports, kg | 0.0003683245 and 0.0535118148 | 0.00015756390385775 and 0.00015756390385775 |
| Difference in predicted volume, m³ | 1.15512e−6 | 4.92e−21 |
| Difference in right pressure, Pa | 19.93984 | 2.84e−11 |
| Staged torque, N·m | 0.25140285 | 3.08767e−11 |
| Independent pressure work residual, J | −1.76914e−13 | 2.03726e−14 |

Both full-step replay runs reject the unsourced phase before publication.
The torque is an instrumented pressure result. The earlier source used a
disposable owner-route retry only to expose this separate pressure
sensitivity. Neither replay adopts that retry.

## Native trajectories

- The original dry control completes all four actual native substeps with
  zero water drift. Final native vertical speed is −0.1629038751 m/s, compared
  with −0.1628666669 m/s before the inertia correction. Maximum native
  impulse discrepancy is 5.52505e−7 N·s.
- The older cached hydrostatic bracket no longer straddles the root.
  Extending it by one independent measured secant inside the
  gravity-only to buoyancy-only displacement interval preserves the same
  physical residual and all release gates. One actual native substep is
  verified at y = 0.7000706196 m and vy = 0.0169556588 m/s. Its water
  drift is zero, independent pressure-work residual is 1.249e−16 J, and
  total mechanical energy decreases by 0.0404649920 J. Native impulse
  discrepancy is 6.0631e−8 N·s. The next physical step rejects unsourced
  phase. The alternate geometry-only rounding remap instead rejects
  asymmetry before publication. No complete hydrostatic wet tick is claimed.
- The original authored level and rotated seeds both reject the first
  warmup step at the phase feasibility gate. The direct level case
  rejects the same phase gate. The direct rotated case hits the pressure
  work limit before reaching phase transport. Every authored wet rejection
  occurs before material or native impulse publication.

Run the adjacent script by absolute path from the repository root.
It uses the existing GNU Make Release native build and allows selection
through `JUDAS_BASIN_CMAKE_BUILD`. It restores the frozen prototype source
in a fresh scratch directory and never patches the repository. The
compressed second-trial snapshot uses binary64 values ordered as lo and
hi box bounds, native y and vy, dt, water, three components of velocity,
and the interface count followed by axis and wet side for each cut.
