#define main BasinSharedMain
#include "BasinSharedStep.cpp"
#undef main
#include "Mirror.h"
#include <fstream>

int main(int argc,char** argv) {
    if(argc!=2)return 2;
    std::cout<<std::setprecision(17);
    const auto fixture=Fixture::Authored(false);
    Backend backend(fixture);
    std::string error;
    if(!backend.Prepare(SeedMode::HydrostaticControl,false,WallMode::Authored,error)){
        std::cout<<"REJECT "<<error<<'\n';return 1;
    }
    std::ifstream file(argv[1],std::ios::binary);
    const auto read=[&](){double v=0.;file.read(reinterpret_cast<char*>(&v),sizeof(v));return v;};
    auto body=fixture.InitialBox();
    for(double& x:body.lo)x=read();
    for(double& x:body.hi)x=read();
    const double y=read(),vy=read(),dt=read();
    for(double& w:backend.state.water)w=read();
    for(auto& v:backend.state.velocity)for(double& u:v)u=read();
    const double count=read();
    if(count!=0. && count!=double(backend.state.water.size()))return 2;
    backend.state.interfaces.resize(std::size_t(count));
    for(auto& trace:backend.state.interfaces){trace.axis=int(read());trace.wetAbove=read()!=0.;}
    if(!file||file.peek()!=std::ifstream::traits_type::eof())return 2;
    CutRegionStep step;
    MeasureMirror(backend.chart,backend.state,nullptr,"input",1);
    std::cout<<"TRIAL y="<<y<<" vy="<<vy<<" dt="<<dt<<" oriented_regions="<<count<<'\n';
    const double nextY=y+dt*vy;
    if(!backend.Advance(body,{0.,nextY-y,0.},dt,step,error)){
        std::cout<<"REJECT "<<error<<'\n';return 1;
    }
    MeasureMirror(backend.chart,step.state,&step.pressure.pressure,"solved",1);
    const auto force=Vector(step.loads.at(0).force);
    const glm::dvec3 chartCenter=(Vector(body.lo)+Vector(body.hi))*.5;
    const auto torque=Vector(step.loads.at(0).torque)-glm::cross(chartCenter,force);
    std::cout<<"WRENCH f="<<force.x<<','<<force.y<<','<<force.z
        <<" t="<<torque.x<<','<<torque.y<<','<<torque.z<<" t_abs="<<glm::length(torque)
        <<" pressure_work_residual_J="<<step.pressureWorkResidual<<'\n';
}
