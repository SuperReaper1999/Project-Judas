import pathlib, shlex, subprocess, sys
p=pathlib.Path(__file__).resolve().parent
b=pathlib.Path(sys.argv[1]).resolve()
name=sys.argv[2]
candidate=pathlib.Path(sys.argv[3]).resolve()
folder=pathlib.Path(sys.argv[4]).resolve()
prefix=sys.argv[5]
omit=sys.argv[6]
f=b/"CMakeFiles/judas_production_fluid_tests.dir"
flags=[]
for line in (f/"flags.make").read_text().splitlines():
    key,_,val=line.partition(" = ")
    if key in {"CXX_DEFINES","CXX_INCLUDES","CXX_FLAGS"}:
        flags.extend(shlex.split(val))
flags+=["-Werror", "-I"+str(p/"tools/prototypes/fluid_volume_grid"),"-I"+str(p)]
link=[v for v in shlex.split((f/"link.txt").read_text()) if not v.startswith("-Wl,--dependency-file=")]
replace=[obj for obj in folder.glob(prefix+"-*.o") if obj.name!=prefix+"-"+omit+".o"]
new=p/(name+"-main.o")
subprocess.run([link[0],*flags,"-c",str(candidate),"-o",str(new)],cwd=b,check=True)
replacement=next(i for i,v in enumerate(link) if v.endswith("ProductionFluidTests.cpp.o"))
link[replacement:replacement+1]=[*replace,new]
link[link.index("-o")+1]=p/name
subprocess.run(link,cwd=b,check=True)
