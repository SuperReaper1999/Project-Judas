# Monotonic phase source refinement control

The independently updated one-retry closure and half-prism pressure are
frozen by applying `owner.patch` after the parent's `source.patch`.
Every changed source and header was checked against `before.sha`.
The exact uninstrumented native rebuild confirms the same 1/4 hydrostatic
and 4/4 dry result. The one allowed retry eliminates three unsupported
gas routes. A second partition produces a different unsupported gas
route through a physical face with zero initial owner inventory.

The scratch variant `RouteIterateFour.cpp` keeps the original fluxes,
physical phase bounds and every conservation and source gate. It
re-solves the same circulation with unsupported phase zeroed at
the reported edges. Only the complementary phase can occupy those
edges when their original bounds permit it. Constraints tighten
monotonically.

The observed unsupported bounds progress from three, then one, then
none. The third solve of this candidate obtains force 3570.9631854 N,
torque 2.57568e−11 N·m and volume divergence 3.99304e−17 m³.
The next exploratory displacement of the continuous rigid root
then fails geometric phase feasibility independently. The retry
limit is never reached. Only the first native substep publishes.
This diagnostic does not establish a second valid coupled endpoint.

To reproduce, follow the parent `run.sh` in a scratch copy, applying
`owner.patch` after the existing source patch and verifying this
directory's `before.sha`. Use the same native driver and command.
Compile a separate variant with `RouteIterateFour.cpp` replacing
`GridPhaseFluxRepair.cpp` for the monotonic diagnostic.
