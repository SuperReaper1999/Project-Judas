#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
repo=$(git rev-parse --show-toplevel)
build=${JUDAS_BASIN_CMAKE_BUILD:-"$repo/.cache/2d-stage1-build"}
out=$(mktemp -d /tmp/judas-native-prism-replay.XXXXXX)
cp -- "$here"/../{BasinFixture.h,BasinMk2.cpp,BasinMk2.h,BasinSharedStep.cpp,build.py,Mirror.h} "$out"/
cp -- "$here"/*.cpp "$here"/relink-one.py "$out"/
git -C "$repo" archive 508bf41e3f9dca1fe2b0ba664275db2573dbe3ee tools/prototypes/fluid_volume_grid | tar -x -C "$out"
(cd "$out"; patch -s -p1 < "$here/source.patch"; sha256sum -c "$here/before.sha" > "$out/source-verification.log")
s="$out/tools/prototypes/fluid_volume_grid"
common=()
for name in CutRegionGeometry CutRegionPressure CutRegionPhase CutRegionMomentum MovingVolumeGrid GridPhaseFluxRepair GridConservativeRemap GridHalfCellGeometry GridGeometricMomentum HalfDualVolumeMomentum MovingVolumeMomentum; do
    common+=(--source "$s/$name.cpp")
done
python3 "$out/build.py" --repo "$repo" --build "$build" --exact --output "$out/native" --source "$out/NativeRebracket.cpp" --source "$s/CutRegionStep.cpp" "${common[@]}"
python3 "$out/relink-one.py" "$build" authored "$out/BasinSharedStep.cpp" "$out" native NativeRebracket
python3 "$out/build.py" --repo "$repo" --build "$build" --exact --output "$out/replay" --source "$out/ReplaySecond.cpp" --source "$out/CutRegionStep-prism-staged.cpp" "${common[@]}"
gzip -dc "$here/second-state.bin.gz" >"$out/second-state.bin"
run() {
    local name=$1 result=0
    shift
    "$@" > "$out/$name.log" 2>&1 || result=$?
    printf '%s\t%s\n' "$name" "$result" | tee -a "$out/results.tsv"
}
run replay-second-prism "$out/replay" "$out/second-state.bin"
run hydro "$out/native" --geometry-after-first --symmetric-routing
run dry "$out/authored" --dry-control --warmup 0
run original-level "$out/authored"
run original-level-direct "$out/authored" --warmup 0
run original-rotated "$out/authored" --rotated --conservative-seed
run original-rotated-direct "$out/authored" --rotated --conservative-seed --warmup 0
sha256sum "$out"/{replay,native,authored} >"$out/binary-sha256.txt"
printf 'Native prism results saved in %s\n' "$out"
