#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
repo=$(git rev-parse --show-toplevel)
out=$(mktemp -d /tmp/judas-native-wrench-latest.XXXXXX)
cp -- "$here"/../{BasinFixture.h,BasinMk2.cpp,BasinMk2.h,BasinSharedStep.cpp,build.py,Mirror.h} "$out"/
cp -- "$here"/*.cpp "$out"/
git -C "$repo" archive 508bf41e3f9dca1fe2b0ba664275db2573dbe3ee tools/prototypes/fluid_volume_grid | tar -x -C "$out"
(cd "$out"; patch -p1 < "$here/source.patch"; sha256sum -c "$here/before.sha")
s="$out/tools/prototypes/fluid_volume_grid"
common=()
for name in CutRegionGeometry CutRegionPressure CutRegionPhase CutRegionMomentum MovingVolumeGrid GridConservativeRemap GridHalfCellGeometry GridGeometricMomentum HalfDualVolumeMomentum MovingVolumeMomentum; do
    common+=(--source "$s/$name.cpp")
done
base=(--source "$s/CutRegionStep.cpp" --source "$s/GridPhaseFluxRepair.cpp")
python3 "$out/build.py" --repo "$repo" --exact --output "$out/replay" --source "$out/ReplayThird.cpp" "${common[@]}" "${base[@]}" "$@"
python3 "$out/build.py" --repo "$repo" --exact --output "$out/native" --source "$out/NativeRemapMirror.cpp" "${common[@]}" "${base[@]}" "$@"
for mode in normal symmetric; do
    gzip -dc "$here/third-$mode.bin.gz" >"$out/third-$mode.bin"
    "$out/replay" "$out/third-$mode.bin" >"$out/replay-$mode.log"
done
"$out/native" --geometry-after-first --symmetric-routing >"$out/hybrid-symmetric.log" 2>&1 || test "$?" = 1
if [[ ${JUDAS_WRENCH_INERTIA_DIAGNOSTIC:-0} == 1 ]]; then
    python3 "$out/build.py" --repo "$repo" --exact --output "$out/inertia" --source "$out/NativeInertiaProbe.cpp" --source "$out/CutRegionStep-inertia-probe.cpp" --source "$out/PhaseRoutesRepair.cpp" "${common[@]}" "$@"
    "$out/inertia" --geometry-after-first --symmetric-routing > "$out/inertia.log" 2>&1 || test "$?" = 1
fi
sha256sum "$out"/{native,replay} >"$out/binary-sha256.txt"
printf 'Updated replay results saved in %s\n' "$out"
