# Fixed third-trial replay after interface reconstruction

The two saved snapshots reproduce the same native third trial input from
the pinned 508bf41e probe, including original rounded body geometry,
starting water inventory, velocity, timestep and the first candidate.
The binary files are gzip-compressed binary64 data. They begin with lower
box bounds, body y, body vy and dt, followed by water and 3-vector fluid
velocity for all 20,344 regions.

The updated prototype source patch here reconstructs phase through the
actual free slab and preserves the sub-coordinate remainder. It also
keeps explicitly dry regions dry. The measured maximum mirrored
pressure defect and torque change on the same stored inputs.

| Remap before the saved trial | Pressure defect before → after | Torque before → after |
| --- | ---: | ---: |
| Ordered wet route | 3662.1993 → 0.02484 Pa | 2.5866799 → 1.94516e−5 N·m |
| Reflected-average wet route | 3662.5694 → 1.03882e−8 Pa | 2.5866514 → 2.82968e−11 N·m |

Updated dry native control passes all four substeps at the same final
native speed. The original authored level and rotated wet direct controls
still reject at the first phase step with no material or native impulse
publication. The separate hydrostatic case reaches one native substep,
then the phase repair returns a tiny unsourced gas parcel. All current
source fingerprints were captured before and after the exact-source build.

The instrumented trace finds 5.7942347548114483e−20 m³ of gas on an outgoing
edge of region 7832, which began solid and received only water. The
disposable ownership retry resolves its face split by restricting affected
edges to source-owned phase when their original geometry bounds permit,
then re-solves and audits the same inventory ledger. It remains outside
the candidate, which rejects the unsourced parcel.

The retry exposes a second independent discontinuity. At otherwise
matching +Y faces 24706 and 32038, a 1.37e−20 m³ trace in one mirrored cut
chooses a perpendicular phase orientation. The two wetted openings differ
by only about 1.4e−16 m². Existing inertia switches from projected wet depth
to a whole-half-width aperture approximation, assigning 0.0003683 versus
0.05351 kg in the paired side and introducing a pressure-driven torque of
0.2514 N·m. This is an operator sensitivity, while the actual apertures
and phase ownership were matched. The proposed correction is to measure
each side's real clipped phase volume in the dual pressure prism.

From the repository root, run the adjacent script. It extracts pinned
prototype files to a temporary directory and applies the measured source
patch only there. Set `JUDAS_WRENCH_INERTIA_DIAGNOSTIC=1` to include the
separate unsupported-flow retry and inertia trace. The build instructions
and native compile dependencies are otherwise the same as the parent packet.
