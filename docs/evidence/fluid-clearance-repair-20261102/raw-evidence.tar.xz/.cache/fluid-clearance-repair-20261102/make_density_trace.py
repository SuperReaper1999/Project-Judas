from pathlib import Path
p=Path('.cache/fluid-clearance-repair-20261102')
s=Path('src/FluidWorld.cpp').read_text()
s='#include <cstdio>\n'+s
s=s.replace('''    ++m_revision;
    if (contactImpulses)''','''    static unsigned debugCall=0;const unsigned debugStep=++debugCall;
    const bool traceStep=debugStep>=316 && debugStep<=318;
    const auto tracked=[](size_t i){return i==19||i==210||i==234;};
    ++m_revision;
    if (contactImpulses)''')
s=s.replace('''        const float alpha0 =''','''        const auto dump=[&](const char* phase){if(traceStep)for(size_t i=0;i<count;++i)if(tracked(i)){
            const auto& p=m_particles[i];std::fprintf(stderr,"PHASE %u %d %s %zu p %.9g %.9g %.9g v %.9g %.9g %.9g predicted %.9g %.9g %.9g\\n",debugStep,substep,phase,i,p.position.x,p.position.y,p.position.z,p.velocity.x,p.velocity.y,p.velocity.z,positions[i].x,positions[i].y,positions[i].z);
        }};
        dump("start");
        const float alpha0 =''')
s=s.replace('''        // This passive geometry state never changes particle positions,''','''        dump("after-density");
        // This passive geometry state never changes particle positions,''')
s=s.replace('''            particle.position = positions[i];
        }
        // Smoothing''','''            if(traceStep&&tracked(i))std::fprintf(stderr,"PRESSURE %u %d %zu actual %.9g %.9g %.9g represented %.9g %.9g %.9g solid %.9g %.9g %.9g\\n",debugStep,substep,i,reconstructedCorrection.x/substepTime,reconstructedCorrection.y/substepTime,reconstructedCorrection.z/substepTime,representedPressureCorrections[i].x/substepTime,representedPressureCorrections[i].y/substepTime,representedPressureCorrections[i].z/substepTime,solidCorrections[i].x,solidCorrections[i].y,solidCorrections[i].z);
            particle.position = positions[i];
        }
        dump("after-pressure");
        // Smoothing''')
s=s.replace('''        std::vector<FluidVelocityContact> velocityContacts;''','''        dump("after-smoothing");
        std::vector<FluidVelocityContact> velocityContacts;''')
s=s.replace('''        std::vector<glm::vec3> impulses(velocityContacts.size(),glm::vec3(0));''','''        if(traceStep)for(const auto& c:velocityContacts)if(tracked(c.particleIndex))std::fprintf(stderr,"CONTACT %u %d %zu owner %u point %.9g %.9g %.9g normal %.9g %.9g %.9g wall %.9g %.9g %.9g\\n",debugStep,substep,c.particleIndex,c.owner.id,c.point.x,c.point.y,c.point.z,c.normal.x,c.normal.y,c.normal.z,c.wallVelocity.x,c.wallVelocity.y,c.wallVelocity.z);
        std::vector<glm::vec3> impulses(velocityContacts.size(),glm::vec3(0));''')
s=s.replace('''        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''','''        dump("after-contacts");
        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''')
(p/'FluidWorld-density-phase.cpp').write_text(s)
