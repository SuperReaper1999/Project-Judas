Final-source passive transient attribution (2026-11-02)

Prepared only; no full pool runs have been started by the reviewer. Wait for
parent confirmation that the coordinated native checks have finished before
running CPU-heavy pool simulations. Run every simulation sequentially.

Sources:
  FluidWorld-original.cpp       exact captured current production source
  FluidWorld-final-phase.cpp    same source plus passive phase/row logging
  pool_probe_peak.original.cpp  byte-identical original unchanged pool driver
  pool_probe_digest.cpp         same inputs and acceptance + physical digests
  prepare.py                    exact generation and compilation recipe

Compiled programs:
  pool_original   original acceptance and published-frame maximum
  pool_digest     original acceptance plus per-frame trajectory/endpoint hashes
  pool_phase      same digest driver with instrumented FluidWorld override

From repository root after CPU work is free:
  .cache/fluid-clearance-repair-20261102/final-passive/pool_digest > .cache/fluid-clearance-repair-20261102/final-passive/digest-1.log 2>&1
  .cache/fluid-clearance-repair-20261102/final-passive/pool_digest > .cache/fluid-clearance-repair-20261102/final-passive/digest-2.log 2>&1
  .cache/fluid-clearance-repair-20261102/final-passive/pool_phase > .cache/fluid-clearance-repair-20261102/final-passive/phase.log 2>&1

Digest specification: FNV-1a64 over canonical little-endian scalar float bits,
covering every frame's particle count/positions/velocities/masses, authoritative
player position/velocity/orientation, dynamic body IDs/poses/linear and angular
velocities. The endpoint hash covers the same physical state without frame
ordinal. Clocks, profiler fields, diagnostics, padding, pointers and arbitrary
allocation state are excluded. Compare phase_digest and final trajectory_digest
and endpoint_digest between ordinary repeats AND instrumented execution.

Instrumentation keeps per-particle before-pressure, after-pressure and
post-smoothing velocity snapshots. For each new POST-CONTACT substep maximum,
it logs all four velocities and exact actual contact rows for that particle,
including target, real nearest-feature gap, published-plane gap, hard/soft,
primitive type, final feature active/preferred flags, wall material velocity,
point/normal, impulse and final relative-normal residual. Contact provenance is
an index into the original rows, not an inferred normal/owner match.

An intermediate substep running maximum is not necessarily the published-frame
maximum from the original driver; report them separately. No performance claim
should use instrumented elapsed time. Logging is passive with respect to physics
inputs and state; digest agreement is the direct passivity check.

All targets link the complete current engine archive. Only pool_phase overrides
FluidWorld with its matching current-header copy; no old-layout production
objects are mixed. PREPARATION_SHA256SUMS.txt binds captured source, scene and
executables. build-commands.txt and build-*.log preserve exact compilation.
