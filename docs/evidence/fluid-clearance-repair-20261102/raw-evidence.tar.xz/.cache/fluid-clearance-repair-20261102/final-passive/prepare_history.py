from pathlib import Path
import shlex,subprocess,hashlib,json
root=Path.cwd();out=root/'.cache/fluid-clearance-repair-20261102/final-passive'
s=(out/'FluidWorld-final-phase.cpp').read_text()
context='''namespace { unsigned historyCall=0; int historySubstep=0,historyIteration=-1;
bool HistoryParticle(std::size_t i) {return i==482 || i==651 || i==678;}
}
'''
s=s.replace('#include <cstdio>\n','#include <cstdio>\n'+context)
s=s.replace('const unsigned traceStep = ++traceCall;','const unsigned traceStep = ++traceCall; historyCall=traceStep;')
s=s.replace('''        const float alpha0 =''','''        historySubstep=substep;historyIteration=-1;
        const float alpha0 =''')
s=s.replace('''        for (int iteration = 0; iteration < iterations; ++iteration) {''','''        for (int iteration = 0; iteration < iterations; ++iteration) {
            historyIteration=iteration;''')
needle='''    auto retain = [&](const BoxContact& contact) {
        observe(contact);'''
assert s.count(needle)==1
s=s.replace(needle,needle+r'''
        if (historyCall>=200 && HistoryParticle(particleIndex) && contact.hardEncounter) {
            BoxContact entry;
            if(contact.box)entry=CollideBox(from,reference,*contact.box,0,substepTime);
            else if(contact.sphere)entry=CollideSphere(from,reference,*contact.sphere,0,substepTime);
            else if(contact.terrain)entry=CollideTerrain(from,reference,*contact.terrain,0,substepTime);
            std::fprintf(stderr,"HISTORY_HARD call=%u sub=%d particle=%zu stage=%d owner=%u entry_sweep_hit=%d from=(%.12g,%.12g,%.12g) entry_to=(%.12g,%.12g,%.12g) working=(%.12g,%.12g,%.12g) hard_projection=(%.12g,%.12g,%.12g) normal=(%.12g,%.12g,%.12g) point=(%.12g,%.12g,%.12g) wall=(%.12g,%.12g,%.12g)\n",
                historyCall,historySubstep,particleIndex,historyIteration,contact.owner.id,int(entry.hit),
                from.x,from.y,from.z,reference.x,reference.y,reference.z,point.x,point.y,point.z,
                contact.projectedPosition.x,contact.projectedPosition.y,contact.projectedPosition.z,
                contact.normal.x,contact.normal.y,contact.normal.z,contact.point.x,contact.point.y,contact.point.z,
                contact.wallVelocity.x,contact.wallVelocity.y,contact.wallVelocity.z);
        }''')
needle='''        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);'''
assert s.count(needle)==1
s=s.replace(needle,r'''        if(historyCall>=200)for(std::size_t i=0;i<count;++i)if(HistoryParticle(i)) {
            const auto p=m_particles[i].position,before=traceBeforePressure[i],pressure=traceAfterPressure[i];
            const auto smooth=traceAfterSmoothing[i],after=m_particles[i].velocity;
            const auto represented=representedPressureCorrections[i]/double(substepTime);
            std::fprintf(stderr,"HISTORY_FINAL call=%u sub=%d particle=%zu start=(%.12g,%.12g,%.12g) unconstrained=(%.12g,%.12g,%.12g) position=(%.12g,%.12g,%.12g) before=(%.12g,%.12g,%.12g) pressure=(%.12g,%.12g,%.12g) smoothing=(%.12g,%.12g,%.12g) contact=(%.12g,%.12g,%.12g) represented_pressure=(%.12g,%.12g,%.12g) speed=%.12g outside=%d\n",
                historyCall,historySubstep,i,starts[i].x,starts[i].y,starts[i].z,
                unconstrainedPositions[i].x,unconstrainedPositions[i].y,unconstrainedPositions[i].z,
                p.x,p.y,p.z,before.x,before.y,before.z,pressure.x,pressure.y,pressure.z,
                smooth.x,smooth.y,smooth.z,after.x,after.y,after.z,represented.x,represented.y,represented.z,
                glm::length(after),int(std::abs(p.x)>6.25f || std::abs(p.z)>4.25f || p.y<0));
            for(std::size_t row=0;row<velocityContacts.size();++row) {
                const auto& c=velocityContacts[row];if(c.particleIndex!=i)continue;
                const auto& original=contacts[i][traceContactOrigins[row]];
                const auto final=FinalizeSoftContact(original,p,m_settings.particleRadius,substepTime);
                std::fprintf(stderr,"HISTORY_ROW call=%u sub=%d particle=%zu owner=%u hard=%d target=%.12g physical_gap=%.12g normal=(%.12g,%.12g,%.12g) wall=(%.12g,%.12g,%.12g) residual=%.12g\n",
                    historyCall,historySubstep,i,c.owner.id,int(original.hardEncounter),c.minimumNormalVelocity,final.gap,
                    c.normal.x,c.normal.y,c.normal.z,c.wallVelocity.x,c.wallVelocity.y,c.wallVelocity.z,
                    c.minimumNormalVelocity-glm::dot(after-c.wallVelocity,c.normal));
            }
        }
'''+needle)
# std::size_t is declared before the diagnostic file-scope context.
s=s.replace('#include <cstdio>\n','#include <cstdio>\n#include <cstddef>\n',1)
(out/'FluidWorld-history.cpp').write_text(s)
commands=[shlex.split(line) for line in (out/'build-commands.txt').read_text().splitlines()]
compile=commands[0];compile[compile.index(str(out/'FluidWorld-final-phase.cpp'))]=str(out/'FluidWorld-history.cpp');compile[compile.index('-o')+1]=str(out/'FluidWorld-history.o')
link=commands[3];link[link.index(str(out/'pool_probe_digest.cpp'))]=str(out/'pool_probe_ids.cpp');link[link.index(str(out/'FluidWorld-final-phase.o'))]=str(out/'FluidWorld-history.o');link[link.index('-o')+1]=str(out/'pool_history')
(out/'history-commands.txt').write_text('\n'.join(shlex.join(c) for c in [compile,link])+'\n')
for i,c in enumerate([compile,link]):
 r=subprocess.run(c,cwd=root/'.cache/2d-stage1-build',capture_output=True,text=True);(out/f'history-build-{i}.log').write_text(r.stdout+r.stderr);print('build',i,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
