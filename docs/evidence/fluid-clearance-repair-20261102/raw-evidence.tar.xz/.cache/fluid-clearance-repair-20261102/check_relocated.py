from pathlib import Path
import subprocess,json,hashlib,os,shutil,time
root=Path.cwd();out=root/'.cache/fluid-clearance-repair-20261102';build=root/'.cache/2d-stage1-build'
package=out/'export-source';relocated=Path('/tmp/Judas Fluid Clearance Verification 20261102')
assert not package.exists() and not relocated.exists()
cmd=[str(build/'judas_export'),str(root/'projects/fluid_comparison/fluid_comparison.judasproj'),str(package),str(build/'judas')]
with (out/'export.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:raise SystemExit(r.returncode)
shutil.move(str(package),str(relocated))
tour=out/'relocated-tour.txt';s=(root/'.cache/fluid-pool-impact-20261102/relocated-tour.txt').read_text().replace('/tmp/judas-fluid-clock-relocated.png',str(out/'relocated-frame.png'));tour.write_text(s)
env=os.environ.copy();env.update(DISPLAY=':0',WAYLAND_DISPLAY='wayland-0',XAUTHORITY='/run/user/1000/xauth_HZnUjo',XDG_RUNTIME_DIR='/run/user/1000',DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus',JUDAS_GPU_DIAGNOSTICS='1',JUDAS_TEST_SCRIPT=str(tour),JUDAS_WINDOW_SIZE='960x540');env.pop('JUDAS_ENGINE_ROOT',None)
exe=relocated/'judas';assert exe.is_file()
start=time.monotonic()
with (out/'relocated-application.log').open('w') as log:
 try:r=subprocess.run([str(exe)],cwd='/tmp',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90);code=r.returncode
 except subprocess.TimeoutExpired:code=124
manifest={str(p.relative_to(relocated)):hashlib.sha256(p.read_bytes()).hexdigest() for p in relocated.rglob('*') if p.is_file()}
(out/'RELOCATED_PACKAGE_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'export_command':cmd,'relocated':str(relocated),'cwd':'/tmp','engine_root_override':False,'gpu_diagnostics':True,'exit':code,'seconds':time.monotonic()-start,'runtime_sha256':manifest['judas'],'files':len(manifest),'bytes':sum(p.stat().st_size for p in relocated.rglob('*') if p.is_file()),'screenshot_exists':(out/'relocated-frame.png').is_file()}
(out/'APPLICATION_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(code)
