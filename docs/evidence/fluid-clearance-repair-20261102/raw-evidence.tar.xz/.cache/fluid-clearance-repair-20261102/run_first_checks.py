from pathlib import Path
import subprocess,time,json,os,hashlib
root=Path.cwd();out=root/'.cache/fluid-clearance-repair-20261102/final';out.mkdir(exist_ok=False)
build=root/'.cache/2d-stage1-build'
checks=[
('clearance','judas_fluid_contact_clearance_tests',[]),
('boundary','judas_fluid_boundary_contact_tests',[]),
('particle-batch','judas_particle_contact_batch_tests',[]),
('cadence','judas_fluid_cadence_motion_tests',[]),
('hydrostatics','judas_fluid_hydrostatics_tests',[]),
('policy','judas_project_fluid_policy_tests',[]),
('lifecycle','judas_fluid_lifecycle_qualification_tests',[]),
('cavity-impact','judas_fluid_cavity_impact_tests',[]),
('containers','judas_fluid_container_integration_tests',['--output',str(out/'containers')]),
('production','judas_production_fluid_tests',['--output',str(out/'production')]),
('player','judas_player_fluid_integration_tests',['--output',str(out/'player')]),
('demo','judas_fluid_demo_integration_tests',['--output',str(out/'demo')]),
('basic-preview','judas_basic_water_preview_tests',[str(out/'basic-preview')]),
]
env=os.environ.copy();env.update(DISPLAY=':0',WAYLAND_DISPLAY='wayland-0',XAUTHORITY='/run/user/1000/xauth_HZnUjo',XDG_RUNTIME_DIR='/run/user/1000',DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus',JUDAS_GPU_DIAGNOSTICS='1')
rows=[]
for name,target,args in checks:
    start=time.monotonic();binary=build/target
    with (out/(name+'.log')).open('w') as log:
        try:r=subprocess.run([str(binary),*args],stdout=log,stderr=subprocess.STDOUT,cwd=root,env=env,timeout=900);code=r.returncode
        except subprocess.TimeoutExpired:code=124
    row={'name':name,'target':target,'args':args,'exit':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
    rows.append(row);(out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
raise SystemExit(any(r['exit']!=0 for r in rows))
