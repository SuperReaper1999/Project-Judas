from pathlib import Path
s=Path('src/FluidWorld.cpp').read_text();s='#include <cstdio>\n'+s
s=s.replace('''    ++m_revision;
    if (contactImpulses)''','''    static unsigned traceCall=0;const auto call=++traceCall;
    ++m_revision;
    if (contactImpulses)''')
s=s.replace('''        std::vector<glm::vec3> impulses(velocityContacts.size(),glm::vec3(0));''','''        std::vector<glm::vec3> beforeContact;for(const auto& p:m_particles)beforeContact.push_back(p.velocity);
        std::vector<glm::vec3> impulses(velocityContacts.size(),glm::vec3(0));''')
s=s.replace('''        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''','''        for(size_t i=0;i<count;++i)if(glm::length(m_particles[i].velocity-beforeContact[i])>5 || glm::length(m_particles[i].velocity)>15) {
            const auto v=beforeContact[i],w=m_particles[i].velocity,p=positions[i];
            std::fprintf(stderr,"SPIKE call=%u sub=%d id=%zu p=(%.9g,%.9g,%.9g) before=(%.9g,%.9g,%.9g) after=(%.9g,%.9g,%.9g) speed=%.9g delta=%.9g\\n",call,substep,i,p.x,p.y,p.z,v.x,v.y,v.z,w.x,w.y,w.z,glm::length(w),glm::length(w-v));
            for(const auto& c:velocityContacts)if(c.particleIndex==i)std::fprintf(stderr,"ROW owner=%u n=(%.9g,%.9g,%.9g) wall=(%.9g,%.9g,%.9g) point=(%.9g,%.9g,%.9g) target=%.9g gap=%.9g\\n",c.owner.id,c.normal.x,c.normal.y,c.normal.z,c.wallVelocity.x,c.wallVelocity.y,c.wallVelocity.z,c.point.x,c.point.y,c.point.z,c.minimumNormalVelocity,glm::dot(p-c.point,c.normal));
            for(const auto& c:contacts[i])std::fprintf(stderr,"ORIGINAL hard=%d box=%d sphere=%d terrain=%d n=(%.9g,%.9g,%.9g) gap=%.9g\\n",c.hardEncounter,bool(c.box),bool(c.sphere),bool(c.terrain),c.normal.x,c.normal.y,c.normal.z,glm::dot(p-c.point,c.normal));
        }
        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''')
Path('.cache/fluid-clearance-repair-20261102/FluidWorld-trace.cpp').write_text(s)
