from pathlib import Path
import hashlib
import json
import shlex
import subprocess

root = Path.cwd()
out = root / '.cache/fluid-clearance-repair-20261102/final-coherent-passive'
build = root / '.cache/2d-stage1-build'
original = root / '.cache/fluid-pool-impact-20261102/pool_probe_peak.cpp'
fluid = (root / 'src/FluidWorld.cpp').read_text()
(out / 'FluidWorld-original.cpp').write_text(fluid)
(out / 'pool_probe_peak.original.cpp').write_bytes(original.read_bytes())

def replace_once(source, old, new):
    assert source.count(old) == 1, (old[:100], source.count(old))
    return source.replace(old, new)

fluid = '#include <cstdio>\n' + fluid
fluid = replace_once(fluid, '''    ++m_revision;
    if (contactImpulses)''', '''    static unsigned traceCall = 0;
    static float traceRunningMaximum = 0;
    const unsigned traceStep = ++traceCall;
    ++m_revision;
    if (contactImpulses)''')
fluid = replace_once(fluid, '''    const auto boundaryFrame=FluidBoundaryFrame(m_particles);''', '''    std::vector<glm::vec3> traceBeforePressure(count), traceAfterPressure(count), traceAfterSmoothing(count);
    const auto boundaryFrame=FluidBoundaryFrame(m_particles);''')
fluid = replace_once(fluid, '''            const glm::vec3 reconstructedCorrection=positions[i]-unconstrainedPositions[i]-solidCorrections[i];''', '''            traceBeforePressure[i] = particle.velocity;
            const glm::vec3 reconstructedCorrection=positions[i]-unconstrainedPositions[i]-solidCorrections[i];''')
fluid = replace_once(fluid, '''        // Smoothing predicts the velocity BEFORE the boundary projection.''', '''        for (std::size_t i = 0; i < count; ++i) traceAfterPressure[i] = m_particles[i].velocity;
        // Smoothing predicts the velocity BEFORE the boundary projection.''')
fluid = replace_once(fluid, '''        std::vector<FluidVelocityContact> velocityContacts;''', '''        for (std::size_t i = 0; i < count; ++i) traceAfterSmoothing[i] = m_particles[i].velocity;
        std::vector<std::size_t> traceContactOrigins;
        std::vector<FluidVelocityContact> velocityContacts;''')
fluid = replace_once(fluid, '''                velocityContacts.push_back({i,c.owner,c.point,c.normal,c.wallVelocity,
                    positions[i],particle.velocity,particle.mass,alpha1,target});''', '''                velocityContacts.push_back({i,c.owner,c.point,c.normal,c.wallVelocity,
                    positions[i],particle.velocity,particle.mass,alpha1,target});
                traceContactOrigins.push_back(k);''')
fluid = replace_once(fluid, '''        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''', r'''        std::size_t traceMaximumParticle = 0;
        float traceSubstepMaximum = 0;
        for (std::size_t i = 0; i < count; ++i) {
            const float speed = glm::length(m_particles[i].velocity);
            if (speed > traceSubstepMaximum) {traceSubstepMaximum = speed; traceMaximumParticle = i;}
        }
        if (traceSubstepMaximum > traceRunningMaximum) {
            traceRunningMaximum = traceSubstepMaximum;
            const std::size_t i = traceMaximumParticle;
            const auto before = traceBeforePressure[i], pressure = traceAfterPressure[i];
            const auto smoothing = traceAfterSmoothing[i], after = m_particles[i].velocity;
            const auto position = m_particles[i].position;
            std::fprintf(stderr,
                "TRANSIENT_MAX call=%u substep=%d particle=%zu h=%.12g speed=%.12g position=(%.12g,%.12g,%.12g) pre_pressure=(%.12g,%.12g,%.12g) post_pressure=(%.12g,%.12g,%.12g) post_smoothing=(%.12g,%.12g,%.12g) post_contact=(%.12g,%.12g,%.12g) pressure_delta=%.12g smoothing_delta=%.12g contact_delta=%.12g\n",
                traceStep,substep,i,substepTime,traceRunningMaximum,position.x,position.y,position.z,
                before.x,before.y,before.z,pressure.x,pressure.y,pressure.z,
                smoothing.x,smoothing.y,smoothing.z,after.x,after.y,after.z,
                glm::length(pressure-before),glm::length(smoothing-pressure),glm::length(after-smoothing));
            const auto represented = representedPressureCorrections[i]/double(substepTime);
            const auto observed = glm::dvec3(pressure)-glm::dvec3(before);
            std::fprintf(stderr,"TRANSIENT_PRESSURE call=%u substep=%d particle=%zu represented=(%.12g,%.12g,%.12g) observed=(%.12g,%.12g,%.12g) residual=%.12g\n",
                traceStep,substep,i,represented.x,represented.y,represented.z,observed.x,observed.y,observed.z,
                glm::length(observed-represented));
            for (std::size_t row = 0; row < velocityContacts.size(); ++row) {
                const auto& c = velocityContacts[row];
                if (c.particleIndex != i) continue;
                const auto& original = contacts[i][traceContactOrigins[row]];
                const auto final = FinalizeSoftContact(original,position,m_settings.particleRadius,substepTime);
                const int kind = original.box ? 1 : original.sphere ? 2 : original.terrain ? 3 : 0;
                std::fprintf(stderr,
                    "TRANSIENT_CONTACT call=%u substep=%d particle=%zu row=%zu owner=%u kind=%d hard=%d witness=%d active=%d preferred=%d target=%.12g physical_gap=%.12g plane_gap=%.12g normal=(%.12g,%.12g,%.12g) wall=(%.12g,%.12g,%.12g) point=(%.12g,%.12g,%.12g) closest_normal=(%.12g,%.12g,%.12g) closest_point=(%.12g,%.12g,%.12g) impulse=(%.12g,%.12g,%.12g) before_relative=%.12g after_relative=%.12g residual=%.12g\n",
                    traceStep,substep,i,row,c.owner.id,kind,int(original.hardEncounter),int(original.displacementWitness),int(final.active),int(final.preferredFeasible),
                    c.minimumNormalVelocity,final.gap,glm::dot(position-c.point,c.normal),
                    c.normal.x,c.normal.y,c.normal.z,c.wallVelocity.x,c.wallVelocity.y,c.wallVelocity.z,
                    c.point.x,c.point.y,c.point.z,final.physical.normal.x,final.physical.normal.y,final.physical.normal.z,
                    final.physical.point.x,final.physical.point.y,final.physical.point.z,
                    impulses[row].x,impulses[row].y,impulses[row].z,
                    glm::dot(smoothing-c.wallVelocity,c.normal),glm::dot(after-c.wallVelocity,c.normal),
                    c.minimumNormalVelocity-glm::dot(after-c.wallVelocity,c.normal));
            }
        }
        m_velocityMilliseconds+=ElapsedFluidMs(phaseStart);''')
(out / 'FluidWorld-final-phase.cpp').write_text(fluid)

pool = original.read_text()
pool = pool.replace('#include <stdexcept>', '#include <stdexcept>\n#include <cstdint>\n#include <cstring>\n#include <iomanip>')
pool = replace_once(pool, '''    auto tick = [&](int frames) {''', r'''    // Passive bitwise digests exclude clocks, profiling and diagnostic fields.
    // All gameplay inputs, phase lengths and original acceptance tests remain unchanged.
    const auto appendWord = [](std::uint64_t& hash, std::uint32_t value) {
        for (int byte = 0; byte < 4; ++byte) {
            hash ^= (value >> (8*byte)) & 255;
            hash *= UINT64_C(1099511628211);
        }
    };
    const auto appendFloat = [&](std::uint64_t& hash, float value) {
        std::uint32_t bits;
        std::memcpy(&bits,&value,sizeof(bits));
        appendWord(hash,bits);
    };
    const auto appendVector = [&](std::uint64_t& hash, const glm::vec3& value) {
        appendFloat(hash,value.x);appendFloat(hash,value.y);appendFloat(hash,value.z);
    };
    const auto appendState = [&](std::uint64_t& hash) {
        appendWord(hash,static_cast<std::uint32_t>(world.Fluid().Particles().size()));
        for (const auto& particle : world.Fluid().Particles()) {
            appendVector(hash,particle.position);appendVector(hash,particle.velocity);
            appendFloat(hash,particle.mass);
        }
        appendVector(hash,session.Player().GetPosition());
        appendVector(hash,session.Player().GetVelocity());
        const auto orientation = session.Player().GetOrientation();
        appendFloat(hash,orientation.w);appendFloat(hash,orientation.x);
        appendFloat(hash,orientation.y);appendFloat(hash,orientation.z);
        appendWord(hash,static_cast<std::uint32_t>(world.DynamicBodies().size()));
        for (const auto& body : world.DynamicBodies()) {
            const auto handle = body.Handle();
            const auto pose = world.Physics().GetTransform(handle);
            appendWord(hash,handle.id);
            appendVector(hash,pose.position);
            appendFloat(hash,pose.rotation.w);appendFloat(hash,pose.rotation.x);
            appendFloat(hash,pose.rotation.y);appendFloat(hash,pose.rotation.z);
            appendVector(hash,world.Physics().GetLinearVelocity(handle));
            appendVector(hash,world.Physics().GetAngularVelocity(handle));
        }
    };
    std::uint64_t trajectory = UINT64_C(14695981039346656037);
    unsigned frame = 0;
    auto tick = [&](int frames) {''')
pool = replace_once(pool, '''            StepPlayedWorld(session, window, 1.f / 60);''', '''            StepPlayedWorld(session, window, 1.f / 60);
            appendWord(trajectory,++frame);
            appendState(trajectory);''')
pool = replace_once(pool, '''        std::cout << "phase_end frames=" << frames << " outside=" << escapes << '\\n';''', '''        std::cout << "phase_end frames=" << frames << " outside=" << escapes << '\\n';
        std::cout << "phase_digest frame=" << frame << " hash=" << std::hex << trajectory << std::dec << '\\n';''')
pool = replace_once(pool, '''    return !(count == 1440''', '''    std::uint64_t endpoint = UINT64_C(14695981039346656037);
    appendState(endpoint);
    std::cout << "trajectory_digest=" << std::hex << trajectory << " endpoint_digest=" << endpoint << std::dec << '\\n';
    return !(count == 1440''')
(out / 'pool_probe_digest.cpp').write_text(pool)

flags = (build / 'CMakeFiles/judas_rendering_architecture_tests.dir/flags.make').read_text()
get = lambda key: shlex.split(next(line.split(' = ',1)[1] for line in flags.splitlines() if line.startswith(key+' = ')))
link = shlex.split((build / 'CMakeFiles/judas_rendering_architecture_tests.dir/link.txt').read_text())
prefix = ['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
tail = link[link.index('libjudas_engine.a'):]
commands = [
    prefix + ['-c',str(out/'FluidWorld-final-phase.cpp'),'-o',str(out/'FluidWorld-final-phase.o')],
    prefix + [str(out/'pool_probe_peak.original.cpp'),'-o',str(out/'pool_original'),*tail],
    prefix + [str(out/'pool_probe_digest.cpp'),'-o',str(out/'pool_digest'),*tail],
    prefix + [str(out/'pool_probe_digest.cpp'),str(out/'FluidWorld-final-phase.o'),'-o',str(out/'pool_phase'),*tail],
]
(out / 'build-commands.txt').write_text('\n'.join(shlex.join(command) for command in commands)+'\n')
for index,command in enumerate(commands):
    result = subprocess.run(command,cwd=build,capture_output=True,text=True)
    (out/f'build-{index}.log').write_text(result.stdout+result.stderr)
    print('build',index,result.returncode,flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
paths = [original,root/'src/FluidWorld.cpp',root/'src/FluidWorld.h',root/'src/PhysicsWorld.h',root/'src/physics/WorldParticles.cpp',root/'src/ProductionFluidCoupling.cpp',build/'libjudas_engine.a',root/'tests/FluidContactClearanceTests.cpp',
         root/'projects/fluid_comparison/Scenes/rectangular_pool.judas',
         out/'FluidWorld-original.cpp',out/'FluidWorld-final-phase.cpp',out/'pool_probe_digest.cpp',
         out/'pool_original',out/'pool_digest',out/'pool_phase']
(out/'PREPARATION_SHA256SUMS.txt').write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(root))+'\n' for path in paths))
(out/'PROVENANCE.json').write_text(json.dumps({'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'build_directory':str(build),'source':str(original),'policy':'Experimental private diagnostic; published Alpha fluid lock unchanged',
    'passivity':'Only copies and logging/digests; same physics inputs and acceptance expression. Phase diagnostic changes measured wall-time, not physics.'},indent=2)+'\n')
print('Prepared only: full pool runs remain HELD pending parent authorization.',flush=True)
