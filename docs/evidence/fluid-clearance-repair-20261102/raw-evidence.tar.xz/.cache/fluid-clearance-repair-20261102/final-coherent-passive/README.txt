Coherent final-source passive validation (2026-11-02)

Freshly generated from production sourcee01571e1... and complete current archive.
Prior failed evidence in ../final-passive remains intact. No old instrumented
source was reused. prepare.py and build-commands.txt reproduce generation/build.

Two ordinary digest runs and one passive phase run PASS the unchanged original
pool acceptance.645frames at1/60s:1440particles/180000kg exactly conserved,
all finite, no escaped particles, player enters/exits and is grounded on exit.
Published-frame peak9.6519m/s. Trajectoryd7594a1ae82ca7cf and endpoint
f5a59cbb035e3268 agree bit-for-bit across all3runs. Ordinary logs are identical.
RUN_RESULTS.json records binary/log hashes, exit codes and execution times;
those times are not a performance claim, especially the instrumented run.

The largest intermediate substep speed10.629775m/s occurs atcall261/sub0/id4.
Pressure adds4.775019m/s, matching represented PBF positional correction within
1.1142e-7m/s. Smoothing reduces speed; static floor/wall contacts removeY/Z
velocity, leaving X=-10.629775. There is no opposing-contact amplification at
this final maximum. ATTRIBUTION.json preserves exact phase vectors/contact rows.

This qualifies the specific reproduced contact episode and rectangular fixture,
not every fluid transient. Legacy planetary/high-speed fluid limitations remain
separate, and no advanced-fluid release policy was changed by this reviewer.

Review: displacementWitness tracks chosen positional geometry separately from
immutable initial-drift collision response. Rollback restores previously chosen
rows, re-adds rejected soft encounters without displacement ownership, and OR
coalescing preserves a genuine selected witness without promoting false-only
history. Marker ownership ignores rejected history; existing marker continuation
still independently validates actual geometric proximity and cell support.
