#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cstdio>
int main(){
 const auto tilt=glm::angleAxis(-.08f,glm::vec3(1,0,0));const glm::vec3 p(0,.18f,0),center(0,.38f,0),half(.5f,.1f,.5f);
 const auto local=glm::inverse(tilt)*(p-center);const auto closest=glm::clamp(local,-half,half);const auto gap=glm::length(local-closest);const auto normal=glm::normalize(tilt*(local-closest));const glm::vec3 wall(0,-2.5f,0);const float h=.04f,target=-gap/h,relative=glm::dot(-wall,normal);const auto delta=std::max(0.f,target-relative)*normal;
 std::printf("gap=%.12g target=%.12g relative=%.12g predicted_gap_if_unchanged=%.12g expected_v=(%.12g,%.12g,%.12g) floor_final_gap=%.12g\n",gap,target,relative,gap+h*relative,delta.x,delta.y,delta.z,.18f+h*delta.y);
}
