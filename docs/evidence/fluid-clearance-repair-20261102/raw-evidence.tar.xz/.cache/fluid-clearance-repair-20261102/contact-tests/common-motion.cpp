#include <glm/gtc/quaternion.hpp>
#include <array>
#include <cmath>
#include <cstdio>
int main() {
 const auto q=glm::angleAxis(.71f,glm::normalize(glm::vec3(1,-2,3)));
 const auto n=glm::normalize(glm::vec3(.2527f,-.0102f,-.9675f));
 const glm::vec3 p(0,.18f,.18f);
 const std::array<glm::vec3,3> centers{q*glm::vec3(0,-.25f,0),q*glm::vec3(0,0,-.25f),q*(p-n*(.18f+.1f-1e-6f))};
 for(int k=1;k<=22;++k) {
  const auto delta=glm::vec3(3,-1,2)*std::ldexp(1.f,-k);
  bool exact=true;
  for(const auto& start:centers) exact &= glm::dvec3(start+delta)-glm::dvec3(start)==glm::dvec3(delta);
  if(exact)std::printf("EXACT k=%d delta=(%.12g %.12g %.12g)\n",k,delta.x,delta.y,delta.z);
 }
}
