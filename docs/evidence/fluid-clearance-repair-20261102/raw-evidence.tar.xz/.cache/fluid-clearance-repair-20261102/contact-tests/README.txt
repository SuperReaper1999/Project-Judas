Contact clearance regression experiment, 2026-11-02

Final production-facing tests: tests/FluidContactClearanceTests.cpp.
Final candidate: 291 checks, 0 failures (final-candidate.log).
Preserved position-fit-only implementation: 291 checks, 6 failures
(final-position-fit-only.log); all failures concern closing opposing soft skins.
Original targeted tests before adding the competing-normal fixture: 259/259
(candidate.log and pre-competing.cpp).

No production source was edited by this reviewer. The final test source and
source/results/executable hashes are retained here. The parent owns CMake and
all implementation changes. Tests were linked from current FluidWorld.o,
WorldParticles.o and ProductionFluidCoupling.o overrides before the existing
engine archive, to keep the appended contact-structure field ABI consistent.
The exact final compile command is final-compile-command.txt; execute it from
.cache/2d-stage1-build, then run final_clearance_tests. The position-fit-only
source was copied verbatim from ../position-fit-only/src/FluidWorld.cpp into
this directory before compilation so quoted includes use the same production
headers instead of creating duplicate pragma-once header identities.

Known-answer controls include original captured velocity rows, real thin-wall
sweeps, noncontact closing wedges, nearest box corner revalidation, mass/count,
actual material wall velocity, native and fallback response, rigid-support vs
fluid-substep horizon, geometry order, one/three substeps, arbitrary rotations,
and feasible single/orthogonal preferred skins.

The all-skins-fit fixture has 18 cm physical gaps, a 6 cm moving-wall interval,
and a 1 micrometre preferred-skin overlap to guarantee retained endpoint contact
inside the existing arithmetic feasibility band. Under position-fit-only code,
native response creates about 23.396 m/s; the corrected soft-group policy leaves
the original 0.001414 m/s unchanged. The stationary controls add no kinetic
energy. This does not prove general rotating finite-body CCD or a complete
fluid pressure/transport scheme; those remain independent qualification.

No tests, acceptance thresholds, research, fluid lock or production budgets
were weakened. The abandoned exact-endpoint fixture missed the moving soft row
through ordinary roundoff and is preserved as competing-no-hit.cpp rather than
being treated as a valid negative control.
