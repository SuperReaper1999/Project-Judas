from pathlib import Path
import subprocess,shlex,json,hashlib,datetime
root=Path.cwd().resolve()
out=root/'.cache/fluid-transient-20261102/original-mechanism-control'
build=root/'.cache/2d-stage1-build'
commit='35db07d0'
commands=[]
def run(command,**kwargs):
    commands.append({'argv':command,'cwd':str(kwargs.get('cwd',root))})
    return subprocess.run(command,**kwargs)
for source in ['src/FluidWorld.cpp','src/physics/WorldParticles.cpp']:
    target=out/Path(source).name
    target.write_bytes(subprocess.check_output(['git','show',f'{commit}:{source}'],cwd=root))
flags=(build/'CMakeFiles/judas_rendering_architecture_tests.dir/flags.make').read_text()
get=lambda key:shlex.split(next(l.split(' = ',1)[1] for l in flags.splitlines() if l.startswith(key+' = ')))
compile_flags=[*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(root/'src/physics'),*get('CXX_FLAGS')]
objects=[]
with (out/'build.log').open('w') as log:
 for name in ['FluidWorld','WorldParticles']:
    obj=out/(name+'.o');objects.append(str(obj))
    run(['c++',*compile_flags,'-c',str(out/(name+'.cpp')),'-o',str(obj)],stdout=log,stderr=subprocess.STDOUT,check=True)
 link=shlex.split((build/'CMakeFiles/judas_rendering_architecture_tests.dir/link.txt').read_text())
 libraries=link[link.index('libjudas_engine.a'):]
 binary=out/'fluid_clearance_original_mechanism'
 run(['c++',*compile_flags,str(root/'tests/FluidContactClearanceTests.cpp'),*objects,'-o',str(binary),*libraries],cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
with (out/'original-mechanism.log').open('w') as log:
 result=run([str(binary)],stdout=log,stderr=subprocess.STDOUT)
record={'classification':'Original source behavior from git35db07d0 recompiled against current headers/layout and linked as object overrides before the current engine archive. This is not an old released binary, and no old-binary/new-header ABI mixture is used.',
        'originalSourceCommit':subprocess.check_output(['git','rev-parse',commit],cwd=root,text=True).strip(),
        'currentCheckout':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode,'commands':commands,'sha256':{}}
for path in [out/'FluidWorld.cpp',out/'WorldParticles.cpp',root/'src/FluidWorld.h',root/'src/PhysicsWorld.h',root/'src/physics/WorldInternal.h',root/'tests/FluidContactClearanceTests.cpp',binary,build/'libjudas_engine.a']:
 record['sha256'][str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/'RESULTS.json').write_text(json.dumps(record,indent=2)+'\n')
print('Original-mechanism exit:',result.returncode)
print('\n'.join((out/'original-mechanism.log').read_text().splitlines()[-10:]))
