from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-before-direct'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
impl=p.compile(root/'.cache/fluid-domain-redesign/VolumeDomain.cpp','volume-domain')
main=p.compile(out/'NativeTetraPressureTests.cpp','before-native-tetra-pressure-tests');p.executable(main,'before-native-tetra-pressure-tests',impl)
