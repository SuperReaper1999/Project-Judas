from pathlib import Path
import shlex,subprocess,sys
root=Path.cwd();out=root/'.cache/fluid-contact-repair';build=root/'build'
flags={}
for line in (build/'CMakeFiles/judas_script_tests.dir/flags.make').read_text().splitlines():
 if ' = ' in line:
  k,v=line.split(' = ',1);flags[k]=shlex.split(v)
compile_flags=flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']
def compile(src,name):
 obj=out/(name+'.o');subprocess.run(['/usr/bin/c++',*compile_flags,'-c',str(src),'-o',str(obj)],check=True);return obj
link=shlex.split((build/'CMakeFiles/judas_script_tests.dir/link.txt').read_text());link=[x for x in link if not x.startswith('-Wl,--dependency-file=')]
def executable(obj,name,override=None):
 args=[str(obj) if x.endswith('/tests/ScriptTests.cpp.o') else x for x in link];args[args.index('-o')+1]=str(out/name)
 if override:args.insert(args.index(str(obj))+1,str(override))
 subprocess.run(args,cwd=build,check=True)
if __name__=='__main__':
 name=sys.argv[1];override=compile(Path(sys.argv[2]),name+'-hydro') if len(sys.argv)>2 else None
 for src,kind in [(root/'tests/FluidHydrostaticsTests.cpp','hydro-tests'),(out/'full.cpp','full')]:
  obj=compile(src,kind);executable(obj,name+'-'+kind,override)
