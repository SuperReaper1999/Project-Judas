#pragma once
#include "../fluid-pressure-coupling/PressureProjection.h"
#include <limits>
namespace grid_fluid {
inline bool Finite(glm::dvec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z);}
inline pressure_prototype::Result ProjectTransactional(
    std::vector<pressure_prototype::Point>& points,
    std::vector<pressure_prototype::Body>& bodies,
    const std::vector<pressure_prototype::Row>& rows,unsigned budget,double tolerance){
    if(!(tolerance>0)||!std::isfinite(tolerance))throw std::invalid_argument("pressure tolerance must be finite and positive");
    for(const auto& p:points)if(!Finite(p.velocity)||!(p.inverseMass>=0)||!std::isfinite(p.inverseMass))throw std::invalid_argument("invalid fluid velocity or inverse mass");
    for(const auto& b:bodies){
        if(!Finite(b.velocity)||!Finite(b.angularVelocity)||!(b.inverseMass>=0)||!std::isfinite(b.inverseMass))throw std::invalid_argument("invalid rigid velocity or inverse mass");
        for(int c=0;c<3;++c)if(!Finite(b.inverseInertia[c]))throw std::invalid_argument("invalid rigid inverse inertia");
        const auto& a=b.inverseInertia;
        for(int i=0;i<3;++i){if(a[i][i]<0)throw std::invalid_argument("negative rigid inverse inertia");for(int j=0;j<i;++j){if(a[i][j]!=a[j][i])throw std::invalid_argument("asymmetric rigid inverse inertia");if(a[i][i]*a[j][j]<a[i][j]*a[i][j])throw std::invalid_argument("indefinite rigid inverse inertia");}}
        if(glm::determinant(a)<0)throw std::invalid_argument("indefinite rigid inverse inertia");
    }
    for(const auto& row:rows){if(!std::isfinite(row.maximumRate))throw std::invalid_argument("invalid continuity constraint");
        for(auto g:row.points)if(g.point>=points.size()||!Finite(g.gradient))throw std::invalid_argument("invalid fluid continuity gradient");
        for(auto g:row.bodies)if(g.body>=bodies.size()||!Finite(g.linear)||!Finite(g.angular))throw std::invalid_argument("invalid rigid continuity gradient");
    }
    auto trialPoints=points;auto trialBodies=bodies;
    auto result=pressure_prototype::Project(trialPoints,trialBodies,rows,budget,tolerance);
    bool finite=std::isfinite(result.maximumResidual);for(auto p:trialPoints)finite&=Finite(p.velocity);for(auto b:trialBodies)finite&=Finite(b.velocity)&&Finite(b.angularVelocity);for(auto p:result.pressureImpulse)finite&=std::isfinite(p)&&p>=0;
    result.converged&=finite;
    if(result.converged){points.swap(trialPoints);bodies.swap(trialBodies);}
    return result;
}
}
