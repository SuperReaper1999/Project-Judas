from pathlib import Path
import re,tarfile,hashlib,json,shutil
root=Path.cwd();base=root/'.cache/fluid-domain-redesign';dest=root/'docs/evidence/advanced-fluid-pressure-followup-20261028/stage2';dest.mkdir(exist_ok=True)
files={p.resolve() for p in base.iterdir() if p.is_file() and (p.suffix in ('.h','.cpp','.py','.json','.txt','.log') or p.name.endswith('.stage2-baseline'))}
files.add((root/'.cache/fluid-contact-repair/setup_probes.py').resolve());queue=list(files)
while queue:
 p=queue.pop()
 if not any(x in p.name for x in ('.h','.cpp')):continue
 for name in re.findall(r'^\s*#include\s*"([^"]+)"',p.read_text(),re.M):
  q=(p.parent/name).resolve()
  if q.is_file() and q.is_relative_to(root/'.cache') and q not in files:files.add(q);queue.append(q)
manifest=[dict(path=str(p.relative_to(root)),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)]
archive=dest/'stage2-sources-and-evidence.tar.gz'
if archive.exists():raise SystemExit('refusing to overwrite existing archive')
with tarfile.open(archive,'w:gz') as out:
 for row in manifest:out.add(root/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive) as inp:
 for row in manifest:assert hashlib.sha256(inp.extractfile(row['path']).read()).hexdigest()==row['sha256']
(dest/'SOURCE_MANIFEST.json').write_text(json.dumps(dict(baseRevision='0f78c76a5a5113d5b59586596dccb076bce910f2',scope='Local numerical prototype sources and evidence, NOT integrated engine backend',files=manifest),indent=2)+'\n')
(dest/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for name in ['STAGE2_REPRODUCE.txt','STAGE2_HANDOFF.txt','PHASE2_RESULTS.json','STAGE2_ADDITIONAL_RESULTS.json','CACHE_MATCHED.json','operator-cache-tests.log','material-moments-tests.log','geometry-exact.log','mass-original-reproduced.log','field-divergence-original.log','owned-capacity-tests.log']:
 p=base/name
 if p.exists():shutil.copy2(p,dest/name)
print('Verified source archive',len(manifest),'members',archive.stat().st_size,'bytes')
