from pathlib import Path
import sys,subprocess
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
implementation=p.compile(out/'VolumeDomain.cpp','volume-domain')
tests=p.compile(out/'WetTetraOracleTests.cpp','wet-tetra-oracle-tests')
p.executable(tests,'wet-tetra-oracle-tests',implementation)
