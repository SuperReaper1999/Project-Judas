#pragma once
#include "PistonSpaceTimeMesh.h"
#include "ConformingCutMesh.h"
namespace fluid_ale_fixture {
struct Compiled {fluid_mesh::Compiler mesh;std::vector<unsigned> source;};
inline Compiled Compile(const fluid_ale::Mesh& motion,double t,const std::vector<fluid_exact::Plane>& body={}){
 Compiled result;
 for(const auto& plane:body)result.mesh.bodyPlanes.push_back(result.mesh.AddPlane(V(plane.normal[0],plane.normal[1],plane.normal[2]),plane.coordinate));
 for(unsigned v=0;v<motion.before.size();++v){V p=motion.Position(v,t);fluid_mesh::Triple planes;std::array<fluid_exact::Plane,3> owned;for(unsigned a=0;a<3;++a){V n(0);n[a]=1;planes[a]=result.mesh.AddPlane(n,p[a]);owned[a]=result.mesh.planes.back();}result.mesh.vertices.push_back({fluid_exact::Intersection::Make(owned),planes,p});}
 for(unsigned c=0;c<motion.cells.size();++c){const auto& ids=motion.cells[c];LiquidTet tet;for(unsigned i=0;i<4;++i)tet[i]=result.mesh.vertices[ids[i]].position;const auto data=fluid_ale::Measure(tet);if(data.volume==0)continue;result.mesh.tetrahedra.push_back({tet,ids,c});result.source.push_back(c);}return result;
}
}
