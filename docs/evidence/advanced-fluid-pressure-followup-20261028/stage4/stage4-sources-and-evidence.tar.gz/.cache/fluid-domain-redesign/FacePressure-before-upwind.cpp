#include "FacePressure.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace fluid_domain {
PressureStep ProjectFaces(const VolumeDomain& domain, double dt,
    const std::vector<Face>& inputFaces,
    const std::vector<pressure_prototype::Body>& inputBodies,
    const std::vector<CapacityWrench>& wrenches) {
    PressureStep result;
    if (!(dt > 0) || !std::isfinite(dt)) {
        result.error = "pressure interval must be finite and positive";
        return result;
    }
    std::map<Key, pressure_prototype::Row> upper, lower;
    std::vector<pressure_prototype::Point> points;
    std::vector<double> areas;
    std::vector<pressure_prototype::Row> directionRows;
    const auto touch = [&](Key key) {
        const auto* cell = domain.Find(key);
        if (!cell) return false;
        upper[key].maximumRate = (cell->capacity - cell->volume) / dt;
        lower[key].maximumRate = cell->volume / dt;
        return true;
    };
    for (unsigned i = 0; i < inputFaces.size(); ++i) {
        const auto& face = inputFaces[i];
        if (!(face.mass > 0) || !std::isfinite(face.mass) || !std::isfinite(face.velocity) ||
            !touch(face.a) || !touch(face.b)) {
            result.error = "invalid pressure face or effective fluid mass";
            return result;
        }
        std::string error;
        const double forward = domain.SharedWetAperture(face.a, face.b, error);
        if (!error.empty()) { result.error = error; return result; }
        const double reverse = domain.SharedWetAperture(face.b, face.a, error);
        if (!error.empty()) { result.error = error; return result; }
        const double area = std::max(forward, reverse);
        if (!(area > 0)) { result.error = "pressure face has no wet aperture"; return result; }
        const double tolerance = 256 * std::numeric_limits<double>::epsilon() * area;
        if (forward > 0 && reverse > 0 && std::abs(forward - reverse) > tolerance) {
            result.error = "asymmetric partially-wet aperture needs upwind space-time geometry";
            return result;
        }
        points.push_back({glm::dvec3(face.velocity, 0, 0), 1 / face.mass});
        areas.push_back(area);
        upper[face.a].points.push_back({i, {-area, 0, 0}});
        upper[face.b].points.push_back({i, {area, 0, 0}});
        lower[face.a].points.push_back({i, {area, 0, 0}});
        lower[face.b].points.push_back({i, {-area, 0, 0}});
        if (forward == 0) directionRows.push_back({{{i, {1, 0, 0}}}, {}, 0});
        if (reverse == 0) directionRows.push_back({{{i, {-1, 0, 0}}}, {}, 0});
    }
    for (const auto& wrench : wrenches) {
        if (!touch(wrench.cell) || wrench.body >= inputBodies.size()) {
            result.error = "invalid moving-capacity owner";
            return result;
        }
        upper[wrench.cell].bodies.push_back({wrench.body, wrench.linear, wrench.angular});
    }
    std::vector<pressure_prototype::Row> rows;
    // Aggregate every wrench on a physical owner before forming its inverse
    // mass. Multiple boundary patches are not independently moving bodies.
    for (auto& entry : upper) {
        std::map<unsigned, std::pair<glm::dvec3, glm::dvec3>> aggregate;
        for (auto g : entry.second.bodies) {
            auto it = aggregate.find(g.body);
            if (it == aggregate.end()) aggregate.emplace(g.body, std::make_pair(g.linear,g.angular));
            else { it->second.first += g.linear; it->second.second += g.angular; }
        }
        entry.second.bodies.clear();
        for (auto& g : aggregate)
            entry.second.bodies.push_back({g.first,g.second.first,g.second.second});
        rows.push_back(entry.second);
        rows.push_back(lower.at(entry.first));
    }
    rows.insert(rows.end(), directionRows.begin(), directionRows.end());
    auto bodies = inputBodies;
    try {
        result.solver = grid_fluid::ProjectTransactional(points, bodies, rows, 256, 1e-9);
    } catch (const std::exception& error) {
        result.error = error.what();
        return result;
    }
    if (!result.solver.converged) {
        result.error = "cell pressure projection did not converge";
        return result;
    }
    result.faces = inputFaces;
    result.bodies = std::move(bodies);
    for (unsigned i = 0; i < result.faces.size(); ++i) {
        auto& face = result.faces[i];
        face.velocity = points[i].velocity.x;
        const double volume = face.velocity * areas[i] * dt;
        if (volume > 0) result.transfers.push_back({face.a,face.b,volume});
        if (volume < 0) result.transfers.push_back({face.b,face.a,-volume});
    }
    result.converged = true;
    return result;
}
} // namespace fluid_domain
