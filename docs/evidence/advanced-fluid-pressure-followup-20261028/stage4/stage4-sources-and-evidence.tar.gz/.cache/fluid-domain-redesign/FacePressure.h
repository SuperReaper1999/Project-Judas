#pragma once

#include "VolumeDomain.h"
#include "../fluid-grid-redesign/TransactionalProjection.h"

namespace fluid_domain {

struct Face {
    Key a, b;
    // The effective mass belongs to this staggered velocity degree of freedom.
    // It must come from its actual fluid support, not a rigid body's volume.
    double mass = 0;
    double velocity = 0;
};
struct CapacityWrench {
    Key cell;
    unsigned body = 0;
    // Negative derivative of void capacity w.r.t. body translation/rotation.
    glm::dvec3 linear{0}, angular{0};
};
struct PressureStep {
    bool converged = false;
    unsigned upwindPasses = 0;
    pressure_prototype::Result solver;
    std::vector<Face> faces;
    std::vector<pressure_prototype::Body> bodies;
    std::vector<Transfer> transfers;
    std::string error;
};

// Momentum/continuity projection only. It stages output; callers must validate
// resolved geometry and publish quantity and momentum at the same boundary.
// Upwind aperture selection is staged and shares one bounded solve budget.
PressureStep ProjectFaces(const VolumeDomain&, double dt,
    const std::vector<Face>&, const std::vector<pressure_prototype::Body>&,
    const std::vector<CapacityWrench>&);

} // namespace fluid_domain
