#define main retained_finite_front_pressure_main
#include "CompiledPressureTests.cpp"
#undef main
#include "AleWindProjection.h"
#include "FiniteFrontGeometry.h"
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* text){++checks;if(!ok){++failures;std::printf("FAIL %s\n",text);}};const double dt=double(1.f/60.f)/4;
 for(double velocity:{.02,.2}){fluid_front::Motion m;m.oldHeight=.649;m.newHeight=.6488;m.owned=1.5;m.thickness=.2;m.dt=dt;m.initial={0,.849,.002};m.horizontal=velocity;m.vertical=.04;auto geometry=fluid_front::Prepare(m);
  for(double time:{0.,.1,.5,.9,1.}){double volume=0;for(const auto& cell:geometry.mesh.cells){LiquidTet t;for(unsigned i=0;i<4;++i)t[i]=geometry.mesh.Position(cell[i],time);volume+=fluid_ale::Measure(t).volume;}check(std::abs(volume-m.owned)<1e-12,"front and nonlinear storage retain actual geometric quantity at interior times");auto s=m.At(time);check(s.width<=velocity*dt+1e-15,"newly wet front cannot fill a whole cell instantaneously");}
  std::vector<unsigned> source;auto active=fluid_front::Active(geometry.mesh,source);std::vector<fluid_ale::Field> physical(active.cells.size());for(auto& f:physical)f.value={-.03,.04,.01};constexpr double root=.77459666924148337704;const std::array<double,3> times{.5*(1-root),.5,.5*(1+root)};std::array<fluid_ale_fixture::WindResult,3> wind;
  for(unsigned i=0;i<3;++i){wind[i]=fluid_ale_fixture::ProjectWind(active,physical,times[i],dt);check(wind[i].accepted,"finite incoming geometry has a bounded compatible transport field");std::printf("FRONT_WIND u=%g t=%g accepted=%d residual=%g divergence=%g gauge=%g error=%s\n",velocity,times[i],wind[i].accepted,wind[i].residual,wind[i].divergence,wind[i].gaugeError,wind[i].error.c_str());}
  if(wind[0].accepted&&wind[1].accepted&&wind[2].accepted){auto result=fluid_ale::Advance(active,physical,dt,1000,[&](unsigned c,V x,double time){unsigned i=0;while(i<3&&std::abs(times[i]-time)>1e-14)++i;if(i==3)throw std::runtime_error("unknown temporal quadrature");return fluid_ale::Evaluate(wind[i].fields[c],x);});check(result.accepted,"finite-front birth satisfies full GCL and physical transport energy identity");std::printf("FINITE_FRONT u=%g width=%g packet=%g accepted=%d gcl=%g c0=%g energy=%g error=%s\n",velocity,m.At(1).width,m.PacketVolume(1),result.accepted,result.matrixGclError,result.constantError,result.energyIdentityError,result.error.c_str());}
 }
 std::printf("FINITE_FRONT checks=%u failures=%u\n",checks,failures);return failures?1:0;}
