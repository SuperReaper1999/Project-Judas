#pragma once
#include "MixedProjection.h"
#include <map>
#include <set>
#include <numeric>
#include <chrono>
// Disposable sparse Cholesky reference. No diagonal regularization or added
// physical compliance; every pivot must be positive in the barrier system.
struct SparseFactor {
 unsigned n;std::vector<unsigned> order,inverse;std::vector<std::vector<unsigned>> columns;
 std::vector<std::vector<double>> source;
 SparseFactor(const std::vector<std::map<unsigned,double>>& a):n(a.size()),order(n),inverse(n),columns(n),source(n){
  std::vector<std::set<unsigned>> graph(n);for(unsigned i=0;i<n;++i)for(auto [j,v]:a[i])if(i!=j&&v!=0){graph[i].insert(j);graph[j].insert(i);}
  std::set<std::pair<unsigned,unsigned>> queue;std::vector<bool> active(n,true);for(unsigned i=0;i<n;++i)queue.emplace(graph[i].size(),i);
  std::vector<std::vector<unsigned>> neighbors(n);
  for(unsigned k=0;k<n;++k){auto [degree,i]=*queue.begin();queue.erase(queue.begin());order[k]=i;inverse[i]=k;active[i]=false;neighbors[k].assign(graph[i].begin(),graph[i].end());
   for(auto j:neighbors[k]){queue.erase({unsigned(graph[j].size()),j});graph[j].erase(i);}
   for(auto j:neighbors[k])for(auto l:neighbors[k])if(j!=l)graph[j].insert(l);
   for(auto j:neighbors[k])queue.emplace(graph[j].size(),j);
  }
  for(unsigned k=0;k<n;++k){columns[k].push_back(k);for(auto j:neighbors[k])columns[k].push_back(inverse[j]);std::sort(columns[k].begin()+1,columns[k].end());source[k].resize(columns[k].size());for(unsigned t=0;t<columns[k].size();++t){const auto i=order[k],j=order[columns[k][t]];auto f=a[std::min(i,j)].find(std::max(i,j));source[k][t]=f==a[std::min(i,j)].end()?0:f->second;}}
 }
 std::vector<std::vector<double>> Factor(const std::vector<double>& diagonal)const{
  auto values=source;for(unsigned k=0;k<n;++k)values[k][0]+=diagonal[order[k]];
  for(unsigned k=0;k<n;++k){auto& col=values[k];const double pivot=col[0];if(!(pivot>0)||!std::isfinite(pivot))throw std::runtime_error("nonpositive sparse physical pivot");col[0]=std::sqrt(pivot);for(unsigned t=1;t<col.size();++t)col[t]/=col[0];
   for(unsigned t=1;t<col.size();++t){const unsigned j=columns[k][t];auto begin=columns[j].begin();for(unsigned u=t;u<col.size();++u){const unsigned l=columns[k][u];auto at=std::lower_bound(begin,columns[j].end(),l);if(at==columns[j].end()||*at!=l)throw std::runtime_error("missing symbolic fill");values[j][at-columns[j].begin()]-=col[t]*col[u];begin=at;}}
  }
  return values;
 }
 std::vector<double> Solve(const std::vector<double>& rhs,const std::vector<std::vector<double>>& values)const{
  std::vector<double> x(n);for(unsigned k=0;k<n;++k)x[k]=rhs[order[k]];
  for(unsigned k=0;k<n;++k){x[k]/=values[k][0];for(unsigned t=1;t<values[k].size();++t)x[columns[k][t]]-=values[k][t]*x[k];}
  for(unsigned k=n;k-->0;){for(unsigned t=1;t<values[k].size();++t)x[k]-=values[k][t]*x[columns[k][t]];x[k]/=values[k][0];}
  std::vector<double> result(n);for(unsigned k=0;k<n;++k)result[order[k]]=x[k];return result;
 }
};
inline pressure_prototype::Result SparseInterior(std::vector<pressure_prototype::Point>& points,std::vector<pressure_prototype::Body>& bodies,const std::vector<pressure_prototype::Row>& rows,const std::vector<bool>& bilateral,unsigned budget,double tolerance){
 using namespace pressure_prototype;Result result;const unsigned n=rows.size();result.pressureImpulse.assign(n,0);
 std::vector<std::map<unsigned,double>> matrix(n);std::vector<std::vector<std::pair<unsigned,glm::dvec3>>> incident(points.size());
 for(unsigned i=0;i<n;++i)for(auto g:rows[i].points)incident[g.point].push_back({i,g.gradient});
 for(unsigned p=0;p<incident.size();++p)for(auto [i,a]:incident[p])for(auto [j,b]:incident[p])if(i<=j)matrix[i][j]+=points[p].inverseMass*glm::dot(a,b);
 for(unsigned b=0;b<bodies.size();++b){std::vector<std::pair<unsigned,BodyGradient>> list;for(unsigned i=0;i<n;++i)for(auto g:rows[i].bodies)if(g.body==b)list.push_back({i,g});for(auto [i,a]:list)for(auto [j,c]:list)if(i<=j)matrix[i][j]+=bodies[b].inverseMass*glm::dot(a.linear,c.linear)+glm::dot(a.angular,bodies[b].inverseInertia*c.angular);}
 std::vector<double> scale(n),rhs(n),lambda(n,0),z(n,0);unsigned contacts=0;
 for(unsigned i=0;i<n;++i){double d=matrix[i][i];if(!(d>0))throw std::runtime_error("empty pressure constraint");scale[i]=1/std::sqrt(d);double v=-rows[i].maximumRate;for(auto g:rows[i].points)v+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)v+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);rhs[i]=v*scale[i];if(!bilateral[i]){lambda[i]=z[i]=1;++contacts;}}
 for(unsigned i=0;i<n;++i)for(auto& [j,v]:matrix[i])v*=scale[i]*scale[j];
 auto setupStart=std::chrono::steady_clock::now();SparseFactor factor(matrix);double factorMs=0;double setupMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-setupStart).count();
 auto multiply=[&](const std::vector<double>& x){std::vector<double> output(n,0);for(unsigned i=0;i<n;++i)for(auto [j,v]:matrix[i]){output[i]+=v*x[j];if(i!=j)output[j]+=v*x[i];}++result.matrixProducts;return output;};
 std::vector<std::vector<double>> numericalFactor;
 auto direction=[&](const std::vector<double>& residual,const std::vector<double>& comp,std::vector<double>& dl,std::vector<double>& dz){std::vector<double> diagonal(n,0),r(n);for(unsigned i=0;i<n;++i){r[i]=-residual[i];if(!bilateral[i]){diagonal[i]=z[i]/lambda[i];r[i]-=comp[i]/lambda[i];}}auto solveStart=std::chrono::steady_clock::now();if(numericalFactor.empty())numericalFactor=factor.Factor(diagonal);dl=factor.Solve(r,numericalFactor);factorMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-solveStart).count();dz=multiply(dl);for(unsigned i=0;i<n;++i)dz[i]+=residual[i];};
 auto step=[&](const std::vector<double>& x,const std::vector<double>& dx){double alpha=1;for(unsigned i=0;i<n;++i)if(!bilateral[i]&&dx[i]<0)alpha=std::min(alpha,-x[i]/dx[i]);return alpha;};
 bool solved=false;
 for(unsigned iteration=0;iteration<budget;++iteration){numericalFactor.clear();auto product=multiply(lambda);std::vector<double> residual(n),comp(n,0),dl,dz;double mu=0,physical=0;
  for(unsigned i=0;i<n;++i){const double e=rhs[i]-product[i];double v=bilateral[i]?std::abs(e/scale[i]):std::max(0.,e/scale[i]);if(!bilateral[i])v=std::max(v,std::abs(lambda[i]*e));physical=std::max(physical,v);residual[i]=product[i]-rhs[i]-z[i];if(!bilateral[i]){comp[i]=lambda[i]*z[i];mu+=comp[i];}}if(physical<=tolerance){solved=true;break;}mu/=contacts;
  direction(residual,comp,dl,dz);double ap=step(lambda,dl),ad=step(z,dz),affine=0;for(unsigned i=0;i<n;++i)if(!bilateral[i])affine+=(lambda[i]+ap*dl[i])*(z[i]+ad*dz[i]);affine/=contacts;const double sigma=std::pow(affine/mu,3);
  for(unsigned i=0;i<n;++i)if(!bilateral[i])comp[i]+=dl[i]*dz[i]-sigma*mu;direction(residual,comp,dl,dz);ap=std::min(1.,.995*step(lambda,dl));ad=std::min(1.,.995*step(z,dz));for(unsigned i=0;i<n;++i){lambda[i]+=ap*dl[i];if(!bilateral[i])z[i]+=ad*dz[i];}++result.sweeps;
 }
 std::printf("SPARSE_TIMING symbolic_ms=%.6f factors_ms=%.6f\n",setupMs,factorMs);
 // Failure is transactional: original velocities remain untouched.
 if(!solved){result.maximumResidual=INFINITY;return result;}
 auto originalPoints=points;auto originalBodies=bodies;
 for(unsigned i=0;i<n;++i){const double p=lambda[i]*scale[i];result.pressureImpulse[i]=p;for(auto g:rows[i].points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*p;for(auto g:rows[i].bodies){auto& body=bodies[g.body];body.velocity-=body.inverseMass*g.linear*p;body.angularVelocity-=body.inverseInertia*g.angular*p;}}
 for(unsigned i=0;i<n;++i){double e=-rows[i].maximumRate;for(auto g:rows[i].points)e+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)e+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);double v=bilateral[i]?std::abs(e):std::max(0.,e);if(!bilateral[i])v=std::max(v,std::abs(result.pressureImpulse[i]*e));result.maximumResidual=std::max(result.maximumResidual,v);}
 result.converged=result.maximumResidual<=tolerance;if(!result.converged){points=originalPoints;bodies=originalBodies;}return result;
}
