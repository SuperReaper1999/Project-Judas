#pragma once
#include "MixedProjection.h"
#include <limits>
#include <cstdio>
extern "C" void dsyev_(const char*,const char*,const int*,double*,const int*,double*,double*,const int*,int*);
extern "C" void dposv_(const char*,const int*,const int*,double*,const int*,double*,const int*,int*);
// Disposable rank-aware dense reference, not a production dependency.
inline pressure_prototype::Result DenseMixedReference(
 std::vector<pressure_prototype::Point>& points,std::vector<pressure_prototype::Body>& bodies,
 const std::vector<pressure_prototype::Row>& rows,const std::vector<bool>& bilateral,unsigned budget,double tolerance){
 using namespace pressure_prototype;
 Result result;const unsigned n=rows.size();result.pressureImpulse.assign(n,0);
 auto gram=[&](unsigned i,unsigned j){double value=0;for(auto a:rows[i].points)for(auto b:rows[j].points)if(a.point==b.point)value+=points[a.point].inverseMass*glm::dot(a.gradient,b.gradient);for(auto a:rows[i].bodies)for(auto b:rows[j].bodies)if(a.body==b.body){auto& body=bodies[a.body];value+=body.inverseMass*glm::dot(a.linear,b.linear)+glm::dot(a.angular,body.inverseInertia*b.angular);}return value;};
 auto rate=[&](unsigned i){double v=-rows[i].maximumRate;for(auto g:rows[i].points)v+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)v+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);return v;};
 std::vector<unsigned> eq,con;std::vector<double> scale(n),rhs(n),a(n*n);
 for(unsigned i=0;i<n;++i){scale[i]=1/std::sqrt(gram(i,i));rhs[i]=rate(i)*scale[i];(bilateral[i]?eq:con).push_back(i);}
 for(unsigned j=0;j<n;++j)for(unsigned i=0;i<=j;++i)a[j*n+i]=a[i*n+j]=gram(i,j)*scale[i]*scale[j];
 const int ne=int(eq.size()),nc=int(con.size());std::vector<double> eigen(ne*ne),value(ne),erhs(ne),base(ne,0),cross(ne*nc,0);
 for(int j=0;j<ne;++j){erhs[j]=rhs[eq[j]];for(int i=0;i<ne;++i)eigen[j*ne+i]=a[eq[j]*n+eq[i]];}
 int status=0,length=std::max(1,3*ne);std::vector<double> work(length);const char upper='U',vectors='V';
 dsyev_(&vectors,&upper,&ne,eigen.data(),&ne,value.data(),work.data(),&length,&status);if(status)throw std::runtime_error("reference equality eigen failed");
 const double rankTolerance=64*std::numeric_limits<double>::epsilon()*ne*value.back();
 for(int k=0;k<ne;++k)if(value[k]>rankTolerance){double dot=0;for(int i=0;i<ne;++i)dot+=eigen[k*ne+i]*erhs[i];for(int i=0;i<ne;++i)base[i]+=eigen[k*ne+i]*dot/value[k];
  for(int j=0;j<nc;++j){dot=0;for(int i=0;i<ne;++i)dot+=eigen[k*ne+i]*a[con[j]*n+eq[i]];for(int i=0;i<ne;++i)cross[j*ne+i]+=eigen[k*ne+i]*dot/value[k];}}
 std::vector<double> c(nc*nc),b(nc),lambda(nc,1),z(nc,1);
 for(int j=0;j<nc;++j){b[j]=rhs[con[j]];for(int k=0;k<ne;++k)b[j]-=a[con[j]*n+eq[k]]*base[k];for(int i=0;i<nc;++i){c[j*nc+i]=a[con[j]*n+con[i]];for(int k=0;k<ne;++k)c[j*nc+i]-=a[con[i]*n+eq[k]]*cross[j*ne+k];}}
 auto direction=[&](const std::vector<double>& residual,const std::vector<double>& complement,std::vector<double>& dl,std::vector<double>& dz){auto matrix=c;dl.resize(nc);for(int i=0;i<nc;++i){matrix[i*nc+i]+=z[i]/lambda[i];dl[i]=-residual[i]-complement[i]/lambda[i];}const int one=1;dposv_(&upper,&nc,&one,matrix.data(),&nc,dl.data(),&nc,&status);if(status){std::printf("NEWTON_FACTOR_FAILURE status=%d ne=%d nc=%d min_eigen=%g max_eigen=%g rank_tol=%g min_lambda=%g min_z=%g\n",status,ne,nc,value.front(),value.back(),rankTolerance,*std::min_element(lambda.begin(),lambda.end()),*std::min_element(z.begin(),z.end()));throw std::runtime_error("reference Newton factor failed");}dz=residual;for(int i=0;i<nc;++i)for(int j=0;j<nc;++j)dz[i]+=c[j*nc+i]*dl[j];};
 auto step=[&](const std::vector<double>& x,const std::vector<double>& dx){double alpha=1;for(int i=0;i<nc;++i)if(dx[i]<0)alpha=std::min(alpha,-x[i]/dx[i]);return alpha;};
 for(unsigned iteration=0;iteration<budget;++iteration){std::vector<double> residual(nc),comp(nc),dl,dz;double mu=0,error=0;
  for(int i=0;i<nc;++i){residual[i]=-b[i]-z[i];for(int j=0;j<nc;++j)residual[i]+=c[j*nc+i]*lambda[j];comp[i]=lambda[i]*z[i];mu+=comp[i];error=std::max(error,std::abs(residual[i]));}mu/=nc;std::printf("INTERIOR iteration=%u error=%g mu=%g\n",iteration,error,mu);
  // Stop only on the exact same physical KKT check used after publication.
  std::vector<double> candidate(n,0);for(int i=0;i<ne;++i){candidate[eq[i]]=base[i];for(int j=0;j<nc;++j)candidate[eq[i]]-=cross[j*ne+i]*lambda[j];}for(int i=0;i<nc;++i)candidate[con[i]]=lambda[i];
  double physicalResidual=0;for(unsigned i=0;i<n;++i){double e=rhs[i];for(unsigned j=0;j<n;++j)e-=a[j*n+i]*candidate[j];double violation=bilateral[i]?std::abs(e/scale[i]):std::max(0.,e/scale[i]);if(!bilateral[i])violation=std::max(violation,std::abs(candidate[i]*e));physicalResidual=std::max(physicalResidual,violation);}std::printf("PHYSICAL_KKT %.12g\n",physicalResidual);if(physicalResidual<=tolerance)break;
  direction(residual,comp,dl,dz);double ap=step(lambda,dl),ad=step(z,dz),affine=0;for(int i=0;i<nc;++i)affine+=(lambda[i]+ap*dl[i])*(z[i]+ad*dz[i]);affine/=nc;double sigma=std::pow(affine/mu,3);
  for(int i=0;i<nc;++i)comp[i]+=dl[i]*dz[i]-sigma*mu;direction(residual,comp,dl,dz);ap=std::min(1.,.995*step(lambda,dl));ad=std::min(1.,.995*step(z,dz));for(int i=0;i<nc;++i){lambda[i]+=ap*dl[i];z[i]+=ad*dz[i];}++result.sweeps;
 }
 for(int i=0;i<ne;++i){double v=base[i];for(int j=0;j<nc;++j)v-=cross[j*ne+i]*lambda[j];result.pressureImpulse[eq[i]]=v*scale[eq[i]];}
 for(int i=0;i<nc;++i)result.pressureImpulse[con[i]]=lambda[i]*scale[con[i]];
 for(unsigned i=0;i<n;++i){const double p=result.pressureImpulse[i];for(auto g:rows[i].points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*p;for(auto g:rows[i].bodies){auto& body=bodies[g.body];body.velocity-=body.inverseMass*g.linear*p;body.angularVelocity-=body.inverseInertia*g.angular*p;}}
 for(unsigned i=0;i<n;++i){double violation=bilateral[i]?std::abs(rate(i)):std::max(0.,rate(i));if(!bilateral[i])violation=std::max(violation,std::abs(result.pressureImpulse[i]*rate(i)));result.maximumResidual=std::max(result.maximumResidual,violation);}
 result.converged=result.maximumResidual<=tolerance;return result;
}
