#pragma once
#include "FacePressure.h"

namespace fluid_domain {
struct GeometricFluxStep {
    bool converged = false;
    std::vector<Transfer> transfers;
    pressure_prototype::Result solver;
    double maximumTransferDifference = 0;
    std::string error;
};

// Integrated volumes are the unknowns. Resolved native geometry supplies the
// end-of-interval capacities; a rounded pose is not replaced by velocity*dt.
// This stages a conservative remap BEFORE quantity publication. It never
// changes a cell quantity, repairs a failed Advance, or edits rigid state.
GeometricFluxStep ResolveFlux(const VolumeDomain&, double dt,
    const std::vector<Face>& predictedFaces, const std::vector<CapacityChange>&);
}
