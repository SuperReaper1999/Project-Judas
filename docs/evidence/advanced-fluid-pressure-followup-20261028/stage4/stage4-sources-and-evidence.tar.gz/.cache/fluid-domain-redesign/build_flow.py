from pathlib import Path
import sys,subprocess
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
impl=p.compile(out/'VolumeDomain.cpp','volume-domain');flow=p.compile(out/'FacePressure.cpp','face-pressure')
override=out/'flow-overrides.o';subprocess.run(['c++','-r',str(impl),str(flow),'-o',str(override)],check=True)
main=p.compile(out/'FacePressureTests.cpp','face-pressure-tests');p.executable(main,'face-pressure-tests',override)
