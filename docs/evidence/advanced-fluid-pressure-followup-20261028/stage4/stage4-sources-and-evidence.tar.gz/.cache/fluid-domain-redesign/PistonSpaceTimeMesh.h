#pragma once
#include "AleTransport.h"
#include <glm/gtc/quaternion.hpp>
namespace fluid_ale_fixture {
using V=glm::dvec3;
inline fluid_ale::Mesh Piston(double oldLeft,double newLeft,double total=1.5,glm::dquat rotation={1,0,0,0}){
 fluid_ale::Mesh mesh;std::map<std::array<unsigned,3>,unsigned> owned;
 auto vertex=[&](unsigned x,unsigned level,unsigned z){std::array<unsigned,3> key{x,level,z};auto it=owned.find(key);if(it!=owned.end())return it->second;unsigned id=mesh.before.size();owned[key]=id;const double oldY=level==0?0:level==1?oldLeft:total-oldLeft,newY=level==0?0:level==1?newLeft:total-newLeft;mesh.before.push_back(rotation*V(x,oldY,z));mesh.after.push_back(rotation*V(x,newY,z));return id;};
 constexpr unsigned tets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
 for(unsigned brick=0;brick<3;++brick){const unsigned left=brick==0?0:1,bottom=brick==2?1:0;std::array<unsigned,8> points;for(unsigned i=0;i<8;++i)points[i]=vertex(left+(i&1),bottom+((i>>1)&1),(i>>2)&1);for(const auto& tet:tets)mesh.cells.push_back({points[tet[0]],points[tet[1]],points[tet[2]],points[tet[3]]});}return mesh;
}
inline V Wind(unsigned cell,V world,double t,double oldLeft,double newLeft,double dt,glm::dquat rotation={1,0,0,0}){
 const V x=glm::inverse(rotation)*world;const double height=oldLeft+t*(newLeft-oldLeft),q=(oldLeft-newLeft)/dt;
 V value;if(cell/6==0)value={q*x.x/height,-q*x.y/height,0};else if(cell/6==1)value={q*(2-x.x)/height,q*x.y/height,0};else value={0,q,0};return rotation*value;
}
inline double SurfaceHeight(double left,double total,double thickness){return std::min(total-left,.5*(total+thickness));}
// Five connected-volume bricks; two above-plate bricks are born at overflow.
// A step crossing the geometric event MUST be split by the caller. This is
// transport quadrature subdivision, never a different native physics cadence.
inline fluid_ale::Mesh OverflowDomain(double oldLeft,double newLeft,double total,double thickness){
 const double critical=.5*(total-thickness);
 if((oldLeft-critical)*(newLeft-critical)<0)throw std::invalid_argument("split material geometry at the plate-top event");
 fluid_ale::Mesh mesh;std::map<std::array<unsigned,3>,unsigned> owned;
 auto level=[&](double left,unsigned y){double top=SurfaceHeight(left,total,thickness);return y==0?0.:y==1?left:y==2?std::min(top,left+thickness):top;};
 auto vertex=[&](unsigned x,unsigned y,unsigned z){std::array<unsigned,3> key{x,y,z};auto at=owned.find(key);if(at!=owned.end())return at->second;unsigned id=mesh.before.size();owned[key]=id;mesh.before.push_back(V(x,level(oldLeft,y),z));mesh.after.push_back(V(x,level(newLeft,y),z));return id;};
 constexpr unsigned tets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
 for(unsigned brick=0;brick<5;++brick){unsigned x=brick==0||brick==4?0:1,y=brick==0||brick==1?0:brick==2?1:2;std::array<unsigned,8> p;for(unsigned i=0;i<8;++i)p[i]=vertex(x+(i&1),y+((i>>1)&1),(i>>2)&1);for(const auto& tet:tets)mesh.cells.push_back({p[tet[0]],p[tet[1]],p[tet[2]],p[tet[3]]});}return mesh;
}

}
