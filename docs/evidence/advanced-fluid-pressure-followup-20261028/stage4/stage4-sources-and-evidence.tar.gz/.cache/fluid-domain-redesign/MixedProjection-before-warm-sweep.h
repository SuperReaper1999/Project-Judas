#pragma once
#include "../fluid-pressure-coupling/PressureProjection.h"
namespace pressure_prototype {
inline Result ProjectMixed(std::vector<Point>& points,std::vector<Body>& bodies,
                      const std::vector<Row>& rows,const std::vector<bool>& bilateral,unsigned budget,double tolerance) {
    Result result;result.pressureImpulse.assign(rows.size(),0);
    std::vector<double> diagonal(rows.size());
    auto rate=[&](const Row& row) {
        double value=0;
        for(const auto& g:row.points)value+=glm::dot(g.gradient,points.at(g.point).velocity);
        for(const auto& g:row.bodies) {
            const auto& b=bodies.at(g.body);
            value+=glm::dot(g.linear,b.velocity)+glm::dot(g.angular,b.angularVelocity);
        }
        return value;
    };
    for(unsigned i=0;i<rows.size();++i) {
        for(const auto& g:rows[i].points)diagonal[i]+=points.at(g.point).inverseMass*glm::dot(g.gradient,g.gradient);
        for(const auto& g:rows[i].bodies) {
            const auto& b=bodies.at(g.body);
            diagonal[i]+=b.inverseMass*glm::dot(g.linear,g.linear)+glm::dot(g.angular,b.inverseInertia*g.angular);
        }
        if(!(diagonal[i]>=0)||!std::isfinite(diagonal[i]))throw std::invalid_argument("invalid pressure mass matrix");
    }
    auto apply=[&](const std::vector<double>& impulses,double scale) {
        for(unsigned i=0;i<rows.size();++i)if(impulses[i]!=0) {
            const double change=scale*impulses[i];
            for(const auto& g:rows[i].points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*change;
            for(const auto& g:rows[i].bodies) {
                auto& b=bodies[g.body];b.velocity-=b.inverseMass*g.linear*change;b.angularVelocity-=b.inverseInertia*g.angular*change;
            }
        }
    };
    std::vector<glm::dvec3> pointWork(points.size()),linearWork(bodies.size()),angularWork(bodies.size());
    auto multiply=[&](const std::vector<double>& input,std::vector<double>& output) {
        std::fill(pointWork.begin(),pointWork.end(),glm::dvec3(0));
        std::fill(linearWork.begin(),linearWork.end(),glm::dvec3(0));
        std::fill(angularWork.begin(),angularWork.end(),glm::dvec3(0));
        for(unsigned i=0;i<rows.size();++i)if(input[i]!=0) {
            for(const auto& g:rows[i].points)pointWork[g.point]+=g.gradient*input[i];
            for(const auto& g:rows[i].bodies){linearWork[g.body]+=g.linear*input[i];angularWork[g.body]+=g.angular*input[i];}
        }
        for(unsigned i=0;i<points.size();++i)pointWork[i]*=points[i].inverseMass;
        for(unsigned i=0;i<bodies.size();++i){linearWork[i]*=bodies[i].inverseMass;angularWork[i]=bodies[i].inverseInertia*angularWork[i];}
        output.assign(rows.size(),0);
        for(unsigned i=0;i<rows.size();++i) {
            for(const auto& g:rows[i].points)output[i]+=glm::dot(g.gradient,pointWork[g.point]);
            for(const auto& g:rows[i].bodies)output[i]+=glm::dot(g.linear,linearWork[g.body])+glm::dot(g.angular,angularWork[g.body]);
        }
        ++result.matrixProducts;
    };
    auto residual=[&]() {
        result.maximumResidual=0;
        for(unsigned i=0;i<rows.size();++i) {
            const double error=rate(rows[i])-rows[i].maximumRate;
            const double violation=(bilateral[i]||result.pressureImpulse[i]>0)?std::abs(error):std::max(0.,error);
            result.maximumResidual=std::max(result.maximumResidual,violation);
        }
        result.converged=result.maximumResidual<=tolerance;
    };
    std::vector<double> rhs(rows.size()),r(rows.size()),z(rows.size()),direction(rows.size()),product;
    std::vector<bool> free(rows.size());
    for(unsigned i=0;i<rows.size();++i)rhs[i]=r[i]=rate(rows[i])-rows[i].maximumRate;
    auto update=[&](){double rz=0;for(unsigned i=0;i<rows.size();++i){free[i]=diagonal[i]>0&&(bilateral[i]||result.pressureImpulse[i]>0||r[i]>0);z[i]=free[i]?r[i]/diagonal[i]:0;rz+=r[i]*z[i];}return rz;};
    auto estimatedResidual=[&](){double value=0;for(unsigned i=0;i<rows.size();++i)value=std::max(value,(bilateral[i]||result.pressureImpulse[i]>0)?std::abs(r[i]):std::max(0.,r[i]));return value;};
    double rz=update();direction=z;
    for(unsigned work=0;work<budget;++work) {
        if(estimatedResidual()<=tolerance) {
            // Verify against the complete operator, not a recursively updated
            // residual, before declaring convergence.
            multiply(result.pressureImpulse,product);
            for(unsigned i=0;i<rows.size();++i)r[i]=rhs[i]-product[i];
            if(estimatedResidual()<=tolerance)break;
            rz=update();direction=z;
        }
        double slope=0;
        for(unsigned i=0;i<rows.size();++i){if(!bilateral[i]&&result.pressureImpulse[i]==0&&direction[i]<0)direction[i]=0;slope+=r[i]*direction[i];}
        if(!(slope>0)){direction=z;slope=rz;}
        if(!(slope>0))break;
        multiply(direction,product);double curvature=0,bound=INFINITY;unsigned leaving=rows.size();
        for(unsigned i=0;i<rows.size();++i){curvature+=direction[i]*product[i];if(!bilateral[i]&&direction[i]<0){double a=-result.pressureImpulse[i]/direction[i];if(a<=bound){bound=a;leaving=i;}}}
        if(!(curvature>0)||!std::isfinite(curvature))break;
        const double alpha=std::min(slope/curvature,bound);
        for(unsigned i=0;i<rows.size();++i){double next=result.pressureImpulse[i]+alpha*direction[i];if(!bilateral[i])next=std::max(0.,next);if(alpha==bound&&i==leaving)next=0;result.pressureImpulse[i]=next;r[i]-=alpha*product[i];}
        const auto oldFree=free;double next=update();
        const bool restart=alpha==bound||free!=oldFree;const double beta=(!restart&&rz>0)?next/rz:0;
        for(unsigned i=0;i<rows.size();++i)direction[i]=z[i]+beta*direction[i];
        rz=next;++result.sweeps;
    }
    // All impulses are committed once. No partially solved pressure state or
    // iterative velocity writes are needed to evaluate the mass operator.
    apply(result.pressureImpulse,1);residual();
    return result;
}
}
