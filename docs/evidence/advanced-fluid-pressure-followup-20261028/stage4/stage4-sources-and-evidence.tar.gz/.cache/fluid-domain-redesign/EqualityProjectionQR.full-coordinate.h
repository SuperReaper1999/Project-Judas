#pragma once
// Included after AffineModel. Bounded independent reference: no Schur normal
// equations, no rank tolerance, no compliance or velocity/energy repair.
struct EqualityQrResult {bool accepted=false;std::string error;double residual=0,divergence=0;unsigned rows=0,dofs=0;};
inline EqualityQrResult ProjectEqualityQR(Model& model,double tolerance=1e-10){
 EqualityQrResult result;try{
  if(model.rows.size()>512||model.points.size()>2048)throw std::invalid_argument("bounded dense equality reference exceeded");
  for(unsigned i=0;i<model.rows.size();++i)if(!model.bilateral[i]||!model.rows[i].bodies.empty())throw std::invalid_argument("QR reference requires fluid-only bilateral constraints");
  auto points=model.points;
  for(const auto& cell:model.cells){double trace=0,norm=0;std::array<V,3> g;for(unsigned k=0;k<3;++k){g[k]=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(g[k],points[cell.first+1+k].velocity);norm+=glm::dot(g[k],g[k]);}if(!(norm>0))throw std::runtime_error("invalid QR fluid mass metric");for(unsigned k=0;k<3;++k)points[cell.first+1+k].velocity-=g[k]*(trace/norm);}
  const unsigned n=model.rows.size(),d=3*points.size();result.rows=n;result.dofs=d;if(n>d)throw std::runtime_error("equality system has too many independent rows");std::vector<double> qr(d*n,0),rhs(n),tau(n); // column-major weighted J^T
  for(unsigned j=0;j<n;++j){const auto& row=model.rows[j];double norm=0,r=-row.maximumRate;for(auto g:row.points){if(!(points[g.point].inverseMass>0))throw std::runtime_error("QR fluid degree has no physical mass");const double weight=std::sqrt(points[g.point].inverseMass);for(unsigned a=0;a<3;++a)qr[j*d+3*g.point+a]+=weight*g.gradient[a];r+=glm::dot(g.gradient,points[g.point].velocity);}for(unsigned i=0;i<d;++i)norm=std::hypot(norm,qr[j*d+i]);if(!(norm>0))throw std::runtime_error("empty physical equality row");for(unsigned i=0;i<d;++i)qr[j*d+i]/=norm;rhs[j]=r/norm;}
  // Householder factorization of the rectangular constraint operator itself.
  for(unsigned k=0;k<n;++k){double norm=0;for(unsigned i=k;i<d;++i)norm=std::hypot(norm,qr[k*d+i]);if(!(norm>0)||!std::isfinite(norm))throw std::runtime_error("singular physical equality operator");const double old=qr[k*d+k],diagonal=-std::copysign(norm,old),v0=old-diagonal;tau[k]=(diagonal-old)/diagonal;qr[k*d+k]=diagonal;for(unsigned i=k+1;i<d;++i)qr[k*d+i]/=v0;for(unsigned j=k+1;j<n;++j){double dot=qr[j*d+k];for(unsigned i=k+1;i<d;++i)dot+=qr[k*d+i]*qr[j*d+i];dot*=tau[k];qr[j*d+k]-=dot;for(unsigned i=k+1;i<d;++i)qr[j*d+i]-=qr[k*d+i]*dot;}}
  std::vector<double> correction(d,0);for(unsigned i=0;i<n;++i){double r=rhs[i];for(unsigned j=0;j<i;++j)r-=qr[i*d+j]*correction[j];correction[i]=r/qr[i*d+i];}
  for(unsigned k=n;k-->0;){double dot=correction[k];for(unsigned i=k+1;i<d;++i)dot+=qr[k*d+i]*correction[i];dot*=tau[k];correction[k]-=dot;for(unsigned i=k+1;i<d;++i)correction[i]-=qr[k*d+i]*dot;}
  for(unsigned p=0;p<points.size();++p)for(unsigned a=0;a<3;++a)points[p].velocity[a]-=std::sqrt(points[p].inverseMass)*correction[3*p+a];
  for(const auto& row:model.rows){double residual=-row.maximumRate;for(auto g:row.points)residual+=glm::dot(g.gradient,points[g.point].velocity);result.residual=std::max(result.residual,std::abs(residual));}
  for(const auto& cell:model.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){V g=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(g,points[cell.first+1+k].velocity);norm+=glm::dot(g,g);}result.divergence=std::max(result.divergence,std::abs(trace)/std::sqrt(norm));}
  if(result.residual>tolerance||result.divergence>tolerance)throw std::runtime_error("QR physical residual verification failed");model.points=std::move(points);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
