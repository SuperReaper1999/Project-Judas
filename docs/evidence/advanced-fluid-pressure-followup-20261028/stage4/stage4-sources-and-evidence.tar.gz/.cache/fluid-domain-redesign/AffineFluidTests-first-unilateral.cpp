#include "VolumeDomain.h"
#include "MixedProjection.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cstdio>
#include <map>

using V=glm::dvec3;
using M=glm::dmat3;
using namespace fluid_domain;
using namespace pressure_prototype;

namespace {
double Volume(const LiquidTet& t){return std::abs(glm::determinant(M(t[1]-t[0],t[2]-t[0],t[3]-t[0])))/6;}
struct FluidCell {Key key;V center;M factor,inverse;double mass;unsigned first;std::vector<V> samples;};
struct Model {
 VolumeDomain domain{.3};std::vector<FluidCell> cells;std::map<Key,unsigned> index;
 std::vector<Point> points;std::vector<Body> bodies;std::vector<Row> rows;std::vector<bool> bilateral;
 V center{.03,.65,-.04};V half{.22};glm::dquat rotation{1,0,0,0};M frame{1};double bodyMass=0,bodyVolume=0;
 void Add(Row row,bool equality){rows.push_back(std::move(row));bilateral.push_back(equality);}
 void Evaluation(Row& row,const FluidCell& cell,V point,V normal,double sign=1)const{
  const auto phi=cell.inverse*(point-cell.center);
  row.points.push_back({cell.first,normal*sign});
  for(unsigned k=0;k<3;++k)row.points.push_back({cell.first+1+k,normal*(sign*phi[k])});
 }
 std::vector<V> Hull(std::vector<V> vertices,V normal)const{
  if(vertices.size()<3)return {};
  int axis=0;if(std::abs(normal.y)>std::abs(normal[axis]))axis=1;if(std::abs(normal.z)>std::abs(normal[axis]))axis=2;
  const int u=(axis+1)%3,v=(axis+2)%3;
  std::sort(vertices.begin(),vertices.end(),[&](V a,V b){return a[u]<b[u]||(a[u]==b[u]&&a[v]<b[v]);});
  vertices.erase(std::unique(vertices.begin(),vertices.end(),[&](V a,V b){return a[u]==b[u]&&a[v]==b[v];}),vertices.end());
  auto turn=[&](V a,V b,V c){return (b[u]-a[u])*(c[v]-a[v])-(b[v]-a[v])*(c[u]-a[u]);};
  std::vector<V> hull;
  for(auto p:vertices){while(hull.size()>1&&turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
  const auto lower=hull.size();
  for(std::size_t i=vertices.size()-1;i-->0;){auto p=vertices[i];while(hull.size()>lower&&turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
  if(hull.size()>1)hull.pop_back();
  return hull;
 }
 std::vector<V> Three(std::vector<V> points,V normal)const{
  auto hull=Hull(std::move(points),normal);if(hull.size()<3)return {};
  unsigned b=1,c=2;for(unsigned i=1;i<hull.size();++i)if(glm::dot(hull[i]-hull[0],hull[i]-hull[0])>glm::dot(hull[b]-hull[0],hull[b]-hull[0]))b=i;
  double area=-1;for(unsigned i=1;i<hull.size();++i){double a=glm::dot(glm::cross(hull[b]-hull[0],hull[i]-hull[0]),glm::cross(hull[b]-hull[0],hull[i]-hull[0]));if(a>area){area=a;c=i;}}
  return {hull[0],hull[b],hull[c]};
 }
 void Build(double angle,double ratio,bool walls,bool fixed){
  rotation=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));bodyVolume=8*half.x*half.y*half.z;bodyMass=1000*bodyVolume*ratio;
  bodies.push_back({V(0),V(0),fixed?0:1/bodyMass,M(fixed?0:3/(2*bodyMass*half.x*half.x))});
  std::vector<glm::dvec4> planes;
  for(int axis=0;axis<3;++axis)for(double sign:{-1.,1.}){V normal(0);normal[axis]=sign;normal=rotation*normal;planes.emplace_back(normal,glm::dot(normal,center)+half[axis]);}
  std::string error;
  const V origin(-.6,0,-.6);constexpr int nx=4,ny=5,nz=4;constexpr double h=.3;
  for(int y=0;y<ny;++y)for(int z=0;z<nz;++z)for(int x=0;x<nx;++x){Key key{x,y,z};const V offset=origin+h*V(x,y,z);auto local=planes;for(auto& p:local)p.w-=glm::dot(V(p),offset);
   auto geometry=LiquidSubtractSolids(LiquidBox(V(0),V(h)),{local});double volume=0;V first(0);for(const auto& t:geometry.cells){double v=Volume(t);volume+=v;first+=v*(t[0]+t[1]+t[2]+t[3])*.25;}
   if(!(volume>1e-14))continue;
   // Initialize from the compiled geometric capacity, not an assumed cuboid.
   if(!domain.Add(key,geometry,0,{0,1,0},error))throw std::runtime_error(error);
   const double capacity=domain.Find(key)->capacity;
   // A fresh filled copy is used because Add's quantity is authoritative.
   V centroid=first/volume;M covariance(0);
   for(const auto& t:geometry.cells){V sum(0);M diagonal(0);for(auto p:t){V r=p-centroid;sum+=r;diagonal+=glm::outerProduct(r,r);}covariance+=Volume(t)*(glm::outerProduct(sum,sum)+diagonal)/20.;}
   covariance/=volume;M factor(0);
   for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double a=covariance[j][i];for(unsigned k=0;k<j;++k)a-=factor[k][i]*factor[k][j];if(i==j){if(!(a>0))throw std::runtime_error("singular fluid covariance");factor[j][i]=std::sqrt(a);}else factor[j][i]=a/factor[j][j];}
   FluidCell cell{key,offset+centroid,factor,glm::inverse(factor),1000*capacity,unsigned(points.size()),{}};
   for(const auto& t:geometry.cells)for(auto p:t)cell.samples.push_back(offset+p);
   for(unsigned k=0;k<4;++k)points.push_back({V(0),1/cell.mass});
   index.emplace(key,unsigned(cells.size()));cells.push_back(cell);
  }
  // Rebuild the immutable capacities as filled cells for face inspection.
  VolumeDomain filled(h);
  for(const auto& cell:cells){const auto* original=domain.Find(cell.key);if(!filled.Add(cell.key,*original->capacityGeometry,original->capacity,{0,1,0},error))throw std::runtime_error(error);}
  domain=std::move(filled);
  for(const auto& cell:cells){Row incompressible;for(unsigned k=0;k<3;++k){V gradient(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);incompressible.points.push_back({cell.first+1+k,gradient*(cell.mass/1000)});}Add(incompressible,true);
   const V offset=origin+h*V(cell.key.x,cell.key.y,cell.key.z);
   for(int axis=0;axis<3;++axis){Key neighbor=cell.key;if(axis==0)++neighbor.x;if(axis==1)++neighbor.y;if(axis==2)++neighbor.z;auto found=index.find(neighbor);if(found==index.end())continue;V normal(0);normal[axis]=1;std::vector<V> vertices;for(auto& patch:domain.SharedWetPatches(cell.key,neighbor))for(auto p:patch)vertices.push_back(offset+p);
    for(auto p:Three(vertices,normal)){Row row;Evaluation(row,cell,p,normal);Evaluation(row,cells[found->second],p,normal,-1);Add(row,true);}
   }
   if(walls)for(int axis=0;axis<3;++axis)for(int sign:{-1,1}){const int at=axis==0?cell.key.x:axis==1?cell.key.y:cell.key.z;const int count=axis==0?nx:axis==1?ny:nz;if((sign<0&&at!=0)||(sign>0&&at!=count-1)||(axis==1&&sign>0))continue;V normal(0);normal[axis]=sign;std::vector<V> vertices;for(auto& patch:domain.WetFacePatches(cell.key,axis,sign))for(auto p:patch)vertices.push_back(offset+p);for(auto p:Hull(vertices,normal)){Row row;Evaluation(row,cell,p,normal);Add(row,false);}}
   for(unsigned face=0;face<planes.size();++face){const auto plane=planes[face];const V n(plane);std::vector<V> vertices;const double d=plane.w-glm::dot(n,offset);constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
    for(const auto& t:domain.Find(cell.key)->wetGeometry->cells)for(auto& f:tri){std::vector<V> polygon;bool on=true;for(auto k:f){on&=std::abs(glm::dot(n,t[k])-d)<1e-13;polygon.push_back(offset+t[k]);}if(!on)continue;
     for(unsigned p=0;p<planes.size()&&!polygon.empty();++p)if(p!=face){std::vector<V> clipped;for(unsigned i=0;i<polygon.size();++i){V a=polygon[i],b=polygon[(i+1)%polygon.size()];double da=glm::dot(V(planes[p]),a)-planes[p].w,db=glm::dot(V(planes[p]),b)-planes[p].w;if(da<=0)clipped.push_back(a);if((da<=0)!=(db<=0))clipped.push_back(a+(b-a)*(da/(da-db)));}polygon=std::move(clipped);}
     vertices.insert(vertices.end(),polygon.begin(),polygon.end());
    }
    for(auto p:Hull(vertices,n)){const V normal=-n;Row row;Evaluation(row,cell,p,normal);row.bodies.push_back({0,-normal,-glm::cross(p-center,normal)});Add(row,false);}
   }
  }
 }
 V Momentum()const{V result(0);for(const auto& cell:cells)result+=cell.mass*points[cell.first].velocity;if(bodies[0].inverseMass>0)result+=bodies[0].velocity*bodyMass;return result;}
 V Angular()const{V result(0);for(const auto& cell:cells){M affine;for(unsigned k=0;k<3;++k)affine[k]=points[cell.first+1+k].velocity;M s=frame*cell.factor*glm::transpose(affine);V local(s[2][1]-s[1][2],s[0][2]-s[2][0],s[1][0]-s[0][1]);result+=cell.mass*(glm::cross(frame*cell.center,points[cell.first].velocity)+local);}if(bodies[0].inverseMass>0)result+=bodyMass*glm::cross(frame*center,bodies[0].velocity)+glm::inverse(bodies[0].inverseInertia)*bodies[0].angularVelocity;return result;}
 double Energy()const{double value=0;for(auto p:points)value+=.5*glm::dot(p.velocity,p.velocity)/p.inverseMass;if(bodies[0].inverseMass>0)value+=.5*bodyMass*glm::dot(bodies[0].velocity,bodies[0].velocity)+.5*glm::dot(bodies[0].angularVelocity,glm::inverse(bodies[0].inverseInertia)*bodies[0].angularVelocity);return value;}
 double MaxSpeed()const{double value=0;for(const auto& cell:cells)for(auto x:cell.samples){V velocity=points[cell.first].velocity;const auto phi=cell.inverse*(x-cell.center);for(unsigned k=0;k<3;++k)velocity+=points[cell.first+1+k].velocity*phi[k];value=std::max(value,glm::length(velocity));}return value;}
};
}

int main(){unsigned failures=0;try{for(double angle:{0.,.37})for(double ratio:{.5,1.,2.}){Model model;model.Build(angle,ratio,true,false);for(const auto& cell:model.cells)model.points[cell.first].velocity={0,-9.81/90,0};model.bodies[0].velocity={0,-9.81/90,0};auto result=ProjectMixed(model.points,model.bodies,model.rows,model.bilateral,256,1e-9);std::printf("AFFINE_FLUID angle=%.3g ratio=%.1f cells=%zu rows=%zu iterations=%u residual=%.12g converged=%d body_vy=%.12g body_w=%.12g max_fluid=%.12g energy=%.12g\n",angle,ratio,model.cells.size(),model.rows.size(),result.sweeps,result.maximumResidual,result.converged,model.bodies[0].velocity.y,glm::length(model.bodies[0].angularVelocity),model.MaxSpeed(),model.Energy());if(!result.converged)++failures;if(ratio==1&&(glm::length(model.bodies[0].velocity)>1e-7||model.MaxSpeed()>1e-7))++failures;if(ratio==.5&&model.bodies[0].velocity.y<=0)++failures;if(ratio==2&&model.bodies[0].velocity.y>=0)++failures;}
 }catch(const std::exception& e){++failures;std::printf("ERROR %s\n",e.what());}std::printf("SUMMARY failures=%u\n",failures);return failures?1:0;}
