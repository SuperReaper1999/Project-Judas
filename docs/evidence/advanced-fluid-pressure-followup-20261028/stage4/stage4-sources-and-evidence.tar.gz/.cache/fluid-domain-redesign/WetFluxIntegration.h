#pragma once
#include <glm/glm.hpp>
#include <array>
#include <vector>
#include <cmath>
#include <stdexcept>
namespace fluid_flux {
// Integral of the POSITIVE affine normal velocity over an actual triangle.
// Used when only the donor is wet: vacuum is not an incoming mass source.
// max(integral(u.n),0) is different and incorrectly loses opposing outflows.
inline double Positive(const std::array<glm::dvec3,3>& triangle,const std::array<double,3>& normalVelocity){
 struct Vertex{glm::dvec3 position;double value;};std::vector<Vertex> polygon;
 for(unsigned i=0;i<3;++i){if(!std::isfinite(normalVelocity[i]))throw std::invalid_argument("nonfinite wet-face velocity");const unsigned j=(i+1)%3;const double a=normalVelocity[i],b=normalVelocity[j];if(a>=0)polygon.push_back({triangle[i],a});if((a>0&&b<0)||(a<0&&b>0)){const double fraction=a/(a-b);glm::dvec3 point;for(unsigned axis=0;axis<3;++axis)point[axis]=std::fma(fraction,triangle[j][axis]-triangle[i][axis],triangle[i][axis]);polygon.push_back({point,0});}}
 double integral=0;for(unsigned i=1;i+1<polygon.size();++i){const auto& a=polygon[0];const auto& b=polygon[i];const auto& c=polygon[i+1];const double area=.5*glm::length(glm::cross(b.position-a.position,c.position-a.position));integral+=area*(a.value+b.value+c.value)/3.;}return integral;
}
}
