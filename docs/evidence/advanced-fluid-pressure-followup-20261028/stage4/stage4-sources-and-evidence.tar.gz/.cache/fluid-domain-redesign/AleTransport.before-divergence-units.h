#pragma once
#include "MaterialMoments.h"
#include <functional>
#include <map>
namespace fluid_ale {
using V=glm::dvec3;using M=glm::dmat3;using Field=fluid_material::Field;
struct Mesh {std::vector<V> before,after;std::vector<std::array<unsigned,4>> cells;};
struct Result {
 bool accepted=false;std::string error;std::vector<Field> fields;
 fluid_incoming::Moments before,after;
 double matrixGclError=0,constantError=0,equationError=0,boundaryError=0;
 double temporalLoss=0,upwindLoss=0,energyIdentityError=0;
 V angularTransport{0};
};
struct Basis {
 V center{0};M inverse{1};double referenceMass=0;
 std::array<double,4> Evaluate(V x)const{V r=inverse*(x-center);return {1,r.x,r.y,r.z};}
 V Gradient(unsigned i)const{return i==0?V(0):V(inverse[0][i-1],inverse[1][i-1],inverse[2][i-1]);}
};
struct TetData {double volume=0;V center{0};M covariance{0};};
inline TetData Measure(const LiquidTet& t){
 TetData result;const double determinant=glm::determinant(M(t[1]-t[0],t[2]-t[0],t[3]-t[0]));
 if(determinant<0||!std::isfinite(determinant))throw std::runtime_error("moving tetrahedron lost orientation");
 result.volume=determinant/6;result.center=(t[0]+t[1]+t[2]+t[3])*.25;V sum(0);
 for(V p:t){V d=p-result.center;sum+=d;result.covariance+=glm::outerProduct(d,d);}result.covariance=(result.covariance+glm::outerProduct(sum,sum))/20.;return result;
}
inline Basis MakeBasis(const LiquidTet& old,const LiquidTet& next,double density){
 const auto a=Measure(old),b=Measure(next);const double volume=a.volume+b.volume;if(!(volume>0))throw std::runtime_error("space-time element has zero endpoint mass");
 Basis basis;basis.referenceMass=density*volume;basis.center=(a.volume*a.center+b.volume*b.center)/volume;
 M covariance=(a.volume*(a.covariance+glm::outerProduct(a.center-basis.center,a.center-basis.center))+b.volume*(b.covariance+glm::outerProduct(b.center-basis.center,b.center-basis.center)))/volume;
 M lower(0);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double v=covariance[j][i];for(unsigned k=0;k<j;++k)v-=lower[k][i]*lower[k][j];if(i==j){if(!(v>0))throw std::runtime_error("singular space-time material basis");lower[j][i]=std::sqrt(v);}else lower[j][i]=v/lower[j][j];}basis.inverse=glm::inverse(lower);return basis;
}
inline V Evaluate(const Field& f,V x){return f.value+f.gradient*(x-f.origin);}
inline std::array<V,4> Quadrature(const LiquidTet& tet){
 constexpr double a=.58541019662496845446,b=.13819660112501051518;
 std::array<V,4> points;for(unsigned i=0;i<4;++i){points[i]=V(0);for(unsigned j=0;j<4;++j)points[i]+=(i==j?a:b)*tet[j];}return points;
}
// Conservative DG1 in space, DG0 in TIME on a moving tetrahedral partition.
// The trial basis is constant in physical coordinates over the interval.
// Positive old/new endpoint mass defines the normalization, so newly wet
// elements do not require a fictitious old velocity/mass. Closed material
// boundaries and an affine, divergence-free, H(div)-continuous advector are
// explicit preconditions and are checked at quadrature points.
// This bounded dense reference is NOT a production scalability implementation.
inline Result Advance(const Mesh& mesh,const std::vector<Field>& initial,double dt,double density,
 const std::function<V(unsigned,V,double)>& advector){
 Result result;
 try{
  const unsigned count=mesh.cells.size(),n=4*count;
  if(count==0||count>128||initial.size()!=count||mesh.before.size()!=mesh.after.size()||!std::isfinite(dt)||!(dt>0)||!std::isfinite(density)||!(density>0)||!advector)throw std::invalid_argument("invalid bounded ALE interval");
  for(unsigned i=0;i<mesh.before.size();++i)for(unsigned a=0;a<3;++a)if(!std::isfinite(mesh.before[i][a])||!std::isfinite(mesh.after[i][a]))throw std::invalid_argument("nonfinite ALE geometry");
  auto geometry=[&](unsigned cell,double time){LiquidTet tet;for(unsigned i=0;i<4;++i){const unsigned v=mesh.cells[cell][i];const V a=mesh.before.at(v),b=mesh.after.at(v);for(unsigned k=0;k<3;++k)tet[i][k]=std::fma(time,b[k]-a[k],a[k]);}return tet;};
  std::vector<Basis> bases;for(unsigned c=0;c<count;++c)bases.push_back(MakeBasis(geometry(c,0),geometry(c,1),density));
  std::vector<double> oldMass(n*n,0),newMass(n*n,0),transport(n*n,0),jumpMatrix(n*n,0);std::vector<V> rhs(n,V(0));
  for(unsigned c=0;c<count;++c)for(unsigned endpoint=0;endpoint<2;++endpoint){auto tet=geometry(c,endpoint);const double volume=Measure(tet).volume;if(volume==0)continue;auto& matrix=endpoint?newMass:oldMass;for(V x:Quadrature(tet)){const double weight=density*volume*.25;auto phi=bases[c].Evaluate(x);for(unsigned i=0;i<4;++i){for(unsigned j=0;j<4;++j)matrix[(4*c+i)*n+4*c+j]+=weight*phi[i]*phi[j];if(!endpoint)rhs[4*c+i]+=weight*phi[i]*Evaluate(initial[c],x);}}if(!endpoint)result.before.Add(fluid_material::Integrate(LiquidGeometry{{tet}},initial[c],density));}
  struct Face{std::array<unsigned,3> vertices;std::vector<unsigned> owners;};std::map<std::array<unsigned,3>,Face> faces;
  constexpr unsigned triangle[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
  for(unsigned c=0;c<count;++c)for(const auto& f:triangle){std::array<unsigned,3> ids{mesh.cells[c][f[0]],mesh.cells[c][f[1]],mesh.cells[c][f[2]]};auto key=ids;std::sort(key.begin(),key.end());auto& face=faces[key];face.vertices=ids;face.owners.push_back(c);if(face.owners.size()>2)throw std::runtime_error("nonmanifold ALE face");}
  struct Jump {unsigned a,b;std::array<double,4> pa,pb;double weight;};std::vector<Jump> jumps;
  struct VolumeSample{unsigned c;V x,wind;double weight;};std::vector<VolumeSample> volumeSamples;
  constexpr double root35=.77459666924148337704,root3=.57735026918962576451;
  const double node[3]={.5*(1-root35),.5,.5*(1+root35)},weight[3]={5./18,4./9,5./18},second[2]={.5*(1-root3),.5*(1+root3)};
  auto addBlock=[&](std::vector<double>& matrix,unsigned a,unsigned b,const std::array<double,4>& pa,const std::array<double,4>& pb,double w){for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)matrix[(4*a+i)*n+4*b+j]+=w*pa[i]*pb[j];};
  for(unsigned time=0;time<3;++time){const double t=node[time],tw=dt*weight[time];
   for(unsigned c=0;c<count;++c){const auto tet=geometry(c,t);const auto measure=Measure(tet);if(!(measure.volume>0))throw std::runtime_error("ALE element has no interior at integration time");
    std::array<V,4> vertexWind;for(unsigned i=0;i<4;++i)vertexWind[i]=advector(c,tet[i],t);M difference(vertexWind[1]-vertexWind[0],vertexWind[2]-vertexWind[0],vertexWind[3]-vertexWind[0]);M gradient=difference*glm::inverse(M(tet[1]-tet[0],tet[2]-tet[0],tet[3]-tet[0]));const double trace=gradient[0][0]+gradient[1][1]+gradient[2][2];if(!std::isfinite(trace)||std::abs(trace)>1e-9)throw std::runtime_error("ALE advector is not incompressible");
    for(V x:Quadrature(tet)){const V w=advector(c,x,t);const auto phi=bases[c].Evaluate(x);const double q=tw*density*measure.volume*.25;for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)transport[(4*c+i)*n+4*c+j]-=q*glm::dot(w,bases[c].Gradient(i))*phi[j];volumeSamples.push_back({c,x,w,q});}
   }
   for(const auto& [key,face]:faces){const unsigned a=face.owners[0],b=face.owners.size()==2?face.owners[1]:unsigned(-1);std::array<V,3> p,velocity;
    for(unsigned i=0;i<3;++i){unsigned v=face.vertices[i];p[i]=mesh.before[v]+t*(mesh.after[v]-mesh.before[v]);velocity[i]=(mesh.after[v]-mesh.before[v])/dt;}
    V normal=glm::cross(p[1]-p[0],p[2]-p[0]);const double twiceArea=glm::length(normal);if(!(twiceArea>0))throw std::runtime_error("degenerate space-time integration face");normal/=twiceArea;if(glm::dot(normal,Measure(geometry(a,t)).center-p[0])>0)normal=-normal;
    for(unsigned i=0;i<3;++i)for(unsigned j=0;j<2;++j){const double s=node[i],r=second[j];const double wa=(1-s)*(1-r),wb=s,wc=(1-s)*r;const V x=wa*p[0]+wb*p[1]+wc*p[2],grid=wa*velocity[0]+wb*velocity[1]+wc*velocity[2];const V wind=advector(a,x,t);const double normalWind=glm::dot(wind-grid,normal);if(!std::isfinite(normalWind))throw std::runtime_error("nonfinite ALE flux");
     if(b==unsigned(-1)){const double error=std::abs(normalWind);result.boundaryError=std::max(result.boundaryError,error);if(error>1e-10*std::max(1.,glm::length(wind)+glm::length(grid)))throw std::runtime_error("ALE material boundary has nonzero relative flow");continue;}
     if(std::abs(glm::dot(wind-advector(b,x,t),normal))>1e-10)throw std::runtime_error("ALE shared normal wind is discontinuous");
     const double q=tw*density*weight[i]*.5*(1-s)*twiceArea*normalWind;const auto pa=bases[a].Evaluate(x),pb=bases[b].Evaluate(x);
     if(q>=0){addBlock(transport,a,a,pa,pa,q);addBlock(transport,b,a,pb,pa,-q);}else{addBlock(transport,a,b,pa,pb,q);addBlock(transport,b,b,pb,pb,-q);}
     const double w=std::abs(q);addBlock(jumpMatrix,a,a,pa,pa,w);addBlock(jumpMatrix,b,b,pb,pb,w);addBlock(jumpMatrix,a,b,pa,pb,-w);addBlock(jumpMatrix,b,a,pb,pa,-w);jumps.push_back({a,b,pa,pb,w});
    }
   }
  }
  std::vector<double> matrix(n*n),scale(n);for(unsigned i=0;i<n;++i)scale[i]=1/std::sqrt(bases[i/4].referenceMass);
  for(unsigned i=0;i<n;++i){double constant=0;for(unsigned j=0;j<n;++j){matrix[i*n+j]=newMass[i*n+j]+transport[i*n+j];const double gcl=newMass[i*n+j]-oldMass[i*n+j]+transport[i*n+j]+transport[j*n+i]-jumpMatrix[i*n+j];result.matrixGclError=std::max(result.matrixGclError,std::abs(gcl)*scale[i]*scale[j]);if(j%4==0)constant+=matrix[i*n+j]-oldMass[i*n+j];}result.constantError=std::max(result.constantError,std::abs(constant)/bases[i/4].referenceMass);}
  if(result.matrixGclError>1e-10||result.constantError>1e-10)throw std::runtime_error("ALE matrix geometric-conservation identity failed");
  auto work=matrix;auto solved=rhs;for(unsigned i=0;i<n;++i){solved[i]*=scale[i];for(unsigned j=0;j<n;++j)work[i*n+j]*=scale[i]*scale[j];}
  for(unsigned k=0;k<n;++k){unsigned pivot=k;for(unsigned i=k+1;i<n;++i)if(std::abs(work[i*n+k])>std::abs(work[pivot*n+k]))pivot=i;if(work[pivot*n+k]==0||!std::isfinite(work[pivot*n+k]))throw std::runtime_error("singular ALE material solve");if(pivot!=k){for(unsigned j=k;j<n;++j)std::swap(work[k*n+j],work[pivot*n+j]);std::swap(solved[k],solved[pivot]);}for(unsigned i=k+1;i<n;++i){double factor=work[i*n+k]/work[k*n+k];for(unsigned j=k+1;j<n;++j)work[i*n+j]-=factor*work[k*n+j];solved[i]-=factor*solved[k];}}
  for(unsigned k=n;k-->0;){for(unsigned j=k+1;j<n;++j)solved[k]-=work[k*n+j]*solved[j];solved[k]/=work[k*n+k];}for(unsigned i=0;i<n;++i)solved[i]*=scale[i];
  for(unsigned i=0;i<n;++i){V residual=-rhs[i];for(unsigned j=0;j<n;++j)residual+=matrix[i*n+j]*solved[j];result.equationError=std::max(result.equationError,glm::length(residual)/bases[i/4].referenceMass);}
  std::vector<Field> staged;for(unsigned c=0;c<count;++c){M affine;for(unsigned k=0;k<3;++k)affine[k]=solved[4*c+1+k];Field f{bases[c].center,solved[4*c],affine*bases[c].inverse};staged.push_back(f);auto end=geometry(c,1);if(Measure(end).volume>0)result.after.Add(fluid_material::Integrate(LiquidGeometry{{end}},f,density));auto old=geometry(c,0);if(Measure(old).volume>0){Field change{f.origin,Evaluate(f,f.origin)-Evaluate(initial[c],f.origin),f.gradient-initial[c].gradient};result.temporalLoss+=fluid_material::Integrate(LiquidGeometry{{old}},change,density).energy;}}
  for(const auto& jump:jumps){V a(0),b(0);for(unsigned k=0;k<4;++k){a+=jump.pa[k]*solved[4*jump.a+k];b+=jump.pb[k]*solved[4*jump.b+k];}result.upwindLoss+=.5*jump.weight*glm::dot(a-b,a-b);}
  for(const auto& q:volumeSamples)result.angularTransport+=q.weight*glm::cross(q.wind,Evaluate(staged[q.c],q.x));
  result.energyIdentityError=std::abs(result.after.energy-result.before.energy+result.temporalLoss+result.upwindLoss);
  if(result.equationError>1e-10||result.after.energy>result.before.energy+1e-10*std::max(1.,result.before.energy)||result.energyIdentityError>1e-10*std::max(1.,result.before.energy))throw std::runtime_error("ALE solve violates physical energy identity");
  result.fields=std::move(staged);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
}
