from pathlib import Path
import subprocess,json,hashlib,datetime,time
root=Path.cwd();out=root/'.cache/fluid-domain-redesign';results=[]
tests=[('build_cut.py','cut-mesh-tests'),('build_cut_adversarial.py','cut-mesh-adversarial'),('build_moving_cut.py','moving-cut-mesh-tests'),('build_wet_cut.py','wet-cut-mesh-tests'),('build_owned_capacity.py','owned-capacity-tests'),('build_complementarity.py','pressure-complementarity-tests'),('build_mass_scale.py','pressure-mass-scale-tests'),('build_fluid_projection.py','fluid-projection-tests'),('build_tetra.py','tetra-pressure-tests'),('build_side.py','tetra-side-tests'),('build_compiled_pressure.py','compiled-pressure-tests'),('build_native_compiled.py','native-compiled-pressure-tests'),('build_advection.py','dg-advection-tests'),('build_wet_flux.py','wet-flux-tests'),('build_moment.py','moment-interface-tests'),('build_incoming.py','incoming-wet-state-tests'),('build_pressure_volume.py','pressure-volume-step-tests')]
for builder,name in tests:
 start=time.monotonic()
 with (out/f'phase2-{name}-build.log').open('w') as log:
  build=subprocess.run(['python3',str(out/builder)],stdout=log,stderr=subprocess.STDOUT)
 record=dict(test=name,build_exit=build.returncode)
 if build.returncode==0:
  exe=root/'.cache/fluid-contact-repair'/name;record['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
  with (out/f'phase2-{name}.log').open('w') as log:
   try:run=subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT,timeout=45);record['exit']=run.returncode
   except subprocess.TimeoutExpired:record['exit']='timeout'
 record['secondsIncludingBuild']=time.monotonic()-start;results.append(record)
 (out/'PHASE2_RESULTS.json').write_text(json.dumps(dict(updatedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseRevision='0f78c76a5a5113d5b59586596dccb076bce910f2',scope='Local numerical prototypes; not a production fluid backend',tests=results),indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if record.get('exit')!=0:break
