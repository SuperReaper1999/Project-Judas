#include "ConformingCutMesh.h"
#include "VolumeDomain.h"
#include <glm/gtc/quaternion.hpp>
#include <cstdio>
#include <chrono>
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* name){++checks;if(!ok){++failures;std::printf("FAIL %s\n",name);}};
 for(double angle:{.17,.71,1.39}){const auto q=glm::angleAxis(angle,glm::normalize(glm::dvec3(1,2,3)));std::array<fluid_exact::Plane,6> planes;unsigned at=0;for(unsigned axis=0;axis<3;++axis)for(double sign:{-1.,1.}){glm::dvec3 n(0);n[axis]=sign;n=q*n;planes[at++]={{n.x,n.y,n.z},glm::dot(n,glm::dvec3(.5))+.18};}fluid_mesh::Compiler compiler;compiler.Build(1,planes);LiquidGeometry capacity;for(const auto& tetrahedron:compiler.tetrahedra)capacity.cells.push_back(tetrahedron.geometry);
  for(double volume:{.1,.4,.8}){fluid_domain::VolumeDomain water(1);std::string error;auto start=std::chrono::steady_clock::now();bool accepted=water.Add({0,0,0},capacity,volume,{.1,1,.2},error);check(accepted,"native oblique geometry compiled with actual face ownership");if(const auto* cell=water.Find({0,0,0})){check(std::abs(cell->capacity-(1-std::pow(.36,3)))<1e-12,"same unchanged analytic native solid capacity");check(std::abs(cell->reconstructionError)<1e-12,"same unchanged wet-volume accuracy");}std::printf("OWNED_CAPACITY angle=%g quantity=%g tets=%zu accepted=%d ms=%.6f diagnostic=%s\n",angle,volume,capacity.cells.size(),accepted,std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(),error.c_str());}}
 std::printf("OWNED_CAPACITY checks=%u failures=%u\n",checks,failures);return failures?1:0;}
