#pragma once
#include "MixedProjection.h"
#include <set>
// LAPACK is a disposable Linux reference dependency for this experiment, NOT
// linked into Judas or its SDK. Test whether rank-aware local inverses help
// before choosing a portable production factorization.
extern "C" void dsyev_(const char*,const char*,const int*,double*,const int*,double*,double*,const int*,int*);
struct AffineSchwarz {
 struct Block {std::vector<unsigned> rows;std::vector<double> vectors,values;};
 std::vector<Block> blocks;std::vector<double> scale;
 AffineSchwarz(const std::vector<pressure_prototype::Point>& points,const std::vector<pressure_prototype::Body>& bodies,const std::vector<pressure_prototype::Row>& rows) {
  auto product=[&](unsigned i,unsigned j){double value=0;for(auto a:rows[i].points)for(auto b:rows[j].points)if(a.point==b.point)value+=points[a.point].inverseMass*glm::dot(a.gradient,b.gradient);for(auto a:rows[i].bodies)for(auto b:rows[j].bodies)if(a.body==b.body){const auto& body=bodies[a.body];value+=body.inverseMass*glm::dot(a.linear,b.linear)+glm::dot(a.angular,body.inverseInertia*b.angular);}return value;};
  scale.resize(rows.size());std::map<unsigned,std::set<unsigned>> groups;
  for(unsigned i=0;i<rows.size();++i){double d=product(i,i);scale[i]=d>0?1/std::sqrt(d):0;for(auto g:rows[i].points)groups[g.point/4].insert(i);for(auto g:rows[i].bodies)if(bodies[g.body].inverseMass>0)groups[unsigned(points.size()/4+g.body)].insert(i);}
  for(auto& group:groups){Block block;for(auto i:group.second)if(scale[i]>0)block.rows.push_back(i);const int n=int(block.rows.size());if(!n)continue;block.vectors.resize(n*n);block.values.resize(n);
   for(int j=0;j<n;++j)for(int i=0;i<=j;++i){double v=product(block.rows[i],block.rows[j])*scale[block.rows[i]]*scale[block.rows[j]];block.vectors[j*n+i]=block.vectors[i*n+j]=v;}
   int length=std::max(1,3*n),status=0;std::vector<double> work(length);const char vectors='V',upper='U';dsyev_(&vectors,&upper,&n,block.vectors.data(),&n,block.values.data(),work.data(),&length,&status);if(status)throw std::runtime_error("Schwarz spectral reference failed");
   const double tolerance=64*std::numeric_limits<double>::epsilon()*n*block.values.back();
   for(auto& value:block.values){if(value< -tolerance)throw std::runtime_error("indefinite physical Gram matrix");value=value>tolerance?1/value:0;}
   blocks.push_back(std::move(block));
  }
 }
 void Apply(const std::vector<double>& r,const std::vector<bool>& free,std::vector<double>& z)const {
  z.resize(r.size());for(unsigned i=0;i<r.size();++i)z[i]=free[i]?r[i]*scale[i]*scale[i]:0;
  for(const auto& block:blocks){const unsigned n=unsigned(block.rows.size());for(unsigned k=0;k<n;++k)if(block.values[k]>0){double value=0;for(unsigned j=0;j<n;++j)if(free[block.rows[j]])value+=block.vectors[k*n+j]*r[block.rows[j]]*scale[block.rows[j]];value*=block.values[k];for(unsigned j=0;j<n;++j)if(free[block.rows[j]])z[block.rows[j]]+=block.vectors[k*n+j]*value*scale[block.rows[j]];}}
 }
};
