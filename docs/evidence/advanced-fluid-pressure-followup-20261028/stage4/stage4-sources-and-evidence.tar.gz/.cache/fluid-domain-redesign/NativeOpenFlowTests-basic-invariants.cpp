#include "FacePressure.h"
#include "PhysicsWorld.h"
#include <cstdio>
#include <cmath>
using namespace fluid_domain;
int main(){
 PhysicsWorld world;world.Init();const auto piston=world.CreateDynamicBox({0,.85f,0},{.5f,.1f,.5f},80,0,0);world.SetLinearVelocity(piston,{0,-1,0});
 const double initial=double(world.GetTransform(piston).position.y)-.1;
 VolumeDomain water(1);std::string error;bool healthy=water.Add({0,0,0},LiquidBox({0,0,0},{1,initial,1}),initial,{0,1,0},error)&&water.Add({1,0,0},LiquidBox({0,0,0},{1,1,1}),initial,{0,1,0},error);
 Face face{{0,0,0},{1,0,0},1000*initial,0};PressureStep pending;unsigned substeps=0,failures=0;double firstMismatch=0;
 auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(1,[&](const auto& phase){
  if(!healthy)return;
  const auto v=world.GetLinearVelocity(piston);
  pending=ProjectFaces(water,phase.deltaTime,{face},{{glm::dvec3(v),glm::dvec3(0),1./80,glm::dmat3(0)}},{{{0,0,0},0,{0,-1,0},{0,0,0}}});
  if(!pending.converged){healthy=false;error=pending.error;return;}
  world.ApplyLinearImpulse(piston,glm::vec3((pending.bodies[0].velocity-glm::dvec3(v))*80.));
 },[&](const auto& phase){
  if(!healthy)return;++substeps;
  const double actualHeight=double(world.GetTransform(piston).position.y)-.1;
  auto capacity=std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{1,actualHeight,1}));
  const double flux=pending.transfers.empty()?0:pending.transfers[0].volume;
  const double expected=water.Find({0,0,0})->volume-flux;
  if(!water.Advance(pending.transfers,{{{0,0,0},capacity}},error)){
   healthy=false;firstMismatch=expected-actualHeight;
   std::printf("FIRST_DIVERGENCE substep=%u h=%.17g before=%.17g transferred=%.17g actual_capacity=%.17g predicted_quantity=%.17g excess=%.17g body_v=%.17g fluid_u=%.17g error=%s\n",substeps,double(phase.deltaTime),water.Find({0,0,0})->volume,flux,actualHeight,expected,firstMismatch,double(world.GetLinearVelocity(piston).y),pending.faces[0].velocity,error.c_str());
   return;
  }
  face=pending.faces[0];
 });
 for(unsigned tick=0;tick<120&&healthy;++tick)world.Step(1.f/60,&coupling);
 if(!healthy){++failures;std::printf("FAIL coupled resolved-flow publication: %s\n",error.c_str());}
 if(std::abs(water.TotalVolume()-2*initial)>1e-12){++failures;std::printf("FAIL conserved quantity\n");}
 std::printf("SUMMARY substeps=%u failures=%u total=%.17g initial=%.17g first_mismatch=%.17g\n",substeps,failures,water.TotalVolume(),2*initial,firstMismatch);return failures?1:0;
}
