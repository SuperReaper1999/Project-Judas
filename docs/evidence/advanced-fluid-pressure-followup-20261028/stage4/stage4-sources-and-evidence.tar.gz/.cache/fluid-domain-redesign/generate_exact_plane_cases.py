"""Independent exact rational signs for immutable binary64 plane fixtures."""
from fractions import Fraction
from itertools import permutations
from pathlib import Path
import random
import math
rng=random.Random(20261028)
perms=list(permutations(range(4)))
def sign_of_determinant(a):
    result=Fraction(0)
    for order in perms:
        inversions=sum(order[i]>order[j] for i in range(4) for j in range(i+1,4))
        term=Fraction(1)
        for i in range(4):
            term*=Fraction.from_float(a[i][order[i]])
        result+=term*(-1 if inversions%2 else 1)
    return (result>0)-(result<0)
cases=[]
for i in range(240):
    a=[[rng.uniform(-1,1) for _ in range(4)] for _ in range(4)]
    if i%3==0:
        a[3]=list(a[2])
    elif i%3==1:
        a[3]=[math.nextafter(x,math.inf) if j==i%4 else x for j,x in enumerate(a[2])]
    cases.append((a,sign_of_determinant(a)))
lines=['struct ExactCase { std::array<std::array<double,4>,4> matrix; int sign; };','static const ExactCase exactCases[]={']
for a,sign in cases:
    lines.append('  {{{'+','.join('{'+','.join(x.hex() for x in row)+'}' for row in a)+'}},'+str(sign)+'},')
lines.append('};')
Path(__file__).with_name('ExactPlaneCases.h').write_text('\n'.join(lines)+'\n')
