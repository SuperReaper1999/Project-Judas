#define main retained_tetra_cache_main
#include "TetraPressureTests.cpp"
#undef main
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* text){++checks;if(!ok){++failures;std::printf("FAIL %s\n",text);}};
 Model original;BuildTetra(original,false,.37);
 auto predict=[](Model& m){for(const auto& c:m.cells)m.points[c.first].velocity=V(0,-9.81/90,0);m.bodies[0].velocity=V(0,-9.81/90,0);};
 SparseWorkspace cache;auto first=original;predict(first);auto initial=ProjectFluidPressure(first,64,1e-10,&cache);check(initial.converged&&cache.operatorBuilds==1,"initial physical operator built");
 for(unsigned scenario=0;scenario<11;++scenario){auto m=original;predict(m);bool changesOperator=false;
  if(scenario==1){for(auto& p:m.points)p.inverseMass*=1.1;changesOperator=true;}
  if(scenario==2){for(auto& g:m.rows[0].points)g.gradient*=1.01;changesOperator=true;}
  if(scenario==3){m.bodies[0].inverseMass*=.8;m.bodies[0].inverseInertia*=1.2;}
  if(scenario==4){m.bodies[0].velocity+=V(.001,.002,-.001);}
  if(scenario==5){for(auto& row:m.rows)for(auto& g:row.bodies){g.linear*=.99;g.angular*=.99;}}
  if(scenario==6){std::swap(m.rows[0],m.rows[1]);bool b=m.bilateral[0];m.bilateral[0]=m.bilateral[1];m.bilateral[1]=b;changesOperator=true;}
  if(scenario==7){m.rows.back().maximumRate=.00001;}
  if(scenario==8){m.bilateral.back()=true;}
  if(scenario==9){m.points.push_back({V(.1),.01});changesOperator=true;}
  if(scenario==10){m.rows.pop_back();m.bilateral.pop_back();changesOperator=true;}
  // Prime the same baseline each time, then change only the intended input.
  auto reset=original;predict(reset);auto primed=ProjectFluidPressure(reset,64,1e-10,&cache);check(primed.converged,"baseline reprime is a real successful solve");const unsigned builds=cache.operatorBuilds,hits=cache.operatorHits;
  auto reference=m;auto actual=ProjectFluidPressure(m,64,1e-10,&cache);SparseWorkspace fresh;auto expected=ProjectFluidPressure(reference,64,1e-10,&fresh);
  check(actual.converged&&expected.converged,"changed-input cached and fresh physical solves converge");
  double difference=0;for(unsigned i=0;i<m.points.size();++i)difference=std::max(difference,glm::length(m.points[i].velocity-reference.points[i].velocity));difference=std::max(difference,glm::length(m.bodies[0].velocity-reference.bodies[0].velocity));difference=std::max(difference,glm::length(m.bodies[0].angularVelocity-reference.bodies[0].angularVelocity));check(difference<1e-8,"cached state agrees with independent fresh operator endpoint");
  check(changesOperator?cache.operatorBuilds==builds+1:cache.operatorBuilds==builds&&cache.operatorHits==hits+1,"only actual fluid Jacobian/mass changes rebuild fluid operator");
  std::printf("CACHE_CASE scenario=%u changed=%d converged=%d fresh=%d endpoint_error=%g builds=%u hits=%u\n",scenario,changesOperator,actual.converged,expected.converged,difference,cache.operatorBuilds,cache.operatorHits);
 }
 // Same sized replacement geometry must not inherit the previous numeric mass operator.
 auto replacement=Model{};BuildTetra(replacement,false,.41);predict(replacement);auto reference=replacement;unsigned before=cache.operatorBuilds;auto a=ProjectFluidPressure(replacement,64,1e-10,&cache);auto b=ProjectFluidPressure(reference,64,1e-10);check(a.converged&&b.converged&&cache.operatorBuilds==before+1,"same-count new geometry invalidates numeric operator");
 double error=0;for(unsigned i=0;i<reference.points.size();++i)error=std::max(error,glm::length(reference.points[i].velocity-replacement.points[i].velocity));check(error<1e-8,"replacement agrees with uncached physical solution");
 std::printf("OPERATOR_CACHE checks=%u failures=%u\n",checks,failures);return failures?1:0;}
