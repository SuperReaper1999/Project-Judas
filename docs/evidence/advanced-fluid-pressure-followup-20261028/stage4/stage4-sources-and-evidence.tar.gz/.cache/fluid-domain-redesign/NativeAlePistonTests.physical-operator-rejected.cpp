#define main retained_native_ale_pressure_main
#include "CompiledPressureTests.cpp"
#undef main
#include "AleWindProjection.h"
#include "PhysicsWorld.h"
#include "FiniteFrontGeometry.h"
#include "ConformingAleWind.h"
#include <cstdio>
#include <fstream>
#include <iomanip>

namespace {
const Key lower{0,0,0,0},right{1,0,0,0},upper{0,0,0,1};
std::vector<fluid_exact::Plane> NativePlate(const BodyTransform& pose,V half,V origin=V(0)){
 std::vector<fluid_exact::Plane> planes;
 for(unsigned a=0;a<3;++a)for(double sign:{-1.,1.}){V n(0);n[a]=sign;n=glm::dquat(pose.rotation)*n;planes.push_back({{n.x,n.y,n.z},glm::dot(n,V(pose.position)-origin)+half[a]});}
 return planes;
}
double Kinetic(const Model& m,double bodyMass){
 double energy=.5*bodyMass*glm::dot(m.bodies[0].velocity,m.bodies[0].velocity);
 for(const auto& point:m.points)energy+=.5*glm::dot(point.velocity,point.velocity)/point.inverseMass;
 return energy;
}
void Capture(const fluid_ale::Mesh& mesh,const std::vector<fluid_ale::Field>& fields,double dt,const std::string& path=".cache/fluid-domain-redesign/native-manual-moving-pressure-capture.txt"){
 if(std::ifstream(path).good())throw std::runtime_error("refusing to overwrite a preserved solver boundary");
 std::ofstream out(path);out<<std::setprecision(17)<<dt<<' '<<mesh.before.size()<<' '<<mesh.cells.size()<<'\n';
 for(unsigned i=0;i<mesh.before.size();++i)out<<mesh.before[i].x<<' '<<mesh.before[i].y<<' '<<mesh.before[i].z<<' '<<mesh.after[i].x<<' '<<mesh.after[i].y<<' '<<mesh.after[i].z<<'\n';
 for(unsigned i=0;i<mesh.cells.size();++i){for(unsigned id:mesh.cells[i])out<<id<<' ';const auto& f=fields[i];out<<f.origin.x<<' '<<f.origin.y<<' '<<f.origin.z<<' '<<f.value.x<<' '<<f.value.y<<' '<<f.value.z<<' ';for(unsigned a=0;a<3;++a)for(unsigned b=0;b<3;++b)out<<f.gradient[a][b]<<' ';out<<'\n';}
 if(!out)throw std::runtime_error("cannot preserve first moving solver boundary");
}
struct Trial {
 PhysicsWorld world;
 BodyHandle body;
 const glm::vec3 half{.5f,.1f,.5f};
 VolumeDomain ledger{1};
 std::vector<fluid_ale::Field> physical=std::vector<fluid_ale::Field>(30),pending;
 double initialHeight=0,owned=0,oldHeight=0,pressureEnergy=0;
 V predictedBody{0};
 unsigned intervals=0,born=0,events=0;
 double maxEnergy=40,maxPressureResidual=0,maxGcl=0,maxEnergyIdentity=0,maxBodyError=0,maxOwnedError=0;
 double pressureMs=0,windMs=0,transportMs=0;
 bool capture=false;
 fluid_front::State front,pendingFront;V origin{0};double horizontal=0,vertical=0;

 Trial(bool captureInput,bool incomingCurrent=false):capture(captureInput){
  world.Init();body=world.CreateDynamicBox({.5f,.85f,.5f},half,80,0,0);
  JointSettings guide;guide.type=JointType::Slider;guide.bodyA=body;guide.anchorB={.5f,.85f,.5f};guide.frameA=guide.frameB=glm::angleAxis(glm::half_pi<float>(),glm::vec3(0,0,1));
  if(!world.CreateJoint(guide).IsValid())throw std::runtime_error("cannot create ordinary guide joint");
  world.SetLinearVelocity(body,{0,-1,0});initialHeight=double(world.GetTransform(body).position.y)-half.y;std::string error;
  if(!ledger.Add(lower,LiquidBox(V(0),V(1,initialHeight,1)),initialHeight,V(0,1,0),error)||
     !ledger.Add(right,LiquidBox(V(0),V(1)),initialHeight,V(0,1,0),error)||
     !ledger.Add(upper,LiquidBox(V(0,initialHeight+2*half.y,0),V(1)),0,V(0,1,0),error))throw std::runtime_error(error);
  owned=ledger.TotalVolume();origin=V(1,.5*(owned+2*double(half.y)),0);
  if(incomingCurrent)for(unsigned c=6;c<24;++c)physical[c].value=V(-.1,0,0);
 }
 void Pressure(){
  const auto started=std::chrono::steady_clock::now();
  const auto pose=world.GetTransform(body);oldHeight=double(pose.position.y)-half.y;
  if(std::abs(oldHeight-ledger.Find(lower)->volume)>1e-12)throw std::runtime_error("body pose and lower owner disagree");
  auto seed=front;if(seed.width==0){seed.bottom=(oldHeight-origin.y)+2*double(half.y);seed.gap=std::max(0.,owned-2*oldHeight-2*double(half.y));}pendingFront=seed;
  fluid_front::Motion placement{oldHeight,oldHeight,owned,2*double(half.y),1,seed,0,0,origin};
  auto current=fluid_front::Prepare(placement).mesh;
  auto prepared=fluid_ale_fixture::Compile(current,0,NativePlate(pose,V(half),origin));
  Model model;BuildCompiled(model,prepared.mesh,false,V(half),glm::dquat(pose.rotation),V(pose.position)-origin,2,V(2,1,1)-origin,false,-origin);
  // Fully wetted boundaries: impermeability. This fixture excludes cavitation
  // and condenses exactly its authored, world-supported vertical slider.
  model.bilateral.assign(model.rows.size(),true);
  for(unsigned c=0;c<model.cells.size();++c){const auto& cell=model.cells[c];const auto& f=physical.at(prepared.source[c]);model.points[cell.first].velocity=fluid_ale::Evaluate(f,cell.center);const M b=f.gradient*cell.factor;for(unsigned k=0;k<3;++k)model.points[cell.first+1+k].velocity=b[k];}
  for(auto& row:model.rows)for(auto& g:row.bodies){g.linear=V(0,g.linear.y,0);g.angular=V(0);}
  const V velocity(world.GetLinearVelocity(body));model.bodies[0]={velocity,V(0),1./world.GetMass(body),M(0)};
  pressureEnergy=Kinetic(model,80);auto solve=ProjectEqualityQR(model,1e-10);
  if(!solve.accepted)throw std::runtime_error("native physical pressure failed");
  if(Kinetic(model,80)>pressureEnergy+1e-9)throw std::runtime_error("physical pressure creates energy");
  maxPressureResidual=std::max(maxPressureResidual,solve.residual);predictedBody=model.bodies[0].velocity;
  world.ApplyLinearImpulse(body,glm::vec3((predictedBody-velocity)*80.));pending.assign(30,{});
  for(unsigned c=0;c<model.cells.size();++c){const auto& cell=model.cells[c];M b;for(unsigned k=0;k<3;++k)b[k]=model.points[cell.first+1+k].velocity;pending[prepared.source[c]]={cell.center,model.points[cell.first].velocity,b*cell.inverse};}
  // Advance the actual front from the represented physical velocity, never
  // by assigning the whole above-plate bay a new equilibrium water level.
  struct Face{std::array<unsigned,3> ids;std::vector<unsigned> owners;};std::map<std::array<unsigned,3>,Face> faces;
  constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
  for(unsigned c=0;c<prepared.mesh.tetrahedra.size();++c)for(const auto& f:tri){const auto& ids=prepared.mesh.tetrahedra[c].vertices;std::array<unsigned,3> key{ids[f[0]],ids[f[1]],ids[f[2]]};auto ordered=key;std::sort(ordered.begin(),ordered.end());faces[ordered].ids=key;faces[ordered].owners.push_back(c);}
  double area=0;V velocityMean(0);const double plane=front.width>0?(1-origin.x)-front.width:1-origin.x;
  for(const auto& [key,f]:faces)if(f.owners.size()==1){const unsigned c=f.owners[0],source=prepared.source[c];if(front.width>0?source<24:source<18||source>=24)continue;std::array<V,3> p;bool on=true;for(unsigned i=0;i<3;++i){p[i]=prepared.mesh.vertices[f.ids[i]].position;on&=p[i].x==plane;}if(!on)continue;const double a=.5*glm::length(glm::cross(p[1]-p[0],p[2]-p[0]));area+=a;velocityMean+=a*fluid_ale::Evaluate(pending[source],(p[0]+p[1]+p[2])/3.);}
  horizontal=vertical=0;if(area>0){velocityMean/=area;horizontal=-velocityMean.x;vertical=velocityMean.y;if(front.width==0&&horizontal<0){horizontal=0;vertical=0;}}
  pressureMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count();
 }
 void TransportPart(double a,double b,double dt,VolumeDomain& candidate,std::vector<fluid_ale::Field>& staged,fluid_front::State& stagedFront){
  const double thickness=2*double(half.y);
  fluid_front::State beginning=stagedFront;
  if(beginning.width==0){beginning.bottom=(a-origin.y)+thickness;beginning.gap=std::max(0.,owned-2*a-thickness);}
  fluid_front::Motion frontMotion{a,b,owned,thickness,dt,beginning,horizontal,vertical,origin};
  auto preparedFront=fluid_front::Prepare(frontMotion);auto motion=preparedFront.mesh;const auto ending=frontMotion.At(1);
  std::string error;auto bottom=std::make_shared<const LiquidGeometry>(LiquidBox(V(0),V(1,b,1)));
  auto packet=std::make_shared<LiquidGeometry>();for(unsigned c=24;c<30;++c){LiquidTet tet;for(unsigned i=0;i<4;++i)tet[i]=motion.Position(motion.cells[c][i],1)+origin;if(fluid_ale::Measure(tet).volume>0)packet->cells.push_back(tet);}
  double packetVolume=0;std::shared_ptr<const LiquidGeometry> capacity;
  if(packet->cells.empty())capacity=std::make_shared<const LiquidGeometry>(LiquidBox(V(0,b+thickness,0),V(1)));
  else{if(!candidate.MeasureCapacity(*packet,packetVolume,error))throw std::runtime_error(error);capacity=packet;}
  const double qLower=candidate.Find(lower)->volume-b,qUpper=packetVolume-candidate.Find(upper)->volume;
  std::vector<Transfer> transfers;
  if(qLower>0)transfers.push_back({lower,right,qLower});if(qLower<0)transfers.push_back({right,lower,-qLower});
  if(qUpper>0)transfers.push_back({right,upper,qUpper});if(qUpper<0)transfers.push_back({upper,right,-qUpper});
  if(!candidate.Advance(transfers,{{lower,bottom},{upper,capacity}},error))throw std::runtime_error(error);
  if(std::abs(candidate.Find(right)->volume-(ending.surface+origin.y))>1e-12)throw std::runtime_error("quantity owner disagrees with finite incoming geometry");

  fluid_ale::Mesh active=motion;active.cells.clear();std::vector<unsigned> source;std::vector<fluid_ale::Field> initial,predicted;
  for(unsigned c=0;c<motion.cells.size();++c){LiquidTet old,next;for(unsigned i=0;i<4;++i){old[i]=motion.before[motion.cells[c][i]];next[i]=motion.after[motion.cells[c][i]];}const double va=fluid_ale::Measure(old).volume,vb=fluid_ale::Measure(next).volume;
   if(va+vb==0)continue;
   active.cells.push_back(motion.cells[c]);source.push_back(c);initial.push_back(staged[c]);auto field=staged[c];
   if(va==0){++born;const V center=fluid_ale::Measure(next).center;double nearest=INFINITY;
    // This extrapolates only a transport-WIND predictor. Physical old mass is
    // zero and the DG source term ignores it; real incoming flux initializes it.
    for(unsigned prior=0;prior<motion.cells.size();++prior){LiquidTet tet;for(unsigned i=0;i<4;++i)tet[i]=motion.before[motion.cells[prior][i]];auto m=fluid_ale::Measure(tet);if(m.volume==0)continue;double distance=glm::length(m.center-center);if(distance<nearest){nearest=distance;field=staged[prior];}}
   }
   predicted.push_back(field);
  }
  if(intervals==1&&capture)Capture(active,predicted,dt);
  const auto windStart=std::chrono::steady_clock::now();constexpr double root=.77459666924148337704;const std::array<double,3> times{.5*(1-root),.5,.5*(1+root)};std::array<fluid_conforming_wind::Result,3> wind;
  for(unsigned i=0;i<3;++i){wind[i]=fluid_conforming_wind::Project(active,predicted,times[i],dt);if(!wind[i].accepted){Capture(active,predicted,dt,".cache/fluid-domain-redesign/native-overflow-moving-pressure.txt");std::ofstream metadata(".cache/fluid-domain-redesign/native-overflow-moving-pressure-meta.txt");metadata<<std::setprecision(17)<<times[i]<<' '<<intervals<<'\n';std::printf("WIND_FAILURE time=%.17g residual=%.17g divergence=%.17g gauge=%.17g\n",times[i],wind[i].residual,0.,0.);throw std::runtime_error(wind[i].error);}}
  windMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-windStart).count();
  const auto transportStart=std::chrono::steady_clock::now();auto moved=fluid_ale::Advance(active,initial,dt,1000,[&](unsigned c,V x,double time){unsigned i=0;while(i<3&&std::abs(time-times[i])>1e-14)++i;if(i==3)throw std::runtime_error("unexpected wind quadrature");return fluid_ale::Evaluate(wind[i].fields[c],x);});
  transportMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-transportStart).count();
  if(!moved.accepted){std::printf("ALE_REJECT interval=%u a=%.17g b=%.17g dt=%.17g width=%.17g bottom=%.17g gap=%.17g horizontal=%.17g vertical=%.17g originY=%.17g gcl=%.17g constant=%.17g boundary=%.17g\n",intervals,a,b,dt,beginning.width,beginning.bottom,beginning.gap,horizontal,vertical,origin.y,moved.matrixGclError,moved.constantError,moved.boundaryError);throw std::runtime_error(moved.error);}
  maxOwnedError=std::max(maxOwnedError,std::abs(candidate.TotalVolume()-owned));
  if(maxOwnedError>1e-12||std::abs(moved.after.volume-owned)>1e-12)throw std::runtime_error("material transport disagrees with quantity owner");
  maxGcl=std::max(maxGcl,moved.matrixGclError);maxEnergyIdentity=std::max(maxEnergyIdentity,moved.energyIdentityError);
  for(unsigned c=0;c<source.size();++c)staged[source[c]]=moved.fields[c];
  stagedFront={ending.width,ending.bottom,beginning.gap};
 }
 void Finish(double dt){
  ++intervals;const double next=double(world.GetTransform(body).position.y)-half.y;
  auto candidate=ledger;auto staged=pending;auto stagedFront=pendingFront;const double critical=.5*(owned-2*double(half.y));
  if(front.width==0&&horizontal==0&&(oldHeight-critical)*(next-critical)<0){
   ++events;const double first=dt*(oldHeight-critical)/(oldHeight-next);
   TransportPart(oldHeight,critical,first,candidate,staged,stagedFront);
   TransportPart(critical,next,dt-first,candidate,staged,stagedFront);
  }else TransportPart(oldHeight,next,dt,candidate,staged,stagedFront);
  fluid_front::Motion finalPlacement{next,next,owned,2*double(half.y),1,stagedFront,0,0,origin};auto geometry=fluid_front::Prepare(finalPlacement).mesh;double fluidEnergy=0;
  for(unsigned c=0;c<geometry.cells.size();++c){LiquidTet tet;for(unsigned i=0;i<4;++i)tet[i]=geometry.after[geometry.cells[c][i]];if(fluid_ale::Measure(tet).volume>0)fluidEnergy+=fluid_material::Integrate(LiquidGeometry{{tet}},staged[c],1000).energy;}
  const double bodyError=glm::length(V(world.GetLinearVelocity(body))-predictedBody);maxBodyError=std::max(maxBodyError,bodyError);
  if(bodyError>3e-7)throw std::runtime_error("native constrained velocity disagrees with pressure");
  const double roundoff=80*(glm::length(predictedBody)+.5*bodyError)*bodyError;
  const double total=.5*80*double(glm::dot(world.GetLinearVelocity(body),world.GetLinearVelocity(body)))+fluidEnergy;
  if(total>pressureEnergy+roundoff+1e-9)throw std::runtime_error("native pressure/ALE interval creates energy");
  maxEnergy=std::max(maxEnergy,total);physical=std::move(staged);ledger=std::move(candidate);front=stagedFront;
 }
};
}
int main(int argc,char** argv){unsigned ticks=argc>1?unsigned(std::stoul(argv[1])):120;if(ticks==0||ticks>600)return 2;bool capture=false,current=false;for(int i=2;i<argc;++i){std::string option=argv[i];if(option=="--capture")capture=true;else if(option=="--incoming-current")current=true;else return 2;}unsigned failures=0;bool healthy=true;std::string error;Trial trial(capture,current);auto begin=std::chrono::steady_clock::now();
 std::printf("NATIVE_ALE_INPUT incoming_current=%d initial_energy=%.17g\n",current,40+(current?.5*1000*trial.initialHeight*.01:0));
 auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(1,[&](const auto&){if(!healthy)return;try{trial.Pressure();}catch(const std::exception& e){healthy=false;error=e.what();}},[&](const auto& phase){if(!healthy)return;try{trial.Finish(phase.deltaTime);}catch(const std::exception& e){healthy=false;error=e.what();}});
 for(unsigned tick=0;tick<ticks&&healthy;++tick)trial.world.Step(1.f/60,&coupling);
 if(!healthy||trial.intervals!=ticks*4)++failures;
 std::printf("NATIVE_ALE intervals=%u healthy=%d failures=%u born=%u events=%u initial_height=%.15g final_height=%.15g lower=%.15g right=%.15g upper=%.15g owned=%.15g max_owned_error=%g max_energy=%g pressure_residual=%g gcl=%g energy_identity=%g body_error=%g pressure_ms=%g wind_ms=%g transport_ms=%g total_ms=%g error=%s\n",trial.intervals,healthy,failures,trial.born,trial.events,trial.initialHeight,double(trial.world.GetTransform(trial.body).position.y)-trial.half.y,trial.ledger.Find(lower)->volume,trial.ledger.Find(right)->volume,trial.ledger.Find(upper)->volume,trial.owned,trial.maxOwnedError,trial.maxEnergy,trial.maxPressureResidual,trial.maxGcl,trial.maxEnergyIdentity,trial.maxBodyError,trial.pressureMs,trial.windMs,trial.transportMs,std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count(),error.c_str());return failures?1:0;
}
