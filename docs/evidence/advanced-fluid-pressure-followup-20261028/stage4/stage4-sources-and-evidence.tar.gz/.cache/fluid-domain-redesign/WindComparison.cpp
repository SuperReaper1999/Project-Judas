#define main retained_wind_comparison_main
#include "CompiledPressureTests.cpp"
#undef main
#include "AleWindProjection.h"
#include "WindCaseReader.h"
#define EqualityQrResult FullEqualityQrResult
#define ProjectEqualityQR ProjectEqualityQRFull
#include "EqualityProjectionQR.full-coordinate.h"
#undef ProjectEqualityQR
#undef EqualityQrResult
#include <fstream>
#include <iomanip>
int main(){unsigned failures=0;constexpr double t=.11270166537925831148;
 for(const std::string name:{"native-first-moving-pressure-local-recapture","native-overflow-moving-pressure"}){
  auto data=ReadWindCase(".cache/fluid-domain-redesign/"+name+".txt");
  std::vector<double> matrix;
  auto reduced=fluid_ale_fixture::ProjectWind(data.mesh,data.fields,t,data.dt,&matrix);
  auto full=fluid_ale_fixture::ProjectWind(data.mesh,data.fields,t,data.dt,nullptr,[](Model& m){m.CondenseDivergence();auto old=ProjectEqualityQRFull(m,1e-10);EqualityQrResult r;r.accepted=old.accepted;r.error=old.error;r.residual=old.residual;r.divergence=old.divergence;r.rows=old.rows;r.dofs=old.dofs;return r;});
  auto schur=fluid_ale_fixture::ProjectWind(data.mesh,data.fields,t,data.dt,nullptr,[](Model& m){m.CondenseDivergence();auto old=ProjectFluidPressure(m,64,1e-10);EqualityQrResult r;r.accepted=old.converged;r.error="preserved Schur projection failure";r.residual=old.maximumResidual;r.divergence=old.divergenceVelocity;return r;});
  double maximum=0,physical=0;for(unsigned c=0;c<data.mesh.cells.size();++c)for(auto id:data.mesh.cells[c]){auto x=data.mesh.Position(id,t);physical=std::max(physical,glm::length(fluid_ale::Evaluate(data.fields[c],x)));if(reduced.accepted)maximum=std::max(maximum,glm::length(fluid_ale::Evaluate(reduced.fields[c],x)));}
  std::ofstream dump(".cache/fluid-domain-redesign/"+name+"-reduced-operator.csv");dump<<std::setprecision(17);for(unsigned i=0;i<reduced.dofs;++i){for(unsigned j=0;j<reduced.rows;++j){if(j)dump<<',';dump<<matrix[j*reduced.dofs+i];}dump<<'\n';}
  std::printf("WIND_COMPARISON case=%s qr11=%d residual=%g divergence=%g qr12=%d residual=%g divergence=%g schur=%d residual=%g divergence=%g source_max=%g wind_max=%g rows=%u dofs=%u qr_error=%s\n",name.c_str(),reduced.accepted,reduced.residual,reduced.divergence,full.accepted,full.residual,full.divergence,schur.accepted,schur.residual,schur.divergence,physical,maximum,reduced.rows,reduced.dofs,reduced.error.c_str());
  if(!reduced.accepted)++failures;
 }
 std::printf("WIND_COMPARISON failures=%u\n",failures);return failures?1:0;}
