#include "VolumeDomain.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cstdio>
using namespace fluid_domain;
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* name){++checks;if(!ok){++failures;std::printf("FAIL %s\n",name);}};std::string error;
 for(double scale:{.001,1.,100.})for(auto normal:{glm::dvec3(1,2,4),glm::dvec3(-1,2,3),glm::dvec3(3,-2,1)})for(double fraction:{.00001,.01,.2,.6,.9999,1-1e-12}){
  LiquidGeometry geometry;geometry.cells.push_back({glm::dvec3(0),glm::dvec3(scale,0,0),glm::dvec3(0,scale,0),glm::dvec3(0,0,scale)});const double capacity=scale*scale*scale/6.;VolumeDomain domain(scale);if(!domain.Add({0,0,0},geometry,capacity*fraction,normal,error)){check(false,"single tetra reconstruction");std::printf("ERROR %s\n",error.c_str());continue;}check(true,"single tetra reconstruction");const auto* cell=domain.Find({0,0,0});double heights[4];for(unsigned i=0;i<4;++i)heights[i]=glm::dot(cell->interfaceNormal,geometry.cells[0][i])/scale;const double at=cell->interfaceCoordinate/scale;double fractionOracle=0;
  // Independent closed form: CDF of a linear function over uniform
  // barycentric coordinates on a tetrahedron (distinct vertex heights).
  // No mesh clipping, tessellation or wet-geometry routine is used here.
  for(unsigned i=0;i<4;++i){double denominator=1;for(unsigned j=0;j<4;++j)if(i!=j)denominator*=heights[j]-heights[i];const double d=std::max(0.,at-heights[i]);fractionOracle+=d*d*d/denominator;}
  check(std::abs(fractionOracle-fraction)<5e-13,"wet tetra independently matches analytic CDF");check(cell->volume==capacity*fraction,"oracle path never edits conserved quantity");double measured=0;for(const auto& tet:cell->wetGeometry->cells)measured+=std::abs(glm::determinant(glm::dmat3(tet[1]-tet[0],tet[2]-tet[0],tet[3]-tet[0])))/6.;check(std::abs(measured/capacity-fraction)<5e-13,"actual clipped wet tetra volume matches oracle");
 }
 std::printf("WET_TETRA_ORACLE checks=%u failures=%u\n",checks,failures);return failures?1:0;}
