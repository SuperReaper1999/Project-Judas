from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
impl=p.compile(out/'VolumeDomain.cpp','volume-domain')
main=p.compile(out/'FaceOwnershipProbe.cpp','face-ownership-probe');p.executable(main,'face-ownership-probe',impl)
