from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
main=p.compile(out/'AleTransportTests.cpp','ale-transport-tests');p.executable(main,'ale-transport-tests')
