from pathlib import Path
import re,tarfile,hashlib,json,shutil,subprocess,datetime
root=Path.cwd();base=root/'.cache/fluid-domain-redesign';dest=root/'docs/evidence/advanced-fluid-pressure-followup-20261028/stage4';dest.mkdir(exist_ok=True)
files={p.resolve() for p in base.iterdir() if p.is_file() and (p.suffix in ('.h','.cpp','.py','.json','.txt','.log','.csv') or p.name.endswith('.stage2-baseline'))}
files.add((root/'.cache/fluid-contact-repair/setup_probes.py').resolve());queue=list(files)
while queue:
 p=queue.pop()
 if p.suffix not in ('.h','.cpp'):continue
 for name in re.findall(r'^\s*#include\s*"([^"]+)"',p.read_text(),re.M):
  q=(p.parent/name).resolve()
  if q.is_file() and q.is_relative_to(root/'.cache') and q not in files:files.add(q);queue.append(q)
manifest=[dict(path=str(p.relative_to(root)),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)]
archive=dest/'stage4-sources-and-evidence.tar.gz'
if archive.exists():raise SystemExit('refusing to overwrite existing archive')
with tarfile.open(archive,'w:gz') as out:
 for row in manifest:out.add(root/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive) as inp:
 for row in manifest:assert hashlib.sha256(inp.extractfile(row['path']).read()).hexdigest()==row['sha256']
(dest/'SOURCE_MANIFEST.json').write_text(json.dumps(dict(baseRevision='66e6f75ed0da7b0c27c9de2629a34c2c6096899a',scope='Private numerical references and failures, NOT integrated engine backend',files=manifest),indent=2)+'\n')
(dest/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
for name in ['STAGE4_REPRODUCE.txt','STAGE4_MATHEMATICS.txt','PHASE4_RESULTS.json','PHASE4_FIRST_STOP.json','STAGE4_FINAL_RESULTS.json','stage4-final-runner.log','phase4-volume-domain-tests.log','phase4-owned-capacity-tests.log','finite-front-native-thin.log','finite-front-QR-basis.log','finite-front-gauss5.log','native-ale-actual-incoming960.log','native-ale-local-diagnostic.log','wind-comparison.log']:
 p=base/name
 if p.exists():shutil.copy2(p,dest/name)
for p in base.glob('final4-*.log'):shutil.copy2(p,dest/p.name)
previous=json.loads((dest.parent/'stage3/FINAL_FINGERPRINTS.json').read_text())
unchanged=[]
for row in previous['unchangedNativeEngine']:
 p=root/row['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==row['sha256'];unchanged.append(dict(path=row['path'],sha256=actual,unchanged=True))
for name in ['src/AdvancedFluidPolicy.h','src/BasicWater.h','src/LiquidGeometry.cpp','src/LiquidPersistence.cpp','src/LiquidTypes.cpp']:
 p=root/name;actual=hashlib.sha256(p.read_bytes()).hexdigest();expected=hashlib.sha256(subprocess.check_output(['git','show','66e6f75:'+name])).hexdigest();assert actual==expected;unchanged.append(dict(path=name,sha256=actual,unchanged=True))
library=root/'build/libjudas_engine.a';libraryHash=hashlib.sha256(library.read_bytes()).hexdigest();assert libraryHash==previous['nativeLibrarySha256']
(dest/'FINAL_FINGERPRINTS.json').write_text(json.dumps(dict(createdUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),unchangedNativeEngine=unchanged,nativeLibrarySha256=libraryHash,reportSha256=hashlib.sha256((root/'docs/ADVANCED_FLUID_PRESSURE_FOLLOWUP.txt').read_bytes()).hexdigest(),archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2)+'\n')
print('Verified source archive',len(manifest),'members',archive.stat().st_size,'bytes')
