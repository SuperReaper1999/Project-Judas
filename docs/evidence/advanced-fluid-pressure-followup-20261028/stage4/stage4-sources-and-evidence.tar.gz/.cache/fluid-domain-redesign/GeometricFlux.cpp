#include "GeometricFlux.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <set>

namespace fluid_domain {
GeometricFluxStep ResolveFlux(const VolumeDomain& domain, double dt,
    const std::vector<Face>& predictedFaces, const std::vector<CapacityChange>& changes) {
    GeometricFluxStep result;
    if (!(dt>0)||!std::isfinite(dt)) {result.error="invalid geometric transport interval";return result;}
    std::map<Key,double> capacities;
    std::map<Key,pressure_prototype::Row> upper,lower;
    for(const auto& change:changes) {
        if(!change.geometry||!domain.Find(change.cell)||capacities.count(change.cell)) {
            result.error="invalid resolved capacity owner";return result;
        }
        double capacity;
        if(!domain.MeasureCapacity(*change.geometry,capacity,result.error))return result;
        capacities.emplace(change.cell,capacity);
    }
    auto touch=[&](Key key) {
        const auto* cell=domain.Find(key);
        if(!cell)return false;
        auto capacity=capacities.find(key);
        upper[key].maximumRate=(capacity==capacities.end()?cell->capacity:capacity->second)-cell->volume;
        lower[key].maximumRate=cell->volume;
        return true;
    };
    for(auto& changed:capacities)touch(changed.first);
    std::vector<pressure_prototype::Point> volumes;
    std::vector<double> predicted;
    std::vector<pressure_prototype::Row> rows;
    std::set<std::pair<Key,Key>> unique;
    for(unsigned i=0;i<predictedFaces.size();++i) {
        const auto& face=predictedFaces[i];
        if(!(face.mass>0)||!std::isfinite(face.mass)||!std::isfinite(face.velocity)||!touch(face.a)||!touch(face.b)) {
            result.error="invalid integrated-flow degree of freedom";return result;
        }
        auto key=face.b<face.a?std::make_pair(face.b,face.a):std::make_pair(face.a,face.b);
        if(!unique.insert(key).second){result.error="duplicate integrated-flow face";return result;}
        double forward=domain.SharedWetAperture(face.a,face.b,result.error);
        if(!result.error.empty())return result;
        double reverse=domain.SharedWetAperture(face.b,face.a,result.error);
        if(!result.error.empty())return result;
        const double area=std::max(forward,reverse);
        if(!(area>0)){result.error="resolved transfer crosses a closed aperture";return result;}
        const double proposed=face.velocity*dt*(face.velocity>=0?forward:reverse);
        predicted.push_back(proposed);
        // Scaling by the common dt^2 does not affect this minimum-change
        // projection. A volume displacement has metric mass/area^2.
        volumes.push_back({{proposed,0,0},area*area/face.mass});
        upper[face.a].points.push_back({i,{-1,0,0}});
        upper[face.b].points.push_back({i,{1,0,0}});
        lower[face.a].points.push_back({i,{1,0,0}});
        lower[face.b].points.push_back({i,{-1,0,0}});
        if(forward==0)rows.push_back({{{i,{1,0,0}}},{},0});
        if(reverse==0)rows.push_back({{{i,{-1,0,0}}},{},0});
    }
    for(auto& row:upper){rows.push_back(row.second);rows.push_back(lower.at(row.first));}
    std::vector<pressure_prototype::Body> noBodies;
    const double tolerance=32*std::numeric_limits<double>::epsilon()*std::max(domain.TotalVolume(),std::numeric_limits<double>::min());
    try {result.solver=grid_fluid::ProjectTransactional(volumes,noBodies,rows,256,tolerance);}
    catch(const std::exception& error){result.error=error.what();return result;}
    if(!result.solver.converged){result.error="resolved geometric flux is infeasible or unconverged";return result;}
    for(unsigned i=0;i<volumes.size();++i) {
        const auto& face=predictedFaces[i];const double volume=volumes[i].velocity.x;
        result.maximumTransferDifference=std::max(result.maximumTransferDifference,std::abs(volume-predicted[i]));
        if(volume>0)result.transfers.push_back({face.a,face.b,volume});
        if(volume<0)result.transfers.push_back({face.b,face.a,-volume});
    }
    result.converged=true;
    return result;
}
}
