from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
impl=p.compile(out/'VolumeDomain.cpp','volume-domain')
main=p.compile(out/'MovingCutMeshTests.cpp','moving-cut-mesh-tests');p.executable(main,'moving-cut-mesh-tests',impl)
