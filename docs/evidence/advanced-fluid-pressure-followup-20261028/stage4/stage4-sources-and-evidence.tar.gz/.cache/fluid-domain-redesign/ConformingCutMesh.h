#pragma once
#include "ExactPlanePredicates.h"
#include "LiquidGeometry.h"
#include <map>
#include <set>
#include <array>
#include <algorithm>
#include <cstdint>
#include <string>
#include <glm/glm.hpp>

namespace fluid_mesh {
using V=glm::dvec3;
using Triple=std::array<unsigned,3>;
using Lattice=std::array<int,3>;
struct Vertex {
    fluid_exact::Intersection exact;
    Triple planes;
    V position;
};
struct Face { unsigned plane; std::vector<unsigned> vertices; };
struct Polyhedron { std::vector<Face> faces; unsigned outside=0,voxel=0; };
struct Tetrahedron { LiquidTet geometry; std::array<unsigned,4> vertices; unsigned voxel=0; };
struct Compiler {
    std::vector<fluid_exact::Plane> planes;
    std::vector<Vertex> vertices;
    std::map<Triple,unsigned> intersections;
    std::map<Lattice,std::vector<unsigned>> buckets;
    std::map<std::array<Lattice,3>,unsigned> backgroundFaces;
    std::vector<Tetrahedron> tetrahedra;
    std::vector<unsigned> bodyPlanes,wetPlanes;
    unsigned centers=0;

    unsigned AddPlane(V n,double d) {
        if(!std::isfinite(d)||!std::isfinite(n.x)||!std::isfinite(n.y)||!std::isfinite(n.z)||glm::dot(n,n)==0)
            throw std::invalid_argument("invalid cut plane");
        planes.push_back({{n.x,n.y,n.z},d});
        return unsigned(planes.size()-1);
    }
    int Side(unsigned vertex,unsigned plane)const {return vertices.at(vertex).exact.Side(planes.at(plane));}
    unsigned Intersection(Triple ids) {
        std::sort(ids.begin(),ids.end());
        if(auto found=intersections.find(ids);found!=intersections.end())return found->second;
        auto exact=fluid_exact::Intersection::Make({planes.at(ids[0]),planes.at(ids[1]),planes.at(ids[2])});
        const auto raw=exact.Position();V position(raw[0],raw[1],raw[2]);
        // Spatial buckets only locate possible aliases. Exact plane predicates
        // prove identity; proximity NEVER establishes a shared vertex.
        Lattice bucket;
        for(unsigned a=0;a<3;++a){const double value=std::floor(position[a]*1024);if(std::abs(value)>1e8)throw std::runtime_error("cut mesh outside bounded local frame");bucket[a]=int(value);}
        for(int z=-1;z<=1;++z)for(int y=-1;y<=1;++y)for(int x=-1;x<=1;++x){Lattice key{bucket[0]+x,bucket[1]+y,bucket[2]+z};auto found=buckets.find(key);if(found==buckets.end())continue;for(unsigned candidate:found->second){bool same=true;for(unsigned plane:vertices[candidate].planes)same&=exact.Side(planes[plane])==0;if(same){intersections.emplace(ids,candidate);return candidate;}}}
        const unsigned id=unsigned(vertices.size());vertices.push_back({std::move(exact),ids,position});intersections.emplace(ids,id);buckets[bucket].push_back(id);return id;
    }
    unsigned BackgroundPlane(std::array<Lattice,3> triangle) {
        std::sort(triangle.begin(),triangle.end());
        if(auto found=backgroundFaces.find(triangle);found!=backgroundFaces.end())return found->second;
        auto vec=[](Lattice p){return V(p[0],p[1],p[2]);};
        const V a=vec(triangle[0]),normal=glm::cross(vec(triangle[1])-a,vec(triangle[2])-a);
        const unsigned id=AddPlane(normal,glm::dot(normal,a));backgroundFaces.emplace(triangle,id);return id;
    }
    Polyhedron Seed(std::array<Lattice,4> points) {
        constexpr unsigned triangles[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
        std::array<unsigned,4> facePlanes,corner;
        for(unsigned f=0;f<4;++f)facePlanes[f]=BackgroundPlane({points[triangles[f][0]],points[triangles[f][1]],points[triangles[f][2]]});
        for(unsigned v=0;v<4;++v){Triple ids;unsigned at=0;for(unsigned f=0;f<4;++f)if(f!=v)ids[at++]=facePlanes[f];corner[v]=Intersection(ids);}
        Polyhedron result;
        for(unsigned f=0;f<4;++f){Face face{facePlanes[f],{corner[triangles[f][0]],corner[triangles[f][1]],corner[triangles[f][2]]}};const auto a=vertices[face.vertices[0]].position,b=vertices[face.vertices[1]].position,c=vertices[face.vertices[2]].position;if(glm::dot(glm::cross(b-a,c-a),vertices[corner[f]].position-a)>0)std::reverse(face.vertices.begin(),face.vertices.end());result.faces.push_back(std::move(face));}
        return result;
    }
    unsigned CutEdge(unsigned a,unsigned b,unsigned facePlane,unsigned cutPlane,const Polyhedron& original) {
        for(const auto& other:original.faces)if(other.plane!=facePlane&&Side(a,other.plane)==0&&Side(b,other.plane)==0){
            try{return Intersection({facePlane,other.plane,cutPlane});}catch(const std::invalid_argument&){/* parallel candidate is not this crossing edge */}
        }
        throw std::runtime_error("crossing cut edge has no independent owned planes");
    }
    Polyhedron Clip(const Polyhedron& original,unsigned plane,int keep) {
        bool positive=false,negative=false;
        for(const auto& face:original.faces)for(unsigned v:face.vertices){const int sign=keep*Side(v,plane);positive|=sign>0;negative|=sign<0;}
        if(!positive)return original;
        if(!negative)return {};
        Polyhedron result;result.outside=original.outside;result.voxel=original.voxel;
        std::map<unsigned,unsigned> capEdges;
        for(const auto& face:original.faces){Face clipped{face.plane,{}};
            for(unsigned i=0;i<face.vertices.size();++i){const unsigned a=face.vertices[i],b=face.vertices[(i+1)%face.vertices.size()];const int sa=keep*Side(a,plane),sb=keep*Side(b,plane);if(sa<=0)clipped.vertices.push_back(a);if((sa<0&&sb>0)||(sa>0&&sb<0))clipped.vertices.push_back(CutEdge(a,b,face.plane,plane,original));}
            clipped.vertices.erase(std::unique(clipped.vertices.begin(),clipped.vertices.end()),clipped.vertices.end());
            if(clipped.vertices.size()>1&&clipped.vertices.front()==clipped.vertices.back())clipped.vertices.pop_back();
            if(clipped.vertices.size()<3)continue;
            for(unsigned i=0;i<clipped.vertices.size();++i){const unsigned a=clipped.vertices[i],b=clipped.vertices[(i+1)%clipped.vertices.size()];if(a!=b&&Side(a,plane)==0&&Side(b,plane)==0){auto [at,inserted]=capEdges.emplace(b,a);if(!inserted&&at->second!=a)throw std::runtime_error("branched cut cap");}}
            result.faces.push_back(std::move(clipped));
        }
        if(capEdges.size()<3)throw std::runtime_error("missing closed cut cap");
        Face cap{plane,{}};const unsigned start=capEdges.begin()->first;unsigned at=start;
        do{cap.vertices.push_back(at);auto next=capEdges.find(at);if(next==capEdges.end())throw std::runtime_error("open cut cap");at=next->second;if(cap.vertices.size()>capEdges.size())throw std::runtime_error("cyclic cut cap repeats");}while(at!=start);
        if(cap.vertices.size()!=capEdges.size())throw std::runtime_error("multiple cut caps in convex piece");
        result.faces.push_back(std::move(cap));return result;
    }
    bool Collinear(unsigned a,unsigned b,unsigned c,unsigned face)const {
        // A second independent owned plane containing all three proves a line.
        for(unsigned plane:vertices[a].planes)if(plane!=face&&Side(b,plane)==0&&Side(c,plane)==0){
            const auto& p=planes[plane];const auto& q=planes[face];
            for(unsigned axis=0;axis<3;++axis){unsigned j=(axis+1)%3,k=(axis+2)%3;auto cross=fluid_exact::Sum(fluid_exact::Product({p.normal[j]},{q.normal[k]}),fluid_exact::Negate(fluid_exact::Product({p.normal[k]},{q.normal[j]})));if(fluid_exact::Sign(cross)!=0)return true;}
        }
        return false;
    }
    void Emit(const Polyhedron& polyhedron) {
        std::set<unsigned> unique;for(const auto& face:polyhedron.faces)unique.insert(face.vertices.begin(),face.vertices.end());if(unique.size()<4)throw std::runtime_error("cut piece has no3D interior");
        // A globally ordered pulling triangulation keeps shared-face diagonals
        // identical without inserting an interior vertex or four tets where
        // the piece was already a single tetrahedron.
        const unsigned anchor=*unique.begin();const V center=vertices[anchor].position;
        for(const auto& face:polyhedron.faces){if(Side(anchor,face.plane)==0)continue;auto polygon=face.vertices;const auto first=std::min_element(polygon.begin(),polygon.end());std::rotate(polygon.begin(),first,polygon.end());for(unsigned i=1;i+1<polygon.size();++i){unsigned a=polygon[0],b=polygon[i],c=polygon[i+1];if(Collinear(a,b,c,face.plane))continue;const V pa=vertices[a].position,pb=vertices[b].position,pc=vertices[c].position;double det=glm::determinant(glm::dmat3(pa-center,pb-center,pc-center));if(!(det>0))throw std::runtime_error("nonpositive represented cut tetrahedron");tetrahedra.push_back({{center,pa,pb,pc},{anchor,a,b,c},polyhedron.voxel});}}

    }
    bool TryMoveBox(const std::array<fluid_exact::Plane,6>& box,std::string& error) {
        if(bodyPlanes.size()!=6){error="no compiled box geometry";return false;}
        Compiler staged=*this;
        try {
            for(unsigned i=0;i<6;++i){const auto& p=box[i];if(!std::isfinite(p.coordinate))throw std::invalid_argument("nonfinite moved plane");for(double v:p.normal)if(!std::isfinite(v))throw std::invalid_argument("nonfinite moved normal");staged.planes[bodyPlanes[i]]=p;}
            for(unsigned i=0;i<vertices.size();++i){const auto ids=vertices[i].planes;auto exact=fluid_exact::Intersection::Make({staged.planes[ids[0]],staged.planes[ids[1]],staged.planes[ids[2]]});
                for(unsigned plane:bodyPlanes)if(exact.Side(staged.planes[plane])!=vertices[i].exact.Side(planes[plane])){error="cut topology changed; full preparation required";return false;}
                auto position=exact.Position();staged.vertices[i].exact=std::move(exact);staged.vertices[i].position={position[0],position[1],position[2]};
            }
            // A formerly degenerate shared corner may split as the body moves.
            // Every symbolic alias must still be an EXACT common intersection.
            for(const auto& [ids,index]:intersections){const auto& point=staged.vertices[index];for(unsigned plane:ids)if(point.exact.Side(staged.planes[plane])!=0){error="shared cut vertex split; full preparation required";return false;}}
            for(auto& tetrahedron:staged.tetrahedra){for(unsigned i=0;i<4;++i)tetrahedron.geometry[i]=staged.vertices.at(tetrahedron.vertices[i]).position;const auto& p=tetrahedron.geometry;const double determinant=glm::determinant(glm::dmat3(p[1]-p[0],p[2]-p[0],p[3]-p[0]));if(!(determinant>0)){error="cut element lost positive orientation; full preparation required";return false;}}
            staged.buckets.clear();for(unsigned i=0;i<staged.vertices.size();++i){Lattice key;for(unsigned a=0;a<3;++a){const double value=std::floor(staged.vertices[i].position[a]*1024);if(std::abs(value)>1e8)throw std::runtime_error("moved cut geometry outside local frame");key[a]=int(value);}staged.buckets[key].push_back(i);}
        }catch(const std::exception& failure){error=failure.what();return false;}
        *this=std::move(staged);return true;
    }
    // Initial scope: one bounded native convex box represented by its six
    // planes, on a lattice-local tetrahedral background. All arrangement cuts
    // are applied consistently, including outside the solid. No feature-size
    // pruning, coordinate weld or voxel occupancy approximation is used.
    using WetComponent = std::vector<fluid_exact::Plane>;
    using WetCell = std::vector<WetComponent>;
    // A union of explicitly owned convex wet regions per voxel. Empty cell:
    // dry. Empty component: fully wet capacity. No fitted plane invents fill
    // between disconnected fragments, and no proximity rule joins them.
    void BuildRegions(unsigned grid,
                      const std::array<fluid_exact::Plane,6>& box,
                      const std::vector<WetCell>& wetRegions) {
        if(grid==0||grid>8)
            throw std::invalid_argument("bounded cut-mesh grid outside prototype scope");
        if(!planes.empty()||!tetrahedra.empty())
            throw std::invalid_argument("compiler instance already owns geometry");
        if(!wetRegions.empty()&&wetRegions.size()!=grid*grid*grid)
            throw std::invalid_argument("one owned wet-region list required per voxel");
        for(auto plane:box)
            bodyPlanes.push_back(AddPlane({plane.normal[0],plane.normal[1],plane.normal[2]},plane.coordinate));
        std::vector<std::vector<std::vector<unsigned>>> regions(wetRegions.size());
        for(unsigned cell=0;cell<wetRegions.size();++cell){
            if(wetRegions[cell].size()>8)
                throw std::invalid_argument("bounded wet-component count exceeded");
            for(const auto& component:wetRegions[cell]){
                if(component.size()>12)
                    throw std::invalid_argument("bounded wet-component plane count exceeded");
                std::vector<unsigned> owned;
                for(const auto& plane:component){
                    const unsigned id=AddPlane({plane.normal[0],plane.normal[1],plane.normal[2]},plane.coordinate);
                    owned.push_back(id);wetPlanes.push_back(id);
                }
                regions[cell].push_back(std::move(owned));
            }
        }
        std::vector<unsigned> cuts=bodyPlanes;
        cuts.insert(cuts.end(),wetPlanes.begin(),wetPlanes.end());
        constexpr unsigned cubeTets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
        for(unsigned z=0;z<grid;++z)for(unsigned y=0;y<grid;++y)for(unsigned x=0;x<grid;++x){
            std::array<Lattice,8> corners;
            for(unsigned i=0;i<8;++i)
                corners[i]={int(x+(i&1)),int(y+((i>>1)&1)),int(z+((i>>2)&1))};
            for(auto indices:cubeTets){
                auto seed=Seed({corners[indices[0]],corners[indices[1]],corners[indices[2]],corners[indices[3]]});
                seed.voxel=(y*grid+z)*grid+x;
                std::vector<Polyhedron> pieces{std::move(seed)};
                for(unsigned cut=0;cut<cuts.size();++cut){
                    std::vector<Polyhedron> next;
                    for(const auto& piece:pieces){
                        auto inside=Clip(piece,cuts[cut],1),outside=Clip(piece,cuts[cut],-1);
                        if(!inside.faces.empty())next.push_back(std::move(inside));
                        if(!outside.faces.empty()){
                            if(cut<6)outside.outside|=1u<<cut;
                            next.push_back(std::move(outside));
                        }
                    }
                    pieces=std::move(next);
                    if(pieces.size()>128)
                        throw std::runtime_error("bounded convex arrangement exceeded");
                }
                for(const auto& piece:pieces){
                    if(!piece.outside)continue;
                    bool wet=regions.empty();
                    if(!regions.empty())for(const auto& component:regions[piece.voxel]){
                        bool inside=true;
                        for(unsigned plane:component)for(const auto& face:piece.faces)
                            for(unsigned vertex:face.vertices)inside&=Side(vertex,plane)<=0;
                        wet|=inside;
                    }
                    if(wet)Emit(piece);
                }
            }
        }
    }
    void Build(unsigned grid,const std::array<fluid_exact::Plane,6>& box,
               const std::vector<fluid_exact::Plane>& wetProfiles={}) {
        if(wetProfiles.empty()){BuildRegions(grid,box,{});return;}
        if(wetProfiles.size()!=grid*grid*grid)
            throw std::invalid_argument("one owned interface plane required per voxel");
        std::vector<WetCell> regions;
        for(const auto& plane:wetProfiles)regions.push_back(WetCell{WetComponent{plane}});
        BuildRegions(grid,box,regions);
    }

};
}
