#pragma once
#include "AleTransport.h"
#include <memory>
namespace fluid_front {
using V=glm::dvec3;
struct State {double width=0,bottom=0,gap=0;};
struct Motion {
 double oldHeight=0,newHeight=0,owned=0,thickness=0,dt=0;
 State initial;double horizontal=0,vertical=0;
 struct Sample {double height,top,width,bottom,frontTop,surface,mid;double dh,dw,db,ds,dm;};
 Sample At(double time)const{
  Sample s{};s.dh=newHeight-oldHeight;s.height=oldHeight+time*s.dh;s.top=s.height+thickness;
  s.dw=horizontal*dt;s.width=initial.width+time*s.dw;s.db=vertical*dt;s.bottom=initial.bottom+time*s.db;s.frontTop=s.bottom+initial.gap;
  if(s.width<0||s.width>1)throw std::runtime_error("finite liquid front leaves bounded fixture");
  const double numerator=std::fma(-2.,s.height,owned-thickness)-.5*s.width*initial.gap,denominator=1+.5*s.width;
  const double gap=numerator/denominator;
  const double dg=((-2*s.dh-.5*s.dw*initial.gap)*denominator-numerator*.5*s.dw)/(denominator*denominator);
  s.surface=s.top+gap;s.ds=s.dh+dg;s.mid=std::min(s.surface,s.top);s.dm=s.surface<s.top?s.ds:s.dh;
  if(s.width>0&&(gap<0||s.bottom<s.top))throw std::runtime_error("finite front requires detachment or solid contact preparation");
  return s;
 }
 double PacketVolume(double time)const{auto s=At(time);return .5*s.width*(initial.gap+std::max(0.,s.surface-s.top));}
};
struct Prepared {fluid_ale::Mesh mesh;std::vector<std::array<unsigned,3>> keys;};
inline Prepared Prepare(const Motion& input){
 if(!(input.dt>0))throw std::invalid_argument("invalid front interval");auto motion=std::make_shared<const Motion>(input);Prepared result;std::map<std::array<unsigned,3>,unsigned> owned;
 auto vertex=[&](unsigned x,unsigned y,unsigned z){std::array<unsigned,3> key{x,y,z};auto it=owned.find(key);if(it!=owned.end())return it->second;unsigned id=result.keys.size();owned[key]=id;result.keys.push_back(key);return id;};
 constexpr unsigned tets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
 for(unsigned brick=0;brick<5;++brick){std::array<unsigned,8> p;for(unsigned i=0;i<8;++i){unsigned x,y;if(brick==4){x=(i&1)?1:3;y=2+((i>>1)&1);}else{x=(brick==0?0:1)+(i&1);y=(brick<2?0:brick==2?1:2)+((i>>1)&1);}p[i]=vertex(x,y,(i>>2)&1);}for(const auto& tet:tets)result.mesh.cells.push_back({p[tet[0]],p[tet[1]],p[tet[2]],p[tet[3]]});}
 auto keys=std::make_shared<const std::vector<std::array<unsigned,3>>>(result.keys);
 result.mesh.trajectory=[motion,keys](unsigned v,double t){auto s=motion->At(t);auto key=keys->at(v);if(key[0]==3)return V(1-s.width,key[1]==2?s.bottom:s.frontTop,key[2]);return V(key[0],key[1]==0?0:key[1]==1?s.height:key[1]==2?s.mid:s.surface,key[2]);};
 result.mesh.derivative=[motion,keys](unsigned v,double t){auto s=motion->At(t);auto key=keys->at(v);if(key[0]==3)return V(-s.dw,s.db,0);return V(0,key[1]==0?0:key[1]==1?s.dh:key[1]==2?s.dm:s.ds,0);};
 for(unsigned v=0;v<result.keys.size();++v){result.mesh.before.push_back(result.mesh.Position(v,0));result.mesh.after.push_back(result.mesh.Position(v,1));}
 return result;
}
inline fluid_ale::Mesh Active(const fluid_ale::Mesh& full,std::vector<unsigned>& source){auto active=full;active.cells.clear();source.clear();for(unsigned c=0;c<full.cells.size();++c){LiquidTet a,b;for(unsigned i=0;i<4;++i){a[i]=full.Position(full.cells[c][i],0);b[i]=full.Position(full.cells[c][i],1);}if(fluid_ale::Measure(a).volume+fluid_ale::Measure(b).volume>0){source.push_back(c);active.cells.push_back(full.cells[c]);}}return active;}
}
