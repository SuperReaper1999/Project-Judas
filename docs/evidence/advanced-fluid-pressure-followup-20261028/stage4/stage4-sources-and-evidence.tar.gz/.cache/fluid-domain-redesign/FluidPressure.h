#pragma once
#include "AffineModel.h"
#include "SparseInterior.h"
namespace {
struct FluidProjectionResult:VelocityProjectionResult {double divergenceVelocity=0;};
inline double FluidDivergenceVelocity(const Model& model){double maximum=0;for(const auto& cell:model.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){const V gradient=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(gradient,model.points[cell.first+1+k].velocity);norm+=glm::dot(gradient,gradient);}if(!(norm>0)||!std::isfinite(norm))throw std::invalid_argument("invalid fluid affine frame");maximum=std::max(maximum,std::abs(trace)/std::sqrt(norm));}return maximum;}
inline FluidProjectionResult ProjectFluidPressure(Model& model,unsigned budget,double tolerance,SparseWorkspace* workspace=nullptr){
 auto points=model.points;auto bodies=model.bodies;const auto oldPressure=workspace?workspace->pressureImpulse:std::vector<double>{};
 // Exact local nullspace elimination requires projecting the PREDICTED state,
 // not only the external constraint gradients. This is an orthogonal physical
 // incompressibility projection; it preserves each cell's linear/angular momenta.
 for(const auto& cell:model.cells){double trace=0,norm=0;std::array<V,3> direction;for(unsigned k=0;k<3;++k){direction[k]=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(direction[k],points[cell.first+1+k].velocity);norm+=glm::dot(direction[k],direction[k]);}if(!(norm>0)||!std::isfinite(norm))throw std::invalid_argument("invalid fluid nullspace mass metric");for(unsigned k=0;k<3;++k)points[cell.first+1+k].velocity-=direction[k]*(trace/norm);}
 FluidProjectionResult result;
 try{static_cast<VelocityProjectionResult&>(result)=SparseInterior(points,bodies,model.rows,model.bilateral,budget,tolerance,workspace);}catch(...){if(workspace)workspace->pressureImpulse=oldPressure;throw;}
 if(!result.converged){if(workspace)workspace->pressureImpulse=oldPressure;return result;}
 // Check the real represented field rather than a cached solver status.
 for(const auto& cell:model.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){const V gradient=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(gradient,points[cell.first+1+k].velocity);norm+=glm::dot(gradient,gradient);}result.divergenceVelocity=std::max(result.divergenceVelocity,std::abs(trace)/std::sqrt(norm));}
 if(result.divergenceVelocity>tolerance){result.converged=false;if(workspace)workspace->pressureImpulse=oldPressure;return result;}
 model.points=std::move(points);model.bodies=std::move(bodies);return result;
}
}
