from pathlib import Path
import subprocess,json,hashlib,datetime,time
root=Path.cwd();out=root/'.cache/fluid-domain-redesign';results=[]
programs=[('build_finite_front.py','finite-front-tests',[[]]),('build_conforming_wind.py','conforming-wind-tests',[[]]),('build_reference_ale.py','reference-ale-tests',[[]]),('build_native_ale.py','native-ale-piston-tests',[['120'],['240','--incoming-current']]),('build_wind_comparison.py','wind-comparison',[[]])]
for builder,name,cases in programs:
 with (out/f'final4-{name}-build.log').open('w') as log:
  built=subprocess.run(['python3',str(out/builder)],stdout=log,stderr=subprocess.STDOUT)
 if built.returncode:raise SystemExit('build failure: '+name)
 exe=root/'.cache/fluid-contact-repair'/name
 for index,args in enumerate(cases):
  logname=f'final4-{name}-{index}.log';start=time.monotonic()
  with (out/logname).open('w') as log:
   run=subprocess.run([str(exe),*args],stdout=log,stderr=subprocess.STDOUT,timeout=90)
  record=dict(test=name,arguments=args,exit=run.returncode,binarySha256=hashlib.sha256(exe.read_bytes()).hexdigest(),log=logname,seconds=time.monotonic()-start);results.append(record)
  (out/'STAGE4_FINAL_RESULTS.json').write_text(json.dumps(dict(baseRevision='66e6f75ed0da7b0c27c9de2629a34c2c6096899a',updatedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Private numerical prototypes; no runtime backend integration',tests=results),indent=2)+'\n');print(json.dumps(record),flush=True)
  if run.returncode:raise SystemExit('test failure: '+name)
