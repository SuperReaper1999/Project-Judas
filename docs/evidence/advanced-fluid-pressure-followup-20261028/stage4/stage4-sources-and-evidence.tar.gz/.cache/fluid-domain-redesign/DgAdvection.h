#pragma once
#include "AffineModel.h"
#include "ConformingCutMesh.h"
#include <functional>
namespace { namespace fluid_advection {
struct Face{unsigned a,b;std::array<V,3> vertices;V normal;double twiceArea;};
struct Transport {
 const Model& model;std::vector<Face> faces;
 Transport(const Model& m,const fluid_mesh::Compiler& mesh):model(m){
  struct Owner{unsigned cell;std::array<V,3> points;};std::map<std::array<unsigned,3>,std::vector<Owner>> owners;constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
  for(unsigned cell=0;cell<mesh.tetrahedra.size();++cell){const auto& t=mesh.tetrahedra[cell];for(auto& face:tri){std::array<unsigned,3> key{t.vertices[face[0]],t.vertices[face[1]],t.vertices[face[2]]};std::sort(key.begin(),key.end());owners[key].push_back({cell,{t.geometry[face[0]],t.geometry[face[1]],t.geometry[face[2]]}});}}
  for(const auto& [key,list]:owners){if(list.size()>2)throw std::runtime_error("nonmanifold transport face");const auto& first=list[0];auto p=first.points;V normal=glm::cross(p[1]-p[0],p[2]-p[0]);if(glm::dot(normal,model.cells[first.cell].center-p[0])>0)normal=-normal;double area=glm::length(normal);if(!(area>0))throw std::runtime_error("zero transport face");faces.push_back({first.cell,list.size()==2?list[1].cell:unsigned(-1),p,normal/area,area});}
 }
 static V Evaluate(const std::vector<Point>& state,const FluidCell& cell,V x){V value=state[cell.first].velocity;const V basis=cell.inverse*(x-cell.center);for(unsigned k=0;k<3;++k)value+=basis[k]*state[cell.first+1+k].velocity;return value;}
 // Immutable, fully filled mesh proof first. The prescribed affine advector
 // must be divergence-free with continuous shared normal traces. This is not
 // the complete moving-domain/free-surface solver. Mass/centroid/covariance and the weak flux operator share one geometry.
 std::vector<V> Rate(const std::vector<Point>& state,const std::vector<Point>& advector,double time,const std::function<V(V,double)>& inflow)const{
  if(state.size()!=model.points.size()||advector.size()!=state.size())throw std::invalid_argument("transport coefficient count does not match owned mesh");
  std::vector<V> derivative(state.size(),V(0));
  for(const auto& cell:model.cells)for(unsigned k=0;k<3;++k){V gradient(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);derivative[cell.first+1+k]+=state[cell.first].velocity*glm::dot(gradient,advector[cell.first].velocity);for(unsigned j=0;j<3;++j)derivative[cell.first+1+k]+=state[cell.first+1+j].velocity*glm::dot(gradient,advector[cell.first+1+j].velocity);}
  constexpr double root3=.57735026918962576451,root35=.77459666924148337704;const double gaussS[3]={.5*(1-root35),.5,.5*(1+root35)},weightS[3]={5./18,4./9,5./18},gaussT[2]={.5*(1-root3),.5*(1+root3)};
  for(const auto& face:faces){
   for(unsigned i=0;i<3;++i)for(unsigned j=0;j<2;++j){const double s=gaussS[i],t=gaussT[j];const V x=face.vertices[0]+s*(face.vertices[1]-face.vertices[0])+(1-s)*t*(face.vertices[2]-face.vertices[0]);const double normal=glm::dot(face.normal,Evaluate(advector,model.cells[face.a],x));if(normal==0)continue;const double weight=weightS[i]*.5*(1-s)*face.twiceArea;const unsigned upwind=normal>0?face.a:face.b;const V value=upwind==unsigned(-1)?inflow(x,time):Evaluate(state,model.cells[upwind],x);const V flux=weight*normal*value;
    auto add=[&](unsigned at,double sign){const auto& cell=model.cells[at];const V basis=cell.inverse*(x-cell.center);const V change=sign*1000*flux/cell.mass;derivative[cell.first]+=change;for(unsigned k=0;k<3;++k)derivative[cell.first+1+k]+=basis[k]*change;};
    add(face.a,-1);if(face.b!=unsigned(-1))add(face.b,1);
   }
  }
  return derivative;
 }
 void Advance(std::vector<Point>& state,const std::vector<Point>& velocity,double time,double dt,const std::function<V(V,double)>& inflow)const{
  if(!std::isfinite(dt)||dt<=0||!std::isfinite(time)||!inflow)throw std::invalid_argument("invalid transport interval or inflow");
  if(state.size()!=model.points.size()||velocity.size()!=state.size())throw std::invalid_argument("transport coefficient count does not match owned mesh");
  bool stationary=true;for(unsigned i=0;i<state.size();++i)for(unsigned a=0;a<3;++a){if(!std::isfinite(state[i].velocity[a])||!std::isfinite(velocity[i].velocity[a]))throw std::invalid_argument("nonfinite transport input");stationary&=velocity[i].velocity[a]==0;}
  if(stationary)return;
  const auto initial=state;auto first=state,second=state;auto rate=Rate(initial,velocity,time,inflow);for(unsigned i=0;i<state.size();++i)first[i].velocity=initial[i].velocity+dt*rate[i];rate=Rate(first,velocity,time+dt,inflow);for(unsigned i=0;i<state.size();++i)second[i].velocity=.75*initial[i].velocity+.25*(first[i].velocity+dt*rate[i]);rate=Rate(second,velocity,time+.5*dt,inflow);auto staged=state;for(unsigned i=0;i<state.size();++i){staged[i].velocity=(initial[i].velocity+2.0*(second[i].velocity+dt*rate[i]))/3.;for(unsigned a=0;a<3;++a)if(!std::isfinite(staged[i].velocity[a]))throw std::runtime_error("nonfinite staged transport velocity");}state=std::move(staged);
 }
 void Advance(std::vector<Point>& state,V velocity,double time,double dt,const std::function<V(V,double)>& inflow)const{auto advector=state;for(auto& point:advector)point.velocity=V(0);for(const auto& cell:model.cells)advector[cell.first].velocity=velocity;Advance(state,advector,time,dt,inflow);}

};
} }
