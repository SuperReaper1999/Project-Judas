from pathlib import Path
import sys,subprocess
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
implementation=p.compile(out/'VolumeDomain.cpp','volume-domain')
flow=p.compile(out/'FacePressure.cpp','face-pressure')
override=out/'native-pressure-overrides.o'
subprocess.run(['c++','-r',str(implementation),str(flow),'-o',str(override)],check=True)
tests=p.compile(out/'NativeVolumePistonTests.cpp','native-volume-piston-tests')
p.executable(tests,'native-volume-piston-tests',override)
