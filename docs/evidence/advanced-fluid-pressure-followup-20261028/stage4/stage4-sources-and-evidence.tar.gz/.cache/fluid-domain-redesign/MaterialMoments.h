#pragma once
#include "IncomingWetState.h"
namespace fluid_material {
using V=glm::dvec3;using M=glm::dmat3;
// Integrate the actual affine donor field over a prepared disjoint material
// fragment. This is restriction/projection, NOT a flow or geometry advection
// algorithm. The caller owns validated, nonoverlapping material geometry.
struct Field {V origin{0},value{0};M gradient{0};};
inline fluid_incoming::Moments Integrate(const LiquidGeometry& fragment,const Field& field,double density){
 if(!(density>0)||!std::isfinite(density))throw std::invalid_argument("invalid material density");
 fluid_incoming::Moments result;
 for(const auto& t:fragment.cells){const double volume=fluid_moment::TetVolume(t);if(!(volume>0)||!std::isfinite(volume))throw std::invalid_argument("invalid material fragment");const V center=(t[0]+t[1]+t[2]+t[3])*.25;M covariance(0);V sum(0);for(auto x:t){const V r=x-center;sum+=r;covariance+=glm::outerProduct(r,r);}covariance=(covariance+glm::outerProduct(sum,sum))/20.;const V velocity=field.value+field.gradient*(center-field.origin);const double mass=density*volume;const M velocityCovariance=field.gradient*covariance*glm::transpose(field.gradient);const M mixed=mass*(glm::outerProduct(center,velocity)+covariance*glm::transpose(field.gradient));
  fluid_incoming::Moments part;part.volume=volume;part.spatial=volume*center;part.momentum=mass*velocity;part.mixed=mixed;part.angular={mixed[2][1]-mixed[1][2],mixed[0][2]-mixed[2][0],mixed[1][0]-mixed[0][1]};part.energy=.5*mass*(glm::dot(velocity,velocity)+velocityCovariance[0][0]+velocityCovariance[1][1]+velocityCovariance[2][2]);result.Add(part);
 }
 if(!std::isfinite(result.energy)||!std::isfinite(glm::dot(result.momentum,result.momentum)))throw std::invalid_argument("nonfinite material field");
 return result;
}
struct Piece {LiquidGeometry geometry;Field field;};
struct Projection {bool accepted=false;fluid_incoming::Initialized state;fluid_incoming::Moments source;double energyChange=0;std::string error;};
// A full affine L2 projection on the unchanged union of these fragments. It
// preserves integrated P and L and cannot increase energy. Projection loss is
// measured, never repaired/clamped. Disconnected components must be submitted
// separately; this helper does NOT infer topology or merge separate water.
inline Projection Project(const std::vector<Piece>& pieces,double density){
 Projection result;LiquidGeometry unionGeometry;
 try{for(const auto& piece:pieces){result.source.Add(Integrate(piece.geometry,piece.field,density));unionGeometry.cells.insert(unionGeometry.cells.end(),piece.geometry.cells.begin(),piece.geometry.cells.end());}result.state=fluid_incoming::Fit(result.source,unionGeometry,density);result.energyChange=result.state.energy-result.source.energy;
  const double momentumScale=std::max(1.,glm::length(result.source.momentum)),angularScale=std::max(1.,glm::length(result.source.angular)),energyScale=std::max(1.,result.source.energy);
  if(glm::length(result.state.mass*result.state.mean-result.source.momentum)>1e-12*momentumScale||glm::length(result.state.angular-result.source.angular)>1e-12*angularScale||result.energyChange>1e-12*energyScale){result.error="material projection fails conservation/energy verification";return result;}result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
}
