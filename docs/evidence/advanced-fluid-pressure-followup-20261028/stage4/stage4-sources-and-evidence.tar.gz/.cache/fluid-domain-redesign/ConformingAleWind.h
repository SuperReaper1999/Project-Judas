#pragma once
#include "AleTransport.h"
#include <queue>
namespace fluid_conforming_wind {
using V=glm::dvec3;using M=glm::dmat3;
struct Result {bool accepted=false;std::string error;std::vector<fluid_ale::Field> fields;double residual=0;std::vector<std::array<double,4>> relativeFlux;};
// Bounded reference: one shared integrated relative flux per interior face.
// RT0 Piola fields enforce matching normal traces by construction. Cell
// continuity is eliminated on a maximum-area spanning tree; cycle velocities
// minimize the physical L2 distance to the supplied advector predictor.
// This constructs a kinematic transport wind, NOT the carried physical state.
inline Result Project(const fluid_ale::Mesh& mesh,const std::vector<fluid_ale::Field>& predicted,double time,double dt){
 Result result;try{
  const unsigned n=mesh.cells.size();if(!n||n>128||predicted.size()!=n||!(dt>0))throw std::invalid_argument("invalid conforming wind input");
  struct Face {std::array<unsigned,3> vertices;unsigned a=0,b=unsigned(-1),oppositeA=0,oppositeB=0;double area=0;};
  std::vector<LiquidTet> tets(n);std::vector<double> volume(n),rate(n);std::vector<fluid_ale::Field> grid(n);
  std::map<std::array<unsigned,3>,unsigned> inventory;std::vector<Face> faces;
  for(unsigned c=0;c<n;++c){std::array<V,4> speed;for(unsigned k=0;k<4;++k){tets[c][k]=mesh.Position(mesh.cells[c][k],time);speed[k]=mesh.Derivative(mesh.cells[c][k],time)/dt;}
   auto measure=fluid_ale::Measure(tets[c]);volume[c]=measure.volume;if(!(volume[c]>0))throw std::runtime_error("zero conforming wind cell");
   M gradient=M(speed[1]-speed[0],speed[2]-speed[0],speed[3]-speed[0])*glm::inverse(M(tets[c][1]-tets[c][0],tets[c][2]-tets[c][0],tets[c][3]-tets[c][0]));grid[c]={tets[c][0],speed[0],gradient};rate[c]=-volume[c]*(gradient[0][0]+gradient[1][1]+gradient[2][2]);
   for(unsigned opposite=0;opposite<4;++opposite){std::array<unsigned,3> ids;unsigned at=0;for(unsigned k=0;k<4;++k)if(k!=opposite)ids[at++]=mesh.cells[c][k];auto key=ids;std::sort(key.begin(),key.end());auto it=inventory.find(key);if(it==inventory.end()){V a=mesh.Position(ids[0],time),b=mesh.Position(ids[1],time),d=mesh.Position(ids[2],time);inventory[key]=faces.size();faces.push_back({ids,c,unsigned(-1),opposite,0,.5*glm::length(glm::cross(b-a,d-a))});}else{auto& f=faces[it->second];if(f.b!=unsigned(-1))throw std::runtime_error("nonmanifold conforming wind");f.b=c;f.oppositeB=opposite;}}
  }
  std::vector<std::vector<unsigned>> adjacency(n);for(unsigned f=0;f<faces.size();++f)if(faces[f].b!=unsigned(-1)){adjacency[faces[f].a].push_back(f);adjacency[faces[f].b].push_back(f);}
  std::vector<bool> seen(n),tree(faces.size());std::vector<unsigned> parent(n,unsigned(-1)),parentFace(n,unsigned(-1)),order,roots;
  using Edge=std::pair<double,unsigned>;std::priority_queue<Edge> queue;
  for(unsigned root=0;root<n;++root)if(!seen[root]){roots.push_back(root);seen[root]=true;order.push_back(root);for(unsigned f:adjacency[root])queue.push({faces[f].area,f});while(!queue.empty()){unsigned f=queue.top().second;queue.pop();auto& face=faces[f];if(seen[face.a]&&seen[face.b])continue;unsigned a=seen[face.a]?face.a:face.b,b=seen[face.a]?face.b:face.a;seen[b]=true;tree[f]=true;parent[b]=a;parentFace[b]=f;order.push_back(b);for(unsigned g:adjacency[b])queue.push({faces[g].area,g});}}
  auto eliminate=[&](std::vector<double> q,std::vector<double> rhs){for(unsigned f=0;f<faces.size();++f)if(!tree[f]&&faces[f].b!=unsigned(-1)){rhs[faces[f].a]-=q[f];rhs[faces[f].b]+=q[f];}for(unsigned k=order.size();k-->0;){unsigned c=order[k];if(parent[c]==unsigned(-1))continue;unsigned f=parentFace[c];q[f]=faces[f].a==c?rhs[c]:-rhs[c];rhs[parent[c]]+=rhs[c];}for(unsigned root:roots){double magnitude=0;for(double v:rate)magnitude+=std::abs(v);if(std::abs(rhs[root])>1e-12*std::max(1.,magnitude))throw std::runtime_error("closed material component has incompatible geometric rate");}return q;};
  const auto base=eliminate(std::vector<double>(faces.size()),rate);std::vector<unsigned> free;for(unsigned f=0;f<faces.size();++f)if(!tree[f]&&faces[f].b!=unsigned(-1))free.push_back(f);
  std::vector<std::vector<double>> cycles;for(unsigned f:free){std::vector<double> q(faces.size());q[f]=1;cycles.push_back(eliminate(q,std::vector<double>(n)));}
  auto reconstruct=[&](const std::vector<double>& q,bool includeGrid){std::vector<fluid_ale::Field> fields(n);if(includeGrid)fields=grid;else for(unsigned c=0;c<n;++c)fields[c].origin=grid[c].origin;for(unsigned f=0;f<faces.size();++f)if(faces[f].b!=unsigned(-1)){for(unsigned side=0;side<2;++side){unsigned c=side?faces[f].b:faces[f].a;double scale=(side?-q[f]:q[f])/(3*volume[c]);V opposite=tets[c][side?faces[f].oppositeB:faces[f].oppositeA];fields[c].value+=scale*(fields[c].origin-opposite);fields[c].gradient+=M(scale);}}return fields;};
  auto initial=reconstruct(base,true);std::vector<std::vector<fluid_ale::Field>> modes;for(const auto& q:cycles)modes.push_back(reconstruct(q,false));unsigned m=modes.size();std::vector<double> gram(m*m),rhs(m);
  for(unsigned c=0;c<n;++c)for(V x:fluid_ale::Quadrature(tets[c])){double weight=volume[c]*.25;V target=fluid_ale::Evaluate(predicted[c],x)-fluid_ale::Evaluate(initial[c],x);std::vector<V> u(m);for(unsigned i=0;i<m;++i)u[i]=fluid_ale::Evaluate(modes[i][c],x);for(unsigned i=0;i<m;++i){rhs[i]+=weight*glm::dot(u[i],target);for(unsigned j=0;j<m;++j)gram[i*m+j]+=weight*glm::dot(u[i],u[j]);}}
  std::vector<double> scales(m);for(unsigned i=0;i<m;++i){if(!(gram[i*m+i]>0))throw std::runtime_error("singular conforming cycle");scales[i]=1/std::sqrt(gram[i*m+i]);}for(unsigned i=0;i<m;++i){rhs[i]*=scales[i];for(unsigned j=0;j<m;++j)gram[i*m+j]*=scales[i]*scales[j];}
  for(unsigned i=0;i<m;++i)for(unsigned j=0;j<=i;++j){double v=gram[i*m+j];for(unsigned k=0;k<j;++k)v-=gram[i*m+k]*gram[j*m+k];if(i==j){if(!(v>0))throw std::runtime_error("nonpositive conforming cycle metric");gram[i*m+j]=std::sqrt(v);}else gram[i*m+j]=v/gram[j*m+j];}
  for(unsigned i=0;i<m;++i){for(unsigned j=0;j<i;++j)rhs[i]-=gram[i*m+j]*rhs[j];rhs[i]/=gram[i*m+i];}for(unsigned i=m;i-->0;){for(unsigned j=i+1;j<m;++j)rhs[i]-=gram[j*m+i]*rhs[j];rhs[i]/=gram[i*m+i];}
  std::vector<double> q(faces.size());for(unsigned i=0;i<m;++i)q[free[i]]=rhs[i]*scales[i];q=eliminate(q,rate);result.fields=reconstruct(q,true);result.relativeFlux.resize(n);for(unsigned f=0;f<faces.size();++f)if(faces[f].b!=unsigned(-1)){result.relativeFlux[faces[f].a][faces[f].oppositeA]=q[f];result.relativeFlux[faces[f].b][faces[f].oppositeB]=-q[f];}
  for(unsigned c=0;c<n;++c){double r=-rate[c];for(unsigned f:adjacency[c])r+=faces[f].a==c?q[f]:-q[f];result.residual=std::max(result.residual,std::abs(r));}if(result.residual>1e-12)throw std::runtime_error("conforming continuity failed");result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;
}
}
