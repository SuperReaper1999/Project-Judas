#pragma once
#include "MixedProjection.h"
#include <map>
#include <set>
#include <numeric>
#include <chrono>
#include <memory>
// Disposable sparse Cholesky reference. No diagonal regularization or added
// physical compliance; every pivot must be positive in the barrier system.
struct SparseFactor {
 unsigned n;std::vector<unsigned> order,inverse;std::vector<std::vector<unsigned>> columns;
 std::vector<std::vector<double>> source;std::vector<std::vector<unsigned>> targets,pattern;
 SparseFactor(const std::vector<std::map<unsigned,double>>& a):n(a.size()),order(n),inverse(n),columns(n),source(n),targets(n),pattern(n){
  for(unsigned i=0;i<n;++i)for(auto [j,v]:a[i])if(v!=0)pattern[i].push_back(j);
  std::vector<std::set<unsigned>> graph(n);for(unsigned i=0;i<n;++i)for(auto [j,v]:a[i])if(i!=j&&v!=0){graph[i].insert(j);graph[j].insert(i);}
  std::set<std::pair<unsigned,unsigned>> queue;std::vector<bool> active(n,true);for(unsigned i=0;i<n;++i)queue.emplace(graph[i].size(),i);
  std::vector<std::vector<unsigned>> neighbors(n);
  for(unsigned k=0;k<n;++k){auto [degree,i]=*queue.begin();queue.erase(queue.begin());order[k]=i;inverse[i]=k;active[i]=false;neighbors[k].assign(graph[i].begin(),graph[i].end());
   for(auto j:neighbors[k]){queue.erase({unsigned(graph[j].size()),j});graph[j].erase(i);}
   for(auto j:neighbors[k])for(auto l:neighbors[k])if(j!=l)graph[j].insert(l);
   for(auto j:neighbors[k])queue.emplace(graph[j].size(),j);
  }
  for(unsigned k=0;k<n;++k){columns[k].push_back(k);for(auto j:neighbors[k])columns[k].push_back(inverse[j]);std::sort(columns[k].begin()+1,columns[k].end());source[k].resize(columns[k].size());for(unsigned t=0;t<columns[k].size();++t){const auto i=order[k],j=order[columns[k][t]];auto f=a[std::min(i,j)].find(std::max(i,j));source[k][t]=f==a[std::min(i,j)].end()?0:f->second;}}
  for(unsigned k=0;k<n;++k)for(unsigned t=1;t<columns[k].size();++t){unsigned j=columns[k][t];auto begin=columns[j].begin();for(unsigned u=t;u<columns[k].size();++u){auto at=std::lower_bound(begin,columns[j].end(),columns[k][u]);if(at==columns[j].end()||*at!=columns[k][u])throw std::runtime_error("missing symbolic factor fill");targets[k].push_back(unsigned(at-columns[j].begin()));begin=at;}}
 }
 bool Matches(const std::vector<std::map<unsigned,double>>& a)const{if(a.size()!=n)return false;for(unsigned i=0;i<n;++i){unsigned k=0;for(auto [j,v]:a[i])if(v!=0){if(k>=pattern[i].size()||pattern[i][k++]!=j)return false;}if(k!=pattern[i].size())return false;}return true;}
 void Update(const std::vector<std::map<unsigned,double>>& a){if(!Matches(a))throw std::runtime_error("changed pressure topology needs symbolic rebuild");for(unsigned k=0;k<n;++k)for(unsigned t=0;t<columns[k].size();++t){const auto i=order[k],j=order[columns[k][t]];auto at=a[std::min(i,j)].find(std::max(i,j));source[k][t]=at==a[std::min(i,j)].end()?0:at->second;}}
 std::vector<std::vector<double>> Factor(const std::vector<double>& diagonal)const{
  auto values=source;for(unsigned k=0;k<n;++k)values[k][0]+=diagonal[order[k]];
  for(unsigned k=0;k<n;++k){auto& col=values[k];const double pivot=col[0];if(!(pivot>0)||!std::isfinite(pivot))throw std::runtime_error("nonpositive sparse physical pivot");col[0]=std::sqrt(pivot);for(unsigned t=1;t<col.size();++t)col[t]/=col[0];
   unsigned target=0;for(unsigned t=1;t<col.size();++t){const unsigned j=columns[k][t];for(unsigned u=t;u<col.size();++u)values[j][targets[k][target++]]-=col[t]*col[u];}
  }
  return values;
 }
 std::vector<double> Solve(const std::vector<double>& rhs,const std::vector<std::vector<double>>& values)const{
  std::vector<double> x(n);for(unsigned k=0;k<n;++k)x[k]=rhs[order[k]];
  for(unsigned k=0;k<n;++k){x[k]/=values[k][0];for(unsigned t=1;t<values[k].size();++t)x[columns[k][t]]-=values[k][t]*x[k];}
  for(unsigned k=n;k-->0;){for(unsigned t=1;t<values[k].size();++t)x[k]-=values[k][t]*x[columns[k][t]];x[k]/=values[k][0];}
  std::vector<double> result(n);for(unsigned k=0;k<n;++k)result[order[k]]=x[k];return result;
 }
};
struct SparseWorkspace{std::unique_ptr<SparseFactor> factor;unsigned rebuilds=0,warmHits=0;std::vector<double> pressureImpulse;};
inline pressure_prototype::Result SparseInterior(std::vector<pressure_prototype::Point>& points,std::vector<pressure_prototype::Body>& bodies,const std::vector<pressure_prototype::Row>& rows,const std::vector<bool>& bilateral,unsigned budget,double tolerance,SparseWorkspace* cached=nullptr){
 using namespace pressure_prototype;Result result;const unsigned n=rows.size();result.pressureImpulse.assign(n,0);
 std::vector<std::map<unsigned,double>> matrix(n);std::vector<std::vector<std::pair<unsigned,glm::dvec3>>> incident(points.size());
 for(unsigned i=0;i<n;++i)for(auto g:rows[i].points)incident[g.point].push_back({i,g.gradient});
 for(unsigned p=0;p<incident.size();++p)for(auto [i,a]:incident[p])for(auto [j,b]:incident[p])if(i<=j)matrix[i][j]+=points[p].inverseMass*glm::dot(a,b);
 // Keep each finite body's six physical degrees of freedom low rank.
 // Forming their Gram entries as a pressure-row clique needlessly densifies
 // the otherwise local fluid operator; Woodbury below is algebraically exact.
 std::vector<std::vector<double>> bodyColumns;
 for(unsigned b=0;b<bodies.size();++b){glm::dmat3 lower(0);const auto& inertia=bodies[b].inverseInertia;for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double a=inertia[j][i];for(unsigned k=0;k<j;++k)a-=lower[k][i]*lower[k][j];if(i==j){if(a<0)throw std::runtime_error("negative body inverse inertia");lower[j][i]=std::sqrt(a);}else if(lower[j][j]>0)lower[j][i]=a/lower[j][j];else if(a!=0)throw std::runtime_error("singular inconsistent inertia");}
  for(unsigned axis=0;axis<6;++axis){std::vector<double> column(n,0);bool nonzero=false;for(unsigned i=0;i<n;++i)for(auto g:rows[i].bodies)if(g.body==b){double v=axis<3?std::sqrt(bodies[b].inverseMass)*g.linear[axis]:glm::dot(lower[axis-3],g.angular);column[i]+=v;nonzero|=v!=0;}if(nonzero)bodyColumns.push_back(std::move(column));}
 }
 std::vector<double> scale(n),rhs(n),lambda(n,0),z(n,0);unsigned contacts=0;
 for(unsigned i=0;i<n;++i){double d=matrix[i][i];for(const auto& column:bodyColumns)d+=column[i]*column[i];if(!(d>0))throw std::runtime_error("empty pressure constraint");scale[i]=1/std::sqrt(d);double v=-rows[i].maximumRate;for(auto g:rows[i].points)v+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)v+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);rhs[i]=v*scale[i];if(!bilateral[i]){lambda[i]=z[i]=1;++contacts;}}
 double initialResidual=0;for(unsigned i=0;i<n;++i){const double v=rhs[i]/scale[i];initialResidual=std::max(initialResidual,bilateral[i]?std::abs(v):std::max(0.,v));}if(initialResidual<=tolerance){result.converged=true;result.maximumResidual=initialResidual;return result;}
 for(unsigned i=0;i<n;++i)for(auto& [j,v]:matrix[i])v*=scale[i]*scale[j];
 for(auto& column:bodyColumns)for(unsigned i=0;i<n;++i)column[i]*=scale[i];
 SparseWorkspace local;auto& workspace=cached?*cached:local;
 auto multiply=[&](const std::vector<double>& x){std::vector<double> output(n,0);for(unsigned i=0;i<n;++i)for(auto [j,v]:matrix[i]){output[i]+=v*x[j];if(i!=j)output[j]+=v*x[i];}for(const auto& column:bodyColumns){double dot=0;for(unsigned i=0;i<n;++i)dot+=column[i]*x[i];for(unsigned i=0;i<n;++i)output[i]+=column[i]*dot;}++result.matrixProducts;return output;};
 bool warmAccepted=false;
 if(workspace.pressureImpulse.size()==n){std::vector<double> candidate(n);bool feasible=true;for(unsigned i=0;i<n;++i){candidate[i]=workspace.pressureImpulse[i]/scale[i];feasible&=std::isfinite(candidate[i])&&(bilateral[i]||candidate[i]>=0);}if(feasible){auto product=multiply(candidate);double error=0;for(unsigned i=0;i<n;++i){double e=rhs[i]-product[i];double v=bilateral[i]?std::abs(e/scale[i]):std::max(0.,e/scale[i]);if(!bilateral[i])v=std::max(v,std::abs(candidate[i]*e));error=std::max(error,v);}if(error<=tolerance){lambda=std::move(candidate);warmAccepted=true;++workspace.warmHits;}}}
 auto setupStart=std::chrono::steady_clock::now();bool rebuilt=!warmAccepted&&(!workspace.factor||!workspace.factor->Matches(matrix));if(rebuilt){workspace.factor=std::make_unique<SparseFactor>(matrix);++workspace.rebuilds;}else if(!warmAccepted)workspace.factor->Update(matrix);double factorMs=0;double setupMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-setupStart).count();
 std::vector<std::vector<double>> numericalFactor,inverseColumns;std::vector<double> bodyFactor;
 auto direction=[&](const std::vector<double>& residual,const std::vector<double>& comp,std::vector<double>& dl,std::vector<double>& dz){std::vector<double> diagonal(n,0),r(n);for(unsigned i=0;i<n;++i){r[i]=-residual[i];if(!bilateral[i]){diagonal[i]=z[i]/lambda[i];r[i]-=comp[i]/lambda[i];}}auto solveStart=std::chrono::steady_clock::now();if(numericalFactor.empty()){numericalFactor=workspace.factor->Factor(diagonal);inverseColumns.clear();const unsigned rank=bodyColumns.size();bodyFactor.assign(rank*rank,0);for(const auto& column:bodyColumns)inverseColumns.push_back(workspace.factor->Solve(column,numericalFactor));for(unsigned j=0;j<rank;++j)for(unsigned i=j;i<rank;++i){double v=i==j?1:0;for(unsigned k=0;k<n;++k)v+=bodyColumns[i][k]*inverseColumns[j][k];for(unsigned k=0;k<j;++k)v-=bodyFactor[k*rank+i]*bodyFactor[k*rank+j];if(i==j){if(!(v>0))throw std::runtime_error("nonpositive body Schur pivot");bodyFactor[j*rank+i]=std::sqrt(v);}else bodyFactor[j*rank+i]=v/bodyFactor[j*rank+j];}}
 dl=workspace.factor->Solve(r,numericalFactor);const unsigned rank=bodyColumns.size();std::vector<double> correction(rank,0);for(unsigned j=0;j<rank;++j){for(unsigned k=0;k<n;++k)correction[j]+=bodyColumns[j][k]*dl[k];for(unsigned k=0;k<j;++k)correction[j]-=bodyFactor[k*rank+j]*correction[k];correction[j]/=bodyFactor[j*rank+j];}for(unsigned j=rank;j-->0;){for(unsigned k=j+1;k<rank;++k)correction[j]-=bodyFactor[j*rank+k]*correction[k];correction[j]/=bodyFactor[j*rank+j];}for(unsigned j=0;j<rank;++j)for(unsigned k=0;k<n;++k)dl[k]-=inverseColumns[j][k]*correction[j];factorMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-solveStart).count();dz=multiply(dl);for(unsigned i=0;i<n;++i)dz[i]+=residual[i];};
 auto step=[&](const std::vector<double>& x,const std::vector<double>& dx){double alpha=1;for(unsigned i=0;i<n;++i)if(!bilateral[i]&&dx[i]<0)alpha=std::min(alpha,-x[i]/dx[i]);return alpha;};
 bool solved=warmAccepted;
 for(unsigned iteration=0;iteration<budget&&!warmAccepted;++iteration){numericalFactor.clear();auto product=multiply(lambda);std::vector<double> residual(n),comp(n,0),dl,dz;double mu=0,physical=0;
  for(unsigned i=0;i<n;++i){const double e=rhs[i]-product[i];double v=bilateral[i]?std::abs(e/scale[i]):std::max(0.,e/scale[i]);if(!bilateral[i])v=std::max(v,std::abs(lambda[i]*e));physical=std::max(physical,v);residual[i]=product[i]-rhs[i]-z[i];if(!bilateral[i]){comp[i]=lambda[i]*z[i];mu+=comp[i];}}if(physical<=tolerance){solved=true;break;}mu/=contacts;
  direction(residual,comp,dl,dz);double ap=step(lambda,dl),ad=step(z,dz),affine=0;for(unsigned i=0;i<n;++i)if(!bilateral[i])affine+=(lambda[i]+ap*dl[i])*(z[i]+ad*dz[i]);affine/=contacts;const double sigma=std::pow(affine/mu,3);
  for(unsigned i=0;i<n;++i)if(!bilateral[i])comp[i]+=dl[i]*dz[i]-sigma*mu;
  direction(residual,comp,dl,dz);ap=std::min(1.,.995*step(lambda,dl));ad=std::min(1.,.995*step(z,dz));for(unsigned i=0;i<n;++i){lambda[i]+=ap*dl[i];if(!bilateral[i])z[i]+=ad*dz[i];}++result.sweeps;
 }
 std::printf("SPARSE_TIMING symbolic_ms=%.6f factors_ms=%.6f rebuilt=%d\n",setupMs,factorMs,rebuilt);
 // Failure is transactional: original velocities remain untouched.
 if(!solved){result.maximumResidual=INFINITY;return result;}
 auto originalPoints=points;auto originalBodies=bodies;
 for(unsigned i=0;i<n;++i){const double p=lambda[i]*scale[i];result.pressureImpulse[i]=p;for(auto g:rows[i].points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*p;for(auto g:rows[i].bodies){auto& body=bodies[g.body];body.velocity-=body.inverseMass*g.linear*p;body.angularVelocity-=body.inverseInertia*g.angular*p;}}
 for(unsigned i=0;i<n;++i){double e=-rows[i].maximumRate;for(auto g:rows[i].points)e+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)e+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);double v=bilateral[i]?std::abs(e):std::max(0.,e);if(!bilateral[i])v=std::max(v,std::abs(result.pressureImpulse[i]*e));result.maximumResidual=std::max(result.maximumResidual,v);}
 result.converged=result.maximumResidual<=tolerance;if(!result.converged){points=originalPoints;bodies=originalBodies;}else workspace.pressureImpulse=result.pressureImpulse;return result;
}
