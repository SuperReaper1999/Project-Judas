#include "VolumeDomain.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <limits>

using namespace fluid_domain;

int main() {
    unsigned checks = 0, failures = 0;
    auto check = [&](bool ok, const char* description) {
        ++checks;
        if (!ok) { ++failures; std::printf("FAIL %s\n", description); }
    };
    std::string error;
    const auto cube = LiquidBox({0,0,0},{1,1,1});
    const auto begin = std::chrono::steady_clock::now();

    // Real geometry, not just scalar-accounting checks.
    for (auto normal : {glm::dvec3(0,1,0),glm::dvec3(1,2,3),glm::dvec3(-3,.1,2)}) {
        for (double fraction : {.001,.07,.25,.5,.9,.999}) {
            VolumeDomain domain(1);
            check(domain.Add({0,0,0},cube,fraction,normal,error), "oblique wet reconstruction");
            const auto* cell = domain.Find({0,0,0});
            if (cell) {
                check(cell->volume == fraction, "reconstruction never adjusts quantity");
                check(std::abs(cell->reconstructionError)<1e-12,"physical wet geometry matches quantity");
                check(std::abs(glm::length(cell->interfaceNormal)-1)<1e-14,"normal normalized");
            } else std::printf("RECONSTRUCTION_ERROR %s\n",error.c_str());
        }
    }

    VolumeDomain flowing(1);
    check(flowing.Add({0,0,0},cube,.75,{0,1,0},error),"wet donor created");
    check(flowing.Add({1,0,0},cube,0,{0,1,0},error),"dry receiver created");
    check(flowing.Add({2,0,0},cube,0,{0,1,0},error),"second dry cell created");
    check(std::abs(flowing.SharedWetAperture({0,0,0},{1,0,0},error)-.75)<1e-12,"actual wet aperture area");
    check(flowing.Advance({{{0,0,0},{1,0,0},.25}},{},error),"dry cell re-wets through real aperture");
    check(flowing.Find({0,0,0})->volume == .5 && flowing.Find({1,0,0})->volume == .25,"paired volume transfer");
    check(flowing.TotalVolume()==.75,"re-wetting conserves total quantity");
    check(flowing.Advance({{{1,0,0},{2,0,0},.125}},{},error),"new wet topology permits subsequent transfer");
    check(flowing.TotalVolume()==.75,"multi-step transport conserved");

    VolumeDomain noTeleport(1);
    check(noTeleport.Add({0,0,0},cube,.5,{0,1,0},error),"teleport test donor");
    check(noTeleport.Add({1,0,0},cube,0,{0,1,0},error),"teleport test dry middle");
    check(noTeleport.Add({2,0,0},cube,0,{0,1,0},error),"teleport test dry end");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.25},{{1,0,0},{2,0,0},.25}},{},error),"cannot cross dry middle in one transaction");
    check(noTeleport.Find({0,0,0})->volume==.5&&noTeleport.Find({1,0,0})->volume==0&&noTeleport.Find({2,0,0})->volume==0,"failed topology transaction fully rolls back");
    check(!noTeleport.Advance({{{0,0,0},{2,0,0},.125}},{},error),"nonadjacent transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.75}},{},error),"negative donor volume rejected before publication");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},-.1}},{},error),"negative transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},std::numeric_limits<double>::infinity()}},{},error),"infinite transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.1},{{0,0,0},{1,0,0},.1}},{},error),"duplicate face flux rejected");

    VolumeDomain mismatch(1);
    check(mismatch.Add({0,0,0},LiquidBox({0,.5,0},{1,1,1}),.5,{0,1,0},error),"upper-half aperture donor");
    check(mismatch.Add({1,0,0},LiquidBox({0,0,0},{1,.5,1}),0,{0,1,0},error),"lower-half aperture receiver");
    check(mismatch.SharedWetAperture({0,0,0},{1,0,0},error)==0,"nonoverlapping positive-area apertures remain disconnected");
    check(!mismatch.Advance({{{0,0,0},{1,0,0},.1}},{},error),"no transfer through mismatched openings");

    VolumeDomain shutter(1);
    check(shutter.Add({0,0,0},LiquidBox({0,0,0},{.5,1,1}),.25,{0,1,0},error),"closed solid boundary donor");
    check(shutter.Add({1,0,0},cube,0,{0,1,0},error),"closed solid boundary receiver");
    check(!shutter.Advance({{{0,0,0},{1,0,0},.1}},{},error),"solid wall blocks transfer");
    check(shutter.Advance({},{{{0,0,0},std::make_shared<const LiquidGeometry>(cube)}},error),"authored aperture can open without changing quantity");
    check(shutter.TotalVolume()==.25,"opening does not create quantity");
    check(shutter.Advance({{{0,0,0},{1,0,0},.125}},{},error),"actual reconnection permits flow");

    VolumeDomain moving(1);
    check(moving.Add({0,0,0},cube,.75,{0,1,0},error),"moving-solid test cell");
    auto half = std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{.5,1,1}));
    const auto oldGeometry = moving.Find({0,0,0})->capacityGeometry;
    check(!moving.Advance({},{{{0,0,0},half}},error),"capacity loss without physical outflow rejected");
    check(moving.Find({0,0,0})->volume==.75&&moving.Find({0,0,0})->capacityGeometry==oldGeometry,"failed moving-solid update preserves geometry and quantity");
    check(moving.Add({1,0,0},cube,0,{0,1,0},error),"moving-solid outflow receiver");
    check(moving.Advance({{{0,0,0},{1,0,0},.25}},{{{0,0,0},half}},error),"capacity loss plus legitimate outflow commits together");
    check(moving.TotalVolume()==.75&&moving.Find({0,0,0})->volume==.5,"moving-solid transaction conserved");

    LiquidGeometry isolated=LiquidBox({0,0,0},{.4,1,1});
    auto other=LiquidBox({.6,0,0},{1,1,1});isolated.cells.insert(isolated.cells.end(),other.cells.begin(),other.cells.end());
    VolumeDomain topology(1);
    check(!topology.Add({0,0,0},isolated,.4,{0,1,0},error),"independent pockets cannot share one scalar fill");
    check(topology.Size()==0,"unsupported pocket topology not published");
    auto overlap=LiquidBox({0,0,0},{.6,1,1});other=LiquidBox({.4,0,0},{.8,1,1});overlap.cells.insert(overlap.cells.end(),other.cells.begin(),other.cells.end());
    check(!topology.Add({0,0,0},overlap,.5,{0,1,0},error),"overlapping capacity tets rejected even when summed volume is below cube volume");
    check(!topology.Add({0,0,0},cube,1.01,{0,1,0},error),"initial overfill rejected");
    check(!topology.Add({0,0,0},cube,-.01,{0,1,0},error),"initial negative quantity rejected");
    check(!topology.Add({0,0,0},cube,.1,{0,0,0},error),"zero interface normal rejected");

    // Repeated re-wetting and drainage use the same physical aperture and state,
    // with no repair/clamp/equilibrium-reset operation in between.
    VolumeDomain cycles(1);
    check(cycles.Add({0,0,0},cube,.75,{0,1,0},error),"repeat donor");
    check(cycles.Add({1,0,0},cube,.25,{0,1,0},error),"repeat receiver");
    for (unsigned i=0;i<100;++i) {
        check(cycles.Advance({{{0,0,0},{1,0,0},.125}},{},error),"repeat forward transfer");
        check(cycles.Advance({{{1,0,0},{0,0,0},.125}},{},error),"repeat reverse transfer");
        check(cycles.TotalVolume()==1,"repeated transactions conserve exact dyadic total");
    }
    const auto* c=cycles.Find({0,0,0});
    check(c->volume==.75&&cycles.Find({1,0,0})->volume==.25,"cycles restore original quantities without resets");
    check(c->interfaceNormal==glm::dvec3(0,1,0),"transport retains authored local interface orientation");
    const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
    std::printf("SUMMARY checks=%u failures=%u milliseconds=%.6f\n",checks,failures,ms);
    std::printf("Scope: geometric quantity/flux transactions only; pressure velocities, moving-body force, advection flux construction and runtime integration are NOT proved by this test.\n");
    return failures?1:0;
}
