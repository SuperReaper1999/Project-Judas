#pragma once
#include "MomentInterface.h"
namespace fluid_incoming {
using V=glm::dvec3;using M=glm::dmat3;
struct Moments{double volume=0,energy=0;V spatial{0},momentum{0},angular{0};M mixed{0};void Add(const Moments& other){volume+=other.volume;energy+=other.energy;spatial+=other.spatial;momentum+=other.momentum;angular+=other.angular;mixed+=other.mixed;}};
inline Moments Integrate(const std::array<V,3>& triangle,const std::array<V,3>& velocity,V normal,double dt,double density){
 if(!std::isfinite(dt)||dt<=0||!std::isfinite(density)||density<=0||std::abs(glm::dot(normal,normal)-1)>1e-12)throw std::invalid_argument("invalid incoming material interval/density/normal");
 struct Vertex{V point,velocity;double flow;};std::vector<Vertex> polygon;std::array<double,3> flow;for(unsigned i=0;i<3;++i){flow[i]=glm::dot(velocity[i],normal);if(!std::isfinite(flow[i]))throw std::invalid_argument("nonfinite material inflow");}
 for(unsigned i=0;i<3;++i){const unsigned j=(i+1)%3;if(flow[i]>=0)polygon.push_back({triangle[i],velocity[i],flow[i]});if((flow[i]>0&&flow[j]<0)||(flow[i]<0&&flow[j]>0)){const double fraction=flow[i]/(flow[i]-flow[j]);V x,u;for(unsigned a=0;a<3;++a){x[a]=std::fma(fraction,triangle[j][a]-triangle[i][a],triangle[i][a]);u[a]=std::fma(fraction,velocity[j][a]-velocity[i][a],velocity[i][a]);}polygon.push_back({x,u,0});}}
 Moments result;const double root35=std::sqrt(.6),root3=std::sqrt(1./3);const double nodes[3]={.5*(1-root35),.5,.5*(1+root35)},weights[3]={5./18,4./9,5./18},tNodes[2]={.5*(1-root3),.5*(1+root3)};
 for(unsigned triangleIndex=1;triangleIndex+1<polygon.size();++triangleIndex){const auto& a=polygon[0];const auto& b=polygon[triangleIndex];const auto& c=polygon[triangleIndex+1];const double twiceArea=glm::length(glm::cross(b.point-a.point,c.point-a.point));for(unsigned i=0;i<3;++i)for(unsigned j=0;j<2;++j){const double s=nodes[i],t=tNodes[j];const double wa=(1-s)*(1-t),wb=s,wc=(1-s)*t;const V x=wa*a.point+wb*b.point+wc*c.point,u=wa*a.velocity+wb*b.velocity+wc*c.velocity;const double f=wa*a.flow+wb*b.flow+wc*c.flow;const double volume=dt*weights[i]*.5*(1-s)*twiceArea*f;const V endpoint=x+.5*dt*u;result.volume+=volume;result.spatial+=volume*endpoint;result.momentum+=density*volume*u;result.angular+=density*volume*glm::cross(endpoint,u);result.mixed+=density*volume*glm::outerProduct(endpoint,u);result.energy+=.5*density*volume*glm::dot(u,u);}}
 return result;
}
struct Initialized{V mean{0},centroid{0},angular{0};M affine{0};double mass=0,energy=0;};
inline Initialized Fit(const Moments& incoming,const LiquidGeometry& actualGeometry,double density){
 if(!(incoming.volume>0))throw std::invalid_argument("empty incoming material");
 Initialized result;result.mass=density*incoming.volume;result.mean=incoming.momentum/result.mass;result.centroid=fluid_moment::Centroid(actualGeometry);M covariance(0);double geometryVolume=0;
 for(const auto& tetrahedron:actualGeometry.cells){double v=fluid_moment::TetVolume(tetrahedron);V sum(0);M diagonal(0);for(auto x:tetrahedron){V r=x-result.centroid;sum+=r;diagonal+=glm::outerProduct(r,r);}covariance+=v*(glm::outerProduct(sum,sum)+diagonal)/20.;geometryVolume+=v;}covariance/=geometryVolume;
 if(std::abs(geometryVolume-incoming.volume)>1e-12*std::max(1.,incoming.volume))throw std::invalid_argument("incoming geometry does not represent authoritative quantity");
 M lower(0);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double a=covariance[j][i];for(unsigned k=0;k<j;++k)a-=lower[k][i]*lower[k][j];if(i==j){if(!(a>0))throw std::runtime_error("singular incoming geometric inertia");lower[j][i]=std::sqrt(a);}else lower[j][i]=a/lower[j][j];}
 const M relative=incoming.mixed-glm::outerProduct(result.centroid,incoming.momentum);result.affine=glm::transpose(glm::inverse(lower)*relative)/result.mass;const M moment=lower*glm::transpose(result.affine);const V spin(moment[2][1]-moment[1][2],moment[0][2]-moment[2][0],moment[1][0]-moment[0][1]);result.angular=result.mass*(glm::cross(result.centroid,result.mean)+spin);result.energy=.5*result.mass*(glm::dot(result.mean,result.mean)+glm::dot(result.affine[0],result.affine[0])+glm::dot(result.affine[1],result.affine[1])+glm::dot(result.affine[2],result.affine[2]));return result;
}
}
