from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
p.link.append('/usr/lib/x86_64-linux-gnu/liblapack.so.3')
impl=p.compile(out/'VolumeDomain.cpp','volume-domain')
main=p.compile(out/'AffineValidation.cpp','affine-validation');p.executable(main,'affine-validation',impl)
