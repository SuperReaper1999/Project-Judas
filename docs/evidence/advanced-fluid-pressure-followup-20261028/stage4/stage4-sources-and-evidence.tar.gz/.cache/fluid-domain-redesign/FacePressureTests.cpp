#include "FacePressure.h"
#include <cstdio>
#include <cmath>
using namespace fluid_domain;
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* n){++checks;if(!ok){++failures;std::printf("FAIL %s\n",n);}};
 const auto cube=LiquidBox({0,0,0},{1,1,1});
 const auto left=LiquidSubtractSolids(cube,{{{1,0,0,1},{-1,0,0,-.9},{0,1,0,1},{0,-1,0,-.25},{0,0,1,1},{0,0,-1,0}}});
 const auto right=LiquidSubtractSolids(cube,{{{1,0,0,.1},{-1,0,0,0},{0,1,0,1},{0,-1,0,-.25},{0,0,1,1},{0,0,-1,0}}});
 std::string error;
 auto full=VolumeDomain(1);check(full.Add({0,0,0},left,.925,{0,1,0},error),"full donor native geometry");check(full.Add({1,0,0},right,.925,{0,1,0},error),"full receiver native geometry");
 auto stopped=ProjectFaces(full,1./60,{{{0,0,0},{1,0,0},250,1}}, {},{});
 check(stopped.converged,"full-cell pressure converges");if(stopped.converged){check(std::abs(stopped.faces[0].velocity)<1e-9,"full cells resist compression with real inertia");check(stopped.solver.pressureImpulse[0]>=0,"nonnegative pressure impulse");}
 check(full.TotalVolume()==1.85,"projection alone never publishes quantity");
 VolumeDomain refill(1);check(refill.Add({0,0,0},left,.6,{0,1,0},error),"refill donor");check(refill.Add({1,0,0},right,0,{0,1,0},error),"refill dry receiver");
 auto flow=ProjectFaces(refill,1./60,{{{0,0,0},{1,0,0},250,.3}}, {},{});
 check(flow.converged,"dry-to-wet pressure step");if(flow.converged){check(refill.Advance(flow.transfers,{},error),"projected flux is actual conservative transport");check(std::abs(refill.Find({1,0,0})->volume-.00125)<1e-12,"physical aperture times velocity times time");check(std::abs(refill.TotalVolume()-.6)<1e-14,"refill step conserved");}
 auto reverse=ProjectFaces(refill,1./60,{{{0,0,0},{1,0,0},250,-.3}}, {},{});
 check(reverse.converged,"asymmetric aperture selects actual wet donor");
 if(reverse.converged) {check(refill.Advance(reverse.transfers,{},error),"asymmetric reverse flow is conservative");check(std::abs(refill.TotalVolume()-.6)<1e-14,"asymmetric transport conserves quantity");}
 // The exactly empty receiver cannot invent a reverse stream.
 VolumeDomain dry(1);check(dry.Add({0,0,0},left,.6,{0,1,0},error)&&dry.Add({1,0,0},right,0,{0,1,0},error),"dry backflow fixture");
 auto noBackflow=ProjectFaces(dry,1./60,{{{0,0,0},{1,0,0},250,-.3}}, {},{});
 check(noBackflow.converged&&std::abs(noBackflow.faces[0].velocity)<1e-9,"dry donor cannot supply negative material");
 VolumeDomain piston(1);auto geometry=LiquidBox({0,0,0},{1,.75,1});check(piston.Add({0,0,0},geometry,.75,{0,1,0},error)&&piston.Add({1,0,0},cube,.75,{0,1,0},error),"finite-body pressure fixture");
 std::vector<pressure_prototype::Body> bodies{{{0,-1,0},{0,0,0},1./80,glm::dmat3(1)}};
 auto coupled=ProjectFaces(piston,1./60,{{{0,0,0},{1,0,0},750,0}},bodies,{{{0,0,0},0,{0,-1,0},{0,0,0}}});
 check(coupled.converged,"finite body and fluid flux solve together");if(coupled.converged){const double a=.75,m=750,bodyMass=80;const double expected=-bodyMass/(bodyMass+m/(a*a));const double v=coupled.bodies[0].velocity.y,u=coupled.faces[0].velocity;std::printf("COUPLED_PISTON vy=%.12g expected=%.12g flow=%.12g residual=%.12g iterations=%u\n",v,expected,u,coupled.solver.maximumResidual,coupled.solver.sweeps);
 check(std::abs(v-expected)<1e-10,"actual finite added mass response");check(std::abs(a*u+v)<1e-10,"piston motion and physical aperture flux satisfy continuity");check(.5*bodyMass*v*v+.5*m*u*u<=40+1e-12,"pressure response does not create energy");check(piston.TotalVolume()==1.5,"staged body pressure does not alter quantity");}
 // Splitting the same physical face into patches must not duplicate body mass.
 auto patches=ProjectFaces(piston,1./60,{{{0,0,0},{1,0,0},750,0}},bodies,{{{0,0,0},0,{0,-.4,0},{0,0,0}},{{0,0,0},0,{0,-.6,0},{0,0,0}}});
 check(patches.converged&&coupled.converged&&glm::length(patches.bodies[0].velocity-coupled.bodies[0].velocity)<1e-12,"same owner boundary patches aggregate before mass inversion");
 auto duplicate=ProjectFaces(piston,1./60,{{{0,0,0},{1,0,0},750,0},{{0,0,0},{1,0,0},750,0}},bodies,{});
 check(!duplicate.converged,"same physical fluid face cannot duplicate inertia");
 std::printf("SUMMARY checks=%u failures=%u\n",checks,failures);std::printf("Scope: pressure/flux assembly; resolved moving-body publication and full free-surface advection remain unqualified.\n");return failures?1:0;}
