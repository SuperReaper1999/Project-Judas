#include "VolumeDomain.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <set>
#include <stdexcept>

namespace fluid_domain {
namespace {

bool Finite(glm::dvec3 p) {
    return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
}

double TetVolume(const LiquidTet& tet) {
    return std::abs(glm::determinant(glm::dmat3(
        tet[1] - tet[0], tet[2] - tet[0], tet[3] - tet[0]))) / 6;
}

double GeometryVolume(const LiquidGeometry& geometry) {
    long double volume = 0;
    for (const auto& tet : geometry.cells) volume += TetVolume(tet);
    return double(volume);
}

LiquidGeometry ScaleGeometry(const LiquidGeometry& geometry, double factor) {
    auto result = geometry;
    for (auto& tet : result.cells) for (auto& point : tet) point *= factor;
    return result;
}

double Below(const LiquidGeometry& geometry, glm::dvec3 normal, double q) {
    long double volume = 0;
    for (const auto& tet : geometry.cells) {
        std::array<double, 4> coordinates;
        for (unsigned i = 0; i < 4; ++i)
            coordinates[i] = glm::dot(normal, tet[i]);
        volume += LiquidClip(tet, coordinates, q).volume;
    }
    return double(volume);
}

bool Adjacent(Key a, Key b, int& axis, int& direction) {
    const int difference[3] = {b.x - a.x, b.y - a.y, b.z - a.z};
    axis = -1;
    for (int i = 0; i < 3; ++i) {
        if (difference[i] == 0) continue;
        if (axis != -1 || std::abs(difference[i]) != 1) return false;
        axis = i;
        direction = difference[i];
    }
    return axis != -1;
}

double Cross(glm::dvec2 a, glm::dvec2 b) {
    return a.x * b.y - a.y * b.x;
}

using Polygon = std::vector<glm::dvec2>;

double Area(const Polygon& polygon) {
    if (polygon.size() < 3) return 0;
    long double twice = 0;
    const auto origin = polygon.front();
    for (std::size_t i = 1; i + 1 < polygon.size(); ++i)
        twice += Cross(polygon[i] - origin, polygon[i + 1] - origin);
    return .5 * std::abs(double(twice));
}

Polygon Intersection(Polygon polygon, const std::array<glm::dvec2, 3>& triangle) {
    const double orientation = Cross(triangle[1] - triangle[0],
                                     triangle[2] - triangle[0]);
    if (orientation == 0) return {};
    const double sign = orientation > 0 ? 1 : -1;
    for (unsigned edge = 0; edge < 3 && !polygon.empty(); ++edge) {
        const auto a = triangle[edge], b = triangle[(edge + 1) % 3];
        Polygon output;
        for (std::size_t i = 0; i < polygon.size(); ++i) {
            const auto p = polygon[i], q = polygon[(i + 1) % polygon.size()];
            const double d0 = sign * Cross(b - a, p - a);
            const double d1 = sign * Cross(b - a, q - a);
            if (d0 >= 0) output.push_back(p);
            if ((d0 >= 0) != (d1 >= 0))
                output.push_back(p + (q - p) * (d0 / (d0 - d1)));
        }
        polygon = std::move(output);
    }
    return polygon;
}

std::vector<std::array<glm::dvec2, 3>> FaceTriangles(
    const LiquidGeometry& geometry, int axis, double coordinate) {
    const int a = (axis + 1) % 3, b = (axis + 2) % 3;
    std::vector<std::array<glm::dvec2, 3>> result;
    constexpr unsigned faces[4][3] = {{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
    // Native clipped cell faces inherit their fixed axis coordinate exactly.
    // A nearby parallel surface is not an aperture, even if its gap is tiny.
    for (const auto& tet : geometry.cells) for (auto& face : faces) {
        std::array<glm::dvec2, 3> triangle;
        bool onFace = true;
        for (unsigned j=0;j<3;++j) {
            onFace &= tet[face[j]][axis] == coordinate;
            triangle[j] = {tet[face[j]][a],tet[face[j]][b]};
        }
        if (onFace && Area({triangle[0],triangle[1],triangle[2]}) > 0)
            result.push_back(triangle);
    }
    return result;
}

// A scalar fill coordinate cannot distinguish isolated pockets. Until the
// runtime supports separate component cells, reject such geometry rather than
// assigning one pocket's water to another. Edge/point touching is not a flow path.
bool ValidatePartition(const LiquidGeometry& geometry, double spacing,
                       std::string& error) {
    if (geometry.cells.empty()) return true;
    std::vector<unsigned> parent(geometry.cells.size());
    for (unsigned i = 0; i < parent.size(); ++i) parent[i] = i;
    auto root = [&](unsigned a) {
        while (parent[a] != a) a = parent[a];
        return a;
    };
    constexpr unsigned faces[4][3] = {{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
    const double eps = std::numeric_limits<double>::epsilon();
    const double coordinateTolerance = 128 * eps * spacing;
    const double areaTolerance = 128 * eps * spacing * spacing;
    const double volumeTolerance = 256 * eps * spacing * spacing * spacing;
    for (unsigned i = 0; i < geometry.cells.size(); ++i) {
        const auto& a = geometry.cells[i];
        glm::dvec3 amin = a[0], amax = a[0];
        for (auto p : a) { amin = glm::min(amin,p); amax = glm::max(amax,p); }
        for (unsigned j = 0; j < i; ++j) {
            const auto& b = geometry.cells[j];
            glm::dvec3 bmin = b[0], bmax = b[0];
            for (auto p : b) { bmin = glm::min(bmin,p); bmax = glm::max(bmax,p); }
            const auto extent = glm::min(amax,bmax)-glm::max(amin,bmin);
            if (glm::any(glm::lessThan(extent,glm::dvec3(-coordinateTolerance)))) continue;
            if (glm::all(glm::greaterThan(extent,glm::dvec3(0)))) {
                const auto overlap = LiquidCutGeometry(LiquidGeometry{{a}},LiquidTetPlanes(b));
                if (GeometryVolume(overlap) > volumeTolerance) {
                    error = "capacity partition contains overlapping tetrahedra";
                    return false;
                }
            }
            if (root(i) == root(j)) continue;
            bool connected = false;
            for (auto& fa : faces) {
                auto normal = glm::cross(a[fa[1]]-a[fa[0]],a[fa[2]]-a[fa[0]]);
                const double length = glm::length(normal);
                if (!(length > 0)) continue;
                normal /= length;
                int axis = 0;
                if (std::abs(normal.y) > std::abs(normal[axis])) axis = 1;
                if (std::abs(normal.z) > std::abs(normal[axis])) axis = 2;
                const int u = (axis+1)%3, v = (axis+2)%3;
                Polygon x;
                for (auto k : fa) x.push_back({a[k][u],a[k][v]});
                for (auto& fb : faces) {
                    bool coplanar = true;
                    for (auto k : fb)
                        coplanar &= std::abs(glm::dot(normal,b[k]-a[fa[0]])) <= coordinateTolerance;
                    if (!coplanar) continue;
                    std::array<glm::dvec2,3> y;
                    for (unsigned k=0;k<3;++k) y[k]={b[fb[k]][u],b[fb[k]][v]};
                    if (Area(Intersection(x,y))/std::abs(normal[axis]) > areaTolerance) {
                        connected = true;
                        break;
                    }
                }
                if (connected) break;
            }
            if (connected) parent[root(i)] = root(j);
        }
    }
    const unsigned first = root(0);
    for (unsigned i=1;i<parent.size();++i) {
        if (root(i) != first) {
            error = "disconnected geometry requires independent fluid subcells";
            return false;
        }
    }
    return true;
}

} // namespace

VolumeDomain::VolumeDomain(double spacing) : m_spacing(spacing) {
    if (!(spacing > 0) || !std::isfinite(spacing))
        throw std::invalid_argument("fluid grid spacing must be finite and positive");
}

bool VolumeDomain::PrepareGeometry(Cell& cell, const LiquidGeometry& geometry,
                                   std::string& error) const {
    const double roundoff = 64 * std::numeric_limits<double>::epsilon() * m_spacing;
    for (const auto& tet : geometry.cells) {
        for (auto vertex : tet) {
            if (!Finite(vertex) ||
                glm::any(glm::lessThan(vertex, glm::dvec3(-roundoff))) ||
                glm::any(glm::greaterThan(vertex, glm::dvec3(m_spacing + roundoff)))) {
                error = "capacity geometry must be finite and cell-local";
                return false;
            }
        }
        if (!(TetVolume(tet) > 0)) {
            error = "capacity geometry contains a degenerate tetrahedron";
            return false;
        }
    }
    auto normalized = ScaleGeometry(geometry,1 / m_spacing);
    if (!ValidatePartition(normalized, 1, error)) return false;
    cell.capacity = GeometryVolume(normalized) * m_spacing * m_spacing * m_spacing;
    const double cube = m_spacing * m_spacing * m_spacing;
    if (!std::isfinite(cell.capacity) || cell.capacity > cube * (1 + 1e-12)) {
        error = "capacity exceeds the cell's physical volume";
        return false;
    }
    cell.capacityGeometry = std::make_shared<const LiquidGeometry>(geometry);
    cell.capacityUnitGeometry = std::make_shared<const LiquidGeometry>(std::move(normalized));
    return true;
}

bool VolumeDomain::Reconstruct(Cell& cell, std::string& error) const {
    if (!std::isfinite(cell.volume) || cell.volume < 0 || cell.volume > cell.capacity) {
        error = "fluid volume is negative or exceeds physical capacity";
        return false;
    }
    if (!Finite(cell.interfaceNormal) || !(glm::length(cell.interfaceNormal) > 0)) {
        error = "fluid interface normal must be finite and nonzero";
        return false;
    }
    cell.interfaceNormal = glm::normalize(cell.interfaceNormal);
    cell.reconstructionError = 0;
    if (cell.volume == 0) {
        cell.interfaceCoordinate = -std::numeric_limits<double>::infinity();
        cell.wetGeometry = std::make_shared<const LiquidGeometry>();
        return true;
    }
    if (cell.volume == cell.capacity) {
        cell.interfaceCoordinate = std::numeric_limits<double>::infinity();
        cell.wetGeometry = cell.capacityGeometry;
        return true;
    }
    double low = std::numeric_limits<double>::infinity(), high = -low;
    for (const auto& tet : cell.capacityUnitGeometry->cells) {
        for (auto vertex : tet) {
            const double coordinate = glm::dot(cell.interfaceNormal, vertex);
            low = std::min(low, coordinate);
            high = std::max(high, coordinate);
        }
    }
    const double cube = m_spacing * m_spacing * m_spacing;
    const double target = cell.volume / cube;
    double q = low, bestError = target;
    // The iteration count follows double's mantissa, not a tunable pressure
    // iteration budget. The stored quantity is never changed to fit geometry.
    for (int i = 0; i < std::numeric_limits<double>::digits + 8; ++i) {
        const double mid = low + .5 * (high - low);
        if (mid == low || mid == high) break;
        const double volume = Below(*cell.capacityUnitGeometry, cell.interfaceNormal, mid);
        const double residual = std::abs(volume - target);
        if (residual < bestError) { bestError = residual; q = mid; }
        if (volume < target) low = mid;
        else high = mid;
    }
    auto wet = LiquidCutGeometry(*cell.capacityUnitGeometry,
                                {glm::dvec4(cell.interfaceNormal, q)});
    cell.interfaceCoordinate = q * m_spacing;
    cell.reconstructionError = GeometryVolume(wet) * cube - cell.volume;
    const double tolerance = 256 * std::numeric_limits<double>::epsilon() *
        m_spacing * m_spacing * m_spacing *
        std::max<std::size_t>(1, cell.capacityGeometry->cells.size());
    if (std::abs(cell.reconstructionError) > tolerance) {
        error = "wet geometry cannot represent the requested conserved volume";
        return false;
    }
    if (!ValidatePartition(wet, 1, error)) return false;
    cell.wetGeometry = std::make_shared<const LiquidGeometry>(ScaleGeometry(wet, m_spacing));
    return true;
}

bool VolumeDomain::Add(Key key, const LiquidGeometry& geometry, double volume,
                       glm::dvec3 normal, std::string& error) {
    error.clear();
    if (m_cells.count(key)) { error = "fluid cell already exists"; return false; }
    Cell cell;
    cell.volume = volume;
    cell.interfaceNormal = normal;
    if (!PrepareGeometry(cell, geometry, error) || !Reconstruct(cell, error))
        return false;
    m_cells.emplace(key, std::move(cell));
    return true;
}

const Cell* VolumeDomain::Find(Key key) const {
    const auto it = m_cells.find(key);
    return it == m_cells.end() ? nullptr : &it->second;
}

double VolumeDomain::TotalVolume() const {
    long double volume = 0;
    for (const auto& entry : m_cells) volume += entry.second.volume;
    return double(volume);
}

double VolumeDomain::SharedWetAperture(Key donor, Key receiver,
                                      std::string& error) const {
    error.clear();
    const Cell* from = Find(donor);
    const Cell* to = Find(receiver);
    int axis, direction;
    if (!from || !to || !Adjacent(donor, receiver, axis, direction)) {
        error = "fluid transfer requires two existing face-adjacent cells";
        return 0;
    }
    auto a = FaceTriangles(*from->wetGeometry, axis, direction > 0 ? m_spacing : 0);
    auto b = FaceTriangles(*to->capacityGeometry, axis, direction > 0 ? 0 : m_spacing);
    long double area = 0;
    for (const auto& x : a) for (const auto& y : b)
        area += Area(Intersection({x[0], x[1], x[2]}, y));
    return double(area);
}

bool VolumeDomain::Advance(const std::vector<Transfer>& transfers,
                           const std::vector<CapacityChange>& changes,
                           std::string& error) {
    error.clear();
    std::map<Key, long double> incoming, outgoing;
    std::set<std::pair<Key, Key>> faces;
    for (const auto& transfer : transfers) {
        if (!(transfer.volume > 0) || !std::isfinite(transfer.volume)) {
            error = "face transfer must have finite positive volume";
            return false;
        }
        const auto face = transfer.receiver < transfer.donor ?
            std::make_pair(transfer.receiver, transfer.donor) :
            std::make_pair(transfer.donor, transfer.receiver);
        if (!faces.insert(face).second) {
            error = "a face may have only one signed transfer per transaction";
            return false;
        }
        const double aperture = SharedWetAperture(transfer.donor, transfer.receiver, error);
        if (!error.empty()) return false;
        if (!(aperture > 0)) {
            error = "fluid transfer crosses a closed or currently dry aperture";
            return false;
        }
        outgoing[transfer.donor] += transfer.volume;
        incoming[transfer.receiver] += transfer.volume;
    }
    // New arrivals cannot immediately jump across a previously dry cell.
    for (const auto& out : outgoing) {
        if (out.second > m_cells.at(out.first).volume) {
            error = "outflow exceeds the donor's initial volume; subdivide transport";
            return false;
        }
    }
    auto staged = m_cells; // immutable geometry is shared; no partial publication
    std::set<Key> changed;
    for (const auto& change : changes) {
        auto it = staged.find(change.cell);
        if (it == staged.end() || !change.geometry || !changed.insert(change.cell).second) {
            error = "invalid or repeated capacity replacement";
            return false;
        }
        if (!PrepareGeometry(it->second, *change.geometry, error)) return false;
    }
    for (const auto& entry : incoming) changed.insert(entry.first);
    for (const auto& entry : outgoing) changed.insert(entry.first);
    for (auto key : changed) {
        auto& cell = staged.at(key);
        cell.volume = double((long double)cell.volume + incoming[key] - outgoing[key]);
        if (!Reconstruct(cell, error)) return false;
    }
    m_cells.swap(staged);
    return true;
}

} // namespace fluid_domain
