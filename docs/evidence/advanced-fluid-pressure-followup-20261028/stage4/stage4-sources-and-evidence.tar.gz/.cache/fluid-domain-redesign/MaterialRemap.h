#pragma once
#include "MaterialMoments.h"
#include "ExactPlanePredicates.h"
namespace fluid_remap {
using V=glm::dvec3;
using Piece=fluid_material::Piece;
inline fluid_exact::Expansion Side(const std::array<V,3>& face,V point){
 std::array<std::array<double,4>,4> matrix;
 for(unsigned i=0;i<3;++i)matrix[i]={face[i].x,face[i].y,face[i].z,1};
 matrix[3]={point.x,point.y,point.z,1};return fluid_exact::Determinant4(matrix);
}
// Local intersection reference. Exact predicates choose half-spaces; coordinates
// and integrals remain binary64 with explicitly checked conservation error.
// No absolute epsilon deletes a thin wet fragment or joins a dry gap.
inline LiquidGeometry Clip(const LiquidGeometry& input,const std::array<V,3>& face,int insideSign,unsigned budget){
 LiquidGeometry result;
 auto append=[&](V a,V b,V c,V d){LiquidTet tet{a,b,c,d};if(fluid_moment::TetVolume(tet)>0){if(result.cells.size()>=budget)throw std::runtime_error("material clipping fragment budget exceeded");result.cells.push_back(tet);}};
 auto prism=[&](V a,V b,V c,V d,V e,V f){append(a,b,c,d);append(b,c,d,e);append(c,d,e,f);};
 for(const auto& tet:input.cells){std::array<unsigned,4> in{},out{};std::array<double,4> distance{};unsigned ni=0,no=0;
  for(unsigned i=0;i<4;++i){const auto exact=Side(face,tet[i]);const int sign=insideSign*fluid_exact::Sign(exact);distance[i]=insideSign*fluid_exact::Estimate(exact);if(sign>=0)in[ni++]=i;else out[no++]=i;}
  auto edge=[&](unsigned a,unsigned b){const double denominator=distance[a]-distance[b];if(denominator==0||!std::isfinite(denominator))throw std::runtime_error("unrepresentable material clipping edge");const double t=distance[a]/denominator;V point;for(unsigned k=0;k<3;++k)point[k]=std::fma(t,tet[b][k]-tet[a][k],tet[a][k]);return point;};
  if(ni==4)append(tet[0],tet[1],tet[2],tet[3]);
  if(ni==1){auto a=in[0];append(tet[a],edge(a,out[0]),edge(a,out[1]),edge(a,out[2]));}
  if(ni==2){auto a=in[0],b=in[1],c=out[0],d=out[1];prism(tet[a],edge(a,c),edge(a,d),tet[b],edge(b,c),edge(b,d));}
  if(ni==3){auto a=in[0],b=in[1],c=in[2],d=out[0];prism(tet[a],tet[b],tet[c],edge(d,a),edge(d,b),edge(d,c));}
 }
 return result;
}
inline LiquidGeometry Intersect(const LiquidTet& source,const LiquidTet& target,unsigned budget){
 V amin=source[0],amax=source[0],bmin=target[0],bmax=target[0];
 for(unsigned i=1;i<4;++i){amin=glm::min(amin,source[i]);amax=glm::max(amax,source[i]);bmin=glm::min(bmin,target[i]);bmax=glm::max(bmax,target[i]);}
 for(unsigned k=0;k<3;++k)if(amax[k]<=bmin[k]||bmax[k]<=amin[k])return {};
 LiquidGeometry current{{source}};
 constexpr unsigned faces[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned i=0;i<4&&!current.cells.empty();++i){std::array<V,3> face{target[faces[i][0]],target[faces[i][1]],target[faces[i][2]]};const int sign=fluid_exact::Sign(Side(face,target[i]));if(sign==0)throw std::invalid_argument("degenerate material receiver tetrahedron");current=Clip(current,face,sign,budget);}
 return current;
}
struct Result {
 bool accepted=false;std::string error;
 std::vector<std::vector<Piece>> receivers;
 fluid_incoming::Moments before,after;
 unsigned intersectionQueries=0,fragments=0;
};
// Restrict a prepared piecewise affine field into a new disjoint receiver
// partition. Preserve the ACTUAL overlap geometry, including multiple separate
// wet fragments. This method NEVER fits/merges them or fills uncovered capacity.
// Native geometry preparation must validate source/receiver disjointness first.
inline Result Remap(const std::vector<Piece>& sources,const LiquidGeometry& receivers,double density,unsigned fragmentBudget=16384){
 Result result;std::vector<std::vector<Piece>> staged(receivers.cells.size());
 try{
  if(fragmentBudget==0)throw std::invalid_argument("zero material remap budget");
  for(const auto& source:sources){result.before.Add(fluid_material::Integrate(source.geometry,source.field,density));for(const auto& donor:source.geometry.cells)for(unsigned r=0;r<receivers.cells.size();++r){++result.intersectionQueries;auto overlap=Intersect(donor,receivers.cells[r],fragmentBudget);if(overlap.cells.empty())continue;
    if(overlap.cells.size()>fragmentBudget-result.fragments)throw std::runtime_error("material remap fragment budget exceeded");
    result.fragments+=overlap.cells.size();result.after.Add(fluid_material::Integrate(overlap,source.field,density));staged[r].push_back({std::move(overlap),source.field});
  }}
  const double volumeScale=std::max(result.before.volume,std::numeric_limits<double>::min());
  if(std::abs(result.after.volume-result.before.volume)>1e-11*volumeScale||glm::length(result.after.momentum-result.before.momentum)>1e-10*std::max(1.,glm::length(result.before.momentum))||glm::length(result.after.angular-result.before.angular)>1e-10*std::max(1.,glm::length(result.before.angular))||std::abs(result.after.energy-result.before.energy)>1e-10*std::max(1.,result.before.energy))throw std::runtime_error("receiver partition does not conservatively cover material");
  result.receivers=std::move(staged);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}
 return result;
}
}
