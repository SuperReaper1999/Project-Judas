#include "MaterialMoments.h"
#include <glm/gtc/quaternion.hpp>
#include <cstdio>
using V=glm::dvec3;using M=glm::dmat3;
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* text){++checks;if(!ok){++failures;std::printf("FAIL %s\n",text);}};
 for(double angle:{0.,1.13}){const auto q=glm::angleAxis(angle,glm::normalize(V(1,-2,3)));const M rotation=glm::mat3_cast(q);auto geometry=[&](double bottom,double top){auto g=LiquidBox(V(0,bottom,0),V(1,top,1));for(auto& t:g.cells)for(auto& x:t)x=q*(x-V(.5));return g;};M gradient(0);gradient[0]={.1,.2,0};gradient[1]={-.2,-.1,.15};gradient[2]={0,-.15,0};gradient=rotation*gradient*glm::transpose(rotation);fluid_material::Field original{V(0),q*V(.12,-.03,.05),gradient};auto full=geometry(0,1),retained=geometry(0,.2),drained=geometry(.2,1);auto initial=fluid_material::Integrate(full,original,1000);auto left=fluid_material::Integrate(retained,original,1000);auto right=fluid_material::Integrate(drained,original,1000);
 check(std::abs(initial.volume-1)<1e-13&&std::abs(left.volume-.2)<1e-13,"1000 to 200 litre actual material restriction");check(glm::length(initial.momentum-left.momentum-right.momentum)<1e-10&&glm::length(initial.angular-left.angular-right.angular)<1e-10&&std::abs(initial.energy-left.energy-right.energy)<1e-10,"draining removes actual spatial momentum and energy, not average state");
 double largest=0;auto retainedField=original;
 for(unsigned cycle=0;cycle<100;++cycle){auto result=fluid_material::Project({{retained,retainedField},{drained,original}},1000);check(result.accepted,"refill projects actual retained and incoming material");const auto& state=result.state;
  // Independent analytic covariance of the complete unit cube, including
  // its rotated copy, is I/12. Feed the result into the NEXT drain/refill.
  retainedField={state.centroid,state.mean,state.affine*std::sqrt(12.)};
  for(const auto& t:full.cells)for(auto x:t){const V actual=retainedField.value+retainedField.gradient*(x-retainedField.origin);largest=std::max(largest,glm::length(actual-(original.value+gradient*x)));}
  check(largest<1e-11&&std::abs(result.energyChange)<1e-10,"repeated stateful refill preserves represented affine modes");
 }
 // Incoming donor has different momentum: the resulting change is accounted
 // for by its actual field, never assigned zero merely because a cell was dry.
 fluid_material::Field incoming{V(0),q*V(1,.1,0),M(0)};auto mixture=fluid_material::Project({{retained,original},{drained,incoming}},1000);auto expected=left;expected.Add(fluid_material::Integrate(drained,incoming,1000));check(mixture.accepted&&glm::length(mixture.state.mass*mixture.state.mean-expected.momentum)<1e-10,"new material carries its own nonzero incoming momentum");check(mixture.energyChange<=1e-10,"affine projection does not manufacture kinetic energy");
 auto existing=fluid_material::Project({{retained,original}},1000);auto other=fluid_material::Project({{drained,incoming}},1000);check(existing.accepted&&other.accepted&&glm::length(existing.source.momentum-left.momentum)<1e-12,"separately submitted components keep their independent state");auto invalid=fluid_material::Project({{full,original}},-1);check(!invalid.accepted,"invalid material preparation has no publishable state");
 std::printf("MATERIAL angle=%g cycles=100 initial_L=%.12g retained_L=%.12g velocity_error=%g mixed_energy_change=%g\n",angle,initial.volume*1000,left.volume*1000,largest,mixture.energyChange);
 }
 std::printf("MATERIAL_MOMENTS checks=%u failures=%u\n",checks,failures);std::puts("Scope: exact prepared fragments and affine field restriction/projection; no geometry transport, topology inference or pressure evolution claimed.");return failures?1:0;}
