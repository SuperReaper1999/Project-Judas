#pragma once
#include "VolumeDomain.h"
#include <glm/glm.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <stdexcept>
namespace fluid_moment {
using V=glm::dvec3;using M=glm::dmat3;
struct Slice {
 V normal{0,1,0},centroid{0};double volume=0,area=0,coordinate=0;M surfaceCovariance{0};
 std::shared_ptr<const LiquidGeometry> geometry;
};
inline double TetVolume(const LiquidTet& t){return std::abs(glm::determinant(M(t[1]-t[0],t[2]-t[0],t[3]-t[0])))/6.;}
inline V Centroid(const LiquidGeometry& geometry){double volume=0;V moment(0);for(const auto& t:geometry.cells){double v=TetVolume(t);volume+=v;moment+=v*(t[0]+t[1]+t[2]+t[3])*.25;}if(!(volume>0))throw std::invalid_argument("empty moment geometry");return moment/volume;}
inline Slice Evaluate(const LiquidGeometry& capacity,double quantity,V normal){
 fluid_domain::VolumeDomain temporary(1);std::string error;if(!temporary.Add({0,0,0},capacity,quantity,normal,error))throw std::runtime_error(error);const auto& cell=*temporary.Find({0,0,0});Slice result;result.normal=cell.interfaceNormal;result.coordinate=cell.interfaceCoordinate;result.volume=cell.volume;result.geometry=cell.wetGeometry;result.centroid=Centroid(*cell.wetGeometry);
 struct Triangle{std::array<V,3> points;double area;};std::vector<Triangle> surface;
 for(const auto& t:capacity.cells){std::array<double,4> distance;bool inside=false;for(unsigned i=0;i<4;++i){distance[i]=glm::dot(result.normal,t[i])-result.coordinate;inside|=distance[i]<0;}if(!inside)continue;std::vector<V> polygon;for(unsigned i=0;i<4;++i)if(distance[i]==0)polygon.push_back(t[i]);for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j)if((distance[i]<0&&distance[j]>0)||(distance[i]>0&&distance[j]<0)){double fraction=distance[i]/(distance[i]-distance[j]);V point;for(unsigned a=0;a<3;++a)point[a]=std::fma(fraction,t[j][a]-t[i][a],t[i][a]);polygon.push_back(point);}if(polygon.size()<3)continue;V center(0);for(auto p:polygon)center+=p;center/=double(polygon.size());V axis=std::abs(result.normal.x)<.8?V(1,0,0):V(0,1,0);V tangent=glm::normalize(glm::cross(result.normal,axis)),other=glm::cross(result.normal,tangent);std::sort(polygon.begin(),polygon.end(),[&](V a,V b){return std::atan2(glm::dot(a-center,other),glm::dot(a-center,tangent))<std::atan2(glm::dot(b-center,other),glm::dot(b-center,tangent));});for(unsigned i=1;i+1<polygon.size();++i){std::array<V,3> tri{polygon[0],polygon[i],polygon[i+1]};double area=.5*glm::length(glm::cross(tri[1]-tri[0],tri[2]-tri[0]));if(area>0)surface.push_back({tri,area});}}
 V surfaceCenter(0);for(const auto& t:surface){result.area+=t.area;surfaceCenter+=t.area*(t.points[0]+t.points[1]+t.points[2])/3.;}if(result.area>0){surfaceCenter/=result.area;for(const auto& t:surface){V sum(0);M diagonal(0);for(auto p:t.points){V r=p-surfaceCenter;sum+=r;diagonal+=glm::outerProduct(r,r);}result.surfaceCovariance+=t.area*(glm::outerProduct(sum,sum)+diagonal)/12.;}result.surfaceCovariance/=result.area;}
 return result;
}
struct Reconstruction {Slice slice;double defect=INFINITY;unsigned evaluations=0;bool represented=false;};
inline Reconstruction Reconstruct(const LiquidGeometry& capacity,double volume,V target,double tolerance=1e-10,unsigned budget=256){
 if(!(volume>0)||!std::isfinite(volume)||!(tolerance>0))throw std::invalid_argument("invalid moment reconstruction");
 Reconstruction best;const V center=Centroid(capacity);std::vector<V> starts;V offset=center-target;if(glm::dot(offset,offset)>0)starts.push_back(glm::normalize(offset));for(unsigned axis=0;axis<3;++axis)for(double sign:{-1.,1.}){V normal(0);normal[axis]=sign;starts.push_back(normal);}
 auto evaluate=[&](V normal){++best.evaluations;auto slice=Evaluate(capacity,volume,glm::normalize(normal));double defect=glm::length(slice.centroid-target);if(defect<best.defect){best.slice=slice;best.defect=defect;}return slice;};
 for(auto start:starts){if(best.evaluations>=budget||best.defect<=tolerance)break;auto current=evaluate(start);for(unsigned iteration=0;iteration<24&&best.evaluations<budget&&best.defect>tolerance;++iteration){const V residual=current.centroid-target;V axis=std::abs(current.normal.x)<.8?V(1,0,0):V(0,1,0);V t0=glm::normalize(glm::cross(current.normal,axis)),t1=glm::cross(current.normal,t0);const V j0=-(current.area/volume)*(current.surfaceCovariance*t0),j1=-(current.area/volume)*(current.surfaceCovariance*t1);double h0=glm::dot(j0,j0),h1=glm::dot(j1,j1),off=glm::dot(j0,j1),g0=glm::dot(j0,residual),g1=glm::dot(j1,residual),det=h0*h1-off*off;double d0=0,d1=0;if(det>64*std::numeric_limits<double>::epsilon()*h0*h1){d0=(-h1*g0+off*g1)/det;d1=(off*g0-h0*g1)/det;}else{double scale=std::max(h0,h1);if(!(scale>0))break;d0=-g0/scale;d1=-g1/scale;}V change=t0*d0+t1*d1;const double length=glm::length(change);if(!(length>0))break;if(length>.5)change*=.5/length;bool accepted=false;for(unsigned line=0;line<8&&best.evaluations<budget;++line){auto candidate=evaluate(current.normal+change);if(glm::length(candidate.centroid-target)<glm::length(residual)){current=std::move(candidate);accepted=true;break;}change*=.5;}if(!accepted)break;}}
 best.represented=best.defect<=tolerance;return best;
}
}
