#include "ExactPlanePredicates.h"
#include "ExactPlaneCases.h"
#include <cstdio>
using namespace fluid_exact;
int main(){unsigned checks=0,failures=0;auto check=[&](bool ok,const char* name){++checks;if(!ok){++failures;std::printf("FAIL %s\n",name);}};
 for(const auto& test:exactCases)check(Sign(Determinant4(test.matrix))==test.sign,"independent rational determinant oracle");
 for(double scale:{.001,1.,100.}){std::array<Plane,3> planes{{{{1,0,0},scale},{{0,1,0},scale*.5},{{0,0,1},scale*.25}}};const auto point=Intersection::Make(planes);for(auto plane:planes)check(point.Side(plane)==0,"intersection belongs to its defining planes exactly");auto position=point.Position();check(position[0]==scale&&position[1]==scale*.5&&position[2]==scale*.25,"exact axis-plane coordinates");for(double gap:{1e-10,1e-14}){Plane lower{{1,0,0},scale*(1-gap)},upper{{1,0,0},scale*(1+gap)};check(point.Side(lower)>0&&point.Side(upper)<0,"real thin gap retains opposite sides");}}
 bool rejected=false;try{Intersection::Make({Plane{{1,0,0},0},Plane{{1,0,0},1},Plane{{0,1,0},0}});}catch(const std::invalid_argument&){rejected=true;}check(rejected,"parallel-plane intersection explicitly rejected");
 std::printf("EXACT_PLANE checks=%u failures=%u\n",checks,failures);return failures?1:0;}
