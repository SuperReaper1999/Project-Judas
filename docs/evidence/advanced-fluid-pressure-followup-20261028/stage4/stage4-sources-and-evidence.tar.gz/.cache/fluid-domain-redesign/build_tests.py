from pathlib import Path
import sys,subprocess
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
implementation=p.compile(out/'VolumeDomain.cpp','volume-domain')
tests=p.compile(out/'VolumeDomainTests.cpp','volume-domain-tests')
p.executable(tests,'volume-domain-tests',implementation)
