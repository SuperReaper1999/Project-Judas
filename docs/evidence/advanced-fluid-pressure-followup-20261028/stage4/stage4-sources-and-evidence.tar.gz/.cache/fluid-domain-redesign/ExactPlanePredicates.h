#pragma once
#if defined(__FAST_MATH__)
#error "Exact geometry predicates require IEEE-preserving arithmetic; disable fast-math"
#endif
#include <array>
#include <vector>
#include <cmath>
#include <stdexcept>
#include <limits>
namespace fluid_exact {
// Binary64 expansion predicates for LOCAL bounded geometry. Coordinates remain
// doubles; topology is determined from exact operations on the input doubles.
// No proximity epsilon creates adjacency. Unsupported overflow/underflow is an
// explicit preparation failure, not a zero/inside classification.
using Expansion=std::vector<double>;
inline void Add(Expansion& e,double b){if(!std::isfinite(b))throw std::runtime_error("nonfinite geometry predicate");double q=b;Expansion out;out.reserve(e.size()+1);for(double a:e){double sum=q+a;if(!std::isfinite(sum))throw std::runtime_error("geometry predicate overflow");double bv=sum-q;double error=(q-(sum-bv))+(a-bv);if(error!=0)out.push_back(error);q=sum;}if(q!=0||out.empty())out.push_back(q);e=std::move(out);}
inline Expansion Sum(Expansion a,const Expansion& b){for(double x:b)Add(a,x);return a;}
inline Expansion Negate(Expansion e){for(auto& v:e)v=-v;return e;}
inline Expansion Product(const Expansion& a,const Expansion& b){Expansion result;for(double x:a)for(double y:b){if(x==0||y==0)continue;double p=x*y;if(!std::isfinite(p)||std::abs(p)<std::numeric_limits<double>::min())throw std::runtime_error("geometry predicate product outside supported range");double error=std::fma(x,y,-p);if(error!=0)Add(result,error);Add(result,p);}if(result.empty())result.push_back(0);return result;}
inline int Sign(const Expansion& e){for(auto i=e.rbegin();i!=e.rend();++i)if(*i!=0)return *i>0?1:-1;return 0;}
inline double Estimate(const Expansion& e){double result=0;for(double v:e)result+=v;return result;}
inline Expansion Determinant3(const std::array<std::array<double,3>,3>& a){Expansion result;constexpr unsigned permutations[6][3]={{0,1,2},{1,2,0},{2,0,1},{0,2,1},{2,1,0},{1,0,2}};for(unsigned k=0;k<6;++k){Expansion term{1};for(unsigned r=0;r<3;++r)term=Product(term,{a[r][permutations[k][r]]});if(k>=3)term=Negate(std::move(term));result=Sum(std::move(result),term);}return result;}
inline Expansion Determinant4(const std::array<std::array<double,4>,4>& a){Expansion result;for(unsigned column=0;column<4;++column){std::array<std::array<double,3>,3> minor;for(unsigned r=1;r<4;++r){unsigned at=0;for(unsigned c=0;c<4;++c)if(c!=column)minor[r-1][at++]=a[r][c];}auto term=Product({a[0][column]},Determinant3(minor));if(column%2)term=Negate(std::move(term));result=Sum(std::move(result),term);}return result;}
struct Plane{std::array<double,3> normal;double coordinate;};
struct Intersection {
 std::array<Expansion,3> numerator;Expansion denominator;
 static Intersection Make(const std::array<Plane,3>& planes){std::array<std::array<double,3>,3> coefficients;for(unsigned r=0;r<3;++r)coefficients[r]=planes[r].normal;Intersection p;p.denominator=Determinant3(coefficients);if(Sign(p.denominator)==0)throw std::invalid_argument("dependent intersection planes");for(unsigned axis=0;axis<3;++axis){auto a=coefficients;for(unsigned r=0;r<3;++r)a[r][axis]=planes[r].coordinate;p.numerator[axis]=Determinant3(a);}return p;}
 int Side(const Plane& plane)const{Expansion value=Negate(Product({plane.coordinate},denominator));for(unsigned axis=0;axis<3;++axis)value=Sum(std::move(value),Product({plane.normal[axis]},numerator[axis]));return Sign(value)*Sign(denominator);}
 std::array<double,3> Position()const{std::array<double,3> result;double d=Estimate(denominator);if(d==0||!std::isfinite(d))throw std::runtime_error("unrepresentable geometry denominator");for(unsigned a=0;a<3;++a){result[a]=Estimate(numerator[a])/d;if(!std::isfinite(result[a]))throw std::runtime_error("unrepresentable geometry coordinate");}return result;}
};
}
