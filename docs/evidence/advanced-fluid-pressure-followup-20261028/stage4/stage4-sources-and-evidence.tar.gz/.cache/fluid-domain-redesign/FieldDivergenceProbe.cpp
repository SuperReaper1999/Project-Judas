#define main retained_tetra_test_main
#include "TetraPressureTests.cpp"
#undef main
#include <random>
double DivergenceError(const Model& m){double maximum=0;for(const auto& c:m.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){V gradient=m.frame*V(c.inverse[0][k],c.inverse[1][k],c.inverse[2][k]);trace+=glm::dot(gradient,m.points[c.first+1+k].velocity);norm+=glm::dot(gradient,gradient);}maximum=std::max(maximum,std::abs(trace)/std::sqrt(norm));}return maximum;}
int main(){Model model;BuildTetra(model,false,.37);std::mt19937 random(17);std::uniform_real_distribution<double> sample(-.2,.2);for(auto& p:model.points)p.velocity={sample(random),sample(random),sample(random)};double before=DivergenceError(model);auto solved=SparseInterior(model.points,model.bodies,model.rows,model.bilateral,64,1e-10);double after=DivergenceError(model);std::printf("RAW_CONDENSED converged=%d reported_velocity_residual=%g actual_divergence_velocity_before=%g after=%g\n",solved.converged,solved.maximumResidual,before,after);return solved.converged&&after<1e-10?0:1;}
