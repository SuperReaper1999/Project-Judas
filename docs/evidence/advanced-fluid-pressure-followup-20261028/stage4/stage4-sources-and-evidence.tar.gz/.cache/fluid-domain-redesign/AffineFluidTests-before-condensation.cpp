#include "VolumeDomain.h"
#include "MixedProjection.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <cstdio>
#include <map>

using V=glm::dvec3;
using M=glm::dmat3;
using namespace fluid_domain;
using namespace pressure_prototype;

namespace {
double Volume(const LiquidTet& t){return std::abs(glm::determinant(M(t[1]-t[0],t[2]-t[0],t[3]-t[0])))/6;}
struct FluidCell {Key key;V center;M factor,inverse;double mass;unsigned first;std::vector<V> samples;};
struct Model {
 VolumeDomain domain{.3};std::vector<FluidCell> cells;std::map<Key,unsigned> index;
 std::vector<Point> points;std::vector<Body> bodies;std::vector<Row> rows;std::vector<bool> bilateral;
 V center{.03,.65,-.04};V half{.22};glm::dquat rotation{1,0,0,0};M frame{1};double bodyMass=0,bodyVolume=0;
 void Add(Row row,bool equality){rows.push_back(std::move(row));bilateral.push_back(equality);}
 void Evaluation(Row& row,const FluidCell& cell,V point,V normal,double sign=1)const{
  const auto phi=cell.inverse*(point-cell.center);
  row.points.push_back({cell.first,normal*sign});
  for(unsigned k=0;k<3;++k)row.points.push_back({cell.first+1+k,normal*(sign*phi[k])});
 }
 std::vector<V> Hull(std::vector<V> vertices,V normal)const{
  if(vertices.size()<3)return {};
  int axis=0;if(std::abs(normal.y)>std::abs(normal[axis]))axis=1;if(std::abs(normal.z)>std::abs(normal[axis]))axis=2;
  const int u=(axis+1)%3,v=(axis+2)%3;
  std::sort(vertices.begin(),vertices.end(),[&](V a,V b){return a[u]<b[u]||(a[u]==b[u]&&a[v]<b[v]);});
  vertices.erase(std::unique(vertices.begin(),vertices.end(),[&](V a,V b){return a[u]==b[u]&&a[v]==b[v];}),vertices.end());
  auto turn=[&](V a,V b,V c){return (b[u]-a[u])*(c[v]-a[v])-(b[v]-a[v])*(c[u]-a[u]);};
  std::vector<V> hull;
  for(auto p:vertices){while(hull.size()>1&&turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
  const auto lower=hull.size();
  for(std::size_t i=vertices.size()-1;i-->0;){auto p=vertices[i];while(hull.size()>lower&&turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
  if(hull.size()>1)hull.pop_back();
  return hull;
 }
 std::vector<V> Three(std::vector<V> points,V normal)const{
  auto hull=Hull(std::move(points),normal);if(hull.size()<3)return {};
  unsigned b=1,c=2;for(unsigned i=1;i<hull.size();++i)if(glm::dot(hull[i]-hull[0],hull[i]-hull[0])>glm::dot(hull[b]-hull[0],hull[b]-hull[0]))b=i;
  double area=-1;for(unsigned i=1;i<hull.size();++i){double a=glm::dot(glm::cross(hull[b]-hull[0],hull[i]-hull[0]),glm::cross(hull[b]-hull[0],hull[i]-hull[0]));if(a>area){area=a;c=i;}}
  return {hull[0],hull[b],hull[c]};
 }
 void Build(double angle,double ratio,bool walls,bool fixed){
  rotation=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));bodyVolume=8*half.x*half.y*half.z;bodyMass=1000*bodyVolume*ratio;
  bodies.push_back({V(0),V(0),fixed?0:1/bodyMass,M(fixed?0:3/(2*bodyMass*half.x*half.x))});
  std::vector<glm::dvec4> planes;
  for(int axis=0;axis<3;++axis)for(double sign:{-1.,1.}){V normal(0);normal[axis]=sign;normal=rotation*normal;planes.emplace_back(normal,glm::dot(normal,center)+half[axis]);}
  std::string error;
  const V origin(-.6,0,-.6);constexpr int nx=4,ny=5,nz=4;constexpr double h=.3;
  for(int y=0;y<ny;++y)for(int z=0;z<nz;++z)for(int x=0;x<nx;++x){Key key{x,y,z};const V offset=origin+h*V(x,y,z);auto local=planes;for(auto& p:local)p.w-=glm::dot(V(p),offset);
   auto geometry=LiquidSubtractSolids(LiquidBox(V(0),V(h)),{local});double volume=0;V first(0);for(const auto& t:geometry.cells){double v=Volume(t);volume+=v;first+=v*(t[0]+t[1]+t[2]+t[3])*.25;}
   if(!(volume>1e-14))continue;
   // Initialize from the compiled geometric capacity, not an assumed cuboid.
   if(!domain.Add(key,geometry,0,{0,1,0},error))throw std::runtime_error(error);
   const double capacity=domain.Find(key)->capacity;
   // A fresh filled copy is used because Add's quantity is authoritative.
   V centroid=first/volume;M covariance(0);
   for(const auto& t:geometry.cells){V sum(0);M diagonal(0);for(auto p:t){V r=p-centroid;sum+=r;diagonal+=glm::outerProduct(r,r);}covariance+=Volume(t)*(glm::outerProduct(sum,sum)+diagonal)/20.;}
   covariance/=volume;M factor(0);
   for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double a=covariance[j][i];for(unsigned k=0;k<j;++k)a-=factor[k][i]*factor[k][j];if(i==j){if(!(a>0))throw std::runtime_error("singular fluid covariance");factor[j][i]=std::sqrt(a);}else factor[j][i]=a/factor[j][j];}
   FluidCell cell{key,offset+centroid,factor,glm::inverse(factor),1000*capacity,unsigned(points.size()),{}};
   for(const auto& t:geometry.cells)for(auto p:t)cell.samples.push_back(offset+p);
   for(unsigned k=0;k<4;++k)points.push_back({V(0),1/cell.mass});
   index.emplace(key,unsigned(cells.size()));cells.push_back(cell);
  }
  // Rebuild the immutable capacities as filled cells for face inspection.
  VolumeDomain filled(h);
  for(const auto& cell:cells){const auto* original=domain.Find(cell.key);if(!filled.Add(cell.key,*original->capacityGeometry,original->capacity,{0,1,0},error))throw std::runtime_error(error);}
  domain=std::move(filled);
  for(const auto& cell:cells){Row incompressible;for(unsigned k=0;k<3;++k){V gradient(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);incompressible.points.push_back({cell.first+1+k,gradient*(cell.mass/1000)});}Add(incompressible,true);
   const V offset=origin+h*V(cell.key.x,cell.key.y,cell.key.z);
   for(int axis=0;axis<3;++axis){Key neighbor=cell.key;if(axis==0)++neighbor.x;if(axis==1)++neighbor.y;if(axis==2)++neighbor.z;auto found=index.find(neighbor);if(found==index.end())continue;V normal(0);normal[axis]=1;std::vector<V> vertices;for(auto& patch:domain.SharedWetPatches(cell.key,neighbor))for(auto p:patch)vertices.push_back(offset+p);
    for(auto p:Three(vertices,normal)){Row row;Evaluation(row,cell,p,normal);Evaluation(row,cells[found->second],p,normal,-1);Add(row,true);}
   }
   if(walls)for(int axis=0;axis<3;++axis)for(int sign:{-1,1}){const int at=axis==0?cell.key.x:axis==1?cell.key.y:cell.key.z;const int count=axis==0?nx:axis==1?ny:nz;if((sign<0&&at!=0)||(sign>0&&at!=count-1)||(axis==1&&sign>0))continue;V normal(0);normal[axis]=sign;std::vector<V> vertices;for(auto& patch:domain.WetFacePatches(cell.key,axis,sign))for(auto p:patch)vertices.push_back(offset+p);for(auto p:Hull(vertices,normal)){Row row;Evaluation(row,cell,p,normal);Add(row,false);}}
   for(unsigned face=0;face<planes.size();++face){const auto plane=planes[face];const V n(plane);std::vector<V> vertices;const double d=plane.w-glm::dot(n,offset);constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
    for(const auto& t:domain.Find(cell.key)->wetGeometry->cells)for(auto& f:tri){std::vector<V> polygon;bool on=true;for(auto k:f){on&=std::abs(glm::dot(n,t[k])-d)<1e-13;polygon.push_back(offset+t[k]);}if(!on)continue;
     for(unsigned p=0;p<planes.size()&&!polygon.empty();++p)if(p!=face){std::vector<V> clipped;for(unsigned i=0;i<polygon.size();++i){V a=polygon[i],b=polygon[(i+1)%polygon.size()];double da=glm::dot(V(planes[p]),a)-planes[p].w,db=glm::dot(V(planes[p]),b)-planes[p].w;if(da<=0)clipped.push_back(a);if((da<=0)!=(db<=0))clipped.push_back(a+(b-a)*(da/(da-db)));}polygon=std::move(clipped);}
     vertices.insert(vertices.end(),polygon.begin(),polygon.end());
    }
    for(auto p:Hull(vertices,n)){const V normal=-n;Row row;Evaluation(row,cell,p,normal);row.bodies.push_back({0,-normal,-glm::cross(p-center,normal)});Add(row,false);}
   }
  }
 }
 V Momentum()const{V result(0);for(const auto& cell:cells)result+=cell.mass*points[cell.first].velocity;if(bodies[0].inverseMass>0)result+=bodies[0].velocity*bodyMass;return result;}
 V Angular()const{V result(0);for(const auto& cell:cells){M affine;for(unsigned k=0;k<3;++k)affine[k]=points[cell.first+1+k].velocity;M s=frame*cell.factor*glm::transpose(affine);V local(s[2][1]-s[1][2],s[0][2]-s[2][0],s[1][0]-s[0][1]);result+=cell.mass*(glm::cross(frame*cell.center,points[cell.first].velocity)+local);}if(bodies[0].inverseMass>0)result+=bodyMass*glm::cross(frame*center,bodies[0].velocity)+glm::inverse(bodies[0].inverseInertia)*bodies[0].angularVelocity;return result;}
 double Energy()const{double value=0;for(auto p:points)value+=.5*glm::dot(p.velocity,p.velocity)/p.inverseMass;if(bodies[0].inverseMass>0)value+=.5*bodyMass*glm::dot(bodies[0].velocity,bodies[0].velocity)+.5*glm::dot(bodies[0].angularVelocity,glm::inverse(bodies[0].inverseInertia)*bodies[0].angularVelocity);return value;}
 double MaxSpeed()const{double value=0;for(const auto& cell:cells)for(auto x:cell.samples){V velocity=points[cell.first].velocity;const auto phi=cell.inverse*(x-cell.center);for(unsigned k=0;k<3;++k)velocity+=points[cell.first+1+k].velocity*phi[k];value=std::max(value,glm::length(velocity));}return value;}
};
}

int main(){unsigned failures=0;try{
 for(bool allBilateral:{false,true}){
  Model model;model.Build(.37,1,true,false);for(const auto& cell:model.cells)model.points[cell.first].velocity={0,-9.81/90,0};model.bodies[0].velocity={0,-9.81/90,0};if(allBilateral)std::fill(model.bilateral.begin(),model.bilateral.end(),true);
  auto result=ProjectMixed(model.points,model.bodies,model.rows,model.bilateral,256,1e-9);
  double mostNegative=0;for(unsigned i=0;i<model.rows.size();++i)if(!model.rows[i].bodies.empty()||!model.bilateral[i])mostNegative=std::min(mostNegative,result.pressureImpulse[i]);
  std::printf("AFFINE_CONTROL bilateral=%d iterations=%u residual=%.12g converged=%d body_v=%.12g max_fluid=%.12g min_contact_multiplier=%.12g\n",allBilateral,result.sweeps,result.maximumResidual,result.converged,glm::length(model.bodies[0].velocity),model.MaxSpeed(),mostNegative);
 }
 Model free;free.Build(.37,1,false,false);
 const V translation(.3,-.2,.1),omega(.2,-.1,.3);M cross(0);cross[0]={0,omega.z,-omega.y};cross[1]={-omega.z,0,omega.x};cross[2]={omega.y,-omega.x,0};

 for(const auto& cell:free.cells){free.points[cell.first].velocity=translation+glm::cross(omega,cell.center);M b=cross*cell.factor;for(unsigned k=0;k<3;++k)free.points[cell.first+1+k].velocity=b[k];}
 free.bodies[0].velocity=translation+glm::cross(omega,free.center);free.bodies[0].angularVelocity=omega;
 double rigidError=0;for(auto& row:free.rows){double value=0;for(auto g:row.points)value+=glm::dot(g.gradient,free.points[g.point].velocity);for(auto g:row.bodies)value+=glm::dot(g.linear,free.bodies[g.body].velocity)+glm::dot(g.angular,free.bodies[g.body].angularVelocity);rigidError=std::max(rigidError,std::abs(value));}
 auto initialP=free.Momentum(),initialL=free.Angular();auto initialE=free.Energy();auto result=ProjectMixed(free.points,free.bodies,free.rows,free.bilateral,256,1e-9);
 std::printf("RIGID_PATCH algebraic_error=%.12g converged=%d iterations=%u dP=%.12g dL=%.12g dE=%.12g\n",rigidError,result.converged,result.sweeps,glm::length(free.Momentum()-initialP),glm::length(free.Angular()-initialL),free.Energy()-initialE);
 if(rigidError>1e-10||!result.converged||result.sweeps!=0)++failures;
 for(const auto& cell:free.cells){free.points[cell.first].velocity={0,-9.81/90,0};for(unsigned k=1;k<4;++k)free.points[cell.first+k].velocity=V(0);}free.bodies[0].velocity={0,-9.81/90,0};free.bodies[0].angularVelocity=V(0);
 result=ProjectMixed(free.points,free.bodies,free.rows,free.bilateral,256,1e-9);
 std::printf("FREEFALL converged=%d iterations=%u residual=%.12g body_vy=%.12g\n",result.converged,result.sweeps,result.maximumResidual,free.bodies[0].velocity.y);
 if(!result.converged||result.sweeps!=0)++failures;
 }catch(const std::exception& e){++failures;std::printf("ERROR %s\n",e.what());}std::printf("STRUCTURAL_CONTROL failures=%u (hydrostatic solve controls are reported separately)\n",failures);return failures?1:0;}
