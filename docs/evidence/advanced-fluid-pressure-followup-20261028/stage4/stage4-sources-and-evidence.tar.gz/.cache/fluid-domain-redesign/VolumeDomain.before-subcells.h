#pragma once

#include "LiquidGeometry.h"
#include <map>
#include <memory>
#include <string>
#include <vector>
#include <tuple>

namespace fluid_domain {

// Coordinates are cell-local metres. World placement and gravity frames are
// deliberately absent from conserved quantity and clipping arithmetic.
struct Key {
    int x = 0, y = 0, z = 0;
    bool operator<(const Key& other) const {
        return std::tie(x, y, z) < std::tie(other.x, other.y, other.z);
    }
    bool operator==(const Key& other) const {
        return x == other.x && y == other.y && z == other.z;
    }
};

struct Cell {
    std::shared_ptr<const LiquidGeometry> capacityGeometry;
    std::shared_ptr<const LiquidGeometry> wetGeometry;
    std::shared_ptr<const LiquidGeometry> capacityUnitGeometry; // derived clipping frame
    double capacity = 0;
    double volume = 0;
    glm::dvec3 interfaceNormal{0, 1, 0};
    double interfaceCoordinate = 0;
    double reconstructionError = 0;
};

struct Transfer {
    Key donor, receiver;
    double volume = 0;
};

struct CapacityChange {
    Key cell;
    std::shared_ptr<const LiquidGeometry> geometry;
};

class VolumeDomain {
public:
    explicit VolumeDomain(double spacing);
    bool Add(Key, const LiquidGeometry&, double volume,
             glm::dvec3 interfaceNormal, std::string& error);
    // Input fluxes must already have been computed by a pressure/advection
    // scheme. This class does not invent fluxes, redistribute overflows or
    // replace a momentum solver. A transaction either publishes in full or not.
    bool Advance(const std::vector<Transfer>&,
                 const std::vector<CapacityChange>&, std::string& error);
    double SharedWetAperture(Key donor, Key receiver, std::string& error) const;
    const Cell* Find(Key key) const;
    std::vector<LiquidPolygon> WetFacePatches(Key,int axis,int direction) const;
    std::vector<LiquidPolygon> SharedWetPatches(Key,Key) const;
    double TotalVolume() const;
    bool MeasureCapacity(const LiquidGeometry&, double& capacity, std::string& error) const;
    std::size_t Size() const { return m_cells.size(); }

private:
    double m_spacing;
    std::map<Key, Cell> m_cells;
    bool Reconstruct(Cell&, std::string& error) const;
    bool PrepareGeometry(Cell&, const LiquidGeometry&, std::string& error) const;
};

} // namespace fluid_domain
