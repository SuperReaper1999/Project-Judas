#include "VolumeDomain.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <limits>
#include <glm/gtc/quaternion.hpp>

using namespace fluid_domain;

int main() {
    unsigned checks = 0, failures = 0;
    auto check = [&](bool ok, const char* description) {
        ++checks;
        if (!ok) { ++failures; std::printf("FAIL %s\n", description); }
    };
    std::string error;
    const auto cube = LiquidBox({0,0,0},{1,1,1});
    const auto begin = std::chrono::steady_clock::now();

    // Real geometry, not just scalar-accounting checks.
    for (auto normal : {glm::dvec3(0,1,0),glm::dvec3(1,2,3),glm::dvec3(-3,.1,2)}) {
        for (double fraction : {.001,.07,.25,.5,.9,.999}) {
            VolumeDomain domain(1);
            check(domain.Add({0,0,0},cube,fraction,normal,error), "oblique wet reconstruction");
            const auto* cell = domain.Find({0,0,0});
            if (cell) {
                check(cell->volume == fraction, "reconstruction never adjusts quantity");
                check(std::abs(cell->reconstructionError)<1e-12,"physical wet geometry matches quantity");
                check(std::abs(glm::length(cell->interfaceNormal)-1)<1e-14,"normal normalized");
            } else std::printf("RECONSTRUCTION_ERROR %s\n",error.c_str());
        }
    }

    VolumeDomain flowing(1);
    check(flowing.Add({0,0,0},cube,.75,{0,1,0},error),"wet donor created");
    check(flowing.Add({1,0,0},cube,0,{0,1,0},error),"dry receiver created");
    check(flowing.Add({2,0,0},cube,0,{0,1,0},error),"second dry cell created");
    check(std::abs(flowing.SharedWetAperture({0,0,0},{1,0,0},error)-.75)<1e-12,"actual wet aperture area");
    check(flowing.Advance({{{0,0,0},{1,0,0},.25}},{},error),"dry cell re-wets through real aperture");
    check(flowing.Find({0,0,0})->volume == .5 && flowing.Find({1,0,0})->volume == .25,"paired volume transfer");
    check(flowing.TotalVolume()==.75,"re-wetting conserves total quantity");
    check(flowing.Advance({{{1,0,0},{2,0,0},.125}},{},error),"new wet topology permits subsequent transfer");
    check(flowing.TotalVolume()==.75,"multi-step transport conserved");

    VolumeDomain noTeleport(1);
    check(noTeleport.Add({0,0,0},cube,.5,{0,1,0},error),"teleport test donor");
    check(noTeleport.Add({1,0,0},cube,0,{0,1,0},error),"teleport test dry middle");
    check(noTeleport.Add({2,0,0},cube,0,{0,1,0},error),"teleport test dry end");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.25},{{1,0,0},{2,0,0},.25}},{},error),"cannot cross dry middle in one transaction");
    check(noTeleport.Find({0,0,0})->volume==.5&&noTeleport.Find({1,0,0})->volume==0&&noTeleport.Find({2,0,0})->volume==0,"failed topology transaction fully rolls back");
    check(!noTeleport.Advance({{{0,0,0},{2,0,0},.125}},{},error),"nonadjacent transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.75}},{},error),"negative donor volume rejected before publication");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},-.1}},{},error),"negative transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},std::numeric_limits<double>::infinity()}},{},error),"infinite transfer rejected");
    check(!noTeleport.Advance({{{0,0,0},{1,0,0},.1},{{0,0,0},{1,0,0},.1}},{},error),"duplicate face flux rejected");

    VolumeDomain mismatch(1);
    check(mismatch.Add({0,0,0},LiquidBox({0,.5,0},{1,1,1}),.5,{0,1,0},error),"upper-half aperture donor");
    check(mismatch.Add({1,0,0},LiquidBox({0,0,0},{1,.5,1}),0,{0,1,0},error),"lower-half aperture receiver");
    check(mismatch.SharedWetAperture({0,0,0},{1,0,0},error)==0,"nonoverlapping positive-area apertures remain disconnected");
    check(!mismatch.Advance({{{0,0,0},{1,0,0},.1}},{},error),"no transfer through mismatched openings");

    VolumeDomain shutter(1);
    check(shutter.Add({0,0,0},LiquidBox({0,0,0},{.5,1,1}),.25,{0,1,0},error),"closed solid boundary donor");
    check(shutter.Add({1,0,0},cube,0,{0,1,0},error),"closed solid boundary receiver");
    check(!shutter.Advance({{{0,0,0},{1,0,0},.1}},{},error),"solid wall blocks transfer");
    check(shutter.Advance({},{{{0,0,0},std::make_shared<const LiquidGeometry>(cube)}},error),"authored aperture can open without changing quantity");
    check(shutter.TotalVolume()==.25,"opening does not create quantity");
    check(shutter.Advance({{{0,0,0},{1,0,0},.125}},{},error),"actual reconnection permits flow");

    VolumeDomain moving(1);
    check(moving.Add({0,0,0},cube,.75,{0,1,0},error),"moving-solid test cell");
    auto half = std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{.5,1,1}));
    const auto oldGeometry = moving.Find({0,0,0})->capacityGeometry;
    check(!moving.Advance({},{{{0,0,0},half}},error),"capacity loss without physical outflow rejected");
    check(moving.Find({0,0,0})->volume==.75&&moving.Find({0,0,0})->capacityGeometry==oldGeometry,"failed moving-solid update preserves geometry and quantity");
    check(moving.Add({1,0,0},cube,0,{0,1,0},error),"moving-solid outflow receiver");
    check(moving.Advance({{{0,0,0},{1,0,0},.25}},{{{0,0,0},half}},error),"capacity loss plus legitimate outflow commits together");
    check(moving.TotalVolume()==.75&&moving.Find({0,0,0})->volume==.5,"moving-solid transaction conserved");

    LiquidGeometry isolated=LiquidBox({0,0,0},{.4,1,1});
    auto other=LiquidBox({.6,0,0},{1,1,1});isolated.cells.insert(isolated.cells.end(),other.cells.begin(),other.cells.end());
    VolumeDomain topology(1);
    check(!topology.Add({0,0,0},isolated,.4,{0,1,0},error),"independent pockets cannot share one scalar fill");
    check(topology.Size()==0,"unsupported pocket topology not published");
    auto overlap=LiquidBox({0,0,0},{.6,1,1});other=LiquidBox({.4,0,0},{.8,1,1});overlap.cells.insert(overlap.cells.end(),other.cells.begin(),other.cells.end());
    check(!topology.Add({0,0,0},overlap,.5,{0,1,0},error),"overlapping capacity tets rejected even when summed volume is below cube volume");
    check(!topology.Add({0,0,0},cube,1.01,{0,1,0},error),"initial overfill rejected");
    check(!topology.Add({0,0,0},cube,-.01,{0,1,0},error),"initial negative quantity rejected");
    check(!topology.Add({0,0,0},cube,.1,{0,0,0},error),"zero interface normal rejected");

    // Repeated re-wetting and drainage use the same physical aperture and state,
    // with no repair/clamp/equilibrium-reset operation in between.
    VolumeDomain cycles(1);
    check(cycles.Add({0,0,0},cube,.75,{0,1,0},error),"repeat donor");
    check(cycles.Add({1,0,0},cube,.25,{0,1,0},error),"repeat receiver");
    for (unsigned i=0;i<100;++i) {
        check(cycles.Advance({{{0,0,0},{1,0,0},.125}},{},error),"repeat forward transfer");
        check(cycles.Advance({{{1,0,0},{0,0,0},.125}},{},error),"repeat reverse transfer");
        check(cycles.TotalVolume()==1,"repeated transactions conserve exact dyadic total");
    }
    const auto* c=cycles.Find({0,0,0});
    check(c->volume==.75&&cycles.Find({1,0,0})->volume==.25,"cycles restore original quantities without resets");
    check(c->interfaceNormal==glm::dvec3(0,1,0),"transport retains authored local interface orientation");
    // Native oblique solid subtraction, not only empty cuboids.
    for (double angle : {.17,.71,1.39}) {
        auto rotation=glm::angleAxis(angle,glm::normalize(glm::dvec3(1,2,3)));
        std::vector<glm::dvec4> planes;
        for(int axis=0;axis<3;++axis)for(double sign:{-1.,1.}) {
            glm::dvec3 n(0);n[axis]=sign;n=rotation*n;
            planes.emplace_back(n,glm::dot(n,glm::dvec3(.5))+.18);
        }
        auto capacity=LiquidSubtractSolids(cube,{planes});
        for(double volume:{.1,.4,.8}) {
            VolumeDomain cut(1);
            check(cut.Add({0,0,0},capacity,volume,{.1,1,.2},error),"native oblique solid/wet geometry");
            if(const auto* cell=cut.Find({0,0,0})) {
                check(std::abs(cell->capacity-(1-std::pow(.36,3)))<1e-12,"native physical solid capacity");
                check(std::abs(cell->reconstructionError)<1e-12,"native wet-volume consistency");
            } else std::printf("NATIVE_CUT_ERROR %s\n",error.c_str());
        }
    }
    for (double h : {.001,.01,.05,.25,4.,100.}) {
        auto geometry=LiquidBox({0,0,0},glm::dvec3(h));
        VolumeDomain scaled(h);
        const double volume=.31*h*h*h;
        check(scaled.Add({0,0,0},geometry,volume,{1,2,-3},error),"cell-size independent reconstruction");
        if(const auto* cell=scaled.Find({0,0,0}))
            check(std::abs(cell->reconstructionError)/(h*h*h)<1e-12,"scale-normalized volume error");
        else std::printf("SCALE_ERROR %.6g %s\n",h,error.c_str());
    }
    VolumeDomain tinyGap(1);
    check(tinyGap.Add({0,0,0},LiquidBox({0,0,0},{1-1e-10,1,1}),.5,{0,1,0},error),"nearly touching donor");
    check(tinyGap.Add({1,0,0},cube,0,{0,1,0},error),"nearly touching receiver");
    check(tinyGap.SharedWetAperture({0,0,0},{1,0,0},error)==0,"tiny dry gap is not mistaken for a wet aperture");
    check(!tinyGap.Advance({{{0,0,0},{1,0,0},.1}},{},error),"no illegal transport across tiny dry gap");

    // A nearly-full clipped volume must retain the physical capacity face,
    // including both triangle patches, even if derived mesh vertices round.
    for(double height:{.75000002384185793,.613,.9999999}) {
        VolumeDomain nearFull(1);
        auto geometry=LiquidBox({0,0,0},{1,height,1});
        check(nearFull.Add({0,0,0},geometry,height,{0,1,0},error),"nearly full source geometry");
        check(nearFull.Add({1,0,0},cube,height,{0,1,0},error),"nearly full receiving geometry");
        check(std::abs(nearFull.SharedWetAperture({0,0,0},{1,0,0},error)-height)<1e-13,
              "capacity-face provenance preserves the entire wet aperture");
    }
    for(unsigned i=0;i<100;++i) {
        const double height=.25+.5*(.5+.5*std::sin(double(i)));
        VolumeDomain exactBox(1);
        check(exactBox.Add({0,0,0},LiquidBox({0,0,0},{1,height,1}),height,{0,1,0},error),
              "full source matches independent analytic box volume");
        if(const auto* cell=exactBox.Find({0,0,0}))
            check(cell->capacity==height,"rectangular source capacity preserves the exact height volume");
    }
    // The void is connected above a sill but its low water pockets are not.
    auto basin=LiquidBox({0,0,0},{.4,1,1});
    other=LiquidBox({.6,0,0},{1,1,1});basin.cells.insert(basin.cells.end(),other.cells.begin(),other.cells.end());
    other=LiquidBox({.4,.75,0},{.6,1,1});basin.cells.insert(basin.cells.end(),other.cells.begin(),other.cells.end());
    VolumeDomain sill(1);
    check(!sill.Add({0,0,0},basin,.2,{0,1,0},error),"dry sill cannot connect low isolated water pockets");
    check(sill.Size()==0,"unsupported wet-pocket split preserves empty domain");

    const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
    std::printf("SUMMARY checks=%u failures=%u milliseconds=%.6f\n",checks,failures,ms);
    std::printf("Scope: geometric quantity/flux transactions only; pressure velocities, moving-body force, advection flux construction and runtime integration are NOT proved by this test.\n");
    return failures?1:0;
}
