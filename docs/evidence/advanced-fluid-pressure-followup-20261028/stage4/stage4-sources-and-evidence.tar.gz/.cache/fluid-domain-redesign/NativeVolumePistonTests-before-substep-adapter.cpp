#include "VolumeDomain.h"
#include "../fluid-grid-redesign/TransactionalProjection.h"
#include "PhysicsWorld.h"
#include <glm/gtc/quaternion.hpp>
#include <cstdio>
#include <cmath>

using namespace fluid_domain;
namespace {
unsigned checks=0,failures=0;
void Check(bool ok,const char* description){++checks;if(!ok){++failures;std::printf("FAIL %s\n",description);}}
constexpr float dt=1.f/60;
}

int main(){
 for(double angle:{0.,.37,1.31}){
  const auto q=glm::angleAxis(float(angle),glm::normalize(glm::vec3(1,-2,3)));
  const glm::vec3 up=q*glm::vec3(0,1,0);
  PhysicsWorld world;world.Init();
  auto body=world.CreateDynamicBox(q*glm::vec3(0,.85f,0),{.5f,.1f,.5f},80,0,0);
  world.ResetBody(body,q*glm::vec3(0,.85f,0),q);
  const auto initial=world.GetTransform(body);
  const double height=double(glm::dot(initial.position,up))-.1;
  auto capacity=LiquidBox({0,0,0},{1,height,1});
  VolumeDomain water(1);std::string error;
  Check(water.Add({0,0,0},capacity,height,{0,1,0},error),"native piston water domain created");
  if(!water.Find({0,0,0})){std::printf("DOMAIN_ERROR %s\n",error.c_str());continue;}
  unsigned calls=0;double impulse=0;bool solved=true,phaseBeforePose=true;
  PhysicsWorld::VelocityCoupling phase;phase.iterations=1;
  BodyTransform stepStart;
  phase.solve=[&](float h,unsigned){
   ++calls;phaseBeforePose&=world.GetTransform(body).position==stepStart.position;
   const auto before=world.GetLinearVelocity(body);const double mass=world.GetMass(body);
   // This reference's centered piston only has a translational normal wrench;
   // native angular velocity/inertia are untouched, not locked or replaced.
   std::vector<pressure_prototype::Point> points;
   std::vector<pressure_prototype::Body> bodies{{glm::dvec3(before),glm::dvec3(0),1/mass,glm::dmat3(0)}};
   pressure_prototype::Row row;row.bodies.push_back({0,-glm::dvec3(up),{0,0,0}});
   const double bottom=double(glm::dot(world.GetTransform(body).position,up))-.1;
   row.maximumRate=(bottom-water.Find({0,0,0})->volume)/h;
   auto result=grid_fluid::ProjectTransactional(points,bodies,{row},256,1e-9);
   solved&=result.converged;
   if(result.converged){const glm::vec3 reaction=glm::vec3((bodies[0].velocity-glm::dvec3(before))*mass);if(glm::dot(reaction,reaction)>0)world.ApplyLinearImpulse(body,reaction);impulse+=glm::dot(reaction,up);}
  };
  for(unsigned tick=0;tick<120;++tick){stepStart=world.GetTransform(body);world.ApplyLinearAcceleration(body,-9.81f*up,dt);world.Step(dt,&phase);}
  const auto final=world.GetTransform(body);const auto velocity=world.GetLinearVelocity(body);
  const double expected=80*9.81*120*dt;
  std::printf("NATIVE_CLOSED_PISTON angle=%.3g calls=%u displacement=%.12g speed=%.12g reaction=%.12g expected=%.12g volume=%.12g\n",angle,calls,double(glm::length(final.position-initial.position)),double(glm::length(velocity)),impulse,expected,water.TotalVolume());
  Check(calls>0&&solved,"pressure participates in actual native velocity phase");
  Check(phaseBeforePose,"pressure runs before native pose advance");
  Check(glm::length(final.position-initial.position)<1e-5f&&glm::length(velocity)<1e-5f,"closed incompressible volume supports actual restored endpoint");
  Check(std::abs(impulse-expected)<.002,"native pressure reaction matches supported load");
  Check(water.TotalVolume()==height,"native pressure does not manufacture water quantity");

  // Independent absent-mechanism control at the identical pose and gravity.
  PhysicsWorld absent;absent.Init();auto fall=absent.CreateDynamicBox(initial.position,{.5f,.1f,.5f},80,0,0);absent.ResetBody(fall,initial.position,q);absent.ApplyLinearAcceleration(fall,-9.81f*up,dt);absent.Step(dt);
  Check(glm::dot(absent.GetTransform(fall).position-initial.position,up)<-.002f,"without pressure the same native body falls");

  // The constraint is unilateral. It must never pull a departing body back.
  world.SetLinearVelocity(body,up);
  stepStart=world.GetTransform(body);const double oldImpulse=impulse;world.Step(dt,&phase);
  Check(glm::dot(world.GetTransform(body).position-stepStart.position,up)>.016f,"native piston can separate from liquid");
  Check(std::abs(impulse-oldImpulse)<1e-6,"separation produces no tensile pressure");
 }
 std::printf("SUMMARY checks=%u failures=%u\n",checks,failures);
 std::printf("Scope: native closed-piston pressure timing/load only. This is not a free-surface buoyancy or open-flow runtime qualification.\n");
 return failures?1:0;
}
