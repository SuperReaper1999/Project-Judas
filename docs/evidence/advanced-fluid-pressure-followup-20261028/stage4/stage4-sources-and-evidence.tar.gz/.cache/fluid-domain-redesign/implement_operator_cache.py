from pathlib import Path
p=Path('.cache/fluid-domain-redesign/SparseInterior.h');s=p.read_text()
s=s.replace('double assemblyMs=0,bodyColumnsMs=0;unsigned calls=0;', '''double assemblyMs=0,bodyColumnsMs=0;unsigned calls=0,operatorBuilds=0,operatorHits=0;
 std::vector<std::vector<pressure_prototype::PointGradient>> operatorRows;
 std::vector<double> operatorMasses,operatorScale;
 std::vector<std::map<unsigned,double>> operatorMatrix;''')
a=s.index(' std::vector<std::map<unsigned,double>> matrix(n);');b=s.index(' workspace.assemblyMs',a)
s=s[:a]+''' // Cache only the fluid mass/Jacobian operator. Exact numeric comparison,
 // including point identities, prevents reuse across moved/replaced geometry.
 // Body inertia, gradients, velocities, row limits and inequality policy remain
 // current inputs and are deliberately NOT cached by this mechanism.
 bool sameOperator=workspace.operatorRows.size()==n&&workspace.operatorMasses.size()==points.size()&&workspace.operatorMatrix.size()==n;
 for(unsigned p=0;p<points.size()&&sameOperator;++p)sameOperator=workspace.operatorMasses[p]==points[p].inverseMass;
 for(unsigned i=0;i<n&&sameOperator;++i){const auto& old=workspace.operatorRows[i];const auto& now=rows[i].points;sameOperator=old.size()==now.size();for(unsigned g=0;g<old.size()&&sameOperator;++g)sameOperator=old[g].point==now[g].point&&old[g].gradient==now[g].gradient;}
 if(!sameOperator){
  std::vector<std::map<unsigned,double>> assembled(n);
  std::vector<std::vector<std::pair<unsigned,glm::dvec3>>> incident(points.size());
  for(unsigned i=0;i<n;++i)for(auto g:rows[i].points)incident.at(g.point).push_back({i,g.gradient});
  for(unsigned p=0;p<incident.size();++p)for(auto [i,a]:incident[p])for(auto [j,b]:incident[p])if(i<=j)assembled[i][j]+=points[p].inverseMass*glm::dot(a,b);
  std::vector<double> scaling(n);
  for(unsigned i=0;i<n;++i){double d=assembled[i][i];if(!(d>0)||!std::isfinite(d))throw std::runtime_error("empty or invalid pressure constraint");scaling[i]=1/std::sqrt(d);}
  for(unsigned i=0;i<n;++i)for(auto& [j,v]:assembled[i])v*=scaling[i]*scaling[j];
  std::vector<std::vector<PointGradient>> keys;keys.reserve(n);for(const auto& row:rows)keys.push_back(row.points);
  std::vector<double> masses;for(const auto& point:points)masses.push_back(point.inverseMass);
  workspace.operatorRows=std::move(keys);workspace.operatorMasses=std::move(masses);workspace.operatorScale=std::move(scaling);workspace.operatorMatrix=std::move(assembled);++workspace.operatorBuilds;
 }else ++workspace.operatorHits;
 const auto& matrix=workspace.operatorMatrix;
 const auto& scale=workspace.operatorScale;
''' +s[b:]
s=s.replace('std::vector<double> scale(n),rhs(n),lambda(n,0),z(n,0);','std::vector<double> rhs(n),lambda(n,0),z(n,0);')
s=s.replace('double d=matrix[i][i];if(!(d>0))throw std::runtime_error("empty pressure constraint");scale[i]=1/std::sqrt(d);double v=', 'double v=')
s=s.replace(' for(unsigned i=0;i<n;++i)for(auto& [j,v]:matrix[i])v*=scale[i]*scale[j];\n','')
p.write_text(s)
p=Path('.cache/fluid-domain-redesign/NativeCompiledPressureTests.cpp');s=p.read_text().replace('workspace.calls,workspace.assemblyMs','workspace.calls,workspace.assemblyMs');s=s.replace('  std::printf("ASSEMBLY_PROFILE', '  std::printf("OPERATOR_CACHE builds=%u hits=%u\\n",workspace.operatorBuilds,workspace.operatorHits);\n  std::printf("ASSEMBLY_PROFILE');p.write_text(s)
