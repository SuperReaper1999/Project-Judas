#pragma once
#include "IncomingWetState.h"
namespace fluid_incoming {
// Geometric normal displacement (m) supplies volume flux; the independently
// transported physical velocity supplies momentum/energy. This is an integrated
// space-time face measure, not a rescaled physical velocity or volume repair.
inline Moments IntegrateSwept(const std::array<V,3>& triangle,const std::array<V,3>& velocity,const std::array<double,3>& displacement,double dt,double density){
 if(!std::isfinite(dt)||dt<=0||!std::isfinite(density)||density<=0)throw std::invalid_argument("invalid incoming material interval/density/normal");
 for(unsigned i=0;i<3;++i)for(unsigned a=0;a<3;++a)if(!std::isfinite(triangle[i][a])||!std::isfinite(velocity[i][a]))throw std::invalid_argument("nonfinite swept material geometry/velocity");
 struct Vertex{V point,velocity;double flow;};std::vector<Vertex> polygon;std::array<double,3> flow;for(unsigned i=0;i<3;++i){flow[i]=displacement[i];if(!std::isfinite(flow[i]))throw std::invalid_argument("nonfinite material inflow");}
 for(unsigned i=0;i<3;++i){const unsigned j=(i+1)%3;if(flow[i]>=0)polygon.push_back({triangle[i],velocity[i],flow[i]});if((flow[i]>0&&flow[j]<0)||(flow[i]<0&&flow[j]>0)){const double fraction=flow[i]/(flow[i]-flow[j]);V x,u;for(unsigned a=0;a<3;++a){x[a]=std::fma(fraction,triangle[j][a]-triangle[i][a],triangle[i][a]);u[a]=std::fma(fraction,velocity[j][a]-velocity[i][a],velocity[i][a]);}polygon.push_back({x,u,0});}}
 Moments result;const double root35=std::sqrt(.6),root3=std::sqrt(1./3);const double nodes[3]={.5*(1-root35),.5,.5*(1+root35)},weights[3]={5./18,4./9,5./18},tNodes[2]={.5*(1-root3),.5*(1+root3)};
 for(unsigned triangleIndex=1;triangleIndex+1<polygon.size();++triangleIndex){const auto& a=polygon[0];const auto& b=polygon[triangleIndex];const auto& c=polygon[triangleIndex+1];const double twiceArea=glm::length(glm::cross(b.point-a.point,c.point-a.point));for(unsigned i=0;i<3;++i)for(unsigned j=0;j<2;++j){const double s=nodes[i],t=tNodes[j];const double wa=(1-s)*(1-t),wb=s,wc=(1-s)*t;const V x=wa*a.point+wb*b.point+wc*c.point,u=wa*a.velocity+wb*b.velocity+wc*c.velocity;const double f=wa*a.flow+wb*b.flow+wc*c.flow;const double volume=weights[i]*.5*(1-s)*twiceArea*f;const V endpoint=x+.5*dt*u;result.volume+=volume;result.spatial+=volume*endpoint;result.momentum+=density*volume*u;result.angular+=density*volume*glm::cross(endpoint,u);result.mixed+=density*volume*glm::outerProduct(endpoint,u);result.energy+=.5*density*volume*glm::dot(u,u);}}
 return result;
}
}
