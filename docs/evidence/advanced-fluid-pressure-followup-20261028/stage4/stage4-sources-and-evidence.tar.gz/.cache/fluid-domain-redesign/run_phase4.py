from pathlib import Path
import subprocess,json,hashlib,datetime,time,sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign';results=[]
tests=[('build_cut.py','cut-mesh-tests'),('build_cut_adversarial.py','cut-mesh-adversarial'),('build_moving_cut.py','moving-cut-mesh-tests'),('build_wet_cut.py','wet-cut-mesh-tests'),('build_owned_capacity.py','owned-capacity-tests'),('build_complementarity.py','pressure-complementarity-tests'),('build_mass_scale.py','pressure-mass-scale-tests'),('build_fluid_projection.py','fluid-projection-tests'),('build_tetra.py','tetra-pressure-tests'),('build_side.py','tetra-side-tests'),('build_compiled_pressure.py','compiled-pressure-tests'),('build_native_compiled.py','native-compiled-pressure-tests'),('build_advection.py','dg-advection-tests'),('build_wet_flux.py','wet-flux-tests'),('build_moment.py','moment-interface-tests'),('build_incoming.py','incoming-wet-state-tests'),('build_pressure_volume.py','pressure-volume-step-tests'),('build_operator_cache.py','operator-cache-tests'),('build_material_moments.py','material-moments-tests'),('build_material_remap.py','material-remap-tests'),('build_pressure_remap.py','pressure-remap-tests'),('build_moving_wet.py','moving-wet-state-tests'),('build_wet_regions.py','wet-region-tests')]
tests += [('build_tests.py','volume-domain-tests'),('build_geometric_transport.py','geometric-transport-tests'),('build_ale.py','ale-transport-tests'),('build_ale_wind.py','ale-wind-tests'),('build_finite_front.py','finite-front-tests'),('build_conforming_wind.py','conforming-wind-tests'),('build_subcells.py','subcell-ownership-tests'),('build_native_piston3d.py','native-piston3d'),('build_native_ale.py','native-ale-piston-tests'),('build_wind_comparison.py','wind-comparison')]
completed=json.loads((out/'PHASE4_RESULTS.json').read_text())['tests'] if '--resume' in sys.argv and (out/'PHASE4_RESULTS.json').exists() else []
for record in completed:
 if record['test']=='volume-domain-tests' and record.get('exit')==1:
  evidence=(out/'phase4-volume-domain-tests.log').read_text()
  assert evidence.count('FAIL native oblique solid/wet geometry')==9 and 'checks=653 failures=9' in evidence
  record['classification']='preserved known raw-unowned-geometry failure; NOT PASS'
results=completed
for builder,name in tests:
 if any(row['test']==name for row in completed):continue
 start=time.monotonic()
 with (out/f'phase4-{name}-build.log').open('w') as log:
  build=subprocess.run(['python3',str(out/builder)],stdout=log,stderr=subprocess.STDOUT)
 record=dict(test=name,build_exit=build.returncode)
 if build.returncode==0:
  exe=root/'.cache/fluid-contact-repair'/name;record['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
  with (out/f'phase4-{name}.log').open('w') as log:
   try:run=subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT,timeout=90);record['exit']=run.returncode
   except subprocess.TimeoutExpired:record['exit']='timeout'
 if name=='volume-domain-tests' and record.get('exit')==1:
  evidence=(out/'phase4-volume-domain-tests.log').read_text()
  if evidence.count('FAIL native oblique solid/wet geometry')==9 and 'checks=653 failures=9' in evidence:
   record['classification']='preserved known raw-unowned-geometry failure; NOT PASS'
 record['secondsIncludingBuild']=time.monotonic()-start;results.append(record)
 (out/'PHASE4_RESULTS.json').write_text(json.dumps(dict(updatedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseRevision='66e6f75ed0da7b0c27c9de2629a34c2c6096899a',scope='Local numerical prototypes; not a production fluid backend',tests=results),indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if record.get('exit')!=0 and not record.get('classification'):break
