#include "FacePressure.h"

#include <algorithm>
#include <cmath>
#include <set>

namespace fluid_domain {
PressureStep ProjectFaces(const VolumeDomain& domain, double dt,
    const std::vector<Face>& inputFaces,
    const std::vector<pressure_prototype::Body>& inputBodies,
    const std::vector<CapacityWrench>& wrenches) {
    PressureStep result;
    if (!(dt > 0) || !std::isfinite(dt)) {
        result.error = "pressure interval must be finite and positive";
        return result;
    }
    std::map<Key, pressure_prototype::Row> baseUpper, baseLower;
    const auto touch = [&](Key key) {
        const auto* cell = domain.Find(key);
        if (!cell) return false;
        baseUpper[key].maximumRate = (cell->capacity - cell->volume) / dt;
        baseLower[key].maximumRate = cell->volume / dt;
        return true;
    };
    std::vector<double> forward, reverse;
    std::vector<bool> directions;
    std::set<std::pair<Key,Key>> uniqueFaces;
    for (const auto& face : inputFaces) {
        if (!(face.mass > 0) || !std::isfinite(face.mass) || !std::isfinite(face.velocity) ||
            !touch(face.a) || !touch(face.b)) {
            result.error = "invalid pressure face or effective fluid mass";
            return result;
        }
        auto key = face.b < face.a ? std::make_pair(face.b,face.a) : std::make_pair(face.a,face.b);
        if (!uniqueFaces.insert(key).second) {
            result.error = "duplicate pressure face";
            return result;
        }
        std::string error;
        forward.push_back(domain.SharedWetAperture(face.a, face.b, error));
        if (!error.empty()) { result.error = error; return result; }
        reverse.push_back(domain.SharedWetAperture(face.b, face.a, error));
        if (!error.empty()) { result.error = error; return result; }
        if (!(forward.back() > 0 || reverse.back() > 0)) {
            result.error = "pressure face has no wet aperture";
            return result;
        }
        directions.push_back(reverse.back() == 0 ||
            (forward.back() > 0 && face.velocity >= 0));
    }
    for (const auto& wrench : wrenches) {
        if (!touch(wrench.cell) || wrench.body >= inputBodies.size()) {
            result.error = "invalid moving-capacity owner";
            return result;
        }
        baseUpper[wrench.cell].bodies.push_back({wrench.body, wrench.linear, wrench.angular});
    }
    for (auto& entry : baseUpper) {
        std::map<unsigned, std::pair<glm::dvec3, glm::dvec3>> aggregate;
        for (auto g : entry.second.bodies) {
            auto it = aggregate.find(g.body);
            if (it == aggregate.end()) aggregate.emplace(g.body, std::make_pair(g.linear,g.angular));
            else { it->second.first += g.linear; it->second.second += g.angular; }
        }
        entry.second.bodies.clear();
        for (auto& g : aggregate)
            entry.second.bodies.push_back({g.first,g.second.first,g.second.second});
    }
    std::set<std::vector<bool>> visited;
    unsigned used = 0, products = 0;
    while (used < 256) {
        if (!visited.insert(directions).second) {
            result.error = "upwind pressure aperture selection cycled";
            return result;
        }
        ++result.upwindPasses;
        auto upper = baseUpper, lower = baseLower;
        std::vector<pressure_prototype::Point> points;
        std::vector<pressure_prototype::Row> rows;
        for (unsigned i=0;i<inputFaces.size();++i) {
            const auto& face=inputFaces[i];
            const double area=directions[i]?forward[i]:reverse[i];
            points.push_back({glm::dvec3(face.velocity,0,0),1/face.mass});
            upper[face.a].points.push_back({i,{-area,0,0}});
            upper[face.b].points.push_back({i,{area,0,0}});
            lower[face.a].points.push_back({i,{area,0,0}});
            lower[face.b].points.push_back({i,{-area,0,0}});
            if (forward[i]==0) rows.push_back({{{i,{1,0,0}}},{},0});
            if (reverse[i]==0) rows.push_back({{{i,{-1,0,0}}},{},0});
        }
        for (auto& row : upper) { rows.push_back(row.second);rows.push_back(lower.at(row.first)); }
        // Every sign retry starts at the SAME predicted momentum. It does not
        // apply a previous trial's impulses twice, or restart its work budget.
        auto bodies=inputBodies;
        try { result.solver=grid_fluid::ProjectTransactional(points,bodies,rows,256-used,1e-9); }
        catch(const std::exception& error) { result.error=error.what();return result; }
        used += std::max(1u,result.solver.sweeps);
        products += result.solver.matrixProducts;
        if (!result.solver.converged) {
            result.error="cell pressure projection did not converge";
            return result;
        }
        auto next=directions;
        bool consistent=true;
        for (unsigned i=0;i<points.size();++i) {
            const double velocity=points[i].velocity.x;
            if ((velocity>0&&forward[i]==0)||(velocity<0&&reverse[i]==0)) {
                result.error="dry-face pressure bound not strictly feasible";
                return result;
            }
            if (velocity!=0) next[i]=velocity>0;
            consistent &= next[i]==directions[i];
        }
        if (!consistent) { directions=std::move(next);continue; }
        result.faces=inputFaces;
        result.bodies=std::move(bodies);
        for (unsigned i=0;i<result.faces.size();++i) {
            auto& face=result.faces[i];face.velocity=points[i].velocity.x;
            const double area=directions[i]?forward[i]:reverse[i];
            const double volume=face.velocity*area*dt;
            if (volume>0) result.transfers.push_back({face.a,face.b,volume});
            if (volume<0) result.transfers.push_back({face.b,face.a,-volume});
        }
        result.solver.sweeps=used;
        result.solver.matrixProducts=products;
        result.converged=true;
        return result;
    }
    result.error="upwind pressure exhausted the shared work budget";
    return result;
}
} // namespace fluid_domain
