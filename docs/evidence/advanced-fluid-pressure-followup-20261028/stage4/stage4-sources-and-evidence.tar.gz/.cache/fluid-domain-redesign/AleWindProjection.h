#pragma once
// Included after the private BuildCompiled pressure fixture builder.
#include "AlePressureMesh.h"
#include "EqualityProjectionQR.h"
namespace fluid_ale_fixture {
struct WindResult {bool accepted=false;std::string error;std::vector<fluid_ale::Field> fields;double residual=0,gaugeError=0,divergence=0;unsigned sweeps=0,rows=0,dofs=0;};
inline WindResult ProjectWind(const fluid_ale::Mesh& motion,const std::vector<fluid_ale::Field>& predicted,double time,double dt,std::vector<double>* diagnosticMatrix=nullptr,
 const std::function<EqualityQrResult(Model&)>& referenceSolver={}){
 WindResult result;try{
  auto prepared=Compile(motion,time);if(prepared.source.size()!=motion.cells.size())throw std::runtime_error("wind quadrature contains an unprepared zero element");Model m;BuildCompiled(m,prepared.mesh,true,V(.2),{1,0,0,0},V(10),2,V(2,1,1),false);
  std::vector<Row> keep;std::vector<bool> flags;for(unsigned i=0;i<m.rows.size();++i)if(m.bilateral[i]){keep.push_back(m.rows[i]);flags.push_back(true);}m.rows=std::move(keep);m.bilateral=std::move(flags);
  for(unsigned c=0;c<m.cells.size();++c){const auto& f=predicted.at(prepared.source[c]);const auto& cell=m.cells[c];m.points[cell.first].velocity=fluid_ale::Evaluate(f,cell.center);const M b=f.gradient*cell.factor;for(unsigned k=0;k<3;++k)m.points[cell.first+1+k].velocity=b[k];}
  struct Face{std::array<unsigned,3> ids;std::vector<unsigned> owners;};std::map<std::array<unsigned,3>,Face> faces;constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};for(unsigned c=0;c<motion.cells.size();++c)for(const auto& f:tri){std::array<unsigned,3> ids{motion.cells[c][f[0]],motion.cells[c][f[1]],motion.cells[c][f[2]]};auto key=ids;std::sort(key.begin(),key.end());faces[key].ids=ids;faces[key].owners.push_back(c);}
  bool omitted=false;Row gauge;
  for(const auto& [key,face]:faces)if(face.owners.size()==1){unsigned c=face.owners[0];std::array<V,3> p;for(unsigned i=0;i<3;++i)p[i]=prepared.mesh.vertices[face.ids[i]].position;V normal=glm::normalize(glm::cross(p[1]-p[0],p[2]-p[0]));if(glm::dot(normal,m.cells[c].center-p[0])>0)normal=-normal;for(unsigned i=0;i<3;++i){Row row;m.Evaluation(row,m.cells[c],p[i],normal);row.maximumRate=glm::dot(motion.Derivative(face.ids[i],time)/dt,normal);if(!omitted){gauge=row;omitted=true;}else m.Add(std::move(row),true);}}
  // One redundant boundary normal is a closed-component pressure gauge.
  // Its physical value is verified independently after solving. This helper
  // currently accepts one connected component, not arbitrary disconnected data.
  auto solved=referenceSolver?referenceSolver(m):ProjectEqualityQR(m,1e-10,diagnosticMatrix);result.rows=solved.rows;result.dofs=solved.dofs;result.residual=solved.residual;result.divergence=solved.divergence;if(!solved.accepted)throw std::runtime_error(solved.error);double error=-gauge.maximumRate;for(auto g:gauge.points)error+=glm::dot(g.gradient,m.points[g.point].velocity);result.gaugeError=std::abs(error);if(result.gaugeError>1e-10)throw std::runtime_error("removed Neumann gauge equation is physically inconsistent");
  for(const auto& cell:m.cells){M b;for(unsigned k=0;k<3;++k)b[k]=m.points[cell.first+1+k].velocity;result.fields.push_back({cell.center,m.points[cell.first].velocity,b*cell.inverse});}result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;
}
}
