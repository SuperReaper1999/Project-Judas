from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-redesign'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
main=p.compile(out/'MaterialMomentsTests.cpp','material-moments-tests');p.executable(main,'material-moments-tests')
