from pathlib import Path
import subprocess,json,re,hashlib,platform,datetime
base=Path('.cache/fluid-domain-redesign');before=base/'native-profile-before-cache.bin';after=Path('.cache/fluid-contact-repair/native-compiled-pressure-tests');records=[]
for trial in range(3):
 for name,exe in ([('before',before),('after',after)] if trial%2==0 else [('after',after),('before',before)]):
  run=subprocess.run([str(exe.resolve())],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30);(base/f'cache-matched-{trial}-{name}.log').write_text(run.stdout)
  records.append(dict(trial=trial,variant=name,exit=run.returncode,binarySha256=hashlib.sha256(exe.read_bytes()).hexdigest(),profiles=re.findall(r'ASSEMBLY_PROFILE[^\n]+',run.stdout),physicalEndpoints=re.findall(r'NATIVE_COMPILED angle=[^\n]+',run.stdout)))
  assert run.returncode==0
(base/'CACHE_MATCHED.json').write_text(json.dumps(dict(timeUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),machine=platform.platform(),scope='Identical 409-tet two-second native neutral-body workload; prototype only',records=records),indent=2)+'\n')
print('3 matched pairs passed')
