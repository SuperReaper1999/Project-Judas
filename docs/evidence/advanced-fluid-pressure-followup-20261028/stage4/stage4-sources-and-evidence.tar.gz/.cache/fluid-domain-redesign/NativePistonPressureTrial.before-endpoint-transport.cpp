#define main retained_compiled_piston_main
#include "CompiledPressureTests.cpp"
#undef main
#include "MaterialMoments.h"
#include "PhysicsWorld.h"
#include <memory>

struct RootFluid {
    double height=0;
    fluid_incoming::Moments moments;
};
using Moments=fluid_incoming::Moments;
double CoupledEnergy(const Model& model,double mass){double energy=.5*mass*glm::dot(model.bodies[0].velocity,model.bodies[0].velocity);for(const auto& point:model.points)energy+=.5*glm::dot(point.velocity,point.velocity)/point.inverseMass;return energy;}

fluid_material::Field ReconstructRoot(const RootFluid& root,unsigned x) {
    if(!(root.height>0)||!(root.moments.volume>0))throw std::runtime_error("empty trial root");
    const double mass=1000*root.moments.volume;
    const V center(x+.5,.5*root.height,.5);
    M covariance(0);covariance[0][0]=covariance[2][2]=1./12;covariance[1][1]=root.height*root.height/12;
    const M relative=root.moments.mixed-glm::outerProduct(center,root.moments.momentum);
    return {center,root.moments.momentum/mass,glm::transpose(relative/mass)*glm::inverse(covariance)};
}
std::array<fluid_exact::Plane,6> PistonPlanes(const BodyTransform& pose,V half) {
    std::array<fluid_exact::Plane,6> result;unsigned at=0;
    for(unsigned a=0;a<3;++a)for(double sign:{-1.,1.}){V n(0);n[a]=sign;n=glm::dquat(pose.rotation)*n;result[at++]={{n.x,n.y,n.z},glm::dot(n,V(pose.position))+half[a]};}
    return result;
}
Moments NegateMoment(Moments a){a.volume=-a.volume;a.energy=-a.energy;a.spatial=-a.spatial;a.momentum=-a.momentum;a.angular=-a.angular;a.mixed=-a.mixed;return a;}
int main(){
    unsigned failures=0,substeps=0;
    PhysicsWorld world;world.Init();const glm::vec3 half(.5f,.1f,.5f);
    auto body=world.CreateDynamicBox({.5f,.85f,.5f},half,80,0,0);
    JointSettings guide;guide.type=JointType::Slider;guide.bodyA=body;guide.anchorB={.5f,.85f,.5f};guide.frameA=guide.frameB=glm::angleAxis(glm::half_pi<float>(),glm::vec3(0,0,1));
    if(!world.CreateJoint(guide).IsValid())return 2;
    world.SetLinearVelocity(body,{0,-1,0});
    const double initialHeight=double(world.GetTransform(body).position.y)-half.y;
    std::array<RootFluid,2> state;for(unsigned i=0;i<2;++i){state[i].height=initialHeight;state[i].moments=fluid_material::Integrate(LiquidBox(V(i,0,0),V(i+1,initialHeight,1)),{},1000);}
    const double initialVolume=state[0].moments.volume+state[1].moments.volume;
    double maximumEnergy=40,maximumResidual=0,maximumGeometryDifference=0,maximumCapacityError=0,maximumFieldProjectionGain=0;
    bool healthy=true;std::string failure;std::unique_ptr<fluid_mesh::Compiler> mesh;std::unique_ptr<Model> pending;std::array<Moments,2> pressureMoments;std::array<M,2> pressureStress;
    const auto begin=std::chrono::steady_clock::now();
    auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(1,[&](const auto& phase){
        if(!healthy)return;
        try{
            const auto pose=world.GetTransform(body);const double height=double(pose.position.y)-half.y;
            if(std::abs(height-state[0].height)>1e-12)throw std::runtime_error("trial starts from inconsistent native geometry");
            std::vector<fluid_mesh::Compiler::WetCell> wet(8);wet[0]={{{{0,1,0},height}}};wet[1]={{{{0,1,0},state[1].height}}};
            mesh=std::make_unique<fluid_mesh::Compiler>();mesh->BuildRegions(2,PistonPlanes(pose,V(half)),wet);
            pending=std::make_unique<Model>();BuildCompiled(*pending,*mesh,false,V(half),glm::dquat(pose.rotation),V(pose.position),2,V(2,1,1));
            std::array<fluid_material::Field,2> fields{ReconstructRoot(state[0],0),ReconstructRoot(state[1],1)};
            for(unsigned i=0;i<pending->cells.size();++i){auto& cell=pending->cells[i];unsigned owner=mesh->tetrahedra[i].voxel;if(owner>1)throw std::runtime_error("unexpected wet root");const auto& field=fields[owner];pending->points[cell.first].velocity=field.value+field.gradient*(cell.center-field.origin);const M b=field.gradient*cell.factor;for(unsigned k=0;k<3;++k)pending->points[cell.first+1+k].velocity=b[k];}
            // Exact analytical condensation of THIS authored vertical slider:
            // its supported lateral/angular coordinates have zero mobility.
            // The ordinary MK2 slider still owns body orientation and motion.
            for(auto& row:pending->rows)for(auto& g:row.bodies){g.linear=V(0,g.linear.y,0);g.angular=V(0);}
            const V velocity(world.GetLinearVelocity(body));pending->bodies[0]={velocity,V(0),1./world.GetMass(body),M(0)};
            const double beforeEnergy=CoupledEnergy(*pending,world.GetMass(body));auto solved=ProjectFluidPressure(*pending,64,1e-10);
            if(!solved.converged)throw std::runtime_error("full3D pressure projection failed");
            maximumResidual=std::max(maximumResidual,solved.maximumResidual);
            if(CoupledEnergy(*pending,world.GetMass(body))>beforeEnergy+1e-7)throw std::runtime_error("pressure creates energy");
            world.ApplyLinearImpulse(body,glm::vec3((pending->bodies[0].velocity-velocity)*double(world.GetMass(body))));
            pressureMoments={};pressureStress={M(0),M(0)};
            for(unsigned i=0;i<pending->cells.size();++i){const auto& cell=pending->cells[i];M b;for(unsigned k=0;k<3;++k)b[k]=pending->points[cell.first+1+k].velocity;fluid_material::Field field{cell.center,pending->points[cell.first].velocity,b*cell.inverse};const unsigned owner=mesh->tetrahedra[i].voxel;pressureMoments[owner].Add(fluid_material::Integrate(LiquidGeometry{{mesh->tetrahedra[i].geometry}},field,1000));M tensor=glm::outerProduct(field.value,field.value);for(unsigned k=0;k<3;++k)tensor+=glm::outerProduct(b[k],b[k]);pressureStress[owner]+=cell.mass*tensor;}
            (void)phase;
        }catch(const std::exception& error){healthy=false;failure=error.what();}
    },[&](const auto& phase){
        if(!healthy)return;
        try{
            ++substeps;const double dt=phase.deltaTime;const double actualHeight=double(world.GetTransform(body).position.y)-half.y;
            const double displacement=state[0].height-actualHeight;
            // Exact integrated continuity for a full unit-area piston bay.
            // Native endpoint geometry supplies this value BEFORE publication.
            if(displacement<0)throw std::runtime_error("reverse flow not in initial piston trial");
            Moments transfer;double predictedVolume=0;
            std::map<std::array<unsigned,3>,std::vector<unsigned>> faces;constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
            for(unsigned i=0;i<mesh->tetrahedra.size();++i)for(const auto& f:tri){auto ids=mesh->tetrahedra[i].vertices;std::array<unsigned,3> key{ids[f[0]],ids[f[1]],ids[f[2]]};std::sort(key.begin(),key.end());faces[key].push_back(i);}
            for(const auto& [ids,owners]:faces){if(owners.size()!=2)continue;unsigned left=owners[0],right=owners[1];if(mesh->tetrahedra[left].voxel==mesh->tetrahedra[right].voxel)continue;if(mesh->tetrahedra[left].voxel!=0)std::swap(left,right);std::array<V,3> points,velocity;const auto& cell=pending->cells[left];for(unsigned k=0;k<3;++k){points[k]=mesh->vertices[ids[k]].position;const V phi=cell.inverse*(points[k]-cell.center);velocity[k]=pending->points[cell.first].velocity;for(unsigned j=0;j<3;++j)velocity[k]+=phi[j]*pending->points[cell.first+1+j].velocity;}auto flow=fluid_incoming::Integrate(points,velocity,V(1,0,0),dt,1000);transfer.Add(flow);const auto& other=pending->cells[right];for(unsigned k=0;k<3;++k){const V phi=other.inverse*(points[k]-other.center);velocity[k]=pending->points[other.first].velocity;for(unsigned j=0;j<3;++j)velocity[k]+=phi[j]*pending->points[other.first+1+j].velocity;}auto reverse=fluid_incoming::Integrate(points,velocity,V(-1,0,0),dt,1000);transfer.Add(NegateMoment(reverse));}
            predictedVolume=transfer.volume;maximumGeometryDifference=std::max(maximumGeometryDifference,std::abs(displacement-predictedVolume));
            if(!(transfer.volume>0)&&displacement>0)throw std::runtime_error("native displacement lacks supporting wet-face flow");
            // First diagnostic deliberately refuses inconsistent continuity;
            // do not rescale flux, clamp a quantity or alter the native pose.
            if(std::abs(displacement-transfer.volume)>1e-10){std::printf("PISTON_CONTINUITY step=%u actual=%.17g integrated=%.17g difference=%.17g\n",substeps,displacement,transfer.volume,displacement-transfer.volume);throw std::runtime_error("instantaneous pressure flux disagrees with actual native endpoint");}
            std::array<RootFluid,2> next;for(unsigned root=0;root<2;++root){next[root].moments=pressureMoments[root];next[root].moments.spatial+=dt*pressureMoments[root].momentum/1000.;next[root].moments.mixed+=dt*pressureStress[root];}
            next[0].moments.Add(NegateMoment(transfer));next[1].moments.Add(transfer);next[0].height=actualHeight;next[1].height=next[1].moments.volume;
            maximumCapacityError=std::max(maximumCapacityError,std::abs(next[0].moments.volume-actualHeight));
            if(std::abs(next[0].moments.volume-actualHeight)>1e-10)throw std::runtime_error("left quantity does not match actual endpoint capacity");
            double projectedEnergy=0;for(unsigned root=0;root<2;++root){auto field=ReconstructRoot(next[root],root);auto geometry=LiquidBox(V(root,0,0),V(root+1,next[root].height,1));auto represented=fluid_material::Integrate(geometry,field,1000);maximumFieldProjectionGain=std::max(maximumFieldProjectionGain,represented.energy-next[root].moments.energy);projectedEnergy+=represented.energy;next[root].moments=represented;}
            const double kinetic=.5*world.GetMass(body)*double(glm::dot(world.GetLinearVelocity(body),world.GetLinearVelocity(body)))+projectedEnergy;maximumEnergy=std::max(maximumEnergy,kinetic);if(kinetic>40+1e-6)throw std::runtime_error("native coupled pressure/transport creates energy");
            state=next;
        }catch(const std::exception& error){healthy=false;failure=error.what();}
    });
    for(unsigned tick=0;tick<12&&healthy;++tick)world.Step(1.f/60,&coupling);
    if(!healthy)++failures;
    std::printf("NATIVE_PISTON3D intervals=%u healthy=%d failures=%u initial_height=%.17g final_height=%.17g volume=%.17g initial_volume=%.17g max_energy=%g pressure_residual=%g flux_difference=%g capacity_error=%g field_projection_gain=%g ms=%.6f error=%s\n",substeps,healthy,failures,initialHeight,double(world.GetTransform(body).position.y)-half.y,state[0].moments.volume+state[1].moments.volume,initialVolume,maximumEnergy,maximumResidual,maximumGeometryDifference,maximumCapacityError,maximumFieldProjectionGain,std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count(),failure.c_str());
    return failures?1:0;
}
