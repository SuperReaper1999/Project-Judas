#include "VolumeDomain.h"
#include <cstdio>
using namespace fluid_domain;
int main(){unsigned checks=0,failures=0;auto check=[&](bool value,const char* text){++checks;if(!value){++failures;std::printf("FAIL %s\n",text);}};std::string error;VolumeDomain owner(1);
 const Key lower{0,0,0,0},upper{0,0,0,1},right{1,0,0,0};
 const auto bottom=LiquidBox({0,0,0},{1,.4,1}),top=LiquidBox({0,.6,0},{1,1,1}),cube=LiquidBox({0,0,0},{1,1,1});
 check(owner.Add(lower,bottom,.4,{0,1,0},error),"lower physical owner");check(owner.Add(upper,top,0,{0,1,0},error),"independent upper subcell survives in same voxel");check(owner.Size()==2,"subcell identities do not overwrite each other");
 check(!owner.Advance({{lower,upper,.1}},{},error),"same voxel does not create an aperture through intervening solid");check(owner.Find(lower)->volume==.4&&owner.Find(upper)->volume==0,"blocked transfer leaves owners intact");
 check(!owner.Add({0,0,0,2},cube,0,{0,1,0},error),"overlapping capacity cannot claim duplicate physical space");check(owner.Size()==2,"invalid owner does not publish");
 check(!owner.Advance({},{{upper,std::make_shared<const LiquidGeometry>(cube)}},error),"capacity change cannot silently overlap another owner");check(owner.Find(upper)->capacityGeometry->cells==top.cells,"failed capacity publication restores original geometry");
 check(owner.Add(right,cube,.8,{0,1,0},error),"real neighbouring donor");check(owner.Advance({{right,upper,.1}},{},error),"wet neighbour can feed upper through its actual side opening");check(owner.Find(upper)->volume==.1,"legal incoming quantity reaches independent upper owner");check(owner.Find(lower)->volume==.4,"upper transfer does not perturb unrelated lower owner");check(std::abs(owner.TotalVolume()-1.2)<1e-14,"legal transfers preserve total");
 std::printf("SUBCELL_OWNERSHIP checks=%u failures=%u\n",checks,failures);return failures?1:0;}
