#pragma once
#include "SparseInterior.h"
#include <queue>
namespace fluid_geometric {
struct Cell {double before=0,capacity=0;bool filled=false;};
struct Face {unsigned a=0,b=0;double predicted=0,inverseMetric=0;};
struct Result {bool accepted=false;std::vector<double> displacement,quantity;std::string error;};
// Minimum-change INTEGRATED volume flux under active geometric continuity.
// Equality gauges are removed by graph conservation, not diagonal regularization.
// Free-cell bounds are verified before publication; an infeasible candidate is
// rejected, never clipped. The caller supplies actual resolved capacities.
inline Result Project(const std::vector<Cell>& cells,const std::vector<Face>& faces){
 Result result;try{
  std::vector<pressure_prototype::Point> values;std::vector<std::vector<unsigned>> graph(cells.size());
  for(const auto& face:faces){if(face.a>=cells.size()||face.b>=cells.size()||face.a==face.b||!(face.inverseMetric>0)||!std::isfinite(face.inverseMetric)||!std::isfinite(face.predicted))throw std::invalid_argument("invalid geometric face");graph[face.a].push_back(face.b);graph[face.b].push_back(face.a);values.push_back({{face.predicted,0,0},face.inverseMetric});}
  std::vector<bool> omitted(cells.size()),seen(cells.size());const double scale=[&]{double sum=0;for(const auto& c:cells){if(!(c.before>=0)||!(c.capacity>=0)||!std::isfinite(c.before+c.capacity))throw std::invalid_argument("invalid geometric cell");sum+=c.before;}return sum;}();const double tolerance=32*std::numeric_limits<double>::epsilon()*std::max(scale,std::numeric_limits<double>::min());
  for(unsigned seed=0;seed<cells.size();++seed)if(!seen[seed]){std::queue<unsigned> queue;queue.push(seed);seen[seed]=true;bool closed=true;double change=0;while(!queue.empty()){unsigned a=queue.front();queue.pop();closed&=cells[a].filled;change+=cells[a].capacity-cells[a].before;for(unsigned b:graph[a])if(!seen[b]){seen[b]=true;queue.push(b);}}if(closed){if(std::abs(change)>tolerance)throw std::runtime_error("closed wet component has incompatible capacity change");omitted[seed]=true;}}
  std::vector<pressure_prototype::Row> rows;std::vector<bool> bilateral;
  for(unsigned i=0;i<cells.size();++i)if(cells[i].filled&&!omitted[i]){pressure_prototype::Row row;row.maximumRate=cells[i].capacity-cells[i].before;for(unsigned f=0;f<faces.size();++f){if(faces[f].a==i)row.points.push_back({f,{-1,0,0}});if(faces[f].b==i)row.points.push_back({f,{1,0,0}});}if(row.points.empty())throw std::runtime_error("active geometric cell has no transfer path");rows.push_back(std::move(row));bilateral.push_back(true);}
  if(!rows.empty()){std::vector<pressure_prototype::Body> bodies;auto solve=SparseInterior(values,bodies,rows,bilateral,64,tolerance);if(!solve.converged)throw std::runtime_error("integrated geometric continuity solve failed");}
  std::vector<double> quantity;for(const auto& c:cells)quantity.push_back(c.before);for(unsigned f=0;f<faces.size();++f){const double q=values[f].velocity.x;quantity[faces[f].a]-=q;quantity[faces[f].b]+=q;}
  for(unsigned i=0;i<cells.size();++i){if(quantity[i]<0||quantity[i]>cells[i].capacity+tolerance)throw std::runtime_error("integrated face flux exceeds a physical quantity/capacity bound");if(cells[i].filled&&std::abs(quantity[i]-cells[i].capacity)>tolerance)throw std::runtime_error("active geometric continuity residual exceeds tolerance");}
  for(const auto& v:values)result.displacement.push_back(v.velocity.x);result.quantity=std::move(quantity);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
}
