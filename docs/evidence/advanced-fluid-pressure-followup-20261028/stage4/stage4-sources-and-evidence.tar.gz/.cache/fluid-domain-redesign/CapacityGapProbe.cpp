#include "VolumeDomain.h"
#include <cstdio>
int main(){unsigned failures=0;for(double gap:{1e-10,1e-14}){auto left=LiquidBox({0,0,0},{.5-.5*gap,1,1});auto right=LiquidBox({.5+.5*gap,0,0},{1,1,1});left.cells.insert(left.cells.end(),right.cells.begin(),right.cells.end());fluid_domain::VolumeDomain domain(1);std::string error;bool accepted=domain.Add({0,0,0},left,.25,{0,1,0},error);std::printf("CAPACITY_GAP gap=%.17g accepted=%d size=%zu diagnostic=%s\n",gap,accepted,domain.Size(),error.c_str());if(accepted)++failures;}std::printf("CAPACITY_GAP failures=%u\n",failures);return failures?1:0;}
