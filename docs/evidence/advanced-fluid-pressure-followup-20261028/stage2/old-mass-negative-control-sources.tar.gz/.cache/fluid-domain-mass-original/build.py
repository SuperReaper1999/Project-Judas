from pathlib import Path
import sys
root=Path.cwd();out=root/'.cache/fluid-domain-mass-original'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as p
impl=p.compile(root/'.cache/fluid-domain-redesign/VolumeDomain.cpp','volume-domain')
main=p.compile(out/'MassScaleReproducer.cpp','original-mass-scale-reproducer');p.executable(main,'original-mass-scale-reproducer',impl)
