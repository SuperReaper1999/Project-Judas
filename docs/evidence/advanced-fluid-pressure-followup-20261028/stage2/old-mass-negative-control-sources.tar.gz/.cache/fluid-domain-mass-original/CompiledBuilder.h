#include "AffineModel.h"
#include "SparseInterior.h"
#include "ConformingCutMesh.h"
#include <cstdio>
struct CompiledFace{unsigned cell;std::array<unsigned,3> ids;std::array<V,3> points;V normal;};
void BuildCompiled(Model& m,fluid_mesh::Compiler& compiler,bool fixed,V half=V(.2),glm::dquat rotation={1,0,0,0},V center=V(.5),double domainSize=1){
 m.center=center;m.half=half;m.bodyVolume=8*half.x*half.y*half.z;m.bodyMass=1000*m.bodyVolume;
 M inverse(0);if(!fixed){for(unsigned axis=0;axis<3;++axis){unsigned b=(axis+1)%3,c=(axis+2)%3;inverse[axis][axis]=3/(m.bodyMass*(half[b]*half[b]+half[c]*half[c]));}M frame=glm::mat3_cast(rotation);inverse=frame*inverse*glm::transpose(frame);}m.bodies.push_back({V(0),V(0),fixed?0:1/m.bodyMass,inverse});std::map<std::array<unsigned,3>,std::vector<CompiledFace>> faces;constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
 for(const auto& source:compiler.tetrahedra){const auto& t=source.geometry;double volume=Volume(t);V centroid=(t[0]+t[1]+t[2]+t[3])*.25;M covariance(0);V sum(0);for(auto p:t){V r=p-centroid;sum+=r;covariance+=glm::outerProduct(r,r);}covariance=(covariance+glm::outerProduct(sum,sum))/20.;M factor(0);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double value=covariance[j][i];for(unsigned k=0;k<j;++k)value-=factor[k][i]*factor[k][j];if(i==j){if(!(value>0))throw std::runtime_error("nonpositive compiled cell covariance");factor[j][i]=std::sqrt(value);}else factor[j][i]=value/factor[j][j];}
  const unsigned ci=m.cells.size();FluidCell cell{{int(ci),0,0},centroid,factor,glm::inverse(factor),1000*volume,unsigned(m.points.size()),{}};for(auto p:t)cell.samples.push_back(p);for(unsigned k=0;k<4;++k)m.points.push_back({V(0),1/cell.mass});m.cells.push_back(cell);Row trace;for(unsigned k=0;k<3;++k)trace.points.push_back({cell.first+1+k,V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k])*volume});m.traceRows.push_back(m.rows.size());m.Add(trace,true);
  for(auto& indices:tri){std::array<unsigned,3> ids{source.vertices[indices[0]],source.vertices[indices[1]],source.vertices[indices[2]]};std::array<V,3> points{t[indices[0]],t[indices[1]],t[indices[2]]};V n=glm::normalize(glm::cross(points[1]-points[0],points[2]-points[0]));if(glm::dot(n,centroid-points[0])>0)n=-n;auto key=ids;std::sort(key.begin(),key.end());faces[key].push_back({ci,ids,points,n});}
 }
 for(const auto& [key,owners]:faces){if(owners.size()>2)throw std::runtime_error("nonmanifold pressure assembly");const auto& first=owners[0];bool body=false,free=false;if(owners.size()==1){bool wall=false;for(unsigned axis=0;axis<3;++axis)for(double coordinate:{0.,domainSize}){if(axis==1&&coordinate==domainSize)continue;fluid_exact::Plane boundary{{0,0,0},coordinate};boundary.normal[axis]=1;bool on=true;for(unsigned v:key)on&=compiler.vertices[v].exact.Side(boundary)==0;wall|=on;}free=!wall;bool inside=true;for(unsigned plane:compiler.bodyPlanes)for(unsigned v:key)inside&=compiler.Side(v,plane)<=0;for(unsigned plane:compiler.bodyPlanes){bool on=true;for(unsigned v:key)on&=compiler.Side(v,plane)==0;body|=on&&inside;}}
  if(free&&!body)continue;
  for(auto p:first.points){Row row;m.Evaluation(row,m.cells[first.cell],p,first.normal);if(owners.size()==2)m.Evaluation(row,m.cells[owners[1].cell],p,first.normal,-1);else if(body)row.bodies.push_back({0,-first.normal,-glm::cross(p-m.center,first.normal)});m.Add(row,owners.size()==2);}
 }
 m.CondenseDivergence();
}
