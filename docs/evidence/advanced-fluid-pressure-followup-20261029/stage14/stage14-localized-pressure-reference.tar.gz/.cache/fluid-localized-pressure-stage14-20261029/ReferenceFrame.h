#pragma once
#include "LocalField.h"
namespace localized_pressure {
inline Eigen::Matrix<Real,6,1> TwistAtOrigin(V center,V linear,V angular){Eigen::Matrix<Real,6,1> result;const V atOrigin=linear-glm::cross(angular,center);for(unsigned a=0;a<3;++a){result[a]=atOrigin[a];result[3+a]=angular[a];}return result;}
inline V TorqueAtCenter(V center,const Eigen::Matrix<Real,6,1>& wrench){return V(wrench[3],wrench[4],wrench[5])-glm::cross(center,V(wrench[0],wrench[1],wrench[2]));}
}
