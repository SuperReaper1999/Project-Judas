from pathlib import Path
import json,time,subprocess
folder=Path('.cache/fluid-localized-pressure-stage14-20261029');out=folder/'final-qualification'
runs=json.loads((out/'RUNS.json').read_text())
for name in ['OraclePrecisionTests','WarmBenchmark']:
 if (out/(name+'.log')).exists():raise RuntimeError('Refusing to overwrite final receipt')
 command=['python3',str(folder/'run_probe.py'),name];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'returnCode':r.returncode,'seconds':time.monotonic()-start};runs.append(row);(out/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
