#pragma once
#include "FastPressureEpoch.h"
#include "../fluid-refined-reconstruction-stage12-20261029/HighPrecisionOracle.h"
namespace localized_pressure {
template<class N>std::vector<N> DenseSolve(std::vector<N> matrix,std::vector<N> rhs,unsigned n,unsigned loads){
 if(!n)return rhs;const auto original=matrix,source=rhs;
 for(unsigned k=0;k<n;++k){unsigned p=k;for(unsigned r=k+1;r<n;++r)if(abs(matrix[size_t(r)*n+k])>abs(matrix[size_t(p)*n+k]))p=r;if(matrix[size_t(p)*n+k]==0)throw std::runtime_error("independent projected oracle has zero pivot");
  if(p!=k){for(unsigned c=0;c<n;++c)std::swap(matrix[size_t(p)*n+c],matrix[size_t(k)*n+c]);for(unsigned a=0;a<loads;++a)std::swap(rhs[size_t(p)*loads+a],rhs[size_t(k)*loads+a]);}
  for(unsigned r=k+1;r<n;++r){const N factor=matrix[size_t(r)*n+k]/matrix[size_t(k)*n+k];matrix[size_t(r)*n+k]=0;for(unsigned c=k+1;c<n;++c)matrix[size_t(r)*n+c]-=factor*matrix[size_t(k)*n+c];for(unsigned a=0;a<loads;++a)rhs[size_t(r)*loads+a]-=factor*rhs[size_t(k)*loads+a];}}
 std::vector<N> result(size_t(n)*loads);for(int r=int(n)-1;r>=0;--r)for(unsigned a=0;a<loads;++a){N v=rhs[size_t(r)*loads+a];for(unsigned c=r+1;c<n;++c)v-=matrix[size_t(r)*n+c]*result[size_t(c)*loads+a];result[size_t(r)*loads+a]=v/matrix[size_t(r)*n+r];}
 N residual=0,scale=1;for(unsigned r=0;r<n;++r)for(unsigned a=0;a<loads;++a){N value=-source[size_t(r)*loads+a];for(unsigned c=0;c<n;++c)value+=original[size_t(r)*n+c]*result[size_t(c)*loads+a];residual=std::max(residual,N(abs(value)));scale=std::max(scale,N(abs(source[size_t(r)*loads+a])));}
 if(residual/scale>N("1e-28"))throw std::runtime_error("independent projected oracle residual exceeds declared precision");return result;
}
template<unsigned Bits>struct ProjectedResult {std::vector<Number<Bits>> flux;std::array<Number<Bits>,6> reaction{};Number<Bits> energy=0;};
// Eliminate local kinetic coordinates at high precision BEFORE assembling the
// global saddle system. Unlike the coarse oracle, this does not use runtime Q/K.
template<unsigned Bits,class Velocity>ProjectedResult<Bits> ProjectedGold(const Epoch& epoch,Velocity velocity,const Eigen::Matrix<Real,6,1>& body){
 using N=Number<Bits>;struct Work{unsigned nr,nf,nc;std::vector<N> J,Y,B,b,r,C,Z;};std::vector<Work> work;const unsigned nc=epoch.coarse.variables;std::vector<N> H(size_t(nc)*nc),target(nc);
 for(unsigned m=0;m<epoch.factors.size();++m){const auto& f=*epoch.factors[m];Work w;w.nr=f.J.rows();w.nf=f.J.cols();w.nc=f.Y.cols();const unsigned loads=w.nc+1;w.J.resize(size_t(w.nr)*w.nf);w.Y.resize(size_t(w.nr)*w.nc);w.B.resize(size_t(w.nr)*6);w.b.resize(w.nr);w.r.resize(w.nr);w.C.resize(size_t(w.nf)*loads);std::vector<N> gram(size_t(w.nf)*w.nf);const auto source=f.sampler->Sample(velocity);
  for(unsigned row=0;row<w.nr;++row){w.b[row]=N(source[row]);w.r[row]=w.b[row];std::vector<std::pair<unsigned,N>> active;
   for(unsigned c=0;c<w.nf;++c){const N value(f.J(row,c));w.J[size_t(row)*w.nf+c]=value;if(value!=0)active.emplace_back(c,value);}
   for(unsigned c=0;c<w.nc;++c)w.Y[size_t(row)*w.nc+c]=N(f.Y(row,c));for(unsigned a=0;a<6;++a){w.B[size_t(row)*6+a]=N(f.Ybody(row,a));w.r[row]-=w.B[size_t(row)*6+a]*N(body[a]);}
   for(const auto& [i,a]:active){for(const auto& [j,b]:active)gram[size_t(i)*w.nf+j]+=a*b;for(unsigned c=0;c<w.nc;++c)w.C[size_t(i)*loads+c]+=a*w.Y[size_t(row)*w.nc+c];w.C[size_t(i)*loads+w.nc]+=a*w.r[row];}}
  w.Z=DenseSolve(std::move(gram),w.C,w.nf,loads);std::vector<N> h(size_t(w.nc)*w.nc),rhs(w.nc);
  for(unsigned row=0;row<w.nr;++row)for(unsigned i=0;i<w.nc;++i){const N a=w.Y[size_t(row)*w.nc+i];rhs[i]+=a*w.r[row];for(unsigned j=0;j<w.nc;++j)h[size_t(i)*w.nc+j]+=a*w.Y[size_t(row)*w.nc+j];}
  for(unsigned i=0;i<w.nc;++i){for(unsigned k=0;k<w.nf;++k)rhs[i]-=w.C[size_t(k)*loads+i]*w.Z[size_t(k)*loads+w.nc];target[epoch.columns[m][i]]+=rhs[i];for(unsigned j=0;j<w.nc;++j){for(unsigned k=0;k<w.nf;++k)h[size_t(i)*w.nc+j]-=w.C[size_t(k)*loads+i]*w.Z[size_t(k)*loads+j];H[size_t(epoch.columns[m][i])*nc+epoch.columns[m][j]]+=h[size_t(i)*w.nc+j];}}
  work.push_back(std::move(w));
 }
 Eigen::FullPivLU<Dense> rank(epoch.coarse.divergence);const unsigned np=rank.rank();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverse=rank.permutationP().inverse();const auto rows=inverse.indices();const unsigned n=nc+np;std::vector<N> saddle(size_t(n)*n),rhs(n);
 for(unsigned i=0;i<nc;++i){rhs[i]=target[i];for(unsigned j=0;j<nc;++j)saddle[size_t(i)*n+j]=H[size_t(i)*nc+j];}
 for(unsigned p=0;p<np;++p){for(unsigned c=0;c<nc;++c)saddle[size_t(c)*n+nc+p]=saddle[size_t(nc+p)*n+c]=N(epoch.coarse.divergence(rows[p],c));for(unsigned a=0;a<6;++a)rhs[nc+p]-=N(epoch.coarse.bodyDivergence(rows[p],a))*N(body[a]);}
 const auto solution=DenseSolve(std::move(saddle),std::move(rhs),n,1);ProjectedResult<Bits> result;result.flux.assign(solution.begin(),solution.begin()+nc);std::vector<N> pressure(epoch.coarse.divergence.rows());for(unsigned p=0;p<np;++p)pressure[rows[p]]=solution[nc+p];
 for(unsigned m=0;m<work.size();++m){const auto& w=work[m];const unsigned loads=w.nc+1;std::vector<N> local(w.nf);
  for(unsigned k=0;k<w.nf;++k){local[k]=w.Z[size_t(k)*loads+w.nc];for(unsigned c=0;c<w.nc;++c)local[k]-=w.Z[size_t(k)*loads+c]*solution[epoch.columns[m][c]];}
  for(unsigned r=0;r<w.nr;++r){N residual=w.r[r];for(unsigned c=0;c<w.nc;++c)residual-=w.Y[size_t(r)*w.nc+c]*solution[epoch.columns[m][c]];for(unsigned k=0;k<w.nf;++k)residual-=w.J[size_t(r)*w.nf+k]*local[k];const N actual=w.b[r]-residual;result.energy+=actual*actual/2;for(unsigned a=0;a<6;++a)result.reaction[a]+=w.B[size_t(r)*6+a]*residual;}
  const auto& f=*epoch.factors[m];for(unsigned r=0;r<f.remainingRows.size();++r)for(unsigned a=0;a<6;++a)result.reaction[a]-=N(f.Gbody(r,a))*pressure[epoch.pressureOffset[m]+r];
 }
 return result;
}
}
