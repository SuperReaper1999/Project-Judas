#include "PressureEpoch.h"
#include <cstdio>
using namespace localized_pressure;
int main(){std::setvbuf(stdout,nullptr,_IOLBF,0);try{Epoch epoch(2,owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(.17,glm::normalize(V(1,2,-.3)))));for(unsigned trial=0;trial<3;++trial){const auto result=epoch.Solve([&](V p){if(trial==2)return V(0);return V(.03*std::sin(5*p.y),-.04+.01*std::cos(3*p.z),.02*std::sin(4*p.x));});std::printf("SOLVE trial=%u variables=%u energy=%g balance=%g reaction_error=%g ms=%g\n",trial,epoch.coarse.variables,result.fullEnergy,result.balance,result.reactionError,result.solveMs);}return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
