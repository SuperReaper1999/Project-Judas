#pragma once
#include "SparsePressureEpoch.h"
namespace localized_pressure {
// Scope guard, not a public API. Shared affine face ownership is currently
// qualified for ONE connected fluid component per background seed only.
class QualifiedEpoch {
 std::shared_ptr<const Epoch> current;
 static void VerifyOwners(const Epoch& candidate){for(const auto& f:candidate.factors)if(f->raw.macros>1)throw std::runtime_error("disconnected fluid components inside a background seed require separate trace ownership");}
public:
 QualifiedEpoch(unsigned grid,const mg::Box& box){auto staged=std::make_shared<Epoch>(grid,box);VerifyOwners(*staged);current=std::move(staged);}
 const Epoch& Inspect()const{return *current;}
 unsigned Update(const mg::Box& box){if(mg::Equal(current->box,box))return 0;auto staged=std::make_shared<Epoch>(*current);const unsigned rebuilt=staged->Update(box);VerifyOwners(*staged);current=std::move(staged);return rebuilt;}
 template<class Velocity>SolveResult Solve(Velocity velocity,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero())const{return current->Solve(velocity,body);}
};
}
