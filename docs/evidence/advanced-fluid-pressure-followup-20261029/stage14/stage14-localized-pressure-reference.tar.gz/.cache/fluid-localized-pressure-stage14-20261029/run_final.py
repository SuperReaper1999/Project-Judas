from pathlib import Path
import json,subprocess,time
folder=Path('.cache/fluid-localized-pressure-stage14-20261029');output=folder/'final-qualification';output.mkdir(exist_ok=False);runs=[]
for name in ['PressureTests','ThinAccuracyTests','ProjectedOracleTests','DisconnectedControlTests','CacheTests']:
 command=['python3',str(folder/'run_probe.py'),name];start=time.monotonic()
 with (output/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'returnCode':r.returncode,'seconds':time.monotonic()-start};runs.append(row);(output/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
