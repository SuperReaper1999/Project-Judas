#pragma once
#include "SparseLocalFactor.h"
#include <cfenv>
#include "../fluid-compatible-flux-stage9-20261029/PreparedConservative.h"
namespace localized_pressure {
struct SolveResult {ConservativeResult coarse;Vector coarseSource;std::vector<Vector> localScaled;double fullEnergy=0,balance=0,reactionError=0,solveMs=0;Eigen::Matrix<Real,6,1> fullReaction=Eigen::Matrix<Real,6,1>::Zero();};
struct Epoch {
 double geometryMs=0,localFieldMs=0,localReductionMs=0,localQrMs=0,sourceCacheMs=0,matrixMs=0,globalQrMs=0;
 unsigned grid;mg::Box box;mg::Bounds bounds;
 std::vector<std::shared_ptr<const mg::Slice>> geometry;
 std::vector<std::shared_ptr<const Factor>> factors;
 std::map<Key,unsigned> keys;
 std::vector<std::vector<unsigned>> columns;
 std::vector<unsigned> rowOffset,pressureOffset;
 System coarse;
 std::shared_ptr<const PreparedConservativeSolver> prepared;
 static std::shared_ptr<const mg::Slice> Geometry(unsigned grid,unsigned seed,const mg::Box& box,const mg::Bounds& bounds){auto slice=std::make_shared<mg::Slice>();if(mg::OverlapSeed(grid,seed,bounds))slice->mesh.BuildSelected(grid,box,{seed});else slice->mesh.BuildLocalizedSelected(grid,box,{seed});slice->moments=mg::Integrate(slice->mesh);return slice;}
 Epoch(unsigned count,const mg::Box& planes):grid(count),box(planes),bounds(mg::BoundBox(planes)){
  if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("localized pressure requires round-to-nearest");
  if(!grid||grid>4)throw std::invalid_argument("bounded localized pressure grid");
  for(unsigned seed=0;seed<6*grid*grid*grid;++seed){geometry.push_back(Geometry(grid,seed,box,bounds));factors.push_back(std::make_shared<Factor>(*geometry.back(),grid));}Assemble();
 }
 void Assemble(){
  const auto begin=std::chrono::steady_clock::now();keys.clear();columns.clear();rowOffset.clear();pressureOffset.clear();unsigned nr=0,np=0;
  for(const auto& f:factors)for(const auto& key:f->keys)keys.emplace(key,0);unsigned id=0;for(auto& entry:keys)entry.second=id++;
  const unsigned nc=3*keys.size();for(const auto& f:factors){rowOffset.push_back(nr);pressureOffset.push_back(np);nr+=f->tail;np+=f->remainingRows.size();std::vector<unsigned> cols;for(const auto& key:f->keys)for(unsigned a=0;a<3;++a)cols.push_back(3*keys.at(key)+a);columns.push_back(std::move(cols));}
  if(nc==0||nr==0)throw std::runtime_error("fully displaced fluid domain is outside pressure prototype scope");
  coarse=System{};coarse.variables=nc;coarse.body=Dense::Zero(nr,6);coarse.bodyDivergence=Dense::Zero(np,6);coarse.divergence=Dense::Zero(np,nc);coarse.predictor=Vector::Zero(nr);coarse.columnScale=Vector::Ones(nc);std::vector<Eigen::Triplet<Real>> entries;
  for(unsigned owner=0;owner<factors.size();++owner){const auto& f=*factors[owner];const auto& cols=columns[owner];for(unsigned c=0;c<cols.size();++c){for(int r=0;r<f.K.rows();++r)if(f.K(r,c)!=0)entries.emplace_back(rowOffset[owner]+r,cols[c],f.K(r,c));for(int r=0;r<f.G.rows();++r)coarse.divergence(pressureOffset[owner]+r,cols[c])+=f.G(r,c);}
   coarse.body.middleRows(rowOffset[owner],f.tail)=f.Kbody;coarse.bodyDivergence.middleRows(pressureOffset[owner],f.remainingRows.size())=f.Gbody;
  }
  coarse.fluid.resize(nr,nc);coarse.fluid.setFromTriplets(entries.begin(),entries.end());coarse.fluid.makeCompressed();const auto factorStart=std::chrono::steady_clock::now();matrixMs=std::chrono::duration<double,std::milli>(factorStart-begin).count();prepared=std::make_shared<PreparedConservativeSolver>(coarse);globalQrMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-factorStart).count();
 }
 unsigned Update(const mg::Box& next){if(mg::Equal(box,next))return 0;if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("localized pressure requires round-to-nearest");const auto nextBounds=mg::BoundBox(next);Epoch staged=*this;staged.geometryMs=staged.localFieldMs=staged.localReductionMs=staged.localQrMs=staged.sourceCacheMs=0;unsigned count=0;
  for(unsigned i=0;i<factors.size();++i)if(mg::OverlapSeed(grid,i,bounds)||mg::OverlapSeed(grid,i,nextBounds)){const auto geomStart=std::chrono::steady_clock::now();staged.geometry[i]=Geometry(grid,i,next,nextBounds);staged.geometryMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-geomStart).count();staged.factors[i]=std::make_shared<Factor>(*staged.geometry[i],grid);const auto& f=*staged.factors[i];staged.localFieldMs+=f.raw.assemblyMs;staged.localReductionMs+=f.reductionMs;staged.localQrMs+=f.qrMs;staged.sourceCacheMs+=f.sourceCacheMs;++count;}
  staged.box=next;staged.bounds=nextBounds;staged.Assemble();*this=std::move(staged);return count;
 }
 template<class Velocity>SolveResult Solve(Velocity velocity,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero())const{
  if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("localized pressure requires round-to-nearest");const auto start=std::chrono::steady_clock::now();SolveResult result;Vector source=Vector::Zero(coarse.fluid.rows());std::vector<Vector> localSources,freeSources;double retained=0;
  for(unsigned m=0;m<factors.size();++m){const auto& f=*factors[m];Vector b=f.sampler->Sample(velocity);const Real kinetic=b.squaredNorm();if(!std::isfinite(kinetic)||kinetic>std::numeric_limits<double>::max())throw std::invalid_argument("unrepresentable sampled kinetic energy");Vector rotated=b;if(f.qr)rotated=f.qr->matrixQ().adjoint()*b;source.segment(rowOffset[m],f.tail)=rotated.tail(f.tail);retained+=.5*rotated.head(f.free.size()).squaredNorm();Vector freeSource(f.free.size());if(f.qr){const Vector ordered=f.triangle.triangularView<Eigen::Upper>().solve(rotated.head(f.free.size()));freeSource=f.qr->colsPermutation()*ordered;}freeSources.push_back(std::move(freeSource));localSources.push_back(std::move(b));}
  if(!source.allFinite()||!std::isfinite(retained))throw std::invalid_argument("unrepresentable condensed kinetic source");result.coarseSource=source;result.coarse=prepared->Solve(source,body);if(!std::isfinite(result.coarse.energyBefore)||!std::isfinite(result.coarse.energyAfter))throw std::runtime_error("nonfinite coarse kinetic state");if(!result.coarse.accepted)throw std::runtime_error(result.coarse.error);
  for(unsigned m=0;m<factors.size();++m){const auto& f=*factors[m];if(f.raw.cells.empty()){result.localScaled.push_back(Vector(0));continue;}Vector q(columns[m].size());for(unsigned c=0;c<columns[m].size();++c)q[c]=result.coarse.flux[columns[m][c]];const Vector rhs=localSources[m]-f.Y*q-f.Ybody*body;Vector initial=freeSources[m]-f.freeTrace*q-f.freeBody*body;const Vector free=f.Refine(rhs,std::move(initial));const Vector dependent=-f.Cfree*free-f.Ctrace*q-f.Cbody*body;Vector z=f.trace*q;
   for(unsigned j=0;j<f.pivots.size();++j)z[f.inside[f.pivots[j]]]=dependent[j];for(unsigned j=0;j<f.free.size();++j)z[f.inside[f.free[j]]]=free[j];
   const Vector actual=f.raw.fluid*z+f.raw.body*body,residual=localSources[m]-actual,gradient=f.raw.fluid.transpose()*residual;Vector p=Vector::Zero(f.raw.divergence.rows());for(unsigned j=0;j<f.remainingRows.size();++j)p[f.remainingRows[j]]=result.coarse.pressure[pressureOffset[m]+j];Vector g(f.rank);for(unsigned j=0;j<f.rank;++j)g[j]=gradient[f.inside[f.pivots[j]]];for(unsigned j=0;j<f.remainingRows.size();++j)g-=f.remainingPivot.row(j).transpose()*p[f.remainingRows[j]];
   if(f.rank){const Vector pressure=f.pivot.transpose().fullPivLu().solve(g);for(unsigned j=0;j<f.rank;++j)p[f.pressureRows[j]]=pressure[j];}
   result.fullReaction+=f.raw.body.transpose()*residual-f.raw.bodyDivergence.transpose()*p;result.fullEnergy+=.5*actual.squaredNorm();result.balance=std::max(result.balance,double((f.raw.divergence*z+f.raw.bodyDivergence*body).lpNorm<Eigen::Infinity>()));result.localScaled.push_back(std::move(z));
  }
  result.reactionError=(result.fullReaction-result.coarse.reaction).norm();if(!std::isfinite(result.fullEnergy)||!std::isfinite(result.balance)||!std::isfinite(result.reactionError)||!result.fullReaction.allFinite())throw std::runtime_error("nonfinite reconstructed physical state");if(result.balance>1e-10||result.reactionError>1e-8||std::abs(result.fullEnergy-result.coarse.energyAfter-retained)>1e-9)throw std::runtime_error("localized pressure reconstruction violates physical work/balance");result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
 }
};
}
