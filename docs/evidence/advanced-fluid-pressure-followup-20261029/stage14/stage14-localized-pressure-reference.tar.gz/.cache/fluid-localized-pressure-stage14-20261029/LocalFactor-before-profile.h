#pragma once
#include "LocalField.h"
#include "../fluid-local-oracle-stage11-20261029/CompensatedGradient.h"
#include "../fluid-compatible-flux-stage9-20261029/ConservativeElimination.h"
#include "../fluid-runtime-viability-stage10-20261029/PredictorSampler.h"
namespace localized_pressure {
namespace mg=moving_geometry;
using Key=mg::FaceKey; // Declared by MortarGeometry, included by entry point.
inline owned_cut::Snapshot Snapshot(const mg::Slice& slice){
 owned_cut::Snapshot out;const auto& a=slice.mesh;auto& b=out.mesh;b.planes=a.planes;b.bodyPlanes=a.bodyPlanes;b.backgroundFaces=a.backgroundFaces;
 for(const auto& v:a.vertices)b.vertices.push_back({v.exact,v.planes,v.position});
 for(const auto& t:a.tetrahedra)b.tetrahedra.push_back({t.geometry,t.vertices,t.voxel,t.seed});
 // A FIXED wrench/twist reference avoids invalidating distant body-lift blocks.
 // Native COM twists/wrenches must be converted explicitly at integration.
 out.solidCenter=V(0);return out;
}
struct Factor {
 System raw;
 std::shared_ptr<const PredictorSampler> sampler;
 std::vector<Key> keys;
 std::vector<unsigned> inside,pivots,free,pressureRows,remainingRows;
 Dense trace,Ai,Di,Dc,Ap,Cfree,Ctrace,Cbody,pivot,remainingPivot,J,Y,Ybody,K,Kbody,G,Gbody,triangle;
 std::shared_ptr<Eigen::ColPivHouseholderQR<Dense>> qr;
 std::shared_ptr<PreparedCompensatedGradient> gradient;
 unsigned rank=0,tail=0;
 explicit Factor(const mg::Slice& slice,unsigned grid):raw(BuildLocal(Snapshot(slice),V(0),grid)){
  sampler=std::make_shared<PredictorSampler>(raw);
  if(raw.cells.empty()){K=Dense::Zero(0,0);Kbody=Dense::Zero(0,6);G=Dense::Zero(0,0);Gbody=Dense::Zero(0,6);return;}
  std::map<Key,unsigned> keyMap;std::map<unsigned,Key> boundary;
  for(unsigned f=0;f<raw.faces.size();++f){const auto& face=raw.faces[f];if(face.variable==unsigned(-1))continue;
   if(face.owners.size()==2){for(unsigned c=0;c<3;++c)inside.push_back(face.variable+c);continue;}
   bool found=false;for(const auto& [key,plane]:raw.geometry.mesh.backgroundFaces){bool on=true;for(unsigned v:face.vertices)on&=raw.geometry.mesh.Side(v,plane)==0;if(on){if(found)throw std::runtime_error("ambiguous background trace");boundary[f]=key;found=true;keyMap.emplace(key,0);}}
   if(!found)throw std::runtime_error("unowned local boundary cannot be treated as a wall");
  }
  for(auto& [key,index]:keyMap){index=keys.size();keys.push_back(key);}
  const unsigned nr=raw.fluid.rows(),ni=inside.size(),nc=3*keys.size();trace=Dense::Zero(raw.variables,nc);
  for(const auto& [f,key]:boundary){const auto& face=raw.faces[f];unsigned axis=0;for(unsigned j=1;j<3;++j)if(abs(face.areaNormal[j])>abs(face.areaNormal[axis]))axis=j;const unsigned u=(axis+1)%3,v=(axis+2)%3;const Real area=ToDouble(face.areaNormal[axis]);const unsigned col=3*keyMap.at(key);
   for(unsigned j=0;j<3;++j){const auto& p=raw.positions[face.vertices[j]];trace(face.variable+j,col)=area/raw.columnScale[face.variable+j];trace(face.variable+j,col+1)=ToDouble(face.areaNormal[axis]*p[u])/raw.columnScale[face.variable+j];trace(face.variable+j,col+2)=ToDouble(face.areaNormal[axis]*p[v])/raw.columnScale[face.variable+j];}}
  Ai.resize(nr,ni);Di.resize(raw.divergence.rows(),ni);for(unsigned j=0;j<ni;++j){Ai.col(j)=raw.fluid.col(inside[j]);Di.col(j)=raw.divergence.col(inside[j]);}
  Dc=raw.divergence*trace;const Dense Ac=raw.fluid*trace;
  std::vector<unsigned> cols(ni),rowOrder(Di.rows());std::iota(cols.begin(),cols.end(),0);std::iota(rowOrder.begin(),rowOrder.end(),0);
  if(ni){Eigen::FullPivLU<Dense> elimination(Di);rank=elimination.rank();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverse=elimination.permutationP().inverse();for(unsigned j=0;j<ni;++j)cols[j]=elimination.permutationQ().indices()[j];for(int j=0;j<Di.rows();++j)rowOrder[j]=inverse.indices()[j];}
  for(unsigned j=0;j<ni;++j)(j<rank?pivots:free).push_back(cols[j]);for(int j=0;j<Di.rows();++j)(unsigned(j)<rank?pressureRows:remainingRows).push_back(rowOrder[j]);
  pivot.resize(rank,rank);Dense Dfree(rank,free.size()),Dt(rank,nc),Db(rank,6),Af(nr,free.size());Ap.resize(nr,rank);
  for(unsigned j=0;j<rank;++j)Ap.col(j)=Ai.col(pivots[j]);for(unsigned j=0;j<free.size();++j)Af.col(j)=Ai.col(free[j]);
  for(unsigned r=0;r<rank;++r){for(unsigned j=0;j<rank;++j)pivot(r,j)=Di(pressureRows[r],pivots[j]);for(unsigned j=0;j<free.size();++j)Dfree(r,j)=Di(pressureRows[r],free[j]);Dt.row(r)=Dc.row(pressureRows[r]);Db.row(r)=raw.bodyDivergence.row(pressureRows[r]);}
  if(rank){Cfree=pivot.fullPivLu().solve(Dfree);Ctrace=pivot.fullPivLu().solve(Dt);Cbody=pivot.fullPivLu().solve(Db);}else{Cfree=Dense::Zero(0,free.size());Ctrace=Dense::Zero(0,nc);Cbody=Dense::Zero(0,6);}
  J=Af-Ap*Cfree;Y=Ac-Ap*Ctrace;Ybody=raw.body-Ap*Cbody;
  tail=nr-free.size();
  if(free.empty()){K=Y;Kbody=Ybody;triangle=Dense::Zero(0,0);}
  else{qr=std::make_shared<Eigen::ColPivHouseholderQR<Dense>>(J);if(unsigned(qr->rank())!=free.size())throw std::runtime_error("localized kinetic rank loss");const Dense rotated=qr->householderQ().adjoint()*Y,rotatedBody=qr->householderQ().adjoint()*Ybody;K=rotated.bottomRows(tail);Kbody=rotatedBody.bottomRows(tail);triangle=qr->matrixR().topLeftCorner(free.size(),free.size()).triangularView<Eigen::Upper>();gradient=std::make_shared<PreparedCompensatedGradient>(J);}
  remainingPivot.resize(remainingRows.size(),rank);G.resize(remainingRows.size(),nc);Gbody.resize(remainingRows.size(),6);
  for(unsigned r=0;r<remainingRows.size();++r){for(unsigned j=0;j<rank;++j)remainingPivot(r,j)=Di(remainingRows[r],pivots[j]);G.row(r)=Dc.row(remainingRows[r])-remainingPivot.row(r)*Ctrace;Gbody.row(r)=raw.bodyDivergence.row(remainingRows[r])-remainingPivot.row(r)*Cbody;}
 }
 Vector Refine(const Vector& rhs,Vector x)const{
  if(x.size()==0)return x;Real last=0;
  for(unsigned step=0;step<2;++step){const Vector g=gradient->Evaluate(rhs,x),ordered=qr->colsPermutation().transpose()*g;const Vector lower=triangle.transpose().triangularView<Eigen::Lower>().solve(ordered);const Vector upper=triangle.triangularView<Eigen::Upper>().solve(lower);const Vector delta=qr->colsPermutation()*upper;x+=delta;last=0;for(unsigned j=0;j<free.size();++j)last=std::max(last,Real(std::abs(raw.columnScale[inside[free[j]]]*delta[j])));}
  if(!x.allFinite()||!std::isfinite(last)||last>1e-12L)throw std::runtime_error("localized refinement did not converge");return x;
 }
};
}
