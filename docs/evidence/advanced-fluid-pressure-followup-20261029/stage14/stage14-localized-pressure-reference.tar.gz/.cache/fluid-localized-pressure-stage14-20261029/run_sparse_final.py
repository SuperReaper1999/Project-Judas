from pathlib import Path
import json,time,subprocess
folder=Path('.cache/fluid-localized-pressure-stage14-20261029');out=folder/'sparse-final-qualification';out.mkdir(exist_ok=False);runs=[]
for name in ['SparsePressureTests','SparseThinAccuracyTests','SparseDisconnectedControlTests','SparseCacheTests','SparseWarmBenchmark','SparseOraclePrecisionTests']:
 command=['python3',str(folder/'run_probe.py'),name];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'returnCode':r.returncode,'seconds':time.monotonic()-start};runs.append(record);(out/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(record),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
