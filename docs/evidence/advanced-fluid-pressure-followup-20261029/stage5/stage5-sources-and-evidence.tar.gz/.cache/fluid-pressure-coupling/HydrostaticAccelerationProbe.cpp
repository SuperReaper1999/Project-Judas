#include "BoxQuadrature.h"
#include <fstream>
#include <sstream>
#include <chrono>
#include <cstdio>
using namespace pressure_prototype;
int main(int argc,char**argv) {
    if(argc!=5)return 2;
    std::vector<glm::dvec3> positions;std::vector<double> volumes;std::vector<Point> points;
    std::ifstream file(argv[1]);std::string line;std::getline(file,line);
    while(std::getline(file,line)){std::replace(line.begin(),line.end(),',',' ');std::istringstream input(line);glm::dvec3 p,v,a;double mass;input>>p.x>>p.y>>p.z>>v.x>>v.y>>v.z>>a.x>>a.y>>a.z>>mass;positions.push_back(p);volumes.push_back(mass/1000);points.push_back({v,1/mass});}
    const glm::dquat q(1,0,0,0);std::vector<Box> boxes{{{0,-.1,0},{1.1,.1,1.1},q,0},{{-1.1,1.5,0},{.1,1.5,1.1},q,1},{{1.1,1.5,0},{.1,1.5,1.1},q,2},{{0,1.5,-1.1},{1,1.499,.1},q,3},{{0,1.5,1.1},{1,1.499,.1},q,4},{{0,.7,0},{.3,.3,.3},q,5}};
    std::vector<glm::dvec3> centers;for(const auto& box:boxes)centers.push_back(box.center);
    std::vector<Body> bodies(6);bodies[5].inverseMass=1./108;bodies[5].inverseInertia=glm::dmat3(1./6.48);bodies[5].velocity={0,-9.81/90,0};for(auto& p:points)p.velocity=glm::dvec3(0,-9.81/90,0);
    Kernel kernel(.42);auto boundary=BoxVolumes(boxes,.2);auto rows=BuildRows(positions,volumes,boundary,centers,kernel,1./90,std::stoi(argv[4])!=0);
    for(auto& row:rows.rows)row.maximumRate=0; // manufactured hydrostatic acceleration, no density bias
    const auto densityCount=rows.rows.size();AppendBoxContacts(rows.rows,positions,boxes,centers,kernel.h,1./90);
    rows.rows.erase(std::remove_if(rows.rows.begin()+densityCount,rows.rows.end(),[](const Row& row){return row.maximumRate/90>.07201;}),rows.rows.end());
    for(unsigned i=densityCount;i<rows.rows.size();++i)rows.rows[i].maximumRate=0;
    auto before=std::chrono::steady_clock::now();auto result=Project(points,bodies,rows.rows,unsigned(std::stoul(argv[2])),1e-5);
    std::printf("HYDROSTATIC body_v=(%.12g %.12g %.12g) apparent_added_mass=%.12g\n",bodies[5].velocity.x,bodies[5].velocity.y,bodies[5].velocity.z,108*(1/bodies[5].velocity.y-1));
    double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-before).count();
    std::ofstream output(argv[3]);output.precision(17);for(auto&p:points)output<<p.velocity.x<<','<<p.velocity.y<<','<<p.velocity.z<<'\n';
    std::printf("FROZEN points=%zu rows=%zu converged=%d sweeps=%u residual=%.12g milliseconds=%.6f\n",points.size(),rows.rows.size(),result.converged,result.sweeps,result.maximumResidual,ms);return result.converged?0:1;
}
