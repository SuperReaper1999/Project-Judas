#pragma once
#include "DensityRows.h"
#include <glm/gtc/quaternion.hpp>
namespace pressure_prototype {
struct Box {glm::dvec3 center,half;glm::dquat rotation;unsigned body;};
inline std::vector<Boundary> BoxVolumes(const std::vector<Box>& boxes,double spacing) {
    std::vector<Boundary> samples;
    for(unsigned i=0;i<boxes.size();++i) {
        const auto& box=boxes[i];glm::ivec3 count;
        for(int k=0;k<3;++k){count[k]=std::max(1,int(std::ceil(2*box.half[k]/spacing)));if(count[k]>128)throw std::runtime_error("prototype volume quadrature scope exceeded");}
        const glm::dvec3 cell=2.*box.half/glm::dvec3(count);const double volume=cell.x*cell.y*cell.z;
        for(int x=0;x<count.x;++x)for(int y=0;y<count.y;++y)for(int z=0;z<count.z;++z) {
            const auto local=-box.half+(glm::dvec3(x,y,z)+.5)*cell;
            const auto point=box.center+box.rotation*local;
            bool duplicate=false;
            for(unsigned j=0;j<i;++j){auto localOther=glm::conjugate(boxes[j].rotation)*(point-boxes[j].center);if(glm::all(glm::lessThan(glm::abs(localOther),boxes[j].half-glm::dvec3(1e-7)))){duplicate=true;break;}}
            if(!duplicate)samples.push_back({point,box.body,volume});
        }
    }
    return samples;
}
inline void AppendBoxContacts(std::vector<Row>& rows,const std::vector<glm::dvec3>& positions,
    const std::vector<Box>& boxes,const std::vector<glm::dvec3>& centers,double radius,double dt) {
    for(unsigned i=0;i<positions.size();++i)for(const auto& box:boxes) {
        const auto local=glm::conjugate(box.rotation)*(positions[i]-box.center);
        auto surface=glm::clamp(local,-box.half,box.half),offset=local-surface;
        double gap=glm::length(offset);glm::dvec3 normal;
        if(gap>0)normal=box.rotation*(offset/gap);
        else {
            int axis=0;for(int k=1;k<3;++k)if(box.half[k]-std::abs(local[k])<box.half[axis]-std::abs(local[axis]))axis=k;
            glm::dvec3 n(0);n[axis]=local[axis]>=0?1:-1;normal=box.rotation*n;
            gap=std::abs(local[axis])-box.half[axis];surface=local;surface[axis]=n[axis]*box.half[axis];
        }
        if(gap>=radius)continue;
        const auto point=box.center+box.rotation*surface;
        Row contact;contact.points={{i,-normal}};
        contact.bodies={{box.body,normal,glm::cross(point-centers[box.body],normal)}};
        contact.maximumRate=gap/dt;rows.push_back(std::move(contact));
    }
}
}
