#include "RuntimeBridge.h"
namespace pressure_prototype {thread_local Bridge* activeBridge=nullptr;}
