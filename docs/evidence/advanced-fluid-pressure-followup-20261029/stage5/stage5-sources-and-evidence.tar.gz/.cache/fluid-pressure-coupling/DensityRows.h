#pragma once
#ifdef PRESSURE_USE_PGS
#include "PressureProjection-pgs.h"
#else
#include "PressureProjection.h"
#endif
#include <map>
#include <unordered_map>
#include <tuple>

namespace pressure_prototype {
struct Kernel {
    double h,h2,coefficient;
    explicit Kernel(double radius):h(radius),h2(radius*radius),coefficient(315./(64.*3.14159265358979323846*std::pow(radius,9))) {}
    double Value(glm::dvec3 displacement) const {
        const double d=h2-glm::dot(displacement,displacement);
        return d>0?coefficient*d*d*d:0;
    }
    glm::dvec3 Gradient(glm::dvec3 displacement) const {
        const double d=h2-glm::dot(displacement,displacement);
        return d>0?(-6.*coefficient*d*d)*displacement:glm::dvec3(0);
    }
};
struct Cell {int x,y,z;bool operator==(const Cell& b)const{return x==b.x&&y==b.y&&z==b.z;}};
struct CellHash {std::size_t operator()(Cell c)const{return std::size_t(c.x)*73856093u^std::size_t(c.y)*19349663u^std::size_t(c.z)*83492791u;}};
struct Grid {
    double width;
    std::unordered_map<Cell,std::vector<unsigned>,CellHash> cells;
    explicit Grid(double w):width(w){}
    Cell At(glm::dvec3 p)const{return {int(std::floor(p.x/width)),int(std::floor(p.y/width)),int(std::floor(p.z/width))};}
    void Add(glm::dvec3 p,unsigned index){cells[At(p)].push_back(index);}
    template<class F>void Visit(glm::dvec3 p,F f)const{
        auto c=At(p);
        for(int x=-1;x<=1;++x)for(int y=-1;y<=1;++y)for(int z=-1;z<=1;++z){auto found=cells.find({c.x+x,c.y+y,c.z+z});if(found!=cells.end())for(auto i:found->second)f(i);}
    }
};
struct Boundary {glm::dvec3 position;unsigned body;double volume=0;};
inline void NormalizeBoundaries(std::vector<Boundary>& boundary,const Kernel& kernel) {
    Grid grid(kernel.h);for(unsigned i=0;i<boundary.size();++i)grid.Add(boundary[i].position,i);
    for(auto& sample:boundary){double sum=0;grid.Visit(sample.position,[&](unsigned j){sum+=kernel.Value(sample.position-boundary[j].position);});sample.volume=1./sum;}
}
struct DensitySystem {std::vector<Row> rows;std::vector<double> density;std::vector<glm::dvec3> queryLocations;std::vector<double> queryVolumes;};
inline DensitySystem BuildRows(const std::vector<glm::dvec3>& positions,const std::vector<double>& volumes,
                              const std::vector<Boundary>& boundary,const std::vector<glm::dvec3>& centers,
                              const Kernel& kernel,double dt,bool completeBoundary=false) {
    Grid fluids(kernel.h),solids(kernel.h);
    for(unsigned i=0;i<positions.size();++i)fluids.Add(positions[i],i);
    for(unsigned i=0;i<boundary.size();++i)solids.Add(boundary[i].position,i);
    DensitySystem system;system.rows.resize(positions.size());system.density.resize(positions.size());system.queryLocations=positions;system.queryVolumes=volumes;
    for(unsigned i=0;i<positions.size();++i) {
        auto& row=system.rows[i];double density=0;glm::dvec3 ownGradient(0);
        fluids.Visit(positions[i],[&](unsigned j){
            auto d=positions[i]-positions[j];if(glm::dot(d,d)>=kernel.h2)return;density+=volumes[j]*kernel.Value(d);
            if(i!=j){auto gradient=volumes[j]*kernel.Gradient(d);ownGradient+=gradient;row.points.push_back({j,-gradient});}
        });
        std::map<unsigned,std::pair<glm::dvec3,glm::dvec3>> bodyGradients;
        solids.Visit(positions[i],[&](unsigned j){
            const auto& sample=boundary[j];auto d=positions[i]-sample.position;if(glm::dot(d,d)>=kernel.h2)return;
            density+=sample.volume*kernel.Value(d);const auto gradient=sample.volume*kernel.Gradient(d);ownGradient+=gradient;
            auto& body=bodyGradients[sample.body];body.first-=gradient;body.second-=glm::cross(sample.position-centers[sample.body],gradient);
        });
        row.points.push_back({i,ownGradient});
        for(const auto& entry:bodyGradients)row.bodies.push_back({entry.first,entry.second.first,entry.second.second});
        system.density[i]=density;// Incompressible continuity requires nonpositive compression rate even
        // where the kernel sum is deficient. Density restoration alone grants
        // artificial compressibility to under-sampled boundary/free-surface rows.
        row.maximumRate=std::min(0.,(1-density)/dt);
    }
    if(completeBoundary)for(unsigned i=0;i<boundary.size();++i) {
        const auto& query=boundary[i];Row row;double density=0;glm::dvec3 ownGradient(0);
        bool touchesFluid=false;
        fluids.Visit(query.position,[&](unsigned j){
            auto d=query.position-positions[j];if(glm::dot(d,d)>=kernel.h2)return;
            density+=volumes[j]*kernel.Value(d);auto gradient=volumes[j]*kernel.Gradient(d);
            ownGradient+=gradient;row.points.push_back({j,-gradient});touchesFluid=true;
        });
        if(!touchesFluid)continue;
        std::map<unsigned,std::pair<glm::dvec3,glm::dvec3>> bodyGradients;
        solids.Visit(query.position,[&](unsigned j){
            const auto& sample=boundary[j];auto d=query.position-sample.position;if(glm::dot(d,d)>=kernel.h2)return;
            density+=sample.volume*kernel.Value(d);
            if(sample.body==query.body)return; // rigid internal distances are constant
            const auto gradient=sample.volume*kernel.Gradient(d);ownGradient+=gradient;
            auto& other=bodyGradients[sample.body];other.first-=gradient;other.second-=glm::cross(sample.position-centers[sample.body],gradient);
        });
        auto& own=bodyGradients[query.body];own.first+=ownGradient;own.second+=glm::cross(query.position-centers[query.body],ownGradient);
        for(auto& entry:bodyGradients)row.bodies.push_back({entry.first,entry.second.first,entry.second.second});
        // Boundary pressure is an unknown, rather than implicitly zero.
        // Its row constrains boundary-adjacent volume flux; it does not make
        // the solid compressible or introduce independent boundary masses.
        row.maximumRate=0;
        system.rows.push_back(std::move(row));system.density.push_back(density);
        system.queryLocations.push_back(query.position);system.queryVolumes.push_back(query.volume);
    }
    return system;
}
}
