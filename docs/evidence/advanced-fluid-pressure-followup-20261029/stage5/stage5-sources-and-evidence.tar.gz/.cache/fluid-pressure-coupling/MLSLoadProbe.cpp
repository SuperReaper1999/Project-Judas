#include "VectorMLSRows.h"
#include <cstdio>
using namespace pressure_prototype;
int main(){const double s=.2;std::vector<glm::dvec3> x;std::vector<double> volumes;std::vector<SurfaceSample> surfaces;std::vector<glm::dvec3> centers{{0,0,0}};
 for(int i=-7;i<=7;++i)for(int j=-7;j<=7;++j)for(int k=-7;k<=7;++k){glm::dvec3 p=s*glm::dvec3(i,j,k);if(std::abs(i)<=1&&std::abs(j)<=1&&std::abs(k)<=1)continue;x.push_back(p);volumes.push_back(s*s*s);}
 for(int axis=0;axis<3;++axis){int a=(axis+1)%3,b=(axis+2)%3;for(int sign:{-1,1})for(int i=0;i<3;++i)for(int j=0;j<3;++j){glm::dvec3 p(0),n(0);p[axis]=.3*sign;n[axis]=sign;p[a]=-.2+.2*i;p[b]=-.2+.2*j;surfaces.push_back({p,n,.04,0});}}
 auto system=BuildMLSCompressionRows(x,volumes,surfaces,centers,Kernel(.42));
 glm::dvec3 force(0),constant(0);unsigned index=0;
 // This field has no unresolved nodes; pressure weighting is physical parcel volume.
 if(system.unresolved){std::printf("UNRESOLVED %u\n",system.unresolved);return 2;}
 for(auto& row:system.rows){double pressure=1000*9.81*(3-x[index].y);for(auto g:row.bodies){force-=g.linear*(pressure*volumes[index]);constant-=g.linear*volumes[index];}++index;}
 std::printf("MLS_LINEAR_PRESSURE force=(%.12g %.12g %.12g) expected_y=2118.96 ratio=%.12g constant_force=%.12g patch_error=%.12g\n",force.x,force.y,force.z,force.y/2118.96,glm::length(constant),system.maximumPatchError);
}
