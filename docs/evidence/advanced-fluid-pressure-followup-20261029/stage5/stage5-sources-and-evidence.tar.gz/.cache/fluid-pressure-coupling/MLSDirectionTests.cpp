#include "VectorMLSRows.h"
#include <cstdio>
using namespace pressure_prototype;
int main(){std::vector<glm::dvec3> x;std::vector<double> volumes;
 for(int i=-2;i<=2;++i)for(int j=-2;j<=2;++j)for(int k=-2;k<=2;++k){x.push_back(.2*glm::dvec3(i,j,k));volumes.push_back(.008);}
 auto system=BuildMLSCompressionRows(x,volumes,{}, {},Kernel(.42));int checks=0,failures=0;auto check=[&](bool ok,const char*s){++checks;if(!ok){++failures;std::printf("FAIL %s\n",s);}};
 std::vector<Body> bodies;
 std::vector<Point> expansion,compression;
 for(auto p:x){expansion.push_back({p,125});compression.push_back({-p,125});}
 for(auto& row:system.rows){double r=0;for(auto g:row.points)r+=glm::dot(g.gradient,expansion[g.point].velocity);check(std::abs(r+3)<1e-9,"expansion has negative compression rate");}
 auto expanded=Project(expansion,bodies,system.rows,256,1e-8);check(expanded.converged,"expansion converges without pressure");
 for(unsigned i=0;i<x.size();++i)check(expansion[i].velocity==x[i]&&expanded.pressureImpulse[i]==0,"expansion stays unchanged");
 auto compressed=Project(compression,bodies,system.rows,256,1e-8);check(compressed.converged,"compression is corrected");
 double initial=0,final=0;for(unsigned i=0;i<x.size();++i){initial+=glm::dot(x[i],x[i]);final+=glm::dot(compression[i].velocity,compression[i].velocity);}check(final<initial,"compression pressure opposes compression");
 std::printf("SUMMARY checks=%d failures=%d\n",checks,failures);return failures?1:0;}
