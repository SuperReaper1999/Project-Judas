#include "PressureProjection.h"
#include <glm/gtc/quaternion.hpp>
#include <map>
#include <cstdio>
#include <chrono>
using namespace pressure_prototype;
struct Face {unsigned point;glm::dvec3 fluidCenter;};
struct ProofResult {Result projection;glm::dvec3 bodyVelocity,force;double maximumFluidSpeed=0,milliseconds=0;};
ProofResult Run(double densityRatio,glm::dquat rotation,bool prescribedPressure) {
    constexpr int nx=10,ny=12,nz=10;constexpr double dx=.2,rho=1000,dt=1./90;
    const double cellVolume=dx*dx*dx,solidVolume=27*cellVolume,mass=rho*solidVolume*densityRatio;
    const glm::dvec3 bodyCenterIndex(5.5,3.5,5.5),worldOffset(-1,0,-1);
    const auto world=[&](glm::dvec3 index){return rotation*(worldOffset+index*dx);};
    const glm::dvec3 bodyCenter=world(bodyCenterIndex),gravity=rotation*glm::dvec3(0,-9.81,0);
    std::vector<Point> points;std::vector<Face> faces;std::vector<Row> rows(nx*ny*nz);
    std::vector<Body> bodies{{gravity*dt,{0,0,0},1/mass,glm::dmat3(1/(mass*.06))}};
    const auto cell=[&](glm::ivec3 p){return unsigned((p.y*nz+p.z)*nx+p.x);};
    auto add=[&](unsigned row,int point,double fluidWeight,double solidWeight,glm::dvec3 normal,glm::dvec3 localNormal,glm::dvec3 leverLocal){
        if(point>=0)rows[row].points.push_back({unsigned(point),normal*fluidWeight});
        if(solidWeight!=0){rows[row].bodies.push_back({0,localNormal*solidWeight,glm::cross(leverLocal,localNormal)*solidWeight});}
    };
    for(int axis=0;axis<3;++axis){glm::ivec3 size(nx,ny,nz);int a=(axis+1)%3,b=(axis+2)%3;glm::dvec3 localNormal(0);localNormal[axis]=1;const auto normal=rotation*localNormal;
        for(int k=0;k<=size[axis];++k)for(int i=0;i<size[a];++i)for(int j=0;j<size[b];++j){
            // Closed sides/bottom; pressure-zero free surface on top.
            bool top=axis==1&&k==ny;if((k==0||k==size[axis])&&!top)continue;
            glm::dvec3 centerIndex(0);centerIndex[axis]=k;centerIndex[a]=i+.5;centerIndex[b]=j+.5;
            const auto low=centerIndex-glm::dvec3(.5),high=centerIndex+glm::dvec3(.5);
            const auto lower=glm::max(low,glm::dvec3(4,2,4)),upper=glm::min(high,glm::dvec3(7,5,7));
            const auto extent=glm::max(upper-lower,glm::dvec3(0));double solidWeight=extent.x*extent.y*extent.z;
            const double solidMassVolume=solidWeight*cellVolume;
            const glm::dvec3 solidLeverLocal=((lower+upper)*.5-bodyCenterIndex)*dx;
            const double full=top?.5:1.,fluidVolume=(full-solidWeight)*cellVolume;
            const auto fullCenter=top?centerIndex-localNormal*.25:centerIndex;
            const auto fluidCenter=fluidVolume>0?world((full*fullCenter-solidWeight*(lower+upper)*.5)/(full-solidWeight)):glm::dvec3(0);
            int point=-1;
            if(fluidVolume>0){point=int(points.size());points.push_back({normal*glm::dot(gravity,normal)*dt,1/(rho*fluidVolume)});faces.push_back({unsigned(point),fluidCenter});}
            const double inverseDistance=top?2/dx:1/dx;
            glm::ivec3 left(centerIndex),right(centerIndex);left[axis]=k-1;right[axis]=k;
            left[a]=right[a]=i;left[b]=right[b]=j;
            if(k>0)add(cell(left),point,-fluidVolume*inverseDistance,-solidMassVolume*inverseDistance,normal,localNormal,solidLeverLocal);
            if(k<size[axis])add(cell(right),point,fluidVolume*inverseDistance,solidMassVolume*inverseDistance,normal,localNormal,solidLeverLocal);
        }
    }
    // A body contributes to many faces of a cell. Aggregate its Jacobian before
    // evaluating the mass matrix; treating samples as independent masses is wrong.
    for(auto& row:rows){glm::dvec3 linear(0),angular(0);for(auto& g:row.bodies){linear+=g.linear;angular+=g.angular;}row.bodies.clear();if(glm::length(linear)>0||glm::length(angular)>0)row.bodies.push_back({0,rotation*linear,rotation*angular});}
    ProofResult out;
    if(prescribedPressure){
        for(int y=0;y<ny;++y)for(int z=0;z<nz;++z)for(int x=0;x<nx;++x){double p=rho*9.81*(ny-y-.5)*dx;for(auto g:rows[cell({x,y,z})].bodies)out.force-=p*g.linear;}
        return out;
    }
    const auto begin=std::chrono::steady_clock::now();out.projection=Project(points,bodies,rows,1024,1e-9);
    out.milliseconds=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();out.bodyVelocity=glm::conjugate(rotation)*bodies[0].velocity;
    for(auto& p:points)out.maximumFluidSpeed=std::max(out.maximumFluidSpeed,glm::length(p.velocity));return out;
}
int main(){int checks=0,failures=0;auto check=[&](bool ok,const char*s){++checks;if(!ok){++failures;std::printf("FAIL %s\n",s);}};
 const glm::dquat identity(1,0,0,0),rotated=glm::angleAxis(.83,glm::normalize(glm::dvec3(1,-2,3)));
 auto force=Run(1,identity,true);std::printf("GRID_LINEAR_PRESSURE Fy=%.12g expected=2118.96\n",force.force.y);check(std::abs(force.force.y-2118.96)<1e-8,"exact coarse-grid hydrostatic load");
 for(double ratio:{.5,1.,2.}){auto a=Run(ratio,identity,false),b=Run(ratio,rotated,false);
  std::printf("GRID ratio=%.1f vy=%.12g rotated_vy=%.12g residual=%.12g sweeps=%u ms=%.6f\n",ratio,a.bodyVelocity.y,b.bodyVelocity.y,a.projection.maximumResidual,a.projection.sweeps,a.milliseconds);
  check(a.projection.converged&&b.projection.converged,"grid projection converges");check(glm::length(a.bodyVelocity-b.bodyVelocity)<1e-7,"gravity-frame covariance");
  if(ratio==.5)check(a.bodyVelocity.y>0,"light body rises");if(ratio==1)check(std::abs(a.bodyVelocity.y)<1e-7&&a.maximumFluidSpeed<1e-7,"neutral fluid and body stay at rest");if(ratio==2)check(a.bodyVelocity.y<0,"dense body sinks");
 }
 std::printf("SUMMARY checks=%d failures=%d\n",checks,failures);return failures?1:0;}
