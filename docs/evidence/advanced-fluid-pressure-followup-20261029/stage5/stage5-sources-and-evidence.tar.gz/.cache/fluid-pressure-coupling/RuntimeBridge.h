#pragma once
#include "VectorMLSRows.h"
#include "PhysicsWorld.h"
#include <functional>
namespace pressure_prototype {
// SCRATCH ADAPTER ONLY. Production integration must pass an explicit callback;
// this scope lets a link-time experiment retain the unchanged engine ABI.
struct Bridge {
    std::function<Body(BodyHandle)> read;
    std::function<glm::dvec3(BodyHandle)> center;
    std::function<void(BodyHandle,glm::dvec3,glm::dvec3)> react;
    std::function<void(BodyHandle,glm::dvec3)> observe;
    unsigned calls=0,failures=0,maxSweeps=0;
    double maxResidual=0;
};
extern thread_local Bridge* activeBridge;
struct ScopedBridge {
    Bridge* previous;
    explicit ScopedBridge(Bridge& bridge):previous(activeBridge){activeBridge=&bridge;}
    ~ScopedBridge(){activeBridge=previous;}
};
}
