#pragma once
#include <glm/glm.hpp>
#include <vector>
#include <cmath>
#include <algorithm>
#include <stdexcept>

namespace pressure_prototype {
// These are velocity degrees of freedom, not independent integration owners.
struct Point { glm::dvec3 velocity{0}; double inverseMass=0; };
struct Body {
    glm::dvec3 velocity{0}, angularVelocity{0};
    double inverseMass=0;
    glm::dmat3 inverseInertia{0};
};
struct PointGradient { unsigned point; glm::dvec3 gradient; };
struct BodyGradient { unsigned body; glm::dvec3 linear, angular; };
struct Row {
    std::vector<PointGradient> points;
    std::vector<BodyGradient> bodies;
    double maximumRate=0; // G*v <= maximumRate
};
struct Result {
    bool converged=false;
    unsigned sweeps=0, matrixProducts=0, accelerationRejections=0;
    double maximumResidual=0;
    std::vector<double> pressureImpulse;
};
// Convex minimum kinetic-change projection. Each row is a real density-rate
// Jacobian; rigid gradients are aggregated by body before computing its mass.
// No body mass is replaced by a collection of independently moving samples.
inline Result Project(std::vector<Point>& points,std::vector<Body>& bodies,
                      const std::vector<Row>& rows,unsigned budget,double tolerance) {
    Result result;result.pressureImpulse.assign(rows.size(),0);
    std::vector<double> diagonal(rows.size());
    auto rate=[&](const Row& row) {
        double value=0;
        for(const auto& g:row.points)value+=glm::dot(g.gradient,points.at(g.point).velocity);
        for(const auto& g:row.bodies) {
            const auto& b=bodies.at(g.body);
            value+=glm::dot(g.linear,b.velocity)+glm::dot(g.angular,b.angularVelocity);
        }
        return value;
    };
    for(unsigned i=0;i<rows.size();++i) {
        for(const auto& g:rows[i].points)diagonal[i]+=points.at(g.point).inverseMass*glm::dot(g.gradient,g.gradient);
        for(const auto& g:rows[i].bodies) {
            const auto& b=bodies.at(g.body);
            diagonal[i]+=b.inverseMass*glm::dot(g.linear,g.linear)+glm::dot(g.angular,b.inverseInertia*g.angular);
        }
        if(!(diagonal[i]>=0)||!std::isfinite(diagonal[i]))throw std::invalid_argument("invalid pressure mass matrix");
    }
    auto apply=[&](const std::vector<double>& impulses,double scale) {
        for(unsigned i=0;i<rows.size();++i)if(impulses[i]!=0) {
            const double change=scale*impulses[i];
            for(const auto& g:rows[i].points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*change;
            for(const auto& g:rows[i].bodies) {
                auto& b=bodies[g.body];b.velocity-=b.inverseMass*g.linear*change;b.angularVelocity-=b.inverseInertia*g.angular*change;
            }
        }
    };
    std::vector<glm::dvec3> pointWork(points.size()),linearWork(bodies.size()),angularWork(bodies.size());
    auto multiply=[&](const std::vector<double>& input,std::vector<double>& output) {
        std::fill(pointWork.begin(),pointWork.end(),glm::dvec3(0));
        std::fill(linearWork.begin(),linearWork.end(),glm::dvec3(0));
        std::fill(angularWork.begin(),angularWork.end(),glm::dvec3(0));
        for(unsigned i=0;i<rows.size();++i)if(input[i]!=0) {
            for(const auto& g:rows[i].points)pointWork[g.point]+=g.gradient*input[i];
            for(const auto& g:rows[i].bodies){linearWork[g.body]+=g.linear*input[i];angularWork[g.body]+=g.angular*input[i];}
        }
        for(unsigned i=0;i<points.size();++i)pointWork[i]*=points[i].inverseMass;
        for(unsigned i=0;i<bodies.size();++i){linearWork[i]*=bodies[i].inverseMass;angularWork[i]=bodies[i].inverseInertia*angularWork[i];}
        output.assign(rows.size(),0);
        for(unsigned i=0;i<rows.size();++i) {
            for(const auto& g:rows[i].points)output[i]+=glm::dot(g.gradient,pointWork[g.point]);
            for(const auto& g:rows[i].bodies)output[i]+=glm::dot(g.linear,linearWork[g.body])+glm::dot(g.angular,angularWork[g.body]);
        }
        ++result.matrixProducts;
    };
    auto residual=[&]() {
        result.maximumResidual=0;
        for(unsigned i=0;i<rows.size();++i) {
            const double error=rate(rows[i])-rows[i].maximumRate;
            const double violation=result.pressureImpulse[i]>0?std::abs(error):std::max(0.,error);
            result.maximumResidual=std::max(result.maximumResidual,violation);
        }
        result.converged=result.maximumResidual<=tolerance;
    };
    unsigned work=0;
    while(work<budget) {
        ++result.sweeps;++work;
        for(unsigned i=0;i<rows.size();++i) {
            if(diagonal[i]==0)continue;
            const auto& row=rows[i];const double old=result.pressureImpulse[i];
            const double next=std::max(0.,old+(rate(row)-row.maximumRate)/diagonal[i]);
            const double change=next-old;result.pressureImpulse[i]=next;
            for(const auto& g:row.points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*change;
            for(const auto& g:row.bodies) {
                auto& b=bodies[g.body];b.velocity-=b.inverseMass*g.linear*change;
                b.angularVelocity-=b.inverseInertia*g.angular*change;
            }
        }
        residual();if(result.converged)break;
        if(work+3>=budget)continue;
        // PCG only accelerates currently positive pressures. Bound variables
        // enter/leave through coordinate projection. A candidate is accepted
        // only within the nonnegative cone and with a verified dual decrease.
        std::vector<double> r(rows.size()),initial(rows.size()),direction(rows.size()),delta(rows.size(),0),product;
        double rz=0;
        for(unsigned i=0;i<rows.size();++i)if(result.pressureImpulse[i]>0&&diagonal[i]>0) {
            initial[i]=r[i]=rate(rows[i])-rows[i].maximumRate;
            direction[i]=r[i]/diagonal[i];rz+=r[i]*direction[i];
        }
        for(unsigned inner=0;inner<24&&work+2<budget&&rz>0;++inner) {
            multiply(direction,product);++work;double curvature=0;
            for(unsigned i=0;i<rows.size();++i)curvature+=direction[i]*product[i];
            if(!(curvature>0)||!std::isfinite(curvature))break;
            const double alpha=rz/curvature;double next=0,maxError=0;
            for(unsigned i=0;i<rows.size();++i)if(result.pressureImpulse[i]>0&&diagonal[i]>0) {
                delta[i]+=alpha*direction[i];r[i]-=alpha*product[i];
                next+=r[i]*r[i]/diagonal[i];maxError=std::max(maxError,std::abs(r[i]));
            }
            if(maxError<=tolerance)break;
            const double beta=next/rz;
            for(unsigned i=0;i<rows.size();++i)if(result.pressureImpulse[i]>0&&diagonal[i]>0)direction[i]=r[i]/diagonal[i]+beta*direction[i];
            rz=next;
        }
        multiply(delta,product);++work;double descent=0,curvature=0,alpha=1,bound=1;unsigned leaving=rows.size();
        for(unsigned i=0;i<rows.size();++i) {
            descent+=initial[i]*delta[i];curvature+=delta[i]*product[i];
            if(delta[i]<0){const double fraction=-result.pressureImpulse[i]/delta[i];if(fraction<=bound){bound=fraction;leaving=i;}}
        }
        alpha=bound;if(curvature>0)alpha=std::min(alpha,descent/curvature);
        if(alpha>0&&std::isfinite(alpha)&&descent>0&&alpha*curvature<=descent) {
            std::vector<double> actual(rows.size());
            for(unsigned i=0;i<rows.size();++i){
                double next=std::max(0.,result.pressureImpulse[i]+alpha*delta[i]);
                if(alpha==bound&&i==leaving)next=0; // exact active-set pivot, no impulse threshold
                actual[i]=next-result.pressureImpulse[i];result.pressureImpulse[i]=next;
            }
            apply(actual,1);
        } else ++result.accelerationRejections;
        residual();if(result.converged)break;
    }
    return result;
}
}
