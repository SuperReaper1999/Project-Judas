#include "DensityRows.h"
#include <glm/gtc/quaternion.hpp>
#include <cstdio>
using namespace pressure_prototype;
int main() {
    int checks=0,failures=0;auto check=[&](bool p,const char*s){++checks;if(!p){++failures;std::printf("FAIL %s\n",s);}};
    Kernel kernel(.42);std::vector<glm::dvec3> x{{.05,.15,0},{.2,.2,.02},{.04,.32,.01}};std::vector<double> volumes(3,.008);std::vector<glm::dvec3> centers{{-.2,0,0}};
    std::vector<Boundary> boundary;
    for(int y=-4;y<=4;++y)for(int z=-4;z<=4;++z)boundary.push_back({{0,y*.1,z*.1},0,0});
    NormalizeBoundaries(boundary,kernel);auto base=BuildRows(x,volumes,boundary,centers,kernel,.01,true);
    constexpr double epsilon=1e-6;
    for(unsigned row=0;row<base.rows.size();++row){
        glm::dvec3 sum(0),moment(0);
        for(auto g:base.rows[row].points){sum+=g.gradient;moment+=glm::cross(x[g.point],g.gradient);
            for(int axis=0;axis<3;++axis){auto plus=x,minus=x;plus[g.point][axis]+=epsilon;minus[g.point][axis]-=epsilon;
                double numerical=(BuildRows(plus,volumes,boundary,centers,kernel,.01,true).density[row]-BuildRows(minus,volumes,boundary,centers,kernel,.01,true).density[row])/(2*epsilon);
                check(std::abs(numerical-g.gradient[axis])<1e-7,"fluid derivative matches density function");}}
        for(auto g:base.rows[row].bodies){sum+=g.linear;moment+=glm::cross(centers[g.body],g.linear)+g.angular;
            for(int axis=0;axis<3;++axis){auto plus=boundary,minus=boundary;for(auto& p:plus)p.position[axis]+=epsilon;for(auto&p:minus)p.position[axis]-=epsilon;
                double numerical=(BuildRows(x,volumes,plus,centers,kernel,.01,true).density[row]-BuildRows(x,volumes,minus,centers,kernel,.01,true).density[row])/(2*epsilon);
                check(std::abs(numerical-g.linear[axis])<1e-7,"body translation derivative matches density function");
                glm::dvec3 a(0);a[axis]=1;auto qp=glm::angleAxis(epsilon,a),qm=glm::angleAxis(-epsilon,a);plus=boundary;minus=boundary;
                for(auto&p:plus)p.position=centers[0]+qp*(p.position-centers[0]);for(auto&p:minus)p.position=centers[0]+qm*(p.position-centers[0]);
                numerical=(BuildRows(x,volumes,plus,centers,kernel,.01,true).density[row]-BuildRows(x,volumes,minus,centers,kernel,.01,true).density[row])/(2*epsilon);
                check(std::abs(numerical-g.angular[axis])<1e-7,"body rotation derivative matches density function");}}
        check(glm::length(sum)<1e-12,"Jacobian conserves linear momentum");check(glm::length(moment)<1e-12,"Jacobian conserves angular momentum");
    }
    std::printf("SUMMARY checks=%d failures=%d\n",checks,failures);return failures?1:0;
}
