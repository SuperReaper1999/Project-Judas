#include "RuntimeBridge.h"
#include "FluidWorld.h"
#include <glm/gtc/quaternion.hpp>
namespace pressure_prototype {
// Experimental pressure phase. Uses the same fluid substep, particle mass,
// gravity, actual collider geometry and normal-contact response as the source.
void RunLateProjection(Bridge& bridge,std::vector<FluidParticle>& particles,
    const std::vector<FluidVelocityContact>& contacts,const std::vector<FluidBoxCollider>& boxes,
    const std::vector<FluidSphereCollider>& spheres,const std::vector<FluidTerrainCollider>& terrains,
    const FluidSettings& settings,float interval,std::vector<glm::vec3>& contactImpulses) {
    struct BoxView {BodyHandle owner;BodyTransform end;glm::quat inverseEnd;glm::vec3 halfExtents;};
    std::vector<BoxView> preparedBoxes;for(auto& b:boxes)preparedBoxes.push_back({b.owner,b.currentPose,glm::conjugate(b.currentPose.rotation),b.halfExtents});
    const auto& preparedSpheres=spheres;const auto& preparedTerrains=terrains;
    const float radius=settings.smoothingRadius,restDensity=settings.restDensity,substepTime=interval;
    const Kernel pressureKernel(radius);
    std::vector<SurfaceSample> boundary;
    std::vector<BodyHandle> handles;
    std::vector<Body> rigid,originalRigid;
    std::vector<glm::dvec3> centers;
    auto indexFor=[&](BodyHandle handle){
        auto found=std::find_if(handles.begin(),handles.end(),[&](BodyHandle h){return h.id==handle.id;});
        if(found!=handles.end())return unsigned(found-handles.begin());
        unsigned index=handles.size();handles.push_back(handle);rigid.push_back(bridge.read(handle));centers.push_back(bridge.center(handle));return index;
    };
    const double spacing=std::cbrt(double(particles.front().mass)/restDensity);
    for(const auto& box:preparedBoxes) {
        const unsigned owner=indexFor(box.owner);
        for(int axis=0;axis<3;++axis){const int a=(axis+1)%3,b=(axis+2)%3;
            const int na=std::max(1,int(std::ceil(2*box.halfExtents[a]/spacing))),nb=std::max(1,int(std::ceil(2*box.halfExtents[b]/spacing)));
            if(na>128||nb>128)throw std::runtime_error("prototype surface patch scope exceeded");
            for(int sign:{-1,1})for(int i=0;i<na;++i)for(int j=0;j<nb;++j){
                glm::dvec3 local(0),normal(0);local[axis]=sign*box.halfExtents[axis];normal[axis]=sign;
                local[a]=-box.halfExtents[a]+(i+.5)*2*box.halfExtents[a]/na;local[b]=-box.halfExtents[b]+(j+.5)*2*box.halfExtents[b]/nb;
                const auto point=glm::dvec3(box.end.position)+glm::dquat(box.end.rotation)*local;
                bool internal=false;for(const auto& other:preparedBoxes)if(&other!=&box){auto p=glm::dquat(other.inverseEnd)*(point-glm::dvec3(other.end.position));if(glm::all(glm::lessThan(glm::abs(p),glm::dvec3(other.halfExtents)-glm::dvec3(1e-7)))){internal=true;break;}}
                if(!internal)boundary.push_back({point,glm::dquat(box.end.rotation)*normal,4.*box.halfExtents[a]*box.halfExtents[b]/(na*nb),owner});
            }
        }
    }
    if(!preparedSpheres.empty()||!preparedTerrains.empty())throw std::runtime_error("prototype requires box boundaries");
    std::vector<glm::dvec3> fluidPositions;
    std::vector<double> volumes;
    std::vector<Point> points;
    for(const auto& particle:particles){fluidPositions.push_back(glm::dvec3(particle.position));volumes.push_back(particle.mass/restDensity);points.push_back({glm::dvec3(particle.velocity),1./particle.mass});}
    originalRigid=rigid;
    auto system=BuildMLSCompressionRows(fluidPositions,volumes,boundary,centers,pressureKernel);
    // Use exactly the geometry contacts, with the same normals and owner.
    // No second approximate distance/skin boundary is constructed here.
    const unsigned pressureRows=system.rows.size();
    for(const auto& contact:contacts) {
        const unsigned owner=indexFor(contact.owner);
        Row row;row.points={{unsigned(contact.particleIndex),-glm::dvec3(contact.normal)}};
        row.bodies={{owner,glm::dvec3(contact.normal),glm::cross(glm::dvec3(contact.point)-centers[owner],glm::dvec3(contact.normal))}};
        row.maximumRate=0;system.rows.push_back(std::move(row));
    }
    auto projected=Project(points,rigid,system.rows,256,1e-5);
    if(bridge.observe) {
        std::vector<glm::dvec3> reaction(rigid.size(),glm::dvec3(0));
        for(unsigned i=0;i<system.rows.size();++i)for(auto& g:system.rows[i].bodies)reaction[g.body]-=projected.pressureImpulse[i]*g.linear;
        for(unsigned i=0;i<reaction.size();++i)bridge.observe(handles[i],reaction[i]);
    }
    contactImpulses.resize(contacts.size());
    for(unsigned i=0;i<contacts.size();++i)contactImpulses[i]=contacts[i].normal*float(projected.pressureImpulse[pressureRows+i]);
    ++bridge.calls;bridge.failures+=!projected.converged;bridge.maxSweeps=std::max(bridge.maxSweeps,projected.sweeps);bridge.maxResidual=std::max(bridge.maxResidual,projected.maximumResidual);
    for(unsigned i=0;i<points.size();++i)particles[i].velocity=glm::vec3(points[i].velocity);
    for(unsigned i=0;i<rigid.size();++i)if(originalRigid[i].inverseMass>0)bridge.react(handles[i],rigid[i].velocity-originalRigid[i].velocity,rigid[i].angularVelocity-originalRigid[i].angularVelocity);
}

}
