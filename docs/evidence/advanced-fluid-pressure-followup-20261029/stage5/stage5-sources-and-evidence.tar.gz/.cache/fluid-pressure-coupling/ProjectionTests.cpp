#include "PressureProjection.h"
#include <cstdio>
using namespace pressure_prototype;
int main() {
    int checks=0,failed=0;
    auto check=[&](bool ok,const char* name){++checks;if(!ok){++failed;std::printf("FAIL %s\n",name);}};
    // One finite-mass boundary, known closed-form common normal velocity.
    std::vector<Point> points{{{0,-3,0},.5}};
    std::vector<Body> bodies{{{0,1,0},{0,0,0},.25,glm::dmat3(1)}};
    Row row;row.points={{0,{0,-1,0}}};row.bodies={{0,{0,1,0},{0,0,0}}};
    const auto result=Project(points,bodies,{row},64,1e-12);
    check(result.converged,"finite-mass convergence");
    check(std::abs(points[0].velocity.y+1./3)<1e-12,"analytic fluid endpoint");
    check(std::abs(bodies[0].velocity.y+1./3)<1e-12,"analytic body endpoint");
    check(std::abs(2*points[0].velocity.y+4*bodies[0].velocity.y+2)<1e-12,"equal and opposite momentum");
    // Moving boundary angular response participates in the SAME effective mass.
    points={{{0,-3,0},.5}};bodies={{{0,0,0},{0,0,0},.25,glm::dmat3(1)}};
    row.bodies={{0,{0,1,0},{0,0,2}}};
    const auto angular=Project(points,bodies,{row},64,1e-12);
    check(angular.converged,"angular convergence");
    check(std::abs(angular.pressureImpulse[0]-3./4.75)<1e-12,"mass and inertia denominator");
    check(std::abs(bodies[0].angularVelocity.z+2*angular.pressureImpulse[0])<1e-12,"boundary torque response");
    // No compression: no invented pressure, no velocity modification.
    points={{{0,3,0},.5}};bodies={{{0,0,0},{0,0,0},.25,glm::dmat3(1)}};
    const auto separate=Project(points,bodies,{row},64,1e-12);
    check(separate.converged&&separate.pressureImpulse[0]==0,"separation stays pressure free");
    check(points[0].velocity==glm::dvec3(0,3,0)&&bodies[0].velocity==glm::dvec3(0),"separation unchanged");
    // Two interacting rows, not independent collision impulses against a frozen wall.
    points={{{0,-2,0},1},{{0,-1,0},1}};bodies={{{0,0,0},{0,0,0},1,glm::dmat3(1)}};
    Row a;a.points={{0,{0,-1,0}}};a.bodies={{0,{0,1,0},{0,0,0}}};
    Row b;b.points={{1,{0,-1,0}}};b.bodies={{0,{0,1,0},{0,0,0}}};
    const auto shared=Project(points,bodies,{a,b},64,1e-12);
    check(shared.converged,"shared-body convergence");
    check(std::abs(points[0].velocity.y+1)<1e-12&&std::abs(points[1].velocity.y+1)<1e-12&&std::abs(bodies[0].velocity.y+1)<1e-12,"shared analytic endpoint");
    // An intentionally unsatisfiable row must REPORT failure, not silently pass.
    points={{{0,-1,0},0}};bodies.clear();Row immovable;immovable.points={{0,{0,-1,0}}};
    const auto impossible=Project(points,bodies,{immovable},4,1e-12);
    check(!impossible.converged&&impossible.maximumResidual==1,"immovable negative control");
    std::printf("SUMMARY checks=%d failures=%d\n",checks,failed);return failed?1:0;
}
