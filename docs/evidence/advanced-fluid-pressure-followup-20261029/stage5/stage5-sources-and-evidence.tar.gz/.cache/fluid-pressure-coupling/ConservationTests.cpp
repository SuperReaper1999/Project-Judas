#include "PressureProjection.h"
#include <cstdio>
using namespace pressure_prototype;
int main(){int checks=0,failed=0;
 auto check=[&](bool ok,const char* name){++checks;if(!ok){++failed;std::printf("FAIL %s\n",name);}};
 for(int trial=0;trial<100;++trial){
  std::vector<Point> points;std::vector<Body> bodies{{{.2,-.3,.4},{0,0,0},.125,glm::dmat3(.4)}};std::vector<Row> rows;
  glm::dvec3 initialMomentum=bodies[0].velocity/bodies[0].inverseMass;double initialEnergy=.5*glm::dot(bodies[0].velocity,bodies[0].velocity)/bodies[0].inverseMass;
  for(int i=0;i<8;++i){double mass=1+.2*i;glm::dvec3 v(std::sin(trial+i),std::cos(.7*trial+i),std::sin(.3*trial-i));points.push_back({v,1/mass});initialMomentum+=mass*v;initialEnergy+=.5*mass*glm::dot(v,v);glm::dvec3 n=glm::normalize(glm::dvec3(std::cos(i+.1),std::sin(i+.2),.3));Row row;row.points={{unsigned(i),-n}};row.bodies={{0,n,{0,0,0}}};rows.push_back(row);}
  auto result=Project(points,bodies,rows,256,1e-10);check(result.converged,"random coupled projection converges");glm::dvec3 momentum=bodies[0].velocity/bodies[0].inverseMass;double energy=.5*glm::dot(bodies[0].velocity,bodies[0].velocity)/bodies[0].inverseMass;
  for(auto&p:points){momentum+=p.velocity/p.inverseMass;energy+=.5*glm::dot(p.velocity,p.velocity)/p.inverseMass;}
  check(glm::length(momentum-initialMomentum)<1e-10,"random finite-mass momentum conserved");check(energy<=initialEnergy+1e-10,"passive pressure projection does not add energy");
  for(double pressure:result.pressureImpulse)check(pressure>=0,"pressure remains compressive");
 }
 std::printf("SUMMARY checks=%d failures=%d\n",checks,failed);return failed?1:0;}
