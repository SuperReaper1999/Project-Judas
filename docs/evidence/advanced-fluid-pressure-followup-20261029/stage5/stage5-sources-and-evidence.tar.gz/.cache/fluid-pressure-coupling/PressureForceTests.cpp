#include "DensityRows.h"
#include <cstdio>
using namespace pressure_prototype;
int main(){constexpr double s=.2,rho=1000,gravity=9.81,dt=.01;std::vector<glm::dvec3> fluid;std::vector<double> volumes;std::vector<Boundary> solid;std::vector<glm::dvec3> centers{{0,0,0}};
 for(int x=-7;x<=7;++x)for(int y=-7;y<=7;++y)for(int z=-7;z<=7;++z){glm::dvec3 p=s*glm::dvec3(x,y,z);if(std::abs(x)<=1&&std::abs(y)<=1&&std::abs(z)<=1)solid.push_back({p,0,s*s*s});else{fluid.push_back(p);volumes.push_back(s*s*s);}}
 auto system=BuildRows(fluid,volumes,solid,centers,Kernel(.42),dt,true);glm::dvec3 load(0);
 for(unsigned i=0;i<system.rows.size();++i){double multiplier=rho*gravity*(3-system.queryLocations[i].y)*system.queryVolumes[i]*dt;for(auto g:system.rows[i].bodies)load-=g.linear*multiplier/dt;}
 const double expected=rho*gravity*.216;
 std::printf("MANUFACTURED_PRESSURE fluid_rows=%zu force=(%.12g %.12g %.12g) expected_y=%.12g ratio=%.9g\n",fluid.size(),load.x,load.y,load.z,expected,load.y/expected);
 return std::abs(load.y-expected)<.02*expected?0:1;}
