#pragma once
#include <glm/glm.hpp>
#include <vector>
#include <cmath>
#include <algorithm>
#include <stdexcept>

namespace pressure_prototype {
// These are velocity degrees of freedom, not independent integration owners.
struct Point { glm::dvec3 velocity{0}; double inverseMass=0; };
struct Body {
    glm::dvec3 velocity{0}, angularVelocity{0};
    double inverseMass=0;
    glm::dmat3 inverseInertia{0};
};
struct PointGradient { unsigned point; glm::dvec3 gradient; };
struct BodyGradient { unsigned body; glm::dvec3 linear, angular; };
struct Row {
    std::vector<PointGradient> points;
    std::vector<BodyGradient> bodies;
    double maximumRate=0; // G*v <= maximumRate
};
struct Result {
    bool converged=false;
    unsigned sweeps=0;
    double maximumResidual=0;
    std::vector<double> pressureImpulse;
};
// Convex minimum kinetic-change projection. Each row is a real density-rate
// Jacobian; rigid gradients are aggregated by body before computing its mass.
// No body mass is replaced by a collection of independently moving samples.
inline Result Project(std::vector<Point>& points,std::vector<Body>& bodies,
                      const std::vector<Row>& rows,unsigned budget,double tolerance) {
    Result result;result.pressureImpulse.assign(rows.size(),0);
    std::vector<double> diagonal(rows.size());
    auto rate=[&](const Row& row) {
        double value=0;
        for(const auto& g:row.points)value+=glm::dot(g.gradient,points.at(g.point).velocity);
        for(const auto& g:row.bodies) {
            const auto& b=bodies.at(g.body);
            value+=glm::dot(g.linear,b.velocity)+glm::dot(g.angular,b.angularVelocity);
        }
        return value;
    };
    for(unsigned i=0;i<rows.size();++i) {
        for(const auto& g:rows[i].points)diagonal[i]+=points.at(g.point).inverseMass*glm::dot(g.gradient,g.gradient);
        for(const auto& g:rows[i].bodies) {
            const auto& b=bodies.at(g.body);
            diagonal[i]+=b.inverseMass*glm::dot(g.linear,g.linear)+glm::dot(g.angular,b.inverseInertia*g.angular);
        }
        if(!(diagonal[i]>=0)||!std::isfinite(diagonal[i]))throw std::invalid_argument("invalid pressure mass matrix");
    }
    for(unsigned sweep=0;sweep<budget;++sweep) {
        for(unsigned i=0;i<rows.size();++i) {
            if(diagonal[i]==0)continue;
            const auto& row=rows[i];
            const double old=result.pressureImpulse[i];
            const double next=std::max(0.,old+(rate(row)-row.maximumRate)/diagonal[i]);
            const double change=next-old;result.pressureImpulse[i]=next;
            for(const auto& g:row.points)points[g.point].velocity-=points[g.point].inverseMass*g.gradient*change;
            for(const auto& g:row.bodies) {
                auto& b=bodies[g.body];b.velocity-=b.inverseMass*g.linear*change;
                b.angularVelocity-=b.inverseInertia*g.angular*change;
            }
        }
        result.sweeps=sweep+1;result.maximumResidual=0;
        for(unsigned i=0;i<rows.size();++i) {
            const double error=rate(rows[i])-rows[i].maximumRate;
            const double residual=result.pressureImpulse[i]>0?std::abs(error):std::max(0.,error);
            result.maximumResidual=std::max(result.maximumResidual,residual);
        }
        if(result.maximumResidual<=tolerance){result.converged=true;break;}
    }
    return result;
}
}
