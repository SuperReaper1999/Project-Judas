#include "VectorMLSRows.h"
#include <cstdio>
using namespace pressure_prototype;
int main(){std::vector<glm::dvec3> x;std::vector<double> volumes;std::vector<SurfaceSample> surface;std::vector<glm::dvec3> centers{{0,0,0}};
 for(int i=0;i<4;++i)for(int j=-2;j<=2;++j)for(int k=-2;k<=2;++k){x.push_back({.1+i*.2,j*.2,k*.2});volumes.push_back(.008);}
 for(int j=-5;j<=5;++j)for(int k=-5;k<=5;++k)surface.push_back({{0,j*.1,k*.1},{1,0,0},.01,0});
 auto rows=BuildMLSRows(x,volumes,surface,centers,Kernel(.42));int checks=0,failed=0;
 auto check=[&](bool ok,const char* text){++checks;if(!ok){++failed;std::printf("FAIL %s\n",text);}};
 check(rows.unresolved==0,"3D boundary-adjacent stencils resolve");check(rows.maximumPatchError<1e-10,"translation and rotation patch invariance");
 for(auto& row:rows.rows){for(int component=0;component<3;++component){double divergence=0;for(auto g:row.points)divergence+=glm::dot(g.gradient,x[g.point])*0; // evaluated explicitly below
   for(auto g:row.points)divergence+=g.gradient[component]*x[g.point][component];
   // The plane's rigid velocity has zero normal component for v_y=y or v_z=z,
   // and v_x=x is zero at x=0; all three are represented exactly.
   check(std::abs(divergence-1)<1e-9,"unit affine strain divergence");}
  for(auto g:row.bodies)check(std::abs(g.linear.y)<1e-12&&std::abs(g.linear.z)<1e-12,"side wall has no tangential traction");}
 auto isolated=BuildMLSRows({{.1,0,0}},{.008},surface,centers,Kernel(.42));check(isolated.unresolved==1&&isolated.rows.empty(),"unresolved one-point stencil is reported");
 std::printf("SUMMARY checks=%d failures=%d patch_error=%.12g\n",checks,failed,rows.maximumPatchError);return failed?1:0;}
