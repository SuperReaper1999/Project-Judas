#pragma once
#include "DensityRows.h"
#include <array>
#include <limits>
namespace pressure_prototype {
struct SurfaceSample {glm::dvec3 position,normal;double area;unsigned body;};
struct MLSSystem {std::vector<Row> rows;unsigned unresolved=0;double maximumPatchError=0;};
using Vector12=std::array<double,12>;
using Matrix12=std::array<Vector12,12>;
inline bool SolveMLS(Matrix12 matrix,Vector12 rhs,Vector12& solution) {
    double norm=0;for(auto& row:matrix)for(double x:row)norm=std::max(norm,std::abs(x));
    const double rounding=64*12*std::numeric_limits<double>::epsilon()*norm;
    for(int k=0;k<12;++k){int pivot=k;for(int i=k+1;i<12;++i)if(std::abs(matrix[i][k])>std::abs(matrix[pivot][k]))pivot=i;
        if(!(std::abs(matrix[pivot][k])>rounding))return false;
        std::swap(matrix[k],matrix[pivot]);std::swap(rhs[k],rhs[pivot]);
        for(int i=k+1;i<12;++i){const double factor=matrix[i][k]/matrix[k][k];for(int j=k+1;j<12;++j)matrix[i][j]-=factor*matrix[k][j];rhs[i]-=factor*rhs[k];}
    }
    for(int i=11;i>=0;--i){double r=rhs[i];for(int j=i+1;j<12;++j)r-=matrix[i][j]*solution[j];solution[i]=r/matrix[i][i];}
    return true;
}
inline MLSSystem BuildMLSRows(const std::vector<glm::dvec3>& positions,const std::vector<double>& volumes,
    const std::vector<SurfaceSample>& boundary,const std::vector<glm::dvec3>& centers,const Kernel& kernel) {
    Grid fluids(kernel.h),solids(kernel.h);
    for(unsigned i=0;i<positions.size();++i)fluids.Add(positions[i],i);
    for(unsigned i=0;i<boundary.size();++i)solids.Add(boundary[i].position,i);
    MLSSystem result;
    struct Observation {unsigned index;bool solid;glm::dvec3 direction;double weight;Vector12 basis;};
    for(unsigned i=0;i<positions.size();++i) {
        Matrix12 moment{};std::vector<Observation> observations;
        auto add=[&](unsigned index,bool solid,glm::dvec3 direction,glm::dvec3 offset,double weight){
            Vector12 a{};for(int c=0;c<3;++c){a[c]=direction[c];for(int axis=0;axis<3;++axis)a[3+3*c+axis]=direction[c]*offset[axis]/kernel.h;}
            for(int r=0;r<12;++r)for(int c=0;c<12;++c)moment[r][c]+=weight*a[r]*a[c];
            observations.push_back({index,solid,direction,weight,a});
        };
        fluids.Visit(positions[i],[&](unsigned j){const auto d=positions[j]-positions[i];double weight=volumes[j]*kernel.Value(d);if(weight==0)return;
            for(int c=0;c<3;++c){glm::dvec3 axis(0);axis[c]=1;add(j,false,axis,d,weight);}
        });
        solids.Visit(positions[i],[&](unsigned j){const auto& b=boundary[j];const auto d=b.position-positions[i];if(glm::dot(-d,b.normal)<-1e-7)return;double weight=b.area*kernel.h*kernel.Value(d);if(weight>0)add(j,true,b.normal,d,weight);});
        Vector12 target{},coefficients{};for(int c=0;c<3;++c)target[3+3*c+c]=1/kernel.h;
        if(!SolveMLS(moment,target,coefficients)){++result.unresolved;continue;}
        Row row;std::map<unsigned,glm::dvec3> pointGradients;std::map<unsigned,std::pair<glm::dvec3,glm::dvec3>> bodyGradients;
        for(auto& observation:observations){double coefficient=0;for(int k=0;k<12;++k)coefficient+=coefficients[k]*observation.basis[k];coefficient*=observation.weight;
            auto gradient=coefficient*observation.direction;
            if(observation.solid){const auto& b=boundary[observation.index];auto& g=bodyGradients[b.body];g.first+=gradient;g.second+=glm::cross(b.position-centers[b.body],gradient);}
            else pointGradients[observation.index]+=gradient;
        }
        glm::dvec3 sum(0),angular(0);
        for(auto& entry:pointGradients){row.points.push_back({entry.first,entry.second});sum+=entry.second;angular+=glm::cross(positions[entry.first],entry.second);}
        for(auto& entry:bodyGradients){row.bodies.push_back({entry.first,entry.second.first,entry.second.second});sum+=entry.second.first;angular+=glm::cross(centers[entry.first],entry.second.first)+entry.second.second;}
        result.maximumPatchError=std::max(result.maximumPatchError,std::max(glm::length(sum),glm::length(angular)));
        row.maximumRate=0;result.rows.push_back(std::move(row));
    }
    return result;
}
}
namespace pressure_prototype {
inline MLSSystem BuildMLSCompressionRows(const std::vector<glm::dvec3>& positions,const std::vector<double>& volumes,
    const std::vector<SurfaceSample>& boundary,const std::vector<glm::dvec3>& centers,const Kernel& kernel) {
    auto result=BuildMLSRows(positions,volumes,boundary,centers,kernel);
    // The projection convention is G*v <= 0 with a nonnegative pressure.
    // Compression is -div(v); expansion must remain pressure-free.
    for(auto& row:result.rows){for(auto& g:row.points)g.gradient=-g.gradient;for(auto& g:row.bodies){g.linear=-g.linear;g.angular=-g.angular;}}
    return result;
}
}
