#pragma once
#include "RigidEqualitySpace.h"
// Model/Row/Body are the retained 3D affine pressure prototype types.
// Generalized rigid coordinates stay in body storage, never fluid cell mass.
struct NativeConstraintReduction {
    RigidEqualitySpace space;
    std::vector<Body> physical;
    NativeConstraintReduction(const std::vector<Stage5Body>& bodies,
                              const std::vector<Stage5Joint>& joints)
        :space(bodies,joints){
        for(const auto& b:bodies)
            physical.push_back({V(b.state->linearVelocity),V(b.state->angularVelocity),
                                b.inverseMass,b.inverseInertia});
    }
    Model Encode(const Model& original)const {
        Model encoded=original;
        encoded.bodies.assign(space.dimension/6,{V(0),V(0),1,M(1)});
        for(auto& row:encoded.rows){
            std::vector<double> gradient(space.dimension,0);
            for(auto g:row.bodies){
                row.maximumRate-=glm::dot(g.linear,space.baseLinear[g.body])+
                                 glm::dot(g.angular,space.baseAngular[g.body]);
                const auto raw=space.Gradient(g.body,g.linear,g.angular);
                for(unsigned a=0;a<space.dimension;++a)gradient[a]+=raw[a];
            }
            gradient=space.Null(gradient);row.bodies.clear();
            for(unsigned b=0;b<encoded.bodies.size();++b){
                const unsigned k=6*b;
                const V linear(gradient[k],gradient[k+1],gradient[k+2]);
                const V angular(gradient[k+3],gradient[k+4],gradient[k+5]);
                if(linear!=V(0)||angular!=V(0))row.bodies.push_back({b,linear,angular});
            }
        }
        return encoded;
    }
    std::vector<double> Decode(Model& encoded,const Model& original,
                                const std::vector<double>& pressure,unsigned jointRows)const {
        std::vector<double> coordinate(space.dimension,0),pressureImpulse(space.dimension,0);
        for(unsigned b=0;b<encoded.bodies.size();++b)for(unsigned a=0;a<3;++a){
            coordinate[6*b+a]=encoded.bodies[b].velocity[a];
            coordinate[6*b+3+a]=encoded.bodies[b].angularVelocity[a];
        }
        const auto response=space.Null(coordinate);
        for(unsigned i=0;i<original.rows.size();++i)for(auto g:original.rows[i].bodies){
            const auto raw=space.Gradient(g.body,g.linear,g.angular);
            for(unsigned a=0;a<space.dimension;++a)pressureImpulse[a]-=raw[a]*pressure.at(i);
        }
        auto jointImpulse=space.initial;
        for(unsigned a=0;a<space.dimension;++a)jointImpulse[a]+=response[a]-pressureImpulse[a];
        const auto dual=space.JointImpulses(jointImpulse,jointRows);
        encoded.bodies=physical;
        for(unsigned b=0;b<physical.size();++b){
            encoded.bodies[b].velocity=space.baseLinear[b]+space.Linear(b,response);
            encoded.bodies[b].angularVelocity=space.baseAngular[b]+space.Angular(b,response);
        }
        encoded.rows=original.rows;encoded.bilateral=original.bilateral;
        return dual;
    }
};
