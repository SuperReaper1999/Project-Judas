#include "PhysicsWorld.h"
#include "NativeNormalBridge.h"
#include "../fluid-coupling-stage5-kernel/MixedProjection.h"
#include <chrono>
#include <functional>
#include <cstdio>
#include <stdexcept>
namespace pp=pressure_prototype;
static std::function<bool(float,unsigned,const std::vector<Stage5Body>&,const std::vector<Stage5Normal>&,const std::vector<Stage5Joint>&)> project;
bool Stage5ParticipantEnabled(){return bool(project);}
bool Stage5ContactPressure(float h,unsigned i,const std::vector<Stage5Body>& b,const std::vector<Stage5Normal>& r,const std::vector<Stage5Joint>& j){return project?project(h,i,b,r,j):false;}
static unsigned checks=0;
void Check(bool condition,const char* message){++checks;if(!condition)throw std::runtime_error(message);}
void Run(const char* name,double fluidMass,bool floor,unsigned count,glm::vec3 up,
         double fluidVelocity=-1,double bodyVelocity=0,bool omitSupport=false,int jointMode=0) {
    PhysicsWorld world;world.Init();world.SetSleepingEnabled(false);
    const auto rotation=glm::normalize(glm::quat(1+up.y,up.z,0,-up.x));
    if(floor)world.CreateStaticBox(-.5f*up,rotation,{10,.5f,10},0,0);
    std::vector<BodyHandle> handles;
    for(unsigned i=0;i<count;++i){handles.push_back(world.CreateDynamicSphere((.5f+float(i))*up,.5f,80,0,0));world.SetLinearVelocity(handles.back(),float(bodyVelocity)*up);}
    JointHandle guide;
    if(jointMode){JointSettings settings;settings.bodyA=handles.back();
        settings.anchorB=world.GetCenterOfMass(handles.back());
        settings.type=jointMode==1?JointType::Fixed:JointType::Slider;
        if(jointMode==2) settings.frameA=settings.frameB=glm::angleAxis(1.57079632679f,glm::vec3(0,0,1));
        if(jointMode==3){settings.limits=true;settings.lower=settings.upper=0;}
        guide=world.CreateJoint(settings);Check(guide.IsValid(),"native guide creation failed");}
    double fluid=fluidVelocity,maximumResidual=0,maximumEnergy=0,support=0,pressure=0,ms=0;
    unsigned products=0,calls=0,normalRows=0;
    const double initialEnergy=.5*fluidMass*fluid*fluid+40*count*bodyVelocity*bodyVelocity;
    project=[&](float,unsigned,const auto& nativeBodies,const auto& nativeRows,const auto& nativeJoints){
        const auto start=std::chrono::steady_clock::now();++calls;normalRows+=nativeRows.size();
        std::vector<pp::Body> bodies;
        const auto ownerCenter=world.GetCenterOfMass(handles.back());
        unsigned owner=unsigned(nativeBodies.size());
        for(unsigned i=0;i<nativeBodies.size();++i){const auto& b=nativeBodies[i];
            bodies.push_back({glm::dvec3(b.state->linearVelocity),glm::dvec3(b.state->angularVelocity),b.inverseMass,b.inverseInertia});
            // Private fixture identifies the participant at its actual current
            // COM; native body IDs should be used by a production interface.
            if(b.state->position==ownerCenter&&b.inverseMass>0)owner=i;}
        Check(owner<bodies.size(),"native owner not present at batch boundary");
        std::vector<pp::Point> points{{glm::dvec3(up)*fluid,1/fluidMass}};
        pp::Row boundary;boundary.points.push_back({0,-glm::dvec3(up)});
        boundary.bodies.push_back({owner,glm::dvec3(up),glm::dvec3(0)});
        std::vector<pp::Row> rows{boundary};
        if(!omitSupport)for(const auto& n:nativeRows){pp::Row row;
            row.bodies.push_back({n.a,-n.normal,-glm::cross(n.armA,n.normal)});
            row.bodies.push_back({n.b,n.normal,glm::cross(n.armB,n.normal)});rows.push_back(row);}
        const auto jointBegin=rows.size();
        std::vector<bool> bilateral(rows.size(),false);
        std::vector<double> jointSigns;
        for(const auto& j:nativeJoints){
            const bool equality=std::isinf(j.low)&&std::isinf(j.high);
            const double sign=(j.high==0)?-1.:1.;
            pp::Row row;row.bodies.push_back({j.a,-sign*j.linearA,-sign*j.angularA});
            row.bodies.push_back({j.b,-sign*j.linearB,-sign*j.angularB});
            row.maximumRate=sign*j.bias;rows.push_back(row);bilateral.push_back(equality);jointSigns.push_back(sign);
        }
        const auto result=pp::ProjectMixed(points,bodies,rows,bilateral,32,1e-10);
        Check(result.converged,"reference pressure/contact batch failed convergence");products+=result.matrixProducts;
        pressure+=result.pressureImpulse[0];
        for(unsigned i=1;i<rows.size();++i)support+=result.pressureImpulse[i];
        // Commit the solved impulse sum once from the physical predictor.
        // The native contact duals and their velocity response are published
        // together, so no unmatched cache or repeated warm impulse remains.
        fluid=glm::dot(points[0].velocity,glm::dvec3(up));
        for(unsigned i=0;i<bodies.size();++i)if(nativeBodies[i].inverseMass>0){
            nativeBodies[i].state->linearVelocity=glm::vec3(bodies[i].velocity);
            nativeBodies[i].state->angularVelocity=glm::vec3(bodies[i].angularVelocity);}
        for(unsigned i=0;i<nativeRows.size();++i)*nativeRows[i].impulse=omitSupport?0:float(result.pressureImpulse[i+1]);
        for(unsigned i=0;i<nativeJoints.size();++i)*nativeJoints[i].impulse=float(jointSigns[i]*result.pressureImpulse[jointBegin+i]);
        ms+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return true;
    };
    auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(2,[](const auto&){},[&](const auto&){
        const double body=glm::dot(glm::dvec3(world.GetLinearVelocity(handles.back())),glm::dvec3(up));
        maximumResidual=std::max(maximumResidual,std::abs(std::min(fluid-body,(1/fluidMass+1./80)*pressure)));
        double energy=.5*fluidMass*fluid*fluid;
        for(auto h:handles){auto v=glm::dvec3(world.GetLinearVelocity(h)),w=glm::dvec3(world.GetAngularVelocity(h));energy+=40*glm::dot(v,v)+.5*glm::dot(w,glm::dmat3(world.GetInertiaWorld(h))*w);}
        maximumEnergy=std::max(maximumEnergy,energy);
    });
    for(unsigned step=0;step<30;++step)world.Step(1.f/60,&coupling);
    project={};
    const double body=glm::dot(glm::dvec3(world.GetLinearVelocity(handles.back())),glm::dvec3(up));
    std::printf("{\"name\":\"%s\",\"fluidMass\":%.17g,\"bodies\":%u,\"floor\":%s,\"omittedContactRows\":%s,\"fluidVelocity\":%.17g,\"bodyVelocity\":%.17g,\"maximumActualResidual\":%.17g,\"initialEnergy\":%.17g,\"maximumEnergy\":%.17g,\"pressureImpulse\":%.17g,\"contactImpulse\":%.17g,\"products\":%u,\"nativeRows\":%u,\"calls\":%u,\"projectionMilliseconds\":%.17g}\n",name,fluidMass,count,floor?"true":"false",omitSupport?"true":"false",fluid,body,maximumResidual,initialEnergy,maximumEnergy,pressure,support,products,normalRows,calls,ms);
    Check(maximumEnergy<=initialEnergy+1e-2,"native batch endpoint gained energy");
    if(!omitSupport)Check(maximumResidual<3e-5,"native batch completed interface residual failed");
    else Check(maximumResidual>.1,"omitted-contact negative control did not fail");
    if(!floor&&!jointMode)Check(std::abs(body-(fluidMass*fluidVelocity+80*count*bodyVelocity)/(fluidMass+80*count))<3e-5,"native batch free momentum failed");
    if(floor&&bodyVelocity>0&&fluidVelocity>0)Check(support<1e-8&&body>0,"native batch unilateral lift-off failed");
}
int main(){try{
 for(double mass:{15.625,1500.,8000.}){Run("supported",mass,true,1,{0,1,0});Run("free",mass,false,1,{0,1,0});}
 Run("lift-off",8000,true,1,{0,1,0},1,2);
 Run("support-chain-2",8000,true,2,{0,1,0});
 Run("support-chain-4",8000,true,4,{0,1,0});
 Run("rotated-support",8000,true,1,{0,0,1});
 Run("fixed-joint",8000,false,1,{0,1,0},-1,0,false,1);
 Run("vertical-slider-free",8000,false,1,{0,1,0},-1,0,false,2);
 Run("horizontal-slider-supported",8000,false,1,{0,1,0},-1,0,false,3);
 Run("missing-contact-negative",8000,true,1,{0,1,0},-1,0,true);
 std::printf("SUMMARY checks=%u failures=0 scope=private-frictionless-normal-reference\n",checks);return 0;
}catch(const std::exception& e){project={};std::fprintf(stderr,"FAIL after %u checks: %s\n",checks,e.what());return 1;}}
