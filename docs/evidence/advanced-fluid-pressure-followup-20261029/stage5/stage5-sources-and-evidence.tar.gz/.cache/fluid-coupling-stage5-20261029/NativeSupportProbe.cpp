#include "PhysicsWorld.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <stdexcept>

// Reduced physical normal-mass model, not a new runtime fluid backend.
// Fluid above a plate approaches downward. A compressive pressure impulse
// accelerates the fluid up and the plate down. The native floor alone owns
// its real contact, collision response, integration and contact bookkeeping.
struct Result {
    double fluid = -1, body = 0, positionError = 0;
    double residual = 0, energy = 0, momentum = 0, applied = 0;
    unsigned callbacks = 0, boundaries = 0;
};

Result Run(double fluidMass, bool floor, unsigned rounds, bool knownFixedMobility) {
    constexpr double bodyMass = 80;
    PhysicsWorld world;
    world.Init();
    if (floor) world.CreateStaticBox({0, -.5f, 0}, {10, .5f, 10}, 0, 0);
    const auto body = world.CreateDynamicSphere({0, .5f, 0}, .5f, float(bodyMass), 0, 0);
    Result result;
    auto coupling = PhysicsWorld::VelocityCoupling::ForEachSubstep(
        rounds,
        [&](const auto&) {
            const double bodyVelocity = world.GetLinearVelocity(body).y;
            // The free rigid mass is the exact two-way pressure operator when
            // there is no other constraint. The fixed-mobility control is an
            // analytic oracle ONLY for the known loaded support in this fixture.
            const double mobility = knownFixedMobility ? 0 : 1 / bodyMass;
            const double impulse = std::max(0., bodyVelocity-result.fluid) /
                                   (1/fluidMass+mobility);
            result.fluid += impulse/fluidMass;
            world.ApplyLinearImpulse(body, {0, -float(impulse), 0});
            result.applied += impulse;
            ++result.callbacks;
        },
        [&](const auto& phase) {
            const double velocity = world.GetLinearVelocity(body).y;
            const double residual = std::max(0., velocity-result.fluid);
            result.residual = std::max(result.residual, residual);
            ++result.boundaries;
            std::printf("{\"kind\":\"boundary\",\"fluidMass\":%.17g,\"floor\":%s,"
                        "\"rounds\":%u,\"fixedMobilityOracle\":%s,\"index\":%u,"
                        "\"fluidVelocity\":%.17g,\"bodyVelocity\":%.17g,"
                        "\"actualInterfaceResidual\":%.17g}\n",
                        fluidMass, floor?"true":"false", rounds,
                        knownFixedMobility?"true":"false", phase.index,
                        result.fluid, velocity, residual);
        });
    world.Step(1.f/60, &coupling);
    const auto velocity = world.GetLinearVelocity(body);
    result.body = velocity.y;
    result.positionError = double(world.GetTransform(body).position.y)-.5;
    result.energy = .5*fluidMass*result.fluid*result.fluid+
                    .5*bodyMass*double(glm::dot(velocity,velocity));
    result.momentum = fluidMass*result.fluid+bodyMass*result.body;
    std::printf("{\"kind\":\"result\",\"fluidMass\":%.17g,\"floor\":%s,"
                "\"rounds\":%u,\"fixedMobilityOracle\":%s,\"callbacks\":%u,"
                "\"boundaries\":%u,\"fluidVelocity\":%.17g,\"bodyVelocity\":%.17g,"
                "\"positionChange\":%.17g,\"maximumActualInterfaceResidual\":%.17g,"
                "\"initialEnergy\":%.17g,\"finalEnergy\":%.17g,"
                "\"initialMomentum\":%.17g,\"finalMomentum\":%.17g,"
                "\"pressureImpulse\":%.17g,\"interfaceContractPass\":%s}\n",
                fluidMass, floor?"true":"false", rounds,
                knownFixedMobility?"true":"false",result.callbacks,result.boundaries,
                result.fluid,result.body,result.positionError,result.residual,
                .5*fluidMass,result.energy,-fluidMass,result.momentum,result.applied,
                result.residual<=3e-7?"true":"false");
    return result;
}

int main() {
    try {
        const auto free = Run(8000, false, 2, false);
        const double expected = -8000./8080;
        if (free.residual > 3e-7 || std::abs(free.body-expected)>3e-7 ||
            std::abs(free.momentum+8000)>1e-3 || free.energy>4000+1e-3)
            throw std::runtime_error("free two-way control failed its analytic physical endpoint");
        for (double mass : {15.625, 1500., 8000.})
            for (unsigned rounds : {1u, 2u}) {
                const auto supported = Run(mass, true, rounds, false);
                if (std::abs(supported.body)>3e-7 || std::abs(supported.positionError)>1e-5)
                    throw std::runtime_error("native floor fixture does not independently hold the body");
                if (supported.residual<=3e-7)
                    throw std::runtime_error("expected composition failure was not reproduced");
            }
        const auto fixed = Run(8000, true, 2, true);
        if (fixed.residual>3e-7 || std::abs(fixed.body)>3e-7 || fixed.energy>1e-6)
            throw std::runtime_error("known-support exact-mobility oracle failed");
        const auto unsafe = Run(8000, false, 2, true);
        if (unsafe.energy<=4000*10)
            throw std::runtime_error("incorrect fixed-mobility negative control did not expose energy creation");
        std::puts("{\"kind\":\"scope\",\"diagnosticCompleted\":true,"
                  "\"genericFluidFixQualified\":false,\"nativeCadenceAndBudgetsChanged\":false,"
                  "\"note\":\"Real native support composition failures remain failures; "
                  "the fixture-specific mobility oracle is not a generic implementation.\"}");
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr,"probe fixture or control failed: %s\n",error.what());
        return 1;
    }
}
