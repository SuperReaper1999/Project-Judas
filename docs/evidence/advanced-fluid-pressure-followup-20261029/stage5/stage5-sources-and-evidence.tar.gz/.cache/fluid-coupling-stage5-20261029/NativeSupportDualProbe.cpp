#define main retained_stage5_v1_main
#include "NativeSupportProbe.cpp"
#undef main

namespace dual_probe {
struct State {
    double fluid = -1, impulse = 0, cached = 0;
    double maximumResidual = 0, maximumEnergy = 0;
};

State Run(double mass, bool floor, bool fixedMobility, unsigned rounds) {
    PhysicsWorld world;
    world.Init();
    if (floor) world.CreateStaticBox({0, -.5f, 0}, {10, .5f, 10}, 0, 0);
    const auto body = world.CreateDynamicSphere({0, .5f, 0}, .5f, 80, 0, 0);
    State state;
    state.maximumEnergy = .5*mass;
    auto apply = [&](double impulse) {
        state.fluid += impulse/mass;
        world.ApplyLinearImpulse(body, {0, -float(impulse), 0});
    };
    const double inverseMass = 1/mass+(fixedMobility?0:1./80);
    auto coupling = PhysicsWorld::VelocityCoupling::ForEachSubstep(
        rounds,
        [&](const auto& phase) {
            if (phase.iteration == 0) {
                // A native contact warm start must have its matching foreign
                // constraint warm state on BOTH sides. This is an iterative
                // guess, not new external momentum or permanent fluid work.
                state.impulse = state.cached;
                apply(state.impulse);
            }
            const double velocity = world.GetLinearVelocity(body).y;
            const double next = std::max(0., state.impulse+
                                              (velocity-state.fluid)/inverseMass);
            apply(next-state.impulse);
            state.impulse = next;
        },
        [&](const auto& phase) {
            const auto velocity = world.GetLinearVelocity(body);
            const double separationSpeed = state.fluid-double(velocity.y);
            // Check actual completed native state, including complementarity,
            // rather than only positive approach or the callback's own iterate.
            const double residual = std::abs(std::min(separationSpeed,
                                                      inverseMass*state.impulse));
            const double energy = .5*mass*state.fluid*state.fluid+
                                  40*double(glm::dot(velocity,velocity));
            state.maximumResidual = std::max(state.maximumResidual,residual);
            state.maximumEnergy = std::max(state.maximumEnergy,energy);
            std::printf("{\"kind\":\"dual-boundary\",\"fluidMass\":%.17g,"
                        "\"floor\":%s,\"fixedMobilityOracle\":%s,\"rounds\":%u,"
                        "\"index\":%u,\"fluidVelocity\":%.17g,\"bodyVelocity\":%.17g,"
                        "\"pressureImpulse\":%.17g,\"actualComplementarityResidual\":%.17g,"
                        "\"physicalEnergy\":%.17g}\n",mass,floor?"true":"false",
                        fixedMobility?"true":"false",rounds,phase.index,
                        state.fluid,double(velocity.y),state.impulse,residual,energy);
            state.cached = state.impulse;
        });
    world.Step(1.f/60,&coupling);
    std::printf("{\"kind\":\"dual-result\",\"fluidMass\":%.17g,\"floor\":%s,"
                "\"fixedMobilityOracle\":%s,\"rounds\":%u,\"fluidVelocity\":%.17g,"
                "\"bodyVelocity\":%.17g,\"positionChange\":%.17g,"
                "\"initialEnergy\":%.17g,\"maximumPhysicalEnergy\":%.17g,"
                "\"maximumActualComplementarityResidual\":%.17g,\"interfaceContractPass\":%s}\n",
                mass,floor?"true":"false",fixedMobility?"true":"false",rounds,state.fluid,
                double(world.GetLinearVelocity(body).y),double(world.GetTransform(body).position.y)-.5,
                .5*mass,state.maximumEnergy,state.maximumResidual,
                state.maximumResidual<=3e-7?"true":"false");
    return state;
}
}

int main() {
    try {
        // Retain the actual failed implementation with the same library and
        // conditions. This is not a new legacy-PBF application reproduction.
        const auto naiveFixed = Run(8000,true,2,true);
        if (naiveFixed.energy<=4000*10)
            throw std::runtime_error("increment-only energy failure no longer reproduces");
        const auto free = dual_probe::Run(8000,false,false,2);
        if (free.maximumResidual>3e-7 || free.maximumEnergy>4000+1e-3)
            throw std::runtime_error("dual free-body physical control failed");
        for (double mass : {15.625,1500.,8000.})
            dual_probe::Run(mass,true,false,2);
        dual_probe::Run(8000,true,true,1);
        const auto exactSupport = dual_probe::Run(8000,true,true,2);
        if (exactSupport.maximumResidual>3e-7 || exactSupport.maximumEnergy>4000+1e-3)
            throw std::runtime_error("dual known-support oracle failed within native two-sweep budget");
        const auto unsafe = dual_probe::Run(8000,false,true,2);
        if (unsafe.maximumResidual<=3e-7)
            throw std::runtime_error("wrong support mobility was not detected by actual-state KKT check");
        std::puts("{\"kind\":\"scope\",\"diagnosticCompleted\":true,"
                  "\"genericFluidFixQualified\":false,\"nativeCadenceAndBudgetsChanged\":false,"
                  "\"note\":\"Dual accounting is necessary; ordinary free-body mobility "
                  "still fails supported cases. Known-support control is not a generic fix.\"}");
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr,"dual probe control failed: %s\n",error.what());
        return 1;
    }
}
