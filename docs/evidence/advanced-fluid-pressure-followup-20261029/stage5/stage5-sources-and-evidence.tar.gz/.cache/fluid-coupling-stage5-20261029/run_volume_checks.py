from pathlib import Path
import sys,subprocess,json
root=Path.cwd();here=root/'.cache/fluid-coupling-stage5-20261029';kernel=root/'.cache/fluid-coupling-stage5-kernel'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as b
impl=b.compile(kernel/'VolumeDomain.cpp','stage5-exact-volume-domain')
cases=[(here/'ExactTransferTests.cpp','stage5-exact-transfer'),(kernel/'VolumeDomainTests.cpp','stage5-volume-tests'),(kernel/'OwnedCapacityTests.cpp','stage5-owned-capacity'),(kernel/'SubcellOwnershipTests.cpp','stage5-subcells')]
results=[]
for source,name in cases:
 if not source.exists():continue
 with (here/(name+'-build.log')).open('w') as log:
  oldout,olderr=sys.stdout,sys.stderr
  obj=b.compile(source,name);b.executable(obj,name,impl)
 with (here/(name+'.log')).open('w') as log:
  run=subprocess.run([str(b.out/name)],stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':run.returncode});print(results[-1],flush=True)
(here/'VOLUME_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
if any(x['exit'] for x in results):raise SystemExit(1)
