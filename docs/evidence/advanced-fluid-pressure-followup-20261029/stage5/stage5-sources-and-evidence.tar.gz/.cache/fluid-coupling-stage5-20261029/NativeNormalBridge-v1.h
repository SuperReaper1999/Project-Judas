#pragma once
#include "RigidBody.h"
#include <vector>
// Private reference bridge, not a production API or persistent pointer store.
struct Stage5Body { RigidBody* state; double inverseMass; glm::dmat3 inverseInertia; };
struct Stage5Normal { unsigned a,b; glm::dvec3 normal,armA,armB; float* impulse; };
bool Stage5ContactPressure(float,unsigned,const std::vector<Stage5Body>&,
                          const std::vector<Stage5Normal>&);
