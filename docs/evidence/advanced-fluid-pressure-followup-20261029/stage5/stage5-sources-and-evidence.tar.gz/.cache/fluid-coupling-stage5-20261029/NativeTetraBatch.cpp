#define main retained_tetra_unit_main
#include "../fluid-coupling-stage5-kernel/TetraPressureTests.cpp"
#undef main
#include "PhysicsWorld.h"
#include "NativeNormalBridge.h"
#include "NativeConstraintReduction.h"
#include <functional>
static std::function<bool(float,unsigned,const std::vector<Stage5Body>&,const std::vector<Stage5Normal>&,const std::vector<Stage5Joint>&)> tetraProject;
bool Stage5ParticipantEnabled(){return bool(tetraProject);}
bool Stage5ContactPressure(float h,unsigned i,const std::vector<Stage5Body>& b,const std::vector<Stage5Normal>& r,const std::vector<Stage5Joint>& j){return tetraProject?tetraProject(h,i,b,r,j):false;}
static unsigned checked=0;
static void Require(bool yes,const char* what){++checked;if(!yes)throw std::runtime_error(what);}
void RunTetra(double mass,float angle,bool omitJoints=false){
 Model fluid;BuildTetra(fluid,false,.37,.25);
 const glm::quat q=glm::angleAxis(angle,glm::normalize(glm::vec3(1,-2,3)));
 const glm::dquat turn=glm::normalize(glm::dquat(q));const V up=turn*V(0,1,0);
 fluid.frame=glm::mat3_cast(turn);
 for(auto& row:fluid.rows){for(auto& g:row.points)g.gradient=turn*g.gradient;for(auto& g:row.bodies){g.linear=turn*g.linear;g.angular=turn*g.angular;}}
 PhysicsWorld world;world.Init();world.SetSleepingEnabled(false);
 const auto center=glm::vec3(turn*fluid.center);
 auto body=world.CreateDynamicBox(center,glm::vec3(.125f),float(mass),0,0);
 const auto spin=glm::angleAxis(.37f,glm::normalize(glm::vec3(1,2,-.3)));
 world.ResetBody(body,center,q*spin);
 JointSettings settings;settings.bodyA=body;settings.anchorB=center;
 auto joint=world.CreateJoint(settings);Require(joint.IsValid(),"fixed joint fixture failed");
 const auto baseRows=fluid.rows;const auto baseFlags=fluid.bilateral;
 SparseWorkspace workspace;unsigned calls=0;double maxResidual=0,maxNativeResidual=0,maxSpeed=0,maxEnergyRise=0;
 V fluidImpulse(0),jointImpulse(0);std::vector<double> times;
 tetraProject=[&](float h,unsigned,const auto& nativeBodies,const auto& nativeRows,const auto& nativeJoints){
  const auto start=std::chrono::steady_clock::now();++calls;
  Require(nativeRows.empty(),"immersed guide fixture unexpectedly has a solid contact");
  auto trial=fluid;trial.rows=baseRows;trial.bilateral=baseFlags;trial.bodies.clear();
  unsigned owner=unsigned(nativeBodies.size());
  for(unsigned i=0;i<nativeBodies.size();++i){auto& b=nativeBodies[i];
   trial.bodies.push_back({V(b.state->linearVelocity),V(b.state->angularVelocity),b.inverseMass,b.inverseInertia});
   if(b.state->position==world.GetCenterOfMass(body)&&b.inverseMass>0)owner=i;}
  Require(owner<trial.bodies.size(),"immersed owner missing at native boundary");
  for(auto& row:trial.rows)for(auto& g:row.bodies)g.body=owner;
  for(const auto& cell:trial.cells)trial.points[cell.first].velocity-=up*(9.81*double(h));
  const auto physicalModel=trial;
  const auto& constraints=omitJoints?std::vector<Stage5Joint>{}:nativeJoints;
  const NativeConstraintReduction reduction(nativeBodies,constraints);
  trial=reduction.Encode(physicalModel);
  const auto energy=[](const Model& m){double e=0;
   for(const auto& p:m.points)e+=.5*glm::dot(p.velocity,p.velocity)/p.inverseMass;
   for(const auto& b:m.bodies)if(b.inverseMass>0)e+=.5*glm::dot(b.velocity,b.velocity)/b.inverseMass+.5*glm::dot(b.angularVelocity,glm::inverse(b.inverseInertia)*b.angularVelocity);
   return e;};
  auto originalPhysical=fluid;originalPhysical.bodies=reduction.physical;
  for(const auto& cell:originalPhysical.cells)originalPhysical.points[cell.first].velocity-=up*(9.81*double(h));
  const double before=energy(originalPhysical);
  const auto solved=ProjectFluidPressure(trial,64,1e-10,&workspace);
  Require(solved.converged,"3D pressure/native joint projection failed");
  maxResidual=std::max(maxResidual,solved.maximumResidual);
  const auto dual=reduction.Decode(trial,physicalModel,solved.pressureImpulse,constraints.size());
  for(unsigned i=0;i<baseRows.size();++i)for(auto g:physicalModel.rows[i].bodies)if(g.body==owner)fluidImpulse-=g.linear*solved.pressureImpulse[i];
  for(unsigned i=0;i<nativeJoints.size();++i){double impulse=omitJoints?0:dual[i];*nativeJoints[i].impulse=float(impulse);jointImpulse+=nativeJoints[i].linearA*impulse;}
  maxEnergyRise=std::max(maxEnergyRise,energy(trial)-before);
  for(unsigned i=0;i<trial.bodies.size();++i)if(nativeBodies[i].inverseMass>0){nativeBodies[i].state->linearVelocity=glm::vec3(trial.bodies[i].velocity);nativeBodies[i].state->angularVelocity=glm::vec3(trial.bodies[i].angularVelocity);}
  fluid.points=std::move(trial.points);
  times.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count());return true;
 };
 auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(2,[](const auto&){},[&](const auto&){
  const V v(world.GetLinearVelocity(body)),w(world.GetAngularVelocity(body));maxSpeed=std::max(maxSpeed,glm::length(v));
  for(const auto& row:baseRows){double r=-row.maximumRate;for(auto g:row.points)r+=glm::dot(g.gradient,fluid.points[g.point].velocity);for(auto g:row.bodies)r+=glm::dot(g.linear,v)+glm::dot(g.angular,w);
   // A positive inequality violation is sufficient for the deliberately
   // omitted-joint control. Positive-pressure separation is checked by the
   // projection and the independent hydrostatic force/endpoint oracle below.
   maxNativeResidual=std::max(maxNativeResidual,std::max(0.,r));}
 });
 const unsigned ticks=omitJoints?1:120;const float dt=1.f/60;
 for(unsigned tick=0;tick<ticks;++tick){world.ApplyLinearAcceleration(body,-9.81f*glm::vec3(up),dt);world.Step(dt,&coupling);}
 tetraProject={};
 const double expected=15.625*9.81*double(dt)*ticks,expectedJoint=(mass-15.625)*9.81*double(dt)*ticks;
 JointState observed;Require(world.GetJoint(joint,observed),"joint reaction observation disappeared");
 const double actualJoint=glm::dot(V(observed.reactionImpulse),up);
 const double displacement=glm::length(world.GetTransform(body).position-center);
 std::sort(times.begin(),times.end());
 std::printf("{\"kind\":\"tetra-native-batch\",\"mass\":%.17g,\"angle\":%.9g,\"omittedJointRows\":%s,\"intervals\":%u,\"tets\":%zu,\"projectionResidual\":%.17g,\"actualNativeClosingResidual\":%.17g,\"maximumBodySpeed\":%.17g,\"displacement\":%.17g,\"maximumProjectionEnergyRise\":%.17g,\"fluidLoad\":%.17g,\"expectedFluidLoad\":%.17g,\"jointLoad\":%.17g,\"expectedJointLoad\":%.17g,\"lastNativeJointImpulse\":%.17g,\"expectedLastJointImpulse\":%.17g,\"medianMilliseconds\":%.17g,\"p95Milliseconds\":%.17g,\"worstMilliseconds\":%.17g}\n",mass,angle,omitJoints?"true":"false",calls,fluid.cells.size(),maxResidual,maxNativeResidual,maxSpeed,displacement,maxEnergyRise,glm::dot(fluidImpulse,up),expected,glm::dot(jointImpulse,up),expectedJoint,actualJoint,expectedJoint/ticks,times[times.size()/2],times[unsigned(std::ceil(.95*times.size()))-1],times.back());
 Require(calls==ticks*4,"native chronology missing intervals");
 Require(maxEnergyRise<1e-8,"3D batch projection created energy");
 if(!omitJoints){Require(maxSpeed<1e-5&&displacement<1e-5,"native fixed body actual endpoint moved");
  Require(std::abs(glm::dot(fluidImpulse,up)-expected)<.001,"3D batch lost Archimedes force");
  Require(std::abs(glm::dot(jointImpulse,up)-expectedJoint)<.001,"3D batch lost native support load");
  Require(std::abs(actualJoint-expectedJoint/ticks)<1e-4,"native cached reaction disagrees with physical joint load");}
 else Require(maxNativeResidual>1e-5||std::abs(glm::dot(fluidImpulse,up)-expected)>1e-3,"omitted-joint negative control did not expose missing mechanism");
}
int main(){try{for(float angle:{0.f,1.13f})for(double mass:{1.,80.})RunTetra(mass,angle);
 RunTetra(80,0,true);std::printf("SUMMARY checks=%u failures=0 scope=fixed-geometry-3D-native-joint-reference\n",checked);return 0;
}catch(const std::exception& e){tetraProject={};std::fprintf(stderr,"FAIL after %u checks: %s\n",checked,e.what());return 1;}}
