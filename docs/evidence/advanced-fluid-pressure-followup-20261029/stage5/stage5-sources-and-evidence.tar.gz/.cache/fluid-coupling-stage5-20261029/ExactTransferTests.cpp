#include "../fluid-coupling-stage5-kernel/VolumeDomain.h"
#include "../fluid-coupling-stage5-kernel/ExactPlanePredicates.h"
#include <cstdio>
#include <limits>
using namespace fluid_domain;
static unsigned checks=0;
void Check(bool yes,const char* what){++checks;if(!yes)throw std::runtime_error(what);}
int main(){try{
 const Key a{0,0,0},b{1,0,0};const auto cube=LiquidBox({0,0,0},{1,1,1});
 const double old=7.9067233157129281e-09,target=2.4588887613113886e-08;
 VolumeDomain d(1);std::string error;
 Check(d.Add(a,cube,.5,{0,1,0},error)&&d.Add(b,cube,old,{0,1,0},error),"rounding fixture setup");
 const auto before=fluid_exact::Sum(d.Find(a)->quantity,d.Find(b)->quantity);
 auto capacity=std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{1,target,1}));
 double measured=0;Check(d.MeasureCapacity(*capacity,measured,error)&&measured==target,"original physical capacity not reproduced");
 const double rounded=target-old;
 Check(old+rounded>target,"original scalar flux rounding failure no longer reproduced");
 Check(!d.Advance({{a,b,rounded}},{{b,capacity}},error),"genuine scalar sub-ulp overcapacity was hidden");
 Check(d.Find(b)->volume==old&&d.Find(a)->volume==.5,"failed scalar transaction mutated ledger");
 for(unsigned step=0;step<1000;++step){
  const double endpoint=step%2?old:target;
  auto exact=fluid_exact::Sum({endpoint},fluid_exact::Negate(d.Find(b)->quantity));
  const int sign=fluid_exact::Sign(exact);Check(sign!=0,"repeat transfer unexpectedly zero");
  auto amount=sign>0?exact:fluid_exact::Negate(exact);
  const Transfer transfer{sign>0?a:b,sign>0?b:a,fluid_exact::Estimate(amount),amount};
  auto geometry=std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{1,endpoint,1}));
  Check(d.Advance({transfer},{{b,geometry}},error),"exact paired flux or wet topology rejected");
  Check(d.Find(b)->volume==endpoint,"exact target quantity changed");
  Check(fluid_exact::Sign(fluid_exact::Sum(d.Find(b)->quantity,{-endpoint}))==0,"exact target expansion differs");
  const auto after=fluid_exact::Sum(d.Find(a)->quantity,d.Find(b)->quantity);
  Check(fluid_exact::Sign(fluid_exact::Sum(after,fluid_exact::Negate(before)))==0,"paired transfer created or destroyed exact quantity");
 }
 {VolumeDomain full(1);Check(full.Add(a,cube,.5,{0,1,0},error)&&full.Add(b,cube,.5,{0,1,0},error),"hidden overflow fixture");
  auto half=std::make_shared<const LiquidGeometry>(LiquidBox({0,0,0},{1,1,1}));
  const Transfer excess{a,b,.5,{.5,std::ldexp(1.,-100)}};
  Check(!full.Advance({excess},{{b,half}},error),"hidden exact overcapacity or outflow accepted");
  Check(full.Find(a)->volume==.5&&full.Find(b)->volume==.5,"hidden overflow mutated state");
  Check(!full.Advance({{a,b,.25,{.125}}},{},error),"mismatched scalar/exact transfer accepted");
  Check(!full.Advance({{a,b,.25,{std::numeric_limits<double>::quiet_NaN()}}},{},error),"nonfinite exact transfer accepted");
 }
 {VolumeDomain invalid(1);
  Check(!invalid.Add(a,cube,std::numeric_limits<double>::infinity(),{0,1,0},error),"infinite initial volume accepted");
  Check(!invalid.Add(a,cube,std::numeric_limits<double>::quiet_NaN(),{0,1,0},error),"NaN initial volume accepted");
  Check(invalid.Size()==0,"invalid initial volume published state");}
 {VolumeDomain signedParts(1);Check(signedParts.Add(a,cube,.5,{0,1,0},error)&&signedParts.Add(b,cube,.25,{0,1,0},error),"signed expansion fixture");
  Check(signedParts.Advance({{a,b,.25,{.25,-std::ldexp(1.,-100)}}},{},error),"positive flux with a negative low component rejected");
  auto expected=fluid_exact::Sum({.5},{-std::ldexp(1.,-100)});
  Check(fluid_exact::Sign(fluid_exact::Sum(signedParts.Find(b)->quantity,fluid_exact::Negate(expected)))==0,"signed expansion flux lost its residual");}
 std::printf("SUMMARY checks=%u failures=0 scalarFailurePreserved=true exactQuantityConserved=true\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks: %s\n",checks,e.what());return 1;}}
