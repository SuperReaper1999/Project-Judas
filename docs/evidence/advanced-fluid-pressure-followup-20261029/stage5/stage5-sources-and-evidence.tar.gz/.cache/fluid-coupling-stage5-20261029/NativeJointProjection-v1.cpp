#include "PhysicsWorld.h"
#include "Narrowphase.h"
#include "../fluid-pressure-coupling/PressureProjection.h"
#include <chrono>
#include <functional>
#include <cstdio>
#include <stdexcept>

static std::function<void(float,unsigned)> predictor;
void Stage5PhysicalPredictor(float h,unsigned step) { if(predictor) predictor(h,step); }
namespace pp=pressure_prototype;
static unsigned checks=0;
void Check(bool condition,const char* message) {++checks;if(!condition)throw std::runtime_error(message);}
struct Metrics {double residual=0,energy=0,pressure=0,support=0,milliseconds=0;unsigned products=0,contacts=0;};
Metrics Run(const char* name,double fluidMass,bool floor,unsigned count,glm::vec3 up,
            double fluidVelocity=-1,double bodyVelocity=0,bool omitSupport=false) {
    PhysicsWorld world; world.Init(); world.SetSleepingEnabled(false);
    const auto rotation=glm::rotation(glm::vec3(0,1,0),up);
    if(floor) {
        const auto ground=world.CreateStaticBox(-.5f*up,{10,.5f,10},0,0);
        auto pose=world.GetTransform(ground);pose.orientation=rotation;world.SetTransform(ground,pose);
    }
    std::vector<BodyHandle> handles;
    for(unsigned i=0;i<count;++i) {
        handles.push_back(world.CreateDynamicSphere((.5f+float(i))*up,.5f,80,0,0));
        world.SetLinearVelocity(handles.back(),float(bodyVelocity)*up);
    }
    double fluid=fluidVelocity;Metrics m;
    const double initialEnergy=.5*fluidMass*fluid*fluid+40*count*bodyVelocity*bodyVelocity;
    predictor=[&](float,unsigned) {
        const auto start=std::chrono::steady_clock::now();
        std::vector<pp::Point> points{{glm::dvec3(up)*fluid,1/fluidMass}};
        std::vector<pp::Body> bodies;
        for(auto handle:handles) bodies.push_back({glm::dvec3(world.GetLinearVelocity(handle)),
            glm::dvec3(world.GetAngularVelocity(handle)),1./world.GetMass(handle),
            glm::inverse(glm::dmat3(world.GetInertiaWorld(handle)))});
        pp::Row pressure;
        pressure.points.push_back({0,-glm::dvec3(up)});
        pressure.bodies.push_back({count-1,glm::dvec3(up),glm::dvec3(0)});
        std::vector<pp::Row> rows{pressure};
        auto index=[&](BodyHandle h)->int {for(unsigned i=0;i<count;++i)if(handles[i].id==h.id)return int(i);return -1;};
        // This bounded reference uses actual narrowphase geometry. No names,
        // grounded flags, ray guesses, or replacement infinite body masses.
        if(!omitSupport)for(const auto& pair:world.FindCollidingPairs()) {
            int ia=index(pair.a),ib=index(pair.b);if(ia<0&&ib<0)continue;
            Shape sa,sb;BodyTransform ta,tb;
            Check(world.GetBodyShape(pair.a,sa,ta)&&world.GetBodyShape(pair.b,sb,tb),"shape snapshot failed");
            RigidBody a,b;a.position=ta.position;a.orientation=ta.orientation;
            b.position=tb.position;b.orientation=tb.orientation;
            auto contacts=ComputeContacts(sa,a,sb,b);
            for(int k=0;k<contacts.count;++k) {
                const auto& c=contacts.points[k];if(!c.hit)continue;
                pp::Row row;const glm::dvec3 n(c.preciseNormal);
                const glm::dvec3 normal=glm::length(n)>0?n:glm::dvec3(c.normal);
                if(ia>=0)row.bodies.push_back({unsigned(ia),-normal,
                    -glm::cross(glm::dvec3(c.point-world.GetCenterOfMass(pair.a)),normal)});
                if(ib>=0)row.bodies.push_back({unsigned(ib),normal,
                    glm::cross(glm::dvec3(c.point-world.GetCenterOfMass(pair.b)),normal)});
                rows.push_back(row);++m.contacts;
            }
        }
        const auto projected=pp::Project(points,bodies,rows,32,1e-10);
        Check(projected.converged,"reference joint pressure/contact projection did not converge");
        m.products+=projected.matrixProducts;m.pressure+=projected.pressureImpulse[0];
        for(unsigned r=1;r<rows.size();++r)m.support+=projected.pressureImpulse[r];
        // Publish only the foreign pressure impulse. Native MK2 retains its
        // contact impulses, warm caches, response, pose integration and CCD.
        const double impulse=projected.pressureImpulse[0];
        fluid+=impulse/fluidMass;
        world.ApplyLinearImpulse(handles.back(),-float(impulse)*up);
        m.milliseconds+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    };
    auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(2,[](const auto&){},[&](const auto&){
        const double body=glm::dot(glm::dvec3(world.GetLinearVelocity(handles.back())),glm::dvec3(up));
        const double residual=std::abs(std::min(fluid-body,(1/fluidMass+1./80)*m.pressure));
        m.residual=std::max(m.residual,residual);
        double energy=.5*fluidMass*fluid*fluid;
        for(auto handle:handles){const auto v=glm::dvec3(world.GetLinearVelocity(handle));
            const auto w=glm::dvec3(world.GetAngularVelocity(handle));
            energy+=40*glm::dot(v,v)+.5*glm::dot(w,glm::dmat3(world.GetInertiaWorld(handle))*w);}
        m.energy=std::max(m.energy,energy);
    });
    for(unsigned step=0;step<30;++step)world.Step(1.f/60,&coupling);
    predictor={};
    const double body=glm::dot(glm::dvec3(world.GetLinearVelocity(handles.back())),glm::dvec3(up));
    std::printf("{\"name\":\"%s\",\"fluidMass\":%.17g,\"bodies\":%u,\"floor\":%s,\"omittedContacts\":%s,\"fluidVelocity\":%.17g,\"bodyVelocity\":%.17g,\"maximumResidual\":%.17g,\"initialEnergy\":%.17g,\"maximumEnergy\":%.17g,\"pressureImpulse\":%.17g,\"contactImpulse\":%.17g,\"products\":%u,\"actualContacts\":%u,\"projectionMilliseconds\":%.17g}\n",
        name,fluidMass,count,floor?"true":"false",omitSupport?"true":"false",fluid,body,m.residual,
        initialEnergy,m.energy,m.pressure,m.support,m.products,m.contacts,m.milliseconds);
    Check(m.energy<=initialEnergy+1e-2,"actual native endpoint gained physical energy");
    if(!omitSupport)Check(m.residual<3e-5,"actual completed native pressure/contact boundary failed");
    else Check(m.residual>.1,"missing-contact negative control did not detect failure");
    if(!floor)Check(std::abs(body-(fluidMass*fluidVelocity+80*count*bodyVelocity)/(fluidMass+80*count))<3e-5,
                    "free control lost linear momentum");
    if(floor&&bodyVelocity>0&&fluidVelocity>0)Check(m.support<1e-8&&body>0,"unilateral support wrongly prevents lift off");
    return m;
}
int main(){try {
    for(double mass:{15.625,1500.,8000.}) {
        Run("supported",mass,true,1,{0,1,0});Run("free",mass,false,1,{0,1,0});
    }
    Run("lift-off",8000,true,1,{0,1,0},1,2);
    Run("support-chain",8000,true,2,{0,1,0});
    Run("rotated-support",8000,true,1,{0,0,1});
    Run("missing-support-negative",8000,true,1,{0,1,0},-1,0,true);
    std::printf("SUMMARY checks=%u failures=0 scope=bounded-normal-reference-not-runtime-fluid\n",checks);return 0;
}catch(const std::exception& e){predictor={};std::fprintf(stderr,"FAIL after %u checks: %s\n",checks,e.what());return 1;}}
