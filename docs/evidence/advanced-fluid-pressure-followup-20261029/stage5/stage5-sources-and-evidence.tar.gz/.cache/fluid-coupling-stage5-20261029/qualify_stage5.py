from pathlib import Path
import argparse,subprocess,shlex,json,hashlib,datetime,time,platform,os
parser=argparse.ArgumentParser();parser.add_argument('--build-dir',default='build');args=parser.parse_args()
root=Path.cwd();here=root/'.cache/fluid-coupling-stage5-20261029';kernel=root/'.cache/fluid-coupling-stage5-kernel';baseline=root/'.cache/fluid-coupling-stage5-baseline-kernel';build=(root/args.build_dir).resolve()
output=here/'final';output.mkdir(exist_ok=True)
flags={}
for line in (build/'CMakeFiles/judas_script_tests.dir/flags.make').read_text().splitlines():
 if ' = ' in line:
  key,value=line.split(' = ',1);flags[key]=shlex.split(value)
compileFlags=flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']
link=[x for x in shlex.split((build/'CMakeFiles/judas_script_tests.dir/link.txt').read_text()) if not x.startswith('-Wl,--dependency-file=')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
commands=[]
def invoke(command,log,cwd=root,timeout=120):
 commands.append({'argv':command,'cwd':str(cwd),'log':str(log.relative_to(here))})
 with log.open('w') as stream:return subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout).returncode
def compile(source,name):
 obj=output/(name+'.o');command=['/usr/bin/c++',*compileFlags,'-c',str(source),'-o',str(obj)]
 if invoke(command,output/(name+'-compile.log')):raise RuntimeError('compile failed: '+name)
 return obj
def executable(source,name,extras=()):
 obj=compile(source,name);command=[str(obj) if x.endswith('/tests/ScriptTests.cpp.o') else x for x in link]
 command[command.index('-o')+1]=str(output/name);at=command.index(str(obj))+1;command[at:at]=[str(x) for x in extras]
 if invoke(command,output/(name+'-link.log'),build):raise RuntimeError('link failed: '+name)
 return output/name
info={'schema':1,'timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Private pressure/contact/joint numerical prototypes. Not a runtime fluid fix or final-source engine qualification.','engineLibrary':{'path':str(build/'libjudas_engine.a'),'sha256':sha(build/'libjudas_engine.a'),'buildIdentity':json.loads((build/'judas-build-info-Release.json').read_text())},'host':{'platform':platform.platform(),'cpu':subprocess.check_output(['lscpu'],text=True)},'results':[]}
def save():
 info['commands']=commands
 (here/'FINAL_RESULTS.json').write_text(json.dumps(info,indent=2)+'\n')
def run(exe,name,argv=(),expected=0,failures=None):
 log=output/(name+'.log');start=time.monotonic();code=invoke([str(exe),*argv],log)
 text=log.read_text();reasonLines=[line for line in text.splitlines() if line.startswith('FAIL ')]
 accepted=code==expected and (failures is None or len(reasonLines)==failures)
 record={'name':name,'arguments':list(argv),'exit':code,'expectedExit':expected,'knownFailureCount':len(reasonLines),'expectationMet':accepted,'seconds':time.monotonic()-start,'binarySha256':sha(exe),'log':str(log.relative_to(here)),'logSha256':sha(log)}
 info['results'].append(record);save();print(json.dumps(record),flush=True)
 if not accepted:raise RuntimeError('unexpected result: '+name)
 return text
native=compile(here/'WorldMk2Batch.cpp','native-batch')
volume=compile(kernel/'VolumeDomain.cpp','exact-volume')
oldVolume=compile(baseline/'VolumeDomain.cpp','baseline-volume')
programs=[(here/'RigidEqualitySpaceTests.cpp','rigid-space',[],0,None),(here/'NativeBatchProjection.cpp','native-batch-reference',[native],0,None),(here/'NativeTetraBatch.cpp','tetra-batch',[native,volume],0,None),(here/'NativeTetraContactBatch.cpp','tetra-contact',[native,volume],0,None),(here/'ExactTransferTests.cpp','exact-transfers',[volume],0,None),(kernel/'OwnedCapacityTests.cpp','owned-capacity',[volume],0,None),(kernel/'SubcellOwnershipTests.cpp','subcell-ownership',[volume],0,None),(kernel/'FiniteFrontTests.cpp','finite-front',[volume],0,None),(kernel/'ConformingAleWindTests.cpp','conforming-wind',[volume],0,None),(kernel/'ReferenceAleTests.cpp','reference-ale',[volume],0,None),(baseline/'VolumeDomainTests.cpp','baseline-raw-geometry',[oldVolume],1,9),(kernel/'VolumeDomainTests.cpp','candidate-raw-geometry',[volume],1,9)]
for source,name,extras,expected,failures in programs:
 exe=executable(source,name,extras);run(exe,name,expected=expected,failures=failures)
exe=executable(here/'NativeAleBatch.cpp','native-ale-batch',[native,volume])
run(exe,'native-ale-480',['120']);run(exe,'native-ale-incoming-960',['240','--incoming-current'])
ordinary=executable(here/'NativeDisabledTrajectory.cpp','ordinary-native-trajectory')
reference=executable(here/'NativeDisabledTrajectory.cpp','disabled-native-trajectory',[native])
first=run(ordinary,'ordinary-native-trajectory');second=run(reference,'disabled-native-trajectory')
if first!=second:raise RuntimeError('disabled private bridge changed actual physical trajectories')
info['disabledTrajectoryByteIdentical']=True
print('FINAL expectations met; original raw-geometry nine failures retained, not counted as corrected.',flush=True)
save()
