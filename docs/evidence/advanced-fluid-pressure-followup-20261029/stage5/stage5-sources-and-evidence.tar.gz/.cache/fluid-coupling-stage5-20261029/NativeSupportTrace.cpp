#include "PhysicsWorld.h"
#include <algorithm>
#include <cstdio>

void Trace(bool dual) {
    PhysicsWorld world;
    world.Init();
    world.CreateStaticBox({0,-.5f,0},{10,.5f,10},0,0);
    const auto body=world.CreateDynamicSphere({0,.5f,0},.5f,80,0,0);
    double fluid=-1,lambda=0,cached=0,published=0;
    auto apply=[&](double impulse) {
        fluid+=impulse/8000;
        world.ApplyLinearImpulse(body,{0,-float(impulse),0});
    };
    auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(2,
        [&](const auto& phase) {
            const double nativeBefore=world.GetLinearVelocity(body).y;
            const double fluidBefore=fluid;
            if(dual&&phase.iteration==0){lambda=cached;apply(lambda);}
            const double afterForeignWarm=world.GetLinearVelocity(body).y;
            const double next=dual?std::max(0.,lambda+(afterForeignWarm-fluid)*8000):
                                   std::max(0.,(nativeBefore-fluid)*8000);
            const double increment=dual?next-lambda:next;
            apply(increment);if(dual)lambda=next;
            std::printf("{\"kind\":\"iteration\",\"dual\":%s,\"substep\":%u,\"iteration\":%u,"
                        "\"previousPublishedBodyVelocity\":%.17g,\"nativeBeforeForeignSolve\":%.17g,"
                        "\"fluidBefore\":%.17g,\"cachedPressureImpulse\":%.17g,"
                        "\"bodyAfterForeignWarm\":%.17g,\"pressureIncrement\":%.17g,"
                        "\"bodyAfterForeignSolve\":%.17g,\"fluidAfter\":%.17g}\n",
                        dual?"true":"false",phase.index,phase.iteration,published,nativeBefore,
                        fluidBefore,cached,afterForeignWarm,increment,
                        double(world.GetLinearVelocity(body).y),fluid);
        },[&](const auto& phase) {
            published=world.GetLinearVelocity(body).y;
            if(dual)cached=lambda;
            std::printf("{\"kind\":\"published\",\"dual\":%s,\"substep\":%u,"
                        "\"bodyVelocity\":%.17g,\"fluidVelocity\":%.17g,\"energy\":%.17g}\n",
                        dual?"true":"false",phase.index,published,fluid,
                        4000*fluid*fluid+40*published*published);
        });
    world.Step(1.f/60,&coupling);
}
int main(){Trace(false);Trace(true);}
