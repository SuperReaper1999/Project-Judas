#include "PhysicsWorld.h"
#include "NativeNormalBridge.h"
#include <cstdint>
#include <cstring>
#include <cstdio>
bool Stage5ParticipantEnabled(){return false;}
bool Stage5ContactPressure(float,unsigned,const std::vector<Stage5Body>&,const std::vector<Stage5Normal>&,const std::vector<Stage5Joint>&){return false;}
static uint64_t digest=UINT64_C(1469598103934665603);
void Hash(float v){uint32_t bits;std::memcpy(&bits,&v,4);for(unsigned i=0;i<4;++i){digest^=(bits>>(8*i))&255;digest*=UINT64_C(1099511628211);}}
void Hash(glm::vec3 v){Hash(v.x);Hash(v.y);Hash(v.z);}
int main(){for(unsigned scene=0;scene<4;++scene)for(unsigned adapter=0;adapter<2;++adapter){
 PhysicsWorld w;w.Init();w.CreateStaticBox({0,-.5f,0},{10,.5f,10},scene==0?0:.4f,.1f);
 std::vector<BodyHandle> bodies;
 for(unsigned i=0;i<8;++i){auto b=w.CreateDynamicBox({float(i%2)*.6f,float(i/2)+.5f,float(i%3)*.3f},{.25f,.25f,.25f},float(2+i),scene==0?0:.4f,scene==1?.9f:0);
  w.SetAngularVelocity(b,{.5f*float(i),2+float(i),-.3f*float(i)});bodies.push_back(b);}
 if(scene>=2)for(unsigned i=1;i<bodies.size();++i){JointSettings j;j.type=scene==2?JointType::Ball:JointType::Hinge;j.bodyA=bodies[i-1];j.bodyB=bodies[i];j.anchorA={.3f,.5f,0};j.anchorB={0,-.5f,0};w.CreateJoint(j);}
 auto observer=PhysicsWorld::VelocityCoupling::ForEachSubstep(1,[](const auto&){});
 for(unsigned tick=0;tick<120;++tick){for(auto b:bodies)w.ApplyLinearAcceleration(b,{0,-9.81f,0},1.f/60);w.Step(1.f/60,adapter?&observer:nullptr);
  for(auto b:bodies){const auto t=w.GetTransform(b);Hash(t.position);Hash(t.rotation.w);Hash(t.rotation.x);Hash(t.rotation.y);Hash(t.rotation.z);Hash(w.GetLinearVelocity(b));Hash(w.GetAngularVelocity(b));}}
 std::printf("TRAJECTORY scene=%u observer=%u digest=%016llx\n",scene,adapter,(unsigned long long)digest);
}return 0;}
