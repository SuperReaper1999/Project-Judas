#include "RigidEqualitySpace.h"
#include <cstdio>
#include <random>
static unsigned checks=0;
void Check(bool yes,const char* msg){++checks;if(!yes)throw std::runtime_error(msg);}
int main(){try{
 for(double mass:{1.,80.,8000.})for(float angle:{0.f,.73f}){
  RigidBody a,b;a.inverseMass=float(1/mass);b.inverseMass=.2f;
  const glm::dquat turn(glm::angleAxis(angle,glm::normalize(glm::vec3(1,2,-3))));
  const glm::dmat3 rotation=glm::mat3_cast(turn);
  const glm::dmat3 ia=rotation*glm::dmat3(.3,0,0,0,.7,0,0,0,1.1)*glm::transpose(rotation);
  const glm::dmat3 ib=rotation*glm::dmat3(1.2,0,0,0,.4,0,0,0,.6)*glm::transpose(rotation);
  std::vector<Stage5Body> bodies{{&a,1/mass,ia},{&b,.2,ib}};
  const auto na=rotation*glm::dvec3(.4,.7,-.2),ra=rotation*glm::dvec3(.3,.8,.2),rb=rotation*glm::dvec3(-.5,.1,.7);
  std::vector<Stage5Joint> rows{{0,1,-na,na,-glm::cross(ra,na),glm::cross(rb,na),0,-INFINITY,INFINITY,nullptr}};
  RigidEqualitySpace space(bodies,rows);
  const auto ga=space.Gradient(0,rows[0].linearA,rows[0].angularA),gb=space.Gradient(1,rows[0].linearB,rows[0].angularB);
  auto joint=ga;for(unsigned i=0;i<joint.size();++i)joint[i]+=gb[i];
  std::mt19937 rng(19);std::uniform_real_distribution<double> sample(-1,1);
  std::vector<double> q(space.dimension),r(space.dimension);for(auto& x:q)x=sample(rng);for(auto& x:r)x=sample(rng);
  const auto projected=space.Null(q),again=space.Null(projected),other=space.Null(r);
  const double expected=RigidEqualitySpace::Dot(q,joint)/RigidEqualitySpace::Dot(joint,joint);
  for(unsigned i=0;i<q.size();++i){Check(std::abs(projected[i]-(q[i]-expected*joint[i]))<1e-12,"independent analytic single-joint projection differs");Check(std::abs(projected[i]-again[i])<1e-12,"projector is not idempotent");}
  Check(std::abs(RigidEqualitySpace::Dot(projected,joint))<1e-12,"projected velocity violates joint");
  Check(std::abs(RigidEqualitySpace::Dot(projected,r)-RigidEqualitySpace::Dot(q,other))<1e-12,"mobility is not reciprocal");
  auto reaction=q;for(unsigned i=0;i<q.size();++i)reaction[i]=projected[i]-q[i];
  const auto impulses=space.JointImpulses(reaction,1);
  Check(std::abs(impulses[0]+expected)<1e-12,"analytic joint reaction differs");
  const auto dpA=space.Linear(0,reaction)*mass,dpB=space.Linear(1,reaction)*5.;
  Check(glm::length(dpA+dpB)<1e-12,"internal joint creates net linear impulse");
  const glm::dvec3 posA(0),posB=ra-rb;
  const auto angular=glm::inverse(ia)*space.Angular(0,reaction)+glm::inverse(ib)*space.Angular(1,reaction)+glm::cross(posB,dpB);
  Check(glm::length(angular)<1e-11,"off-center internal joint creates angular momentum");
  auto duplicates=rows;duplicates.push_back(rows[0]);RigidEqualitySpace dependent(bodies,duplicates);
  Check(dependent.basis.size()==1,"dependent equality created spurious degree of constraint");
  const auto distributed=dependent.JointImpulses(reaction,2);
  Check(std::abs(distributed[0]+expected*.5)<1e-12&&std::abs(distributed[1]+expected*.5)<1e-12,"dependent duals do not retain symmetric minimum-norm support");
  duplicates[1].bias=1;bool rejected=false;try{RigidEqualitySpace invalid(bodies,duplicates);}catch(const std::runtime_error&){rejected=true;}
  Check(rejected,"inconsistent dependent constraint accepted");
  rows[0].low=0;rejected=false;try{RigidEqualitySpace invalid(bodies,rows);}catch(const std::runtime_error&){rejected=true;}
  Check(rejected,"unilateral constraint silently treated as bilateral");
 }
 {RigidBody a;a.linearVelocity={2,-3,4};std::vector<Stage5Body> bodies{{&a,.5,glm::dmat3(1)}};
  RigidEqualitySpace free(bodies,{});std::vector<double> q(6,1);Check(free.Null(q)==q,"free body mobility changed");
  std::vector<Stage5Joint> fixed;for(unsigned axis=0;axis<6;++axis){glm::dvec3 linear(0),angular(0);if(axis<3)linear[axis]=1;else angular[axis-3]=1;
   fixed.push_back({0,0,linear,glm::dvec3(0),angular,glm::dvec3(0),0,-INFINITY,INFINITY,nullptr});}
  RigidEqualitySpace anchored(bodies,fixed);Check(anchored.basis.size()==6,"fixed body does not constrain all six DOFs");
  Check(glm::length(anchored.baseLinear[0])<1e-12,"physical predictor not projected onto fixed joint");
  for(double value:anchored.Null(q))Check(std::abs(value)<1e-12,"fixed body retains artificial mobility");
 }
 std::printf("SUMMARY checks=%u failures=0 scope=independent-rigid-constraint-space\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks: %s\n",checks,e.what());return 1;}}
