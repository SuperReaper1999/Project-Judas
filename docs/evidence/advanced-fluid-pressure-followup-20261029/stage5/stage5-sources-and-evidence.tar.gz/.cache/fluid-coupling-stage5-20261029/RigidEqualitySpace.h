#pragma once
#include "NativeNormalBridge.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>
// Bounded reference factorization of ACTUAL prepared bilateral joint rows.
// q is a mass-whitened rigid impulse coordinate, never a material parcel.
struct RigidEqualitySpace {
    struct BodyMap { unsigned first=unsigned(-1); double massRoot=0; glm::dmat3 inertiaRoot{0}; };
    std::vector<BodyMap> map;
    std::vector<glm::dvec3> baseLinear,baseAngular;
    std::vector<std::vector<double>> basis,triangular,allCoefficients;
    std::vector<unsigned> independent;
    std::vector<double> initial;
    unsigned dimension=0;
    static double Dot(const std::vector<double>& a,const std::vector<double>& b){double s=0;for(unsigned i=0;i<a.size();++i)s+=a[i]*b[i];return s;}
    glm::dvec3 Linear(unsigned body,const std::vector<double>& q)const {
        const auto& m=map.at(body);if(m.first==unsigned(-1))return glm::dvec3(0);
        return m.massRoot*glm::dvec3(q[m.first],q[m.first+1],q[m.first+2]);
    }
    glm::dvec3 Angular(unsigned body,const std::vector<double>& q)const {
        const auto& m=map.at(body);if(m.first==unsigned(-1))return glm::dvec3(0);
        return m.inertiaRoot*glm::dvec3(q[m.first+3],q[m.first+4],q[m.first+5]);
    }
    std::vector<double> Gradient(unsigned body,glm::dvec3 linear,glm::dvec3 angular)const {
        std::vector<double> g(dimension,0);const auto& m=map.at(body);if(m.first==unsigned(-1))return g;
        for(unsigned a=0;a<3;++a){g[m.first+a]=m.massRoot*linear[a];g[m.first+3+a]=glm::dot(m.inertiaRoot[a],angular);}return g;
    }
    std::vector<double> Null(std::vector<double> x)const {
        // Twice reorthogonalize; this is a projector, not an artificial loss.
        for(unsigned pass=0;pass<2;++pass)for(const auto& u:basis){double c=Dot(x,u);for(unsigned a=0;a<dimension;++a)x[a]-=c*u[a];}
        return x;
    }
    RigidEqualitySpace(const std::vector<Stage5Body>& bodies,const std::vector<Stage5Joint>& joints){
        for(const auto& b:bodies){BodyMap m;
            if(b.inverseMass>0){m.first=dimension;dimension+=6;m.massRoot=std::sqrt(b.inverseMass);
                for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double x=b.inverseInertia[j][i];
                    for(unsigned k=0;k<j;++k)x-=m.inertiaRoot[k][i]*m.inertiaRoot[k][j];
                    if(i==j){if(!(x>0))throw std::runtime_error("reference requires positive rigid inertia");m.inertiaRoot[j][i]=std::sqrt(x);}
                    else m.inertiaRoot[j][i]=x/m.inertiaRoot[j][j];}}
            map.push_back(m);baseLinear.emplace_back(b.state->linearVelocity);baseAngular.emplace_back(b.state->angularVelocity);}
        initial.assign(dimension,0);
        std::vector<double> target;
        for(unsigned i=0;i<joints.size();++i){const auto& r=joints[i];
            if(!std::isinf(r.low)||!std::isinf(r.high))throw std::runtime_error("reference equality space does not accept joint limits or motors");
            auto a=Gradient(r.a,r.linearA,r.angularA),b=Gradient(r.b,r.linearB,r.angularB);
            for(unsigned k=0;k<dimension;++k)a[k]+=b[k];
            double rhs=-r.bias-glm::dot(r.linearA,baseLinear[r.a])-glm::dot(r.angularA,baseAngular[r.a])-glm::dot(r.linearB,baseLinear[r.b])-glm::dot(r.angularB,baseAngular[r.b]);
            const double norm0=std::sqrt(Dot(a,a));std::vector<double> factors(basis.size(),0);
            for(unsigned pass=0;pass<2;++pass)for(unsigned j=0;j<basis.size();++j){double c=Dot(a,basis[j]);factors[j]+=c;rhs-=c*target[j];for(unsigned k=0;k<dimension;++k)a[k]-=c*basis[j][k];}
            const double norm=std::sqrt(Dot(a,a));
            if(norm<=1e-12*norm0){if(std::abs(rhs)>1e-10)throw std::runtime_error("inconsistent dependent joint constraint");allCoefficients.push_back(factors);continue;}
            for(double& x:a)x/=norm;
            factors.push_back(norm);allCoefficients.push_back(factors);triangular.push_back(factors);basis.push_back(a);target.push_back(rhs/norm);independent.push_back(i);
        }
        for(unsigned i=0;i<basis.size();++i)for(unsigned a=0;a<dimension;++a)initial[a]+=basis[i][a]*target[i];
        for(unsigned b=0;b<bodies.size();++b){baseLinear[b]+=Linear(b,initial);baseAngular[b]+=Angular(b,initial);}
    }
    std::vector<double> JointImpulses(const std::vector<double>& whitenedJointImpulse,unsigned rows)const {
        const unsigned rank=basis.size();
        std::vector<double> factor(rank*rank,0),z(rank,0);
        for(unsigned i=0;i<rank;++i){z[i]=Dot(whitenedJointImpulse,basis[i]);
            for(unsigned j=0;j<=i;++j){double x=0;
                for(const auto& row:allCoefficients)if(i<row.size())x+=row[i]*row[j];
                for(unsigned k=0;k<j;++k)x-=factor[i*rank+k]*factor[j*rank+k];
                if(i==j){if(!(x>0))throw std::runtime_error("singular joint dual recovery");factor[i*rank+j]=std::sqrt(x);}
                else factor[i*rank+j]=x/factor[j*rank+j];
            }
        }
        for(unsigned i=0;i<rank;++i){for(unsigned j=0;j<i;++j)z[i]-=factor[i*rank+j]*z[j];z[i]/=factor[i*rank+i];}
        for(unsigned i=rank;i-->0;){for(unsigned j=i+1;j<rank;++j)z[i]-=factor[j*rank+i]*z[j];z[i]/=factor[i*rank+i];}
        if(rows!=allCoefficients.size())throw std::runtime_error("joint dual row ownership mismatch");
        std::vector<double> result(rows,0),reconstructed(dimension,0);
        for(unsigned i=0;i<rows;++i){const auto& r=allCoefficients[i];
            for(unsigned j=0;j<r.size();++j)result[i]+=r[j]*z[j];
            for(unsigned j=0;j<r.size();++j)for(unsigned a=0;a<dimension;++a)reconstructed[a]+=basis[j][a]*r[j]*result[i];
        }
        double residual=0;for(unsigned a=0;a<dimension;++a)residual=std::max(residual,std::abs(whitenedJointImpulse[a]-reconstructed[a]));
        if(residual>1e-8)throw std::runtime_error("joint reaction reconstruction is inconsistent");
        return result;
    }
};
