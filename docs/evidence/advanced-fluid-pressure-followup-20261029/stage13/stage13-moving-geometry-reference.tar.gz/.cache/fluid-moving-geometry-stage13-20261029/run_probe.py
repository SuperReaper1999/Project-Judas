from pathlib import Path
import sys,subprocess,os
sys.path.insert(0,'.cache/fluid-contact-repair');import setup_probes as b
boost=Path(os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'))
if not (boost/'boost/multiprecision/cpp_int.hpp').is_file():raise RuntimeError('Set BOOST_INCLUDE_DIR to locally extracted Boost 1.90 headers; no engine dependency is changed')
b.compile_flags+=['-I'+str(boost)]
eigen=Path(os.environ.get('EIGEN_INCLUDE_DIR','/tmp/judas-fluid-reference-eigen/extracted/usr/include/eigen3'))
if not (eigen/'Eigen/Dense').is_file():raise RuntimeError('Set EIGEN_INCLUDE_DIR to locally extracted Eigen 3.4 headers; no engine dependency is changed')
b.compile_flags+=['-I'+str(eigen)]
name=sys.argv[1];src=Path('.cache/fluid-moving-geometry-stage13-20261029')/(name+'.cpp')
b.executable(b.compile(src.resolve(),'stage13-'+name),'stage13-'+name,b.out/'stage5-exact-volume-domain.o')
raise SystemExit(subprocess.run([str(b.out/('stage13-'+name)),*sys.argv[2:]]).returncode)
