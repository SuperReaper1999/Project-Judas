#pragma once
#include "LocalizedGeometry.h"
namespace moving_geometry {
using Point2=std::array<R,2>;using Triangle2=std::array<Point2,3>;using Polygon=std::vector<RV>;using FaceKey=std::array<motion_mesh::Lattice,3>;
inline R Cross2(const Point2& a,const Point2& b,const Point2& c){return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);}
inline R Area(const Triangle2& t){return abs(Cross2(t[0],t[1],t[2]))/2;}
inline Polygon Clip3(const Polygon& points,const fluid_exact::Plane& plane,bool inside){
 Polygon result;bool hasStrict=false;auto side=[&](const RV& p){R value=-R(plane.coordinate);for(unsigned j=0;j<3;++j)value+=R(plane.normal[j])*p[j];return inside?value:R(-value);};
 for(const auto& p:points)hasStrict|=side(p)<0;if(!hasStrict)return {}; // Coplanar OUTSIDE is not a second owner.
 for(unsigned k=0;k<points.size();++k){const auto& a=points[k];const auto& b=points[(k+1)%points.size()];const R sa=side(a),sb=side(b);if(sa<=0)result.push_back(a);if((sa<0&&sb>0)||(sa>0&&sb<0)){RV point;for(unsigned j=0;j<3;++j)point[j]=a[j]+sa/(sa-sb)*(b[j]-a[j]);result.push_back(std::move(point));}}
 return result;
}
// Subtract the solid footprint from a trace even if it only TOUCHES a seed.
inline std::vector<Polygon> Aperture(Polygon trace,const Box& box){std::vector<Polygon> open;auto inside=std::move(trace);
 for(const auto& plane:box){if(inside.empty())break;bool negative=false,positive=false;for(const auto& p:inside){R s=-R(plane.coordinate);for(unsigned j=0;j<3;++j)s+=R(plane.normal[j])*p[j];negative|=s<0;positive|=s>0;}
  if(!positive)continue; // Entire trace is inside or coplanar with this plane.
  if(!negative){open.push_back(std::move(inside));inside.clear();break;}
  auto outside=Clip3(inside,plane,false);if(!outside.empty())open.push_back(std::move(outside));inside=Clip3(inside,plane,true);
 }return open;
}
using Moments2=std::array<R,6>;
inline Moments2 TriangleMoments(const Triangle2& t){const R area=Area(t);R sx=0,sy=0,xx=0,xy=0,yy=0;for(const auto& p:t){sx+=p[0];sy+=p[1];xx+=p[0]*p[0];xy+=p[0]*p[1];yy+=p[1]*p[1];}return {area,area*sx/3,area*sy/3,area*(sx*sx+xx)/12,area*(sx*sy+xy)/12,area*(sy*sy+yy)/12};}
inline Moments2 Overlap(const Triangle2& first,const Triangle2& second){std::vector<Point2> poly(first.begin(),first.end());auto other=second;if(Cross2(other[0],other[1],other[2])<0)std::swap(other[1],other[2]);
 for(unsigned e=0;e<3&&!poly.empty();++e){std::vector<Point2> next;for(unsigned k=0;k<poly.size();++k){const auto& a=poly[k];const auto& b=poly[(k+1)%poly.size()];const R sa=Cross2(other[e],other[(e+1)%3],a),sb=Cross2(other[e],other[(e+1)%3],b);if(sa>=0)next.push_back(a);if((sa<0&&sb>0)||(sa>0&&sb<0)){Point2 p;for(unsigned j=0;j<2;++j)p[j]=a[j]+sa/(sa-sb)*(b[j]-a[j]);next.push_back(std::move(p));}}poly=std::move(next);}
 Moments2 moments{};for(unsigned k=1;k+1<poly.size();++k){const auto tri=TriangleMoments({poly[0],poly[k],poly[k+1]});for(unsigned a=0;a<6;++a)moments[a]+=tri[a];}return moments;
}
struct Trace {unsigned seed;std::vector<Triangle2> triangles;};
inline std::map<FaceKey,std::vector<Trace>> Traces(const LocalEpoch& epoch){std::map<FaceKey,std::vector<Trace>> result;
 constexpr unsigned faces[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned seed=0;seed<epoch.slices.size();++seed){const auto& mesh=epoch.slices[seed]->mesh;std::map<std::array<unsigned,3>,unsigned> occurrences;
  for(const auto& tet:mesh.tetrahedra)for(const auto& face:faces){std::array<unsigned,3> key{tet.vertices[face[0]],tet.vertices[face[1]],tet.vertices[face[2]]};std::sort(key.begin(),key.end());++occurrences[key];}
  for(const auto& [background,plane]:mesh.backgroundFaces){Trace trace{seed,{}};RV p0{},p1{},p2{};for(unsigned a=0;a<3;++a){p0[a]=background[0][a];p1[a]=background[1][a];p2[a]=background[2][a];}const auto n=owned_metrics::Cross(Sub(p1,p0),Sub(p2,p0));unsigned axis=0;for(unsigned a=1;a<3;++a)if(abs(n[a])>abs(n[axis]))axis=a;const unsigned u=(axis+1)%3,v=(axis+2)%3;
   for(const auto& [ids,count]:occurrences)if(count==1){bool on=true;for(unsigned id:ids)on&=mesh.Side(id,plane)==0;if(!on)continue;Polygon tri;for(unsigned id:ids)tri.push_back(owned_metrics::Position(mesh.vertices[id].exact));
    for(const auto& open:Aperture(std::move(tri),epoch.box))for(unsigned k=1;k+1<open.size();++k){Triangle2 t{Point2{open[0][u],open[0][v]},Point2{open[k][u],open[k][v]},Point2{open[k+1][u],open[k+1][v]}};if(Area(t)>0)trace.triangles.push_back(std::move(t));}
   }result[background].push_back(std::move(trace));
  }
 }return result;
}
struct MortarResult {unsigned interfaces=0,patches=0,nonmatching=0;};
inline MortarResult VerifyMortars(std::map<FaceKey,std::vector<Trace>> traces){MortarResult result;
 for(const auto& [key,sides]:traces){if(sides.size()==1)continue;if(sides.size()!=2)throw std::runtime_error("invalid background trace ownership");++result.interfaces;const auto& a=sides[0].triangles;const auto& b=sides[1].triangles;std::vector<Moments2> coveredA(a.size()),coveredB(b.size());
  for(unsigned i=0;i<a.size();++i)for(unsigned j=0;j<b.size();++j){const auto moments=Overlap(a[i],b[j]);if(moments[0]>0){for(unsigned m=0;m<6;++m){coveredA[i][m]+=moments[m];coveredB[j][m]+=moments[m];}++result.patches;}}
  for(unsigned i=0;i<a.size();++i)if(coveredA[i]!=TriangleMoments(a[i]))throw std::runtime_error("mortar leaves unmatched aperture or double coverage");
  for(unsigned j=0;j<b.size();++j)if(coveredB[j]!=TriangleMoments(b[j]))throw std::runtime_error("mortar leaves unmatched aperture or double coverage");
  auto keyA=a,keyB=b;for(auto& t:keyA)std::sort(t.begin(),t.end());for(auto& t:keyB)std::sort(t.begin(),t.end());std::sort(keyA.begin(),keyA.end());std::sort(keyB.begin(),keyB.end());if(keyA!=keyB)++result.nonmatching;
 }return result;
}
}
