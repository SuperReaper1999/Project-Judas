from pathlib import Path
import subprocess,time,json
folder=Path('.cache/fluid-moving-geometry-stage13-20261029');out=folder/'reproduction-results';out.mkdir(exist_ok=False);runs=[]
for name in ['GeometryMotionTests','ExchangeTests','LocalizedMotionTests','MortarTests']:
 start=time.monotonic();command=['python3',str(folder/'run_probe.py'),name]
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'returnCode':r.returncode,'seconds':time.monotonic()-start};runs.append(record);(out/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(record),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
