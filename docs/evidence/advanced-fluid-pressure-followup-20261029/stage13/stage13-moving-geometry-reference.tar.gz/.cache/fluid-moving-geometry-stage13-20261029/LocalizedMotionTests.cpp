#include "LocalizedGeometry.h"
#include <cstdio>
#include <chrono>
#include <sys/resource.h>
using namespace moving_geometry;unsigned checks=0;void Check(bool b,const char* what){++checks;if(!b)throw std::runtime_error(what);}
using Clock=std::chrono::steady_clock;double Ms(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
void Summary(const char* name,std::vector<double> values){std::sort(values.begin(),values.end());std::printf("TIMING name=%s count=%zu median_ms=%g p95_ms=%g worst_ms=%g\n",name,values.size(),values[values.size()/2],values[unsigned(std::ceil(.95*values.size()))-1],values.back());}
int main(){std::setvbuf(stdout,nullptr,_IOLBF,0);try{const unsigned grid=4;const V half(.23,.19,.27);auto first=owned_cut::BoxPlanes({1.5,1.5,1.5},half,glm::dquat(1,0,0,0));LocalEpoch cache(grid,first);std::vector<double> incremental,fullTimes;unsigned totalChanged=0;
 for(unsigned step=0;step<12;++step){const auto next=owned_cut::BoxPlanes({1.5+.07*step,1.5+.015*step,1.5-.02*step},half,glm::angleAxis(.03*step,glm::normalize(V(1,2,-.3))));const auto old=cache.slices;unsigned changed;double updateMs,fullMs;std::unique_ptr<LocalEpoch> full;
  const auto update=[&]{auto t=Clock::now();changed=cache.Update(next);updateMs=Ms(t);};const auto rebuild=[&]{auto t=Clock::now();full=std::make_unique<LocalEpoch>(grid,next);fullMs=Ms(t);};if(step%2){rebuild();update();}else{update();rebuild();}
  const auto a=cache.Sum(),b=full->Sum();Check(a.volume==b.volume&&a.first==b.first,"local incremental moments differ from fresh local rebuild");unsigned reused=0;for(unsigned id=0;id<old.size();++id){if(cache.slices[id]==old[id])++reused;Check(Keys(cache.slices[id]->mesh)==Keys(full->slices[id]->mesh),"incremental local seed differs from fresh canonical geometry");}Check(reused+changed==old.size(),"unaffected geometry owner not retained");const auto solid=BoxMoments(next);Check(a.volume+solid.volume==R(grid*grid*grid),"localized subtraction volume differs from independent box");
  for(unsigned j=0;j<3;++j)Check(a.first[j]+solid.first[j]==R(grid*grid*grid*grid)/2,"localized subtraction first moment differs from analytic body");
  Check(changed<old.size()/4,"local box motion invalidates excessive fraction of background");totalChanged+=changed;
  std::printf("LOCAL step=%u changed=%u reused=%u total=%zu update_ms=%g full_ms=%g exact_geometry_equal=1 exact_moments_equal=1\n",step,changed,reused,old.size(),updateMs,fullMs);if(step){incremental.push_back(updateMs);fullTimes.push_back(fullMs);}
 }
 const auto before=cache.slices;auto invalid=cache.box;invalid[0].normal[0]=NAN;bool rejected=false;try{cache.Update(invalid);}catch(const std::exception&){rejected=true;}Check(rejected&&cache.slices==before,"invalid local epoch partly publishes");Check(cache.Update(cache.box)==0&&cache.slices==before,"unchanged local geometry rebuilt");Summary("incremental_geometry_and_moments",incremental);Summary("full_geometry_and_moments",fullTimes);struct rusage usage{};getrusage(RUSAGE_SELF,&usage);std::printf("SUMMARY checks=%u failures=0 total_changed=%u peak_rss_kib=%ld no_pressure_backend=1\n",checks,totalChanged,usage.ru_maxrss);return 0;
 }catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
