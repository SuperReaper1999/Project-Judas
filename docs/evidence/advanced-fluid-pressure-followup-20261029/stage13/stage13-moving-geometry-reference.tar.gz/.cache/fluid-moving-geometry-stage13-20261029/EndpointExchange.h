#pragma once
#include "LocalGeometry.h"
namespace moving_geometry {
inline void Add(Moments& a,const Moments& b){a.volume+=b.volume;for(unsigned j=0;j<3;++j)a.first[j]+=b.first[j];}
inline Moments PieceMoments(const motion_mesh::Compiler& mesh,const motion_mesh::Polyhedron& piece){
 Moments result;std::set<unsigned> ids;for(const auto& face:piece.faces)ids.insert(face.vertices.begin(),face.vertices.end());if(ids.empty())return result;
 const unsigned anchor=*ids.begin();const RV origin=owned_metrics::Position(mesh.vertices[anchor].exact);
 for(const auto& face:piece.faces){if(mesh.Side(anchor,face.plane)==0)continue;const auto& polygon=face.vertices;
  for(unsigned k=1;k+1<polygon.size();++k){const RV a=owned_metrics::Position(mesh.vertices[polygon[0]].exact),b=owned_metrics::Position(mesh.vertices[polygon[k]].exact),c=owned_metrics::Position(mesh.vertices[polygon[k+1]].exact);
   const R det=owned_metrics::Dot(Sub(a,origin),owned_metrics::Cross(Sub(b,origin),Sub(c,origin)));if(det<0)throw std::runtime_error("negative exact exchange polyhedron orientation");const R volume=det/6;result.volume+=volume;for(unsigned j=0;j<3;++j)result.first[j]+=volume*(origin[j]+a[j]+b[j]+c[j])/4;
  }
 }return result;
}
struct Exchange {Moments common,lost,gained,solid;};
// Exact ENDPOINT Boolean overlap, not an integrated wall trajectory or fluid routing.
inline Exchange EndpointOverlap(unsigned grid,const Box& oldBox,const Box& newBox){
 if(grid==0||grid>8)throw std::invalid_argument("bounded exchange grid");Exchange result;
 constexpr unsigned cubeTets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
 for(unsigned id=0;id<6*grid*grid*grid;++id){motion_mesh::Compiler mesh;std::vector<unsigned> cuts;
  for(const auto* box:{&oldBox,&newBox})for(const auto& p:*box)cuts.push_back(mesh.AddPlane({p.normal[0],p.normal[1],p.normal[2]},p.coordinate));
  const unsigned voxel=id/6,x=voxel%grid,y=(voxel/grid)%grid,z=voxel/(grid*grid);std::array<motion_mesh::Lattice,8> corners;for(unsigned i=0;i<8;++i)corners[i]={int(x+(i&1)),int(y+((i>>1)&1)),int(z+((i>>2)&1))};const auto indices=cubeTets[id%6];auto seed=mesh.Seed({corners[indices[0]],corners[indices[1]],corners[indices[2]],corners[indices[3]]});std::vector<motion_mesh::Polyhedron> pieces{std::move(seed)};
  for(unsigned cut=0;cut<12;++cut){std::vector<motion_mesh::Polyhedron> next;
   for(const auto& p:pieces){auto inside=mesh.Clip(p,cuts[cut],1),outside=mesh.Clip(p,cuts[cut],-1);if(!inside.faces.empty())next.push_back(std::move(inside));if(!outside.faces.empty()){outside.outside|=1u<<cut;next.push_back(std::move(outside));}}
   pieces=std::move(next);if(pieces.size()>1024)throw std::runtime_error("bounded endpoint arrangement exceeded");}
  for(const auto& p:pieces){const bool oldFluid=(p.outside&63)!=0,newFluid=(p.outside>>6)!=0;auto& target=oldFluid?(newFluid?result.common:result.lost):(newFluid?result.gained:result.solid);Add(target,PieceMoments(mesh,p));}
 }
 return result;
}
// Independent closed form for the finite six-plane parallelepiped, not its mesh.
inline Moments BoxMoments(const Box& box){std::array<RV,3> rows;RV centerRight{},width{};for(unsigned a=0;a<3;++a){for(unsigned j=0;j<3;++j){rows[a][j]=R(box[2*a+1].normal[j]);if(box[2*a].normal[j]!=-box[2*a+1].normal[j])throw std::invalid_argument("paired box normals disagree");}width[a]=R(box[2*a].coordinate)+R(box[2*a+1].coordinate);centerRight[a]=(R(box[2*a+1].coordinate)-R(box[2*a].coordinate))/2;if(width[a]<=0)throw std::invalid_argument("invalid paired box width");}
 const R determinant=owned_metrics::Dot(rows[0],owned_metrics::Cross(rows[1],rows[2]));if(determinant==0)throw std::invalid_argument("singular box reference");Moments result;result.volume=width[0]*width[1]*width[2]/abs(determinant);
 const auto c0=owned_metrics::Cross(rows[1],rows[2]),c1=owned_metrics::Cross(rows[2],rows[0]),c2=owned_metrics::Cross(rows[0],rows[1]);for(unsigned j=0;j<3;++j)result.first[j]=result.volume*(centerRight[0]*c0[j]+centerRight[1]*c1[j]+centerRight[2]*c2[j])/determinant;return result;
}
}
