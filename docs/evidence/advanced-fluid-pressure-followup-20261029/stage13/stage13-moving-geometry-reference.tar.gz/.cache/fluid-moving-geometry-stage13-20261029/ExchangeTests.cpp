#include "EndpointExchange.h"
#include <cstdio>
using namespace moving_geometry;unsigned checks=0;void Check(bool b,const char* what){++checks;if(!b)throw std::runtime_error(what);}
int main(){std::setvbuf(stdout,nullptr,_IOLBF,0);try{const V half(.25,.125,.1875);const auto first=owned_cut::BoxPlanes({.75,.8125,.875},half,glm::dquat(1,0,0,0));auto before=first;R cycleLost=0;
 for(unsigned step=0;step<4;++step){const V center=step==3?V(.75,.8125,.875):V(.875+.125*step,.84375,.875);const auto next=owned_cut::BoxPlanes(center,half,glm::angleAxis(step==2?.17:0.,glm::normalize(V(1,2,-.3))));const auto exchange=EndpointOverlap(2,before,next);
  motion_mesh::Compiler oldMesh,newMesh;oldMesh.BuildRegions(2,before,{});newMesh.BuildRegions(2,next,{});const auto old=Integrate(oldMesh),current=Integrate(newMesh);auto commonLost=exchange.common,commonGained=exchange.common;Add(commonLost,exchange.lost);Add(commonGained,exchange.gained);
  Check(commonLost.volume==old.volume&&commonLost.first==old.first,"old endpoint exact partition is incomplete");Check(commonGained.volume==current.volume&&commonGained.first==current.first,"new endpoint exact partition is incomplete");
  const auto oldSolid=BoxMoments(before),newSolid=BoxMoments(next);Check(old.volume+oldSolid.volume==R(8)&&current.volume+newSolid.volume==R(8),"independent analytic box capacity does not match exact geometry");
  R work=0,expectedWork=0;const RV gravity{R(1.25),R(-9.81),R(.375)};
  for(unsigned j=0;j<3;++j){work+=1000*gravity[j]*(current.first[j]-old.first[j]);expectedWork-=1000*gravity[j]*(newSolid.first[j]-oldSolid.first[j]);Check(current.first[j]-old.first[j]==-(newSolid.first[j]-oldSolid.first[j]),"independent first-moment displacement mismatch");}
  Check(work==expectedWork,"hydrostatic displacement-work reference mismatch");
  // Prescribed affine-carrier moment identity; not a pressure/momentum time step.
  const RV mean{R(.4),R(-.2),R(.1)};const std::array<RV,3> gradient{RV{R(.1),R(.02),R(-.03)},RV{R(-.04),R(.05),R(.01)},RV{R(.03),R(-.02),R(.07)}};
  for(unsigned a=0;a<3;++a){R actual=mean[a]*(current.volume-old.volume),paired=mean[a]*(exchange.gained.volume-exchange.lost.volume);for(unsigned j=0;j<3;++j){actual+=gradient[a][j]*(current.first[j]-old.first[j]);paired+=gradient[a][j]*(exchange.gained.first[j]-exchange.lost.first[j]);}Check(actual==paired,"endpoint affine-carrier momentum bookkeeping differs from exact geometric exchange");}Check(exchange.lost.volume>=0&&exchange.gained.volume>=0,"negative endpoint displacement");
  Check(exchange.common.volume<old.volume,"naive overlap-only remap negative control failed to expose missing water");cycleLost+=exchange.lost.volume;
  std::printf("EXCHANGE step=%u lost=%.17g gained=%.17g naive_overlap_water_loss=%.17g work=%.17g exact_partitions=1 exact_work=1\n",step,exchange.lost.volume.convert_to<double>(),exchange.gained.volume.convert_to<double>(),(old.volume-exchange.common.volume).convert_to<double>(),work.convert_to<double>());before=next;
 }
 const auto same=EndpointOverlap(2,first,first);Check(same.lost.volume==0&&same.gained.volume==0&&cycleLost>0,"endpoint-only cyclic-motion negative control failed");std::printf("CYCLIC endpoint_loss=0 traversed_leg_loss=%g path_information_required=1\n",cycleLost.convert_to<double>());std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
 }catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
