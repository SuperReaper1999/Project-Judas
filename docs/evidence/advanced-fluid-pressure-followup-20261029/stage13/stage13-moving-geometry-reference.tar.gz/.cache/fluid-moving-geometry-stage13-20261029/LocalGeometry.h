#pragma once
#include "MotionCompiler.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <memory>
#include <numeric>
namespace moving_geometry {
using R=owned_metrics::R;using RV=owned_metrics::RV;using V=glm::dvec3;using Box=std::array<fluid_exact::Plane,6>;
inline RV Sub(RV a,const RV& b){for(unsigned k=0;k<3;++k)a[k]-=b[k];return a;}
struct Moments {R volume=0;RV first{};};
inline Moments Integrate(const motion_mesh::Compiler& mesh){Moments result;
 for(const auto& t:mesh.tetrahedra){std::array<RV,4> p;for(unsigned j=0;j<4;++j)p[j]=owned_metrics::Position(mesh.vertices[t.vertices[j]].exact);
  const R det=owned_metrics::Dot(Sub(p[1],p[0]),owned_metrics::Cross(Sub(p[2],p[0]),Sub(p[3],p[0])));if(det<=0)throw std::runtime_error("nonpositive exact moved tetrahedron");const R volume=det/6;result.volume+=volume;for(unsigned a=0;a<3;++a)for(unsigned j=0;j<4;++j)result.first[a]+=volume*p[j][a]/4;
 }return result;
}
inline bool Equal(const Box& a,const Box& b){for(unsigned i=0;i<6;++i)if(a[i].coordinate!=b[i].coordinate||a[i].normal!=b[i].normal)return false;return true;}
inline int Side(const fluid_exact::Plane& plane,std::array<unsigned,3> point){R value=-R(plane.coordinate);for(unsigned a=0;a<3;++a)value+=R(plane.normal[a])*point[a];return (value>0)-(value<0);}
inline bool Dirty(unsigned grid,unsigned seed,const Box& before,const Box& after){
 constexpr unsigned triangles[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};const unsigned voxel=seed/6,x=voxel%grid,y=(voxel/grid)%grid,z=voxel/(grid*grid);
 for(unsigned p=0;p<6;++p){if(before[p].coordinate==after[p].coordinate&&before[p].normal==after[p].normal)continue;int sign=0;
  for(unsigned corner:triangles[seed%6])for(const auto* box:{&before,&after}){const int next=Side((*box)[p],{x+(corner&1),y+((corner>>1)&1),z+((corner>>2)&1)});if(next==0|| (sign&&next!=sign))return true;sign=next;}}
 return false;
}
struct Slice {motion_mesh::Compiler mesh;Moments moments;};
inline std::shared_ptr<const Slice> Compile(unsigned grid,unsigned seed,const Box& box){auto slice=std::make_shared<Slice>();slice->mesh.BuildSelected(grid,box,{seed});slice->moments=Integrate(slice->mesh);return slice;}
struct Epoch {
 unsigned grid=0;Box box;std::vector<std::shared_ptr<const Slice>> slices;
 explicit Epoch(unsigned count,const Box& planes):grid(count),box(planes){if(!grid||grid>8)throw std::invalid_argument("bounded motion geometry grid");for(unsigned seed=0;seed<6*grid*grid*grid;++seed)slices.push_back(Compile(grid,seed,box));}
 unsigned Update(const Box& next){for(const auto& p:next){if(!std::isfinite(p.coordinate))throw std::invalid_argument("nonfinite updated plane");for(double n:p.normal)if(!std::isfinite(n))throw std::invalid_argument("nonfinite updated normal");if(p.normal==std::array<double,3>{})throw std::invalid_argument("zero updated plane normal");}
  if(Equal(box,next))return 0;auto staged=slices;unsigned changed=0;
  for(unsigned seed=0;seed<slices.size();++seed)if(Dirty(grid,seed,box,next)){staged[seed]=Compile(grid,seed,next);++changed;}
  slices.swap(staged);box=next;return changed;
 }
 Moments Sum()const{Moments m;for(const auto& slice:slices){m.volume+=slice->moments.volume;for(unsigned a=0;a<3;++a)m.first[a]+=slice->moments.first[a];}return m;}
};
using TetKey=std::array<RV,4>;
inline std::vector<TetKey> Keys(const motion_mesh::Compiler& mesh){std::vector<TetKey> keys;for(const auto& t:mesh.tetrahedra){TetKey key;for(unsigned j=0;j<4;++j)key[j]=owned_metrics::Position(mesh.vertices[t.vertices[j]].exact);std::sort(key.begin(),key.end());keys.push_back(std::move(key));}std::sort(keys.begin(),keys.end());return keys;}
inline std::vector<TetKey> Keys(const Epoch& epoch){std::vector<TetKey> keys;for(const auto& slice:epoch.slices){auto local=Keys(slice->mesh);keys.insert(keys.end(),local.begin(),local.end());}std::sort(keys.begin(),keys.end());return keys;}
}
