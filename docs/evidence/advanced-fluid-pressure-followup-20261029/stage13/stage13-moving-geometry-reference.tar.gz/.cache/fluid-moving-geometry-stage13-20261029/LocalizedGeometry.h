#pragma once
#include "EndpointExchange.h"
namespace moving_geometry {
struct Bounds {RV low,high;};
inline Bounds BoundBox(const Box& box){BoxMoments(box);Bounds bounds;bool first=true;
 for(unsigned mask=0;mask<8;++mask){const auto vertex=fluid_exact::Intersection::Make({box[(mask&1)?1:0],box[(mask&2)?3:2],box[(mask&4)?5:4]});const RV point=owned_metrics::Position(vertex);if(first){bounds.low=bounds.high=point;first=false;}else for(unsigned a=0;a<3;++a){bounds.low[a]=std::min(bounds.low[a],point[a]);bounds.high[a]=std::max(bounds.high[a],point[a]);}}
 return bounds;
}
inline bool OverlapSeed(unsigned grid,unsigned seed,const Bounds& box){const unsigned voxel=seed/6;const unsigned xyz[3]={voxel%grid,(voxel/grid)%grid,voxel/(grid*grid)};for(unsigned a=0;a<3;++a)if(box.high[a]<R(xyz[a])||box.low[a]>R(xyz[a]+1))return false;return true;}
inline std::shared_ptr<const Slice> CompileLocalized(unsigned grid,unsigned seed,const Box& box){auto slice=std::make_shared<Slice>();slice->mesh.BuildLocalizedSelected(grid,box,{seed});slice->moments=Integrate(slice->mesh);return slice;}
struct LocalEpoch {
 unsigned grid;Box box;Bounds bounds;std::vector<std::shared_ptr<const Slice>> slices;
 LocalEpoch(unsigned count,const Box& planes):grid(count),box(planes),bounds(BoundBox(planes)){if(!grid||grid>8)throw std::invalid_argument("bounded local epoch grid");for(unsigned id=0;id<6*grid*grid*grid;++id)slices.push_back(CompileLocalized(grid,id,box));}
 unsigned Update(const Box& next){if(Equal(box,next))return 0;const auto newBounds=BoundBox(next);auto staged=slices;unsigned count=0;
  for(unsigned id=0;id<slices.size();++id)if(OverlapSeed(grid,id,bounds)||OverlapSeed(grid,id,newBounds)){staged[id]=CompileLocalized(grid,id,next);++count;}
  slices.swap(staged);box=next;bounds=newBounds;return count;
 }
 Moments Sum()const{Moments result;for(const auto& slice:slices)Add(result,slice->moments);return result;}
};
}
