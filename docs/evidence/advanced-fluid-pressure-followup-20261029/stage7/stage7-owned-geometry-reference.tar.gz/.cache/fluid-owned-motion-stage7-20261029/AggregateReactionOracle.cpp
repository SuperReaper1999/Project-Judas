#include "../fluid-owned-motion-stage7-kernel/AffineModel.h"
#include "../fluid-owned-motion-stage7-kernel/SparseInterior.h"
#include "../fluid-owned-motion-stage7-kernel/RankEqualityQR.h"
#include "AggregatePressure.h"
#include <cstdio>
int main(){try{auto geometry=owned_cut::Prepare(2,V(1),V(.5,.1,.5),glm::dquat(1,0,0,0));V reactions[2],torques[2];for(unsigned order=0;order<2;++order){Model m;BuildAggregate(m,geometry);if(order)std::reverse(m.rows.begin()+m.traceRows.size(),m.rows.end());for(const auto& c:m.cells)m.points[c.first].velocity={0,-9.81/240,0};auto result=ProjectRankEqualityQR(m);if(!result.accepted)throw std::runtime_error(result.error);V reaction(0),torque(0);for(unsigned i=0;i<m.rows.size();++i)for(auto g:m.rows[i].bodies){reaction-=g.linear*result.pressureImpulse[i];torque-=g.angular*result.pressureImpulse[i];}reactions[order]=reaction;torques[order]=torque;std::printf("REACTION order=%u rank=%u constraints=%u dofs=%u residual=%g max_speed=%g force=(%.17g %.17g %.17g) torque_norm=%.17g\n",order,result.rank,result.rows,result.dofs,result.residual,m.MaxSpeed(),reaction.x,reaction.y,reaction.z,glm::length(torque));}
 if(glm::length(reactions[0]-reactions[1])<1e-3&&glm::length(torques[0]-torques[1])<1e-3)throw std::runtime_error("control did not demonstrate reaction ambiguity");
 std::puts("DIAGNOSTIC demonstrated: calm endpoint is insufficient; aggregate pressure model is rejected");return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
