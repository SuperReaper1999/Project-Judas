from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path.cwd();here=Path(__file__).resolve().parent;out=here/'final-narrow';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':1,'sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'engineSha256':sha(root/'build/libjudas_engine.a'),'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Private geometry and rejected numerical references, NOT runtime fluid qualification','cases':[]}
for name,expected,marker in [
 ('AggregatePressureTests',1,'independent aggregate hydrostatic force/calm contract'),
 ('AggregateReactionOracle',0,'aggregate pressure model is rejected')]:
 log=out/(name+'.log')
 with log.open('w') as stream:
  run=subprocess.run(['python3',str(here/'run_probe.py'),name],cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
 text=log.read_text();binary=root/'.cache/fluid-contact-repair'/('stage7-'+name)
 record={'name':name,'exit':run.returncode,'expectedExit':expected,'marker':marker,'expectationMet':run.returncode==expected and marker in text,'sourceSha256':sha(here/(name+'.cpp')),'binarySha256':sha(binary) if binary.exists() else None,'logSha256':sha(log)}
 report['cases'].append(record);(here/'NARROW_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(record,flush=True)
 if not record['expectationMet']:raise RuntimeError('unexpected '+name)
print('Geometry references pass; two pressure approaches remain rejected. Diagnostic control is not fluid acceptance.')
