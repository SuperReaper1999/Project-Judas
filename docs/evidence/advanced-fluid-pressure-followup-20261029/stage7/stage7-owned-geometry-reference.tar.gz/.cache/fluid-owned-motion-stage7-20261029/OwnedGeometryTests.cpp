#include "OwnedCutGeometry.h"
#include <cstdio>
#include <chrono>
using V=glm::dvec3;
unsigned checks=0;void Check(bool b,const char* s){++checks;if(!b)throw std::runtime_error(s);}
void Test(double angle,V center,V half,bool contained){
 const auto q=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));
 const auto start=std::chrono::steady_clock::now();const auto mesh=owned_cut::Prepare(2,center,half,q);
 unsigned owned=0;V areaVector(0);double area=0,divergence=0;
 const auto planes=owned_cut::BoxPlanes(center,half,q);
 for(const auto& b:mesh.boundaries)if(b.solidPlane>=0){
  ++owned;const auto& a=mesh.mesh.vertices[b.vertices[0]].exact;
  const V x=owned_cut::Difference(mesh.mesh.vertices[b.vertices[1]].exact,a),y=owned_cut::Difference(mesh.mesh.vertices[b.vertices[2]].exact,a);
  const double faceArea=.5*glm::length(glm::cross(x,y));area+=faceArea;areaVector+=faceArea*b.normal;
  V centroid(0);for(auto i:b.vertices)centroid+=mesh.mesh.vertices[i].position/3.;
  divergence+=faceArea*glm::dot(-b.normal,centroid-center)/3;
  const auto& n=planes[b.solidPlane].normal;
  Check(glm::length(b.normal+glm::normalize(V(n[0],n[1],n[2])))<1e-15,"owned normal is actual native plane normal");
  for(auto i:b.vertices)Check(mesh.mesh.Side(i,mesh.mesh.bodyPlanes[b.solidPlane])==0,"solid face retains exact plane ancestry");
 }
 Check(owned>0,"real solid boundary survives arbitrary native rotation");
 if(contained){const double bodyVolume=8*half.x*half.y*half.z,bodyArea=8*(half.x*half.y+half.y*half.z+half.z*half.x);
  Check(std::abs(mesh.volume-(8-bodyVolume))<2e-12,"contained rotation preserves independent analytic capacity");
  Check(std::abs(area-bodyArea)<2e-11,"complete native surface area remains physically equivalent");
  Check(glm::length(areaVector)<2e-11,"closed solid normals independently balance");
  Check(std::abs(divergence-bodyVolume)<2e-11,"independent surface divergence gives solid volume");
 }
 std::printf("OWNED angle=%.17g tets=%zu owned_faces=%u area=%.17g volume=%.17g ms=%.6f\n",angle,mesh.mesh.tetrahedra.size(),owned,area,mesh.volume,std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count());
}
int main(){try{
 for(double a:{0.,3.2137858346770188e-11,1e-8,.001,.37,1.13})Test(a,V(1),V(.5,.1,.5),true);
 Test(3.2137858346770188e-11,V(.5,.849741397798061,.5),V(.5,.1,.5),false);
 std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
