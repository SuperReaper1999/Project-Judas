#include "OwnedCutGeometry.h"
#include "PhysicsWorld.h"
#include <cstdio>
#include <chrono>
unsigned checks=0;void Check(bool b,const char* message){++checks;if(!b)throw std::runtime_error(message);}
int main(){try{
 PhysicsWorld baseline,observed;baseline.Init();observed.Init();
 const auto a=baseline.CreateDynamicBox({1,1,1},{.5f,.1f,.5f},80,0,0),b=observed.CreateDynamicBox({1,1,1},{.5f,.1f,.5f},80,0,0);
 baseline.SetAngularVelocity(a,{.3f,1,-.2f});observed.SetAngularVelocity(b,{.3f,1,-.2f});baseline.SetLinearVelocity(a,{.01f,-.02f,.01f});observed.SetLinearVelocity(b,{.01f,-.02f,.01f});
 double totalMs=0,minimum=1e300;unsigned tets=0;
 for(unsigned step=0;step<16;++step){baseline.Step(1.f/240);observed.Step(1.f/240);const auto p=observed.GetTransform(b);const auto reference=baseline.GetTransform(a);
  Check(p.position==reference.position&&p.rotation==reference.rotation&&observed.GetLinearVelocity(b)==baseline.GetLinearVelocity(a)&&observed.GetAngularVelocity(b)==baseline.GetAngularVelocity(a),"geometry observation never changes native momentum or integration");
  const auto start=std::chrono::steady_clock::now();auto cut=owned_cut::Prepare(2,glm::dvec3(p.position),{.5,.1,.5},glm::dquat(p.rotation));
  totalMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();tets+=cut.mesh.tetrahedra.size();
  Check(std::abs(cut.volume-7.8)<2e-12,"actual rotating native body retains equivalent contained fluid capacity");
  unsigned solid=0;for(const auto& face:cut.boundaries)if(face.solidPlane>=0){++solid;for(auto v:face.vertices)Check(cut.mesh.Side(v,cut.mesh.bodyPlanes[face.solidPlane])==0,"moving solid face retains exact owner ancestry");}
  Check(solid>0,"native rotation cannot turn a solid into an open fluid boundary");
  minimum=std::min(minimum,cut.volume);
 }
 // Reproduce the exact stage6 first divergent native quaternion, not an ideal
 // axis-angle approximation. The surrounding wet volume is explicitly owned.
 const glm::dquat q(1,-1.2221851948459456e-13,1.1333153104975015e-20,1.6068929173385094e-11);
 std::vector<fluid_mesh::Compiler::WetCell> wet(8);for(auto& region:wet)region={{{{1,0,0},2},{{0,1,0},1},{{0,0,1},1}}};
 const auto exact=owned_cut::Prepare(2,{.5,.849741397798061,.5},{.5,.1,.5},q,wet);
 unsigned owned=0;for(const auto& f:exact.boundaries)owned+=f.solidPlane>=0;
 Check(owned>0,"exact formerly failing native quaternion retains actual solid ownership");
 std::printf("MOTION snapshots=16 mean_geometry_ms=%g minimum_capacity=%.17g mean_tets=%g divergent_quaternion_owned_faces=%u\n",totalMs/16,minimum,double(tets)/16,owned);
 std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
