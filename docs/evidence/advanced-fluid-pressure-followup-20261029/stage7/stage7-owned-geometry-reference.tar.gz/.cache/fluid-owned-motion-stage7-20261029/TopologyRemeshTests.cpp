#include "OwnedCutGeometry.h"
#include <cstdio>
#include <numeric>
using V=glm::dvec3;using M=glm::dmat3;
unsigned checks=0;void Check(bool b,const char* s){++checks;if(!b)throw std::runtime_error(s);}
unsigned Components(const owned_cut::Snapshot& cut){
 const auto& mesh=cut.mesh;std::vector<unsigned> root(mesh.tetrahedra.size());std::iota(root.begin(),root.end(),0);const auto find=[&](unsigned a){while(root[a]!=a)a=root[a];return a;};
 std::map<std::array<unsigned,3>,unsigned> faces;constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned c=0;c<mesh.tetrahedra.size();++c)for(const auto& f:tri){const auto& ids=mesh.tetrahedra[c].vertices;std::array<unsigned,3> key{ids[f[0]],ids[f[1]],ids[f[2]]};std::sort(key.begin(),key.end());auto [at,inserted]=faces.emplace(key,c);if(!inserted)root[find(c)]=find(at->second);}
 std::set<unsigned> components;for(unsigned c=0;c<root.size();++c)components.insert(find(c));return components.size();
}
struct Moments {double volume=0,energy=0;V momentum{0},angular{0};};
Moments Integrate(const owned_cut::Snapshot& cut){
 Moments out;const M gradient(V(.2,.1,0),V(-.1,-.1,.03),V(.01,0,-.1));const V mean(.4,.2,-.3);
 for(const auto& t:cut.mesh.tetrahedra){const auto& ids=t.vertices;auto m=owned_metrics::Tetra({cut.mesh.vertices[ids[0]].exact,cut.mesh.vertices[ids[1]].exact,cut.mesh.vertices[ids[2]].exact,cut.mesh.vertices[ids[3]].exact});const V center=cut.mesh.vertices[ids[0]].position+(m.edge[0]+m.edge[1]+m.edge[2])*.25;
 const M ref(V(3,-1,-1)/80.,V(-1,3,-1)/80.,V(-1,-1,3)/80.),cov=m.edge*ref*glm::transpose(m.edge);const V velocity=mean+gradient*center;
 const double mass=1000*m.volume;const M mixed=mass*(glm::outerProduct(center,velocity)+cov*glm::transpose(gradient)),vCov=gradient*cov*glm::transpose(gradient);
 out.volume+=m.volume;out.momentum+=mass*velocity;out.angular+=V(mixed[2][1]-mixed[1][2],mixed[0][2]-mixed[2][0],mixed[1][0]-mixed[0][1]);out.energy+=.5*mass*(glm::dot(velocity,velocity)+vCov[0][0]+vCov[1][1]+vCov[2][2]);
 }return out;
}
int main(){try{
 const auto q=glm::angleAxis(.37,glm::normalize(V(1,2,-.3)));const auto initial=owned_cut::Prepare(2,V(1),V(.2),q);std::vector<fluid_mesh::Compiler::WetCell> partition(8);
 for(auto& cell:partition)cell={{{{1,0,0},.83}},{{{-1,0,0},-.83}}};
 const auto refined=owned_cut::Prepare(2,V(1),V(.2),q,partition);
 const auto a=Integrate(initial),b=Integrate(refined);
 Check(initial.mesh.tetrahedra.size()!=refined.mesh.tetrahedra.size(),"remesh actually changes integration partition");
 Check(std::abs(a.volume-b.volume)<2e-12,"same-time remesh preserves owned quantity");
 Check(glm::length(a.momentum-b.momentum)<1e-8,"same-time affine restriction preserves momentum");
 Check(glm::length(a.angular-b.angular)<1e-8,"same-time affine restriction preserves angular momentum");
 Check(std::abs(a.energy-b.energy)<1e-8,"same-time affine restriction preserves wave energy without flattening");
 auto wet=partition;for(auto& cell:wet)cell={{{{1,0,0},.4}},{{{-1,0,0},-.6}}};
 const auto disconnected=owned_cut::Prepare(2,V(1),V(.1),q,wet);
 Check(Components(disconnected)==2,"actual dry gap separates wet topology");
 Check(std::abs(disconnected.volume-7.192)<2e-12,"dry gap remains absent from physical capacity");
 for(auto& cell:wet)cell.push_back({{{1,0,0},.7},{{-1,0,0},-.3},{{0,1,0},1.2},{{0,-1,0},-.8},{{0,0,1},1.2},{{0,0,-1},-.8}});
 const auto connected=owned_cut::Prepare(2,V(1),V(.1),q,wet);
 Check(Components(connected)==1,"only an actually wet bridge reconnects components");
 Check(std::abs(connected.volume-7.224)<2e-12,"wet bridge adds only its owned physical volume");
 Check(Components(disconnected)==2,"preparing connection does not mutate old material topology");
 std::printf("REMESH old_tets=%zu new_tets=%zu quantity_error=%.17g momentum_error=%.17g angular_error=%.17g energy_error=%.17g disconnected_tets=%zu connected_tets=%zu\n",initial.mesh.tetrahedra.size(),refined.mesh.tetrahedra.size(),a.volume-b.volume,glm::length(a.momentum-b.momentum),glm::length(a.angular-b.angular),a.energy-b.energy,disconnected.mesh.tetrahedra.size(),connected.mesh.tetrahedra.size());
 std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
