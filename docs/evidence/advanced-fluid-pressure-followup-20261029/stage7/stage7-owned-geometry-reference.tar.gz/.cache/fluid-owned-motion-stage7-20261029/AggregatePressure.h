#pragma once
#include "OwnedCutGeometry.h"
#include "../fluid-owned-motion-stage7-kernel/AffineModel.h"
// Physical cells are connected wet pieces of a background voxel. Arrangement
// tetrahedra describe integration/ownership; they are not separate tiny masses.
inline void BuildAggregate(Model& model,const owned_cut::Snapshot& geometry){
 const auto& mesh=geometry.mesh;const unsigned count=mesh.tetrahedra.size();
 struct Face {std::array<unsigned,3> ids;std::vector<unsigned> owners;};
 std::map<std::array<unsigned,3>,Face> faces;constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned c=0;c<count;++c)for(const auto& f:tri){const auto& t=mesh.tetrahedra[c];std::array<unsigned,3> ids{t.vertices[f[0]],t.vertices[f[1]],t.vertices[f[2]]};auto key=ids;std::sort(key.begin(),key.end());auto& face=faces[key];face.ids=ids;face.owners.push_back(c);}
 std::vector<unsigned> parent(count);std::iota(parent.begin(),parent.end(),0);
 const auto find=[&](unsigned a){while(parent[a]!=a)a=parent[a];return a;};
 for(const auto& [key,f]:faces)if(f.owners.size()==2){auto a=f.owners[0],b=f.owners[1];if(mesh.tetrahedra[a].voxel==mesh.tetrahedra[b].voxel)parent[find(a)]=find(b);}
 std::map<unsigned,unsigned> components;std::vector<unsigned> cell(count);
 for(unsigned c=0;c<count;++c){auto [at,inserted]=components.emplace(find(c),components.size());cell[c]=at->second;}
 struct Moment {double volume=0;V first{0};M second{0};};
 std::vector<Moment> moments(components.size());
 for(unsigned c=0;c<count;++c){const auto& t=mesh.tetrahedra[c];const auto& ids=t.vertices;const auto metrics=owned_metrics::Tetra({mesh.vertices[ids[0]].exact,mesh.vertices[ids[1]].exact,mesh.vertices[ids[2]].exact,mesh.vertices[ids[3]].exact});
  const V origin=mesh.vertices[ids[0]].position;const M ref(V(3,-1,-1)/80.,V(-1,3,-1)/80.,V(-1,-1,3)/80.);const V center=origin+(metrics.edge[0]+metrics.edge[1]+metrics.edge[2])*.25;
  auto& m=moments[cell[c]];m.volume+=metrics.volume;m.first+=metrics.volume*center;m.second+=metrics.volume*(metrics.edge*ref*glm::transpose(metrics.edge)+glm::outerProduct(center,center));
 }
 for(unsigned c=0;c<moments.size();++c){const auto& m=moments[c];const V center=m.first/m.volume;const M covariance=m.second/m.volume-glm::outerProduct(center,center);M factor(0);
  for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double v=covariance[j][i];for(unsigned k=0;k<j;++k)v-=factor[k][i]*factor[k][j];if(i==j){if(!(v>0))throw std::runtime_error("connected physical cell covariance is not representable");factor[j][i]=std::sqrt(v);}else factor[j][i]=v/factor[j][j];}
  FluidCell f{{int(c),0,0},center,factor,glm::inverse(factor),1000*m.volume,unsigned(model.points.size()),{}};model.cells.push_back(f);for(unsigned k=0;k<4;++k)model.points.push_back({V(0),1/f.mass});
  Row row;for(unsigned k=0;k<3;++k)row.points.push_back({f.first+1+k,V(f.inverse[0][k],f.inverse[1][k],f.inverse[2][k])});model.traceRows.push_back(model.rows.size());model.Add(row,true);
 }
 model.center=geometry.solidCenter;model.half=geometry.solidHalf;model.bodyVolume=8*model.half.x*model.half.y*model.half.z;model.bodyMass=1000*model.bodyVolume;model.bodies.push_back({V(0),V(0),0,M(0)});
 using PlaneKey=std::array<owned_metrics::R,4>;
 using PatchKey=std::tuple<unsigned,unsigned,PlaneKey>;
 struct Patch {unsigned a,b;int solid;V normal;std::set<unsigned> vertices;};std::map<PatchKey,Patch> patches;
 for(const auto& [key,face]:faces){const unsigned a=cell[face.owners[0]],b=face.owners.size()==2?cell[face.owners[1]]:unsigned(-1);if(a==b)continue;
  unsigned plane=unsigned(-1);for(unsigned p=0;p<mesh.planes.size();++p)if(mesh.Side(key[0],p)==0&&mesh.Side(key[1],p)==0&&mesh.Side(key[2],p)==0){plane=p;break;}
  if(plane==unsigned(-1))throw std::runtime_error("physical cell interface lacks owned plane");
  const auto& definition=mesh.planes[plane];V normal(definition.normal[0],definition.normal[1],definition.normal[2]);normal=glm::normalize(normal);
  V centroid(0);for(auto i:key)centroid+=mesh.vertices[i].position/3.;if(glm::dot(normal,model.cells[a].center-centroid)>0)normal=-normal;
  int solid=-1;bool in=true;for(auto p:mesh.bodyPlanes)for(auto i:key)in&=mesh.Side(i,p)<=0;
  if(in)for(unsigned p=0;p<mesh.bodyPlanes.size();++p){bool on=true;for(auto i:key)on&=mesh.Side(i,mesh.bodyPlanes[p])==0;if(on){solid=int(p);const auto& n=mesh.planes[mesh.bodyPlanes[p]].normal;normal=-glm::normalize(V(n[0],n[1],n[2]));break;}}
  // Top of the tank is the explicit pressure-free boundary, not an implicit
  // interpretation of an unowned/missing solid face.
  bool open=b==unsigned(-1)&&solid<0;for(auto i:key)open&=mesh.vertices[i].position.y==2.;if(open)continue;
  PlaneKey canonical;unsigned pivot=0;while(pivot<3&&definition.normal[pivot]==0)++pivot;
  for(unsigned k=0;k<3;++k)canonical[k]=owned_metrics::R(definition.normal[k])/owned_metrics::R(definition.normal[pivot]);
  canonical[3]=owned_metrics::R(definition.coordinate)/owned_metrics::R(definition.normal[pivot]);
  auto [at,inserted]=patches.emplace(PatchKey{a,b,canonical},Patch{a,b,solid,normal,{}});at->second.vertices.insert(key.begin(),key.end());
 }
 for(const auto& [key,p]:patches){std::vector<unsigned> basis;
  for(auto v:p.vertices){if(basis.size()<2){basis.push_back(v);continue;}try{owned_metrics::Triangle({mesh.vertices[basis[0]].exact,mesh.vertices[basis[1]].exact,mesh.vertices[v].exact});basis.push_back(v);break;}catch(const std::runtime_error&){}}
  if(basis.size()!=3)throw std::runtime_error("physical patch lacks three independent owned vertices");
  // The normal velocity is affine on this exact plane. Three noncollinear
  // evaluations span ALL tessellation-corner equalities, without a rank epsilon.
  for(auto v:basis){const V point=mesh.vertices[v].position;Row row;model.Evaluation(row,model.cells[p.a],point,p.normal);if(p.b!=unsigned(-1))model.Evaluation(row,model.cells[p.b],point,p.normal,-1);else if(p.solid>=0)row.bodies.push_back({0,-p.normal,-glm::cross(point-model.center,p.normal)});model.Add(row,true);}
 }
}
