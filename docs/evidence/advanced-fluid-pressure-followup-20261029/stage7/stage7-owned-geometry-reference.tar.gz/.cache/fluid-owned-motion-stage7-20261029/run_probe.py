from pathlib import Path
import sys,subprocess,os
sys.path.insert(0,'.cache/fluid-contact-repair');import setup_probes as b
boost=Path(os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'))
if not (boost/'boost/multiprecision/cpp_int.hpp').is_file():raise RuntimeError('Set BOOST_INCLUDE_DIR to locally extracted Boost 1.90 headers; no engine dependency is changed')
b.compile_flags+=['-I'+str(boost)]
name=sys.argv[1];src=Path('.cache/fluid-owned-motion-stage7-20261029')/(name+'.cpp')
b.executable(b.compile(src.resolve(),'stage7-'+name),'stage7-'+name,b.out/'stage5-exact-volume-domain.o')
raise SystemExit(subprocess.run([str(b.out/('stage7-'+name)),*sys.argv[2:]]).returncode)
