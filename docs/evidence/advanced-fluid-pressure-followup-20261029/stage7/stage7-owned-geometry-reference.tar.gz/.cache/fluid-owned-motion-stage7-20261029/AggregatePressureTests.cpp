#include "../fluid-owned-motion-stage7-kernel/AffineModel.h"
#include "../fluid-owned-motion-stage7-kernel/SparseInterior.h"
#include "../fluid-owned-motion-stage7-kernel/RankEqualityQR.h"
#include "AggregatePressure.h"
#include <cstdio>
#include <chrono>
int main(){unsigned checks=0;try{for(double angle:{0.,3.2137858346770188e-11,1e-8,.001,.37}){
 const auto q=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));auto cut=owned_cut::Prepare(2,V(1),V(.5,.1,.5),q);Model m;BuildAggregate(m,cut);
 for(const auto& c:m.cells)m.points[c.first].velocity={0,-9.81/240,0};
 const auto start=std::chrono::steady_clock::now();auto result=ProjectRankEqualityQR(m);V impulse(0),torque(0);for(unsigned i=0;i<m.rows.size();++i)for(auto g:m.rows[i].bodies){impulse-=g.linear*result.pressureImpulse[i];torque-=g.angular*result.pressureImpulse[i];}
 std::printf("AGGREGATE angle=%.17g tets=%zu cells=%zu rows=%zu accepted=%d residual=%.17g load=(%.17g %.17g %.17g) torque=%.17g maxSpeed=%.17g ms=%.6f error=%s\n",angle,cut.mesh.tetrahedra.size(),m.cells.size(),m.rows.size(),result.accepted,result.residual,impulse.x,impulse.y,impulse.z,glm::length(torque),m.MaxSpeed(),std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(),result.error.c_str());std::fflush(stdout);
 if(!result.accepted)throw std::runtime_error("owned aggregate pressure convergence");
 ++checks;
 if(std::abs(impulse.y-.2*1000*9.81/240)>1e-6||glm::length(V(impulse.x,0,impulse.z))>1e-6||glm::length(torque)>1e-6||m.MaxSpeed()>1e-8)throw std::runtime_error("independent aggregate hydrostatic force/calm contract");
 ++checks;
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
