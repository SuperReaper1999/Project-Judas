#pragma once
// Bounded direct equality reference. Fluid trace is ELIMINATED in coordinates,
// never stored as an approximately projected 12-dimensional constraint row.
struct RankEqualityQrResult {
 bool accepted=false;std::string error;double residual=0,divergence=0;
 unsigned rows=0,dofs=0,rank=0;std::vector<double> pressureImpulse;
};
namespace fluid_rank_equality {
using Nine=std::array<double,9>;
struct LocalBasis {
 Nine reflector{};double tau=0,inverseMass=0;unsigned first=0;
 void Transform(Nine& values)const{double dot=values[0];for(unsigned i=1;i<9;++i)dot+=reflector[i]*values[i];dot*=tau;values[0]-=dot;for(unsigned i=1;i<9;++i)values[i]-=reflector[i]*dot;}
};
inline M InverseInertiaRoot(const M& source){
 M lower(0);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double value=source[j][i];for(unsigned k=0;k<j;++k)value-=lower[k][i]*lower[k][j];if(i==j){if(value<0||!std::isfinite(value))throw std::invalid_argument("invalid physical inverse inertia");lower[j][i]=std::sqrt(value);}else if(lower[j][j]>0)lower[j][i]=value/lower[j][j];else if(value!=0)throw std::invalid_argument("inconsistent singular inverse inertia");}return lower;
}
}
inline RankEqualityQrResult ProjectRankEqualityQR(Model& model,double tolerance=1e-10,
                                          std::vector<double>* diagnosticMatrix=nullptr){
 using namespace fluid_rank_equality;RankEqualityQrResult result;
 try{
  if(model.rows.size()>512||model.points.size()>2048)throw std::invalid_argument("bounded dense equality reference exceeded");
  const unsigned cells=model.cells.size(),fluidDofs=11*cells,d=fluidDofs+6*model.bodies.size();
  std::vector<LocalBasis> basis;std::vector<unsigned> pointOwner(model.points.size(),unsigned(-1));std::vector<double> coordinates(fluidDofs);
  for(unsigned c=0;c<cells;++c){const auto& cell=model.cells[c];LocalBasis local;local.first=cell.first;local.inverseMass=model.points.at(cell.first).inverseMass;if(!(local.inverseMass>0)||!std::isfinite(local.inverseMass))throw std::invalid_argument("invalid fluid mass");Nine trace{},affine{};
   for(unsigned k=0;k<4;++k){if(pointOwner.at(cell.first+k)!=unsigned(-1)||model.points[cell.first+k].inverseMass!=local.inverseMass)throw std::invalid_argument("inconsistent owned fluid degrees");pointOwner[cell.first+k]=c;}
   for(unsigned k=0;k<3;++k){const V g=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);for(unsigned a=0;a<3;++a){trace[3*k+a]=g[a];affine[3*k+a]=model.points[cell.first+1+k].velocity[a];coordinates[11*c+a]=model.points[cell.first].velocity[a];}}
   double norm=0;for(double v:trace)norm=std::hypot(norm,v);if(!(norm>0))throw std::runtime_error("empty fluid trace operator");const double diagonal=-std::copysign(norm,trace[0]),first=trace[0]-diagonal;local.tau=(diagonal-trace[0])/diagonal;local.reflector[0]=1;for(unsigned i=1;i<9;++i)local.reflector[i]=trace[i]/first;
   local.Transform(affine);for(unsigned i=1;i<9;++i)coordinates[11*c+2+i]=affine[i];basis.push_back(local);
  }
  for(unsigned owner:pointOwner)if(owner==unsigned(-1))throw std::invalid_argument("unowned fluid degree in equality solve");
  std::vector<unsigned> rowIndex;std::set<unsigned> traces(model.traceRows.begin(),model.traceRows.end());
  for(unsigned i=0;i<model.rows.size();++i)if(!traces.count(i)){if(!model.bilateral.at(i))throw std::invalid_argument("equality reference requires bilateral rows");rowIndex.push_back(i);}
  const unsigned n=rowIndex.size();result.rows=n;result.dofs=d;result.pressureImpulse.assign(model.rows.size(),0);
  std::vector<M> inertiaRoots;for(const auto& body:model.bodies){if(body.inverseMass<0||!std::isfinite(body.inverseMass))throw std::invalid_argument("invalid body mobility");inertiaRoots.push_back(InverseInertiaRoot(body.inverseInertia));}
  std::vector<double> qr(d*n,0),rhs(n),rowScale(n),tau(n);
  for(unsigned j=0;j<n;++j){const auto& row=model.rows[rowIndex[j]];std::vector<Nine> raw(cells);std::vector<V> mean(cells,V(0));double r=-row.maximumRate;
   for(auto g:row.points){const unsigned c=pointOwner.at(g.point),offset=g.point-basis[c].first;if(offset==0)mean[c]+=g.gradient;else for(unsigned a=0;a<3;++a)raw[c][3*(offset-1)+a]+=g.gradient[a];}
   for(unsigned c=0;c<cells;++c){const double mass=std::sqrt(basis[c].inverseMass);for(unsigned a=0;a<3;++a){qr[j*d+11*c+a]=mass*mean[c][a];r+=mean[c][a]*coordinates[11*c+a];}basis[c].Transform(raw[c]);for(unsigned i=1;i<9;++i){qr[j*d+11*c+2+i]=mass*raw[c][i];r+=raw[c][i]*coordinates[11*c+2+i];}}
   for(auto g:row.bodies){const auto& body=model.bodies.at(g.body);r+=glm::dot(g.linear,body.velocity)+glm::dot(g.angular,body.angularVelocity);for(unsigned a=0;a<3;++a){qr[j*d+fluidDofs+6*g.body+a]+=std::sqrt(body.inverseMass)*g.linear[a];qr[j*d+fluidDofs+6*g.body+3+a]+=glm::dot(inertiaRoots[g.body][a],g.angular);}}
   double norm=0;for(unsigned i=0;i<d;++i)norm=std::hypot(norm,qr[j*d+i]);if(!(norm>0)||!std::isfinite(norm))throw std::runtime_error("empty physical equality row");rowScale[j]=1/norm;for(unsigned i=0;i<d;++i)qr[j*d+i]*=rowScale[j];rhs[j]=r*rowScale[j];
  }
  if(diagnosticMatrix)*diagnosticMatrix=qr;
  unsigned rank=0;
  const double rankTolerance=64*std::numeric_limits<double>::epsilon()*std::max(n,d);
  for(unsigned k=0;k<std::min(n,d);++k){
   unsigned pivot=k;double maximum=0;
   for(unsigned j=k;j<n;++j){double norm=0;for(unsigned i=k;i<d;++i)norm=std::hypot(norm,qr[j*d+i]);if(norm>maximum){maximum=norm;pivot=j;}}
   if(maximum<=rankTolerance)break;
   if(pivot!=k){for(unsigned i=0;i<d;++i)std::swap(qr[k*d+i],qr[pivot*d+i]);std::swap(rhs[k],rhs[pivot]);std::swap(rowScale[k],rowScale[pivot]);std::swap(rowIndex[k],rowIndex[pivot]);}
   const double old=qr[k*d+k],diagonal=-std::copysign(maximum,old),v0=old-diagonal;tau[k]=(diagonal-old)/diagonal;qr[k*d+k]=diagonal;for(unsigned i=k+1;i<d;++i)qr[k*d+i]/=v0;
   for(unsigned j=k+1;j<n;++j){double dot=qr[j*d+k];for(unsigned i=k+1;i<d;++i)dot+=qr[k*d+i]*qr[j*d+i];dot*=tau[k];qr[j*d+k]-=dot;for(unsigned i=k+1;i<d;++i)qr[j*d+i]-=qr[k*d+i]*dot;}
   ++rank;
  }
  result.rank=rank;
  std::vector<double> correction(d,0);for(unsigned i=0;i<rank;++i){double r=rhs[i];for(unsigned j=0;j<i;++j)r-=qr[i*d+j]*correction[j];correction[i]=r/qr[i*d+i];}
  auto dual=correction;for(unsigned k=rank;k-->0;){for(unsigned j=k+1;j<rank;++j)dual[k]-=qr[j*d+k]*dual[j];dual[k]/=qr[k*d+k];result.pressureImpulse[rowIndex[k]]=rowScale[k]*dual[k];}
  for(unsigned k=rank;k-->0;){double dot=correction[k];for(unsigned i=k+1;i<d;++i)dot+=qr[k*d+i]*correction[i];dot*=tau[k];correction[k]-=dot;for(unsigned i=k+1;i<d;++i)correction[i]-=qr[k*d+i]*dot;}
  auto points=model.points;auto bodies=model.bodies;
  for(unsigned c=0;c<cells;++c){const auto& local=basis[c];const double weight=std::sqrt(local.inverseMass);for(unsigned a=0;a<3;++a)points[local.first].velocity[a]=coordinates[11*c+a]-weight*correction[11*c+a];Nine affine{};for(unsigned i=1;i<9;++i)affine[i]=coordinates[11*c+2+i]-weight*correction[11*c+2+i];local.Transform(affine);for(unsigned k=0;k<3;++k)for(unsigned a=0;a<3;++a)points[local.first+1+k].velocity[a]=affine[3*k+a];}
  for(unsigned b=0;b<bodies.size();++b){V linear,angular;for(unsigned a=0;a<3;++a){linear[a]=correction[fluidDofs+6*b+a];angular[a]=correction[fluidDofs+6*b+3+a];}bodies[b].velocity-=std::sqrt(bodies[b].inverseMass)*linear;bodies[b].angularVelocity-=inertiaRoots[b]*angular;}
  for(unsigned i:rowIndex){const auto& row=model.rows[i];double residual=-row.maximumRate;for(auto g:row.points)residual+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:row.bodies)residual+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);result.residual=std::max(result.residual,std::abs(residual));}
  for(const auto& cell:model.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){V g=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(g,points[cell.first+1+k].velocity);norm+=glm::dot(g,g);}result.divergence=std::max(result.divergence,std::abs(trace)/std::sqrt(norm));}
  if(!std::isfinite(result.residual)||result.residual>tolerance||result.divergence>tolerance)throw std::runtime_error("QR physical residual verification failed");
  model.points=std::move(points);model.bodies=std::move(bodies);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
