#pragma once
#include "ExactPlanePredicates.h"
#include <glm/glm.hpp>
#include <boost/multiprecision/cpp_int.hpp>
namespace owned_metrics {
using R=boost::multiprecision::cpp_rational;
using RV=std::array<R,3>;
inline R Rational(const fluid_exact::Expansion& e){R out=0;for(double x:e)out+=R(x);return out;}
inline RV Position(const fluid_exact::Intersection& p){RV out;const R d=Rational(p.denominator);for(unsigned i=0;i<3;++i)out[i]=Rational(p.numerator[i])/d;return out;}
inline RV Cross(const RV& a,const RV& b){RV c;for(unsigned i=0;i<3;++i)c[i]=a[(i+1)%3]*b[(i+2)%3]-a[(i+2)%3]*b[(i+1)%3];return c;}
inline R Dot(const RV& a,const RV& b){R r=0;for(unsigned i=0;i<3;++i)r+=a[i]*b[i];return r;}
struct FaceMetric {glm::dvec3 normal;double area;};
inline FaceMetric Triangle(const std::array<fluid_exact::Intersection,3>& p){
 const RV origin=Position(p[0]);RV a=Position(p[1]),b=Position(p[2]);
 for(unsigned k=0;k<3;++k){a[k]-=origin[k];b[k]-=origin[k];}
 const RV cross=Cross(a,b);R maximum=0;
 for(const auto& v:cross){R magnitude=v<0?-v:v;if(magnitude>maximum)maximum=magnitude;}
 if(maximum==0)throw std::runtime_error("degenerate exact owned face");
 glm::dvec3 unit;for(unsigned k=0;k<3;++k)unit[k]=(cross[k]/maximum).convert_to<double>();
 const double magnitude=glm::length(unit);return {unit/magnitude,.5*maximum.convert_to<double>()*magnitude};
}
struct Frame {glm::dmat3 edge,inverse;double volume;};
inline Frame Tetra(const std::array<fluid_exact::Intersection,4>& p){
 std::array<RV,3> e;const RV a=Position(p[0]);
 for(unsigned i=0;i<3;++i){const RV b=Position(p[i+1]);for(unsigned k=0;k<3;++k)e[i][k]=b[k]-a[k];}
 const R determinant=Dot(e[0],Cross(e[1],e[2]));
 if(determinant<=0)throw std::runtime_error("nonpositive exact owned tetrahedron");
 Frame result;result.volume=(determinant/6).convert_to<double>();
 if(!(result.volume>0))throw std::runtime_error("unrepresentable positive owned volume");
 for(unsigned i=0;i<3;++i){const RV cross=Cross(e[(i+1)%3],e[(i+2)%3]);for(unsigned k=0;k<3;++k){
  result.edge[i][k]=e[i][k].convert_to<double>();result.inverse[k][i]=(cross[k]/determinant).convert_to<double>();
  if(!std::isfinite(result.edge[i][k])||!std::isfinite(result.inverse[k][i]))throw std::runtime_error("unrepresentable owned cell frame");
 }}return result;
}
}
