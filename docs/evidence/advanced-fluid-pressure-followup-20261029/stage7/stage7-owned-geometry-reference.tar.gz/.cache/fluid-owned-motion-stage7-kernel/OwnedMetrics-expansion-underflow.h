#pragma once
#include "ExactPlanePredicates.h"
#include <glm/glm.hpp>
namespace owned_metrics {
using E=fluid_exact::Expansion;
using EV=std::array<E,3>;
using V=glm::dvec3;
inline E Sub(E a,const E& b){return fluid_exact::Sum(std::move(a),fluid_exact::Negate(b));}
inline EV Cross(const EV& a,const EV& b){EV c;for(unsigned i=0;i<3;++i)c[i]=Sub(fluid_exact::Product(a[(i+1)%3],b[(i+2)%3]),fluid_exact::Product(a[(i+2)%3],b[(i+1)%3]));return c;}
inline E Dot(const EV& a,const EV& b){E r{0};for(unsigned i=0;i<3;++i)r=fluid_exact::Sum(std::move(r),fluid_exact::Product(a[i],b[i]));return r;}
inline double Ratio(const E& a,const E& b){const double value=fluid_exact::Estimate(a)/fluid_exact::Estimate(b);if(!std::isfinite(value))throw std::runtime_error("unrepresentable owned metric");return value;}
struct Frame {glm::dmat3 edge,inverse;double volume;};
inline Frame Tetra(const std::array<fluid_exact::Intersection,4>& p){
 std::array<EV,3> n;std::array<E,3> d;
 for(unsigned e=0;e<3;++e){d[e]=fluid_exact::Product(p[e+1].denominator,p[0].denominator);for(unsigned a=0;a<3;++a)n[e][a]=Sub(fluid_exact::Product(p[e+1].numerator[a],p[0].denominator),fluid_exact::Product(p[0].numerator[a],p[e+1].denominator));}
 const E numerator=Dot(n[0],Cross(n[1],n[2]));
 const E denominator=fluid_exact::Product(fluid_exact::Product(d[0],d[1]),d[2]);
 Frame result;result.volume=Ratio(numerator,denominator)/6.;
 if(fluid_exact::Sign(numerator)*fluid_exact::Sign(denominator)<=0||!(result.volume>0))throw std::runtime_error("nonpositive exact owned tetrahedron");
 for(unsigned e=0;e<3;++e){const EV cross=Cross(n[(e+1)%3],n[(e+2)%3]);for(unsigned a=0;a<3;++a){result.edge[e][a]=Ratio(n[e][a],d[e]);result.inverse[a][e]=Ratio(fluid_exact::Product(cross[a],d[e]),numerator);}}
 return result;
}
}
