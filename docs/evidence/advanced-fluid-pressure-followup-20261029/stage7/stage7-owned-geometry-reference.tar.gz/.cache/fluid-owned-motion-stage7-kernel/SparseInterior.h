#pragma once
#include "MixedProjection.h"
#include <map>
#include <set>
#include <numeric>
#include <chrono>
#include <memory>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <stdexcept>
// Disposable sparse Cholesky reference. No diagonal regularization or added
// physical compliance; every pivot must be positive in the barrier system.
struct SingularPressureCandidate:std::runtime_error{using std::runtime_error::runtime_error;};
struct SparseFactor {
 unsigned n;std::vector<unsigned> order,inverse;std::vector<std::vector<unsigned>> columns;
 std::vector<std::vector<double>> source;std::vector<std::vector<unsigned>> targets,pattern;
 SparseFactor(const std::vector<std::map<unsigned,double>>& a):n(a.size()),order(n),inverse(n),columns(n),source(n),targets(n),pattern(n){
  for(unsigned i=0;i<n;++i)for(auto [j,v]:a[i])if(v!=0)pattern[i].push_back(j);
  std::vector<std::set<unsigned>> graph(n);for(unsigned i=0;i<n;++i)for(auto [j,v]:a[i])if(i!=j&&v!=0){graph[i].insert(j);graph[j].insert(i);}
  std::set<std::pair<unsigned,unsigned>> queue;std::vector<bool> active(n,true);for(unsigned i=0;i<n;++i)queue.emplace(graph[i].size(),i);
  std::vector<std::vector<unsigned>> neighbors(n);
  for(unsigned k=0;k<n;++k){auto [degree,i]=*queue.begin();queue.erase(queue.begin());order[k]=i;inverse[i]=k;active[i]=false;neighbors[k].assign(graph[i].begin(),graph[i].end());
   for(auto j:neighbors[k]){queue.erase({unsigned(graph[j].size()),j});graph[j].erase(i);}
   for(auto j:neighbors[k])for(auto l:neighbors[k])if(j!=l)graph[j].insert(l);
   for(auto j:neighbors[k])queue.emplace(graph[j].size(),j);
  }
  for(unsigned k=0;k<n;++k){columns[k].push_back(k);for(auto j:neighbors[k])columns[k].push_back(inverse[j]);std::sort(columns[k].begin()+1,columns[k].end());source[k].resize(columns[k].size());for(unsigned t=0;t<columns[k].size();++t){const auto i=order[k],j=order[columns[k][t]];auto f=a[std::min(i,j)].find(std::max(i,j));source[k][t]=f==a[std::min(i,j)].end()?0:f->second;}}
  for(unsigned k=0;k<n;++k)for(unsigned t=1;t<columns[k].size();++t){unsigned j=columns[k][t];auto begin=columns[j].begin();for(unsigned u=t;u<columns[k].size();++u){auto at=std::lower_bound(begin,columns[j].end(),columns[k][u]);if(at==columns[j].end()||*at!=columns[k][u])throw std::runtime_error("missing symbolic factor fill");targets[k].push_back(unsigned(at-columns[j].begin()));begin=at;}}
 }
 bool Matches(const std::vector<std::map<unsigned,double>>& a)const{if(a.size()!=n)return false;for(unsigned i=0;i<n;++i){unsigned k=0;for(auto [j,v]:a[i])if(v!=0){if(k>=pattern[i].size()||pattern[i][k++]!=j)return false;}if(k!=pattern[i].size())return false;}return true;}
 void Update(const std::vector<std::map<unsigned,double>>& a){if(!Matches(a))throw std::runtime_error("changed pressure topology needs symbolic rebuild");for(unsigned k=0;k<n;++k)for(unsigned t=0;t<columns[k].size();++t){const auto i=order[k],j=order[columns[k][t]];auto at=a[std::min(i,j)].find(std::max(i,j));source[k][t]=at==a[std::min(i,j)].end()?0:at->second;}}
 std::vector<std::vector<double>> Factor(const std::vector<double>& diagonal)const{
  auto values=source;for(unsigned k=0;k<n;++k)values[k][0]+=diagonal[order[k]];
  for(unsigned k=0;k<n;++k){auto& col=values[k];const double pivot=col[0];if(!(pivot>0)||!std::isfinite(pivot))throw SingularPressureCandidate("nonpositive sparse physical pivot");col[0]=std::sqrt(pivot);for(unsigned t=1;t<col.size();++t)col[t]/=col[0];
   unsigned target=0;for(unsigned t=1;t<col.size();++t){const unsigned j=columns[k][t];for(unsigned u=t;u<col.size();++u)values[j][targets[k][target++]]-=col[t]*col[u];}
  }
  return values;
 }
 std::vector<double> Solve(const std::vector<double>& rhs,const std::vector<std::vector<double>>& values)const{
  std::vector<double> x(n);for(unsigned k=0;k<n;++k)x[k]=rhs[order[k]];
  for(unsigned k=0;k<n;++k){x[k]/=values[k][0];for(unsigned t=1;t<values[k].size();++t)x[columns[k][t]]-=values[k][t]*x[k];}
  for(unsigned k=n;k-->0;){for(unsigned t=1;t<values[k].size();++t)x[k]-=values[k][t]*x[columns[k][t]];x[k]/=values[k][0];}
  std::vector<double> result(n);for(unsigned k=0;k<n;++k)result[order[k]]=x[k];return result;
 }
};
struct SparseWorkspace{double assemblyMs=0,bodyColumnsMs=0;unsigned calls=0,operatorBuilds=0,operatorHits=0;
 std::vector<std::vector<pressure_prototype::PointGradient>> operatorRows;
 std::vector<double> operatorMasses,operatorScale;
 std::vector<std::map<unsigned,double>> operatorMatrix;std::unique_ptr<SparseFactor> factor;unsigned rebuilds=0,warmHits=0,directHits=0,directRejected=0;std::vector<std::vector<double>> directSource,directFactor;std::vector<double> pressureImpulse;};
struct VelocityProjectionResult:pressure_prototype::Result{double maximumRelativeWork=0;};
inline VelocityProjectionResult SparseInterior(std::vector<pressure_prototype::Point>& points,std::vector<pressure_prototype::Body>& bodies,const std::vector<pressure_prototype::Row>& rows,const std::vector<bool>& bilateral,unsigned budget,double tolerance,SparseWorkspace* cached=nullptr,double relativeWorkTolerance=1e-10){
 using namespace pressure_prototype;VelocityProjectionResult result;const unsigned n=rows.size();result.pressureImpulse.assign(n,0);
 SparseWorkspace local;auto& workspace=cached?*cached:local;++workspace.calls;
 const auto assemblyStart=std::chrono::steady_clock::now();
 // Cache only the fluid mass/Jacobian operator. Exact numeric comparison,
 // including point identities, prevents reuse across moved/replaced geometry.
 // Body inertia, gradients, velocities, row limits and inequality policy remain
 // current inputs and are deliberately NOT cached by this mechanism.
 bool sameOperator=false; // Reference mixed Gram includes current native rigid geometry/mobility.
 for(unsigned p=0;p<points.size()&&sameOperator;++p)sameOperator=workspace.operatorMasses[p]==points[p].inverseMass;
 for(unsigned i=0;i<n&&sameOperator;++i){const auto& old=workspace.operatorRows[i];const auto& now=rows[i].points;sameOperator=old.size()==now.size();for(unsigned g=0;g<old.size()&&sameOperator;++g)sameOperator=old[g].point==now[g].point&&old[g].gradient==now[g].gradient;}
 if(!sameOperator){
  std::vector<std::map<unsigned,double>> assembled(n);
  std::vector<std::vector<std::pair<unsigned,glm::dvec3>>> incident(points.size());
  for(unsigned i=0;i<n;++i)for(auto g:rows[i].points)incident.at(g.point).push_back({i,g.gradient});
  for(unsigned p=0;p<incident.size();++p)for(auto [i,a]:incident[p])for(auto [j,b]:incident[p])if(i<=j)assembled[i][j]+=points[p].inverseMass*glm::dot(a,b);
  // Exact full mixed Gram reference. Native contact rows have no fluid
  // entries; their diagonal comes from actual rigid mass/inertia. No fictitious
  // particles, regularization, or equality assumption for unilateral contacts.
  for(unsigned b=0;b<bodies.size();++b){
   struct Gradient {unsigned row;glm::dvec3 linear,angular;};std::vector<Gradient> gradients;
   for(unsigned i=0;i<n;++i){glm::dvec3 linear(0),angular(0);bool found=false;
    for(auto g:rows[i].bodies)if(g.body==b){linear+=g.linear;angular+=g.angular;found=true;}
    if(found)gradients.push_back({i,linear,angular});}
   for(unsigned i=0;i<gradients.size();++i)for(unsigned j=i;j<gradients.size();++j){const auto& a=gradients[i];const auto& c=gradients[j];
    assembled[a.row][c.row]+=bodies[b].inverseMass*glm::dot(a.linear,c.linear)+glm::dot(a.angular,bodies[b].inverseInertia*c.angular);}
  }
  std::vector<double> scaling(n);
  for(unsigned i=0;i<n;++i){double d=assembled[i][i];if(!(d>0)||!std::isfinite(d))throw std::runtime_error("empty or invalid pressure constraint");scaling[i]=1/std::sqrt(d);}
  for(unsigned i=0;i<n;++i)for(auto& [j,v]:assembled[i])v*=scaling[i]*scaling[j];
  std::vector<std::vector<PointGradient>> keys;keys.reserve(n);for(const auto& row:rows)keys.push_back(row.points);
  std::vector<double> masses;for(const auto& point:points)masses.push_back(point.inverseMass);
  workspace.operatorRows=std::move(keys);workspace.operatorMasses=std::move(masses);workspace.operatorScale=std::move(scaling);workspace.operatorMatrix=std::move(assembled);++workspace.operatorBuilds;
 }else ++workspace.operatorHits;
 const auto& matrix=workspace.operatorMatrix;
 const auto& scale=workspace.operatorScale;
 workspace.assemblyMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-assemblyStart).count();
 const auto bodyStart=std::chrono::steady_clock::now();
 // Keep each finite body's six physical degrees of freedom low rank.
 // Forming their Gram entries as a pressure-row clique needlessly densifies
 // the otherwise local fluid operator; Woodbury below is algebraically exact.
 std::vector<std::vector<double>> bodyColumns;
 // Rigid response is already included above, never add it again through Woodbury.
 workspace.bodyColumnsMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-bodyStart).count();
 std::vector<double> rhs(n),lambda(n,0),z(n,0);unsigned contacts=0;
 for(unsigned i=0;i<n;++i){double v=-rows[i].maximumRate;for(auto g:rows[i].points)v+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)v+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);rhs[i]=v*scale[i];if(!bilateral[i]){lambda[i]=z[i]=1;++contacts;}}
 double initialResidual=0;for(unsigned i=0;i<n;++i){const double v=rhs[i]/scale[i];initialResidual=std::max(initialResidual,bilateral[i]?std::abs(v):std::max(0.,v));}if(initialResidual<=tolerance){result.converged=true;result.maximumResidual=initialResidual;return result;}
 for(auto& column:bodyColumns)for(unsigned i=0;i<n;++i)column[i]*=scale[i];
 // Every row is a physical normal velocity constraint (m/s). Complementarity
 // work has energy units and must not share an absolute velocity threshold.
 // Use the natural residual in velocity units, and a SEPARATE dimensionless
 // relative-work check. Both are invariant under consistent mass-unit changes.
 double workScale=0;for(double value:rhs)workScale+=value*value;
 const double initialScale=std::sqrt(workScale/std::max(1u,n));if(!(initialScale>0)||!std::isfinite(initialScale))throw std::invalid_argument("unrepresentable pressure normalization");for(unsigned i=0;i<n;++i)if(!bilateral[i])lambda[i]=z[i]=initialScale;
 std::vector<double> effectiveDiagonal(n);for(unsigned i=0;i<n;++i){effectiveDiagonal[i]=matrix[i].at(i);for(const auto& column:bodyColumns)effectiveDiagonal[i]+=column[i]*column[i];}
 auto measure=[&](const std::vector<double>& impulses,const std::vector<double>& residual){double velocityError=0,work=0;for(unsigned i=0;i<n;++i){const double natural=bilateral[i]?std::abs(residual[i]):std::abs(std::min(impulses[i]*effectiveDiagonal[i],-residual[i]));velocityError=std::max(velocityError,natural/scale[i]);work=std::max(work,std::abs(impulses[i]*residual[i]));}return std::pair<double,double>{velocityError,workScale>0?work/workScale:work};};

 auto multiply=[&](const std::vector<double>& x){std::vector<double> output(n,0);for(unsigned i=0;i<n;++i)for(auto [j,v]:matrix[i]){output[i]+=v*x[j];if(i!=j)output[j]+=v*x[i];}for(const auto& column:bodyColumns){double dot=0;for(unsigned i=0;i<n;++i)dot+=column[i]*x[i];for(unsigned i=0;i<n;++i)output[i]+=column[i]*dot;}++result.matrixProducts;return output;};
 bool warmAccepted=false;
 if(workspace.pressureImpulse.size()==n){std::vector<double> candidate(n);bool feasible=true;for(unsigned i=0;i<n;++i){candidate[i]=workspace.pressureImpulse[i]/scale[i];feasible&=std::isfinite(candidate[i])&&(bilateral[i]||candidate[i]>=0);}if(feasible){auto product=multiply(candidate);for(unsigned i=0;i<n;++i)product[i]=rhs[i]-product[i];const auto error=measure(candidate,product);if(error.first<=tolerance&&error.second<=relativeWorkTolerance){lambda=std::move(candidate);warmAccepted=true;++workspace.warmHits;}}}
 auto setupStart=std::chrono::steady_clock::now();bool rebuilt=!warmAccepted&&(!workspace.factor||!workspace.factor->Matches(matrix));if(rebuilt){workspace.factor=std::make_unique<SparseFactor>(matrix);++workspace.rebuilds;}else if(!warmAccepted)workspace.factor->Update(matrix);double factorMs=0;double setupMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-setupStart).count();
 bool directAttempt=false;std::vector<std::vector<double>> numericalFactor,inverseColumns;std::vector<double> bodyFactor;
 auto direction=[&](const std::vector<double>& residual,const std::vector<double>& comp,std::vector<double>& dl,std::vector<double>& dz){std::vector<double> diagonal(n,0),r(n);for(unsigned i=0;i<n;++i){r[i]=-residual[i];if(!bilateral[i]){diagonal[i]=directAttempt?0:z[i]/lambda[i];if(!directAttempt)r[i]-=comp[i]/lambda[i];}}auto solveStart=std::chrono::steady_clock::now();if(numericalFactor.empty()){if(directAttempt&&workspace.directSource==workspace.factor->source&&!workspace.directFactor.empty())numericalFactor=workspace.directFactor;else{numericalFactor=workspace.factor->Factor(diagonal);if(directAttempt){workspace.directSource=workspace.factor->source;workspace.directFactor=numericalFactor;}}inverseColumns.clear();const unsigned rank=bodyColumns.size();bodyFactor.assign(rank*rank,0);for(const auto& column:bodyColumns)inverseColumns.push_back(workspace.factor->Solve(column,numericalFactor));for(unsigned j=0;j<rank;++j)for(unsigned i=j;i<rank;++i){double v=i==j?1:0;for(unsigned k=0;k<n;++k)v+=bodyColumns[i][k]*inverseColumns[j][k];for(unsigned k=0;k<j;++k)v-=bodyFactor[k*rank+i]*bodyFactor[k*rank+j];if(i==j){if(!(v>0))throw SingularPressureCandidate("nonpositive body Schur pivot");bodyFactor[j*rank+i]=std::sqrt(v);}else bodyFactor[j*rank+i]=v/bodyFactor[j*rank+j];}}
 dl=workspace.factor->Solve(r,numericalFactor);const unsigned rank=bodyColumns.size();std::vector<double> correction(rank,0);for(unsigned j=0;j<rank;++j){for(unsigned k=0;k<n;++k)correction[j]+=bodyColumns[j][k]*dl[k];for(unsigned k=0;k<j;++k)correction[j]-=bodyFactor[k*rank+j]*correction[k];correction[j]/=bodyFactor[j*rank+j];}for(unsigned j=rank;j-->0;){for(unsigned k=j+1;k<rank;++k)correction[j]-=bodyFactor[j*rank+k]*correction[k];correction[j]/=bodyFactor[j*rank+j];}for(unsigned j=0;j<rank;++j)for(unsigned k=0;k<n;++k)dl[k]-=inverseColumns[j][k]*correction[j];factorMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-solveStart).count();dz=multiply(dl);for(unsigned i=0;i<n;++i)dz[i]+=residual[i];};
 auto step=[&](const std::vector<double>& x,const std::vector<double>& dx){double alpha=1;for(unsigned i=0;i<n;++i)if(!bilateral[i]&&dx[i]<0)alpha=std::min(alpha,-x[i]/dx[i]);return alpha;};
 bool solved=warmAccepted;unsigned attempted=0;
 // An equality candidate is cheap when all non-pulling contact bounds are
 // nonbinding. It is accepted ONLY after checking every multiplier and the
 // full physical KKT conditions. Separating or otherwise invalid candidates
 // fall back to the bounded inequality solve without touching velocities.
 if(!solved&&budget>0){directAttempt=true;std::vector<double> residual=rhs,comp(n,0),dl,dz;for(auto& v:residual)v=-v;++attempted;
  try{direction(residual,comp,dl,dz);bool feasible=true;for(unsigned i=0;i<n;++i)feasible&=std::isfinite(dl[i])&&(bilateral[i]||dl[i]>=0);if(feasible){auto product=multiply(dl);for(unsigned i=0;i<n;++i)product[i]=rhs[i]-product[i];const auto error=measure(dl,product);if(error.first<=tolerance&&error.second<=relativeWorkTolerance){lambda=std::move(dl);solved=true;++workspace.directHits;}}}catch(const SingularPressureCandidate&){/* A singular candidate is rejected, never regularized. */}
  if(!solved)++workspace.directRejected;
  directAttempt=false;numericalFactor.clear();
 }
 for(unsigned iteration=attempted;iteration<budget&&!solved;++iteration){numericalFactor.clear();auto product=multiply(lambda);std::vector<double> residual(n),comp(n,0),dl,dz;double mu=0;std::vector<double> physicalResidual(n);
  for(unsigned i=0;i<n;++i){physicalResidual[i]=rhs[i]-product[i];residual[i]=product[i]-rhs[i]-z[i];if(!bilateral[i]){comp[i]=lambda[i]*z[i];mu+=comp[i];}}const auto physical=measure(lambda,physicalResidual);if(physical.first<=tolerance&&physical.second<=relativeWorkTolerance){solved=true;break;}mu/=contacts;
  direction(residual,comp,dl,dz);double ap=step(lambda,dl),ad=step(z,dz),affine=0;for(unsigned i=0;i<n;++i)if(!bilateral[i])affine+=(lambda[i]+ap*dl[i])*(z[i]+ad*dz[i]);affine/=contacts;const double sigma=std::pow(affine/mu,3);
  for(unsigned i=0;i<n;++i)if(!bilateral[i])comp[i]+=dl[i]*dz[i]-sigma*mu;
  direction(residual,comp,dl,dz);ap=std::min(1.,.995*step(lambda,dl));ad=std::min(1.,.995*step(z,dz));for(unsigned i=0;i<n;++i){lambda[i]+=ap*dl[i];if(!bilateral[i])z[i]+=ad*dz[i];}++result.sweeps;
 }
 result.sweeps+=attempted;
 std::printf("SPARSE_TIMING symbolic_ms=%.6f factors_ms=%.6f rebuilt=%d\n",setupMs,factorMs,rebuilt);
 // Failure is transactional: original velocities remain untouched.
 if(!solved){result.maximumResidual=result.maximumRelativeWork=INFINITY;return result;}
 auto originalPoints=points;auto originalBodies=bodies;
 // Accumulate each physical impulse before applying its inverse mass once.
 // Repeated row-wise subtraction introduces a different rounding path from
 // the mass operator and needlessly perturbs calm states on subsequent solves.
 std::vector<glm::dvec3> pointImpulse(points.size(),glm::dvec3(0)),bodyImpulse(bodies.size(),glm::dvec3(0)),bodyTorque(bodies.size(),glm::dvec3(0));
 for(unsigned i=0;i<n;++i){const double p=lambda[i]*scale[i];result.pressureImpulse[i]=p;for(auto g:rows[i].points)pointImpulse[g.point]+=g.gradient*p;for(auto g:rows[i].bodies){bodyImpulse[g.body]+=g.linear*p;bodyTorque[g.body]+=g.angular*p;}}
 for(unsigned i=0;i<points.size();++i)points[i].velocity-=points[i].inverseMass*pointImpulse[i];
 for(unsigned i=0;i<bodies.size();++i){bodies[i].velocity-=bodies[i].inverseMass*bodyImpulse[i];bodies[i].angularVelocity-=bodies[i].inverseInertia*bodyTorque[i];}
 std::vector<double> physicalResidual(n);for(unsigned i=0;i<n;++i){double e=-rows[i].maximumRate;for(auto g:rows[i].points)e+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:rows[i].bodies)e+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);physicalResidual[i]=e*scale[i];}
 const auto final=measure(lambda,physicalResidual);result.maximumResidual=final.first;result.maximumRelativeWork=final.second;result.converged=final.first<=tolerance&&final.second<=relativeWorkTolerance;if(!result.converged){points=originalPoints;bodies=originalBodies;}else workspace.pressureImpulse=result.pressureImpulse;return result;
}
