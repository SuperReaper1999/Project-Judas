#pragma once
#include "WeakPolynomial.h"
// Bounded variational cut-pressure reference. Continuous P1 pressure lives on
// background tetrahedra; actual wet integration and owned solid traces define
// BOTH fluid and rigid gradients. Cell-average velocities are not a transport
// flux field and this module does not claim strong normal-trace reconstruction.
namespace cut_potential {
using V=glm::dvec3;using M=glm::dmat3;using Matrix=Eigen::MatrixXd;using Vector=Eigen::VectorXd;
struct Seed {std::array<V,4> points,gradients;std::array<unsigned,4> nodes;M inverse;};
inline Seed Background(unsigned seed){
 constexpr unsigned tetrahedra[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
 const unsigned voxel=seed/6,x=voxel%2,y=(voxel/2)%2,z=voxel/4;Seed out;
 for(unsigned i=0;i<4;++i){unsigned corner=tetrahedra[seed%6][i];out.points[i]=V(x+(corner&1),y+((corner>>1)&1),z+((corner>>2)&1));out.nodes[i]=unsigned(out.points[i].x)+3*unsigned(out.points[i].y)+9*unsigned(out.points[i].z);}
 out.inverse=glm::inverse(M(out.points[1]-out.points[0],out.points[2]-out.points[0],out.points[3]-out.points[0]));const M transpose=glm::transpose(out.inverse);out.gradients[0]=V(0);for(unsigned i=1;i<4;++i){out.gradients[i]=transpose[i-1];out.gradients[0]-=out.gradients[i];}return out;
}
inline std::array<double,4> Shape(const Seed& seed,V point){const V b=seed.inverse*(point-seed.points[0]);return {1-b.x-b.y-b.z,b.x,b.y,b.z};}
struct Cell {Seed background;unsigned component;double volume=0;V center{0},velocity{0};std::array<int,4> pressure;};
struct System {std::vector<Cell> cells;std::vector<unsigned> cutCell;std::vector<V> linear,angular;std::vector<std::pair<unsigned,unsigned>> identities;double quantity=0,buildMs=0;V bodyCenter;};
inline System Build(const owned_cut::Snapshot& geometry,bool closed=false){
 if(closed)throw std::invalid_argument("closed cut-pressure gauge is outside this bounded reference");
 const auto started=std::chrono::steady_clock::now();const auto& mesh=geometry.mesh;System sys;sys.bodyCenter=geometry.solidCenter;
 const unsigned count=mesh.tetrahedra.size();std::vector<unsigned> global(count),local(count);std::iota(global.begin(),global.end(),0);local=global;
 const auto find=[](const std::vector<unsigned>& roots,unsigned c){while(roots[c]!=c)c=roots[c];return c;};
 std::map<std::array<unsigned,3>,unsigned> faces;constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned c=0;c<count;++c)for(const auto& f:tri){const auto& t=mesh.tetrahedra[c];std::array<unsigned,3> key{t.vertices[f[0]],t.vertices[f[1]],t.vertices[f[2]]};std::sort(key.begin(),key.end());auto [at,inserted]=faces.emplace(key,c);if(!inserted){global[find(global,c)]=find(global,at->second);if(mesh.tetrahedra[c].seed==mesh.tetrahedra[at->second].seed)local[find(local,c)]=find(local,at->second);}}
 std::map<unsigned,unsigned> groups;std::vector<unsigned> cell(count);std::map<std::pair<unsigned,unsigned>,int> pressure;
 for(unsigned c=0;c<count;++c){auto [at,inserted]=groups.emplace(find(local,c),groups.size());cell[c]=at->second;if(inserted){Cell out;out.background=Background(mesh.tetrahedra[c].seed);out.component=find(global,c);out.pressure.fill(-1);sys.cells.push_back(out);}auto& target=sys.cells[cell[c]];
  const auto& t=mesh.tetrahedra[c];const auto& id=t.vertices;const auto m=owned_metrics::Tetra({mesh.vertices[id[0]].exact,mesh.vertices[id[1]].exact,mesh.vertices[id[2]].exact,mesh.vertices[id[3]].exact});target.volume+=m.volume;target.center+=m.volume*(t.geometry[0]+(m.edge[0]+m.edge[1]+m.edge[2])*.25);
 }
 sys.cutCell=cell;
 for(auto& c:sys.cells){c.center/=c.volume;sys.quantity+=c.volume;for(unsigned i=0;i<4;++i){if(!closed&&c.background.points[i].y==2)continue;auto [at,inserted]=pressure.emplace(std::make_pair(c.component,c.background.nodes[i]),int(pressure.size()));c.pressure[i]=at->second;}}
 if(pressure.size()>256)throw std::runtime_error("bounded cut pressure node count exceeded");
 sys.identities.resize(pressure.size());for(const auto& [key,id]:pressure)sys.identities[id]=key;
 sys.linear.assign(pressure.size(),V(0));sys.angular.assign(pressure.size(),V(0));
 for(const auto& f:geometry.boundaries)if(f.solidPlane>=0){const auto& c=sys.cells[cell[f.cell]];weak_pressure::IntegrateFace(mesh,f.vertices,[&](V point,double weight){const auto shape=Shape(c.background,point);for(unsigned i=0;i<4;++i)if(c.pressure[i]>=0){const unsigned id=c.pressure[i];sys.linear[id]-=weight*shape[i]*f.normal;sys.angular[id]-=weight*shape[i]*glm::cross(point-geometry.solidCenter,f.normal);}});}
 sys.buildMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count();return sys;
}
struct Result {bool accepted=false;std::string error;std::vector<V> velocity;Vector pressure;V bodyVelocity{0},bodyAngularVelocity{0},impulse{0},torque{0};double residual=0,energyBefore=0,energyAfter=0,workError=0,solveMs=0;};
inline Result Project(const System& sys,V bodyVelocity=V(0),V bodyAngularVelocity=V(0),double inverseMass=0,M inverseInertia=M(0)){
 Result result;try{const auto start=std::chrono::steady_clock::now();if(!std::isfinite(inverseMass)||inverseMass<0)throw std::invalid_argument("invalid cut rigid inverse mass");const unsigned n=sys.linear.size();Matrix matrix=Matrix::Zero(n,n);Vector rhs=Vector::Zero(n);
  for(const auto& c:sys.cells)for(unsigned i=0;i<4;++i)if(c.pressure[i]>=0){const unsigned row=c.pressure[i];rhs[row]+=c.volume*glm::dot(c.background.gradients[i],c.velocity);for(unsigned j=0;j<4;++j)if(c.pressure[j]>=0)matrix(row,c.pressure[j])+=c.volume/1000*glm::dot(c.background.gradients[i],c.background.gradients[j]);}
  for(unsigned i=0;i<n;++i){rhs[i]+=glm::dot(sys.linear[i],bodyVelocity)+glm::dot(sys.angular[i],bodyAngularVelocity);for(unsigned j=0;j<n;++j)matrix(i,j)+=inverseMass*glm::dot(sys.linear[i],sys.linear[j])+glm::dot(sys.angular[i],inverseInertia*sys.angular[j]);}
  Eigen::LLT<Matrix> factor(matrix);if(factor.info()!=Eigen::Success)throw std::runtime_error("cut pressure matrix is not positive definite (closed gauges require explicit elimination)");result.pressure=factor.solve(rhs);if(!result.pressure.allFinite())throw std::runtime_error("nonfinite cut pressure");
  result.residual=(matrix*result.pressure-rhs).lpNorm<Eigen::Infinity>();
  for(const auto& c:sys.cells){V gradient(0);for(unsigned i=0;i<4;++i)if(c.pressure[i]>=0)gradient+=c.background.gradients[i]*result.pressure[c.pressure[i]];result.velocity.push_back(c.velocity-gradient/1000.);result.energyBefore+=.5*1000*c.volume*glm::dot(c.velocity,c.velocity);result.energyAfter+=.5*1000*c.volume*glm::dot(result.velocity.back(),result.velocity.back());}
  for(unsigned i=0;i<n;++i){result.impulse-=sys.linear[i]*result.pressure[i];result.torque-=sys.angular[i]*result.pressure[i];}
  result.bodyVelocity=bodyVelocity+inverseMass*result.impulse;result.bodyAngularVelocity=bodyAngularVelocity+inverseInertia*result.torque;
  if(inverseMass>0){result.energyBefore+=.5*glm::dot(bodyVelocity,bodyVelocity)/inverseMass;result.energyAfter+=.5*glm::dot(result.bodyVelocity,result.bodyVelocity)/inverseMass;}
  if(glm::determinant(inverseInertia)>0){const M inertia=glm::inverse(inverseInertia);result.energyBefore+=.5*glm::dot(bodyAngularVelocity,inertia*bodyAngularVelocity);result.energyAfter+=.5*glm::dot(result.bodyAngularVelocity,inertia*result.bodyAngularVelocity);}
  result.workError=std::abs(result.energyBefore-result.energyAfter-.5*rhs.dot(result.pressure));result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  if(!std::isfinite(result.workError)||!std::isfinite(result.residual)||result.residual>1e-10||result.workError>1e-8||result.energyAfter>result.energyBefore+1e-9)throw std::runtime_error("cut pressure residual/work verification failed");
  result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;
}
}
