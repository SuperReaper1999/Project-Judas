#include "CoefficientPressure.h"
#include <cstdio>
int main(){unsigned checks=0;try{for(double angle:{0.,3.2137858346770188e-11}){
 auto q=glm::angleAxis(angle,glm::normalize(owned_cut::V(1,2,-.3)));auto geometry=owned_cut::Prepare(2,{1,1,1},{.5,.1,.5},q);auto sys=coefficient_pressure::Build(geometry);
 for(bool reverse:{false,true}){auto r=coefficient_pressure::Project(sys,{0,-9.81/240,0},reverse);
 std::printf("COEFFICIENT angle=%.17g reverse=%d cells=%zu constraints=%zu rank=%u accepted=%d residual=%g force=(%.17g %.17g %.17g) torque=%g speed=%g energy_before=%g energy_after=%g geometry_ms=%g solve_ms=%g error=%s\n",angle,reverse,sys.cells.size(),sys.rows.size(),r.rank,r.accepted,r.residual,r.bodyImpulse.x,r.bodyImpulse.y,r.bodyImpulse.z,glm::length(r.bodyTorque),r.maximumSpeed,r.energyBefore,r.energyAfter,sys.geometryMs,r.solveMs,r.error.c_str());std::fflush(stdout);
 if(!r.accepted)throw std::runtime_error("strong seed projection rejected");
 ++checks;
 if(glm::length(r.bodyImpulse-owned_cut::V(0,8.175,0))>1e-6||glm::length(r.bodyTorque)>1e-6||r.maximumSpeed>1e-8)throw std::runtime_error("independent strong force and calm contract");
 ++checks;
 }}std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
