from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path.cwd();here=Path(__file__).resolve().parent;out=here/'final';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':1,'parentRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'timestampUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'engineSha256':sha(root/'build/libjudas_engine.a'),'engineIdentity':json.loads((root/'build/judas-build-info-Release.json').read_text()),'scope':'Bounded variational pressure/native proofs, not a production fluid backend or transport qualification','cases':[]}
for name,expected,marker in [('CutPotentialTests',0,'SUMMARY checks=12 failures=0'),('CutDynamicsTests',0,'SUMMARY checks=20 failures=0'),('NativeCutPressureTests',0,'SUMMARY checks=96 failures=0'),('FluxBoundaryGap',1,'PRESERVED_FAILURE: cell averages cannot be published as impermeable material face fluxes'),('CutBenchmark',0,'iterations=100')]:
 log=out/(name+'.log')
 with log.open('w') as stream:
  run=subprocess.run(['python3',str(here/'run_probe.py'),name],stdout=stream,stderr=subprocess.STDOUT,cwd=root,timeout=90)
 binary=root/'.cache/fluid-contact-repair'/('stage8-'+name)
 item={'name':name,'exit':run.returncode,'expectedExit':expected,'marker':marker,'expectationMet':run.returncode==expected and marker in log.read_text(),'binarySha256':sha(binary) if binary.exists() else None,'sourceSha256':sha(here/(name+'.cpp')),'logSha256':sha(log)}
 report['cases'].append(item);(here/'FINAL_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(item,flush=True)
 if not item['expectationMet']:raise RuntimeError('unexpected '+name)
print('128 positive checks pass. Material face-flux failure remains explicit. NOT runtime fluid qualification.')
