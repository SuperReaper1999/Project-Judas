#include "CutPotential.h"
#include "PhysicsWorld.h"
#include "PhysicsConstraintBatch.h"
#include "../fluid-coupling-stage5-20261029/RigidEqualitySpace.h"
#include <cstdio>
using V=glm::dvec3;using M=glm::dmat3;
unsigned checks=0;void Check(bool b,const char* s){++checks;if(!b)throw std::runtime_error(s);}
void Run(bool fixed,double angle,bool omitted=false,double frameAngle=0){
 const auto frame=glm::angleAxis(frameAngle,glm::normalize(V(2,-1,3)));const V up=frame*V(0,1,0);const glm::vec3 center(frame*V(1));
 PhysicsWorld world;world.Init();const auto q=glm::quat(frame)*glm::angleAxis(float(angle),glm::normalize(glm::vec3(1,2,-.3)));
 const auto body=world.CreateShape(Shape::Box({.5f,.1f,.5f}),{center,q},true,80,0,0);
 if(fixed){JointSettings settings;settings.bodyA=body;settings.anchorB=center;settings.frameA=glm::inverse(q);Check(world.CreateJoint(settings).IsValid(),"real fixed guide created");}
 PhysicsConstraintParticipant participant;participant.bodies={body};unsigned published=0,snapshots=0;double force=0,maximumResidual=0,endpointError=0;V expectedV(0),expectedW(0);std::vector<V> staged,material;
 participant.propose=[&](const PhysicsConstraintBatch& batch,PhysicsConstraintProposal& proposal){
  // Explicit one-shot interaction for the unconstrained case. This does NOT
  // pretend to advance a moving liquid or fall back after a failed live solve.
  if(!fixed&&published)return false;
  ++snapshots;Check(batch.contacts.empty(),"no unmodelled native contact in coupling fixture");
  unsigned owner=unsigned(-1);std::vector<RigidBody> storage(batch.bodies.size());std::vector<Stage5Body> bodies;for(unsigned i=0;i<batch.bodies.size();++i){const auto& b=batch.bodies[i];storage[i].linearVelocity=b.linearVelocity;storage[i].angularVelocity=b.angularVelocity;storage[i].orientation=b.orientation;bodies.push_back({&storage[i],b.inverseMass,M(b.inverseInertia)});if(b.handle.id==body.id&&b.handle.world==body.world)owner=i;}
  Check(owner!=unsigned(-1),"native body identity retained");const auto& actual=batch.bodies[owner];
  auto cut=owned_cut::Prepare(2,glm::inverse(frame)*V(actual.center),{.5,.1,.5},glm::inverse(frame)*glm::dquat(actual.orientation));auto sys=cut_potential::Build(cut);for(auto& c:sys.cells){c.velocity=-up*(9.81*batch.context.deltaTime);for(auto& gradient:c.background.gradients)gradient=frame*gradient;}for(auto& v:sys.linear)v=frame*v;for(auto& v:sys.angular)v=frame*v;
  std::vector<float> values(batch.joints.size());std::vector<Stage5Joint> joints;for(unsigned i=0;i<batch.joints.size();++i){const auto& j=batch.joints[i];joints.push_back({j.a,j.b,V(j.linearA),V(j.linearB),V(j.angularA),V(j.angularB),j.bias,-INFINITY,INFINITY,&values[i]});}
  RigidEqualitySpace space(bodies,joints);const unsigned n=sys.linear.size();Eigen::MatrixXd matrix=Eigen::MatrixXd::Zero(n,n);Eigen::VectorXd rhs=Eigen::VectorXd::Zero(n);std::vector<std::vector<double>> raw,projected;
  for(unsigned i=0;i<n;++i){raw.push_back(space.Gradient(owner,sys.linear[i],sys.angular[i]));projected.push_back(space.Null(raw.back()));rhs[i]+=glm::dot(sys.linear[i],space.baseLinear[owner])+glm::dot(sys.angular[i],space.baseAngular[owner]);}
  for(const auto& c:sys.cells)for(unsigned i=0;i<4;++i)if(c.pressure[i]>=0){const unsigned r=c.pressure[i];rhs[r]+=c.volume*glm::dot(c.background.gradients[i],c.velocity);for(unsigned j=0;j<4;++j)if(c.pressure[j]>=0)matrix(r,c.pressure[j])+=c.volume/1000*glm::dot(c.background.gradients[i],c.background.gradients[j]);}
  for(unsigned i=0;i<n;++i)for(unsigned j=0;j<n;++j)matrix(i,j)+=RigidEqualitySpace::Dot(projected[i],projected[j]);
  Eigen::LLT<Eigen::MatrixXd> factor(matrix);Check(factor.info()==Eigen::Success,"native-reduced pressure matrix is positive definite");const Eigen::VectorXd pressure=factor.solve(rhs);maximumResidual=std::max(maximumResidual,(matrix*pressure-rhs).lpNorm<Eigen::Infinity>());Check(maximumResidual<1e-10,"native coupled pressure residual");
  V impulse(0),torque(0);std::vector<double> materialCoordinate(space.dimension,0);for(unsigned i=0;i<n;++i){impulse-=sys.linear[i]*pressure[i];torque-=sys.angular[i]*pressure[i];for(unsigned k=0;k<space.dimension;++k)materialCoordinate[k]-=raw[i][k]*pressure[i];}
  const auto response=space.Null(materialCoordinate);auto jointCoordinate=space.initial;for(unsigned k=0;k<space.dimension;++k)jointCoordinate[k]+=response[k]-materialCoordinate[k];const auto dual=space.JointImpulses(jointCoordinate,batch.joints.size());
  proposal.linearImpulses.assign(batch.bodies.size(),V(0));proposal.angularImpulses.assign(batch.bodies.size(),V(0));proposal.linearImpulses[owner]=impulse;proposal.angularImpulses[owner]=torque;proposal.contactImpulses.clear();proposal.jointImpulses.resize(dual.size());for(unsigned i=0;i<dual.size();++i)proposal.jointImpulses[i]=omitted?0:float(dual[i]);
  expectedV=space.baseLinear[owner]+space.Linear(owner,response);expectedW=space.baseAngular[owner]+space.Angular(owner,response);staged.clear();for(const auto& c:sys.cells){V gradient(0);for(unsigned i=0;i<4;++i)if(c.pressure[i]>=0)gradient+=c.background.gradients[i]*pressure[c.pressure[i]];staged.push_back(c.velocity-gradient/1000.);}
  if(fixed){const double expected=.2*1000*9.81*batch.context.deltaTime;Check(std::abs(glm::dot(impulse,up)-expected)<1e-6&&glm::length(impulse-up*glm::dot(impulse,up))<1e-6,"real native guide receives independently correct hydrostatic impulse");}
  force+=glm::dot(impulse,up);return true;
 };
 participant.published=[&](const auto&) noexcept{++published;material.swap(staged);};
 PhysicsWorld::VelocityCoupling coupling;coupling.physicalBatch=&participant;coupling.afterSubstep=[&](const auto& phase){if(fixed||phase.index==0){const double error=glm::length(V(world.GetLinearVelocity(body))-expectedV)+glm::length(V(world.GetAngularVelocity(body))-expectedW);endpointError=std::max(endpointError,error);Check(error<3e-7,"actual native endpoint matches simultaneous fluid/joint solve");}};
 bool rejected=false;try{world.Step(1.f/60,&coupling);}catch(const std::runtime_error& e){if(!omitted)throw;Check(std::string(e.what()).find("proposal violates a native joint constraint")!=std::string::npos,"negative control fails specifically at native joint validation");rejected=true;}
 if(omitted)Check(rejected&&published==0&&material.empty(),"omitted native reaction rejected before fluid publication");else{Check(published==(fixed?4u:1u),"only accepted native transactions publish material");Check(!material.empty(),"actual staged material state published");}
 std::printf("NATIVE_CUT fixed=%d angle=%g frame_angle=%g omitted=%d snapshots=%u published=%u residual=%g endpoint_error=%g total_y_impulse=%.17g rejected=%d\n",fixed,angle,frameAngle,omitted,snapshots,published,maximumResidual,endpointError,force,rejected);
}
int main(){try{Run(true,0);Run(true,.37);Run(false,.37);Run(true,0,true);Run(true,.37,false,1.13);std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
