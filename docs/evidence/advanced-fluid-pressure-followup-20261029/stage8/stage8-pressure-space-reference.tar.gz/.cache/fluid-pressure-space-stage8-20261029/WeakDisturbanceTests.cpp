#include "WeakPolynomial.h"
#include <cstdio>
int main(){unsigned checks=0;try{for(unsigned mode=0;mode<3;++mode){
 auto q=glm::angleAxis(.37,glm::normalize(owned_cut::V(1,2,-.3)));auto geometry=owned_cut::Prepare(2,{1,1,1},{.5,.1,.5},q);auto sys=weak_pressure::Build(geometry);
 for(auto& cell:sys.cells){if(mode==0){cell.predicted[0]=.2;cell.predicted[weak_pressure::P]=-.1;}if(mode==1){cell.predicted[1]=.3;cell.predicted[weak_pressure::P+2]=-.3;}if(mode==2){cell.predicted[5]=.4;cell.predicted[weak_pressure::P+8]=-.3;}}
 auto r=weak_pressure::Project(sys,{0,0,0});std::printf("DISTURBANCE mode=%u accepted=%d rank=%u residual=%g energy_before=%g energy_after=%g sampled_solid_normal_speed=%g speed=%g error=%s\n",mode,r.accepted,r.rank,r.residual,r.energyBefore,r.energyAfter,r.maximumSolidNormalSpeed,r.maximumSpeed,r.error.c_str());std::fflush(stdout);
 if(!r.accepted)throw std::runtime_error("weak disturbance projection failed");++checks;
 if(r.maximumSolidNormalSpeed>1e-8)throw std::runtime_error("averaged boundary admits local solid leakage");++checks;
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
