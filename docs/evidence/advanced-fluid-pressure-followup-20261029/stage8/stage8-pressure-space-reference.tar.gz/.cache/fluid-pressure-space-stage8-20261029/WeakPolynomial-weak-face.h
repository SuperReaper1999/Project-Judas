#pragma once
#include "OwnedCutGeometry.h"
#include <Eigen/Dense>
#include <map>
#include <set>
#include <numeric>
#include <chrono>
namespace weak_pressure {
using V=glm::dvec3;using Matrix=Eigen::MatrixXd;using Vector=Eigen::VectorXd;
constexpr unsigned P=10;
inline Eigen::Matrix<double,P,1> Basis(V p){Eigen::Matrix<double,P,1> v;v<<1,p.x,p.y,p.z,p.x*p.x,p.x*p.y,p.x*p.z,p.y*p.y,p.y*p.z,p.z*p.z;return v;}
inline Eigen::Matrix<double,P,1> Derivative(V p,unsigned a){Eigen::Matrix<double,P,1> v;v.setZero();v[1+a]=1;if(a==0){v[4]=2*p.x;v[5]=p.y;v[6]=p.z;}if(a==1){v[5]=p.x;v[7]=2*p.y;v[8]=p.z;}if(a==2){v[6]=p.x;v[8]=p.y;v[9]=2*p.z;}return v;}
struct Cell {V origin;Matrix mass=Matrix::Zero(P,P),root,inverseRoot;Vector predicted=Vector::Zero(3*P);std::vector<unsigned> tetrahedra;double volume=0;};
struct Constraint {Vector gradient;V bodyLinear{0},bodyAngular{0};double scale=1;};
struct BoundaryProbe {unsigned cell;V point,normal;};
struct System {std::vector<BoundaryProbe> solidProbes;std::vector<Cell> cells;std::vector<Constraint> rows;V bodyCenter;double geometryMs=0;};
constexpr double gauss4x[]={.0694318442029737124,.330009478207571868,.669990521792428132,.930568155797026288};
constexpr double gauss4w[]={.173927422568726929,.326072577431273071,.326072577431273071,.173927422568726929};
constexpr double gauss3x[]={.112701665379258311,.5,.887298334620741689};
constexpr double gauss3w[]={5./18,8./18,5./18};
template<class F>void IntegrateTet(const fluid_mesh::Compiler& mesh,const fluid_mesh::Tetrahedron& t,F function){
 const auto& ids=t.vertices;const auto m=owned_metrics::Tetra({mesh.vertices[ids[0]].exact,mesh.vertices[ids[1]].exact,mesh.vertices[ids[2]].exact,mesh.vertices[ids[3]].exact});
 const V origin=mesh.vertices[ids[0]].position;
 for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)for(unsigned k=0;k<4;++k){const double u=gauss4x[i],v=gauss4x[j],w=gauss4x[k];const V local(u,(1-u)*v,(1-u)*(1-v)*w);
  function(origin+m.edge*local,6*m.volume*gauss4w[i]*gauss4w[j]*gauss4w[k]*(1-u)*(1-u)*(1-v));}
}
template<class F>void IntegrateFace(const fluid_mesh::Compiler& mesh,std::array<unsigned,3> ids,F function){
 const auto& a=mesh.vertices[ids[0]];const auto metric=owned_metrics::Triangle({a.exact,mesh.vertices[ids[1]].exact,mesh.vertices[ids[2]].exact});
 const V x=owned_cut::Difference(mesh.vertices[ids[1]].exact,a.exact),y=owned_cut::Difference(mesh.vertices[ids[2]].exact,a.exact);
 for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j){const double u=gauss3x[i],v=gauss3x[j];function(a.position+u*x+(1-u)*v*y,2*metric.area*gauss3w[i]*gauss3w[j]*(1-u));}
}
inline System Build(const owned_cut::Snapshot& geometry){
 const auto start=std::chrono::steady_clock::now();System sys;sys.bodyCenter=geometry.solidCenter;
 const auto& mesh=geometry.mesh;const unsigned count=mesh.tetrahedra.size();
 struct Face{std::vector<unsigned> owners;std::array<unsigned,3> ids;};std::map<std::array<unsigned,3>,Face> faces;
 constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 for(unsigned c=0;c<count;++c)for(const auto& f:tri){const auto& t=mesh.tetrahedra[c];std::array<unsigned,3> ids{t.vertices[f[0]],t.vertices[f[1]],t.vertices[f[2]]};auto key=ids;std::sort(key.begin(),key.end());auto& face=faces[key];face.owners.push_back(c);face.ids=ids;}
 std::vector<unsigned> parent(count);std::iota(parent.begin(),parent.end(),0);const auto find=[&](unsigned a){while(parent[a]!=a)a=parent[a];return a;};
 for(const auto& [key,f]:faces)if(f.owners.size()==2){auto a=f.owners[0],b=f.owners[1];if(mesh.tetrahedra[a].voxel==mesh.tetrahedra[b].voxel)parent[find(a)]=find(b);}
 std::map<unsigned,unsigned> groups;std::vector<unsigned> cell(count);
 for(unsigned c=0;c<count;++c){auto [it,inserted]=groups.emplace(find(c),groups.size());if(inserted){Cell out;unsigned voxel=mesh.tetrahedra[c].voxel;out.origin=V(voxel%2+.5,(voxel/2)%2+.5,voxel/4+.5);sys.cells.push_back(std::move(out));}cell[c]=it->second;sys.cells[cell[c]].tetrahedra.push_back(c);}
 if(sys.cells.size()>32)throw std::runtime_error("bounded polynomial reference supports at most32 components");
 const unsigned dofs=3*P*sys.cells.size();
 for(unsigned c=0;c<sys.cells.size();++c){auto& out=sys.cells[c];
  for(auto t:out.tetrahedra)IntegrateTet(mesh,mesh.tetrahedra[t],[&](V p,double weight){const auto basis=Basis(p-out.origin);out.mass.noalias()+=1000*weight*basis*basis.transpose();out.volume+=weight;});
  Eigen::LLT<Matrix> factor(out.mass);if(factor.info()!=Eigen::Success)throw std::runtime_error("nonpositive physical polynomial mass");out.root=factor.matrixL();out.inverseRoot=out.root.triangularView<Eigen::Lower>().solve(Matrix::Identity(P,P));
  for(unsigned test=0;test<4;++test){Constraint row;row.gradient=Vector::Zero(dofs);
   for(auto t:out.tetrahedra)IntegrateTet(mesh,mesh.tetrahedra[t],[&](V p,double weight){p-=out.origin;const double phi=test?p[test-1]:1;for(unsigned a=0;a<3;++a)row.gradient.segment(c*3*P+a*P,P).noalias()+=weight*phi*Derivative(p,a);});
   row.scale=1/out.volume;sys.rows.push_back(std::move(row));
  }
 }
 using Canonical=std::array<owned_metrics::R,4>;using Key=std::tuple<unsigned,unsigned,Canonical>;
 struct Patch{unsigned a,b;int solid;V normal;std::vector<std::array<unsigned,3>> triangles;};std::map<Key,Patch> patches;
 for(const auto& [key,f]:faces){unsigned a=cell[f.owners[0]],b=f.owners.size()==2?cell[f.owners[1]]:unsigned(-1);if(a==b)continue;
  unsigned plane=unsigned(-1);for(unsigned p=0;p<mesh.planes.size();++p)if(mesh.Side(key[0],p)==0&&mesh.Side(key[1],p)==0&&mesh.Side(key[2],p)==0){plane=p;break;}if(plane==unsigned(-1))throw std::runtime_error("unowned physical patch");
  const auto& def=mesh.planes[plane];V normal(def.normal[0],def.normal[1],def.normal[2]);normal=glm::normalize(normal);
  for(auto v:mesh.tetrahedra[f.owners[0]].vertices)if(std::find(key.begin(),key.end(),v)==key.end()){if(mesh.Side(v,plane)>0)normal=-normal;break;}
  int solid=-1;bool inside=true;for(auto p:mesh.bodyPlanes)for(auto v:key)inside&=mesh.Side(v,p)<=0;
  if(inside)for(unsigned p=0;p<mesh.bodyPlanes.size();++p){bool on=true;for(auto v:key)on&=mesh.Side(v,mesh.bodyPlanes[p])==0;if(on){solid=int(p);const auto& n=mesh.planes[mesh.bodyPlanes[p]].normal;normal=-glm::normalize(V(n[0],n[1],n[2]));break;}}
  bool open=b==unsigned(-1)&&solid<0;for(auto v:key)open&=mesh.vertices[v].position.y==2.;if(open)continue;
  if(b!=unsigned(-1)&&b<a){std::swap(a,b);normal=-normal;}
  unsigned pivot=0;while(def.normal[pivot]==0)++pivot;Canonical canonical;for(unsigned k=0;k<3;++k)canonical[k]=owned_metrics::R(def.normal[k])/owned_metrics::R(def.normal[pivot]);canonical[3]=owned_metrics::R(def.coordinate)/owned_metrics::R(def.normal[pivot]);
  auto [it,inserted]=patches.emplace(Key{a,b,canonical},Patch{a,b,solid,normal,{}});it->second.triangles.push_back(key);
 }
 for(const auto& [key,patch]:patches){
  if(patch.solid>=0)for(auto t:patch.triangles)for(auto v:t)sys.solidProbes.push_back({patch.a,mesh.vertices[v].position,patch.normal});
  double area=0;V center(0);for(auto t:patch.triangles)IntegrateFace(mesh,t,[&](V p,double w){area+=w;center+=w*p;});center/=area;
  unsigned omitted=0;for(unsigned a=1;a<3;++a)if(std::abs(patch.normal[a])>std::abs(patch.normal[omitted]))omitted=a;const unsigned u=(omitted+1)%3,v=(omitted+2)%3;
  for(unsigned test=0;test<3;++test){Constraint row;row.gradient=Vector::Zero(dofs);row.scale=1/area;
   for(auto t:patch.triangles)IntegrateFace(mesh,t,[&](V p,double w){const double phi=test==0?1:p[test==1?u:v]-center[test==1?u:v];
    for(unsigned a=0;a<3;++a){row.gradient.segment(patch.a*3*P+a*P,P).noalias()+=w*phi*patch.normal[a]*Basis(p-sys.cells[patch.a].origin);if(patch.b!=unsigned(-1))row.gradient.segment(patch.b*3*P+a*P,P).noalias()-=w*phi*patch.normal[a]*Basis(p-sys.cells[patch.b].origin);}
    if(patch.solid>=0){row.bodyLinear-=w*phi*patch.normal;row.bodyAngular-=w*phi*glm::cross(p-sys.bodyCenter,patch.normal);}
   });sys.rows.push_back(std::move(row));
  }
 }
 sys.geometryMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return sys;
}
struct Result{bool accepted=false;std::string error;double residual=0,maximumSpeed=0,energyBefore=0,energyAfter=0,solveMs=0;double maximumSolidNormalSpeed=0;Vector physical;V bodyImpulse{0},bodyTorque{0};unsigned rank=0;};
inline Result Project(System& sys,V gravityStep,bool reverse=false){Result result;try{
 const auto start=std::chrono::steady_clock::now();const unsigned d=sys.cells.size()*3*P,n=sys.rows.size();Matrix transpose(d,n);Vector rhs(n),scale(n);
 for(unsigned j=0;j<n;++j){const auto& row=sys.rows[j];Vector gradient(d);double r=0;
  for(unsigned c=0;c<sys.cells.size();++c)for(unsigned a=0;a<3;++a){const auto& cell=sys.cells[c];const auto g=row.gradient.segment(c*3*P+a*P,P);gradient.segment(c*3*P+a*P,P)=cell.inverseRoot*g;r+=g.dot(cell.predicted.segment(a*P,P))+g[0]*gravityStep[a];}
  const double norm=gradient.norm();if(!(norm>0))throw std::runtime_error("empty weak physical row");scale[j]=1/norm;transpose.col(j)=gradient*scale[j];rhs[j]=r*scale[j];
 }
 if(reverse){transpose=transpose.rowwise().reverse().eval();rhs.reverseInPlace();scale.reverseInPlace();}
 Eigen::ColPivHouseholderQR<Matrix> qr(transpose);const unsigned rank=qr.rank();result.rank=rank;const Matrix R=qr.matrixR();const Vector permuted=qr.colsPermutation().transpose()*rhs;
 Vector y=Vector::Zero(d);y.head(rank)=R.topLeftCorner(rank,rank).transpose().triangularView<Eigen::Lower>().solve(permuted.head(rank));const Vector correction=qr.householderQ()*y;
 Vector dual=Vector::Zero(n);dual.head(rank)=R.topLeftCorner(rank,rank).triangularView<Eigen::Upper>().solve(y.head(rank));Vector impulse=qr.colsPermutation()*dual;if(reverse)impulse.reverseInPlace();
 Vector physical=Vector::Zero(d);
 for(unsigned c=0;c<sys.cells.size();++c)for(unsigned a=0;a<3;++a){const auto& cell=sys.cells[c];Vector predicted=cell.predicted.segment(a*P,P);predicted[0]+=gravityStep[a];const Vector q=cell.root.transpose()*predicted,after=q-correction.segment(c*3*P+a*P,P);physical.segment(c*3*P+a*P,P)=cell.inverseRoot.transpose()*after;result.energyBefore+=.5*q.squaredNorm();result.energyAfter+=.5*after.squaredNorm();}
 if(!physical.allFinite()||!impulse.allFinite())throw std::runtime_error("nonfinite weak projection");
 for(unsigned j=0;j<n;++j){const auto& row=sys.rows[j];result.residual=std::max(result.residual,std::abs(row.gradient.dot(physical)*row.scale));const double s=reverse?scale[n-1-j]:scale[j];result.bodyImpulse-=row.bodyLinear*(s*impulse[j]);result.bodyTorque-=row.bodyAngular*(s*impulse[j]);}
 for(unsigned c=0;c<sys.cells.size();++c){const auto& cell=sys.cells[c];for(auto t:cell.tetrahedra){(void)t;for(auto p:{V(-.5),V(.5),V(0)}){V velocity;for(unsigned a=0;a<3;++a)velocity[a]=Basis(p).dot(physical.segment(c*3*P+a*P,P));result.maximumSpeed=std::max(result.maximumSpeed,glm::length(velocity));}}}
 for(const auto& probe:sys.solidProbes){V velocity;for(unsigned a=0;a<3;++a)velocity[a]=Basis(probe.point-sys.cells[probe.cell].origin).dot(physical.segment(probe.cell*3*P+a*P,P));result.maximumSolidNormalSpeed=std::max(result.maximumSolidNormalSpeed,std::abs(glm::dot(velocity,probe.normal)));}
 result.physical=physical;
 result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();if(result.residual>1e-10)throw std::runtime_error("weak physical residual failed");if(result.energyAfter>result.energyBefore+1e-10)throw std::runtime_error("weak projection creates energy");result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;}
}
