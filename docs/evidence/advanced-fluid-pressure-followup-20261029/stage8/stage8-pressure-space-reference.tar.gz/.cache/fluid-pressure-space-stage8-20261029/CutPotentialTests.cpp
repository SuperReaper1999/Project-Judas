#include "CutPotential.h"
#include <cstdio>
int main(){unsigned checks=0;try{for(double angle:{0.,3.2137858346770188e-11,1e-8,.001,.37,1.13}){
 const auto q=glm::angleAxis(angle,glm::normalize(owned_cut::V(1,2,-.3)));auto geometry=owned_cut::Prepare(2,{1,1,1},{.5,.1,.5},q);auto sys=cut_potential::Build(geometry);for(auto& c:sys.cells)c.velocity={0,-9.81/240,0};auto r=cut_potential::Project(sys);double speed=0;for(auto v:r.velocity)speed=std::max(speed,glm::length(v));
 std::printf("CUT_POTENTIAL angle=%.17g cells=%zu pressure_nodes=%zu accepted=%d residual=%g force=(%.17g %.17g %.17g) torque=%g max_cell_speed=%g work_error=%g build_ms=%g solve_ms=%g error=%s\n",angle,sys.cells.size(),sys.linear.size(),r.accepted,r.residual,r.impulse.x,r.impulse.y,r.impulse.z,glm::length(r.torque),speed,r.workError,sys.buildMs,r.solveMs,r.error.c_str());std::fflush(stdout);
 if(!r.accepted)throw std::runtime_error("cut potential solve rejected");
 ++checks;
 if(glm::length(r.impulse-owned_cut::V(0,8.175,0))>1e-6||glm::length(r.torque)>1e-6||speed>1e-8)throw std::runtime_error("independent cut hydrostatic force/calm contract");
 ++checks;
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
