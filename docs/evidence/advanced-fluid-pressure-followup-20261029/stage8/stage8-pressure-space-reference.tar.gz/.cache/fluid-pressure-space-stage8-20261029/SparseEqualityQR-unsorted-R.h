#pragma once
#include "../fluid-pressure-space-stage8-kernel/EqualityProjectionQR.h"
#include <Eigen/SparseQR>
#include <chrono>
struct SparseEqualityResult:EqualityQrResult {unsigned rank=0;double assemblyMs=0,factorMs=0;};
inline SparseEqualityResult ProjectSparseEquality(Model& model,double tolerance=1e-10){
 using namespace fluid_equality;using Matrix=Eigen::SparseMatrix<double>;using Vector=Eigen::VectorXd;
 SparseEqualityResult result;
 try{
  const auto begin=std::chrono::steady_clock::now();
  const unsigned cells=model.cells.size(),fluidDofs=11*cells,d=fluidDofs+6*model.bodies.size();
  if(cells>2048||model.rows.size()>16384)throw std::runtime_error("bounded sparse reference exceeded");
  std::vector<LocalBasis> basis;std::vector<unsigned> pointOwner(model.points.size(),unsigned(-1));std::vector<double> coordinates(fluidDofs);
  for(unsigned c=0;c<cells;++c){const auto& cell=model.cells[c];LocalBasis local;local.first=cell.first;local.inverseMass=model.points.at(cell.first).inverseMass;if(!(local.inverseMass>0)||!std::isfinite(local.inverseMass))throw std::invalid_argument("invalid fluid mass");Nine trace{},affine{};
   for(unsigned k=0;k<4;++k){if(pointOwner.at(cell.first+k)!=unsigned(-1)||model.points[cell.first+k].inverseMass!=local.inverseMass)throw std::invalid_argument("inconsistent owned fluid degrees");pointOwner[cell.first+k]=c;}
   for(unsigned k=0;k<3;++k){const V g=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);for(unsigned a=0;a<3;++a){trace[3*k+a]=g[a];affine[3*k+a]=model.points[cell.first+1+k].velocity[a];coordinates[11*c+a]=model.points[cell.first].velocity[a];}}
   double norm=0;for(double v:trace)norm=std::hypot(norm,v);if(!(norm>0))throw std::runtime_error("empty fluid trace operator");const double diagonal=-std::copysign(norm,trace[0]),first=trace[0]-diagonal;local.tau=(diagonal-trace[0])/diagonal;local.reflector[0]=1;for(unsigned i=1;i<9;++i)local.reflector[i]=trace[i]/first;
   local.Transform(affine);for(unsigned i=1;i<9;++i)coordinates[11*c+2+i]=affine[i];basis.push_back(local);
  }
  std::vector<unsigned> rowIndex;const std::set<unsigned> traces(model.traceRows.begin(),model.traceRows.end());
  for(unsigned i=0;i<model.rows.size();++i)if(!traces.count(i)){if(!model.bilateral.at(i))throw std::invalid_argument("sparse equality reference requires bilateral rows");rowIndex.push_back(i);}
  const unsigned n=rowIndex.size();result.rows=n;result.dofs=d;result.pressureImpulse.assign(model.rows.size(),0);
  std::vector<M> inertiaRoots;for(const auto& body:model.bodies)inertiaRoots.push_back(InverseInertiaRoot(body.inverseInertia));
  std::vector<Eigen::Triplet<double>> triplets;Vector rhs(n);std::vector<double> rowScale(n);
  for(unsigned j=0;j<n;++j){const auto& row=model.rows[rowIndex[j]];std::map<unsigned,Nine> raw;std::map<unsigned,V> mean;std::map<unsigned,double> values;double r=-row.maximumRate;
   for(auto g:row.points){const unsigned c=pointOwner.at(g.point),offset=g.point-basis[c].first;if(offset==0){auto [at,inserted]=mean.emplace(c,V(0));at->second+=g.gradient;}else{auto [at,inserted]=raw.emplace(c,Nine{});for(unsigned a=0;a<3;++a)at->second[3*(offset-1)+a]+=g.gradient[a];}}
   for(const auto& [c,v]:mean){const double mass=std::sqrt(basis[c].inverseMass);for(unsigned a=0;a<3;++a){values[11*c+a]+=mass*v[a];r+=v[a]*coordinates[11*c+a];}}
   for(auto [c,v]:raw){basis[c].Transform(v);const double mass=std::sqrt(basis[c].inverseMass);for(unsigned i=1;i<9;++i){values[11*c+2+i]+=mass*v[i];r+=v[i]*coordinates[11*c+2+i];}}
   for(auto g:row.bodies){const auto& b=model.bodies[g.body];r+=glm::dot(g.linear,b.velocity)+glm::dot(g.angular,b.angularVelocity);for(unsigned a=0;a<3;++a){values[fluidDofs+6*g.body+a]+=std::sqrt(b.inverseMass)*g.linear[a];values[fluidDofs+6*g.body+3+a]+=glm::dot(inertiaRoots[g.body][a],g.angular);}}
   double norm=0;for(auto [i,v]:values)norm=std::hypot(norm,v);if(!(norm>0)||!std::isfinite(norm))throw std::runtime_error("empty physical equality row");rowScale[j]=1/norm;rhs[j]=r*rowScale[j];
   for(auto [i,v]:values)if(v!=0)triplets.emplace_back(i,j,v*rowScale[j]);
  }
  Matrix transpose(d,n);transpose.setFromTriplets(triplets.begin(),triplets.end());transpose.makeCompressed();
  const auto factorBegin=std::chrono::steady_clock::now();result.assemblyMs=std::chrono::duration<double,std::milli>(factorBegin-begin).count();
  Eigen::SparseQR<Matrix,Eigen::COLAMDOrdering<int>> qr;qr.compute(transpose);
  if(qr.info()!=Eigen::Success)throw std::runtime_error("sparse QR factorization failed");
  const unsigned rank=qr.rank();result.rank=rank;result.factorMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-factorBegin).count();
  const Matrix R=qr.matrixR();Vector permuted=qr.colsPermutation().transpose()*rhs,y=Vector::Zero(d);
  for(unsigned i=0;i<rank;++i){double value=permuted[i];for(unsigned j=0;j<i;++j)value-=R.coeff(j,i)*y[j];y[i]=value/R.coeff(i,i);}
  Vector correction=qr.matrixQ()*y,dual=Vector::Zero(n);
  for(unsigned i=rank;i-->0;){double value=y[i];for(unsigned j=i+1;j<rank;++j)value-=R.coeff(i,j)*dual[j];dual[i]=value/R.coeff(i,i);}
  const Vector unpermuted=qr.colsPermutation()*dual;
  for(unsigned i=0;i<n;++i)result.pressureImpulse[rowIndex[i]]=rowScale[i]*unpermuted[i];
  auto points=model.points;auto bodies=model.bodies;
  for(unsigned c=0;c<cells;++c){const auto& local=basis[c];const double weight=std::sqrt(local.inverseMass);for(unsigned a=0;a<3;++a)points[local.first].velocity[a]=coordinates[11*c+a]-weight*correction[11*c+a];Nine affine{};for(unsigned i=1;i<9;++i)affine[i]=coordinates[11*c+2+i]-weight*correction[11*c+2+i];local.Transform(affine);for(unsigned k=0;k<3;++k)for(unsigned a=0;a<3;++a)points[local.first+1+k].velocity[a]=affine[3*k+a];}
  for(unsigned b=0;b<bodies.size();++b){V linear,angular;for(unsigned a=0;a<3;++a){linear[a]=correction[fluidDofs+6*b+a];angular[a]=correction[fluidDofs+6*b+3+a];}bodies[b].velocity-=std::sqrt(bodies[b].inverseMass)*linear;bodies[b].angularVelocity-=inertiaRoots[b]*angular;}
  for(unsigned i:rowIndex){const auto& row=model.rows[i];double residual=-row.maximumRate;for(auto g:row.points)residual+=glm::dot(g.gradient,points[g.point].velocity);for(auto g:row.bodies)residual+=glm::dot(g.linear,bodies[g.body].velocity)+glm::dot(g.angular,bodies[g.body].angularVelocity);result.residual=std::max(result.residual,std::abs(residual));}
  for(const auto& cell:model.cells){double trace=0,norm=0;for(unsigned k=0;k<3;++k){V g=model.frame*V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k]);trace+=glm::dot(g,points[cell.first+1+k].velocity);norm+=glm::dot(g,g);}result.divergence=std::max(result.divergence,std::abs(trace)/std::sqrt(norm));}
  if(!std::isfinite(result.residual)||result.residual>tolerance||result.divergence>tolerance)throw std::runtime_error("sparse QR physical residual verification failed");
  model.points=std::move(points);model.bodies=std::move(bodies);result.accepted=true;
 }catch(const std::exception& error){result.error=error.what();}return result;
}
