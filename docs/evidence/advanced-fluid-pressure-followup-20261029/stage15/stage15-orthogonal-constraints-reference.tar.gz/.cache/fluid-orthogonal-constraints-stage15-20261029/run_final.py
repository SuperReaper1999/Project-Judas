from pathlib import Path
import subprocess,json,time
folder=Path('.cache/fluid-orthogonal-constraints-stage15-20261029');output=folder/'final';output.mkdir(exist_ok=False);records=[]
for name in ['PressureTests','ThinTests','CacheTests']:
 command=['python3',str(folder/'run_probe.py'),name];start=time.monotonic()
 with (output/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'returnCode':r.returncode,'seconds':time.monotonic()-start};records.append(row);(output/'RUNS.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
