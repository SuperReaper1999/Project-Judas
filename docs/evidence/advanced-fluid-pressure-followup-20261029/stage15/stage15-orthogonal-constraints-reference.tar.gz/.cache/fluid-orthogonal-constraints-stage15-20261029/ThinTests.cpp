#include "PressureEpoch.h"
#include "../fluid-refined-reconstruction-stage12-20261029/CoarseOracle.h"
#include <cstdio>
using namespace localized_pressure;unsigned checks=0;void Check(bool x,const char* s){++checks;if(!x)throw std::runtime_error(s);}
int main(){std::setvbuf(stdout,nullptr,_IOLBF,0);try{for(double angle:{0.,3.2137858346770188e-11,.17}){Epoch epoch(1,owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))));
 for(unsigned trial=0;trial<3;++trial){auto velocity=[&](V p){if(trial==2)return V(0);return double(trial+1)*V(.03*std::sin(5*p.y),-.04+.01*std::cos(3*p.z),.02*std::sin(4*p.x));};Eigen::Matrix<Real,6,1> body=Eigen::Matrix<Real,6,1>::Zero();if(trial==1)body<<.02,-.03,.01,.01,-.02,.03;const auto result=epoch.Solve(velocity,body);auto coarse=epoch.coarse;coarse.predictor=result.coarseSource;VerifyCoarse(coarse,body,result.coarse);Check(true,"independent coarse saddle system matches");double maximum=0;
  for(unsigned m=0;m<epoch.factors.size();++m){const auto& f=*epoch.factors[m];Vector q(epoch.columns[m].size());for(unsigned c=0;c<q.size();++c)q[c]=result.coarse.flux[epoch.columns[m][c]];Frozen frozen;frozen.local=m;frozen.matrix=f.J;frozen.rhs=f.sampler->Sample(velocity)-f.Y*q-f.Ybody*body;const auto gold=Solve<160>(frozen);
   for(unsigned c=0;c<f.free.size();++c){const auto index=f.inside[f.free[c]];const Number<160> error=abs(Number<160>(f.raw.columnScale[index])*(Number<160>(result.localScaled[m][index])-gold[c]));maximum=std::max(maximum,error.convert_to<double>());}
   for(unsigned c=0;c<f.pivots.size();++c){Number<160> dependent=0;for(unsigned j=0;j<gold.size();++j)dependent-=Number<160>(f.Cfree(c,j))*gold[j];for(unsigned j=0;j<q.size();++j)dependent-=Number<160>(f.Ctrace(c,j))*Number<160>(q[j]);for(unsigned j=0;j<6;++j)dependent-=Number<160>(f.Cbody(c,j))*Number<160>(body[j]);const auto index=f.inside[f.pivots[c]];const Number<160> error=abs(Number<160>(f.raw.columnScale[index])*(Number<160>(result.localScaled[m][index])-dependent));maximum=std::max(maximum,error.convert_to<double>());}
   Check(maximum<1e-12,"localized physical free/dependent flux differs from high precision oracle");
  }
  Check(result.balance<1e-10&&result.reactionError<1e-8,"localized full continuity/work check");if(trial==2)Check(result.fullEnergy==0&&result.fullReaction.norm()==0,"zero source leaves stale flow");
  std::printf("ACCURACY angle=%.17g trial=%u max_physical_flux_error=%g balance=%g reaction_error=%g solve_ms=%g\n",angle,trial,maximum,result.balance,result.reactionError,result.solveMs);
 }
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
