#pragma once
#include "PressureEpoch.h"
#include "../fluid-localized-pressure-stage14-20261029/ReferenceFrame.h"
namespace localized_pressure {
struct Monolithic {System system;std::vector<unsigned> offsets;};
template<class Velocity>Monolithic AssembleMonolithic(const Epoch& epoch,Velocity velocity){
 Monolithic out;auto& sys=out.system;unsigned nr=0,np=0,nc=epoch.coarse.variables;
 for(const auto& f:epoch.factors){out.offsets.push_back(nc);nr+=f->raw.fluid.rows();np+=f->raw.divergence.rows();nc+=f->inside.size();}
 sys.variables=nc;sys.fluid.resize(nr,nc);sys.body=Dense::Zero(nr,6);sys.divergence=Dense::Zero(np,nc);sys.bodyDivergence=Dense::Zero(np,6);sys.predictor=Vector::Zero(nr);sys.columnScale=Vector::Ones(nc);std::vector<Eigen::Triplet<Real>> entries;unsigned r0=0,p0=0;
 for(unsigned m=0;m<epoch.factors.size();++m){const auto& f=*epoch.factors[m];const auto& cols=epoch.columns[m];const Dense boundary=f.raw.fluid*f.trace,Dtrace=f.raw.divergence*f.trace;
  for(unsigned c=0;c<cols.size();++c){for(int r=0;r<boundary.rows();++r)if(boundary(r,c)!=0)entries.emplace_back(r0+r,cols[c],boundary(r,c));for(int r=0;r<Dtrace.rows();++r)sys.divergence(p0+r,cols[c])=Dtrace(r,c);}
  for(unsigned c=0;c<f.inside.size();++c){for(Sparse::InnerIterator it(f.raw.fluid,f.inside[c]);it;++it)entries.emplace_back(r0+it.row(),out.offsets[m]+c,it.value());sys.divergence.block(p0,out.offsets[m]+c,f.raw.divergence.rows(),1)=f.raw.divergence.col(f.inside[c]);}
  sys.body.middleRows(r0,f.raw.body.rows())=f.raw.body;sys.bodyDivergence.middleRows(p0,f.raw.bodyDivergence.rows())=f.raw.bodyDivergence;sys.predictor.segment(r0,f.raw.predictor.size())=f.sampler->Sample(velocity);r0+=f.raw.body.rows();p0+=f.raw.divergence.rows();
 }
 sys.fluid.setFromTriplets(entries.begin(),entries.end());sys.fluid.makeCompressed();for(int j=0;j<sys.fluid.outerSize();++j){Real norm=0;for(Sparse::InnerIterator it(sys.fluid,j);it;++it)norm=std::hypot(norm,it.value());if(norm==0)throw std::runtime_error("empty monolithic kinetic column");sys.columnScale[j]=1/norm;for(Sparse::InnerIterator it(sys.fluid,j);it;++it)it.valueRef()*=sys.columnScale[j];sys.divergence.col(j)*=sys.columnScale[j];}return out;
}

}
