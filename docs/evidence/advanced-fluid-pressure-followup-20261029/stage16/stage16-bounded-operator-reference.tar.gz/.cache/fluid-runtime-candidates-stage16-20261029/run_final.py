from pathlib import Path
import subprocess,json,time,hashlib,sys
root=Path('.cache/fluid-runtime-candidates-stage16-20261029')
out=root/'final'
out.mkdir(exist_ok=False)
cases=[
 ('Local','vem/VemLocalTests.cpp'),('Condensed','vem/CondensedCellTests.cpp'),
 ('Boundary','geometry/BoundaryCompilerTests.cpp'),('BoundaryTouch','runtime/BoundaryTouchTests.cpp'),('Factored','geometry/FactoredFaceMetricsTests.cpp'),
 ('Epoch','runtime/EpochTests.cpp'),('Basis','runtime/BasisComparisonTests.cpp'),
 ('Independent','runtime/IndependentEpochTests.cpp'),('Moving','runtime/MovingTests.cpp'),
 ('Native',None),
]
rows=[]
for name,src in cases:
 cmd=[sys.executable,str(root/('run_probe.py' if src else 'run_native.py'))]
 if src:cmd.append(src)
 log=out/(name+'.log');start=time.monotonic()
 with log.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,p.returncode,round(rows[-1]['elapsedSeconds'],2),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
