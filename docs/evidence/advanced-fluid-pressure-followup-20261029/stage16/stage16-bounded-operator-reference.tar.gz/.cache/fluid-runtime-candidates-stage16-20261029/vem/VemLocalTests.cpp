#include "VemLocal.h"
#include "../acceptance/PolynomialOracles.h"
#include <algorithm>
#include <cstdio>
#include <random>

using namespace JudasFluidVem;

// Exactly integrates degree<=3 Cartesian monomials over an affine image of
// [-1,1]^3. This test-only Gauss collector is independent of Build's Green
// identities and polynomial matrices; production clipping is owned elsewhere.
struct BoxFixture {
    CellGeometry geometry;
    Mat3 edges;
    Vec3 center;
    std::vector<std::vector<Vec3>> faceCorners;
};

Real Monomial(const Vec3& p, unsigned index) {
    Real value=1;
    for (unsigned a=0; a<3; ++a)
        for (unsigned j=0; j<Powers[index][a]; ++j) value*=p(a);
    return value;
}

BoxFixture Box(const Mat3& edges, const Vec3& center) {
    BoxFixture fixture;
    fixture.edges=edges;
    fixture.center=center;
    auto& g=fixture.geometry;
    const Real gauss=1/std::sqrt(3.0L);
    const Real jacobian=std::abs(edges.determinant());
    for (Real x:{-gauss,gauss}) for (Real y:{-gauss,gauss}) for (Real z:{-gauss,gauss}) {
        const Vec3 r=center+edges*Vec3(x,y,z);
        for (unsigned m=0; m<20; ++m) g.volume[m]+=jacobian*Monomial(r,m);
    }
    for (unsigned fixed=0; fixed<3; ++fixed) for (Real sign:{-1.0L,1.0L}) {
        const unsigned u=(fixed+1)%3,v=(fixed+2)%3;
        const Vec3 faceCenter=center+sign*edges.col(fixed);
        const Vec3 eu=edges.col(u),ev=edges.col(v);
        const Vec3 areaVector=eu.cross(ev);
        const Real faceJacobian=areaVector.norm();
        FaceGeometry f;
        f.normal=areaVector.normalized()*sign;
        if (edges.determinant()<0) f.normal=-f.normal;
        const Eigen::Matrix<Real,3,2> tangent=(Eigen::Matrix<Real,3,2>() << eu,ev).finished();
        const Eigen::Matrix<Real,2,3> dual=(tangent.transpose()*tangent).inverse()*tangent.transpose();
        f.basis(0,0)=1;
        for (unsigned a=0; a<2; ++a) {
            f.basis(a+1,0)=-dual.row(a).dot(faceCenter);
            f.basis.block(a+1,1,1,3)=dual.row(a);
        }
        for (Real s:{-gauss,gauss}) for (Real t:{-gauss,gauss}) {
            const Vec3 r=faceCenter+eu*s+ev*t;
            const Vec3 psi(1,s,t);
            for (unsigned m=0; m<20; ++m) f.area[m]+=faceJacobian*Monomial(r,m);
            for (unsigned i=0; i<3; ++i) {
                for (unsigned j=0; j<3; ++j) f.gram(i,j)+=faceJacobian*psi(i)*psi(j);
                for (unsigned m=0; m<10; ++m) f.mixed(i,m)+=faceJacobian*psi(i)*Monomial(r,m);
            }
        }
        std::vector<Vec3> corners;
        for (const auto st:{std::array<Real,2>{-1,-1},{1,-1},{1,1},{-1,1}})
            corners.push_back(faceCenter+eu*st[0]+ev*st[1]);
        fixture.faceCorners.push_back(corners);
        g.faces.push_back(f);
    }
    return fixture;
}

fluid_acceptance::Vec Plain(const Vec3& a) { return {a.x(),a.y(),a.z()}; }
fluid_acceptance::Moments Plain(const Moments& m) {
    fluid_acceptance::Moments a;
    a.measure=m[0];
    for (unsigned i=0; i<3; ++i) {
        a.first[i]=m[i+1];
        for (unsigned j=0; j<3; ++j) a.second[i][j]=m[ProductIndex(i+1,j+1)];
    }
    return a;
}
fluid_acceptance::AffineVelocity Plain(const Affine& a) {
    fluid_acceptance::AffineVelocity v;
    for (unsigned i=0; i<3; ++i) {
        v.value[i]=a(4*i);
        for (unsigned j=0; j<3; ++j) v.gradient[i][j]=a(4*i+j+1);
    }
    return v;
}

int main() {
    unsigned checks=0,failures=0;
    auto check=[&](bool pass,const char* what) {
        ++checks;
        if (!pass) { ++failures; std::printf("FAIL %s\n",what); }
    };
    std::mt19937_64 rng(0x8df17a);
    std::uniform_real_distribution<Real> random(-1,1);
    const Real angle=.417L;
    const Mat3 rotation=Eigen::AngleAxis<Real>(angle,Vec3(1,2,-.4L).normalized()).toRotationMatrix();
    Real maxProjection=0,maxMass=0,maxTrace=0,maxDiv=0,maxConjugacy=0;
    for (unsigned specimen=0; specimen<5; ++specimen) {
        Mat3 edges=Mat3::Zero();
        if (specimen==0) edges.diagonal()<<.5L,.5L,.5L;
        if (specimen==1) edges=rotation*(Vec3(.3L,.7L,.5L).asDiagonal());
        if (specimen==2) {
            edges<<.31L,.12L,.02L, .04L,.62L,-.07L, -.03L,.16L,.47L;
        }
        if (specimen==3) edges=rotation*Vec3(2e-3L,3e-3L,4e-3L).asDiagonal();
        if (specimen==4) edges=rotation*Vec3(20,30,40).asDiagonal();
        const Vec3 center=specimen==2?Vec3(.03L,-.01L,.07L):Vec3::Zero();
        auto fixture=Box(edges,center);
        const auto op=Build(fixture.geometry);
        maxProjection=std::max(maxProjection,op.polynomialReproductionError);
        maxDiv=std::max(maxDiv,op.divergenceReproductionError);
        check(op.polynomialReproductionError<1e-11L,"affine polynomial projection reproduction");
        check(op.divergenceReproductionError<1e-11L,"affine divergence reproduction");
        Eigen::LLT<Matrix> massFactor(op.mass);
        check(massFactor.info()==Eigen::Success,"strictly positive local kinetic metric");
        const auto analyticMoments=Plain(fixture.geometry.volume);
        for (unsigned trial=0; trial<10; ++trial) {
            Affine a,b;
            for (unsigned j=0; j<12; ++j) { a(j)=random(rng);b(j)=random(rng); }
            const auto da=op.InterpolateAffineDOFs(a),db=op.InterpolateAffineDOFs(b);
            const Real exact=fluid_acceptance::KineticInnerProduct(analyticMoments,Plain(a),Plain(b),fixture.geometry.density);
            const Real computed=da.dot(op.mass*db);
            const Real relative=std::abs(computed-exact)/std::max(1.0L,std::abs(exact));
            maxMass=std::max(maxMass,relative);
            check(relative<1e-11L,"affine kinetic inner product versus independent analytic moments");
            const Affine pa=op.Project(da);
            check((pa-a).norm()<1e-10L,"arbitrary affine field reproduced");
            for (unsigned f=0; f<fixture.geometry.faces.size(); ++f) {
                const auto& face=fixture.geometry.faces[f];
                for (const Vec3& r:fixture.faceCorners[f]) {
                    const Real normal=op.EvaluateFaceNormal(f,da,r);
                    const Real expected=face.normal.dot(EvaluateAffine(a,r));
                    const Real error=std::abs(normal-expected);
                    maxTrace=std::max(maxTrace,error);
                    check(error<1e-10L,"primary face trace matches affine normal at face corners");
                }
            }
            // Exact consistency must hold against *any* virtual test DOFs,
            // not only against a second polynomial. This detects a false mass
            // model that reproduces energy but applies the wrong body work.
            Vector q(op.dimension);
            for (Eigen::Index j=0;j<q.size();++j) q(j)=random(rng);
            const Vector lhs=op.mass*da;
            const Vector rhs=fixture.geometry.density*op.projection.transpose()*op.polynomialGram*a;
            const Real conjugacy=(lhs-rhs).norm()/std::max(1.0L,rhs.norm());
            maxConjugacy=std::max(maxConjugacy,conjugacy);
            check(conjugacy<1e-11L,"affine-to-virtual mass work conjugacy");
            check(q.dot(op.mass*q)>0,"random virtual kinetic energy positive");
        }
        const Affine rigid=RigidAffine(Vec3(.2L,-.3L,.1L),Vec3(.7L,.4L,-.8L));
        const auto dofs=op.InterpolateAffineDOFs(rigid);
        check(op.Divergence(dofs).norm()<1e-10L,"rigid rotation divergence zero");
        for (unsigned f=0; f<fixture.geometry.faces.size(); ++f)
            for (const Vec3& r:fixture.faceCorners[f])
                check(std::abs(op.EvaluateFaceNormal(f,dofs,r)-fixture.geometry.faces[f].normal.dot(EvaluateAffine(rigid,r)))<1e-10L,
                      "rigid rotation no hidden solid-normal leakage");
        // Primary normal flux remains authoritative for non-affine VEM DOFs.
        // The projection generally has a different trace, so replacing q with
        // the projected velocity would intentionally fail this negative check.
        Vector virtualDofs=Vector::Zero(op.dimension);
        virtualDofs(1)=fixture.geometry.faces[0].area[0];
        const Affine projected=op.Project(virtualDofs);
        Real gap=0;
        for (const Vec3& r:fixture.faceCorners[0])
            gap=std::max(gap,std::abs(op.EvaluateFaceNormal(0,virtualDofs,r)-fixture.geometry.faces[0].normal.dot(EvaluateAffine(projected,r))));
        check(gap>1e-4L,"negative control catches projected boundary flux overwrite");
        auto reversed=fixture.geometry;
        reversed.faces[0].normal=-reversed.faces[0].normal;
        const auto bad=Build(reversed);
        check(bad.polynomialReproductionError>1e-3L || bad.divergenceReproductionError>1e-3L,
              "negative control catches reversed outward normal");
        std::printf("VEM_LOCAL specimen=%u dofs=%u volume=%.12Lg projection=%.5Lg div=%.5Lg\n",specimen,op.dimension,fixture.geometry.volume[0],op.polynomialReproductionError,op.divergenceReproductionError);
    }
    std::printf("VEM_LOCAL_SUMMARY checks=%u failures=%u projection=%.8Lg mass_relative=%.8Lg trace=%.8Lg divergence=%.8Lg work=%.8Lg\n",
                checks,failures,maxProjection,maxMass,maxTrace,maxDiv,maxConjugacy);
    return failures?1:0;
}
