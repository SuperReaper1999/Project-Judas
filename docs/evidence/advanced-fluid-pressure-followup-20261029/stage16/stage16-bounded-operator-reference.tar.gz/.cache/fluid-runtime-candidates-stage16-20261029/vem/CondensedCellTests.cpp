// Reuse the independent affine-box integration fixture without running its
// test entry point. Neither KKT validation nor finite differences below reuse
// the local angular elimination formula.
#define main VemLocalFixtureMain
#include "VemLocalTests.cpp"
#undef main
#include "CondensedCell.h"

int main() {
    unsigned checks=0,failures=0;
    auto check=[&](bool pass,const char* what) {
        ++checks;
        if (!pass) { ++failures;std::printf("FAIL %s\n",what); }
    };
    std::mt19937_64 rng(0x18135f);
    std::uniform_real_distribution<Real> random(-1,1);
    const Mat3 rotation=Eigen::AngleAxis<Real>(.731L,Vec3(-.3L,1,.7L).normalized()).toRotationMatrix();
    Real maximumKkt=0,maximumObjective=0,maximumGradient=0,maximumDivergence=0;
    for (unsigned specimen=0; specimen<3; ++specimen) {
        const Mat3 edges=rotation*Vec3(.3L,.7L,.5L).asDiagonal()*(specimen==2?.01L:1.0L);
        const Vec3 center=specimen==1?Vec3(.03L,-.01L,.07L):Vec3::Zero();
        const auto fixture=Box(edges,center);
        const auto local=Build(fixture.geometry);
        const CondensedCell cell(local);
        check((cell.Tface.topRows(cell.faceDimension)-Matrix::Identity(cell.faceDimension,cell.faceDimension)).norm()==0,
              "condensation preserves all primary face DOFs");
        Eigen::LLT<Matrix> factor(cell.faceMass);
        check(factor.info()==Eigen::Success,"condensed face metric positive definite");
        for (unsigned trial=0; trial<8; ++trial) {
            Affine predictor;
            for (unsigned j=0;j<12;++j) predictor(j)=random(rng);
            const Vector rawPredictor=local.InterpolateAffineDOFs(predictor);
            const auto source=cell.SourceFromPredictor(rawPredictor);
            Vector face(cell.faceDimension);
            for (Eigen::Index j=0;j<face.size();++j) face(j)=random(rng)*fixture.geometry.volume[0];
            // A single independent face adjusts total cell flux. No DOF is
            // dropped, and the same closure is enforced in the full KKT solve.
            face(0)-=(cell.closure*face)(0)/cell.closure(0);
            const Vector raw=cell.Reconstruct(face,source);
            const Real div=local.Divergence(raw).norm();
            maximumDivergence=std::max(maximumDivergence,div);
            check(div<1e-10L,"reconstructed field has full P1 zero divergence");
            check((cell.Tangular.transpose()*(cell.rawMass*raw-source.rawLoad)).norm()<1e-10L,
                  "eliminated angular momentum is stationary");
            const Real full=cell.FullObjective(raw,source),reduced=cell.ReducedObjective(face,source);
            const Real energyError=std::abs(full-reduced)/std::max(1.0L,std::abs(full));
            maximumObjective=std::max(maximumObjective,energyError);
            check(energyError<1e-12L,"exact eliminated source energy constant retained");

            // Independent constrained minimizer in ALL raw unknowns: fixed
            // face moments plus the three linear weak-divergence equations.
            const unsigned n=cell.rawDimension,m=cell.faceDimension+3;
            Matrix constraints=Matrix::Zero(m,n);
            constraints.topLeftCorner(cell.faceDimension,cell.faceDimension).setIdentity();
            constraints.bottomRows(3)=local.divergenceMoments.bottomRows(3);
            Vector wanted=Vector::Zero(m);
            wanted.head(cell.faceDimension)=face;
            Vector variableScale(n);
            for (unsigned j=0;j<n;++j) variableScale(j)=1/std::sqrt(cell.rawMass(j,j));
            constraints=constraints*variableScale.asDiagonal();
            for (unsigned j=0;j<m;++j) {
                const Real rowNorm=constraints.row(j).norm();
                constraints.row(j)/=rowNorm;
                wanted(j)/=rowNorm;
            }
            Matrix saddle=Matrix::Zero(n+m,n+m);
            saddle.topLeftCorner(n,n)=variableScale.asDiagonal()*cell.rawMass*variableScale.asDiagonal();
            saddle.topRightCorner(n,m)=constraints.transpose();
            saddle.bottomLeftCorner(m,n)=constraints;
            Vector rhs=Vector::Zero(n+m);
            rhs.head(n)=variableScale.asDiagonal()*source.rawLoad;
            rhs.tail(m)=wanted;
            const Vector independent=saddle.fullPivLu().solve(rhs);
            const Real kkt=(variableScale.asDiagonal()*independent.head(n)-raw).norm()/std::max(1.0L,raw.norm());
            maximumKkt=std::max(maximumKkt,kkt);
            check(kkt<1e-10L,"angular condensation matches independent full constrained KKT solve");
            const Vector gradient=cell.Gradient(face,source);
            const Vector originalGradient=cell.ReconstructionDerivative().transpose()*(cell.rawMass*raw-source.rawLoad);
            const Real gradientError=(gradient-originalGradient).norm()/std::max(1.0L,gradient.norm());
            maximumGradient=std::max(maximumGradient,gradientError);
            check(gradientError<1e-11L,"condensed derivative equals full physical work derivative");
            Matrix B=Matrix::Zero(cell.faceDimension,6);
            for (Eigen::Index i=0;i<B.rows();++i)
                for (unsigned j=0;j<6;++j) B(i,j)=random(rng);
            const Vector pullback=cell.PullbackGradient(B,face,source);
            const Vector originalPullback=B.transpose()*originalGradient;
            check((pullback-originalPullback).norm()/std::max(1.0L,pullback.norm())<1e-11L,
                  "generic rigid-face parameter pullback preserves force torque work");
            // Removing the constant must be detectable for a generic source;
            // positive retained energy is not silently treated as a zero.
            if (trial==0) check(std::abs(source.constant)>1e-14L,
                                "negative control omitted source energy constant is nontrivial");
        }
    }
    std::printf("VEM_CONDENSED_SUMMARY checks=%u failures=%u kkt=%.8Lg objective=%.8Lg gradient=%.8Lg divergence=%.8Lg\n",
                checks,failures,maximumKkt,maximumObjective,maximumGradient,maximumDivergence);
    return failures?1:0;
}
