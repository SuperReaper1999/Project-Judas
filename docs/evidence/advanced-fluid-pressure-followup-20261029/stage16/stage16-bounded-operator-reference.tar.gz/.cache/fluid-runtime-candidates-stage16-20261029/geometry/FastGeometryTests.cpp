#include "FastPolyhedralMoments.h"
#include "BoundaryCompiler.h"
#include "../acceptance/VemPatchAcceptance.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>

namespace vg=stage16_geometry;
namespace va=fluid_acceptance;
using Real=JudasFluidVem::Real;
unsigned checks=0;
Real maxMomentError=0,maxMixedError=0,maxPhysicalError=0;

void Check(bool value,const char* text) {
    ++checks;
    if(!value) throw std::runtime_error(text);
}
void Scaled(Real actual,Real expected,Real scale,Real tolerance,
            Real& maximum,const char* text) {
    ++checks;
    scale=std::max(std::abs(scale),std::abs(expected));
    const Real error=scale>0?std::abs(actual-expected)/scale:
                           (actual==expected?0:std::numeric_limits<Real>::infinity());
    maximum=std::max(maximum,error);
    if(!std::isfinite(error) || error>tolerance) {
        std::printf("COMPARE_FAIL %s actual=%Lg expected=%Lg scale=%Lg error=%Lg\n",
                    text,actual,expected,scale,error);
        throw std::runtime_error(text);
    }
}

va::Vec Point(const vg::RV& x) {
    return {x[0].convert_to<Real>(),x[1].convert_to<Real>(),x[2].convert_to<Real>()};
}

void Compare(const motion_mesh::Compiler& mesh,const vg::Cell& exact,const vg::Cell& fast) {
    Check(exact.center==fast.center,"exact physical centroid changed");
    Check(exact.faces.size()==fast.faces.size(),"face ownership count changed");
    Check(exact.fineTets==fast.fineTets,"integration topology changed");
    if(exact.fineTets==0) return;
    va::Vec bound;
    for(const auto& face:fast.faces)
        for(const auto& triangle:face.triangles)
            for(const auto& point:triangle.points)
                for(unsigned a=0;a<3;++a)
                    bound[a]=std::max(bound[a],std::abs(point[a].convert_to<Real>()));
    for(unsigned m=0;m<20;++m) {
        Real scale=exact.geometry.volume[0];
        for(unsigned a=0;a<3;++a)
            for(unsigned n=0;n<JudasFluidVem::Powers[m][a];++n) scale*=bound[a];
        Scaled(fast.geometry.volume[m],exact.geometry.volume[m],scale,1e-11L,
               maxMomentError,"fast volume P3");
    }
    std::vector<va::FacePatch> patches;
    for(unsigned f=0;f<fast.faces.size();++f) {
        const auto& a=exact.faces[f];
        const auto& b=fast.faces[f];
        Check(a.solid==b.solid && a.background==b.background,"exact face identity changed");
        Check(a.pivot==b.pivot && a.u==b.u && a.v==b.v,"face coordinate pivot changed");
        Check(a.measure==b.measure && a.meanU==b.meanU && a.meanV==b.meanV,
              "exact face measure/centroid changed");
        Check(a.varU==b.varU && a.cov==b.cov && a.varV==b.varV,
              "exact face covariance changed");
        for(unsigned m=0;m<10;++m) Check(a.projected[m]==b.projected[m],"exact face P2 changed");
        for(unsigned m=10;m<20;++m) Check(b.projected[m]==0,"fast collector invents exact P3");
        va::FacePatch patch;
        va::Vec faceBound;
        for(const auto& triangle:b.triangles) {
            std::array<va::Vec,3> p;
            for(unsigned j=0;j<3;++j) {
                p[j]=Point(triangle.points[j]);
                for(unsigned axis=0;axis<3;++axis)
                    faceBound[axis]=std::max(faceBound[axis],std::abs(p[j][axis]));
            }
            patch.push_back(va::MakeTriangle(p));
        }
        patches.push_back(std::move(patch));
        for(unsigned m=0;m<20;++m) {
            Real scale=exact.geometry.faces[f].area[0];
            for(unsigned axis=0;axis<3;++axis)
                for(unsigned n=0;n<JudasFluidVem::Powers[m][axis];++n) scale*=faceBound[axis];
            Scaled(fast.geometry.faces[f].area[m],exact.geometry.faces[f].area[m],
                   scale,1e-11L,maxMomentError,"fast face P3");
            if(m<10)
                for(unsigned row=0;row<3;++row)
                    Scaled(fast.geometry.faces[f].mixed(row,m),exact.geometry.faces[f].mixed(row,m),
                           16*scale,1e-11L,maxMixedError,"fast mixed face P3");
        }
    }
    va::Moments reference;
    for(const auto& tet:mesh.tetrahedra) {
        std::array<va::Vec,4> p;
        for(unsigned j=0;j<4;++j)
            p[j]=Point(vg::Sub(owned_metrics::Position(mesh.vertices[tet.vertices[j]].exact),fast.center));
        reference.Add(va::TetraMoments(p));
    }
    const auto op=JudasFluidVem::Build(fast.geometry);
    const auto report=va::CheckPolynomialPatches(op,reference,patches,1e-8L);
    checks+=report.checks;
    maxPhysicalError=std::max(maxPhysicalError,report.worstError);
    if(report.failures) {
        std::printf("PATCH_FAIL failed=%u error=%Lg check=%s\n",report.failures,
                    report.worstError,report.worstCheck.c_str());
        const auto referenceOperator=JudasFluidVem::Build(exact.geometry);
        const auto referenceReport=va::CheckPolynomialPatches(referenceOperator,reference,patches,1e-8L);
        std::printf("EXACT_REFERENCE_PATCH failed=%u error=%Lg check=%s\n",
                    referenceReport.failures,referenceReport.worstError,
                    referenceReport.worstCheck.c_str());
        for(unsigned category=0;category<static_cast<unsigned>(va::CheckGroup::Count);++category)
            std::printf("PATCH_CATEGORY category=%u fast=%Lg exact=%Lg\n",category,
                        report.maxScaledError[category],referenceReport.maxScaledError[category]);
        throw std::runtime_error("fast collector independent physical polynomial patch");
    }
}

// Corrected-input oracle alongside, not in place of, the unchanged rounded
// triangle oracle above. Exact topology/area and small exact centered basis
// factors are converted BEFORE arithmetic can lose a thin face's dimensions.
// This never consumes the candidate's supplied face Gram or mixed moments.
void FactoredTraceChecks(const vg::Cell& cell) {
    if(!cell.fineTets) return;
    const auto op=JudasFluidVem::Build(cell.geometry);
    for(unsigned mode=0;mode<13;++mode) {
        JudasFluidVem::Vector dofs(op.dimension);
        va::AffineVelocity field;
        if(mode<12) {
            field=va::PolynomialBasis(mode);
            JudasFluidVem::Affine coefficient=JudasFluidVem::Affine::Zero();
            coefficient[mode]=1;
            dofs=op.InterpolateAffineDOFs(coefficient);
        } else {
            for(unsigned d=0;d<op.dimension;++d) dofs[d]=(int(d%13)-6)*.031L;
        }
        for(unsigned faceIndex=0;faceIndex<cell.faces.size();++faceIndex) {
            const auto& face=cell.faces[faceIndex];
            const Real su=std::sqrt(face.varU.convert_to<Real>());
            const vg::R exactK=face.cov/face.varU;
            const Real sv=std::sqrt((face.varV-face.cov*exactK).convert_to<Real>());
            const auto normalCoefficient=op.FaceNormalCoefficients(faceIndex,dofs);
            std::array<stage16_fast_geometry::Sum,3> integrated,expected;
            std::array<Real,3> scales{};
            for(const auto& triangle:face.triangles) {
                std::array<std::array<Real,3>,3> psi{};
                std::array<Real,3> normalSpeed{},analyticSpeed{};
                JudasFluidVem::Vec3 ratio;
                for(unsigned axis=0;axis<3;++axis)
                    ratio[axis]=(triangle.areaVector[axis]/abs(triangle.areaVector[face.pivot]))
                                        .convert_to<Real>();
                const Real metric=ratio.norm();
                const auto normal=(ratio/metric).eval();
                const Real area=abs(triangle.areaVector[face.pivot]).convert_to<Real>()*metric;
                Real maxSpeed=0;
                for(unsigned vertex=0;vertex<3;++vertex) {
                    const auto& p=triangle.points[vertex];
                    const vg::R du=p[face.u]-face.meanU;
                    const vg::R dv=p[face.v]-face.meanV;
                    psi[0][vertex]=1;
                    psi[1][vertex]=du.convert_to<Real>()/su;
                    psi[2][vertex]=(dv-exactK*du).convert_to<Real>()/sv;
                    for(unsigned row=0;row<3;++row)
                        normalSpeed[vertex]+=psi[row][vertex]*normalCoefficient[row];
                    const auto value=field.At(Point(p));
                    analyticSpeed[vertex]=normal[0]*value.x+normal[1]*value.y+normal[2]*value.z;
                    maxSpeed=std::max(maxSpeed,std::abs(normalSpeed[vertex]));
                }
                for(unsigned row=0;row<3;++row) {
                    std::array<std::array<Real,3>,3> factors{};
                    factors[0]=psi[row];
                    factors[1]=normalSpeed;
                    integrated[row].Add(area*stage16_fast_geometry::ProductAverage<3>(factors,2));
                    factors[1]=analyticSpeed;
                    expected[row].Add(area*stage16_fast_geometry::ProductAverage<3>(factors,2));
                    Real maxPsi=0;
                    for(Real value:psi[row]) maxPsi=std::max(maxPsi,std::abs(value));
                    scales[row]+=area*maxPsi*std::max(Real(1),maxSpeed);
                }
            }
            for(unsigned row=0;row<3;++row) {
                Scaled(integrated[row].Get(),dofs[3*faceIndex+row],scales[row],1e-8L,
                       maxPhysicalError,"factored primary flux actual P1 trace");
                if(mode<12)
                    Scaled(dofs[3*faceIndex+row],expected[row].Get(),scales[row],1e-8L,
                           maxPhysicalError,"factored affine P1 normal flux");
            }
        }
    }
}

unsigned Choose(unsigned n,unsigned k) {
    if(k>n) return 0;
    unsigned result=1;
    for(unsigned i=1;i<=k;++i) result=result*(n+1-i)/i;
    return result;
}

vg::R TranslatedExact(const vg::ExactMoments& moments,unsigned m,const vg::RV& delta) {
    const auto& p=JudasFluidVem::Powers[m];
    vg::R value=0;
    for(unsigned x=0;x<=p[0];++x)
        for(unsigned y=0;y<=p[1];++y)
            for(unsigned z=0;z<=p[2];++z) {
                const unsigned index=JudasFluidVem::MomentIndex(x,y,z);
                value+=moments[index]*Choose(p[0],x)*Choose(p[1],y)*Choose(p[2],z)
                     *vg::Power(delta[0],p[0]-x)*vg::Power(delta[1],p[1]-y)*vg::Power(delta[2],p[2]-z);
            }
    return value;
}

Real TranslatedRounded(const JudasFluidVem::Moments& moments,unsigned m,const vg::RV& exactDelta) {
    const auto& p=JudasFluidVem::Powers[m];
    const auto delta=Point(exactDelta);
    Real value=0;
    for(unsigned x=0;x<=p[0];++x)
        for(unsigned y=0;y<=p[1];++y)
            for(unsigned z=0;z<=p[2];++z) {
                const unsigned index=JudasFluidVem::MomentIndex(x,y,z);
                value+=moments[index]*Choose(p[0],x)*Choose(p[1],y)*Choose(p[2],z)
                     *std::pow(delta.x,int(p[0]-x))*std::pow(delta.y,int(p[1]-y))*std::pow(delta.z,int(p[2]-z));
            }
    return value;
}

void CompareDirect(const vg::Cell& exact,const vg::Cell& fast) {
    Check(exact.faces.size()==fast.faces.size(),"direct boundary face count differs");
    if(!fast.fineTets) return;
    const auto delta=vg::Sub(exact.center,fast.center);
    va::Vec bound;
    for(const auto& face:fast.faces)
        for(const auto& triangle:face.triangles)
            for(const auto& p:triangle.points)
                for(unsigned axis=0;axis<3;++axis)
                    bound[axis]=std::max(bound[axis],std::abs(p[axis].convert_to<Real>()));
    for(unsigned m=0;m<20;++m) {
        Real scale=exact.geometry.volume[0];
        for(unsigned axis=0;axis<3;++axis)
            for(unsigned power=0;power<JudasFluidVem::Powers[m][axis];++power) scale*=bound[axis];
        Scaled(fast.geometry.volume[m],TranslatedRounded(exact.geometry.volume,m,delta),
               scale,1e-10L,maxMomentError,"direct volume P3 in declared frame");
    }
    for(const auto& face:fast.faces) {
        auto found=std::find_if(exact.faces.begin(),exact.faces.end(),[&](const auto& candidate) {
            return face.solid>=0?candidate.solid==face.solid:
                   candidate.solid<0 && candidate.background==face.background;
        });
        Check(found!=exact.faces.end(),"direct face ownership absent in reference");
        Check(face.pivot==found->pivot && face.u==found->u && face.v==found->v,
              "direct face physical projection changed");
        Check(face.measure==found->measure && face.varU==found->varU &&
              face.cov==found->cov && face.varV==found->varV,"direct exact face measure/covariance");
        Check(face.meanU+fast.center[face.u]==found->meanU+exact.center[face.u] &&
              face.meanV+fast.center[face.v]==found->meanV+exact.center[face.v],
              "direct exact physical face centroid");
        for(unsigned m=0;m<10;++m)
            Check(face.projected[m]==TranslatedExact(found->projected,m,delta),
                  "direct exact face P2 differs after frame translation");
    }
    FactoredTraceChecks(fast);
}

void DirectBench(unsigned selected) {
    using V=glm::dvec3;
    double totalReference=0,totalDirect=0,totalMetric=0;
    for(unsigned fixture=0;fixture<5;++fixture) {
        if(selected!=99 && selected!=fixture) continue;
        const auto rotation=fixture==2?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):
            fixture==4?glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3))):
                       glm::dquat(1,0,0,0);
        const auto planes=owned_cut::BoxPlanes(fixture==0?V(3):V(.5),
            fixture==3?V(.499999999,.2,.17):V(.2),rotation);
        double referenceMs=0,directMs=0,metricMs=0;
        for(unsigned seed=0;seed<6;++seed) {
            motion_mesh::Compiler mesh;
            mesh.BuildSelected(1,planes,{seed});
            auto begin=std::chrono::steady_clock::now();
            const auto reference=vg::Collect(mesh);
            referenceMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
            begin=std::chrono::steady_clock::now();
            stage16_boundary::Compiler direct;
            direct.Build(1,seed,planes);
            directMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
            begin=std::chrono::steady_clock::now();
            const auto fast=vg::FastCollectPrepared(direct);
            metricMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
            CompareDirect(reference,fast);
        }
        totalReference+=referenceMs;
        totalDirect+=directMs;
        totalMetric+=metricMs;
        std::printf("DIRECT_GEOMETRY fixture=%u exact_ms=%g direct_topology_ms=%g fast_metrics_ms=%g\n",
                    fixture,referenceMs,directMs,metricMs);
    }
    std::printf("DIRECT_SUMMARY checks=%u failures=0 exact_ms=%g direct_topology_ms=%g "
                "fast_metrics_ms=%g max_scaled_moment_error=%Lg max_scaled_factored_flux_error=%Lg\n",
                checks,totalReference,totalDirect,totalMetric,maxMomentError,maxPhysicalError);
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        if(argc>1 && std::string(argv[1])=="direct") {
            DirectBench(argc>2?unsigned(std::strtoul(argv[2],nullptr,10)):99);
            return 0;
        }
        using V=glm::dvec3;
        const unsigned selected=argc>1?unsigned(std::strtoul(argv[1],nullptr,10)):99;
        double exactTotal=0,fastTotal=0,meshTotal=0;
        unsigned totalTets=0,totalFaces=0;
        for(unsigned fixture=0;fixture<5;++fixture) {
            if(selected!=99 && selected!=fixture) continue;
            const auto rotation=fixture==2?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):
                fixture==4?glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3))):
                           glm::dquat(1,0,0,0);
            const auto planes=owned_cut::BoxPlanes(fixture==0?V(3):V(.5),
                fixture==3?V(.499999999,.2,.17):V(.2),rotation);
            double exactMs=0,fastMs=0,meshMs=0;
            Real volume=0;
            for(unsigned seed=0;seed<6;++seed) {
                auto begin=std::chrono::steady_clock::now();
                motion_mesh::Compiler mesh;
                mesh.BuildSelected(1,planes,{seed});
                meshMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                begin=std::chrono::steady_clock::now();
                const auto exact=vg::Collect(mesh);
                exactMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                begin=std::chrono::steady_clock::now();
                const auto fast=vg::FastCollect(mesh);
                fastMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                Compare(mesh,exact,fast);
                volume+=fast.geometry.volume[0];
                totalTets+=fast.fineTets;
                totalFaces+=fast.faces.size();
            }
            Real expected=1;
            if(fixture>0) expected-=8*(fixture==3?.499999999L:.2L)*.2L*(fixture==3?.17L:.2L);
            Check(std::abs(volume-expected)<1e-14L,"fast aggregate cut volume");
            exactTotal+=exactMs;
            fastTotal+=fastMs;
            meshTotal+=meshMs;
            std::printf("FAST_GEOMETRY fixture=%u mesh_ms=%g exact_ms=%g fast_ms=%g ratio=%g volume=%Lg\n",
                        fixture,meshMs,exactMs,fastMs,exactMs/fastMs,volume);
        }
        std::printf("SUMMARY checks=%u failures=0 tets=%u faces=%u exact_ms=%g fast_ms=%g mesh_ms=%g "
                    "max_scaled_moment_error=%Lg max_scaled_mixed_error=%Lg max_scaled_physical_error=%Lg\n",
                    checks,totalTets,totalFaces,exactTotal,fastTotal,meshTotal,
                    maxMomentError,maxMixedError,maxPhysicalError);
        return 0;
    } catch(const std::exception& e) {
        std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());
        return 1;
    }
}
