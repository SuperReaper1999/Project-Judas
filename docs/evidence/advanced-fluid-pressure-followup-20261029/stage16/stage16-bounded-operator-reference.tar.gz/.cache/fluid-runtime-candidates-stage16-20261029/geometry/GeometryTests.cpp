#include "PolyhedralMoments.h"
#include "../acceptance/VemPatchAcceptance.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <chrono>
#include <cstdio>
using namespace stage16_geometry;
unsigned checks=0;
void Check(bool b,const char* text){++checks;if(!b)throw std::runtime_error(text);}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
    using V=glm::dvec3;unsigned totalFaces=0,totalTets=0;long double maxErr=0;
    for(unsigned fixture=0;fixture<4;++fixture){
        auto planes=owned_cut::BoxPlanes(fixture==0?V(3):V(.5),fixture==3?V(0.499999999,0.2,0.17):V(.2),fixture==2?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):glm::dquat(1,0,0,0));
        long double volume=0;const auto begin=std::chrono::steady_clock::now();
        for(unsigned seed=0;seed<6;++seed){motion_mesh::Compiler mesh;mesh.BuildSelected(1,planes,{seed});auto cell=Collect(mesh);if(cell.fineTets==0)continue;
            const auto op=vem::Build(cell.geometry);volume+=cell.geometry.volume[0];totalFaces+=cell.faces.size();totalTets+=cell.fineTets;
            fluid_acceptance::Moments reference;for(const auto& t:mesh.tetrahedra){std::array<fluid_acceptance::Vec,4> p;for(unsigned j=0;j<4;++j){const auto r=Sub(owned_metrics::Position(mesh.vertices[t.vertices[j]].exact),cell.center);p[j]={r[0].convert_to<long double>(),r[1].convert_to<long double>(),r[2].convert_to<long double>()};}reference.Add(fluid_acceptance::TetraMoments(p));}
            std::vector<fluid_acceptance::FacePatch> patches;for(const auto& face:cell.faces){fluid_acceptance::FacePatch patch;for(const auto& tri:face.triangles){std::array<fluid_acceptance::Vec,3> p;for(unsigned j=0;j<3;++j)p[j]={tri.points[j][0].convert_to<long double>(),tri.points[j][1].convert_to<long double>(),tri.points[j][2].convert_to<long double>()};patch.push_back(fluid_acceptance::MakeTriangle(p));}patches.push_back(std::move(patch));}
            const auto report=fluid_acceptance::CheckPolynomialPatches(op,reference,patches,1e-8L);checks+=report.checks;maxErr=std::max(maxErr,report.worstError);if(report.failures){printf("PATCH_FAIL fixture=%u seed=%u failed=%u error=%Lg check=%s\n",fixture,seed,report.failures,report.worstError,report.worstCheck.c_str());throw std::runtime_error("independent actual geometry patch test");}
            printf("CELL fixture=%u seed=%u tets=%u faces=%zu dofs=%u projection=%Lg divergence=%Lg physical_error=%Lg\n",fixture,seed,cell.fineTets,cell.faces.size(),op.dimension,op.polynomialReproductionError,op.divergenceReproductionError,report.worstError);
        }
        long double expected=1;if(fixture>0){const long double hx=fixture==3?0.499999999L:.2L;expected-=8*hx*.2L*(fixture==3?.17L:.2L);}Check(std::abs(volume-expected)<1e-14L,"aggregate cut volume differs");
        printf("GEOMETRY fixture=%u ms=%g volume=%Lg\n",fixture,std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count(),volume);
    }
    printf("SUMMARY checks=%u failures=0 fine_tets=%u faces=%u max_scaled_physical_error=%Lg\n",checks,totalTets,totalFaces,maxErr);return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
