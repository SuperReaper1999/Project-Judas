#include "BoundaryCompiler.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using namespace stage16_boundary;

struct Reference {
    R volume=0;
    unsigned components=0;
};

Reference ExactReference(unsigned grid,unsigned seed,const Box& box) {
    motion_mesh::Compiler mesh;
    mesh.BuildSelected(grid,box,{seed});
    Reference result;
    std::vector<unsigned> parent(mesh.tetrahedra.size());
    std::iota(parent.begin(),parent.end(),0);
    const auto root=[&](unsigned id) { while(parent[id]!=id) id=parent[id];return id; };
    std::map<std::array<unsigned,3>,unsigned> owner;
    constexpr unsigned faceIds[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
    for(unsigned t=0;t<mesh.tetrahedra.size();++t) {
        const auto& tetrahedron=mesh.tetrahedra[t];
        std::array<RV,4> p;
        for(unsigned j=0;j<4;++j) p[j]=owned_metrics::Position(mesh.vertices[tetrahedron.vertices[j]].exact);
        const R measure=owned_metrics::Dot(Sub(p[1],p[0]),owned_metrics::Cross(Sub(p[2],p[0]),Sub(p[3],p[0])))/6;
        if(measure<=0) throw std::runtime_error("reference cut tet lost positive volume");
        result.volume+=measure;
        for(const auto& f:faceIds) {
            std::array<unsigned,3> key={tetrahedron.vertices[f[0]],tetrahedron.vertices[f[1]],tetrahedron.vertices[f[2]]};
            std::sort(key.begin(),key.end());
            const auto [at,inserted]=owner.emplace(key,t);
            if(!inserted) parent[root(t)]=root(at->second);
        }
    }
    std::set<unsigned> components;
    for(unsigned t=0;t<parent.size();++t) components.insert(root(t));
    result.components=components.size();
    return result;
}

int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    unsigned checks=0,failures=0;
    auto check=[&](bool pass,const char* text) {
        ++checks;
        if(!pass) { ++failures;std::printf("FAIL %s\n",text); }
    };
    using V=glm::dvec3;
    std::vector<Box> boxes;
    boxes.push_back(owned_cut::BoxPlanes(V(.5),V(.2),glm::dquat(1,0,0,0)));
    boxes.push_back(owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(.17,glm::normalize(V(1,2,-.3)))));
    boxes.push_back(owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(1e-10,glm::normalize(V(1,2,-.3)))));
    boxes.push_back(owned_cut::BoxPlanes(V(1.125,.5,.5),V(.25,.375,.375),glm::dquat(1,0,0,0)));
    boxes.push_back(owned_cut::BoxPlanes(V(1.25,.5,.5),V(.25,.25,.25),glm::dquat(1,0,0,0))); // exact tangent
    boxes.push_back(owned_cut::BoxPlanes(V(.5),V(.0625,2,2),glm::dquat(1,0,0,0))); // separates wet volumes
    boxes.push_back(owned_cut::BoxPlanes(V(.5),V(2),glm::dquat(1,0,0,0))); // completely displaced
    for(unsigned fixture=0;fixture<boxes.size();++fixture) {
        unsigned componentMax=0,triangles=0,simplices=0;
        for(unsigned seed=0;seed<6;++seed) {
            const auto reference=ExactReference(1,seed,boxes[fixture]);
            Compiler direct;
            direct.rejectDisconnected=false; // inspect topology, never assemble a merged VEM cell
            try { direct.Build(1,seed,boxes[fixture]); }
            catch(const std::exception& e) {
                ++failures;std::printf("ERROR fixture=%u seed=%u %s\n",fixture,seed,e.what());continue;
            }
            check(direct.volume==reference.volume,"direct boundary-only volume equals exact original arrangement");
            check(direct.components==reference.components,"positive-area inherited-cap connectivity equals independent tet connectivity");
            check(direct.mesh.tetrahedra.empty(),"direct compiler never emits a fine tetrahedral mesh");
            check(direct.outside.size()<=6,"sequential subtraction respects bounded piece count");
            check(!direct.centerIsCentroid,"non-centroid local reference is declared explicitly");
            componentMax=std::max(componentMax,direct.components);
            triangles+=direct.boundary.size();simplices+=direct.integration.size();
            RV totalArea{};
            R boundaryVolume=0;
            for(const auto& triangle:direct.boundary) {
                for(unsigned a=0;a<3;++a) totalArea[a]+=triangle.areaVector[a];
                boundaryVolume+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
                const auto& plane=direct.mesh.planes[triangle.plane];
                RV n={R(plane.normal[0]),R(plane.normal[1]),R(plane.normal[2])};
                const auto solid=std::find(direct.mesh.bodyPlanes.begin(),direct.mesh.bodyPlanes.end(),triangle.plane);
                if(solid!=direct.mesh.bodyPlanes.end())
                    check(owned_metrics::Dot(triangle.areaVector,n)<0,"body boundary normal points outward from fluid into solid");
                else {
                    bool found=false;
                    for(const auto& face:direct.seed.faces) if(face.plane==triangle.plane) {
                        const RV a=direct.Position(face.vertices[0]),b=direct.Position(face.vertices[1]),c=direct.Position(face.vertices[2]);
                        check(owned_metrics::Dot(triangle.areaVector,owned_metrics::Cross(Sub(b,a),Sub(c,a)))>0,
                              "background boundary keeps original outward seed orientation");
                        found=true;break;
                    }
                    check(found,"every boundary triangle retains original geometry ownership");
                }
            }
            check(totalArea[0]==0 && totalArea[1]==0 && totalArea[2]==0,"exact boundary closes with zero vector area");
            check(boundaryVolume==reference.volume,"exact oriented physical boundary encloses correct volume");
            for(const auto& simplex:direct.integration)
                check(simplex.volume>0,"all integration-only cones have strictly positive exact volume");
            if(direct.components>1) {
                bool rejected=false;
                try { Compiler strict;strict.Build(1,seed,boxes[fixture]); }
                catch(const std::runtime_error&) { rejected=true; }
                check(rejected,"disconnected wet regions rejected rather than silently sharing pressure");
            }
        }
        std::printf("BOUNDARY_COMPILER fixture=%u max_components=%u triangles=%u integration_simplices=%u\n",fixture,componentMax,triangles,simplices);
        if(fixture==5) check(componentMax>1,"negative slab fixture genuinely separates wet topology");
    }
    std::printf("BOUNDARY_COMPILER_SUMMARY checks=%u failures=%u\n",checks,failures);
    return failures?1:0;
}
