#include "FactoredFaceMetrics.h"
#include "../acceptance/PolynomialOracles.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>

namespace fg=stage16_factored;
namespace vg=stage16_geometry;
namespace va=fluid_acceptance;
namespace vem=JudasFluidVem;
using Real=vem::Real;
unsigned checks=0,sharedFaces=0,subdivisionFaces=0;
Real maxMetricError=0,maxPhysicalError=0;

void Check(bool value,const char* description) {
    ++checks;
    if(!value) throw std::runtime_error(description);
}
void Near(Real actual,Real expected,Real scale,Real& maximum,const char* description) {
    ++checks;
    scale=std::max(std::abs(expected),std::abs(scale));
    const Real error=scale>0?std::abs(actual-expected)/scale:
                           (actual==expected?0:std::numeric_limits<Real>::infinity());
    maximum=std::max(maximum,error);
    if(!std::isfinite(error) || error>1e-8L) {
        std::printf("FAIL_METRIC %s actual=%Lg expected=%Lg scale=%Lg error=%Lg\n",
                    description,actual,expected,scale,error);
        throw std::runtime_error(description);
    }
}
unsigned Choose(unsigned n,unsigned k) {
    unsigned value=1;
    for(unsigned i=1;i<=k;++i) value=value*(n+1-i)/i;
    return value;
}
vg::ExactMoments Translate(const vg::ExactMoments& source,const vg::RV& delta) {
    vg::ExactMoments result{};
    for(unsigned m=0;m<20;++m) {
        const auto& p=vem::Powers[m];
        for(unsigned x=0;x<=p[0];++x)
            for(unsigned y=0;y<=p[1];++y)
                for(unsigned z=0;z<=p[2];++z)
                    result[m]+=source[vem::MomentIndex(x,y,z)]*Choose(p[0],x)*Choose(p[1],y)*Choose(p[2],z)
                        *vg::Power(delta[0],p[0]-x)*vg::Power(delta[1],p[1]-y)*vg::Power(delta[2],p[2]-z);
    }
    return result;
}
bool SameFrame(const fg::CanonicalFrame& a,const fg::CanonicalFrame& b) {
    return a.origin==b.origin && a.edge==b.edge && a.transverse==b.transverse &&
           a.cross==b.cross && a.minU==b.minU && a.maxU==b.maxU &&
           a.minV==b.minV && a.maxV==b.maxV && a.pivot==b.pivot;
}

void ExactReference(const fg::Cell& candidate,const vg::Cell& reference) {
    Check(candidate.faces.size()==reference.faces.size(),"factored face ownership count");
    for(unsigned index=0;index<candidate.faces.size();++index) {
        const auto& face=candidate.faces[index];
        const auto& actual=candidate.geometry.faces[index];
        const auto found=std::find_if(reference.faces.begin(),reference.faces.end(),[&](const auto& old) {
            return face.solid>=0?old.solid==face.solid:old.solid<0 && old.background==face.background;
        });
        Check(found!=reference.faces.end(),"factored actual owner absent in exact reference");
        Check(face.frame.pivot==found->pivot,"factored normal projection pivot");
        Check(face.projectedMeasure==found->measure,"factored geometry measure changes actual aperture");
        const auto moments=Translate(found->projected,vg::Sub(reference.center,candidate.center));
        const auto basis=face.frame.LocalBasis(candidate.center);
        vem::Vec3 ratio;
        for(unsigned axis=0;axis<3;++axis)
            ratio[axis]=(found->triangles[0].areaVector[axis]/
                         abs(found->triangles[0].areaVector[face.frame.pivot])).convert_to<Real>();
        const Real metric=ratio.norm();
        for(unsigned row=0;row<3;++row) {
            for(unsigned col=0;col<3;++col) {
                vg::R value=0;
                for(unsigned a=0;a<4;++a)
                    for(unsigned b=0;b<4;++b)
                        value+=basis[row][a]*basis[col][b]*moments[vem::ProductIndex(a,b)];
                Near(actual.gram(row,col),value.convert_to<Real>()*metric,actual.area[0],
                     maxMetricError,"factored Gram versus exact integrated P2");
            }
            for(unsigned m=0;m<10;++m) {
                vg::R value=0;
                for(unsigned a=0;a<4;++a)
                    value+=basis[row][a]*moments[vem::ProductIndex(a,m)];
                Near(actual.mixed(row,m),value.convert_to<Real>()*metric,actual.area[0],
                     maxMetricError,"factored mixed versus exact integrated P3");
            }
        }
    }
}

void SubdivideChecks(const fg::Cell& cell) {
    for(unsigned index=0;index<cell.faces.size();++index) {
        const auto& original=cell.faces[index];
        fg::Face subdivided=original;
        subdivided.triangles.clear();
        for(const auto& triangle:original.triangles) {
            vg::RV center;
            for(unsigned axis=0;axis<3;++axis)
                center[axis]=(triangle.points[0][axis]+triangle.points[1][axis]+triangle.points[2][axis])/3;
            for(unsigned edge=0;edge<3;++edge) {
                vg::BoundaryTriangle piece;
                piece.plane=triangle.plane;
                piece.points={triangle.points[edge],triangle.points[(edge+1)%3],center};
                piece.areaVector=owned_metrics::Cross(vg::Sub(piece.points[1],piece.points[0]),
                                                       vg::Sub(piece.points[2],piece.points[0]));
                for(auto& x:piece.areaVector) x/=2;
                subdivided.triangles.push_back(std::move(piece));
            }
        }
        const auto geometry=fg::CollectFace(subdivided,cell.center);
        Check(SameFrame(original.frame,subdivided.frame),"subdivision changes canonical exact hull frame");
        Check(original.projectedMeasure==subdivided.projectedMeasure,"subdivision changes exact aperture measure");
        ++subdivisionFaces;
        const auto& expected=cell.geometry.faces[index];
        for(unsigned row=0;row<3;++row) {
            for(unsigned col=0;col<3;++col)
                Near(geometry.gram(row,col),expected.gram(row,col),expected.area[0],
                     maxMetricError,"subdivision face Gram");
            for(unsigned m=0;m<10;++m)
                Near(geometry.mixed(row,m),expected.mixed(row,m),expected.area[0],
                     maxMetricError,"subdivision face mixed P3");
        }
        if(original.triangles.size()>1) {
            auto missing=original;
            missing.triangles.erase(missing.triangles.begin());
            (void)fg::CollectFace(missing,cell.center);
            Check(missing.projectedMeasure<original.projectedMeasure,
                  "negative control must detect removed aperture triangle, not fill convex hull");
        }
    }
}

void PolynomialChecks(const fg::Cell& cell) {
    if(!cell.fineTets) return;
    const auto op=vem::Build(cell.geometry);
    va::Moments volume;
    volume.measure=cell.geometry.volume[0];
    volume.first={cell.geometry.volume[1],cell.geometry.volume[2],cell.geometry.volume[3]};
    for(unsigned a=0;a<3;++a)
        for(unsigned b=0;b<3;++b) volume.second[a][b]=cell.geometry.volume[vem::ProductIndex(a+1,b+1)];
    const auto gram=va::PolynomialGram(volume,{},1,cell.geometry.density);
    std::array<vem::Vector,12> dofs;
    for(unsigned polynomial=0;polynomial<13;++polynomial) {
        vem::Vector state(op.dimension);
        if(polynomial<12) {
            vem::Affine coefficients=vem::Affine::Zero();
            coefficients[polynomial]=1;
            state=op.InterpolateAffineDOFs(coefficients);
            dofs[polynomial]=state;
            const auto divergence=op.divergenceMoments*state;
            const Real div=polynomial%4==polynomial/4+1?1:0;
            for(unsigned m=0;m<4;++m)
                Near(divergence[m],div*cell.geometry.volume[m],volume.measure,
                     maxPhysicalError,"factored physical divergence patch");
        } else {
            for(unsigned d=0;d<op.dimension;++d) state[d]=(int(d%13)-6)*.031L;
        }
        for(unsigned f=0;f<cell.faces.size();++f) {
            const auto& face=cell.faces[f];
            const auto coefficient=op.FaceNormalCoefficients(f,state);
            std::array<fg::fast::Sum,3> integral;
            std::array<Real,3> integralScale{};
            for(const auto& triangle:face.triangles) {
                std::array<std::array<Real,3>,3> psi{};
                std::array<Real,3> speed{};
                for(unsigned vertex=0;vertex<3;++vertex) {
                    const auto factors=face.frame.Factors(triangle.points[vertex]);
                    for(unsigned row=0;row<3;++row) {
                        psi[row][vertex]=factors[row];
                        speed[vertex]+=factors[row]*coefficient[row];
                    }
                }
                vem::Vec3 ratio;
                for(unsigned axis=0;axis<3;++axis)
                    ratio[axis]=(triangle.areaVector[axis]/abs(triangle.areaVector[face.frame.pivot])).convert_to<Real>();
                const Real measure=abs(triangle.areaVector[face.frame.pivot]).convert_to<Real>()*ratio.norm();
                Real maxSpeed=0;
                for(Real value:speed) maxSpeed=std::max(maxSpeed,std::abs(value));
                for(unsigned row=0;row<3;++row) {
                    std::array<std::array<Real,3>,3> factors{};
                    factors[0]=psi[row];factors[1]=speed;
                    integral[row].Add(measure*fg::fast::ProductAverage<3>(factors,2));
                    Real maxPsi=0;
                    for(Real value:psi[row]) maxPsi=std::max(maxPsi,std::abs(value));
                    integralScale[row]+=measure*maxSpeed*maxPsi;
                }
            }
            for(unsigned row=0;row<3;++row)
                Near(integral[row].Get(),state[3*f+row],integralScale[row],
                     maxPhysicalError,"factored primary flux physical normal trace");
        }
    }
    for(unsigned a=0;a<12;++a)
        for(unsigned b=0;b<12;++b)
            Near(dofs[a].dot(op.mass*dofs[b]),gram[a][b],std::sqrt(gram[a][a]*gram[b][b]),
                 maxPhysicalError,"factored polynomial physical mass patch");
}

struct Shared {
    fg::CanonicalFrame frame;
    vg::R measure;
    vem::Vec3 normal;
    vem::Mat3 gram;
    unsigned count=0;
};
using SharedMap=std::map<std::array<motion_mesh::Lattice,3>,Shared>;

void SharedChecks(const fg::Cell& cell,SharedMap& shared) {
    for(unsigned index=0;index<cell.faces.size();++index) {
        const auto& face=cell.faces[index];
        if(face.solid>=0) continue;
        const auto& geometry=cell.geometry.faces[index];
        auto [at,inserted]=shared.emplace(face.background,
            Shared{face.frame,face.projectedMeasure,geometry.normal,geometry.gram,1});
        if(inserted) continue;
        auto& old=at->second;
        Check(old.count==1,"background face acquired more than two fluid owners");
        ++old.count;
        Check(SameFrame(face.frame,old.frame),"opposite face owners disagree on canonical exact frame");
        Check(face.projectedMeasure==old.measure,"opposite face owners disagree on actual aperture");
        for(unsigned row=0;row<3;++row) {
            Near(geometry.normal[row],-old.normal[row],1,maxMetricError,"shared face outward orientation");
            for(unsigned col=0;col<3;++col)
                Near(geometry.gram(row,col),old.gram(row,col),geometry.area[0],
                     maxMetricError,"shared canonical face metric");
        }
        ++sharedFaces;
    }
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        const unsigned selected=argc>1?unsigned(std::strtoul(argv[1],nullptr,10)):99;
        for(unsigned fixture=0;fixture<5;++fixture) {
            if(selected!=99 && selected!=fixture) continue;
            const auto rotation=fixture==2?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):
                fixture==4?glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3))):
                           glm::dquat(1,0,0,0);
            const auto planes=owned_cut::BoxPlanes(fixture==0?V(3):V(.5),
                fixture==3?V(.499999999,.2,.17):V(.2),rotation);
            SharedMap shared;
            double topologyMs=0,factoredMs=0,exactMetricsMs=0;
            Real totalVolume=0;
            for(unsigned seed=0;seed<6;++seed) {
                auto begin=std::chrono::steady_clock::now();
                stage16_boundary::Compiler direct;
                direct.Build(1,seed,planes);
                topologyMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                begin=std::chrono::steady_clock::now();
                const auto fast=fg::Collect(direct);
                factoredMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                begin=std::chrono::steady_clock::now();
                const auto exactMetrics=vg::FastCollectPrepared(direct);
                exactMetricsMs+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
                for(unsigned m=0;m<20;++m)
                    Check(fast.geometry.volume[m]==exactMetrics.geometry.volume[m],"positive volume integrator changed");
                motion_mesh::Compiler referenceMesh;
                referenceMesh.BuildSelected(1,planes,{seed});
                const auto reference=vg::Collect(referenceMesh);
                ExactReference(fast,reference);
                SubdivideChecks(fast);
                PolynomialChecks(fast);
                SharedChecks(fast,shared);
                totalVolume+=fast.geometry.volume[0];
            }
            Real expected=1;
            if(fixture>0) expected-=8*(fixture==3?.499999999L:.2L)*.2L*(fixture==3?.17L:.2L);
            Near(totalVolume,expected,1,maxMetricError,"factored total physical capacity");
            std::printf("FACTORED fixture=%u topology_ms=%g old_exactP2_metrics_ms=%g factored_metrics_ms=%g\n",
                        fixture,topologyMs,exactMetricsMs,factoredMs);
        }
        std::printf("SUMMARY checks=%u failures=0 shared_faces=%u subdivision_faces=%u "
                    "max_scaled_metric_error=%Lg max_scaled_physical_error=%Lg\n",
                    checks,sharedFaces,subdivisionFaces,maxMetricError,maxPhysicalError);
        return 0;
    } catch(const std::exception& e) {
        std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());
        return 1;
    }
}
