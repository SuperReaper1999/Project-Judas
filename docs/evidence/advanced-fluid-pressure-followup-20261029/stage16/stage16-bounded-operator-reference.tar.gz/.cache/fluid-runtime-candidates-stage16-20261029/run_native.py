from pathlib import Path
import sys,subprocess,os
sys.path.insert(0,'.cache/fluid-contact-repair');import setup_probes as b
b.compile_flags+=['-I'+os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'),'-I'+os.environ.get('EIGEN_INCLUDE_DIR','/tmp/judas-fluid-reference-eigen/extracted/usr/include/eigen3')]
src=Path('.cache/fluid-runtime-candidates-stage16-20261029/runtime/NativePressureTests.cpp')
b.executable(b.compile(src.resolve(),'stage16-NativePressureTests'),'stage16-NativePressureTests',b.out/'stage5-exact-volume-domain.o')
raise SystemExit(subprocess.run([str(b.out/'stage16-NativePressureTests')]).returncode)
