from pathlib import Path
import hashlib,json,tarfile,gzip,re,subprocess,datetime
root=Path('.cache/fluid-runtime-candidates-stage16-20261029')
dest=Path('docs/evidence/advanced-fluid-pressure-followup-20261029/stage16')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
provenance=json.loads((root/'PROVENANCE.json').read_text())
provenance['completedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
provenance['finalSourceSha256']={str(p):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and p.suffix in {'.cpp','.h','.py'}}
provenance['finalProbeSha256']={str(p):sha(p) for p in sorted(root.glob('*.exe'))}
for p in [Path('.cache/fluid-contact-repair/stage16-NativePressureTests'),Path('build/judas_stage16_public_fluid_policy_tests'),Path('build/judas')]:
 provenance['finalProbeSha256'][str(p)]=sha(p)
provenance['nativeCompileFlags']=Path('build/CMakeFiles/judas_script_tests.dir/flags.make').read_text()
provenance['nativeLinkCommand']=Path('build/CMakeFiles/judas_script_tests.dir/link.txt').read_text()
provenance['buildIdentityHeader']=json.loads(Path('.cache/fluid-orthogonal-constraints-stage15-20261029/PROVENANCE.json').read_text())['buildIdentityHeader']
(root/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
runs=json.loads((root/'final/RESULTS.json').read_text())
for row in runs:
 data=Path(row['log']).read_text();matches=re.findall(r'(?:SUMMARY[^\n]*?checks=)(\d+)',data)
 row['assertions']=int(matches[-1]) if matches else None
 row['summaries']=[line for line in data.splitlines() if 'SUMMARY' in line or line.startswith('TIMING')]
results={
 'scope':'Private bounded operator research, not production fluid qualification or unlock',
 'finalSelectedModelRuns':runs,
 'totalKnownFinalAssertions':sum(r['assertions'] or 0 for r in runs),
 'touchCases':5,
 'independentPhysics':{
  'strictReference':{'checks':36,'passed':True,'log':str(root/'logs/strict-reference-v1.log'),'classification':'pointwise incompressible finite-space comparison; different trace resolution, not continuum certification'},
  'curlTrial':{'checks':613,'integrationPassed':True,'coarseAccuracyQualified':False,'log':str(root/'logs/curl-trial-v1.log'),'translationTrialEnergy':0.151353137414965986,'compactTranslationEnergy':0.159423109859390222,'excessPercent':5.3318},
  'matchedRefinement':{'exitCode':1,'classification':'two resolutions run; later disconnected geometry unsupported; no convergence certification','log':str(root/'logs/refinement-matched-v2.log')},
  'resolutionProbe':{'exitCode':1,'classification':'h=1/3 explicit unsupported, h=1/4 also unsupported and exits','log':str(root/'logs/compact-resolution-v1.log')},
 },
 'preservedFailures':[
  {'log':'logs/fine-comparison-v1.log','classification':'initially confounded by sealed/open boundary; not accuracy evidence alone'},
  {'log':'logs/boundary-touch-before.log','classification':'genuine candidate geometry defect; corrected and final positive/negative controls pass'},
  {'log':'logs/boundary-touch-after-v2.log','classification':'unsupported disconnected whole-world fixture; local zero-area edge contact tested separately without merging'},
  {'source':'geometry/FastGeometryTests.cpp mode4','classification':'unchanged rounded-input tiny-angle oracle fails both exact and fast collectors; independent factored-coordinate oracle passes unchanged bound'},
  {'log':'logs/public-fluid-policy.log','classification':'stale public test61a1a94 vs runtime9be9e7a; export identity prerequisite fails'},
  {'log':'logs/public-fluid-policy-relinked.log','classification':'matching binary initially outside runtime directory; export prerequisite fails'},
 ],
 'publicPolicy':{'log':'logs/public-fluid-policy-qualified.log','passed':True,'method':'unmodified test relinked against existing archive and placed beside matching runtime; not a fresh SDK'},
 'noMainPromotion':True,'noFluidUnlock':True,'noHumanAcceptanceClaim':True,
}
(dest/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
archive=dest/'stage16-bounded-operator-reference.tar.gz'
files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.suffix in {'.cpp','.h','.py','.txt','.log','.json'}]
manifest={'schema':1,'parent':provenance['parent'],'files':{}}
with archive.open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for p in files:
    raw=p.read_bytes();info=tarfile.TarInfo(str(p));info.size=len(raw);info.mtime=0;info.mode=0o644
    import io
    tar.addfile(info,io.BytesIO(raw));manifest['files'][str(p)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
manifest['archiveSha256']=sha(archive)
(dest/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archivedFiles':len(files),'archiveBytes':archive.stat().st_size,'finalAssertions':results['totalKnownFinalAssertions'],'cases':len(runs)},indent=2))
