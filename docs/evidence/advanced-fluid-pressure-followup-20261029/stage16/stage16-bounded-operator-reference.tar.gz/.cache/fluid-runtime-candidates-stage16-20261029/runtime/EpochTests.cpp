#include "FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace stage16_runtime;
unsigned checks=0;void Check(bool b,const char* text){++checks;if(!b)throw std::runtime_error(text);}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
 for(unsigned fixture=0;fixture<3;++fixture){
    const auto q=fixture==1?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):glm::dquat(1,0,0,0);
    auto planes=owned_cut::BoxPlanes(V(.5),V(.2),q);const auto t=Clock::now();Epoch epoch(1,planes);const auto built=Ms(t);
    auto zero=epoch.Solve(epoch.Constant(vm::Vec3::Zero()));Check(zero.energy==0&&zero.reaction.norm()==0&&zero.flux.norm()==0,"zero source retains fluid motion");
    vm::Vec3 g=fixture==2?vm::Vec3(.02,-.035,.01):vm::Vec3(0,-.04,0);const auto hydro=epoch.Solve(epoch.Constant(g));const vm::Vec3 expected=-1000*.064L*g;
    const auto forceError=(hydro.reaction.head<3>()-expected).norm();vm::Vec3 center(.5,.5,.5);const auto torqueError=(hydro.reaction.tail<3>()-center.cross(expected)).norm();
    printf("HYDRO fixture=%u build_ms=%g geometry_ms=%g local_ms=%g assembly_ms=%g factor_ms=%g solve_ms=%g cells=%zu faces=%zu tets=%u max_dofs=%u energy=%Lg balance=%Lg force_error=%Lg torque_error=%Lg stationarity=%Lg work=%Lg\n",fixture,built,epoch.geometryMs,epoch.localMs,epoch.assemblyMs,epoch.factorMs,hydro.solveMs,epoch.cells.size(),epoch.interfaces.size(),epoch.fineTets,epoch.maxLocalDofs,hydro.energy,hydro.balance,forceError,torqueError,hydro.stationarity,hydro.energyIdentity);
    Check(hydro.energy<1e-18L,"hydrostatic gravity creates fluid velocity");Check(forceError<1e-10L&&torqueError<1e-10L,"hydrostatic solid wrench wrong");Check(hydro.balance<1e-12L&&hydro.stationarity<1e-12L,"physical solve violates continuity or stationarity");
    Twist twist;twist<<.01,-.02,.03,.02,.03,-.01;const auto moving=epoch.Solve(epoch.Constant(g),twist);Check(moving.balance<1e-12L&&moving.stationarity<1e-12L,"rotating solid violates continuity");Check(moving.energyIdentity<1e-12L,"fluid/body kinetic work identity fails");
    for(unsigned c=0;c<epoch.cells.size();++c)for(unsigned f=0;f<epoch.cells[c]->cell.faces.size();++f)if(epoch.cells[c]->cell.faces[f].solid>=0){const auto exact=(epoch.maps[c].body*twist).eval();Check((moving.local[c].segment(3*f,3)-exact.segment(3*f,3)).norm()<1e-16L,"actual primary solid flux does not match rigid trace");}
    auto predictors=epoch.Constant(vm::Vec3::Zero());for(unsigned c=0;c<predictors.size();++c){predictors[c][0]=.03L*(c+1);predictors[c][4]=-.02L;predictors[c][9]=.014L;}const auto disturbed=epoch.Solve(predictors);Check(disturbed.energy<=disturbed.predictorEnergy*(1+1e-12L),"fixed boundaries create fluid kinetic energy");Check(disturbed.balance<1e-12L&&disturbed.energyIdentity<1e-12L,"disturbed compatible projection violates physical identity");
 }
 {const auto box=owned_cut::BoxPlanes(V(.95,.5,.5),V(.2),glm::dquat(1,0,0,0));Epoch open(1,box,1,Boundary::OpenTop);Twist entering=Twist::Zero();entering[0]=-.1L;const auto flow=open.Solve(open.Constant(vm::Vec3::Zero()),entering);Check(open.componentOpen.size()==1&&open.componentOpen[0],"open top retains full pressure rank instead of sealed gauge");Check(flow.balance<1e-12L&&flow.energyIdentity<1e-12L&&flow.flux.norm()>1e-4L,"actual open boundary cannot receive legitimate displaced fluid flow");}
 printf("SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
