#include "FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace stage16_runtime;
void Run(unsigned fixture,unsigned grid,const mg::Box& box){
    Epoch epoch(grid,box);
    const auto hydro=epoch.Solve(epoch.Constant(vm::Vec3(0,-.04,0)));
    const Real volume=mg::BoxMoments(box).volume.convert_to<Real>();
    const vm::Vec3 expected(0,40*volume,0);
    if((hydro.reaction.head<3>()-expected).norm()>1e-9L||hydro.energy>1e-18L||hydro.balance>1e-12L)
        throw std::runtime_error("boundary-touch ownership corrupts hydrostatic physical load or calm state");
    printf("TOUCH_PASS fixture=%u cells=%zu interfaces=%zu energy=%Lg force=%Lg,%Lg,%Lg balance=%Lg\n",fixture,epoch.cells.size(),epoch.interfaces.size(),hydro.energy,hydro.reaction[0],hydro.reaction[1],hydro.reaction[2],hydro.balance);
}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
    using V=glm::dvec3;
    unsigned fixture=0;
    for(V center:{V(1.25,.5,.5),V(.5,1.25,.5),V(.5,.5,1.25),V(.75,.5,.5)})
        Run(fixture++,2,owned_cut::BoxPlanes(center,V(.25),glm::dquat(1,0,0,0)));
    const auto edgeBox=owned_cut::BoxPlanes(V(1.25,1.25,.5),V(.25),glm::dquat(1,0,0,0));
    for(unsigned seed=0;seed<6;++seed) {
        stage16_boundary::Compiler local;
        local.Build(2,seed,edgeBox);
        if(local.volume!=vg::R(1)/6 || local.components!=1)
            throw std::runtime_error("zero-area edge contact changes the unaffected seed volume/topology");
        for(const auto& triangle:local.boundary)
            if(std::find(local.mesh.bodyPlanes.begin(),local.mesh.bodyPlanes.end(),triangle.plane)!=local.mesh.bodyPlanes.end())
                throw std::runtime_error("zero-area edge contact invents a positive-area wetted body face");
    }
    bool disconnected=false;
    try { Epoch unsupported(2,edgeBox); }
    catch(const std::runtime_error& e) { disconnected=std::string(e.what()).find("disconnected wet pieces")!=std::string::npos; }
    if(!disconnected) throw std::runtime_error("known disconnected geometry unexpectedly merged during touch correction");
    printf("TOUCH_EDGE local_seeds=6 unchanged=1 global_status=explicit_disconnected_rejection\n");
    // Exact non-axis background-plane contact: u=x-y has lower boundary0.
    // Integer plane normals make the coincidence a genuine owned identity,
    // not an almost-45-degree floating-point rotation interpreted as tangent.
    const V center(.625,.375,.5);
    mg::Box oblique;
    unsigned at=0;
    for(V n:{V(1,-1,0),V(1,1,0),V(0,0,1)}) for(double sign:{-1.,1.}) {
        const V normal=sign*n;
        oblique[at++]={{normal.x,normal.y,normal.z},glm::dot(normal,center)+.25};
    }
    Run(fixture++,1,oblique);
    printf("TOUCH_SUMMARY cases=%u failures=0\n",fixture);
    return 0;
}catch(const std::exception& e){fprintf(stderr,"TOUCH_FAIL %s\n",e.what());return 1;}}
