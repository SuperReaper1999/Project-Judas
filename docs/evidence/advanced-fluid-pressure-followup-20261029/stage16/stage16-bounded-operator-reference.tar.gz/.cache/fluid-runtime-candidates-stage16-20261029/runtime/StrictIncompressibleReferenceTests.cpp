#include "StrictIncompressibleReference.h"
#include <cstdio>

namespace sr=stage16_strict_reference;
namespace cf=compatible_flux_extended;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;
    if(!condition) throw std::runtime_error(message);
}

int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(double angle:{0.,.17}) {
            const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
            for(unsigned scenario=0;scenario<3;++scenario) {
                const V source=scenario?V(0):V(0,-.04,0);
                auto weak=sr::Build(1,box,source,false); // Explicit matching pressure-free TOP.
                const auto continuity=sr::PerTetrahedron(weak);
                cf::Dense macro=cf::Dense::Zero(weak.divergence.rows(),weak.variables);
                cf::Dense bodyMacro=cf::Dense::Zero(weak.bodyDivergence.rows(),6);
                for(unsigned c=0;c<weak.cells.size();++c) {
                    const unsigned m=weak.cells[c].macro;
                    for(unsigned test=0;test<4;++test) {
                        const cf::Real weight=test?continuity.centroids[c][test-1]:1;
                        macro.row(4*m+test)+=weight*continuity.fluid.row(c);
                        bodyMacro.row(4*m+test)+=weight*continuity.body.row(c);
                    }
                }
                const auto macroError=(macro-weak.divergence).cwiseAbs().maxCoeff();
                const auto bodyError=(bodyMacro-weak.bodyDivergence).cwiseAbs().maxCoeff();
                Check(macroError<1e-10L && bodyError<1e-10L,"exact face-flux strict equations reconstruct original four weak macro moments");
                Eigen::Matrix<cf::Real,6,1> body=Eigen::Matrix<cf::Real,6,1>::Zero();
                if(scenario==1) body<<.01,-.02,.03,0,0,0;
                if(scenario==2) body<<.01,-.02,.03,.02,.03,-.01;
                const auto weakResult=cf::ProjectConservative(weak,body);
                Check(weakResult.accepted,"unchanged macro-divergence fine kinetic reference accepted");
                const auto weakDefect=sr::Measure(continuity,sr::IntegratedDefect(weak,continuity,weakResult,body));
                auto strict=weak;
                sr::Install(strict,continuity);
                const auto strictResult=cf::ProjectConservative(strict,body);
                Check(strictResult.accepted,"pointwise element-incompressible fine reference accepted");
                const auto strictDefect=sr::Measure(continuity,sr::IntegratedDefect(strict,continuity,strictResult,body));
                Check(strictDefect.maximumVolumeRate<1e-10L,"strict reference has no unaccounted element volume-rate defect");
                if(scenario) {
                    Check(weakDefect.maximumVolumeRate>1e-8L,"negative control old weak pressure space has a genuine unresolved local divergence mode");
                    Check(strictResult.energyAfter+1e-9>=weakResult.energyAfter,
                          "additional physical constraints do not spuriously reduce minimum kinetic energy");
                }
                const auto work=std::abs(strictResult.energyAfter*2+body.dot(strictResult.reaction));
                if(scenario) Check(work<1e-9L,"strict zero-source kinetic resistance is work-conjugate");
                std::printf("STRICT_REFERENCE angle=%g scenario=%u tets=%zu unknowns=%u weak_energy=%.16g strict_energy=%.16g weak_force=%Lg,%Lg,%Lg strict_force=%Lg,%Lg,%Lg weak_max_div=%Lg weak_rms_div=%Lg strict_max_div=%Lg strict_max_volume_rate=%Lg macro_error=%Lg body_macro_error=%Lg strict_stationarity=%g strict_work=%Lg weak_ms=%g strict_ms=%g\n",
                            angle,scenario,weak.cells.size(),weak.variables,weakResult.energyAfter,strictResult.energyAfter,
                            weakResult.reaction[0],weakResult.reaction[1],weakResult.reaction[2],strictResult.reaction[0],strictResult.reaction[1],strictResult.reaction[2],
                            weakDefect.maximumDivergence,weakDefect.rmsDivergence,strictDefect.maximumDivergence,strictDefect.maximumVolumeRate,
                            macroError,bodyError,strictResult.stationarity,work,weakResult.solveMs,strictResult.solveMs);
            }
        }
        std::printf("STRICT_REFERENCE_SUMMARY checks=%u failures=0\n",checks);
        return 0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"FAIL after%uchecks %s\n",checks,error.what());
        return 1;
    }
}
