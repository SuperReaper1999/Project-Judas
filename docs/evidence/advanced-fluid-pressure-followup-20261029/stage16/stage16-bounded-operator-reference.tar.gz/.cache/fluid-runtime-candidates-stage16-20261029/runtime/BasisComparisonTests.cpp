#include "FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace stage16_runtime;
unsigned checks=0;void Check(bool b,const char* what){++checks;if(!b)throw std::runtime_error(what);}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;Real maxFlux=0,maxWrench=0,maxEnergy=0,maxVolumeMoment=0;
 for(unsigned fixture=0;fixture<3;++fixture){const double angle=fixture==0?0:fixture==1?.17:3.2137858346770188e-11;const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));Epoch fast(1,box);ExactEpoch exact(1,box);
  for(unsigned source=0;source<4;++source){auto predictor=fast.Constant(vm::Vec3(0,-.04L,0));if(source==1||source==3)for(unsigned c=0;c<predictor.size();++c){predictor[c][0]=.01L*(c+1);predictor[c][6]=.013L;predictor[c][9]=-.014L;}if(source==2)predictor=fast.Constant(vm::Vec3::Zero());Twist body=Twist::Zero();if(source==3)body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
   const auto a=fast.Solve(predictor,body);const auto b=exact.Solve(predictor,body);Real flux=0,moments=0;
   for(unsigned c=0;c<fast.cells.size();++c){Check(fast.cells[c]->cell.center==exact.cells[c]->cell.center,"basis comparison uses different physical frames");for(unsigned f=0;f<fast.cells[c]->cell.faces.size();++f)flux=std::max(flux,(fast.cells[c]->op.FaceNormalMoments(f,a.local[c])-exact.cells[c]->op.FaceNormalMoments(f,b.local[c])).cwiseAbs().maxCoeff());moments=std::max(moments,(fast.cells[c]->op.momentOperator*a.local[c]-exact.cells[c]->op.momentOperator*b.local[c]).norm());}
   const Real wrench=(a.reaction-b.reaction).norm(),energy=std::abs(a.energy-b.energy);maxFlux=std::max(maxFlux,flux);maxWrench=std::max(maxWrench,wrench);maxEnergy=std::max(maxEnergy,energy);maxVolumeMoment=std::max(maxVolumeMoment,moments);Check(flux<1e-10L&&wrench<1e-10L&&energy<1e-10L&&moments<1e-10L,"stable face basis changes actual physical pressure solution");printf("BASIS fixture=%u source=%u flux_moments=%Lg body_wrench=%Lg energy=%Lg volume_velocity_moments=%Lg\n",fixture,source,flux,wrench,energy,moments);
  }
 }
 printf("SUMMARY checks=%u failures=0 max_flux=%Lg max_wrench=%Lg max_energy=%Lg max_moments=%Lg\n",checks,maxFlux,maxWrench,maxEnergy,maxVolumeMoment);return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
