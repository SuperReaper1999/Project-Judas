#include "FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace stage16_runtime;
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
 for(unsigned n:{1,2,3,4}){try{const auto b=owned_cut::BoxPlanes(V(.5*n),V(.2*n),glm::angleAxis(.17,glm::normalize(V(1,2,-.3))));auto t=Clock::now();Epoch e(n,b,vg::R(1)/n,Boundary::OpenTop);const double build=Ms(t);Twist twist;twist<<.01,-.02,.03,.02,.03,-.01;const auto a=e.Solve(e.Constant(vm::Vec3::Zero()),twist);Real poly=0,volume=0;for(unsigned c=0;c<e.cells.size();++c){const auto& op=e.cells[c]->op;auto p=op.Project(a.local[c]);poly+=op.geometry.density*p.dot(op.polynomialGram*p)/2;volume+=op.geometry.volume[0];}if(std::abs(volume-.936L)>1e-13L)throw std::runtime_error("physical refinement changes wet volume");const auto hydro=e.Solve(e.Constant(vm::Vec3(0,-.04,0)));if((hydro.reaction.head<3>()-vm::Vec3(0,2.56,0)).norm()>1e-10L)throw std::runtime_error("physical refinement changes hydrostatic wrench");printf("RESOLUTION grid=%u h=%g extent=1 status=solved build_ms=%g variables=%ld cells=%zu energy=%Lg affine=%Lg complement=%Lg volume=%Lg balance=%Lg\n",n,1./n,build,long(e.mass.rows()),e.cells.size(),a.energy,poly,a.energy-poly,volume,a.balance);
 }catch(const std::runtime_error& error){if(n!=3||std::string(error.what()).find("disconnected wet pieces")==std::string::npos)throw;printf("RESOLUTION grid=%u status=unsupported reason=disconnected_within_seed preserved=1\n",n);}}
 return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL %s\n",error.what());return 1;}}
