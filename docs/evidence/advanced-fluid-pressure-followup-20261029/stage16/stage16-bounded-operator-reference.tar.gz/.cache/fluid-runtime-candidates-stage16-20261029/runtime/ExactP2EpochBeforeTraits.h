#pragma once
#include "../geometry/PolyhedralMoments.h"
#include "../geometry/BoundaryCompiler.h"
#include "../geometry/FastPolyhedralMoments.h"
#include "../vem/CondensedCell.h"
#include "../../fluid-moving-geometry-stage13-20261029/LocalizedGeometry.h"
#include <Eigen/SparseCholesky>
#include <chrono>
#include <cfenv>
#include <memory>
namespace stage16_runtime {
namespace vg=stage16_geometry; namespace vm=JudasFluidVem;namespace mg=moving_geometry;
using Real=vm::Real;using Matrix=vm::Matrix;using Vector=vm::Vector;using Twist=Eigen::Matrix<Real,6,1>;
using Key=std::array<motion_mesh::Lattice,3>;
using Clock=std::chrono::steady_clock;
inline double Ms(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
struct Local {
    vg::Cell cell;vm::LocalOperator op;vm::CondensedCell condensed;
    explicit Local(vg::Cell c):cell(std::move(c)),op(vm::Build(cell.geometry)),condensed(op){}
};
struct Map {std::vector<int> faceColumns;std::vector<Real> sign;Matrix body;};
struct Result {
    Vector flux,pressure;std::vector<Vector> local;
    Twist reaction=Twist::Zero();Real energy=0,predictorEnergy=0,objective=0,balance=0,stationarity=0,energyIdentity=0;
    double solveMs=0;
};
struct FaceRecord {unsigned firstCell,firstFace,secondCell=~0u,secondFace=~0u,id=0;};
struct Factor {
    Vector scale,pressureScale;std::vector<unsigned> retainedRows;
    Eigen::SparseMatrix<Real> scaledMass;
    Eigen::SimplicialLDLT<Eigen::SparseMatrix<Real>> kinetic;
    Matrix inverseContinuity,scaledContinuity;
    Eigen::LDLT<Matrix> pressure;
};
struct Epoch {
    unsigned grid=0;mg::Box box;mg::Bounds bounds;
    std::vector<std::shared_ptr<const Local>> cells;
    std::vector<unsigned> seedIds;
    std::vector<Map> maps;std::map<Key,FaceRecord> interfaces;
    std::vector<std::vector<unsigned>> components;
    Matrix continuity,bodyContinuity,bodyMass;
    Eigen::SparseMatrix<Real> mass;Matrix mixedBody;
    std::shared_ptr<Factor> factor;
    double geometryMs=0,localMs=0,assemblyMs=0,factorMs=0;
    unsigned fineTets=0,maxLocalDofs=0;
    static std::shared_ptr<const Local> BuildLocal(unsigned grid,unsigned seed,const mg::Box& box,const mg::Bounds& bounds,double& geometryMs,double& localMs){
        (void)bounds;stage16_boundary::Compiler geometry;auto t=Clock::now();geometry.Build(grid,seed,box);
        auto c=vg::FastCollectPrepared(geometry);geometryMs+=Ms(t);if(!c.fineTets)return {};t=Clock::now();auto local=std::make_shared<Local>(std::move(c));localMs+=Ms(t);return local;
    }
    Epoch(unsigned n,const mg::Box& b):grid(n),box(b),bounds(mg::BoundBox(b)){
        if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("Stage16 requires round-to-nearest");
        if(!n||n>4)throw std::runtime_error("Stage16 bounded reference domain");
        for(unsigned s=0;s<6*n*n*n;++s){auto c=BuildLocal(n,s,b,bounds,geometryMs,localMs);if(c){seedIds.push_back(s);cells.push_back(std::move(c));}}Assemble();
    }
    unsigned Update(const mg::Box& next){
        if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("Stage16 requires round-to-nearest");
        if(mg::Equal(box,next))return 0;
        const auto nextBounds=mg::BoundBox(next);Epoch staged=*this;staged.cells.clear();staged.seedIds.clear();staged.geometryMs=staged.localMs=0;unsigned changed=0;std::map<unsigned,unsigned> old;for(unsigned i=0;i<seedIds.size();++i)old.emplace(seedIds[i],i);
        for(unsigned seed=0;seed<6*grid*grid*grid;++seed){std::shared_ptr<const Local> cell;if(mg::OverlapSeed(grid,seed,bounds)||mg::OverlapSeed(grid,seed,nextBounds)){cell=BuildLocal(grid,seed,next,nextBounds,staged.geometryMs,staged.localMs);++changed;}else if(old.count(seed))cell=cells[old.at(seed)];if(cell){staged.seedIds.push_back(seed);staged.cells.push_back(std::move(cell));}}
        staged.box=next;staged.bounds=nextBounds;staged.Assemble();*this=std::move(staged);return changed;
    }
    bool Outer(const Key& key)const {for(unsigned a=0;a<3;++a){bool low=true,high=true;for(const auto& p:key){low&=p[a]==0;high&=p[a]==int(grid);}if(low||high)return true;}return false;}
    void Assemble(){
        auto start=Clock::now();interfaces.clear();maps.clear();fineTets=maxLocalDofs=0;
        for(unsigned c=0;c<cells.size();++c){const auto& local=*cells[c];fineTets+=local.cell.fineTets;maxLocalDofs=std::max(maxLocalDofs,local.op.dimension);for(unsigned f=0;f<local.cell.faces.size();++f){const auto& face=local.cell.faces[f];if(face.solid>=0||Outer(face.background))continue;auto [at,inserted]=interfaces.emplace(face.background,FaceRecord{c,f});if(!inserted){if(at->second.secondCell!=~0u)throw std::runtime_error("third owner of fluid interface");at->second.secondCell=c;at->second.secondFace=f;}}}
        unsigned id=0;for(auto& [key,face]:interfaces){if(face.secondCell==~0u)throw std::runtime_error("interior wet face missing adjacent owner");face.id=id++;const auto& a=cells[face.firstCell]->cell;const auto& b=cells[face.secondCell]->cell;const auto& fa=a.faces[face.firstFace];const auto& fb=b.faces[face.secondFace];
            if(fa.pivot!=fb.pivot||fa.measure!=fb.measure||fa.varU!=fb.varU||fa.varV!=fb.varV||fa.cov!=fb.cov||fa.meanU+a.center[fa.u]!=fb.meanU+b.center[fb.u]||fa.meanV+a.center[fa.v]!=fb.meanV+b.center[fb.v])throw std::runtime_error("shared face exact metric/basis mismatch");
            if((a.geometry.faces[face.firstFace].normal+b.geometry.faces[face.secondFace].normal).norm()>1e-15L)throw std::runtime_error("shared face normals are not opposite");}
        const unsigned n=3*interfaces.size();if(!n||cells.empty())throw std::runtime_error("fully displaced/trace-free Stage16 domain");
        continuity=Matrix::Zero(cells.size(),n);bodyContinuity=Matrix::Zero(cells.size(),6);bodyMass=Matrix::Zero(6,6);mixedBody=Matrix::Zero(n,6);std::vector<Eigen::Triplet<Real>> entries;
        for(unsigned c=0;c<cells.size();++c){const auto& l=*cells[c];Map map;const unsigned nf=l.cell.faces.size();map.faceColumns.assign(nf,-1);map.sign.assign(nf,0);map.body=Matrix::Zero(3*nf,6);
            for(unsigned f=0;f<nf;++f){const auto& face=l.cell.faces[f];if(face.solid>=0){vm::Vec3 center;for(unsigned a=0;a<3;++a)center[a]=l.cell.center[a].convert_to<Real>();for(unsigned k=0;k<6;++k){vm::Vec3 v=vm::Vec3::Zero(),omega=vm::Vec3::Zero();if(k<3)v[k]=1;else{omega[k-3]=1;v=omega.cross(center);}map.body.block(3*f,k,3,1)=(l.op.polynomialDofs*vm::RigidAffine(v,omega)).segment(3*f,3);}}
                else if(!Outer(face.background)){const auto& owner=interfaces.at(face.background);map.faceColumns[f]=3*owner.id;map.sign[f]=owner.firstCell==c?1:-1;}}
            const auto& h=l.condensed.faceMass;const Matrix hb=h*map.body;bodyMass+=map.body.transpose()*hb;bodyContinuity.row(c)=l.condensed.closure*map.body;
            for(unsigned f=0;f<nf;++f)if(map.faceColumns[f]>=0)for(unsigned a=0;a<3;++a){const unsigned row=map.faceColumns[f]+a;const Real sign=map.sign[f];continuity(c,row)+=l.condensed.closure[3*f+a]*sign;mixedBody.row(row)+=sign*hb.row(3*f+a);for(unsigned g=0;g<nf;++g)if(map.faceColumns[g]>=0)for(unsigned b=0;b<3;++b)if(h(3*f+a,3*g+b)!=0)entries.emplace_back(row,map.faceColumns[g]+b,sign*map.sign[g]*h(3*f+a,3*g+b));}
            maps.push_back(std::move(map));
        }
        mass.resize(n,n);mass.setFromTriplets(entries.begin(),entries.end());assemblyMs=Ms(start);start=Clock::now();factor=std::make_shared<Factor>();auto& f=*factor;f.scale.resize(n);for(unsigned i=0;i<n;++i){if(!(mass.coeff(i,i)>0))throw std::runtime_error("nonpositive global kinetic diagonal");f.scale[i]=1/sqrt(mass.coeff(i,i));}
        f.scaledMass=f.scale.asDiagonal()*mass*f.scale.asDiagonal();f.kinetic.compute(f.scaledMass);if(f.kinetic.info()!=Eigen::Success||(f.kinetic.vectorD().array()<=0).any())throw std::runtime_error("global kinetic factor is not positive");
        std::vector<unsigned> parent(cells.size());std::iota(parent.begin(),parent.end(),0);const auto root=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};for(const auto& [key,face]:interfaces)parent[root(face.secondCell)]=root(face.firstCell);std::set<unsigned> roots;for(unsigned c=0;c<cells.size();++c)if(!roots.insert(root(c)).second)f.retainedRows.push_back(c);
        components.clear();std::map<unsigned,unsigned> group;for(unsigned c=0;c<cells.size();++c){auto [at,inserted]=group.emplace(root(c),components.size());if(inserted)components.emplace_back();components[at->second].push_back(c);}
        f.scaledContinuity.resize(f.retainedRows.size(),n);f.pressureScale.resize(f.retainedRows.size());for(unsigned r=0;r<f.retainedRows.size();++r){const auto row=(continuity.row(f.retainedRows[r])*f.scale.asDiagonal()).eval();f.pressureScale[r]=1/row.norm();f.scaledContinuity.row(r)=f.pressureScale[r]*row;}
        f.inverseContinuity=f.kinetic.solve(f.scaledContinuity.transpose());Matrix schur=f.scaledContinuity*f.inverseContinuity;schur=(schur+schur.transpose()).eval()/2;f.pressure.compute(schur);if(f.pressure.info()!=Eigen::Success||!f.pressure.isPositive())throw std::runtime_error("topological pressure Schur factor failed");factorMs=Ms(start);
    }
    Result Solve(const std::vector<vm::Affine>& predictors,const Twist& twist=Twist::Zero())const {
        if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("Stage16 requires round-to-nearest");
        auto start=Clock::now();if(predictors.size()!=cells.size()||!twist.allFinite())throw std::invalid_argument("invalid Stage16 physical source");const auto& f=*factor;
        for(const auto& component:components){Real sum=0,scale=0;for(unsigned c:component){const Real rate=(bodyContinuity.row(c)*twist)[0];sum+=rate;scale+=std::abs(rate);}if(std::abs(sum)>128*std::numeric_limits<Real>::epsilon()*scale)throw std::invalid_argument("prescribed body flux changes sealed component volume");}
        std::vector<vm::CondensedSource> sources;Vector rhs=Vector::Zero(mass.rows());Result out;for(unsigned c=0;c<cells.size();++c){const auto& l=*cells[c];if(!predictors[c].allFinite())throw std::invalid_argument("nonfinite predictor");const Vector raw=l.op.InterpolateAffineDOFs(predictors[c]);auto source=l.condensed.SourceFromPredictor(raw);out.predictorEnergy+=source.predictorEnergyConstant;for(unsigned face=0;face<l.cell.faces.size();++face)if(maps[c].faceColumns[face]>=0)rhs.segment(maps[c].faceColumns[face],3)+=maps[c].sign[face]*source.faceLoad.segment(3*face,3);sources.push_back(std::move(source));}
        rhs-=mixedBody*twist;const Vector scaledRhs=f.scale.asDiagonal()*rhs;Vector y=f.kinetic.solve(scaledRhs);Vector b(f.retainedRows.size());for(unsigned r=0;r<f.retainedRows.size();++r)b[r]=f.pressureScale[r]*(bodyContinuity.row(f.retainedRows[r])*twist)[0];Vector lambda=f.pressure.solve((f.scaledContinuity*y+b).eval());y-=f.inverseContinuity*lambda;
        out.flux=f.scale.asDiagonal()*y;out.pressure=Vector::Zero(cells.size());for(unsigned r=0;r<f.retainedRows.size();++r)out.pressure[f.retainedRows[r]]=f.pressureScale[r]*lambda[r];
        out.stationarity=(mass*out.flux-rhs+continuity.transpose()*out.pressure).norm()/std::max<Real>(1,rhs.norm());
        for(unsigned c=0;c<cells.size();++c){const auto& l=*cells[c];Vector face=maps[c].body*twist;for(unsigned p=0;p<l.cell.faces.size();++p)if(maps[c].faceColumns[p]>=0)face.segment(3*p,3)+=maps[c].sign[p]*out.flux.segment(maps[c].faceColumns[p],3);
            Vector raw=l.condensed.Reconstruct(face,sources[c]);out.energy+=l.op.Energy(raw);out.objective+=l.condensed.FullObjective(raw,sources[c]);out.balance=std::max(out.balance,(l.op.divergenceMoments*raw).cwiseAbs().maxCoeff());out.reaction-=maps[c].body.transpose()*l.condensed.Gradient(face,sources[c]);out.local.push_back(std::move(raw));}
        out.reaction-=bodyContinuity.transpose()*out.pressure;out.energyIdentity=std::abs(out.objective+out.energy+twist.dot(out.reaction)-out.predictorEnergy);out.solveMs=Ms(start);
        if(!out.flux.allFinite()||!out.reaction.allFinite()||!std::isfinite(out.energy))throw std::runtime_error("nonfinite Stage16 physical result");
        return out;
    }
    std::vector<vm::Affine> Constant(vm::Vec3 velocity)const {std::vector<vm::Affine> result(cells.size(),vm::Affine::Zero());for(auto& a:result)for(unsigned k=0;k<3;++k)a[4*k]=velocity[k];return result;}
};
} // namespace stage16_runtime
