#include "FaceEpoch.h"
#include "../../fluid-localized-pressure-stage14-20261029/SparsePressureEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;using namespace stage16_runtime;
 for(double angle:{0.,.17}){const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));Epoch compact(1,box,1,Boundary::OpenTop);localized_pressure::Epoch fine(1,box);
  for(unsigned scenario=0;scenario<3;++scenario){Twist body=Twist::Zero();if(scenario==1)body<<.01,-.02,.03,0,0,0;if(scenario==2)body<<.01,-.02,.03,.02,.03,-.01;const vm::Vec3 source=scenario?vm::Vec3::Zero():vm::Vec3(0,-.04,0);const auto a=compact.Solve(compact.Constant(source),body);const auto b=fine.Solve([&](V){return V(source.x(),source.y(),source.z());},body);const auto wrench=(a.reaction-b.fullReaction).norm();const auto energy=std::abs(a.energy-b.fullEnergy);printf("FINE_COMPARISON angle=%g scenario=%u compact_energy=%Lg fine_energy=%.16g compact_force=%Lg,%Lg,%Lg fine_force=%Lg,%Lg,%Lg wrench_absolute=%Lg wrench_relative=%Lg energy_relative=%Lg\n",angle,scenario,a.energy,b.fullEnergy,a.reaction[0],a.reaction[1],a.reaction[2],b.fullReaction[0],b.fullReaction[1],b.fullReaction[2],wrench,wrench/std::max<Real>(1e-18L,b.fullReaction.norm()),energy/std::max<Real>(1e-18L,std::abs(b.fullEnergy)));}
 }
 return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
