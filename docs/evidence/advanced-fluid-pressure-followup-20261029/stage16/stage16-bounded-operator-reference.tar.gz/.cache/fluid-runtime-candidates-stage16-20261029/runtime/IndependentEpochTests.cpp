// Independent global, uncondensed KKT check for the chosen Stage16 metric.
// It imports no CondensedCell data or FaceEpoch global matrices. Geometry and
// the local VEM mass are shared definitions; this is an algebra/assembly oracle,
// not an independent continuum-discretization accuracy claim.
#include "FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace independent_epoch {
using namespace stage16_runtime;
struct FaceOwner {unsigned cell=0,face=0;};
struct Answer {
    std::vector<Vector> local;
    Twist reaction=Twist::Zero();
    Real energy=0,residual=0,stationarity=0;
    unsigned variables=0,rows=0;
};
struct Oracle {
    const Epoch& epoch;
    std::vector<unsigned> offset;
    Matrix mass,rows,bodyRows;
    Vector rawScale,rowScale;
    Eigen::FullPivLU<Matrix> factor;
    unsigned variables=0;
    bool omittedInterface=false;

    bool IsOuter(const Key& key)const {
        for(unsigned a=0;a<3;++a){bool low=true,high=true;
            for(const auto& p:key){low=low&&(p[a]==0);high=high&&(p[a]==int(epoch.grid));}
            if(low||high)return true;
        }
        return false;
    }
    explicit Oracle(const Epoch& e,bool omitOneTangentialInterface=false):epoch(e){
        for(const auto& c:e.cells){offset.push_back(variables);variables+=c->op.dimension;}
        mass=Matrix::Zero(variables,variables);
        for(unsigned c=0;c<e.cells.size();++c)
            mass.block(offset[c],offset[c],e.cells[c]->op.dimension,e.cells[c]->op.dimension)=e.cells[c]->op.mass;
        std::vector<Vector> constraint;
        std::vector<Twist> prescribed;
        const auto append=[&](const Vector& row,const Twist& b){constraint.push_back(row);prescribed.push_back(b);};
        std::map<Key,std::vector<FaceOwner>> shared;
        for(unsigned c=0;c<e.cells.size();++c){const auto& local=*e.cells[c];
            for(unsigned f=0;f<local.cell.faces.size();++f){const auto& face=local.cell.faces[f];
                if(face.solid<0&&!IsOuter(face.background)){shared[face.background].push_back({c,f});continue;}
                Matrix boundary=Matrix::Zero(3,6);
                if(face.solid>=0){vm::Vec3 center;for(unsigned a=0;a<3;++a)center[a]=local.cell.center[a].convert_to<Real>();
                    for(unsigned k=0;k<6;++k){vm::Vec3 v=vm::Vec3::Zero(),w=vm::Vec3::Zero();
                        if(k<3)v[k]=1;else{w[k-3]=1;v=w.cross(center);}
                        boundary.col(k)=(local.op.polynomialDofs*vm::RigidAffine(v,w)).segment(3*f,3);
                    }
                }
                for(unsigned a=0;a<3;++a){Vector row=Vector::Zero(variables);row[offset[c]+3*f+a]=1;append(row,boundary.row(a).transpose());}
            }
        }
        std::vector<unsigned> parent(e.cells.size());std::iota(parent.begin(),parent.end(),0);
        const auto root=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};
        for(const auto& [key,owners]:shared){if(owners.size()!=2)throw std::runtime_error("independent oracle found incomplete shared face");
            parent[root(owners[1].cell)]=root(owners[0].cell);
            for(unsigned a=0;a<3;++a){
                // Remove a tangential moment only. Removing mean flux would
                // also change the one-gauge-per-component rank argument.
                if(omitOneTangentialInterface&&!omittedInterface&&a==1){omittedInterface=true;continue;}
                Vector row=Vector::Zero(variables);for(const auto& owner:owners)row[offset[owner.cell]+3*owner.face+a]=1;
                append(row,Twist::Zero());
            }
        }
        std::set<unsigned> seen;
        for(unsigned c=0;c<e.cells.size();++c){const bool omitConstant=seen.insert(root(c)).second;
            for(unsigned a=0;a<4;++a){if(omitConstant&&a==0)continue;Vector row=Vector::Zero(variables);
                row.segment(offset[c],e.cells[c]->op.dimension)=e.cells[c]->op.divergenceMoments.row(a).transpose();append(row,Twist::Zero());}
        }
        rows.resize(constraint.size(),variables);bodyRows.resize(constraint.size(),6);
        for(unsigned r=0;r<constraint.size();++r){rows.row(r)=constraint[r].transpose();bodyRows.row(r)=prescribed[r].transpose();}
        rawScale.resize(variables);for(unsigned i=0;i<variables;++i){if(!(mass(i,i)>0))throw std::runtime_error("independent nonpositive mass diagonal");rawScale[i]=1/std::sqrt(mass(i,i));}
        Matrix C=rows*rawScale.asDiagonal();rowScale.resize(rows.rows());
        for(unsigned r=0;r<rows.rows();++r){if(!(C.row(r).norm()>0))throw std::runtime_error("independent empty constraint");rowScale[r]=1/C.row(r).norm();}
        C=rowScale.asDiagonal()*C;
        const unsigned size=variables+rows.rows();Matrix saddle=Matrix::Zero(size,size);
        saddle.topLeftCorner(variables,variables)=rawScale.asDiagonal()*mass*rawScale.asDiagonal();
        saddle.topRightCorner(variables,rows.rows())=C.transpose();saddle.bottomLeftCorner(rows.rows(),variables)=C;
        factor.compute(saddle);
        if(factor.rank()!=size)throw std::runtime_error("independent raw KKT is rank deficient");
    }
    Answer Solve(const std::vector<vm::Affine>& predictor,const Twist& twist)const {
        Vector load=Vector::Zero(variables);
        for(unsigned c=0;c<epoch.cells.size();++c){const auto& local=*epoch.cells[c];
            load.segment(offset[c],local.op.dimension)=local.op.mass*(local.op.polynomialDofs*predictor[c]);}
        Vector rhs(variables+rows.rows());rhs.head(variables)=rawScale.asDiagonal()*load;
        const Vector boundary=bodyRows*twist;rhs.tail(rows.rows())=rowScale.asDiagonal()*boundary;
        const Vector solution=factor.solve(rhs);const Vector raw=rawScale.asDiagonal()*solution.head(variables);
        const Vector lambda=rowScale.asDiagonal()*solution.tail(rows.rows());
        Answer out;out.variables=variables;out.rows=rows.rows();out.reaction=bodyRows.transpose()*lambda;
        out.energy=raw.dot(mass*raw)/2;
        out.residual=(rows*raw-boundary).norm()/std::max<Real>(1,boundary.norm());
        out.stationarity=(mass*raw+rows.transpose()*lambda-load).norm()/std::max<Real>(1,load.norm());
        for(unsigned c=0;c<epoch.cells.size();++c)out.local.push_back(raw.segment(offset[c],epoch.cells[c]->op.dimension));
        return out;
    }
};
}

using namespace stage16_runtime;
unsigned checks=0;
void Check(bool b,const char* text){++checks;if(!b)throw std::runtime_error(text);}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
    using V=glm::dvec3;Real maxRaw=0,maxEnergy=0,maxWrench=0,maxResidual=0;
    for(unsigned fixture=0;fixture<2;++fixture){const auto rotation=fixture?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):glm::dquat(1,0,0,0);
        Epoch epoch(1,owned_cut::BoxPlanes(V(.5),V(.2),rotation));independent_epoch::Oracle reference(epoch);
        auto disturbed=epoch.Constant(vm::Vec3(0,-.04L,0));
        for(unsigned c=0;c<disturbed.size();++c){disturbed[c][0]+=.015L*(c+1);disturbed[c][3]=-.02L;disturbed[c][6]=.013L;disturbed[c][9]=.014L;}
        for(unsigned source=0;source<3;++source){auto predictor=source==0?epoch.Constant(vm::Vec3(0,-.04L,0)):disturbed;
            Twist body=Twist::Zero();if(source==2)body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
            const auto actual=epoch.Solve(predictor,body);const auto oracle=reference.Solve(predictor,body);
            Real rawError=0;for(unsigned c=0;c<epoch.cells.size();++c){const auto difference=actual.local[c]-oracle.local[c];
                rawError=std::max(rawError,std::sqrt(std::abs(difference.dot(epoch.cells[c]->op.mass*difference))));}
            const Real kineticScale=std::max<Real>(1,std::sqrt(2*oracle.energy));
            const Real energyError=std::abs(actual.energy-oracle.energy)/std::max<Real>(1,oracle.energy);
            const Real wrenchError=(actual.reaction-oracle.reaction).norm()/std::max<Real>(1,oracle.reaction.norm());
            maxRaw=std::max(maxRaw,rawError/kineticScale);maxEnergy=std::max(maxEnergy,energyError);maxWrench=std::max(maxWrench,wrenchError);maxResidual=std::max(maxResidual,std::max(oracle.residual,oracle.stationarity));
            Check(rawError/kineticScale<1e-10L,"condensed physical endpoint differs from raw global KKT");
            Check(energyError<1e-10L,"condensed energy differs from raw global KKT");
            Check(wrenchError<1e-10L,"condensed body wrench differs from raw global KKT");
            Check(oracle.residual<1e-10L&&oracle.stationarity<1e-10L,"raw independent physical equations fail");
            printf("INDEPENDENT fixture=%u source=%u variables=%u rows=%u kinetic_endpoint=%Lg energy=%Lg wrench=%Lg residual=%Lg stationarity=%Lg\n",fixture,source,oracle.variables,oracle.rows,rawError/kineticScale,energyError,wrenchError,oracle.residual,oracle.stationarity);
        }
        independent_epoch::Oracle broken(epoch,true);Check(broken.omittedInterface,"missing-interface negative control not constructed");
        const auto absent=broken.Solve(disturbed,Twist::Zero());const auto good=reference.Solve(disturbed,Twist::Zero());
        Real difference=0;for(unsigned c=0;c<epoch.cells.size();++c)difference=std::max(difference,(absent.local[c]-good.local[c]).norm());
        Check(difference>1e-7L,"independent global oracle cannot detect missing interface moment");
        printf("NEGATIVE missing_tangential_interface fixture=%u endpoint_difference=%Lg\n",fixture,difference);
    }
    printf("INDEPENDENT_EPOCH_SUMMARY checks=%u failures=0 max_kinetic_endpoint=%Lg max_energy=%Lg max_wrench=%Lg max_equation_residual=%Lg\n",checks,maxRaw,maxEnergy,maxWrench,maxResidual);return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL after%u checks %s\n",checks,e.what());return 1;}}
