#pragma once

// Diagnostic reference only. Reuses the preserved fine affine H(div) kinetic
// field and changes its continuity test space from four moments per original
// macrocell to one exact integrated-divergence equation per physical tetrahedron.
// An affine velocity has constant divergence on each tetrahedron, so these
// constraints establish pointwise element incompressibility. Fine background
// subface traces remain unrestricted: this is a valid richer-space diagnostic,
// not an identical-DOF comparison against the compact coarse face field.
#include "../../fluid-compatible-flux-stage9-20261029/ConservativeElimination.h"
#include "../../fluid-moving-geometry-stage13-20261029/MotionCompiler.h"

namespace stage16_strict_reference {

namespace cf=compatible_flux_extended;
using cf::Real;
using cf::R;
using cf::RV;
using cf::Dense;
using cf::Vector;
using Box=std::array<fluid_exact::Plane,6>;

inline owned_cut::Snapshot Snapshot(const motion_mesh::Compiler& source) {
    owned_cut::Snapshot result;
    auto& target=result.mesh;
    target.planes=source.planes;
    target.bodyPlanes=source.bodyPlanes;
    target.backgroundFaces=source.backgroundFaces;
    for(const auto& vertex:source.vertices)
        target.vertices.push_back({vertex.exact,vertex.planes,vertex.position});
    for(const auto& tetrahedron:source.tetrahedra)
        target.tetrahedra.push_back({tetrahedron.geometry,tetrahedron.vertices,tetrahedron.voxel,tetrahedron.seed});
    // Same fixed origin as Stage14 and Stage16. This changes only the twist
    // reference used by the kinetic lift, never the physical cut geometry.
    result.solidCenter=cf::V(0);
    return result;
}

inline cf::System Build(unsigned grid,const Box& box,cf::V predicted=cf::V(0),bool closed=false) {
    motion_mesh::Compiler mesh;
    std::vector<unsigned> selected(6*grid*grid*grid);
    std::iota(selected.begin(),selected.end(),0);
    mesh.BuildSelected(grid,box,selected);
    return cf::Build(Snapshot(mesh),predicted,grid,closed);
}

struct Continuity {
    Dense fluid,body;
    std::vector<Real> volumes;
    std::vector<std::array<Real,3>> centroids;
};

inline Continuity PerTetrahedron(const cf::System& raw) {
    Continuity result;
    result.fluid=Dense::Zero(raw.cells.size(),raw.variables);
    result.body=Dense::Zero(raw.cells.size(),6);
    result.volumes.resize(raw.cells.size());
    result.centroids.resize(raw.cells.size());
    const RV center={R(raw.geometry.solidCenter.x),R(raw.geometry.solidCenter.y),R(raw.geometry.solidCenter.z)};
    for(unsigned c=0;c<raw.cells.size();++c) {
        const auto& cell=raw.cells[c];
        const RV& a=raw.positions[cell.vertices[0]];
        const RV& b=raw.positions[cell.vertices[1]];
        const RV& d=raw.positions[cell.vertices[2]];
        const RV& e=raw.positions[cell.vertices[3]];
        const R volume=cf::Dot(cf::Sub(b,a),cf::Cross(cf::Sub(d,a),cf::Sub(e,a)))/6;
        if(volume<=0) throw std::runtime_error("strict reference has nonpositive exact tetrahedron");
        result.volumes[c]=volume.convert_to<Real>();
        for(unsigned axis=0;axis<3;++axis) {
            R centroid=0;
            for(unsigned vertex:cell.vertices) centroid+=raw.positions[vertex][axis]/4;
            result.centroids[c][axis]=centroid.convert_to<Real>();
        }
        std::array<R,6> body{};
        for(unsigned faceId:cell.faces) {
            const auto& face=raw.faces[faceId];
            const int sign=face.owners[0]==c?1:-1;
            if(face.variable!=~0u) {
                // The Piola corner flux is 2*physicalArea*normalVelocity.
                // Integrating affine normal velocity therefore sums its three
                // corner flux increments with weight 1/6, exactly.
                for(unsigned corner=0;corner<3;++corner)
                    result.fluid(c,face.variable+corner)+=sign*raw.columnScale(face.variable+corner)/6;
            } else if(face.wall) {
                // Build's rigid lift is divergence-free. Free faces carry
                // rigid lift plus the unknown increment; solid faces retain
                // the lift; fixed walls cancel it. The net body divergence is
                // consequently minus the exact rigid wall flux, with no thin
                // tetrahedral inverse or reconstructed-velocity cancellation.
                for(unsigned vertex:face.vertices) {
                    const auto lift=cf::Rigid(raw.positions[vertex],center);
                    for(unsigned axis=0;axis<3;++axis)
                        for(unsigned j=0;j<6;++j)
                            body[j]-=R(sign)*face.areaNormal[axis]*lift[axis][j]/6;
                }
            }
        }
        for(unsigned j=0;j<6;++j) result.body(c,j)=body[j].convert_to<Real>();
    }
    return result;
}

inline void Install(cf::System& privateCopy,const Continuity& continuity) {
    privateCopy.divergence=continuity.fluid;
    privateCopy.bodyDivergence=continuity.body;
}

inline Vector Scaled(const cf::System& raw,const cf::ConservativeResult& result) {
    return result.flux.cwiseQuotient(raw.columnScale);
}

inline Vector IntegratedDefect(const cf::System& raw,const Continuity& continuity,
                               const cf::ConservativeResult& result,
                               const Eigen::Matrix<Real,6,1>& body) {
    return continuity.fluid*Scaled(raw,result)+continuity.body*body;
}

struct Defect {
    Real maximumVolumeRate=0,maximumDivergence=0,rmsDivergence=0;
};

inline Defect Measure(const Continuity& continuity,const Vector& integrated) {
    Defect result;
    Real volume=0,weighted=0;
    for(unsigned c=0;c<continuity.volumes.size();++c) {
        const Real divergence=integrated(c)/continuity.volumes[c];
        result.maximumVolumeRate=std::max(result.maximumVolumeRate,std::abs(integrated(c)));
        result.maximumDivergence=std::max(result.maximumDivergence,std::abs(divergence));
        weighted+=continuity.volumes[c]*divergence*divergence;
        volume+=continuity.volumes[c];
    }
    result.rmsDivergence=std::sqrt(weighted/volume);
    return result;
}

} // namespace stage16_strict_reference
