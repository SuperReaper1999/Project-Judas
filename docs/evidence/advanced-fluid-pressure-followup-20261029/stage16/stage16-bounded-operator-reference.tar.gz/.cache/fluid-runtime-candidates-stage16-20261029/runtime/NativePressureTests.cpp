#include "NativePressure.h"
#include "PhysicsWorld.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using V=glm::dvec3;
namespace np=stage16_native;
unsigned checks=0;
void Check(bool condition,const char* what) {
    ++checks;
    if(!condition) throw std::runtime_error(what);
}

enum class Support { Free,Fixed,Hinge };

void Run(Support support,double mass,double angle,bool omitNativeReaction=false) {
    PhysicsWorld world;
    world.Init();
    const glm::vec3 half(.2f),center(.5f);
    const auto q=glm::angleAxis(float(angle),glm::normalize(glm::vec3(1,2,-.3)));
    const auto body=world.CreateShape(Shape::Box(half),{center,q},true,float(mass),0,0);
    if(support!=Support::Fixed) world.SetLinearVelocity(body,{0,float(-9.81/240),0});
    if(support!=Support::Free) {
        JointSettings settings;
        settings.bodyA=body;
        settings.type=support==Support::Hinge?JointType::Hinge:JointType::Fixed;
        if(support==Support::Hinge) settings.anchorA={0,0,.15f};
        settings.anchorB=center+q*settings.anchorA;
        settings.frameA=glm::inverse(q);
        Check(world.CreateJoint(settings).IsValid(),"actual native support joint created");
    }
    PhysicsConstraintParticipant participant;
    participant.bodies={body};
    unsigned publications=0;
    std::vector<np::Vector> staged,published;
    np::Solution solution;
    double endpointError=0,impulseY=0,buildMs=0,solveMs=0;
    bool rejected=false;
    participant.propose=[&](const PhysicsConstraintBatch& batch,PhysicsConstraintProposal& proposal) {
        // One qualified native boundary only. Later native substeps remain
        // ordinary physics; no moving-volume/transport continuation is claimed.
        if(publications) return false;
        Check(batch.contacts.empty(),"native support proof has no unrepresented contact");
        unsigned owner=~0u;
        for(unsigned b=0;b<batch.bodies.size();++b)
            if(batch.bodies[b].handle.id==body.id && batch.bodies[b].handle.world==body.world) owner=b;
        Check(owner!=~0u,"real native body identity retained");
        const auto& native=batch.bodies[owner];
        const auto box=owned_cut::BoxPlanes(V(native.center),V(half),glm::dquat(native.orientation));
        auto start=np::Clock::now();
        np::Epoch epoch(1,box);
        buildMs=np::Ms(start);
        np::Vec3 com;
        for(unsigned a=0;a<3;++a) com(a)=native.center[a];
        const np::Vec3 gravity(0,-9.81L*batch.context.deltaTime,0);
        const auto predictors=epoch.Constant(gravity);
        start=np::Clock::now();
        const np::FluidSchur schur(epoch,predictors,com);
        solution=np::Solve(schur,batch,owner);
        solveMs=np::Ms(start);
        Check(schur.symmetryError<1e-11L,"fluid added-mass derivative preserves work symmetry");
        Check(solution.stationarity<1e-10L,"simultaneous native/fluid impulse stationarity");
        Check(solution.fluid.balance<1e-12L,"actual fluid primary normal flux satisfies continuity");
        const np::Twist originTwist=schur.comToOrigin*solution.velocity;
        for(unsigned c=0;c<epoch.cells.size();++c) {
            const auto& cell=*epoch.cells[c];
            np::Vec3 cellCenter;
            for(unsigned a=0;a<3;++a) cellCenter(a)=cell.cell.center[a].convert_to<np::Real>();
            for(unsigned f=0;f<cell.cell.faces.size();++f) if(cell.cell.faces[f].solid>=0)
                for(const auto& triangle:cell.cell.faces[f].triangles)
                    for(const auto& exactLocal:triangle.points) {
                        np::Vec3 r;
                        for(unsigned a=0;a<3;++a) r(a)=exactLocal[a].convert_to<np::Real>();
                        const np::Vec3 point=cellCenter+r;
                        const np::Vec3 solidVelocity=originTwist.head<3>()+originTwist.tail<3>().cross(point);
                        const auto normal=cell.op.EvaluateFaceNormal(f,solution.fluid.local[c],r);
                        Check(std::abs(normal-cell.op.geometry.faces[f].normal.dot(solidVelocity))<1e-10L,
                              "actual primary fluid trace has no solid-normal leakage at owned boundary vertices");
                    }
        }
        Check(solution.fluid.energyIdentity<1e-10L && solution.energyDefect<1e-10L,
              "fluid and actual native body retain complete coupled energy identity");
        Check(solution.energyAfter<=solution.energyBefore+std::abs(solution.jointWork)+1e-9L,
              "coupled body fluid energy bound includes only actual prescribed joint work");
        if(support==Support::Free)
            Check(mass>64?solution.velocity(1)<0:solution.velocity(1)>0,
                  "heavy native owner sinks and light native owner rises");
        if(support==Support::Fixed) {
            const auto volume=np::mg::BoxMoments(box).volume.convert_to<np::Real>();
            Check(std::abs(solution.reaction(1)+1000*volume*gravity.y())<1e-8L,
                  "fixed native owner receives independently correct buoyancy impulse");
            Check(solution.velocity.norm()<1e-8L,"actual fixed support remains physically still");
        }
        if(support==Support::Hinge) {
            Check(std::abs(solution.velocity(3))>1e-4L,"off-center hinge has genuine free-axis angular response");
            Check((solution.joints*solution.velocity-solution.jointTargets).norm()<1e-10L,
                  "coupled hinge endpoint obeys its actual native rows");
        }
        proposal.linearImpulses.assign(batch.bodies.size(),V(0));
        proposal.angularImpulses.assign(batch.bodies.size(),V(0));
        for(unsigned a=0;a<3;++a) {
            proposal.linearImpulses[owner][a]=double(solution.reaction(a));
            proposal.angularImpulses[owner][a]=double(solution.reaction(a+3));
        }
        proposal.contactImpulses.clear();
        proposal.jointImpulses.resize(batch.joints.size());
        for(unsigned j=0;j<batch.joints.size();++j)
            proposal.jointImpulses[j]=omitNativeReaction?0:float(solution.jointImpulses(j));
        staged=solution.fluid.local;
        impulseY=double(solution.reaction(1));
        return true;
    };
    participant.published=[&](const auto&) noexcept { ++publications;published.swap(staged); };
    PhysicsWorld::VelocityCoupling coupling;
    coupling.physicalBatch=&participant;
    coupling.afterSubstep=[&](const auto& phase) {
        if(phase.index!=0) return;
        const V linear(world.GetLinearVelocity(body)),angular(world.GetAngularVelocity(body));
        V expectedLinear,expectedAngular;
        for(unsigned a=0;a<3;++a) {
            expectedLinear[a]=double(solution.velocity(a));
            expectedAngular[a]=double(solution.velocity(a+3));
        }
        endpointError=glm::length(linear-expectedLinear)+glm::length(angular-expectedAngular);
        Check(endpointError<3e-7,"actual completed native physical endpoint agrees with simultaneous pressure solve");
        np::Twist actual;
        for(unsigned a=0;a<3;++a) { actual(a)=linear[a];actual(a+3)=angular[a]; }
        const auto energy=solution.fluid.energy+actual.dot(solution.bodyMass*actual)/2;
        Check(energy<=solution.energyBefore+std::abs(solution.jointWork)+1e-7L,
              "actual published native endpoint retains the coupled kinetic bound");
    };
    try { world.Step(1.f/60,&coupling); }
    catch(const std::runtime_error& error) {
        if(!omitNativeReaction) throw;
        Check(std::string(error.what()).find("proposal violates a native joint constraint")!=std::string::npos,
              "omitted native reaction fails the actual native constraint validator");
        rejected=true;
    }
    Check(omitNativeReaction?(rejected && publications==0 && published.empty()):(publications==1 && !published.empty()),
          "only a genuinely accepted native transaction publishes fluid state");
    std::printf("NATIVE_VEM support=%u mass=%g angle=%g omitted=%d published=%u endpoint_error=%.9g impulse_y=%.12g energy_before=%.12Lg energy_after=%.12Lg energy_defect=%.8Lg build_ms=%g solve_ms=%g rejected=%d\n",
                unsigned(support),mass,angle,omitNativeReaction,publications,endpointError,impulseY,solution.energyBefore,solution.energyAfter,solution.energyDefect,buildMs,solveMs,rejected);
}

int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        Run(Support::Fixed,80,0);
        Run(Support::Fixed,80,.37);
        Run(Support::Free,80,.37);
        Run(Support::Free,20,.37);
        Run(Support::Hinge,80,0);
        Run(Support::Fixed,80,0,true);
        std::printf("SUMMARY checks=%u failures=0\n",checks);
        return 0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());
        return 1;
    }
}
