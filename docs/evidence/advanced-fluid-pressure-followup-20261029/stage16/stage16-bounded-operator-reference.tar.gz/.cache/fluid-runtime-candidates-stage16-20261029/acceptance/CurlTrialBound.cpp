// Independent continuum admissible-flow upper bound for the closed unit tank.
// The trial construction imports NO discrete fluid matrix or solved velocity.
// Epoch is used only at the final comparison boundary and can be omitted with
// -DJUDAS_TRIAL_WITH_EPOCH=0 for the small independent analytic executable.
#include "PolynomialOracles.h"
#include <algorithm>
#include <cstdio>
#include <limits>
#include <vector>

#ifndef JUDAS_TRIAL_WITH_EPOCH
#define JUDAS_TRIAL_WITH_EPOCH 1
#endif
#if JUDAS_TRIAL_WITH_EPOCH
#include "../runtime/FaceEpoch.h"
#include "../../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#endif

namespace trial {
using namespace fluid_acceptance;
constexpr Real bodyHalf=.2L,tankHalf=.5L,density=1000;

struct AxisCutoff { Real value=0,first=0,second=0; };
inline AxisCutoff Cutoff(Real coordinate) {
    const Real magnitude=std::abs(coordinate);
    if(magnitude<=bodyHalf) return {1,0,0};
    if(magnitude>=tankHalf) return {};
    const Real width=tankHalf-bodyHalf;
    const Real t=(magnitude-bodyHalf)/width;
    const Real sign=coordinate<0?-1:1;
    return {1-3*t*t+2*t*t*t,sign*(-6*t+6*t*t)/width,(-6+12*t)/(width*width)};
}

struct Field { Vec velocity; Matrix gradient{}; Real chi=0; };
inline Field Evaluate(Vec r,Vec translationAtBodyCenter,Vec omega) {
    std::array<AxisCutoff,3> f;
    for(unsigned a=0;a<3;++a) f[a]=Cutoff(r[a]);
    const Real chi=f[0].value*f[1].value*f[2].value;
    Vec grad;
    Matrix hessian{};
    for(unsigned a=0;a<3;++a) {
        const unsigned b=(a+1)%3,c=(a+2)%3;
        grad[a]=f[a].first*f[b].value*f[c].value;
        hessian[a][a]=f[a].second*f[b].value*f[c].value;
        for(unsigned d=a+1;d<3;++d) {
            const unsigned other=3-a-d;
            hessian[a][d]=hessian[d][a]=f[a].first*f[d].first*f[other].value;
        }
    }
    // curl(A)=U+omega cross r, so curl(chi*A) is divergence-free and equals
    // the physical rigid velocity near the whole body, zero at tank walls.
    const Vec A=Cross(translationAtBodyCenter,r)/2-omega*(Dot(r,r)/2);
    const Vec rigid=translationAtBodyCenter+Cross(omega,r);
    Field out;
    out.chi=chi;
    out.velocity=rigid*chi+Cross(grad,A);
    // Direct derivative calculation provides an independent local divergence
    // check; this is not a hard-coded zero or a finite-difference cancellation.
    for(unsigned derivative=0;derivative<3;++derivative) {
        Vec unit;
        unit[derivative]=1;
        const Vec dRigid=Cross(omega,unit);
        const Vec dA=Cross(translationAtBodyCenter,unit)/2-omega*r[derivative];
        const Vec dGrad{hessian[0][derivative],hessian[1][derivative],hessian[2][derivative]};
        const Vec column=rigid*grad[derivative]+dRigid*chi+Cross(dGrad,A)+Cross(grad,dA);
        for(unsigned component=0;component<3;++component) out.gradient[component][derivative]=column[component];
    }
    return out;
}

struct Rule { std::vector<Real> x,w; };
inline Rule Gauss(unsigned order) {
    Rule rule{std::vector<Real>(order),std::vector<Real>(order)};
    const Real pi=std::acos(Real(-1));
    for(unsigned i=0;i<(order+1)/2;++i) {
        Real x=std::cos(pi*(i+.75L)/(order+.5L));
        bool converged=false;
        Real derivative=0;
        for(unsigned iteration=0;iteration<64;++iteration) {
            Real previous=1,current=x;
            for(unsigned n=2;n<=order;++n) {
                const Real next=((2*n-1)*x*current-(n-1)*previous)/n;
                previous=current;current=next;
            }
            derivative=order*(x*current-previous)/(x*x-1);
            const Real next=x-current/derivative;
            if(std::abs(next-x)<=4*std::numeric_limits<Real>::epsilon()) {
                x=next;converged=true;break;
            }
            x=next;
        }
        if(!converged) throw std::runtime_error("independent Gauss root did not converge");
        Real previous=1,current=x;
        for(unsigned n=2;n<=order;++n) {
            const Real next=((2*n-1)*x*current-(n-1)*previous)/n;
            previous=current;current=next;
        }
        derivative=order*(x*current-previous)/(x*x-1);
        const Real weight=2/((1-x*x)*derivative*derivative);
        rule.x[i]=-x;rule.x[order-1-i]=x;
        rule.w[i]=rule.w[order-1-i]=weight;
    }
    return rule;
}

struct Result { Real energy=0,maxDivergence=0,maxRelativeDivergence=0; unsigned points=0; };
inline Result Integrate(unsigned order,Vec translation,Vec omega) {
    const auto rule=Gauss(order);
    const std::array<Real,4> cuts{-tankHalf,-bodyHalf,bodyHalf,tankHalf};
    Real sum=0,correction=0;
    Result result;
    for(unsigned bx=0;bx<3;++bx)
        for(unsigned by=0;by<3;++by)
            for(unsigned bz=0;bz<3;++bz) {
                if(bx==1 && by==1 && bz==1) continue; // no fluid inside solid
                const std::array<unsigned,3> box{bx,by,bz};
                Vec center,half;
                for(unsigned a=0;a<3;++a) {
                    center[a]=(cuts[box[a]]+cuts[box[a]+1])/2;
                    half[a]=(cuts[box[a]+1]-cuts[box[a]])/2;
                }
                for(unsigned i=0;i<order;++i)
                    for(unsigned j=0;j<order;++j)
                        for(unsigned k=0;k<order;++k) {
                            const Vec r{center.x+half.x*rule.x[i],center.y+half.y*rule.x[j],
                                        center.z+half.z*rule.x[k]};
                            const auto field=Evaluate(r,translation,omega);
                            const Real weight=rule.w[i]*rule.w[j]*rule.w[k]*half.x*half.y*half.z;
                            const Real energy=density*Dot(field.velocity,field.velocity)*weight/2;
                            const Real adjusted=energy-correction;
                            const Real next=sum+adjusted;
                            correction=(next-sum)-adjusted;
                            sum=next;
                            Real trace=0,scale=0;
                            for(unsigned a=0;a<3;++a) {
                                trace+=field.gradient[a][a];
                                for(unsigned b=0;b<3;++b) scale+=std::abs(field.gradient[a][b]);
                            }
                            result.maxDivergence=std::max(result.maxDivergence,std::abs(trace));
                            if(scale>0) result.maxRelativeDivergence=std::max(result.maxRelativeDivergence,std::abs(trace)/scale);
                            ++result.points;
                        }
            }
    result.energy=sum;
    return result;
}

// For a=.2,b=.5, the separable cutoff integrals are rational and give an
// independent closed-form TRANSLATION energy, not merely agreement of Gauss
// rules: I0=int f²=109/175, I2=int x²f²=463/21000,
// Id=int f'²=8, I2d=int x²f'²=176/175.
inline Real AnalyticTranslationEnergy(Vec translation) {
    const Real I0=109.L/175,I2=463.L/21000,Id=8,I2d=176.L/175;
    const Real volumeWeight=I0*I0*I0/8+I2d*I0*I0/2+Id*I2*I0/2
                           -8*bodyHalf*bodyHalf*bodyHalf;
    return density*volumeWeight*Dot(translation,translation)/2;
}

unsigned checks=0;
inline void Check(bool condition,const char* what) {
    ++checks;
    if(!condition) throw std::runtime_error(what);
}
inline void BoundaryChecks(Vec translation,Vec omega) {
    const std::array<Real,5> samples{-1,-.5L,0,.5L,1};
    for(unsigned axis=0;axis<3;++axis)
        for(int side:{-1,1})
            for(Real u:samples)
                for(Real v:samples) {
                    Vec r;
                    r[axis]=side*bodyHalf;
                    r[(axis+1)%3]=u*bodyHalf;r[(axis+2)%3]=v*bodyHalf;
                    Check(Norm(Evaluate(r,translation,omega).velocity-
                               (translation+Cross(omega,r)))<1e-17L,"trial does not match actual rigid body boundary");
                    r[axis]=side*tankHalf;
                    r[(axis+1)%3]=u*tankHalf;r[(axis+2)%3]=v*tankHalf;
                    Check(Norm(Evaluate(r,translation,omega).velocity)==0,"trial violates closed tank wall");
                }
}
} // namespace trial

int main() {
    using namespace trial;
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        std::printf("CURL_TRIAL contract=continuum_admissible_energy_upper_bound "
                    "tank_side=1 body_half=.2 density=1000 cutoff=C1_piecewise_cubic "
                    "quadrature_polynomial_degree_per_axis<=10 order6_sufficient_exact_arithmetic=1\n");
#if JUDAS_TRIAL_WITH_EPOCH
        stage16_runtime::Epoch epoch(1,owned_cut::BoxPlanes(glm::dvec3(.5),glm::dvec3(.2),glm::dquat(1,0,0,0)));
#endif
        for(unsigned scenario=0;scenario<2;++scenario) {
            const Vec worldLinear{.01L,-.02L,.03L};
            const Vec omega=scenario?Vec{.02L,.03L,-.01L}:Vec{};
            const Vec atBody=worldLinear+Cross(omega,Vec{.5L,.5L,.5L});
            BoundaryChecks(atBody,omega);
            Real previous=0;
            for(unsigned order:{8,10,12}) {
                const auto result=Integrate(order,atBody,omega);
                Check(result.maxRelativeDivergence<1e-16L,"trial direct analytic divergence is not zero");
                if(previous>0)
                    Check(std::abs(result.energy-previous)<1e-12L*result.energy,"polynomial trial quadrature disagrees");
                if(!scenario)
                    Check(std::abs(result.energy-AnalyticTranslationEnergy(atBody))<1e-12L*result.energy,
                          "trial translation quadrature disagrees with independent rational closed form");
                std::printf("CURL_TRIAL scenario=%u order=%u energy=%0.18Lg max_div=%Lg "
                            "max_relative_div=%Lg points=%u analytic_translation=%0.18Lg\n",
                            scenario,order,result.energy,result.maxDivergence,result.maxRelativeDivergence,
                            result.points,scenario?Real(0):AnalyticTranslationEnergy(atBody));
                previous=result.energy;
            }
#if JUDAS_TRIAL_WITH_EPOCH
            stage16_runtime::Twist twist;
            twist<<worldLinear.x,worldLinear.y,worldLinear.z,omega.x,omega.y,omega.z;
            const auto candidate=epoch.Solve(epoch.Constant(JudasFluidVem::Vec3::Zero()),twist);
            std::printf("CURL_COMPARISON scenario=%u candidate_energy=%0.18Lg continuum_upper_bound=%0.18Lg "
                        "candidate_over_bound=%Lg above_bound=%u qualifier=coarse_model_accuracy_not_algebra_residual\n",
                        scenario,candidate.energy,previous,candidate.energy/previous,
                        unsigned(candidate.energy>previous*(1+1e-12L)));
            // Deliberately report, do not turn the existing candidate result
            // into a manufactured pass or silently tune stabilization.
#endif
        }
        std::printf("CURL_TRIAL_SUMMARY checks=%u failures=0 scope=analytic_trial_only\n",checks);
        return 0;
    } catch(const std::exception& e) {
        std::fprintf(stderr,"CURL_TRIAL_FAIL checks=%u %s\n",checks,e.what());
        return 1;
    }
}
