#pragma once

#include "PolynomialOracles.h"
#include "../vem/VemLocal.h"

#include <algorithm>
#include <limits>
#include <string>

namespace fluid_acceptance {

// Independent boundary triangulation in the SAME centroid-local frame as the
// candidate geometry. Triangles are grouped by candidate face, not new DOFs.
using FacePatch = std::vector<Triangle>;

enum class CheckGroup { Geometry, Dofs, Mass, Projection, Divergence, Trace, Count };

struct PatchReport {
    unsigned checks=0, failures=0;
    std::array<Real,static_cast<unsigned>(CheckGroup::Count)> maxScaledError{};
    std::string worstCheck;
    Real worstError=0;
    Real tolerance=1e-10L;

    void Compare(Real actual, Real expected, Real characteristic,
                 CheckGroup group, const std::string& name) {
        ++checks;
        const Real error=std::abs(actual-expected);
        const Real scale=std::max(std::abs(expected),std::abs(characteristic));
        Real normalized=0;
        if(!std::isfinite(actual) || !std::isfinite(expected))
            normalized=std::numeric_limits<Real>::infinity();
        else if(scale>0) normalized=error/scale;
        else if(error>0) normalized=std::numeric_limits<Real>::infinity();
        auto& maximum=maxScaledError[static_cast<unsigned>(group)];
        maximum=std::max(maximum,normalized);
        if(normalized>worstError) { worstError=normalized; worstCheck=name; }
        if(normalized>tolerance) ++failures;
    }
};

inline Vec FromEigen(const JudasFluidVem::Vec3& x) { return {x.x(),x.y(),x.z()}; }
inline JudasFluidVem::Vec3 ToEigen(Vec x) { return {x.x,x.y,x.z}; }

inline FaceBasis IndependentBasis(const JudasFluidVem::FaceGeometry& face) {
    FaceBasis basis{};
    for(unsigned i=0;i<3;++i)
        for(unsigned j=0;j<4;++j) basis[i][j]=face.basis(i,j);
    return basis;
}

// Independently evaluate the DECLARED face basis. This deliberately does not
// invoke any VEM reconstruction. Respect an explicitly anchored basis so that
// thin faces do not subtract two enormous raw affine polynomial terms.
inline Real BasisAt(const JudasFluidVem::FaceGeometry& face,unsigned row,Vec x) {
    if(!face.anchoredBasis) return Evaluate(IndependentBasis(face)[row],x);
    const Vec origin=FromEigen(face.evaluationOrigin);
    Real value=face.basisAtOrigin[row];
    for(unsigned i=0;i<3;++i) value+=face.basis(row,i+1)*(x[i]-origin[i]);
    return value;
}

inline std::array<Real,3> IntegrateTrace(const Triangle& triangle,
                                       const std::array<Real,3>& speed,
                                       const JudasFluidVem::FaceGeometry& face) {
    const Real speedSum=speed[0]+speed[1]+speed[2];
    std::array<Real,3> integral{};
    for(unsigned row=0;row<3;++row) {
        Real testSum=0,diagonal=0;
        for(unsigned corner=0;corner<3;++corner) {
            const Real test=BasisAt(face,row,triangle.vertices[corner]);
            testSum+=test;
            diagonal+=speed[corner]*test;
        }
        integral[row]=triangle.moments.measure*(speedSum*testSum+diagonal)/12;
    }
    return integral;
}

inline std::array<Real,10> LowMoments(const Moments& m) {
    return {m.measure,m.first.x,m.first.y,m.first.z,
            m.second[0][0],m.second[0][1],m.second[0][2],
            m.second[1][1],m.second[1][2],m.second[2][2]};
}

inline Real MonomialScale(Real measure, Vec coordinateMax, unsigned monomial) {
    static constexpr unsigned powers[10][3]={{0,0,0},{1,0,0},{0,1,0},{0,0,1},
        {2,0,0},{1,1,0},{1,0,1},{0,2,0},{0,1,1},{0,0,2}};
    Real value=measure;
    for(unsigned a=0;a<3;++a)
        for(unsigned p=0;p<powers[monomial][a];++p) value*=coordinateMax[a];
    return value;
}

inline Vec CoordinateBounds(const FacePatch& patch) {
    Vec maximum;
    for(const auto& triangle:patch)
        for(Vec vertex:triangle.vertices)
            for(unsigned i=0;i<3;++i) maximum[i]=std::max(maximum[i],std::abs(vertex[i]));
    return maximum;
}

inline Real FieldBound(const std::vector<FacePatch>& patches,
                        const AffineVelocity& field) {
    Real maximum=0;
    for(const auto& patch:patches)
        for(const auto& triangle:patch)
            for(Vec vertex:triangle.vertices) maximum=std::max(maximum,Norm(field.At(vertex)));
    return maximum;
}

inline std::vector<Real> IndependentDofs(const JudasFluidVem::LocalOperator& op,
                                        const Moments& volume,
                                        const std::vector<FacePatch>& patches,
                                        const AffineVelocity& field) {
    std::vector<Real> result(op.dimension,0);
    for(unsigned face=0;face<patches.size();++face) {
        for(const auto& triangle:patches[face]) {
            std::array<Real,3> speed{};
            for(unsigned corner=0;corner<3;++corner)
                speed[corner]=Dot(triangle.normal,field.At(triangle.vertices[corner]));
            const auto moments=IntegrateTrace(triangle,speed,op.geometry.faces[face]);
            for(unsigned i=0;i<3;++i) result[3*face+i]+=moments[i];
        }
    }
    const Vec mean=VelocityIntegral(volume,field);
    const Vec angular=AngularMomentum(volume,field,{});
    for(unsigned i=0;i<3;++i) {
        result[op.MeanOffset()+i]=mean[i];
        result[op.AngularOffset()+i]=angular[i];
    }
    return result;
}

inline Real DofScale(const JudasFluidVem::LocalOperator& op,
                      const Moments& volume,const std::vector<FacePatch>& patches,
                      const AffineVelocity& field,unsigned dof) {
    const Real speed=FieldBound(patches,field);
    if(dof<op.MeanOffset()) {
        const unsigned face=dof/3,row=dof%3;
        Real maximum=0,area=0;
        for(const auto& triangle:patches[face]) {
            area+=triangle.moments.measure;
            for(Vec vertex:triangle.vertices)
                maximum=std::max(maximum,std::abs(BasisAt(op.geometry.faces[face],row,vertex)));
        }
        return area*maximum*speed;
    }
    if(dof<op.AngularOffset()) return volume.measure*speed;
    Real radius=0;
    for(const auto& patch:patches)
        for(const auto& triangle:patch)
            for(Vec vertex:triangle.vertices) radius=std::max(radius,Norm(vertex));
    return volume.measure*radius*speed;
}

// Actual face transport is tested separately from the affine L2 projection.
// Primary flux may legitimately differ from Project(dofs)'s boundary trace for
// non-polynomial states. Overwriting primary flux with that projection fails.
inline void CheckActualTrace(PatchReport& report,
                              const JudasFluidVem::LocalOperator& op,
                              const std::vector<FacePatch>& patches,
                              const JudasFluidVem::Vector& dofs,
                              const std::string& label) {
    for(unsigned face=0;face<patches.size();++face) {
        std::array<Real,3> integrated{},scales{};
        for(const auto& triangle:patches[face]) {
            std::array<Real,3> speed{};
            Real maxSpeed=0;
            for(unsigned corner=0;corner<3;++corner) {
                speed[corner]=op.EvaluateFaceNormal(face,dofs,ToEigen(triangle.vertices[corner]));
                maxSpeed=std::max(maxSpeed,std::abs(speed[corner]));
            }
            const auto actual=IntegrateTrace(triangle,speed,op.geometry.faces[face]);
            for(unsigned row=0;row<3;++row) {
                integrated[row]+=actual[row];
                Real maxBasis=0;
                for(Vec vertex:triangle.vertices)
                    maxBasis=std::max(maxBasis,std::abs(BasisAt(op.geometry.faces[face],row,vertex)));
                scales[row]+=triangle.moments.measure*maxSpeed*maxBasis;
            }
        }
        for(unsigned row=0;row<3;++row)
            report.Compare(integrated[row],dofs[3*face+row],scales[row],CheckGroup::Trace,
                           label+" actual primary trace face="+std::to_string(face));
    }
}

inline PatchReport CheckPolynomialPatches(const JudasFluidVem::LocalOperator& op,
                                          const Moments& referenceVolume,
                                          const std::vector<FacePatch>& patches,
                                          Real tolerance=1e-10L) {
    if(patches.size()!=op.geometry.faces.size())
        throw std::runtime_error("acceptance face decomposition count mismatch");
    PatchReport report;
    report.tolerance=tolerance;
    Vec cellBounds;
    for(unsigned face=0;face<patches.size();++face) {
        Moments area;
        for(const auto& triangle:patches[face]) {
            area.Add(triangle.moments);
            for(unsigned a=0;a<3;++a)
                report.Compare(op.geometry.faces[face].normal[a],triangle.normal[a],1,
                               CheckGroup::Geometry,"oriented boundary normal");
        }
        const Vec bounds=CoordinateBounds(patches[face]);
        for(unsigned a=0;a<3;++a) cellBounds[a]=std::max(cellBounds[a],bounds[a]);
        const auto expected=LowMoments(area);
        for(unsigned i=0;i<10;++i)
            report.Compare(op.geometry.faces[face].area[i],expected[i],
                           MonomialScale(area.measure,bounds,i),CheckGroup::Geometry,
                           "independent face P2 moments");
    }
    const auto expectedVolume=LowMoments(referenceVolume);
    for(unsigned i=0;i<10;++i)
        report.Compare(op.geometry.volume[i],expectedVolume[i],
                       MonomialScale(referenceVolume.measure,cellBounds,i),
                       CheckGroup::Geometry,"independent volume P2 moments");

    std::array<JudasFluidVem::Vector,12> dofs;
    const auto gram=PolynomialGram(referenceVolume,{},1,op.geometry.density);
    for(unsigned polynomial=0;polynomial<12;++polynomial) {
        const auto field=PolynomialBasis(polynomial);
        const auto reference=IndependentDofs(op,referenceVolume,patches,field);
        JudasFluidVem::Affine coefficient=JudasFluidVem::Affine::Zero();
        coefficient[polynomial]=1;
        dofs[polynomial]=op.InterpolateAffineDOFs(coefficient);
        for(unsigned i=0;i<op.dimension;++i)
            report.Compare(dofs[polynomial][i],reference[i],
                           DofScale(op,referenceVolume,patches,field,i),CheckGroup::Dofs,
                           "independent affine DOFs polynomial="+std::to_string(polynomial));

        const auto projected=op.Project(dofs[polynomial]);
        const Real speed=FieldBound(patches,field);
        for(unsigned face=0;face<patches.size();++face)
            for(const auto& triangle:patches[face])
                for(Vec vertex:triangle.vertices)
                    report.Compare(op.EvaluateFaceNormal(face,dofs[polynomial],ToEigen(vertex)),
                                   Dot(triangle.normal,field.At(vertex)),speed,CheckGroup::Trace,
                                   "independent affine boundary corner normal");
        // Compare physical velocities, not potentially huge coefficients in a
        // thin affine basis. This still checks values at every boundary vertex.
        for(const auto& patch:patches)
            for(const auto& triangle:patch)
                for(Vec vertex:triangle.vertices) {
                    const Vec actual=FromEigen(JudasFluidVem::EvaluateAffine(projected,ToEigen(vertex)));
                    const Vec expected=field.At(vertex);
                    for(unsigned a=0;a<3;++a)
                        report.Compare(actual[a],expected[a],speed,CheckGroup::Projection,
                                       "physical affine patch velocity");
                }
        const auto actualDiv=op.divergenceMoments*dofs[polynomial];
        const auto expectedDiv=DivergenceMoments(referenceVolume,field);
        for(unsigned i=0;i<4;++i) {
            Real scale=referenceVolume.measure;
            if(i) scale*=cellBounds[i-1];
            report.Compare(actualDiv[i],expectedDiv[i],scale,CheckGroup::Divergence,
                           "independent affine divergence moments");
        }
        CheckActualTrace(report,op,patches,dofs[polynomial],"affine");
    }
    for(unsigned i=0;i<12;++i)
        for(unsigned j=0;j<12;++j) {
            const Real actual=dofs[i].dot(op.mass*dofs[j]);
            const Real scale=std::sqrt(std::abs(gram[i][i]*gram[j][j]));
            report.Compare(actual,gram[i][j],scale,CheckGroup::Mass,
                           "independent physical affine mass");
        }
    JudasFluidVem::Vector arbitrary(op.dimension);
    for(unsigned i=0;i<op.dimension;++i) arbitrary[i]=(int(i%13)-6)*.031L;
    CheckActualTrace(report,op,patches,arbitrary,"non-polynomial");
    return report;
}

} // namespace fluid_acceptance
