#include "PolynomialOracles.h"

#include <algorithm>
#include <cstdio>
#include <string>

using namespace fluid_acceptance;

namespace {
unsigned checks=0;
void Require(bool condition, const char* message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}
void Near(Real actual, Real expected, const char* message) {
    Require(std::abs(actual-expected)<=2e-15L*std::max(Real(1),std::abs(expected)),message);
}
void Near(Vec actual, Vec expected, const char* message) {
    for(unsigned i=0;i<3;++i) Near(actual[i],expected[i],message);
}

Moments CubeMoments() {
    Moments m;
    std::array<unsigned,3> permutation{0,1,2};
    do {
        Vec a,b;
        a[permutation[0]]=1;
        b=a;
        b[permutation[1]]=1;
        m.Add(TetraMoments({Vec{},a,b,Vec{1,1,1}}));
    } while(std::next_permutation(permutation.begin(),permutation.end()));
    return m;
}

void MassAndMomentum() {
    const Moments cube=CubeMoments();
    Near(cube.measure,1,"cube volume");
    Near(cube.first,{.5L,.5L,.5L},"cube first moment");
    for(unsigned i=0;i<3;++i)
        for(unsigned j=0;j<3;++j)
            Near(cube.second[i][j],i==j?1.L/3:1.L/4,"cube second moment");

    const auto rigid=RigidVelocity({1,2,-1},{2,-1,3},{.5L,.5L,.5L});
    Near(rigid.Divergence(),0,"rigid divergence");
    Near(KineticEnergy(cube,rigid,12),50,"rigid physical inertia energy");
    Near(VelocityIntegral(cube,rigid)*12,{12,24,-12},"rigid linear momentum");
    Near(AngularMomentum(cube,rigid,{.5L,.5L,.5L},12),{4,-2,6},
         "rigid angular momentum");

    AffineVelocity affine;
    affine.origin={.5L,.5L,.5L};
    affine.value={1,-2,.5L};
    affine.gradient={{{{1,0,0}},{{0,2,0}},{{0,0,3}}}};
    Near(KineticEnergy(cube,affine,12),38.5L,"affine physical energy");
    const auto divergence=DivergenceMoments(cube,affine,{.5L,.5L,.5L});
    Near(divergence[0],6,"affine divergence integral");
    for(unsigned i=1;i<4;++i) Near(divergence[i],0,"centered divergence moments");

    const auto gram=PolynomialGram(cube,{.5L,.5L,.5L},1,12);
    for(unsigned i=0;i<12;++i) {
        for(unsigned j=0;j<12;++j) {
            const Real expected=i==j?(i%4==0?12:1):0;
            Near(gram[i][j],expected,"independent affine mass patch matrix");
        }
    }

    // Negative control: treating rigid angular velocity as uniform translation
    // has the wrong energy even if all face equations were solved exactly.
    auto missingRotation=rigid;
    missingRotation.gradient={};
    Require(std::abs(KineticEnergy(cube,missingRotation,12)-50)>1,
            "mass oracle must reject absent rotational kinetic energy");
}

void ActualFaceTrace() {
    const auto face=MakeTriangle({Vec{0,0,1},Vec{1,0,1},Vec{0,1,1}});
    AffineVelocity field;
    field.value={.2L,-.1L,.3L};
    field.gradient={{{{.1L,.2L,-.1L}},{{.3L,-.2L,.4L}},{{.7L,-.5L,.6L}}}};
    const Vec origin{1.L/3,1.L/3,1};
    const Vec u{1,0,0},v{0,1,0};
    const auto expected=FaceFluxMoments(face,field,origin,u,v);
    std::array<Real,3> normal;
    for(unsigned i=0;i<3;++i) normal[i]=Dot(face.normal,field.At(face.vertices[i]));
    const auto actual=FaceFluxFromVertexTrace(face,normal,origin,u,v);
    for(unsigned i=0;i<3;++i) Near(actual[i],expected[i],"actual P1 face flux");

    const FaceBasis basis{{{{1,0,0,0}},{{-1.L/3,1,0,0}},{{-1.L/3,0,1,0}}}};
    const auto general=FaceMomentsInBasis(face,field,basis);
    const auto sampled=VertexTraceMomentsInBasis(face,normal,basis);
    for(unsigned i=0;i<3;++i) {
        Near(general[i],expected[i],"general affine face test basis");
        Near(sampled[i],expected[i],"general actual P1 boundary trace");
    }

    const auto rigid=RigidVelocity({1,2,-1},{2,-1,3},{.5L,.5L,.5L});
    const auto dofs=AffineDOFs(CubeMoments(),{face},{basis},rigid);
    Require(dofs.size()==9,"face3 plus interior mean3 angular3 layout");
    Near(Vec{dofs[3],dofs[4],dofs[5]},{1,2,-1},"unweighted integral velocity DOFs");
    Near(Vec{dofs[6],dofs[7],dofs[8]},{-7.L/6,5.L/6,1},
         "unweighted integral angular DOFs use common origin");

    // Negative control: a constant cell-average trace preserves the net flux
    // but loses both first moments. Net-only comparisons must not pass it.
    const Real average=(normal[0]+normal[1]+normal[2])/3;
    const auto wrong=FaceFluxFromVertexTrace(face,{average,average,average},origin,u,v);
    Near(wrong[0],expected[0],"constant wrong trace has identical net flux");
    Require(std::abs(wrong[1]-expected[1])>1e-3L,
            "first-moment test detects absent varying normal trace");
    Require(std::abs(wrong[2]-expected[2])>1e-3L,
            "second first-moment test detects absent varying normal trace");
}

void HydrostaticWrench() {
    const std::array<Vec,8> p{{{0,0,0},{1,0,0},{0,1,0},{1,1,0},
                             {0,0,1},{1,0,1},{0,1,1},{1,1,1}}};
    // Outward-solid winding, reversed below to obtain outward-fluid normals.
    const std::array<std::array<unsigned,3>,12> faces{{
        {{0,4,6}},{{0,6,2}},{{1,3,7}},{{1,7,5}},
        {{0,1,5}},{{0,5,4}},{{2,6,7}},{{2,7,3}},
        {{0,2,3}},{{0,3,1}},{{4,5,7}},{{4,7,6}}}};
    const Vec gravity{1.25L,-9.81L,.375L};
    const Vec torqueCenter{.25L,-.125L,0};
    const Real density=7;
    Wrench total;
    for(const auto& f:faces) {
        const auto triangle=MakeTriangle({p[f[0]],p[f[2]],p[f[1]]});
        total.Add(PressureWrench(triangle,100,density*gravity,{},torqueCenter));
    }
    const auto analytic=AnalyticBuoyancy(CubeMoments(),density,gravity,torqueCenter);
    Near(total.force,analytic.force,"hydrostatic displacement force");
    Near(total.torque,analytic.torque,"hydrostatic displacement torque");
    Require(Norm(total.torque)>1,"hydrostatic torque control is not centered");

    // A zero wrench or linear-only reaction must be distinguishable from a
    // correctly solved, zero endpoint-velocity supported-body case.
    Require(Norm(total.force)>1 && Norm(total.torque)>1,
            "supported endpoint is insufficient without nonzero wrench");
}
} // namespace

int main() {
    try {
        MassAndMomentum();
        ActualFaceTrace();
        HydrostaticWrench();
        std::printf("POLYNOMIAL_ORACLES checks=%u failures=0 negative_controls=4\n",checks);
        return 0;
    } catch(const std::exception& e) {
        std::fprintf(stderr,"POLYNOMIAL_ORACLES checks=%u failure=%s\n",checks,e.what());
        return 1;
    }
}
