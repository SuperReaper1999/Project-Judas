#pragma once

// Independent analytic polynomial integration for the Stage16 candidates.
// No pressure/velocity reconstruction or candidate assembly is imported here.
// All coordinates should be in the same bounded local frame. These moments are
// reference arithmetic, not a robust orientation or clipped-geometry predicate.

#include <array>
#include <cmath>
#include <stdexcept>
#include <vector>

namespace fluid_acceptance {

using Real = long double;

struct Vec {
    Real x = 0, y = 0, z = 0;
    Real& operator[](unsigned i) { return i == 0 ? x : (i == 1 ? y : z); }
    Real operator[](unsigned i) const { return i == 0 ? x : (i == 1 ? y : z); }
};

inline Vec operator+(Vec a, Vec b) { return {a.x+b.x, a.y+b.y, a.z+b.z}; }
inline Vec operator-(Vec a, Vec b) { return {a.x-b.x, a.y-b.y, a.z-b.z}; }
inline Vec operator*(Vec a, Real b) { return {a.x*b, a.y*b, a.z*b}; }
inline Vec operator*(Real b, Vec a) { return a*b; }
inline Vec operator/(Vec a, Real b) { return a*(1/b); }
inline Real Dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline Vec Cross(Vec a, Vec b) {
    return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x};
}
inline Real Norm(Vec a) { return std::sqrt(Dot(a,a)); }

using Matrix = std::array<std::array<Real,3>,3>;

inline Vec Multiply(const Matrix& a, Vec x) {
    Vec result;
    for (unsigned i=0; i<3; ++i)
        for (unsigned j=0; j<3; ++j)
            result[i] += a[i][j]*x[j];
    return result;
}

struct Moments {
    Real measure = 0;
    Vec first;
    Matrix second{}; // integral x_i*x_j, NOT covariance

    void Add(const Moments& b) {
        measure += b.measure;
        first = first+b.first;
        for (unsigned i=0; i<3; ++i)
            for (unsigned j=0; j<3; ++j)
                second[i][j] += b.second[i][j];
    }
};

// Integral of x and xx^T over a uniformly weighted d-simplex. The barycentric
// identities are E[lambda_i]=1/(d+1) and E[lambda_i lambda_j]
// =(1+delta_ij)/((d+1)(d+2)). This is independent of candidate face quadrature.
template <unsigned N>
inline Moments SimplexMoments(const std::array<Vec,N>& vertices, Real measure) {
    if (!(measure > 0) || !std::isfinite(measure))
        throw std::runtime_error("nonpositive/nonfinite analytic simplex measure");
    Moments result;
    result.measure = measure;
    Vec sum;
    for (Vec v: vertices) sum = sum+v;
    result.first = sum*(measure/N);
    for (unsigned i=0; i<3; ++i) {
        for (unsigned j=0; j<3; ++j) {
            Real value = sum[i]*sum[j];
            for (Vec v: vertices) value += v[i]*v[j];
            result.second[i][j] = value*measure/(N*(N+1));
        }
    }
    return result;
}

inline Moments TetraMoments(const std::array<Vec,4>& v) {
    const Real volume = std::abs(Dot(v[1]-v[0],Cross(v[2]-v[0],v[3]-v[0])))/6;
    return SimplexMoments<4>(v,volume);
}

struct Triangle {
    std::array<Vec,3> vertices;
    Vec normal; // oriented unit normal: vertex winding defines its sign
    Moments moments;
};

inline Triangle MakeTriangle(const std::array<Vec,3>& vertices) {
    const Vec areaNormal = Cross(vertices[1]-vertices[0],vertices[2]-vertices[0])/2;
    const Real area = Norm(areaNormal);
    if (!(area>0)) throw std::runtime_error("degenerate analytic triangle");
    return {vertices,areaNormal/area,SimplexMoments<3>(vertices,area)};
}

inline Moments Shift(const Moments& m, Vec origin) {
    Moments out = m;
    out.first = m.first-origin*m.measure;
    for (unsigned i=0; i<3; ++i)
        for (unsigned j=0; j<3; ++j)
            out.second[i][j] = m.second[i][j]-origin[i]*m.first[j]
                -m.first[i]*origin[j]+origin[i]*origin[j]*m.measure;
    return out;
}

struct AffineVelocity {
    Vec origin;
    Vec value;       // velocity at origin
    Matrix gradient{}; // derivative gradient[i][j] = partial_j velocity_i
    Vec At(Vec x) const { return value+Multiply(gradient,x-origin); }
    Real Divergence() const {
        return gradient[0][0]+gradient[1][1]+gradient[2][2];
    }
};

inline AffineVelocity RigidVelocity(Vec linear, Vec angular, Vec center) {
    Matrix gradient{{{{0,-angular.z,angular.y}},
                     {{angular.z,0,-angular.x}},
                     {{-angular.y,angular.x,0}}}};
    return {center,linear,gradient};
}

inline Vec VelocityIntegral(const Moments& m, const AffineVelocity& v) {
    return v.value*m.measure+Multiply(v.gradient,m.first-v.origin*m.measure);
}

inline Real KineticInnerProduct(const Moments& m, const AffineVelocity& a,
                               const AffineVelocity& b, Real density=1) {
    const Moments local = Shift(m,a.origin);
    const Vec bv = b.At(a.origin);
    Real value = Dot(a.value,bv)*m.measure;
    value += Dot(a.value,Multiply(b.gradient,local.first));
    value += Dot(bv,Multiply(a.gradient,local.first));
    for (unsigned i=0; i<3; ++i)
        for (unsigned j=0; j<3; ++j)
            for (unsigned k=0; k<3; ++k)
                value += a.gradient[i][j]*b.gradient[i][k]*local.second[j][k];
    return density*value;
}

inline Real KineticEnergy(const Moments& m, const AffineVelocity& v, Real density=1) {
    return KineticInnerProduct(m,v,v,density)/2;
}

// Cartesian [P1]^3 ordering: [vx:1,x,y,z; vy:1,x,y,z; vz:1,x,y,z],
// with the three coordinates measured from origin and divided by scale.
inline AffineVelocity PolynomialBasis(unsigned index, Vec origin={}, Real scale=1) {
    if (index>=12 || !(scale>0)) throw std::runtime_error("invalid polynomial basis");
    AffineVelocity v;
    v.origin = origin;
    const unsigned component=index/4, monomial=index%4;
    if (monomial==0) v.value[component]=1;
    else v.gradient[component][monomial-1]=1/scale;
    return v;
}

using PolynomialGramMatrix = std::array<std::array<Real,12>,12>;
inline PolynomialGramMatrix PolynomialGram(const Moments& m, Vec origin={},
                                           Real scale=1, Real density=1) {
    PolynomialGramMatrix gram{};
    for (unsigned i=0; i<12; ++i)
        for (unsigned j=0; j<12; ++j)
            gram[i][j]=KineticInnerProduct(m,PolynomialBasis(i,origin,scale),
                                           PolynomialBasis(j,origin,scale),density);
    return gram;
}

inline std::array<Real,4> DivergenceMoments(const Moments& m,
                                           const AffineVelocity& v,
                                           Vec origin={}, Real scale=1) {
    if (!(scale>0)) throw std::runtime_error("invalid divergence coordinate scale");
    const Moments local=Shift(m,origin);
    const Real div=v.Divergence();
    return {div*m.measure,div*local.first.x/scale,
            div*local.first.y/scale,div*local.first.z/scale};
}

inline Vec AngularMomentum(const Moments& m, const AffineVelocity& v,
                           Vec center, Real density=1) {
    const Moments local = Shift(m,center);
    const Vec atCenter = v.At(center);
    Vec result = Cross(local.first,atCenter);
    // integral r cross (G*r), evaluated by columns; no VEM mass reused.
    for (unsigned j=0; j<3; ++j) {
        Vec mixed{local.second[0][j],local.second[1][j],local.second[2][j]};
        Vec column{v.gradient[0][j],v.gradient[1][j],v.gradient[2][j]};
        result = result+Cross(mixed,column);
    }
    return result*density;
}

// Integrals (normal speed)*[1, dot(x-origin,tangentU)/scale,
// dot(x-origin,tangentV)/scale]. Tangents need not be normalized, but callers
// must use the same declared basis when comparing candidate face DOFs.
inline std::array<Real,3> FaceFluxMoments(const Triangle& face,
                                         const AffineVelocity& velocity,
                                         Vec origin, Vec tangentU, Vec tangentV,
                                         Real scale=1) {
    if (!(scale>0)) throw std::runtime_error("invalid face coordinate scale");
    const Moments local = Shift(face.moments,origin);
    const Real constant = Dot(face.normal,velocity.At(origin));
    Vec gradient;
    for (unsigned j=0; j<3; ++j)
        for (unsigned i=0; i<3; ++i)
            gradient[j] += face.normal[i]*velocity.gradient[i][j];
    auto firstMoment = [&](Vec tangent) {
        return (constant*Dot(tangent,local.first)
                +Dot(tangent,Multiply(local.second,gradient)))/scale;
    };
    return {constant*face.moments.measure+Dot(gradient,local.first),
            firstMoment(tangentU),firstMoment(tangentV)};
}

// Independent barycentric integration of a P1 ACTUAL normal trace. Supply the
// three normal speeds returned by the candidate's physical boundary evaluator,
// not an overwritten display field or its already-integrated primary DOFs.
inline std::array<Real,3> FaceFluxFromVertexTrace(const Triangle& face,
                                                std::array<Real,3> speed,
                                                Vec origin, Vec tangentU,
                                                Vec tangentV, Real scale=1) {
    if (!(scale>0)) throw std::runtime_error("invalid face coordinate scale");
    const Real sum = speed[0]+speed[1]+speed[2];
    auto firstMoment = [&](Vec tangent) {
        Real coordinateSum = 0, diagonal = 0;
        for (unsigned i=0; i<3; ++i) {
            const Real q = Dot(face.vertices[i]-origin,tangent)/scale;
            coordinateSum += q;
            diagonal += q*speed[i];
        }
        return face.moments.measure*(sum*coordinateSum+diagonal)/12;
    };
    return {face.moments.measure*sum/3,firstMoment(tangentU),firstMoment(tangentV)};
}

using FaceBasis = std::array<std::array<Real,4>,3>; // coefficients in [1,x,y,z]

inline Real Evaluate(const std::array<Real,4>& polynomial, Vec x) {
    return polynomial[0]+polynomial[1]*x.x+polynomial[2]*x.y+polynomial[3]*x.z;
}

inline std::array<Real,3> FaceMomentsInBasis(const Triangle& face,
                                           const AffineVelocity& field,
                                           const FaceBasis& basis) {
    const Real constant=Dot(face.normal,field.At({}));
    Vec gradient;
    for(unsigned j=0;j<3;++j)
        for(unsigned i=0;i<3;++i)
            gradient[j]+=face.normal[i]*field.gradient[i][j];
    std::array<Real,3> result{};
    for(unsigned row=0;row<3;++row) {
        const Vec b{basis[row][1],basis[row][2],basis[row][3]};
        result[row]=basis[row][0]*(constant*face.moments.measure
                     +Dot(gradient,face.moments.first))
            +constant*Dot(b,face.moments.first)
            +Dot(b,Multiply(face.moments.second,gradient));
    }
    return result;
}

inline std::array<Real,3> VertexTraceMomentsInBasis(const Triangle& face,
                                                   std::array<Real,3> normalSpeed,
                                                   const FaceBasis& basis) {
    std::array<Real,3> result{};
    const Real speedSum=normalSpeed[0]+normalSpeed[1]+normalSpeed[2];
    for(unsigned row=0;row<3;++row) {
        Real testSum=0,diagonal=0;
        for(unsigned corner=0;corner<3;++corner) {
            const Real test=Evaluate(basis[row],face.vertices[corner]);
            testSum+=test;
            diagonal+=normalSpeed[corner]*test;
        }
        result[row]=face.moments.measure*(speedSum*testSum+diagonal)/12;
    }
    return result;
}

// Independent VEM-style DOF oracle: three outward normal moments per actual
// triangle, followed by integral v and integral x cross v. Coordinates, velocity
// origin and polynomial face coefficients must use ONE common cell-local frame.
inline std::vector<Real> AffineDOFs(const Moments& volume,
                                    const std::vector<Triangle>& faces,
                                    const std::vector<FaceBasis>& bases,
                                    const AffineVelocity& velocity) {
    if(faces.size()!=bases.size()) throw std::runtime_error("face/basis count mismatch");
    std::vector<Real> dofs;
    dofs.reserve(faces.size()*3+6);
    for(unsigned i=0;i<faces.size();++i) {
        const auto face=FaceMomentsInBasis(faces[i],velocity,bases[i]);
        dofs.insert(dofs.end(),face.begin(),face.end());
    }
    const Vec mean=VelocityIntegral(volume,velocity);
    const Vec angular=AngularMomentum(volume,velocity,{});
    for(unsigned i=0;i<3;++i) dofs.push_back(mean[i]);
    for(unsigned i=0;i<3;++i) dofs.push_back(angular[i]);
    return dofs;
}

struct Wrench {
    Vec force, torque;
    void Add(const Wrench& b) { force=force+b.force; torque=torque+b.torque; }
};

// Pressure p(x)=pressureAtOrigin+gradient dot (x-pressureOrigin).
// The oriented face normal is the FLUID outward normal into the solid, so +p*n
// is force ON the solid. Reverse winding for an outward-solid surface mesh.
inline Wrench PressureWrench(const Triangle& face, Real pressureAtOrigin,
                             Vec gradient, Vec pressureOrigin, Vec torqueCenter) {
    const Moments local = Shift(face.moments,torqueCenter);
    const Real pCenter = pressureAtOrigin+Dot(gradient,torqueCenter-pressureOrigin);
    const Real integralPressure = pCenter*local.measure+Dot(gradient,local.first);
    const Vec pressureFirst = local.first*pCenter+Multiply(local.second,gradient);
    return {face.normal*integralPressure,Cross(pressureFirst,face.normal)};
}

inline Wrench AnalyticBuoyancy(const Moments& displacedSolid, Real density,
                               Vec gravity, Vec torqueCenter) {
    const Vec force = gravity*(-density*displacedSolid.measure);
    const Vec centroid = displacedSolid.first/displacedSolid.measure;
    return {force,Cross(centroid-torqueCenter,force)};
}

} // namespace fluid_acceptance
