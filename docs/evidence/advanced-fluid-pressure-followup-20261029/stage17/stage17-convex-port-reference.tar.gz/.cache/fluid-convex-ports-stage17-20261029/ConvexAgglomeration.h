#pragma once

// PRIVATE geometry-representation experiment. Merge only actual adjacent
// same-partition-region convex pieces when their exact union is convex and its
// dimensionless compactness improves the worse input piece. Volume, integration
// and every surviving physical patch remain exact. No face/quantity is pruned.
#include "VoxelPorts.h"

namespace convex_agglomeration {
using namespace convex_ports;
using Exact=R;

inline std::set<RV> Vertices(const Cell& cell) {
    std::set<RV> result;
    for(const auto& simplex:cell.integration)
        result.insert(simplex.points.begin(),simplex.points.end());
    return result;
}
inline R Compactness(const Cell& cell) {
    const auto points=Vertices(cell);
    R diameterSquared=0;
    for(auto a=points.begin();a!=points.end();++a)
        for(auto b=std::next(a);b!=points.end();++b) {
            const auto delta=Sub(*a,*b);
            diameterSquared=std::max(diameterSquared,owned_metrics::Dot(delta,delta));
        }
    if(cell.volume<=0||diameterSquared<=0)
        throw std::runtime_error("agglomeration shape lacks positive volume/diameter");
    // V²/D^6 is dimensionless, exact and independent of face subdivision.
    return cell.volume*cell.volume/(diameterSquared*diameterSquared*diameterSquared);
}
struct MergeReceipt {
    unsigned first=0,second=0;
    R worseBefore=0,after=0;
    unsigned removedPorts=0;
};
struct Compiler : convex_ports::Compiler {
    unsigned inputCells=0,candidatePairs=0,nonconvexRefusals=0,qualityRefusals=0;
    std::vector<MergeReceipt> merges;
    R inputVolume=0,outputVolume=0,minCompactnessBefore=0,minCompactnessAfter=0;
    // Diagnostic-only alternative. Default uses strict compactness improvement
    // and has no tuned velocity, impulse, cell-volume or timestep threshold.
    bool mergeAllConvexSameExclusion=false;
    bool sameFirstExclusionOnly=true;

    struct Node {Cell cell;std::set<unsigned> origins;bool active=true;};
    struct Owners {unsigned first=~0u,second=~0u;};
    static std::map<PortKey,Owners> PortOwners(const std::vector<Node>& nodes) {
        std::map<PortKey,Owners> result;
        for(unsigned node=0;node<nodes.size();++node) if(nodes[node].active)
            for(const auto& face:nodes[node].cell.faces) if(face.kind!=Kind::Solid) {
                auto& owner=result[face.key];
                if(owner.first==~0u)owner.first=node;
                else if(owner.second==~0u)owner.second=node;
                else throw std::runtime_error("agglomeration encountered a third port owner");
            }
        return result;
    }
    static bool TryUnion(const Node& a,const Node& b,const std::map<PortKey,Owners>& owners,
                         unsigned ai,unsigned bi,Cell& result,unsigned& removed) {
        result=Cell{};result.seed=std::min(a.cell.seed,b.cell.seed);result.piece=a.cell.piece;
        result.volume=a.cell.volume+b.cell.volume;
        result.integration=a.cell.integration;
        result.integration.insert(result.integration.end(),b.cell.integration.begin(),b.cell.integration.end());
        removed=0;
        for(const auto* input:{&a.cell,&b.cell}) for(const auto& face:input->faces) {
            bool paired=false;
            if(face.kind!=Kind::Solid) {
                const auto& pair=owners.at(face.key);
                paired=(pair.first==ai&&pair.second==bi)||(pair.first==bi&&pair.second==ai);
            }
            if(paired) {++removed;continue;}
            result.faces.push_back(face);
        }
        if(!removed||removed%2) throw std::runtime_error("agglomeration union lacks complete paired interface");
        removed/=2;
        const auto points=Vertices(result);
        // Every exact old integration vertex lies in every surviving outward
        // halfspace. Since both old cells are convex, this proves containment
        // of their entire union. A positive-area actual shared port supplies
        // connectivity; no gap, edge touch or dry region is filled.
        for(const auto& face:result.faces) for(const auto& triangle:face.triangles)
            for(const auto& point:points)
                if(owned_metrics::Dot(Sub(point,triangle.points[0]),triangle.areaVector)>0)
                    return false;
        RV area{};R volume=0;
        for(const auto& face:result.faces)for(const auto& triangle:face.triangles) {
            for(unsigned axis=0;axis<3;++axis)area[axis]+=triangle.areaVector[axis];
            volume+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
        }
        if(area!=RV{}||volume!=result.volume)
            throw std::runtime_error("agglomeration exact exterior volume/closure mismatch");
        auto low=*points.begin(),high=low;
        for(const auto& point:points)for(unsigned axis=0;axis<3;++axis) {
            low[axis]=std::min(low[axis],point[axis]);high[axis]=std::max(high[axis],point[axis]);
        }
        for(unsigned axis=0;axis<3;++axis)result.center[axis]=(low[axis]+high[axis])/2;
        return true;
    }

    void Build(const convex_ports::Compiler& source) {
        if(grid||!cells.empty())throw std::invalid_argument("agglomeration compiler already owns geometry");
        if(!source.grid||source.grid>8)throw std::invalid_argument("agglomeration source grid is invalid");
        grid=source.grid;box=source.box;inputCells=source.cells.size();
        std::vector<Node> nodes;
        std::vector<unsigned> seedParent(grid*grid*grid);std::iota(seedParent.begin(),seedParent.end(),0);
        const auto root=[&](unsigned seed){while(seedParent[seed]!=seed)seed=seedParent[seed];return seed;};
        bool first=true;
        for(const auto& cell:source.cells) {
            if(cell.seed>=grid*grid*grid)throw std::invalid_argument("agglomeration original voxel is invalid");
            nodes.push_back({cell,{cell.seed},true});inputVolume+=cell.volume;
            const R q=Compactness(cell);
            if(first||q<minCompactnessBefore)minCompactnessBefore=q;
            first=false;
        }
        while(true) {
            const auto owners=PortOwners(nodes);
            struct Candidate {unsigned a,b;PortKey key;R quality;};
            std::vector<Candidate> candidates;std::set<std::pair<unsigned,unsigned>> seen;
            for(const auto& [key,pair]:owners) {
                if(pair.second==~0u||pair.first==pair.second)continue;
                const unsigned a=std::min(pair.first,pair.second),b=std::max(pair.first,pair.second);
                if((sameFirstExclusionOnly&&nodes[a].cell.piece!=nodes[b].cell.piece)||
                   !seen.emplace(a,b).second)continue;
                candidates.push_back({a,b,key,std::min(Compactness(nodes[a].cell),Compactness(nodes[b].cell))});
            }
            std::sort(candidates.begin(),candidates.end(),[](const auto& a,const auto& b) {
                if(a.quality!=b.quality)return a.quality<b.quality;
                return a.key<b.key;
            });
            bool changed=false;
            for(const auto& candidate:candidates) {
                ++candidatePairs;Cell merged;unsigned removed=0;
                if(!TryUnion(nodes[candidate.a],nodes[candidate.b],owners,candidate.a,candidate.b,merged,removed)) {
                    ++nonconvexRefusals;continue;
                }
                const R after=Compactness(merged);
                if(!mergeAllConvexSameExclusion&&after<=candidate.quality) {++qualityRefusals;continue;}
                Node joined;joined.cell=std::move(merged);
                joined.origins=nodes[candidate.a].origins;
                joined.origins.insert(nodes[candidate.b].origins.begin(),nodes[candidate.b].origins.end());
                const unsigned base=*joined.origins.begin();
                for(unsigned origin:joined.origins)seedParent[root(origin)]=root(base);
                merges.push_back({candidate.a,candidate.b,candidate.quality,after,removed});
                nodes[candidate.a].active=nodes[candidate.b].active=false;
                nodes.push_back(std::move(joined));changed=true;break;
            }
            if(!changed)break;
        }
        first=true;
        for(auto& node:nodes)if(node.active) {
            node.cell.seed=root(*node.origins.begin());
            for(unsigned origin:node.origins)
                if(root(origin)!=node.cell.seed)throw std::runtime_error("agglomeration original-voxel DSU is inconsistent");
            const R quality=Compactness(node.cell);
            if(first||quality<minCompactnessAfter)minCompactnessAfter=quality;
            first=false;outputVolume+=node.cell.volume;cells.push_back(std::move(node.cell));
        }
        if(outputVolume!=inputVolume)throw std::runtime_error("agglomeration changes exact physical wet volume");
        // Propagate original-voxel ownership to EVERY untouched piece as well.
        for(auto& cell:cells)cell.seed=root(cell.seed);
        std::vector<Node> finalNodes;for(const auto& cell:cells)finalNodes.push_back({cell,{},true});
        const auto finalOwners=PortOwners(finalNodes);
        std::map<PortKey,PortKey> renamed;
        for(const auto& [key,pair]:finalOwners)if(pair.second!=~0u) {
            const unsigned a=cells[pair.first].seed,b=cells[pair.second].seed;
            if(a!=b)continue;
            if(key.kind==Kind::Background) {
                PortKey internal=key;internal.kind=Kind::Internal;internal.seed=a;
                // Keep the original square/exclusion identity, so no unrelated
                // actual aperture can alias this internalized numerical port.
                renamed.emplace(key,std::move(internal));
            }
        }
        for(auto& cell:cells)for(auto& face:cell.faces) {
            auto at=renamed.find(face.key);
            if(at!=renamed.end()) {face.kind=Kind::Internal;face.key=at->second;}
        }
    }
    void Build(unsigned count,const Box& definition) {
        voxel_ports::Compiler source;source.Build(count,definition);Build(source);
    }
};
} // namespace convex_agglomeration
