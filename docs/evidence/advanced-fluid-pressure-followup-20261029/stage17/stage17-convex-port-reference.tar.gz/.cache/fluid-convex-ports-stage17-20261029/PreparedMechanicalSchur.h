#pragma once
// Private exact algebra experiment. Eliminate the SAME prepared pressure KKT
// onto its six native rigid variables in one multiple-right-hand-side solve.
// No six separately reconstructed fake unit-motion fields, changed metric,
// fitted added mass, stale geometry reuse or extra native body mass.
#include "VoxelNetwork.h"
namespace stage17_mechanical {
using namespace stage17_network;
using Mat6=Eigen::Matrix<Real,6,6>;
struct Operator {
    const Network& epoch;
    const std::shared_ptr<Factor> generation;
    Matrix coupling;
    Mat6 addedMass=Mat6::Zero();
    Real residual=0,symmetryError=0;
    double preparationMs=0;
    explicit Operator(const Network& e):epoch(e),generation(e.factor) {
        Network::CheckRounding();
        const auto start=Clock::now();
        const auto& f=*epoch.factor;
        const unsigned nv=e.mass.rows(),np=f.retainedRows.size();
        coupling=Matrix::Zero(nv+np,6);
        coupling.topRows(nv)=f.velocityScale.asDiagonal()*e.mixedBody;
        for(unsigned i=0;i<np;++i)
            coupling.row(nv+i)=f.pressureScale[i]*e.bodyContinuity.row(f.retainedRows[i]);
        for(unsigned axis=0;axis<6;++axis){Twist unit=Twist::Zero();unit[axis]=1;e.CheckPrescribedFlux(unit);}
        Matrix response=Matrix::Zero(coupling.rows(),6);
        if(f.hasSystem) {
            response=f.solver.solve(coupling);
            if(f.solver.info()!=Eigen::Success || !response.allFinite())
                throw std::runtime_error("mechanical Schur pressure response failed");
        }
        residual=(f.saddle*response-coupling).norm()/std::max<Real>(1,coupling.norm());
        const Mat6 raw=e.bodyMass-coupling.transpose()*response;
        symmetryError=(raw-raw.transpose()).norm()/std::max<Real>(1,raw.norm());
        if(residual>1e-10L || symmetryError>1e-10L || !raw.allFinite())
            throw std::runtime_error("mechanical Schur lost the prepared pressure equations/work symmetry");
        addedMass=(raw+raw.transpose()).eval()/2;
        preparationMs=Milliseconds(start);
    }
    Twist Source(const std::vector<vm::Affine>& predictors) const {
        Network::CheckRounding();
        if(epoch.factor!=generation)
            throw std::invalid_argument("mechanical Schur belongs to a superseded geometry/factor epoch");
        if(predictors.size()!=epoch.cells.size())
            throw std::invalid_argument("mechanical Schur predictor count mismatch");
        const auto& f=*epoch.factor;
        const unsigned nv=epoch.mass.rows(),np=f.retainedRows.size();
        Vector load=Vector::Zero(nv);Twist bodyLoad=Twist::Zero();Real energy=0;
        for(unsigned c=0;c<epoch.cells.size();++c) {
            if(!predictors[c].allFinite())
                throw std::invalid_argument("mechanical Schur nonfinite predictor");
            const auto& local=*epoch.cells[c];const auto& map=epoch.maps[c];
            const auto source=local.condensed.SourceFromPredictor(local.op.InterpolateAffineDOFs(predictors[c]));
            energy+=source.predictorEnergyConstant;
            for(unsigned face=0;face<local.cell.faces.size();++face)
                if(map.column[face]>=0)
                    load.segment(map.column[face],3)+=map.sign[face]*source.faceLoad.segment(3*face,3);
            bodyLoad+=map.body.transpose()*source.faceLoad;
        }
        if(!std::isfinite(energy) || energy>std::numeric_limits<double>::max())
            throw std::invalid_argument("mechanical Schur predictor energy is not representable");
        Vector rhs=Vector::Zero(nv+np);rhs.head(nv)=f.velocityScale.asDiagonal()*load;
        Vector solution=Vector::Zero(rhs.size());
        if(f.hasSystem) {
            solution=f.solver.solve(rhs);
            if(f.solver.info()!=Eigen::Success || !solution.allFinite())
                throw std::runtime_error("mechanical Schur source pressure solve failed");
        }
        if((f.saddle*solution-rhs).norm()>1e-10L*std::max<Real>(1,rhs.norm()))
            throw std::runtime_error("mechanical Schur source lost its pressure residual");
        return bodyLoad-coupling.transpose()*solution;
    }
};
} // namespace stage17_mechanical
