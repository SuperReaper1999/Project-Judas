#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using namespace stage17_network;
unsigned checks=0;
void Check(bool condition,const char* what) {
    ++checks;
    if(!condition) throw std::runtime_error(what);
}
int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(double angle:{0.,3.2137858346770188e-11,.17}) {
            const auto box=owned_cut::BoxPlanes(V(.5),V(.2),
                glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
            convex_ports::Compiler geometry;
            geometry.Build(1,box);
            unsigned diagnosed=0;
            for(const auto& physical:geometry.cells) {
                try {
                    const auto metrics=BuildMetrics(physical,vg::R(1));
                    const auto local=vm::Build(metrics.geometry);
                    Check(local.polynomialReproductionError<1e-8L,
                          "thin convex-cell affine polynomial reproduction is inaccurate");
                    ++diagnosed;
                } catch(const std::exception& error) {
                    printf("TINY_LOCAL_FAILURE angle=%.17g seed=%u piece=%u volume=%Lg diagnosed=%u reason=%s\n",
                        angle,physical.seed,physical.piece,physical.volume.convert_to<Real>(),diagnosed,error.what());
                    throw;
                }
            }
            Epoch epoch(geometry);
            const auto hydro=epoch.Solve(epoch.Constant(vm::Vec3(0,-.04L,0)));
            Check(hydro.energy<1e-18L,"thin-angle calm source creates kinetic energy");
            const vm::Vec3 expected(0,2.56L,0),center(.5L,.5L,.5L);
            const Real force=(hydro.reaction.head<3>()-expected).norm();
            const Real torque=(hydro.reaction.tail<3>()-center.cross(expected)).norm();
            Check(force<1e-10L&&torque<1e-10L,"thin-angle buoyancy wrench fails");
            Twist body;
            body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
            const auto motion=epoch.Solve(epoch.Constant(vm::Vec3::Zero()),body);
            Check(motion.balance<1e-12L&&motion.stationarity<1e-12L,
                  "thin-angle pressure violates continuity/stationarity");
            Check(motion.energyIdentity<1e-12L,"thin-angle body/fluid work identity fails");
            for(unsigned owner=0;owner<epoch.cells.size();++owner) {
                const auto& local=*epoch.cells[owner];
                const Vector prescribed=epoch.maps[owner].body*body;
                for(unsigned face=0;face<local.cell.faces.size();++face)
                    if(local.cell.faces[face].kind==Kind::Solid)
                        Check((motion.local[owner].segment(3*face,3)-prescribed.segment(3*face,3)).norm()<1e-16L,
                              "thin-angle primary solid trace leaks");
            }
            printf("TINY_NETWORK angle=%.17g cells=%zu variables=%ld energy=%Lg force_error=%Lg torque_error=%Lg balance=%Lg stationarity=%Lg work=%Lg\n",
                angle,epoch.cells.size(),long(epoch.mass.rows()),motion.energy,force,torque,
                motion.balance,motion.stationarity,motion.energyIdentity);
        }
        printf("TINY_NETWORK_SUMMARY checks=%u failures=0\n",checks);
        return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());
        return 1;
    }
}
