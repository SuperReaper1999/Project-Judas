# Independent physical-contract checks (private Stage 17)

These are numerical acceptance probes for candidate representations. They do not
qualify a production runtime or authorize enabling Advanced Fluid Dynamics.
Stage 16 failures and the old Stage 17 tetra/sliver failures are preserved.

## Voxel physical work and covariance

Source: `VoxelPhysicalContracts.cpp`.
Reproduction: `python3 .cache/fluid-convex-ports-stage17-20261029/run_probe.py VoxelPhysicalContracts.cpp`.
Final-source log: `logs/voxel-physical-contracts-v3.log`.

Three prescribed poses (axis aligned, 0.17 rad oblique, and
3.2137858346770188e-11 rad) pass 97 assertions. These are assertions across
three fixtures, not 97 independent physical scenarios.

The probe independently integrates solid/wall rigid virtual velocities against
actual published face triangles. For translation, the derivative of a face
moment is the oriented area vector times its basis integral. For rotation, it is
`integral psi * (x cross n) dA`. The body plus wall impulse must equal the
fluid linear/angular momentum change, measured from actual state DOFs. Omitting
wall reaction is a negative control: an internally consistent body-only wrench
is not sufficient. Actual body-source work is also compared with finite
differences in all six rigid components.

Observed maxima:

- Linear/angular impulse-balance scaled error: 8.89e-18.
- Moving-body balance error: 4.20e-18.
- Independent finite-difference work error: 1.25e-16.
- Reversing cell/face ordering changes energy at most 1.36e-20 and wrench at
  most 1.69e-18.
- A vortical source retains 0.434--0.437 of predictor kinetic energy; it is not
  silently zeroed. Invalid source rejection does not mutate a later valid solve.

The original first-exclusion voxel partition has a real coarse directional
bias. Added-mass diagonal is (299.354, 216.549, 117.595) kg in the axis-aligned
fixture; relative axis spread is 0.443. Rotational spread is 0.162. Coordinate
cycling with matching body-plane permutation remains covariant. Thus coordinate
covariance is verified, while isotropy/continuum accuracy is not claimed.

`logs/voxel-physical-contracts-v2.log` preserves a failed run: the old floating
closed-volume compatibility check rejected the oblique pose after 62 checks.
The final guard instead integrates exact rational rigid solid flux and checks
closed-component incidence exactly. No acceptance tolerance was enlarged.

## Exact physical geometry

`VoxelPortGeometryTests.cpp` has passed 50,265 assertions on nine fixtures,
including actual apertures, first and second volume moments, disconnected
regions and a missing-face negative control. The independent reference sums
six frozen exact tetrahedral seeds per original voxel. Three-corner square
identifiers are never treated as triangle apertures: an uncut full square has
area 1 while that identifier triangle has area 1/2.

`SymmetricVoxelPortGeometryTests.cpp` is a separate source adaptation for the
new maximum-native-halfspace partition. It additionally verifies the exact
inequalities `f_i >= 0` and `f_i >= f_j`, the difference-plane internal ports,
and canonical maximum/tie labels of physical background patches. It retains
all original nine fixtures and adds the true native voxel-corner tiny-angle
fixture (grid 2, body center .75, half extent .25). It passed 136,907 assertions across ten fixtures and 187 paired ports; see
`logs/symmetric-voxel-port-geometry-v1.log`. This verifies the physical domain,
not pressure conditioning at the true corner. The symmetric interior pieces
have minimum volume .156 (axis/tiny) and .154888 (oblique), for identical total
water volume .936.

The geometry probe compares actual apertures using rational 2D polygon
intersection and symmetric difference. Matching areas or P2 moments alone are
not accepted as aperture identity. Hydraulic components are built from actual
positive-area paired ports and compared with independent fine-domain component
moment signatures. No small cell, face or volume is dropped to obtain a pass.
