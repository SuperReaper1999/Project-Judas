#pragma once

// Isolated matrix-free Schur/PCG alternative for the SAME exactly condensed model.
// No baseline header is modified and no pressure or physical equation is dropped.
// Exact subdomain elimination for the SAME Stage17 convex-cell kinetic model.
// Only artificial INTERNAL port velocities and redundant local pressure rows
// are eliminated. Physical cells, sources, normal traces and their pressure
// constraints are reconstructed; no convex pieces are merged or retuned.
#include "LocalCondensedNetwork.h"

namespace stage17_krylov {
using namespace stage17_network;

using PieceMap=stage17_condensed::PieceMap;
using SubdomainSource=stage17_condensed::SubdomainSource;
using Subdomain=stage17_condensed::Subdomain;

enum class Preconditioner { Diagonal, PortBlock3 };

struct PressureSolution {
    Vector pressure;
    unsigned iterations=0,applications=0,restarts=0;
    Real relativeResidual=0;
    double solveMs=0;
};
struct Factor {
    Vector velocityScale,pressureScale;
    std::vector<unsigned> retainedRows;
    std::vector<int> pressureIndex;
    Sparse scaledMass,scaledContinuity,preconditioner;
    Eigen::SimplicialLDLT<Sparse> kinetic,pressurePreconditioner;
    bool hasKinetic=false,hasPressure=false;
    double kineticMs=0,preconditionerMs=0;

    Vector ApplySchur(const Vector& input) const {
        if(input.size()!=scaledContinuity.rows())
            throw std::invalid_argument("Stage17 Schur vector dimension mismatch");
        if(!input.size()) return Vector(0);
        const Vector result=scaledContinuity*kinetic.solve(scaledContinuity.transpose()*input);
        if(kinetic.info()!=Eigen::Success||!result.allFinite())
            throw std::runtime_error("Stage17 matrix-free Schur application failed");
        return result;
    }
    PressureSolution SolvePressure(const Vector& rhs) const {
        const auto start=Clock::now();
        if(rhs.size()!=scaledContinuity.rows()||!rhs.allFinite())
            throw std::invalid_argument("Stage17 pressure source is invalid");
        PressureSolution result;
        result.pressure=Vector::Zero(rhs.size());
        const Real norm=rhs.norm();
        if(norm==0) {result.solveMs=Milliseconds(start);return result;}
        // This is an internal solver tolerance, stricter than the unchanged
        // physical acceptance gates. Never accept only a recurrence residual.
        constexpr Real relativeTolerance=1e-15L;
        const Real target=relativeTolerance*norm;
        Vector residual=rhs;
        Vector preconditioned=pressurePreconditioner.solve(residual);
        if(pressurePreconditioner.info()!=Eigen::Success||!preconditioned.allFinite())
            throw std::runtime_error("Stage17 pressure preconditioner solve failed");
        Real product=residual.dot(preconditioned);
        if(!(product>0)||!std::isfinite(product))
            throw std::runtime_error("Stage17 pressure preconditioner has nonpositive curvature");
        Vector direction=preconditioned;
        const unsigned budget=2*unsigned(rhs.size());
        for(unsigned iteration=0;iteration<budget;++iteration) {
            const Vector response=ApplySchur(direction);++result.applications;
            const Real curvature=direction.dot(response);
            if(!(curvature>0)||!std::isfinite(curvature))
                throw std::runtime_error("Stage17 Schur operator has nonpositive curvature");
            const Real alpha=product/curvature;
            result.pressure+=alpha*direction;
            residual-=alpha*response;
            result.iterations=iteration+1;
            if(!result.pressure.allFinite()||!residual.allFinite())
                throw std::runtime_error("Stage17 pressure iteration became nonfinite");
            bool restart=false;
            if(residual.norm()<=target||iteration+1==budget) {
                residual=rhs-ApplySchur(result.pressure);++result.applications;
                result.relativeResidual=residual.norm()/norm;
                if(residual.norm()<=target) {
                    result.solveMs=Milliseconds(start);return result;
                }
                // Recurrence drift cannot manufacture convergence. Restart
                // within the SAME bounded iteration budget using true residual.
                restart=true;++result.restarts;
            }
            preconditioned=pressurePreconditioner.solve(residual);
            if(pressurePreconditioner.info()!=Eigen::Success||!preconditioned.allFinite())
                throw std::runtime_error("Stage17 pressure preconditioner iteration failed");
            const Real next=residual.dot(preconditioned);
            if(!(next>0)||!std::isfinite(next))
                throw std::runtime_error("Stage17 pressure iteration has nonpositive preconditioned residual");
            if(restart) direction=preconditioned;
            else direction=preconditioned+(next/product)*direction;
            product=next;
        }
        throw std::runtime_error("Stage17 matrix-free pressure exceeded 2*np budget with true residual="+
                                 std::to_string(double(result.relativeResidual)));
    }
};

using SubdomainMap=stage17_condensed::SubdomainMap;

struct Result : stage17_network::Result {
    Real localEquationResidual=0,reactionReconstructionError=0,objectiveReconstructionError=0;
    unsigned pressureIterations=0,pressureApplications=0,pressureRestarts=0;
    Real pressureRelativeResidual=0;
    double pressureSolveMs=0;
};

struct LocalCondensedNetwork {
    unsigned grid=0;
    Box box;
    vg::R physicalScale=1;
    Boundary boundary=Boundary::Sealed;
    Preconditioner preconditioner=Preconditioner::Diagonal;
    std::vector<std::shared_ptr<const Local>> cells;
    std::map<PortKey,FaceOwners> allPorts,interfaces;
    std::vector<Subdomain> subdomains;
    std::vector<unsigned> cellSubdomain;
    std::vector<SubdomainMap> maps;
    std::vector<std::vector<unsigned>> components;
    std::vector<bool> componentOpen;
    Sparse mass,continuity;
    Matrix bodyContinuity,mixedBody,bodyMass;
    std::shared_ptr<Factor> factor;
    unsigned integrationSimplexes=0,maxLocalDofs=0,maxLocalKkt=0;
    double geometryMs=0,localMs=0,assemblyMs=0,factorMs=0,condensationMs=0;

    LocalCondensedNetwork(unsigned count,const Box& planes,const vg::R& scale=1,
                          Boundary condition=Boundary::Sealed)
        :grid(count),box(planes),physicalScale(scale),boundary(condition) {
        Network::CheckRounding();
        if(!grid||grid>4||scale<=0) throw std::invalid_argument("Stage17 local-condensed domain is invalid");
        const auto start=Clock::now();
        convex_ports::Compiler geometry;
        geometry.Build(grid,box);
        geometryMs=Milliseconds(start);
        for(const auto& physical:geometry.cells) {
            const auto metricStart=Clock::now();
            auto metrics=BuildMetrics(physical,physicalScale);
            geometryMs+=Milliseconds(metricStart);
            const auto localStart=Clock::now();
            cells.push_back(std::make_shared<Local>(std::move(metrics)));
            localMs+=Milliseconds(localStart);
        }
        Assemble();
    }
    explicit LocalCondensedNetwork(const Network& reference)
        :grid(reference.grid),box(reference.box),physicalScale(reference.physicalScale),
         boundary(reference.boundary),cells(reference.cells) {
        Network::CheckRounding();
        Assemble();
    }
    explicit LocalCondensedNetwork(const stage17_condensed::LocalCondensedNetwork& reference,
                                   Preconditioner policy=Preconditioner::Diagonal)
        :grid(reference.grid),box(reference.box),physicalScale(reference.physicalScale),
         boundary(reference.boundary),cells(reference.cells),allPorts(reference.allPorts),
         interfaces(reference.interfaces),subdomains(reference.subdomains),
         cellSubdomain(reference.cellSubdomain),maps(reference.maps),
         mass(reference.mass),continuity(reference.continuity),
         bodyContinuity(reference.bodyContinuity),mixedBody(reference.mixedBody),
         bodyMass(reference.bodyMass),integrationSimplexes(reference.integrationSimplexes),
         maxLocalDofs(reference.maxLocalDofs),maxLocalKkt(reference.maxLocalKkt) {
        preconditioner=policy;
        Network::CheckRounding();
        // Reuse/copy the exact already-qualified local operators so the paired
        // test isolates only global factorization and solve policy.
        BuildFactor();
    }
    bool Outer(const PortKey& key) const {
        if(key.kind!=Kind::Background) return false;
        for(unsigned axis=0;axis<3;++axis) {
            bool low=true,high=true;
            for(const auto& point:key.background) {
                low=low&&(point[axis]==0);
                high=high&&(point[axis]==int(grid));
            }
            if(low||high) return true;
        }
        return false;
    }
    bool Open(const PortKey& key) const {
        if(boundary!=Boundary::OpenTop||key.kind!=Kind::Background) return false;
        for(const auto& point:key.background) if(point[1]!=int(grid)) return false;
        return true;
    }
    bool Unknown(const PhysicalFace& face) const {
        return face.kind!=Kind::Solid&&(!Outer(face.key)||Open(face.key));
    }

    void Discover() {
        allPorts.clear();interfaces.clear();subdomains.clear();maps.clear();
        integrationSimplexes=maxLocalDofs=maxLocalKkt=0;
        for(unsigned owner=0;owner<cells.size();++owner) {
            const auto& local=*cells[owner];
            integrationSimplexes+=local.cell.integrationSimplexes;
            maxLocalDofs=std::max(maxLocalDofs,local.op.dimension);
            for(unsigned face=0;face<local.cell.faces.size();++face) {
                const auto& patch=local.cell.faces[face];
                if(!Unknown(patch)) continue;
                auto [at,inserted]=allPorts.emplace(patch.key,FaceOwners{owner,face});
                if(!inserted) {
                    if(at->second.secondCell!=~0u) throw std::runtime_error("Stage17 local port has three owners");
                    at->second.secondCell=owner;at->second.secondFace=face;
                }
            }
        }
        for(const auto& [key,port]:allPorts) {
            if(port.secondCell==~0u) {
                if(!Open(key)) throw std::runtime_error("Stage17 local port lacks its opposite owner");
            } else {
                const auto& a=*cells[port.firstCell];const auto& b=*cells[port.secondCell];
                if(!SameFrame(a.cell.faces[port.firstFace],b.cell.faces[port.secondFace])||
                   (a.op.geometry.faces[port.firstFace].normal+b.op.geometry.faces[port.secondFace].normal).norm()>1e-15L)
                    throw std::runtime_error("Stage17 local opposite-port geometry differs");
            }
            if(key.kind==Kind::Background) interfaces.emplace(key,port);
        }
        unsigned next=0;for(auto& [key,port]:interfaces) port.id=next++;
        std::vector<unsigned> parent(cells.size());std::iota(parent.begin(),parent.end(),0);
        const auto root=[&](unsigned cell){while(parent[cell]!=cell) cell=parent[cell];return cell;};
        for(const auto& [key,port]:allPorts) if(key.kind==Kind::Internal) {
            if(port.secondCell==~0u||cells[port.firstCell]->cell.seed!=cells[port.secondCell]->cell.seed)
                throw std::runtime_error("Stage17 internal port escapes its original seed");
            parent[root(port.secondCell)]=root(port.firstCell);
        }
        cellSubdomain.resize(cells.size());std::map<unsigned,unsigned> groups;
        for(unsigned cell=0;cell<cells.size();++cell) {
            auto [at,inserted]=groups.emplace(root(cell),subdomains.size());
            if(inserted) {subdomains.emplace_back();subdomains.back().seed=cells[cell]->cell.seed;}
            cellSubdomain[cell]=at->second;
            subdomains[at->second].cells.push_back(cell);
        }
    }

    void BuildSubdomain(unsigned group) {
        auto& domain=subdomains[group];
        std::map<PortKey,unsigned> internal,boundaryPorts;
        for(unsigned cell:domain.cells) for(const auto& face:cells[cell]->cell.faces) {
            if(!Unknown(face)) continue;
            if(face.kind==Kind::Internal) internal.emplace(face.key,0);
            else boundaryPorts.emplace(face.key,0);
        }
        unsigned next=0;
        for(auto& [key,index]:internal) {index=next++;domain.internalKeys.push_back(key);}
        next=0;
        for(auto& [key,index]:boundaryPorts) {index=next++;domain.boundaryKeys.push_back(key);}
        const unsigned ni=3*internal.size(),nz=3*boundaryPorts.size()+6;
        domain.internalVariables=ni;
        Matrix hii=Matrix::Zero(ni,ni),hiz=Matrix::Zero(ni,nz),hzz=Matrix::Zero(nz,nz);
        Matrix ci=Matrix::Zero(domain.cells.size(),ni),cz=Matrix::Zero(domain.cells.size(),nz);
        for(unsigned piece=0;piece<domain.cells.size();++piece) {
            const unsigned owner=domain.cells[piece];
            const auto& local=*cells[owner];const unsigned nf=local.cell.faces.size();
            PieceMap map;map.cell=owner;
            map.internal=Matrix::Zero(3*nf,ni);map.boundary=Matrix::Zero(3*nf,nz);
            vm::Vec3 center;
            for(unsigned axis=0;axis<3;++axis) center[axis]=local.cell.center[axis].convert_to<Real>();
            for(unsigned face=0;face<nf;++face) {
                const auto& patch=local.cell.faces[face];
                if(patch.kind==Kind::Solid) {
                    for(unsigned degree=0;degree<6;++degree) {
                        vm::Vec3 linear=vm::Vec3::Zero(),angular=vm::Vec3::Zero();
                        if(degree<3) linear[degree]=1;
                        else {angular[degree-3]=1;linear=angular.cross(center);}
                        map.boundary.block(3*face,nz-6+degree,3,1)=
                            (local.op.polynomialDofs*vm::RigidAffine(linear,angular)).segment(3*face,3);
                    }
                } else if(Unknown(patch)) {
                    if(patch.kind==Kind::Internal) {
                        const auto& port=allPorts.at(patch.key);
                        const Real sign=port.firstCell==owner?1:-1;
                        map.internal.block(3*face,3*internal.at(patch.key),3,3)=sign*vm::Mat3::Identity();
                    } else {
                        map.boundary.block(3*face,3*boundaryPorts.at(patch.key),3,3).setIdentity();
                    }
                }
            }
            const auto& h=local.condensed.faceMass;
            hii+=map.internal.transpose()*h*map.internal;
            hiz+=map.internal.transpose()*h*map.boundary;
            hzz+=map.boundary.transpose()*h*map.boundary;
            ci.row(piece)=local.condensed.closure*map.internal;
            cz.row(piece)=local.condensed.closure*map.boundary;
            domain.maps.push_back(std::move(map));
        }
        domain.internalMass=hii;
        domain.boundaryMass=hzz;
        domain.internalContinuity=ci;
        domain.boundaryContinuity=cz;
        domain.closure=cz.colwise().sum();
        // Internal face fluxes cancel identically. This is the exact remaining
        // macro constraint, not a weaker replacement for the individual rows.
        if(ci.cols() && ci.colwise().sum().cwiseAbs().maxCoeff()!=0)
            throw std::runtime_error("Stage17 local internal fluxes do not cancel");
        const unsigned constraints=domain.cells.size()?domain.cells.size()-1:0;
        for(unsigned piece=1;piece<domain.cells.size();++piece) domain.retainedPieces.push_back(piece);
        const unsigned n=ni+constraints;
        domain.scale=Vector::Ones(n);
        for(unsigned column=0;column<ni;++column) {
            if(!(hii(column,column)>0)) throw std::runtime_error("Stage17 local internal kinetic diagonal is nonpositive");
            domain.scale[column]=1/std::sqrt(hii(column,column));
        }
        for(unsigned row=0;row<constraints;++row) {
            const Real norm=(ci.row(row+1)*domain.scale.head(ni).asDiagonal()).norm();
            if(!(norm>0)) throw std::runtime_error("Stage17 local pressure row is disconnected");
            domain.scale[ni+row]=1/norm;
        }
        Matrix kkt=Matrix::Zero(n,n);
        kkt.topLeftCorner(ni,ni)=hii;
        domain.coupling=Matrix::Zero(n,nz);
        domain.coupling.topRows(ni)=hiz;
        for(unsigned row=0;row<constraints;++row) {
            kkt.block(ni+row,0,1,ni)=ci.row(row+1);
            kkt.block(0,ni+row,ni,1)=ci.row(row+1).transpose();
            domain.coupling.row(ni+row)=cz.row(row+1);
        }
        domain.scaledKkt=domain.scale.asDiagonal()*kkt*domain.scale.asDiagonal();
        if(n) {
            domain.factor.compute(domain.scaledKkt);
            if(domain.factor.rank()!=n) throw std::runtime_error("Stage17 local pressure/kinetic KKT is rank deficient");
        }
        domain.inverseCoupling=domain.InverseColumns(domain.coupling);
        domain.reducedMass=hzz-domain.coupling.transpose()*domain.inverseCoupling;
        domain.reducedMass=(domain.reducedMass+domain.reducedMass.transpose()).eval()/2;
        maxLocalKkt=std::max(maxLocalKkt,n);
    }

    void Assemble() {
        Network::CheckRounding();
        const auto start=Clock::now();
        Discover();
        const auto localStart=Clock::now();
        for(unsigned group=0;group<subdomains.size();++group) BuildSubdomain(group);
        condensationMs=Milliseconds(localStart);
        const unsigned variables=3*interfaces.size();
        mixedBody=Matrix::Zero(variables,6);bodyMass=Matrix::Zero(6,6);
        bodyContinuity=Matrix::Zero(subdomains.size(),6);
        std::vector<Triplet> kineticEntries,continuityEntries;
        for(unsigned group=0;group<subdomains.size();++group) {
            const auto& domain=subdomains[group];const unsigned ne=domain.boundaryKeys.size();
            const unsigned nz=3*ne+6;
            SubdomainMap map;map.columns.resize(ne);map.signs.resize(ne);
            for(unsigned face=0;face<ne;++face) {
                const auto& port=interfaces.at(domain.boundaryKeys[face]);
                map.columns[face]=3*port.id;
                map.signs[face]=cellSubdomain[port.firstCell]==group?1:-1;
            }
            const auto& h=domain.reducedMass;
            bodyMass+=h.bottomRightCorner(6,6);
            bodyContinuity.row(group)=domain.closure.tail(6);
            for(unsigned face=0;face<ne;++face) for(unsigned axis=0;axis<3;++axis) {
                const unsigned row=map.columns[face]+axis,local=3*face+axis;
                const Real sign=map.signs[face];
                const Real rate=domain.closure[local]*sign;
                if(rate!=0) continuityEntries.emplace_back(group,row,rate);
                mixedBody.row(row)+=sign*h.block(local,nz-6,1,6);
                for(unsigned other=0;other<ne;++other) for(unsigned component=0;component<3;++component) {
                    const Real value=sign*map.signs[other]*h(local,3*other+component);
                    if(value!=0) kineticEntries.emplace_back(row,map.columns[other]+component,value);
                }
            }
            maps.push_back(std::move(map));
        }
        mass.resize(variables,variables);mass.setFromTriplets(kineticEntries.begin(),kineticEntries.end());
        continuity.resize(subdomains.size(),variables);continuity.setFromTriplets(continuityEntries.begin(),continuityEntries.end());
        assemblyMs=Milliseconds(start);
        BuildFactor();
    }

    void BuildFactor() {
        const auto start=Clock::now();factor=std::make_shared<Factor>();
        std::vector<unsigned> parent(subdomains.size());std::iota(parent.begin(),parent.end(),0);
        const auto root=[&](unsigned group){while(parent[group]!=group) group=parent[group];return group;};
        for(const auto& [key,port]:interfaces) if(port.secondCell!=~0u)
            parent[root(cellSubdomain[port.secondCell])]=root(cellSubdomain[port.firstCell]);
        std::set<unsigned> openRoots;
        for(const auto& [key,port]:interfaces) if(port.secondCell==~0u) openRoots.insert(root(cellSubdomain[port.firstCell]));
        std::map<unsigned,unsigned> groups;components.clear();componentOpen.clear();
        for(unsigned group=0;group<subdomains.size();++group) {
            auto [at,inserted]=groups.emplace(root(group),components.size());
            if(inserted) {components.emplace_back();componentOpen.push_back(openRoots.count(root(group))!=0);}
            components[at->second].push_back(group);
            if(!inserted||componentOpen[at->second]) factor->retainedRows.push_back(group);
        }
        auto& prepared=*factor;const unsigned nv=mass.rows();
        prepared.velocityScale.resize(nv);
        for(unsigned i=0;i<nv;++i) {
            if(!(mass.coeff(i,i)>0)) throw std::runtime_error("Stage17 Krylov kinetic diagonal is nonpositive");
            prepared.velocityScale[i]=1/std::sqrt(mass.coeff(i,i));
        }
        prepared.scaledMass=prepared.velocityScale.asDiagonal()*mass*prepared.velocityScale.asDiagonal();
        auto phase=Clock::now();
        if(nv) {
            // The same positive factor previously computed only as a check is
            // retained and used by every exact Schur application.
            prepared.kinetic.compute(prepared.scaledMass);
            if(prepared.kinetic.info()!=Eigen::Success||(prepared.kinetic.vectorD().array()<=0).any())
                throw std::runtime_error("Stage17 Krylov kinetic metric is not positive");
            prepared.hasKinetic=true;
        }
        prepared.kineticMs=Milliseconds(phase);
        const unsigned np=prepared.retainedRows.size();
        prepared.pressureIndex.assign(subdomains.size(),-1);prepared.pressureScale.resize(np);
        for(unsigned row=0;row<np;++row) prepared.pressureIndex[prepared.retainedRows[row]]=row;
        std::vector<Real> norm(np,0);
        for(unsigned column=0;column<unsigned(continuity.outerSize());++column)
            for(Sparse::InnerIterator item(continuity,column);item;++item) {
                const int row=prepared.pressureIndex[item.row()];if(row<0) continue;
                const Real value=item.value()*prepared.velocityScale[item.col()];norm[row]+=value*value;
            }
        for(unsigned row=0;row<np;++row) {
            if(!(norm[row]>0)) throw std::runtime_error("Stage17 Krylov continuity row has no external port");
            prepared.pressureScale[row]=1/std::sqrt(norm[row]);
        }
        std::vector<Triplet> entries;
        for(unsigned column=0;column<unsigned(continuity.outerSize());++column)
            for(Sparse::InnerIterator item(continuity,column);item;++item) {
                const int row=prepared.pressureIndex[item.row()];if(row<0) continue;
                entries.emplace_back(row,item.col(),prepared.pressureScale[row]*item.value()*prepared.velocityScale[item.col()]);
            }
        prepared.scaledContinuity.resize(np,nv);
        prepared.scaledContinuity.setFromTriplets(entries.begin(),entries.end());
        phase=Clock::now();
        if(np) {
            Vector inverseDiagonal(nv);
            for(unsigned column=0;column<nv;++column)
                inverseDiagonal[column]=1/prepared.scaledMass.coeff(column,column);
            if(preconditioner==Preconditioner::Diagonal) {
                prepared.preconditioner=prepared.scaledContinuity*inverseDiagonal.asDiagonal()*prepared.scaledContinuity.transpose();
            } else {
                // The three trace moments of one physical port are a single
                // kinetic block. Retain their complete SPD coupling rather
                // than treating an arbitrary polynomial basis diagonally.
                if(nv%3) throw std::runtime_error("Stage17 port block partition is invalid");
                std::vector<Triplet> blocks;
                for(unsigned port=0;port<nv;port+=3) {
                    vm::Mat3 block;
                    for(unsigned i=0;i<3;++i) for(unsigned j=0;j<3;++j)
                        block(i,j)=prepared.scaledMass.coeff(port+i,port+j);
                    const Matrix inverse=vm::PositiveInverse(block,"Stage17 port block kinetic metric is not positive");
                    for(unsigned i=0;i<3;++i) for(unsigned j=0;j<3;++j)
                        if(inverse(i,j)!=0) blocks.emplace_back(port+i,port+j,inverse(i,j));
                }
                Sparse inverseBlocks(nv,nv);
                inverseBlocks.setFromTriplets(blocks.begin(),blocks.end());
                prepared.preconditioner=prepared.scaledContinuity*inverseBlocks*prepared.scaledContinuity.transpose();
            }
            prepared.pressurePreconditioner.compute(prepared.preconditioner);
            if(prepared.pressurePreconditioner.info()!=Eigen::Success||
               (prepared.pressurePreconditioner.vectorD().array()<=0).any())
                throw std::runtime_error("Stage17 pressure graph preconditioner is not positive");
            prepared.hasPressure=true;
        }
        prepared.preconditionerMs=Milliseconds(phase);
        factorMs=Milliseconds(start);
    }

    void CheckFlux(const Twist& twist) const {
        for(unsigned component=0;component<components.size();++component) {
            if(componentOpen[component]) continue;
            Real total=0,magnitude=0;
            for(unsigned group:components[component]) {
                const Real rate=(bodyContinuity.row(group)*twist)[0];
                total+=rate;magnitude+=std::abs(rate);
            }
            if(std::abs(total)>128*std::numeric_limits<Real>::epsilon()*magnitude)
                throw std::invalid_argument("Stage17 local-condensed body flow changes a sealed component volume");
        }
    }

    Result SolveRaw(const std::vector<Vector>& predictors,const Twist& twist=Twist::Zero()) const {
        Network::CheckRounding();const auto start=Clock::now();
        if(predictors.size()!=cells.size()||!twist.allFinite()) throw std::invalid_argument("Stage17 local-condensed source is invalid");
        CheckFlux(twist);
        for(unsigned cell=0;cell<cells.size();++cell)
            if(predictors[cell].size()!=cells[cell]->op.dimension||!predictors[cell].allFinite())
                throw std::invalid_argument("Stage17 local-condensed raw predictor is invalid");
        Result result;
        std::vector<SubdomainSource> sources;Vector load=Vector::Zero(mass.rows());
        for(unsigned group=0;group<subdomains.size();++group) {
            const auto& domain=subdomains[group];auto source=domain.PrepareSource(cells,predictors);
            for(const auto& piece:source.pieces) result.predictorEnergy+=piece.predictorEnergyConstant;
            for(unsigned face=0;face<domain.boundaryKeys.size();++face)
                load.segment(maps[group].columns[face],3)+=maps[group].signs[face]*source.reducedLoad.segment(3*face,3);
            sources.push_back(std::move(source));
        }
        if(!std::isfinite(result.predictorEnergy)||result.predictorEnergy>std::numeric_limits<double>::max())
            throw std::invalid_argument("Stage17 local-condensed source energy is not representable");
        load-=mixedBody*twist;
        const auto& prepared=*factor;const unsigned nv=mass.rows(),np=prepared.retainedRows.size();
        const Vector kineticRhs=prepared.velocityScale.asDiagonal()*load;
        Vector velocity=Vector::Zero(nv);
        if(prepared.hasKinetic) {
            velocity=prepared.kinetic.solve(kineticRhs);
            if(prepared.kinetic.info()!=Eigen::Success||!velocity.allFinite())
                throw std::runtime_error("Stage17 Krylov unconstrained kinetic solve failed");
        }
        Vector boundaryRhs=Vector::Zero(np);
        for(unsigned row=0;row<np;++row)
            boundaryRhs[row]=-prepared.pressureScale[row]*(bodyContinuity.row(prepared.retainedRows[row])*twist)[0];
        const auto pressure=prepared.SolvePressure(prepared.scaledContinuity*velocity-boundaryRhs);
        if(np) velocity-=prepared.kinetic.solve(prepared.scaledContinuity.transpose()*pressure.pressure);
        result.pressureIterations=pressure.iterations;
        result.pressureApplications=pressure.applications;
        result.pressureRestarts=pressure.restarts;
        result.pressureRelativeResidual=pressure.relativeResidual;
        result.pressureSolveMs=pressure.solveMs;
        const Real kineticResidual=(prepared.scaledMass*velocity+
            prepared.scaledContinuity.transpose()*pressure.pressure-kineticRhs).norm();
        const Real volumeResidual=(prepared.scaledContinuity*velocity-boundaryRhs).norm();
        result.scaledEquationResidual=std::hypot(kineticResidual,volumeResidual)/
            std::max<Real>(1,std::hypot(kineticRhs.norm(),boundaryRhs.norm()));
        result.flux=prepared.velocityScale.asDiagonal()*velocity;
        Vector macroPressure=Vector::Zero(subdomains.size());
        for(unsigned row=0;row<np;++row)
            macroPressure[prepared.retainedRows[row]]=prepared.pressureScale[row]*pressure.pressure[row];
        result.stationarity=(mass*result.flux-load+continuity.transpose()*macroPressure).norm()/std::max<Real>(1,load.norm());
        result.pressure=Vector::Zero(cells.size());result.local.resize(cells.size());
        Twist reducedReaction=Twist::Zero();Real reducedObjective=0;
        for(unsigned group=0;group<subdomains.size();++group) {
            const auto& domain=subdomains[group];const auto& source=sources[group];
            const unsigned ne=domain.boundaryKeys.size();Vector boundaryValues(3*ne+6);
            for(unsigned face=0;face<ne;++face)
                boundaryValues.segment(3*face,3)=maps[group].signs[face]*result.flux.segment(maps[group].columns[face],3);
            boundaryValues.tail(6)=twist;
            const Vector internal=source.offset-domain.inverseCoupling*boundaryValues;
            const Vector localRhs=(domain.scaledKkt*domain.scale.cwiseInverse().asDiagonal()*internal+
                domain.scale.asDiagonal()*domain.coupling*boundaryValues).eval();
            // Equivalently evaluate the original local KKT equation in its
            // equilibrated frame. Its nonzero RHS is retained source offset.
            const Vector sourceRhs=domain.scaledKkt*domain.scale.cwiseInverse().asDiagonal()*source.offset;
            result.localEquationResidual=std::max(result.localEquationResidual,
                (localRhs-sourceRhs).norm()/std::max<Real>(1,sourceRhs.norm()));
            reducedReaction-=(domain.reducedMass*boundaryValues-source.reducedLoad).tail(6);
            reducedReaction-=domain.closure.tail(6).transpose()*macroPressure[group];
            reducedObjective+=boundaryValues.dot(domain.reducedMass*boundaryValues)/2-
                              source.reducedLoad.dot(boundaryValues)+source.constant;
            for(unsigned piece=0;piece<domain.maps.size();++piece) {
                const auto& map=domain.maps[piece];const auto& local=*cells[map.cell];
                const Vector faces=map.internal*internal.head(domain.internalVariables)+map.boundary*boundaryValues;
                auto raw=local.condensed.Reconstruct(faces,source.pieces[piece]);
                result.local[map.cell]=raw;
                Real pressure=macroPressure[group];
                if(piece>0) pressure+=internal[domain.internalVariables+piece-1];
                result.pressure[map.cell]=pressure;
                result.energy+=local.op.Energy(raw);
                result.objective+=local.condensed.FullObjective(raw,source.pieces[piece]);
                result.balance=std::max(result.balance,(local.op.divergenceMoments*raw).cwiseAbs().maxCoeff());
                const Matrix body=map.boundary.rightCols(6);
                result.reaction-=body.transpose()*local.condensed.Gradient(faces,source.pieces[piece]);
                result.reaction-=(local.condensed.closure*body).transpose()*pressure;
            }
        }
        result.reactionReconstructionError=(result.reaction-reducedReaction).norm();
        result.objectiveReconstructionError=std::abs(result.objective-reducedObjective);
        result.energyIdentity=std::abs(result.objective+result.energy+twist.dot(result.reaction)-result.predictorEnergy);
        result.solveMs=Milliseconds(start);
        if(!result.reaction.allFinite()||!std::isfinite(result.energy)||!result.flux.allFinite())
            throw std::runtime_error("Stage17 local-condensed physical result is nonfinite");
        const Real energyScale=std::max<Real>(1,result.predictorEnergy+std::abs(twist.dot(result.reaction)));
        if(result.scaledEquationResidual>1e-10L||result.localEquationResidual>1e-10L||result.stationarity>1e-10L||
           result.balance>1e-10L*std::max<Real>(1,result.flux.norm())||result.energyIdentity>1e-10L*energyScale||
           result.objectiveReconstructionError>1e-10L*energyScale||
           result.reactionReconstructionError>1e-10L*std::max<Real>(1,result.reaction.norm()))
            throw std::runtime_error("Stage17 local-condensed reconstruction violates physical acceptance");
        return result;
    }

    Result Solve(const std::vector<vm::Affine>& predictors,const Twist& twist=Twist::Zero()) const {
        if(predictors.size()!=cells.size()) throw std::invalid_argument("Stage17 local-condensed affine source count is invalid");
        std::vector<Vector> raw;raw.reserve(cells.size());
        for(unsigned cell=0;cell<cells.size();++cell) {
            if(!predictors[cell].allFinite()) throw std::invalid_argument("Stage17 local-condensed affine source is nonfinite");
            raw.push_back(cells[cell]->op.InterpolateAffineDOFs(predictors[cell]));
        }
        return SolveRaw(raw,twist);
    }
    std::vector<vm::Affine> Constant(const vm::Vec3& velocity) const {
        std::vector<vm::Affine> result(cells.size(),vm::Affine::Zero());
        for(auto& coefficients:result) for(unsigned axis=0;axis<3;++axis) coefficients[4*axis]=velocity[axis];
        return result;
    }
};
using Epoch=LocalCondensedNetwork;
} // namespace stage17_krylov
