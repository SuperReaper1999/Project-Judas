#pragma once
#include "ResolvedCell.h"
#include <Eigen/SparseLU>
#include <chrono>
#include <memory>

// Isolated uncondensed pressure prototype. Baseline Network is unchanged.
// Physical polynomial and complementary coordinates remain primary globally;
// they are never condensed back to an absolute face-flux kinetic matrix.
namespace stage17_resolved_network {
namespace rs=stage17_resolved;namespace fr=stage17_framed;namespace vm=JudasFluidVem;
using Real=fr::Real;using R=fr::R;using RV=fr::RV;using Vec=fr::Vec;using Mat=fr::Mat;
using Matrix=fr::Matrix;using Vector=fr::Vector;using Affine=fr::Affine;
using Twist=Eigen::Matrix<Real,6,1>;using Sparse=Eigen::SparseMatrix<Real>;using Triplet=Eigen::Triplet<Real>;
using Box=convex_ports::Box;using Kind=convex_ports::Kind;using Key=convex_ports::PortKey;
using Clock=std::chrono::steady_clock;
inline double Ms(Clock::time_point start){return std::chrono::duration<double,std::milli>(Clock::now()-start).count();}
enum class Boundary {Sealed,OpenTop};

struct Local {
    convex_ports::Cell source;
    rs::Cell cell;
    Matrix inverseRoot,faceMap,divergence,lift;
    std::vector<Eigen::Matrix<Real,3,6>> bodyTrace;
    unsigned offset=0,dimension=0;
    explicit Local(convex_ports::Cell input,const R& scale):source(std::move(input)),cell(source,scale){
        dimension=12+cell.kernelDimension;
        inverseRoot=Matrix::Identity(dimension,dimension);
        for(unsigned a=0;a<3;++a)inverseRoot.block(4*a,4*a,4,4)=cell.polynomialFactor.block(4*a,4*a,4,4).template triangularView<Eigen::Upper>().solve(Eigen::Matrix<Real,4,4>::Identity());
        faceMap.resize(cell.faceDimension,dimension);faceMap.leftCols(12)=cell.facePolynomial;faceMap.rightCols(cell.kernelDimension)=cell.kernelFace;
        lift=Matrix::Zero(dimension,6);
        for(unsigned a=0;a<3;++a)lift(4*a,a)=1;
        for(unsigned axis=0;axis<3;++axis){RV omega{};omega[axis]=1;const RV value=owned_metrics::Cross(omega,cell.framed.frame.origin);for(unsigned a=0;a<3;++a){lift(4*a,3+axis)=value[a].convert_to<Real>();for(unsigned b=0;b<3;++b)lift(4*a+b+1,3+axis)=owned_metrics::Cross(omega,cell.framed.frame.columns[b])[a].convert_to<Real>();}}
        divergence=Matrix::Zero(4,dimension);
        for(unsigned t=0;t<4;++t)for(unsigned a=0;a<3;++a)for(unsigned b=0;b<3;++b)
            divergence(t,4*a+b+1)=cell.framed.referenceGeometry.volume[t]*cell.framed.frame.inverse(b,a);
        Matrix fluxMoments=Matrix::Zero(4,cell.faceDimension);
        for(unsigned f=0;f<source.faces.size();++f){
            const auto& canonical=cell.framed.faces[f];
            fluxMoments(0,3*f)=1; // psi0=1: integrated normal flux IS q0.
            RV base=fr::Sub(canonical.origin,cell.framed.frame.origin);
            base=fr::Add(base,fr::Mul(canonical.edge,canonical.midU/owned_metrics::Dot(canonical.edge,canonical.edge)));
            base=fr::Add(base,fr::Mul(canonical.transverse,canonical.midV/owned_metrics::Dot(canonical.transverse,canonical.transverse)));
            const RV xi0=fr::ExactApply(cell.framed.frame.inverseRows,base);
            const RV xi1=fr::ExactApply(cell.framed.frame.inverseRows,fr::Mul(canonical.edge,canonical.spanU/owned_metrics::Dot(canonical.edge,canonical.edge)));
            const RV xi2=fr::ExactApply(cell.framed.frame.inverseRows,fr::Mul(canonical.transverse,canonical.spanV/owned_metrics::Dot(canonical.transverse,canonical.transverse)));
            for(unsigned a=0;a<3;++a){fluxMoments(a+1,3*f)=xi0[a].convert_to<Real>();fluxMoments(a+1,3*f+1)=xi1[a].convert_to<Real>();fluxMoments(a+1,3*f+2)=xi2[a].convert_to<Real>();}
            std::array<std::array<R,6>,3> exact{};
            for(const auto& triangle:source.faces[f].triangles){
                std::array<RV,3> points;std::array<std::array<R,3>,3> psi;
                for(unsigned v=0;v<3;++v){points[v]=fr::Mul(triangle.points[v],scale);const auto p=rs::ExactFactors(canonical,points[v]);for(unsigned i=0;i<3;++i)psi[i][v]=p[i];}
                const RV area=fr::Mul(triangle.areaVector,scale*scale);
                for(unsigned k=0;k<6;++k){std::array<R,3> normal;for(unsigned v=0;v<3;++v){RV velocity{};if(k<3)velocity[k]=1;else{RV omega{};omega[k-3]=1;velocity=owned_metrics::Cross(omega,points[v]);}normal[v]=owned_metrics::Dot(area,velocity);}for(unsigned i=0;i<3;++i)exact[i][k]+=rs::ProductAverage(psi[i],normal);}
            }
            Eigen::Matrix<Real,3,6> trace;for(unsigned i=0;i<3;++i)for(unsigned k=0;k<6;++k)trace(i,k)=exact[i][k].convert_to<Real>();bodyTrace.push_back(trace);
        }
        divergence.rightCols(cell.kernelDimension)=fluxMoments*cell.kernelFace;
    }
    Vector Root(const Vector& eta)const{Vector result=eta;result.head(12)=cell.polynomialFactor*eta.head(12);return result;}
    rs::State StateFrom(const Vector& x)const{const Vector eta=inverseRoot*x;rs::State s;s.polynomial=eta.head(12);s.kernel=eta.tail(cell.kernelDimension);return s;}
    Vector Eta(const rs::State& s)const{Vector e(dimension);e.head(12)=s.polynomial;e.tail(cell.kernelDimension)=s.kernel;return e;}
};

struct Result {
    std::vector<rs::State> residual;
    Twist body=Twist::Zero(),reaction=Twist::Zero(),variationalReaction=Twist::Zero();
    Vector x,lambda;
    Real energy=0,predictorEnergy=0,objective=0,energyIdentity=0,stationarity=0,constraint=0;
    Real normalizedDivergence=0,pointDivergence=0,roundedFaceRate=0;
    double solveMs=0;
};

struct Epoch {
    unsigned grid=0,variables=0,rows=0;
    R scale=1;Boundary boundary=Boundary::Sealed;
    std::vector<std::shared_ptr<const Local>> cells;
    std::map<Key,std::vector<std::pair<unsigned,unsigned>>> ports;
    std::vector<std::vector<unsigned>> components;
    Matrix bodyConstraints,solidReaction,liftRoot;
    Vector rowScale;
    Sparse constraints,kkt;
    Eigen::SparseLU<Sparse,Eigen::COLAMDOrdering<int>> factor;
    double buildMs=0;

    bool Outer(const Key& k)const{for(unsigned a=0;a<3;++a){bool low=true,high=true;for(const auto& p:k.background){low&=p[a]==0;high&=p[a]==int(grid);}if(low||high)return true;}return false;}
    bool Open(const Key& k)const{if(boundary!=Boundary::OpenTop)return false;for(const auto& p:k.background)if(p[1]!=int(grid))return false;return true;}
    Epoch(unsigned n,const Box& box,const R& physicalScale=R(1),Boundary policy=Boundary::Sealed):grid(n),scale(physicalScale),boundary(policy){
        const auto started=Clock::now();convex_ports::Compiler geometry;geometry.Build(n,box);
        for(auto& source:geometry.cells){auto local=std::make_shared<Local>(std::move(source),scale);local->offset=variables;variables+=local->dimension;const unsigned c=cells.size();for(unsigned f=0;f<local->source.faces.size();++f)ports[local->source.faces[f].key].push_back({c,f});cells.push_back(std::move(local));}
        if(cells.empty())throw std::runtime_error("resolved network has no physical fluid cells");
        std::vector<unsigned> parent(cells.size());std::iota(parent.begin(),parent.end(),0);const auto root=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};
        for(const auto& [key,owners]:ports){const bool outer=key.kind==Kind::Solid||(key.kind==Kind::Background&&Outer(key));if(owners.size()!=(outer?1u:2u))throw std::runtime_error("resolved network port incidence is incomplete");if(!outer)parent[root(owners[1].first)]=root(owners[0].first);}
        std::map<unsigned,unsigned> groups;for(unsigned c=0;c<cells.size();++c){auto [at,inserted]=groups.emplace(root(c),components.size());if(inserted)components.emplace_back();components[at->second].push_back(c);}
        std::vector<bool> anchored(components.size(),false);for(const auto& [key,owners]:ports)if(key.kind==Kind::Background&&Outer(key)&&Open(key))anchored[groups.at(root(owners[0].first))]=true;
        std::set<unsigned> omitted;for(unsigned i=0;i<components.size();++i)if(!anchored[i])omitted.insert(components[i][0]);
        unsigned count=0;for(const auto& [key,owners]:ports)if(!(key.kind==Kind::Background&&Outer(key)&&Open(key)))count+=3;count+=4*cells.size()-omitted.size();rows=count;
        bodyConstraints=Matrix::Zero(rows,6);solidReaction=Matrix::Zero(rows,6);liftRoot=Matrix::Zero(variables,6);
        std::vector<Triplet> entries;unsigned row=0;
        const auto append=[&](unsigned r,const Matrix& block,const Local& local){for(unsigned i=0;i<block.rows();++i)for(unsigned j=0;j<block.cols();++j)if(block(i,j)!=0)entries.emplace_back(r+i,local.offset+j,block(i,j));};
        for(unsigned c=0;c<cells.size();++c){const auto& local=*cells[c];for(unsigned k=0;k<6;++k)liftRoot.block(local.offset,k,local.dimension,1)=local.Root(local.lift.col(k));}
        for(const auto& [key,owners]:ports){if(key.kind==Kind::Background&&Outer(key)&&Open(key))continue;for(const auto [c,f]:owners){const auto& local=*cells[c];append(row,local.faceMap.block(3*f,0,3,local.dimension)*local.inverseRoot,local);}if(key.kind==Kind::Solid){const auto [c,f]=owners[0];solidReaction.block(row,0,3,6)=cells[c]->bodyTrace[f];}else if(key.kind==Kind::Background&&Outer(key)){const auto [c,f]=owners[0];bodyConstraints.block(row,0,3,6)=cells[c]->bodyTrace[f];}row+=3;}
        for(unsigned c=0;c<cells.size();++c){const auto& local=*cells[c];for(unsigned t=0;t<4;++t){if(t==0&&omitted.count(c))continue;append(row,local.divergence.row(t)*local.inverseRoot,local);++row;}}
        if(row!=rows)throw std::runtime_error("resolved network constraint inventory mismatch");
        Sparse raw(rows,variables);raw.setFromTriplets(entries.begin(),entries.end());rowScale=Vector::Zero(rows);for(int c=0;c<raw.outerSize();++c)for(Sparse::InnerIterator it(raw,c);it;++it)rowScale(it.row())+=it.value()*it.value();for(unsigned r=0;r<rows;++r){if(!(rowScale(r)>0))throw std::runtime_error("resolved network has a zero constraint row");rowScale(r)=1/std::sqrt(rowScale(r));}
        constraints=rowScale.asDiagonal()*raw;
        std::vector<Triplet> saddle;for(unsigned i=0;i<variables;++i)saddle.emplace_back(i,i,1);for(int c=0;c<constraints.outerSize();++c)for(Sparse::InnerIterator it(constraints,c);it;++it){saddle.emplace_back(variables+it.row(),it.col(),it.value());saddle.emplace_back(it.col(),variables+it.row(),it.value());}
        kkt.resize(variables+rows,variables+rows);kkt.setFromTriplets(saddle.begin(),saddle.end());factor.compute(kkt);if(factor.info()!=Eigen::Success)throw std::runtime_error("resolved uncondensed constraint factorization failed");buildMs=Ms(started);
    }
    std::vector<rs::State> Constant(const Vec& velocity)const{std::vector<rs::State> result;for(const auto& c:cells)result.push_back(c->cell.PhysicalAffine(velocity,Mat::Zero()));return result;}
    Result Solve(const std::vector<rs::State>& predictors,const Twist& body=Twist::Zero())const{
        const auto started=Clock::now();if(predictors.size()!=cells.size()||!body.allFinite())throw std::invalid_argument("resolved network invalid physical predictor");
        Vector source(variables);for(unsigned c=0;c<cells.size();++c)source.segment(cells[c]->offset,cells[c]->dimension)=cells[c]->cell.Coordinates(predictors[c]);
        Vector rhs(variables+rows);rhs.head(variables)=source-liftRoot*body;rhs.tail(rows)=-(rowScale.asDiagonal()*bodyConstraints*body);
        const Vector solved=factor.solve(rhs);if(factor.info()!=Eigen::Success||!solved.allFinite())throw std::runtime_error("resolved uncondensed physical solve failed");
        Result out;out.body=body;out.x=solved.head(variables);out.lambda=rowScale.asDiagonal()*solved.tail(rows);const Vector actual=out.x+liftRoot*body;
        out.reaction=solidReaction.transpose()*out.lambda;out.variationalReaction=-liftRoot.transpose()*(actual-source)-bodyConstraints.transpose()*out.lambda;
        out.energy=actual.squaredNorm()/2;out.predictorEnergy=source.squaredNorm()/2;out.objective=(actual-source).squaredNorm()/2;out.energyIdentity=std::abs(out.objective+out.energy+body.dot(out.reaction)-out.predictorEnergy);
        out.stationarity=(actual-source+constraints.transpose()*solved.tail(rows)).norm();out.constraint=(constraints*out.x+rowScale.asDiagonal()*bodyConstraints*body).cwiseAbs().maxCoeff();
        for(unsigned c=0;c<cells.size();++c){const auto& local=*cells[c];auto state=local.StateFrom(out.x.segment(local.offset,local.dimension));const Vector eta=local.Eta(state);Eigen::Matrix<Real,4,1> moments=local.divergence*eta;out.normalizedDivergence=std::max(out.normalizedDivergence,moments.cwiseAbs().maxCoeff()/local.cell.framed.physicalVolume);
            Eigen::Matrix<Real,4,4> gram;for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)gram(i,j)=local.cell.framed.referenceGeometry.volume[vm::ProductIndex(i,j)]/local.cell.framed.physicalVolume;
            const Eigen::Matrix<Real,4,1> coefficients=gram.llt().solve(moments/local.cell.framed.physicalVolume);for(const auto& simplex:local.source.integration)for(const auto& point:simplex.points){const Vec xi=local.cell.framed.frame.CoordinatesReal(fr::Mul(point,scale));Eigen::Matrix<Real,4,1> p;p<<1,xi.x(),xi.y(),xi.z();out.pointDivergence=std::max(out.pointDivergence,std::abs(coefficients.dot(p)));}
            const auto flux=local.cell.FaceFlux(state);stage16_fast_geometry::Sum sum;for(unsigned f=0;f<local.source.faces.size();++f)sum.Add(flux(3*f));out.roundedFaceRate=std::max(out.roundedFaceRate,std::abs(sum.Get())/local.cell.framed.physicalVolume);out.residual.push_back(std::move(state));}
        out.solveMs=Ms(started);return out;
    }
};
} // namespace stage17_resolved_network
