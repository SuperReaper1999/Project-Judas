#include "KrylovCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <cstdlib>

namespace direct=stage17_condensed;
namespace iterative=stage17_krylov;
namespace net=stage17_network;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;
    if(!condition) throw std::runtime_error(message);
}
void Run(unsigned grid,double angle,iterative::Preconditioner mode=iterative::Preconditioner::Diagonal) {
    using V=glm::dvec3;
    const auto box=owned_cut::BoxPlanes(V(.5*grid),V(.2*grid),
        glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
    const auto start=net::Clock::now();
    direct::Epoch baseline(grid,box,net::vg::R(1)/grid);
    const double baselineBuild=net::Milliseconds(start);
    auto phase=net::Clock::now();
    iterative::Epoch candidate(baseline,mode);
    const double preparation=net::Milliseconds(phase);
    Check(baseline.mass.rows()==candidate.mass.rows(),"Krylov comparison changes variables");
    Check((net::Matrix(baseline.mass).array()==net::Matrix(candidate.mass).array()).all(),
          "Krylov comparison changes the chosen kinetic matrix");
    Check((net::Matrix(baseline.continuity).array()==net::Matrix(candidate.continuity).array()).all(),
          "Krylov comparison changes physical constraints");
    for(unsigned scenario=0;scenario<3;++scenario) {
        auto source=baseline.Constant(net::vm::Vec3(0,-.04L,0));
        if(scenario==1) source=baseline.Constant(net::vm::Vec3::Zero());
        if(scenario==2)
            for(unsigned cell=0;cell<baseline.cells.size();++cell) {
                const auto& physical=baseline.cells[cell]->cell;
                const long double seed=physical.seed+3*physical.piece;
                source[cell][0]=.03L*std::sin(seed*.017L);
                source[cell][4]=-.02L*std::cos(seed*.031L);
                source[cell][8]=.01L*std::sin(seed*.023L);
                source[cell][3]=.015L;source[cell][6]=-.01L;source[cell][9]=.012L;
            }
        net::Twist body=net::Twist::Zero();
        if(scenario==1) body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto a=baseline.Solve(source,body);
        const auto b=candidate.Solve(source,body);
        long double field=0;
        for(unsigned cell=0;cell<baseline.cells.size();++cell) {
            const net::Vector difference=a.local[cell]-b.local[cell];
            const auto& mass=baseline.cells[cell]->op.mass;
            const long double error=std::sqrt(std::abs(difference.dot(mass*difference)));
            field=std::max(field,error/std::max<long double>(1,std::sqrt(std::abs(a.local[cell].dot(mass*a.local[cell])))));
        }
        const long double energy=std::abs(a.energy-b.energy)/std::max<long double>(1,a.energy);
        const long double wrench=(a.reaction-b.reaction).norm()/std::max<long double>(1,a.reaction.norm());
        Check(field<1e-10L,"Krylov solver changes actual physical endpoints");
        Check(energy<1e-10L,"Krylov solver changes kinetic energy");
        Check(wrench<1e-10L,"Krylov solver changes native body wrench");
        Check(b.pressureRelativeResidual<=1e-15L,"Krylov acceptance did not use strict true Schur residual");
        Check(b.pressureIterations<=2*candidate.factor->retainedRows.size(),"Krylov solver exceeded its normal policy");
        Check(b.balance<1e-12L&&b.energyIdentity<1e-10L&&b.reactionReconstructionError<1e-10L,
              "Krylov physical reconstruction loses work or continuity");
        printf("KRYLOV preconditioner=%s grid=%u angle=%g scenario=%u cells=%zu macro_variables=%ld pressure_rows=%zu baseline_build_ms=%g baseline_global_factor_ms=%g candidate_prepare_ms=%g candidate_global_factor_ms=%g kinetic_factor_ms=%g preconditioner_ms=%g baseline_solve_ms=%g candidate_solve_ms=%g pressure_solve_ms=%g iterations=%u applications=%u restarts=%u true_relative_residual=%Lg field_error=%Lg energy_error=%Lg wrench_error=%Lg balance=%Lg work=%Lg\n",
            mode==iterative::Preconditioner::Diagonal?"diagonal":"port_block3",grid,angle,scenario,baseline.cells.size(),long(baseline.mass.rows()),candidate.factor->retainedRows.size(),
            baselineBuild,baseline.factorMs,preparation,candidate.factorMs,candidate.factor->kineticMs,
            candidate.factor->preconditionerMs,a.solveMs,b.solveMs,b.pressureSolveMs,b.pressureIterations,
            b.pressureApplications,b.pressureRestarts,b.pressureRelativeResidual,field,energy,wrench,b.balance,b.energyIdentity);
    }
    const auto zero=candidate.Solve(candidate.Constant(net::vm::Vec3::Zero()));
    Check(zero.energy==0&&zero.reaction.norm()==0&&zero.pressureIterations==0,
          "Krylov solver retains state or invents a zero-source pressure");
}
int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        if(argc>1) Run(unsigned(std::strtoul(argv[1],nullptr,10)),.17,argc>2&&std::string(argv[2])=="block"?iterative::Preconditioner::PortBlock3:iterative::Preconditioner::Diagonal);
        else {Run(1,0);Run(1,.17);Run(4,.17);}
        printf("KRYLOV_SUMMARY checks=%u failures=0\n",checks);return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
