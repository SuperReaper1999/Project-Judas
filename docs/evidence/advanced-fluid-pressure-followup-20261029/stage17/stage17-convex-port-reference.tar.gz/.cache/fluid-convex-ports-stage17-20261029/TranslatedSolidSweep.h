#pragma once
// Private exact-in-time swept geometry proof for a convex native box in a
// fixed voxel grid. Translation only: the fixed plane normals are a declared
// boundary, not an approximation to rotation. No fluid quantities are moved.
#include "ExactConvexClip.h"
#include "ConvexPorts.h"
#include <chrono>
#include <set>
namespace translated_sweep {
using R=exact_convex::R;using RV=exact_convex::RV;
using Plane=exact_convex::Plane;using Poly=exact_convex::Polyhedron;
using Box=convex_ports::Box;
inline R Dot(const RV& a,const RV& b){return owned_metrics::Dot(a,b);}
inline RV Difference(const RV& a,const RV& b){return exact_convex::Sub(a,b);}
inline R Det3(const std::array<std::array<R,3>,3>& m){return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]);}
inline R Det4(const std::array<Plane,4>& planes){R result=0;for(unsigned c=0;c<4;++c){std::array<std::array<R,3>,3> minor;for(unsigned i=1;i<4;++i){unsigned column=0;for(unsigned j=0;j<4;++j)if(j!=c)minor[i-1][column++]=j<3?planes[i].normal[j]:planes[i].coordinate;}const R value=(c<3?planes[0].normal[c]:planes[0].coordinate)*Det3(minor);result+=(c&1)?-value:value;}return result;}
struct Moments {R volume=0;RV first{};};
struct Cell {
    unsigned voxel=0;
    Moments oldState,newState;
    R sweptVolume=0;
    RV sweptFirst{};
    std::array<R,6> nativeFaceVolumes{};
    unsigned intervals=0,samples=0;
};
struct Result {std::vector<Cell> cells;unsigned intervals=0,samples=0;double milliseconds=0;};
struct Path {
    unsigned grid=0;Box native;
    RV displacement{},initialTranslation{};
    R duration=1;
    Path(unsigned n,const Box& box,const RV& movement,const R& seconds=1)
        :grid(n),native(box),displacement(movement),duration(seconds) {
        if(!n||n>4||seconds<=0)throw std::invalid_argument("translated sweep requires a positive bounded grid and time interval");
        for(const auto& p:box){if(!std::isfinite(p.coordinate))throw std::invalid_argument("translated sweep nonfinite native plane");for(double x:p.normal)if(!std::isfinite(x))throw std::invalid_argument("translated sweep nonfinite native normal");}
    }
    Path Reversed() const {
        Path result=*this;
        for(unsigned a=0;a<3;++a){result.initialTranslation[a]+=displacement[a];result.displacement[a]=-displacement[a];}
        return result;
    }
    std::vector<Plane> Planes(unsigned voxel,const R& time) const {
        std::vector<Plane> result;
        for(const auto& p:native){Plane plane;for(unsigned a=0;a<3;++a)plane.normal[a]=R(p.normal[a]);plane.coordinate=R(p.coordinate)+Dot(plane.normal,initialTranslation)+time*Dot(plane.normal,displacement);result.push_back(std::move(plane));}
        const unsigned xyz[3]={voxel%grid,(voxel/grid)%grid,voxel/(grid*grid)};
        for(unsigned a=0;a<3;++a)for(unsigned side=0;side<2;++side){Plane p;p.normal[a]=side?1:-1;p.coordinate=side?R(xyz[a]+1):R(-int(xyz[a]));result.push_back(std::move(p));}
        return result;
    }
    Poly Cube(unsigned voxel) const {
        const unsigned xyz[3]={voxel%grid,(voxel/grid)%grid,voxel/(grid*grid)};Poly cube;
        for(unsigned axis=0;axis<3;++axis)for(unsigned side=0;side<2;++side){const unsigned u=(axis+1)%3,v=(axis+2)%3;RV p={R(xyz[0]),R(xyz[1]),R(xyz[2])};p[axis]+=side;RV a=p,b=p,c=p;++a[u];++b[u];++b[v];++c[v];exact_convex::Face face{6+2*axis+side,{p,a,b,c}};if(!side)std::reverse(face.vertices.begin(),face.vertices.end());cube.faces.push_back(std::move(face));}return cube;
    }
    Poly Body(unsigned voxel,const R& time) const {
        auto solid=Cube(voxel);const auto planes=Planes(voxel,time);
        for(unsigned p=0;p<6&&!solid.faces.empty();++p)solid=exact_convex::Clip(solid,planes,p,1);
        return solid;
    }
    static Moments Integrate(const Poly& solid) {
        Moments result;for(const auto& tet:exact_convex::PositiveCones(solid)){result.volume+=tet.volume;for(unsigned a=0;a<3;++a)for(const auto& p:tet.points)result.first[a]+=tet.volume*p[a]/4;}return result;
    }
    static bool ActiveEvent(const std::vector<Plane>& planes,const std::array<unsigned,4>& event) {
        // Inactive intersections cannot change the clipped native solid.
        // This exact halfspace certificate removes work, never an admitted
        // boundary feature or a small positive physical volume.
        for(unsigned omitted=0;omitted<4;++omitted) {
            std::array<std::array<R,3>,3> matrix;RV rhs;unsigned row=0;
            for(unsigned i=0;i<4;++i)if(i!=omitted){matrix[row]=planes[event[i]].normal;rhs[row++]=planes[event[i]].coordinate;}
            const R denominator=Det3(matrix);if(denominator==0)continue;RV point;
            for(unsigned axis=0;axis<3;++axis){auto numerator=matrix;for(unsigned r=0;r<3;++r)numerator[r][axis]=rhs[r];point[axis]=Det3(numerator)/denominator;}
            for(const auto& plane:planes)if(exact_convex::Evaluate(point,plane)>0)return false;
            return true;
        }
        return false; // Four rank-deficient planes cannot define a 3D vertex.
    }
    std::set<R> Events(unsigned voxel) const {
        const auto begin=Planes(voxel,0),end=Planes(voxel,1);std::set<R> result{R(0),R(1)};
        // A fixed-normal affine plane arrangement changes its combinatorial
        // type only where four planes meet (including simultaneous events).
        // Exact halfspace checks discard inactive intersections only.
        for(unsigned a=0;a<12;++a)for(unsigned b=a+1;b<12;++b)for(unsigned c=b+1;c<12;++c)for(unsigned d=c+1;d<12;++d){const R before=Det4({begin[a],begin[b],begin[c],begin[d]}),after=Det4({end[a],end[b],end[c],end[d]});if(before==after)continue;const R time=before/(before-after);if(time>0&&time<1 && ActiveEvent(Planes(voxel,time),{a,b,c,d}))result.insert(time);}
        return result;
    }
    Cell Sweep(unsigned voxel) const {
        if(voxel>=grid*grid*grid)throw std::invalid_argument("translated sweep voxel outside grid");
        Cell result;result.voxel=voxel;result.oldState=Integrate(Body(voxel,0));result.newState=Integrate(Body(voxel,1));
        const auto events=Events(voxel);const std::array<R,3> nodes={R(1)/6,R(1)/2,R(5)/6},weights={R(3)/8,R(1)/4,R(3)/8};
        // Vertices are affine in time within an arrangement epoch. Surface
        // area is quadratic and x*area is cubic. This interior three-point
        // Newton-Cotes rule integrates both EXACTLY, avoiding degenerate event
        // endpoint evaluation as a numerical special case.
        for(auto left=events.begin(),right=std::next(left);right!=events.end();++left,++right){++result.intervals;const R interval=*right-*left;for(unsigned sample=0;sample<3;++sample){++result.samples;const R time=*left+interval*nodes[sample],weight=interval*weights[sample];const auto solid=Body(voxel,time);for(const auto& face:solid.faces)if(face.plane<6)for(const auto& triangle:exact_convex::Triangulate(face)){const R amount=weight*Dot(displacement,triangle.areaVector);result.sweptVolume+=amount;result.nativeFaceVolumes[face.plane]+=amount;for(unsigned a=0;a<3;++a)for(const auto& point:triangle.points)result.sweptFirst[a]+=amount*point[a]/3;}}}
        return result;
    }
    Result Run() const {
        const auto start=std::chrono::steady_clock::now();Result result;
        for(unsigned voxel=0;voxel<grid*grid*grid;++voxel){auto cell=Sweep(voxel);result.intervals+=cell.intervals;result.samples+=cell.samples;result.cells.push_back(std::move(cell));}
        result.milliseconds=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
    }
};
} // namespace translated_sweep
