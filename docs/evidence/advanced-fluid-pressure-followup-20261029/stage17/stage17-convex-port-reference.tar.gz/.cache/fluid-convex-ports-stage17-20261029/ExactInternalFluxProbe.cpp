// DIAGNOSTIC ONLY. This does NOT alter a solved state, minimize a new objective,
// publish fluid quantities, repair production flux or recompute native wrench.
// It asks whether an exact graph-coordinate representation can carry the SAME
// non-tree and external flux data without tiny-cell subtraction loss.
#include "LocalCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <limits>
#include <queue>

using namespace stage17_network;
using Exact=vg::R;

struct Edge {
    PortKey key;
    unsigned first=0,firstFace=0,second=0,secondFace=0;
    Exact original=0;
};
struct Incidence { unsigned edge=0,other=0,face=0; };
unsigned checks=0;
void Check(bool condition,const char* description) {
    ++checks;
    if(!condition) throw std::runtime_error(description);
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),
            glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3))));
        const Network physical(1,box);
        const stage17_condensed::Epoch condensed(physical);
        Twist body;body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto solved=condensed.Solve(physical.Constant(vm::Vec3::Zero()),body);

        std::vector<std::vector<Exact>> original(physical.cells.size()),certificate;
        for(unsigned cell=0;cell<physical.cells.size();++cell) {
            const unsigned faces=physical.cells[cell]->cell.faces.size();
            original[cell].resize(faces);
            for(unsigned face=0;face<faces;++face)
                original[cell][face]=Exact(solved.local[cell][3*face]);
        }
        certificate=original; // independent exact-rational diagnostic data
        std::vector<Edge> edges;
        std::vector<std::vector<Incidence>> graph(physical.cells.size());
        for(const auto& [key,port]:condensed.allPorts) {
            if(key.kind!=Kind::Internal) continue;
            Check(port.secondCell!=~0u,"internal graph edge lacks opposite owner");
            Check(original[port.firstCell][port.firstFace]+original[port.secondCell][port.secondFace]==0,
                  "unchanged solve does not expose exact opposite signed internal values");
            const unsigned index=edges.size();
            edges.push_back({key,port.firstCell,port.firstFace,port.secondCell,port.secondFace,
                             original[port.firstCell][port.firstFace]});
            graph[port.firstCell].push_back({index,port.secondCell,port.firstFace});
            graph[port.secondCell].push_back({index,port.firstCell,port.secondFace});
        }
        std::vector<bool> tree(edges.size(),false),visited(physical.cells.size(),false),isRoot(physical.cells.size(),false);
        std::vector<unsigned> parent(physical.cells.size(),~0u),parentEdge(physical.cells.size(),~0u);
        Exact maxDelta=0,maxUlps=0;
        Real maxBefore=0,maxAfterNonRoot=0,maxRootRate=0;
        unsigned treeEdges=0,cycleEdges=0;
        for(const auto& domain:condensed.subdomains) {
            Check(!domain.cells.empty(),"empty internal connected component");
            unsigned root=domain.cells.front();
            for(unsigned cell:domain.cells)
                if(physical.cells[cell]->cell.exactVolume>physical.cells[root]->cell.exactVolume) root=cell;
            isRoot[root]=true;
            std::vector<unsigned> order;
            std::queue<unsigned> queue;
            queue.push(root);visited[root]=true;parent[root]=root;
            while(!queue.empty()) {
                const unsigned cell=queue.front();queue.pop();order.push_back(cell);
                for(const auto& next:graph[cell]) if(!visited[next.other]) {
                    Check(physical.cells[next.other]->cell.seed==domain.seed,"internal tree crossed original seed");
                    visited[next.other]=true;parent[next.other]=cell;parentEdge[next.other]=next.edge;
                    tree[next.edge]=true;++treeEdges;
                    queue.push(next.other);
                }
            }
            Check(order.size()==domain.cells.size(),"internal graph disagrees with unchanged subdomain ownership");
            for(unsigned reverse=order.size();reverse>0;--reverse) {
                const unsigned cell=order[reverse-1];
                if(cell==root) continue;
                const auto& edge=edges[parentEdge[cell]];
                const unsigned face=cell==edge.first?edge.firstFace:edge.secondFace;
                Exact others=0;
                for(unsigned f=0;f<certificate[cell].size();++f) if(f!=face) others+=certificate[cell][f];
                const Exact outward=-others;
                const Exact canonical=cell==edge.first?outward:-outward;
                certificate[edge.first][edge.firstFace]=canonical;
                certificate[edge.second][edge.secondFace]=-canonical;
                const Exact delta=abs(canonical-edge.original);
                maxDelta=std::max(maxDelta,delta);
                const Real before=solved.local[edge.first][3*edge.firstFace];
                const Real next=std::nextafter(before,std::numeric_limits<Real>::infinity());
                const Exact ulp=abs(Exact(next)-Exact(before));
                if(ulp>0) maxUlps=std::max(maxUlps,Exact(delta/ulp));
                // canonical is NEVER converted back to a published float.
            }
            Exact coarse=0,rootSum=0;
            for(unsigned cell:domain.cells) {
                Exact sum=0,before=0;
                for(unsigned f=0;f<certificate[cell].size();++f) {
                    sum+=certificate[cell][f];before+=original[cell][f];
                    if(physical.cells[cell]->cell.faces[f].kind!=Kind::Internal) {
                        coarse+=original[cell][f];
                        Check(certificate[cell][f]==original[cell][f],"external or solid flux changed in exact certificate");
                    }
                }
                const Exact volume=physical.cells[cell]->cell.exactVolume;
                const Real beforeRate=abs(before/volume).convert_to<Real>();
                const Real afterRate=abs(sum/volume).convert_to<Real>();
                maxBefore=std::max(maxBefore,beforeRate);
                if(cell!=root) {
                    Check(sum==0,"non-root graph cell is not EXACTLY conservative");
                    maxAfterNonRoot=std::max(maxAfterNonRoot,afterRate);
                } else {rootSum=sum;maxRootRate=std::max(maxRootRate,afterRate);}
                if(beforeRate>1e-8L || afterRate>1e-8L)
                    std::printf("EXACT_GRAPH_CELL seed=%u piece=%u root=%u volume=%Lg before_rate=%Lg after_rate=%Lg\n",
                        physical.cells[cell]->cell.seed,physical.cells[cell]->cell.piece,unsigned(cell==root),
                        volume.convert_to<Real>(),beforeRate,afterRate);
            }
            Check(rootSum==coarse,"root residual is not the unchanged component external/solid residual");
            std::printf("EXACT_GRAPH_COMPONENT seed=%u cells=%zu root_cell=%u root_piece=%u root_volume=%Lg coarse_flux=%Lg root_rate=%Lg\n",
                domain.seed,domain.cells.size(),root,physical.cells[root]->cell.piece,
                physical.cells[root]->cell.exactVolume.convert_to<Real>(),coarse.convert_to<Real>(),
                abs(rootSum/physical.cells[root]->cell.exactVolume).convert_to<Real>());
        }
        for(unsigned edge=0;edge<edges.size();++edge) {
            const auto& e=edges[edge];
            Check(certificate[e.first][e.firstFace]+certificate[e.second][e.secondFace]==0,
                  "diagnostic opposite port values no longer cancel exactly");
            if(!tree[edge]) {
                ++cycleEdges;
                Check(certificate[e.first][e.firstFace]==original[e.first][e.firstFace],
                      "non-tree internal cycle flux changed");
            }
        }
        const char* output=argc>1?argv[1]:
            ".cache/fluid-convex-ports-stage17-20261029/logs/exact-internal-flux-certificate-v1.txt";
        std::ofstream file(output,std::ios::out|std::ios::trunc);
        if(!file) throw std::runtime_error("cannot preserve exact graph certificate");
        file<<"DIAGNOSTIC_ONLY accepted_state_modified=0 objective_recomputed=0 wrench_recomputed=0\n";
        file<<"Exact rational values below are NOT rounded back into physical runtime storage.\n";
        for(unsigned cell=0;cell<physical.cells.size();++cell)
            for(unsigned face=0;face<certificate[cell].size();++face) {
                file<<"cell="<<cell<<" seed="<<physical.cells[cell]->cell.seed
                    <<" piece="<<physical.cells[cell]->cell.piece<<" face="<<face
                    <<" root="<<isRoot[cell]<<" kind="<<int(physical.cells[cell]->cell.faces[face].kind)
                    <<" original_hex="<<std::hexfloat<<std::setprecision(std::numeric_limits<Real>::max_digits10)
                    <<solved.local[cell][3*face]<<std::defaultfloat
                    <<" original_exact="<<original[cell][face]<<" certificate_exact="<<certificate[cell][face]<<'\n';
            }
        file.close();
        if(!file) throw std::runtime_error("could not finish exact graph certificate");
        std::printf("EXACT_GRAPH_SUMMARY checks=%u failures=0 tree_edges=%u cycle_edges=%u "
                    "before_mean_div=%Lg nonroot_after_mean_div=%Lg root_after_mean_div=%Lg "
                    "max_absolute_tree_delta=%Lg max_tree_delta_ulps=%Lg "
                    "accepted_state_modified=0 objective_recomputed=0 wrench_recomputed=0 certificate=%s\n",
                    checks,treeEdges,cycleEdges,maxBefore,maxAfterNonRoot,maxRootRate,
                    maxDelta.convert_to<Real>(),maxUlps.convert_to<Real>(),output);
        return 0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"EXACT_GRAPH_FAIL checks=%u %s\n",checks,error.what());
        return 1;
    }
}
