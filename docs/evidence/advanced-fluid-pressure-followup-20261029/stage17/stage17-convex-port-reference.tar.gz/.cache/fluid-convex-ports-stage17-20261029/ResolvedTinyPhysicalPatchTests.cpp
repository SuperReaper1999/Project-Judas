// Independent physical polynomial and NONPOLYNOMIAL kernel acceptance.
// The latter is inferred from ACTUAL face flux and exact geometry, not from a
// zero reported by PhysicalMoments or the constructor's SVD residual.
#include "ResolvedCell.h"
#include "acceptance/ExactKernelMoments.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <cstdlib>

namespace rc=stage17_resolved;
namespace ek=exact_kernel;
namespace pa=port_acceptance;
namespace vm=JudasFluidVem;
using pa::R;
using pa::RV;
using Real=vm::Real;
using Coefficients=std::array<R,12>;

RV Field(const Coefficients& field,const RV& r) {
    RV result{};
    for(unsigned a=0;a<3;++a) {
        result[a]=field[4*a];
        for(unsigned b=0;b<3;++b) result[a]+=field[4*a+b+1]*r[b];
    }
    return result;
}
Real Magnitude(const RV& v) {
    Real square=0;
    for(const auto& value:v) {const Real x=value.convert_to<Real>();square+=x*x;}
    return std::sqrt(square);
}
std::vector<Coefficients> Fields() {
    std::vector<Coefficients> fields(15);
    for(unsigned i=0;i<12;++i) fields[i][i]=1;
    fields[12][7]=-1;fields[12][10]=1;
    fields[13][3]=1;fields[13][9]=-1;
    fields[14][2]=-1;fields[14][5]=1;
    return fields;
}

struct PhysicalOracle {
    pa::Moments volume{};
    std::vector<RV> vertices;
    explicit PhysicalOracle(const convex_ports::Cell& input) {
        std::set<RV> unique;
        for(const auto& simplex:input.integration) {
            std::array<RV,4> r;
            for(unsigned i=0;i<4;++i) {r[i]=pa::Sub(simplex.points[i],input.center);unique.insert(simplex.points[i]);}
            pa::Add(volume,pa::TetraP2(r));
        }
        vertices.assign(unique.begin(),unique.end());
    }
    R Kinetic(const Coefficients& a,const Coefficients& b) const {
        R result=0;
        for(unsigned component=0;component<3;++component)
            for(unsigned i=0;i<4;++i)
                for(unsigned j=0;j<4;++j)
                    result+=1000*a[4*component+i]*b[4*component+j]*volume[vm::ProductIndex(i,j)];
        return result;
    }
    std::array<R,12> Moments(const Coefficients& field) const {
        std::array<R,12> out{};
        for(unsigned component=0;component<3;++component)
            for(unsigned m=0;m<4;++m)
                for(unsigned j=0;j<4;++j)
                    out[4*component+m]+=field[4*component+j]*volume[vm::ProductIndex(m,j)];
        return out;
    }
};

rc::State ExactPhysicalState(const rc::Cell& cell,const Coefficients& field) {
    rc::State state;
    state.kernel=vm::Vector::Zero(cell.kernelDimension);
    const RV atOrigin=Field(field,cell.framed.frame.offset);
    for(unsigned a=0;a<3;++a) {
        state.polynomial[4*a]=atOrigin[a].convert_to<Real>();
        for(unsigned reference=0;reference<3;++reference) {
            R coefficient=0;
            for(unsigned physical=0;physical<3;++physical)
                coefficient+=field[4*a+physical+1]*cell.framed.frame.columns[reference][physical];
            state.polynomial[4*a+reference+1]=coefficient.convert_to<Real>();
        }
    }
    return state;
}

struct Stats {
    unsigned checks=0,failures=0,exactNonzeroKernel=0,unitStressAbsoluteFailures=0;
    Real velocity=0,normal=0,energy=0,work=0,moments=0,kernelVelocity=0,
         kernelMoment=0,kernelEnergy=0,unitStressVelocity=0;
    void Observe(Real value,Real& maximum,bool gate=true) {
        ++checks;maximum=std::max(maximum,std::abs(value));
        if(gate && (!std::isfinite(value)||std::abs(value)>1e-8L)) ++failures;
    }
    void Merge(const Stats& other) {
        checks+=other.checks;failures+=other.failures;
        exactNonzeroKernel+=other.exactNonzeroKernel;unitStressAbsoluteFailures+=other.unitStressAbsoluteFailures;
        velocity=std::max(velocity,other.velocity);normal=std::max(normal,other.normal);
        energy=std::max(energy,other.energy);work=std::max(work,other.work);moments=std::max(moments,other.moments);
        kernelVelocity=std::max(kernelVelocity,other.kernelVelocity);kernelMoment=std::max(kernelMoment,other.kernelMoment);
        kernelEnergy=std::max(kernelEnergy,other.kernelEnergy);unitStressVelocity=std::max(unitStressVelocity,other.unitStressVelocity);
    }
};

Stats PolynomialChecks(const convex_ports::Cell& input,const rc::Cell& cell) {
    Stats stats;
    const PhysicalOracle oracle(input);
    const auto fields=Fields();
    std::vector<rc::State> states;
    std::vector<Real> norm;
    Real radius=0;
    for(const auto& point:oracle.vertices) radius=std::max(radius,Magnitude(pa::Sub(point,input.center)));
    for(const auto& field:fields) {
        states.push_back(ExactPhysicalState(cell,field));
        const auto& state=states.back();
        Real amplitude=0;
        for(const auto& point:oracle.vertices) {
            const auto expected=Field(field,pa::Sub(point,input.center));
            const auto actual=cell.EvaluateProjectedPhysical(state,point);
            const RV difference{R(actual.x())-expected[0],R(actual.y())-expected[1],R(actual.z())-expected[2]};
            stats.Observe(Magnitude(difference),stats.velocity);
            amplitude=std::max(amplitude,Magnitude(expected));
        }
        for(unsigned face=0;face<input.faces.size();++face)
            for(const auto& triangle:input.faces[face].triangles) {
                const Real area=std::sqrt(owned_metrics::Dot(triangle.areaVector,triangle.areaVector).convert_to<Real>());
                for(const auto& point:triangle.points) {
                    const auto expected=Field(field,pa::Sub(point,input.center));
                    const Real normal=owned_metrics::Dot(triangle.areaVector,expected).convert_to<Real>()/area;
                    stats.Observe(cell.PhysicalNormal(face,state,point)-normal,stats.normal);
                }
            }
        const Real exact=oracle.Kinetic(field,field).convert_to<Real>();
        norm.push_back(exact);
        stats.Observe((cell.Energy(state)-exact/2)/(exact/2),stats.energy);
        const auto expected=oracle.Moments(field);
        const auto actual=cell.PhysicalMoments(state);
        const Real volume=oracle.volume[0].convert_to<Real>();
        for(unsigned a=0;a<3;++a) {
            stats.Observe((actual.mean[a]-expected[4*a].convert_to<Real>())/(volume*amplitude),stats.moments);
            for(unsigned b=0;b<3;++b)
                stats.Observe((actual.first(a,b)-expected[4*a+b+1].convert_to<Real>())/
                              (volume*amplitude*radius),stats.moments);
        }
    }
    for(unsigned a=0;a<fields.size();++a)
        for(unsigned b=0;b<fields.size();++b) {
            const Real expected=oracle.Kinetic(fields[a],fields[b]).convert_to<Real>();
            stats.Observe((cell.Inner(states[a],states[b])-expected)/std::sqrt(norm[a]*norm[b]),stats.work);
        }
    return stats;
}

void KernelChecks(const convex_ports::Cell& input,const rc::Cell& cell,Stats& stats,bool negativeControl) {
    const ek::Oracle oracle(input,cell.framed);
    for(unsigned scaling=0;scaling<2;++scaling) {
        rc::State state;
        state.polynomial.setZero();state.kernel.resize(cell.kernelDimension);
        for(unsigned i=0;i<cell.kernelDimension;++i) state.kernel[i]=(int(i%11)-5)/16.L;
        if(scaling) state.kernel*=.1L*std::sqrt(1000*cell.framed.physicalVolume)/state.kernel.norm();
        const Real energy=cell.Energy(state);
        const Real rms=std::sqrt(2*energy/(1000*cell.framed.physicalVolume));
        const auto published=cell.FaceFlux(state);
        for(unsigned form=0;form<2;++form) {
            std::vector<R> q(cell.faceDimension,R(0));
            for(unsigned row=0;row<cell.faceDimension;++row) {
                if(form==0) q[row]=R(published[row]);
                else for(unsigned column=0;column<cell.kernelDimension;++column)
                    q[row]+=R(cell.kernelFace(row,column))*R(state.kernel[column]);
            }
            const auto reconstructed=oracle.Reconstruct(q,energy);
            if(reconstructed.projectionEnergy!=0) ++stats.exactNonzeroKernel;
            // Unit-z is retained as a stress diagnostic. Its kinetic energy in
            // a microscopic volume implies enormous physical RMS velocities.
            // Report its absolute threshold failures explicitly, alongside the
            // SAME numerical quality and an ADDITIONAL .1m/s physical control.
            if(!scaling) {
                stats.Observe(reconstructed.maxPointLeak,stats.unitStressVelocity,false);
                if(reconstructed.maxPointLeak>1e-8L) ++stats.unitStressAbsoluteFailures;
            } else stats.Observe(reconstructed.maxPointLeak,stats.kernelVelocity);
            stats.Observe(reconstructed.maxScaledMoment,stats.kernelMoment);
            stats.Observe(std::sqrt(reconstructed.energyFraction),stats.kernelEnergy);
            std::printf("RESOLVED_KERNEL seed=%u piece=%u scaling=%s flux=%s declared_energy=%Lg "
                        "physical_rms=%Lg actual_P1_point_leak=%Lg point_leak_over_rms=%Lg "
                        "scaled_P1_moment_leak=%Lg P1_energy_norm_fraction=%Lg exact_zero=%u\n",
                        input.seed,input.piece,scaling?"physical_rms_0.1":"original_unit_z",
                        form?"exact_evaluation_of_published_factors":"flattened_public_FaceFlux",
                        energy,rms,reconstructed.maxPointLeak,reconstructed.maxPointLeak/rms,
                        reconstructed.maxScaledMoment,std::sqrt(reconstructed.energyFraction),
                        unsigned(reconstructed.projectionEnergy==0));
        }
    }
    if(negativeControl) {
        bool detected=false;
        for(unsigned column=0;column<cell.faceDimension && !detected;++column) {
            std::vector<R> absentConstraint(cell.faceDimension,R(0));absentConstraint[column]=1;
            detected=oracle.Reconstruct(absentConstraint,1).projectionEnergy>0;
        }
        ++stats.checks;
        if(!detected) {++stats.failures;throw std::runtime_error("independent kernel oracle failed to detect absent moment constraint");}
        std::printf("RESOLVED_KERNEL_NEGATIVE absent_moment_constraint=detected\n");
    }
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        const double angle=argc>1?std::strtod(argv[1],nullptr):3.2137858346770188e-11;
        using V=glm::dvec3;
        convex_ports::Compiler geometry;
        geometry.Build(1,owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))));
        Stats total;
        for(unsigned owner=0;owner<geometry.cells.size();++owner) {
            const auto& input=geometry.cells[owner];
            const rc::Cell cell(input);
            auto stats=PolynomialChecks(input,cell);
            KernelChecks(input,cell,stats,owner==0);
            total.Merge(stats);
            std::printf("RESOLVED_INDEPENDENT_CELL seed=%u piece=%u volume=%Lg velocity=%Lg normal=%Lg "
                        "energy_relative=%Lg crosswork=%Lg moments=%Lg kernel_point_0.1rms=%Lg "
                        "kernel_scaled_moment=%Lg kernel_energy_norm=%Lg checks=%u failures=%u\n",
                        input.seed,input.piece,input.volume.convert_to<Real>(),stats.velocity,stats.normal,
                        stats.energy,stats.work,stats.moments,stats.kernelVelocity,stats.kernelMoment,
                        stats.kernelEnergy,stats.checks,stats.failures);
        }
        std::printf("RESOLVED_INDEPENDENT_SUMMARY angle=%.17g checks=%u failures=%u velocity=%Lg normal=%Lg "
                    "energy_relative=%Lg crosswork=%Lg moments=%Lg kernel_point_0.1rms=%Lg "
                    "kernel_scaled_moment=%Lg kernel_energy_norm=%Lg original_unit_z_absolute_point_leak=%Lg "
                    "original_unit_z_absolute_threshold_exceedances=%u exact_nonzero_kernel_projections=%u "
                    "threshold=1e-8 original_failures=preserved\n",
                    angle,total.checks,total.failures,total.velocity,total.normal,total.energy,total.work,total.moments,
                    total.kernelVelocity,total.kernelMoment,total.kernelEnergy,total.unitStressVelocity,
                    total.unitStressAbsoluteFailures,total.exactNonzeroKernel);
        return total.failures?1:0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"RESOLVED_INDEPENDENT_ERROR %s\n",error.what());
        return 1;
    }
}
