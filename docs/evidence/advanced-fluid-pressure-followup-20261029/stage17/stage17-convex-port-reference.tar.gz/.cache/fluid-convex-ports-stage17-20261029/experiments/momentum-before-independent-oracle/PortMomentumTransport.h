#pragma once
// PRIVATE fixed-geometry, first-order finite-volume advection of cell-mean
// momentum through the ACTUAL P1 normal ports. Complementary/local fluctuations
// are retained locally; this is not higher-order whole-field advection, moving
// boundaries, a free surface or a production M54 quantity implementation.
#include "VoxelConservativeNetwork.h"
#include "ExactConvexClip.h"
namespace port_momentum {
using namespace stage17_network;
using R=vg::R;using RV=vg::RV;
using World=stage17_conservative_network::Epoch;
using State=stage17_conservative_network::Result;
inline std::array<R,3> Basis(const PhysicalFace& f,const RV& p) {
    const auto delta=vg::Sub(p,f.frame.origin);
    return {R(1),(owned_metrics::Dot(f.frame.edge,delta)-f.frame.midU)/f.frame.spanU,
                 (owned_metrics::Dot(f.frame.transverse,delta)-f.frame.midV)/f.frame.spanV};
}
struct Face {
    unsigned a=0,b=0,fa=0,fb=0,pivot=0;
    std::vector<exact_convex::Triangle> triangles;
    std::array<std::array<R,3>,3> gram{};
    PhysicalFace geometry;
    Face(const World& world,const FaceOwners& owners):a(owners.firstCell),b(owners.secondCell),fa(owners.firstFace),fb(owners.secondFace) {
        const auto& owner=*world.cells[a];geometry=owner.cell.faces[fa];pivot=geometry.frame.pivot;
        for(const auto& input:geometry.triangles){exact_convex::Triangle t;t.areaVector=input.areaVector;t.plane=input.plane;
            for(unsigned v=0;v<3;++v)for(unsigned axis=0;axis<3;++axis)t.points[v][axis]=input.points[v][axis]+owner.cell.center[axis];triangles.push_back(t);
            std::array<std::array<R,3>,3> values;std::array<R,3> sums{};for(unsigned v=0;v<3;++v){values[v]=Basis(geometry,t.points[v]);for(unsigned i=0;i<3;++i)sums[i]+=values[v][i];}
            const R area=abs(t.areaVector[pivot]);for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j){R product=sums[i]*sums[j];for(unsigned v=0;v<3;++v)product+=values[v][i]*values[v][j];gram[i][j]+=area*product/12;}
        }
    }
    static R Det(const std::array<std::array<R,3>,3>& m){return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]);}
    std::array<R,3> Coefficients(const std::array<R,3>& moments) const {const R determinant=Det(gram);if(determinant==0)throw std::runtime_error("momentum port Gram is singular");std::array<R,3> result;for(unsigned i=0;i<3;++i){auto m=gram;for(unsigned row=0;row<3;++row)m[row][i]=moments[row];result[i]=Det(m)/determinant;}return result;}
    R Value(const RV& p,const std::array<R,3>& coefficients) const {const auto basis=Basis(geometry,p);R result=0;for(unsigned i=0;i<3;++i)result+=basis[i]*coefficients[i];return result;}
    R Positive(const exact_convex::Triangle& triangle,const std::array<R,3>& coefficients,int sign) const {
        std::vector<RV> clipped;for(unsigned i=0;i<3;++i){const RV& a=triangle.points[i];const RV& b=triangle.points[(i+1)%3];const R va=sign*Value(a,coefficients),vb=sign*Value(b,coefficients);if(va>=0)clipped.push_back(a);if((va<0&&vb>0)||(va>0&&vb<0)){RV p;const R t=va/(va-vb);for(unsigned axis=0;axis<3;++axis)p[axis]=a[axis]+t*(b[axis]-a[axis]);clipped.push_back(std::move(p));}}
        R result=0;if(clipped.size()<3)return result;
        for(unsigned i=1;i+1<clipped.size();++i){const std::array<RV,3> p={clipped[0],clipped[i],clipped[i+1]};const auto area=owned_metrics::Cross(vg::Sub(p[1],p[0]),vg::Sub(p[2],p[0]));const R measure=abs(area[pivot])/2;R value=0;for(const auto& x:p)value+=sign*Value(x,coefficients);result+=measure*value/3;}return result;
    }
    std::array<R,2> Directed(const std::array<R,3>& moments) const {const auto c=Coefficients(moments);std::array<R,2> result{};for(const auto& triangle:triangles){result[0]+=Positive(triangle,c,1);result[1]+=Positive(triangle,c,-1);}if(result[0]<0||result[1]<0||result[0]-result[1]!=moments[0])throw std::runtime_error("momentum counterflow split loses an exact primary face mean");return result;}
};
struct Prediction {
    std::vector<Vector> raw;
    RV exactTransportImpulse{};
    Real energyBefore=0,energyAfter=0,momentumError=0;
    unsigned directedPackets=0;
};
struct Transport {
    const World& world;
    const std::shared_ptr<Factor> generation;
    std::vector<Face> ports;
    explicit Transport(const World& source):world(source),generation(source.factor) {
        if(world.boundary!=Boundary::Sealed)throw std::invalid_argument("bounded momentum reference requires fixed closed walls");
        for(const auto& [key,owners]:world.allPorts){if(owners.secondCell==~0u)throw std::invalid_argument("bounded momentum reference has an open port");ports.emplace_back(world,owners);}
    }
    Prediction Apply(const State& state,const R& dt) const {
        if(dt<=0||world.factor!=generation||state.local.size()!=world.cells.size()||state.exactFaceMeans.size()!=world.cells.size())throw std::invalid_argument("momentum transport invalid time/state or stale geometry epoch");
        Prediction result;result.raw=state.local;
        std::vector<RV> mean(world.cells.size()),impulse(world.cells.size());std::vector<R> volumeChange(world.cells.size()),outflow(world.cells.size());
        for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];if(state.local[c].size()!=local.op.dimension||!state.local[c].allFinite())throw std::invalid_argument("momentum transport invalid physical kinetic source");for(unsigned face=0;face<local.cell.faces.size();++face)if(local.cell.faces[face].kind==Kind::Solid||world.Outer(local.cell.faces[face].key))for(unsigned axis=0;axis<3;++axis)if(state.local[c][3*face+axis]!=0)throw std::invalid_argument("fixed-geometry momentum reference received a moving prescribed boundary");for(unsigned a=0;a<3;++a)mean[c][a]=R(state.local[c][local.op.MeanOffset()+a]/local.op.geometry.volume[0]);result.energyBefore+=local.op.Energy(state.local[c]);}
        for(const auto& port:ports){const auto& first=state.local[port.a];const std::array<R,3> q={state.exactFaceMeans[port.a][port.fa],R(first[3*port.fa+1]),R(first[3*port.fa+2])};const auto flux=port.Directed(q);
            for(unsigned direction=0;direction<2;++direction){const R amount=dt*flux[direction];if(amount==0)continue;const unsigned donor=direction?port.b:port.a,receiver=direction?port.a:port.b;++result.directedPackets;outflow[donor]+=amount;volumeChange[donor]-=amount;volumeChange[receiver]+=amount;const R density=R(world.cells[donor]->op.geometry.density);if(density!=R(world.cells[receiver]->op.geometry.density))throw std::invalid_argument("bounded momentum reference does not silently mix densities");for(unsigned a=0;a<3;++a){const R change=density*amount*mean[donor][a];impulse[donor][a]-=change;impulse[receiver][a]+=change;}}
        }
        vm::Vec3 before=vm::Vec3::Zero(),after=vm::Vec3::Zero();
        for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];if(outflow[c]>local.cell.exactVolume)throw std::invalid_argument("momentum transport exceeds donor availability; transaction rejected");if(volumeChange[c]!=0)throw std::invalid_argument("fixed full-capacity momentum transport requires exact per-cell geometric balance");vm::Vec3 change;for(unsigned a=0;a<3;++a){change[a]=(impulse[c][a]/(R(local.op.geometry.density)*local.cell.exactVolume)).convert_to<Real>();result.exactTransportImpulse[a]+=impulse[c][a];before[a]+=local.op.geometry.density*state.local[c][local.op.MeanOffset()+a];}vm::Affine affine=vm::Affine::Zero();for(unsigned a=0;a<3;++a)affine[4*a]=change[a];result.raw[c]+=local.op.InterpolateAffineDOFs(affine);for(unsigned a=0;a<3;++a)after[a]+=local.op.geometry.density*result.raw[c][local.op.MeanOffset()+a];result.energyAfter+=local.op.Energy(result.raw[c]);}
        if(result.exactTransportImpulse!=RV{})throw std::runtime_error("paired momentum packets create material impulse");result.momentumError=(after-before).norm();
        if(result.energyAfter>result.energyBefore+1e-12L*std::max<Real>(1,result.energyBefore))throw std::runtime_error("upwind mean-momentum transport unexpectedly creates physical kinetic energy");
        return result;
    }
};
} // namespace port_momentum
