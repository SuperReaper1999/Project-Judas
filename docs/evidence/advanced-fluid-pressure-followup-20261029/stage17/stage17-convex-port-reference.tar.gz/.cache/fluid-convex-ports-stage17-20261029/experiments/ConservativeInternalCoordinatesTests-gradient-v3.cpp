#include "ConservativeInternalCoordinates.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace cc=stage17_conservative;
namespace lc=stage17_condensed;
using namespace stage17_network;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;if(!condition) throw std::runtime_error(message);
}
Vector BoundaryState(const lc::Epoch& network,unsigned group,const lc::Result& result,const Twist& body) {
    const auto& domain=network.subdomains[group];
    Vector boundary(3*domain.boundaryKeys.size()+6);
    for(unsigned face=0;face<domain.boundaryKeys.size();++face)
        boundary.segment(3*face,3)=network.maps[group].signs[face]*
            result.flux.segment(network.maps[group].columns[face],3);
    boundary.tail(6)=body;return boundary;
}
std::vector<Vector> Predictors(const lc::Epoch& network,unsigned scenario) {
    auto affine=network.Constant(scenario==0?vm::Vec3(0,-.04L,0):vm::Vec3::Zero());
    if(scenario==2) for(unsigned cell=0;cell<network.cells.size();++cell) {
        affine[cell][0]=.001L*(1+network.cells[cell]->cell.seed+3*network.cells[cell]->cell.piece);
        affine[cell][3]=.015L;affine[cell][6]=-.01L;affine[cell][9]=.012L;
    }
    std::vector<Vector> result;
    for(unsigned cell=0;cell<network.cells.size();++cell)
        result.push_back(network.cells[cell]->op.InterpolateAffineDOFs(affine[cell]));
    return result;
}
void Run(double angle,bool tiny) {
    using V=glm::dvec3;
    lc::Epoch network(1,owned_cut::BoxPlanes(V(.5),V(.2),
        glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))));
    for(unsigned scenario=0;scenario<3;++scenario) {
        const auto predictors=Predictors(network,scenario);
        Twist body=Twist::Zero();if(scenario==1) body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto solved=network.SolveRaw(predictors,body);
        Real maxEndpoint=0,maxObjective=0,maxGradient=0,maxGaugeGradient=0,maxFreeGradient=0,maxScaledStationarity=0,maxBeforeRate=0,maxRoundedRate=0,maxRootRate=0,maxBodyChange=0;
        unsigned exactNonroots=0,freeVariables=0;
        for(unsigned group=0;group<network.subdomains.size();++group) {
            const auto& domain=network.subdomains[group];
            cc::Coordinates coordinates(network,group);freeVariables+=coordinates.freeVariables;
            Check(coordinates.root<domain.cells.size(),"conservative root is missing");
            for(unsigned piece=0;piece<domain.cells.size();++piece)
                Check(network.cells[domain.cells[coordinates.root]]->cell.exactVolume>=
                      network.cells[domain.cells[piece]]->cell.exactVolume,"conservative root is not largest exact volume");
            const auto boundary=BoundaryState(network,group,solved,body);
            const auto source=coordinates.Prepare(predictors);
            const auto state=coordinates.Reconstruct(source,boundary);
            const auto oldSource=domain.PrepareSource(network.cells,predictors);
            const Vector old=oldSource.offset-domain.inverseCoupling*boundary;
            const Vector oldGradient=domain.reducedMass*boundary-oldSource.reducedLoad;
            const Vector gradientDifference=state.boundaryGradient-oldGradient;
            Vector macro(coordinates.externalVariables);
            for(unsigned i=0;i<coordinates.externalVariables;++i)
                macro[i]=coordinates.macroClosure[i].convert_to<Real>();
            // Changing the omitted local cell changes the pressure gauge.
            // Only gradients tangent to the SAME remaining macro constraint
            // are comparable. Global macro pressure restores the normal part.
            Vector tangent=gradientDifference;
            if(macro.squaredNorm()>0)
                tangent-=macro*(macro.dot(gradientDifference)/macro.squaredNorm());
            maxGradient=std::max(maxGradient,tangent.norm()/std::max<Real>(1,oldGradient.norm()));
            maxGaugeGradient=std::max(maxGaugeGradient,gradientDifference.norm());
            maxObjective=std::max(maxObjective,std::abs(state.objective-state.reducedObjective)/
                                 std::max<Real>(1,source.predictorEnergy));
            maxBodyChange=std::max(maxBodyChange,coordinates.maximumBodyMeanCoefficientChange);
            const Vector residual=coordinates.freeMass*state.free+coordinates.freeBoundary*boundary-source.freeLoad;
            const Real rawStationarity=residual.norm();
            const Real scaledStationarity=(coordinates.freeScale.asDiagonal()*residual).norm()/
                std::max<Real>({1,(coordinates.freeScale.asDiagonal()*source.freeLoad).norm(),
                                (coordinates.freeScale.asDiagonal()*coordinates.freeBoundary*boundary).norm()});
            maxFreeGradient=std::max(maxFreeGradient,rawStationarity);
            maxScaledStationarity=std::max(maxScaledStationarity,scaledStationarity);
            if(rawStationarity>=1e-10L)
                printf("CONSERVATIVE_FREE_GRADIENT angle=%.17g scenario=%u group=%u raw=%Lg scaled=%Lg\n",
                    angle,scenario,group,rawStationarity,scaledStationarity);
            // Raw derivatives have different units/scales for q1/q2 on tiny
            // apertures. Check the SAME equilibrated coordinates used by the
            // SPD solve, while all physical endpoint/work bounds remain fixed.
            Check(scaledStationarity<1e-10L,
                  "free-coordinate kinetic optimum violates scaled stationarity");
            for(unsigned piece=0;piece<domain.maps.size();++piece) {
                const auto& map=domain.maps[piece];const auto& physical=*network.cells[map.cell];
                const Vector oldFaces=map.internal*old.head(domain.internalVariables)+map.boundary*boundary;
                const Vector oldRaw=physical.condensed.Reconstruct(oldFaces,oldSource.pieces[piece]);
                const Vector difference=state.roundedKineticLocal[piece]-oldRaw;
                const Real norm=std::sqrt(std::abs(difference.dot(physical.op.mass*difference)));
                maxEndpoint=std::max(maxEndpoint,norm/std::max<Real>(1,std::sqrt(std::abs(oldRaw.dot(physical.op.mass*oldRaw)))));
                cc::Exact oldSum=0,roundedSum=0;
                for(unsigned face=0;face<physical.cell.faces.size();++face) {
                    oldSum+=cc::Exact(solved.local[map.cell][3*face]);
                    roundedSum+=cc::Exact(state.faces[piece][3*face]);
                    const auto& patch=physical.cell.faces[face];
                    if(patch.kind!=Kind::Internal) {
                        const auto expected=cc::Dot(coordinates.pieces[piece].faceExternalMeans[face],cc::ExactValues(boundary));
                        Check(state.conservative.faceMeans[piece][face]==expected,
                              "conservative coordinates alter a primary external/solid mean flux");
                    }
                }
                const auto volume=physical.cell.exactVolume;
                maxBeforeRate=std::max(maxBeforeRate,abs(oldSum/volume).convert_to<Real>());
                if(piece==coordinates.root) {
                    Check(state.conservative.cellSums[piece]==state.conservative.externalSum,
                          "root residual is not the unchanged macro external residual");
                    maxRootRate=std::max(maxRootRate,abs(state.conservative.cellSums[piece]/volume).convert_to<Real>());
                } else {
                    Check(state.conservative.cellSums[piece]==0,
                          "non-root physical cell is not EXACTLY conservative");
                    ++exactNonroots;
                    maxRoundedRate=std::max(maxRoundedRate,abs(roundedSum/volume).convert_to<Real>());
                }
            }
            std::map<PortKey,cc::Exact> paired;
            for(unsigned piece=0;piece<coordinates.pieces.size();++piece)
                for(unsigned face=0;face<coordinates.pieces[piece].physical->cell.faces.size();++face) {
                    const auto& patch=coordinates.pieces[piece].physical->cell.faces[face];
                    if(patch.kind==Kind::Internal) paired[patch.key]+=state.conservative.faceMeans[piece][face];
                }
            for(const auto& [key,sum]:paired) Check(sum==0,"opposite internal exact primary means do not cancel");
        }
        Check(maxEndpoint<1e-10L,"conservative parameterization changes physical kinetic endpoint");
        Check(maxObjective<1e-10L,"conservative elimination loses source constants/work");
        Check(maxGradient<1e-10L,"conservative exact mean geometry changes native work gradient");
        Check(maxRootRate<1e-12L,"largest-root macro divergence remains excessive");
        if(tiny&&scenario==1)
            Check(maxRoundedRate>1e-8L,"rounded mean storage negative control did not reveal the tiny-cell defect");
        printf("CONSERVATIVE_COORDINATES angle=%.17g scenario=%u free_variables=%u exact_nonroots=%u old_max_mean_div=%Lg exact_nonroot_mean_div=0 root_mean_div=%Lg rounded_storage_negative_mean_div=%Lg field_error=%Lg objective_error=%Lg tangent_gradient_error=%Lg raw_gauge_gradient_difference=%Lg raw_free_gradient=%Lg scaled_stationarity=%Lg body_mean_coefficient_change=%Lg\n",
            angle,scenario,freeVariables,exactNonroots,maxBeforeRate,maxRootRate,maxRoundedRate,
            maxEndpoint,maxObjective,maxGradient,maxGaugeGradient,maxFreeGradient,maxScaledStationarity,maxBodyChange);
    }
}
int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        Run(0,false);Run(.17,false);Run(3.2137858346770188e-11,true);
        printf("CONSERVATIVE_COORDINATES_SUMMARY checks=%u failures=0\n",checks);return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
