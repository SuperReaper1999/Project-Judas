#pragma once

// Stage17 PRIVATE pressure/kinetic prototype. Convex physical cells and their
// separately owned fluid-fluid/solid ports are retained. This is not a moving
// water, momentum-transport or production-engine implementation.
#include "ConvexPorts.h"
#include "../fluid-runtime-candidates-stage16-20261029/geometry/FactoredFaceMetrics.h"
#include "../fluid-runtime-candidates-stage16-20261029/vem/CondensedCell.h"
#include <Eigen/SparseCholesky>
#include <Eigen/SparseLU>
#include <cfenv>
#include <chrono>
#include <memory>
#include <numeric>
#include <set>

namespace stage17_network {
namespace vm=JudasFluidVem;
namespace vg=stage16_geometry;
namespace fm=stage16_factored;
using Real=vm::Real;
using Matrix=vm::Matrix;
using Vector=vm::Vector;
using Twist=Eigen::Matrix<Real,6,1>;
using Sparse=Eigen::SparseMatrix<Real>;
using Triplet=Eigen::Triplet<Real>;
using Clock=std::chrono::steady_clock;
inline double Milliseconds(Clock::time_point start) {
    return std::chrono::duration<double,std::milli>(Clock::now()-start).count();
}

enum class Boundary { Sealed, OpenTop };

// Defined after the geometry header's concrete names are established.
// Geometry adapter preserves each logical port separately, even if several
// coplanar ports share one supporting plane.
using PortKey=convex_ports::PortKey;
using Kind=convex_ports::Kind;
using Box=convex_ports::Box;

struct PhysicalFace : fm::Face {
    Kind kind=Kind::Background;
    PortKey key;
};
struct PhysicalCell {
    unsigned seed=0,piece=0;
    vg::RV center{};
    vg::R exactVolume=0;
    unsigned integrationSimplexes=0;
    vm::CellGeometry geometry;
    std::vector<PhysicalFace> faces;
};

inline PhysicalCell BuildMetrics(const convex_ports::Cell& input,const vg::R& scale) {
    if(scale<=0) throw std::invalid_argument("Stage17 physical scale must be positive");
    PhysicalCell cell;
    cell.seed=input.seed;
    cell.piece=input.piece;
    cell.center=input.center;
    for(auto& coordinate:cell.center) coordinate*=scale;
    cell.exactVolume=input.volume*scale*scale*scale;
    cell.integrationSimplexes=input.integration.size();
    std::array<stage16_fast_geometry::Sum,20> moments;
    vg::R integratedVolume=0;
    for(const auto& simplex:input.integration) {
        std::array<stage16_fast_geometry::Point,4> points;
        for(unsigned vertex=0;vertex<4;++vertex) {
            vg::RV physical=simplex.points[vertex];
            for(auto& coordinate:physical) coordinate*=scale;
            points[vertex]=stage16_fast_geometry::Rounded(vg::Sub(physical,cell.center));
        }
        const vg::R exactMeasure=simplex.volume*scale*scale*scale;
        if(exactMeasure<=0) throw std::runtime_error("Stage17 nonpositive integration simplex");
        integratedVolume+=exactMeasure;
        const Real measure=exactMeasure.convert_to<Real>();
        if(!(measure>0)||!std::isfinite(measure))
            throw std::runtime_error("Stage17 positive geometry is not representable");
        for(unsigned monomial=0;monomial<20;++monomial)
            moments[monomial].Add(measure*stage16_fast_geometry::MonomialAverage<4>(points,monomial));
    }
    if(integratedVolume!=cell.exactVolume||cell.exactVolume<=0)
        throw std::runtime_error("Stage17 convex integration volume mismatch");
    for(unsigned monomial=0;monomial<20;++monomial)
        cell.geometry.volume[monomial]=moments[monomial].Get();
    cell.geometry.volume[0]=cell.exactVolume.convert_to<Real>();
    for(const auto& patch:input.faces) {
        if(patch.kind!=patch.key.kind ||
           (patch.kind==Kind::Solid ? (patch.solid<0||patch.solid>=6) : patch.solid!=-1))
            throw std::runtime_error("Stage17 physical port classification is inconsistent");
        PhysicalFace face;
        face.kind=patch.kind;
        face.key=patch.key;
        face.solid=patch.solid;
        face.background=patch.key.background;
        face.triangles=patch.triangles;
        for(auto& triangle:face.triangles) {
            for(auto& point:triangle.points)
                for(auto& coordinate:point) coordinate*=scale;
            for(auto& coordinate:triangle.areaVector) coordinate*=scale*scale;
        }
        // Each physical patch receives its OWN P1 trace, including coplanar
        // fluid and solid ports. Never merge patches by supporting plane ID.
        auto metric=fm::CollectFace(face,cell.center);
        cell.geometry.faces.push_back(std::move(metric));
        for(auto& triangle:face.triangles)
            for(auto& point:triangle.points) point=vg::Sub(point,cell.center);
        cell.faces.push_back(std::move(face));
    }
    return cell;
}

inline bool SameFrame(const PhysicalFace& a,const PhysicalFace& b) {
    const auto& x=a.frame;
    const auto& y=b.frame;
    return a.projectedMeasure==b.projectedMeasure && x.origin==y.origin &&
        x.edge==y.edge && x.transverse==y.transverse && x.cross==y.cross &&
        x.minU==y.minU && x.maxU==y.maxU && x.minV==y.minV && x.maxV==y.maxV;
}

struct Local {
    PhysicalCell cell;
    vm::LocalOperator op;
    vm::CondensedCell condensed;
    explicit Local(PhysicalCell input)
        :cell(std::move(input)),op(vm::Build(cell.geometry)),condensed(op) {}
};
struct FaceMap {
    std::vector<int> column;
    std::vector<Real> sign;
    Matrix body;
};
struct FaceOwners {
    unsigned firstCell=0,firstFace=0;
    unsigned secondCell=~0u,secondFace=~0u;
    unsigned id=0;
};
struct Result {
    Vector flux,pressure;
    std::vector<Vector> local;
    Twist reaction=Twist::Zero();
    Real energy=0,predictorEnergy=0,objective=0,balance=0,stationarity=0,energyIdentity=0;
    Real scaledEquationResidual=0;
    double solveMs=0;
};
struct Factor {
    Vector velocityScale,pressureScale;
    std::vector<unsigned> retainedRows;
    std::vector<int> pressureIndex;
    Sparse saddle;
    Eigen::SparseLU<Sparse,Eigen::COLAMDOrdering<int>> solver;
    bool hasSystem=false;
};

struct Network {
    unsigned grid=0;
    Box box;
    vg::R physicalScale=1;
    Boundary boundary=Boundary::Sealed;
    std::vector<std::shared_ptr<const Local>> cells;
    std::vector<FaceMap> maps;
    std::map<PortKey,FaceOwners> interfaces;
    std::vector<std::vector<unsigned>> components;
    std::vector<bool> componentOpen;
    Sparse mass,continuity;
    Matrix bodyContinuity,mixedBody,bodyMass;
    std::shared_ptr<Factor> factor;
    unsigned integrationSimplexes=0,maxLocalDofs=0;
    double geometryMs=0,localMs=0,assemblyMs=0,factorMs=0;

    Network(unsigned count,const Box& planes,const vg::R& scale=1,
            Boundary condition=Boundary::Sealed)
        :grid(count),box(planes),physicalScale(scale),boundary(condition) {
        CheckRounding();
        if(!grid||grid>4||scale<=0)
            throw std::invalid_argument("Stage17 bounded reference domain/scale is invalid");
        const auto start=Clock::now();
        convex_ports::Compiler geometry;
        geometry.Build(grid,box);
        geometryMs=Milliseconds(start);
        BuildCells(geometry);
        Assemble();
    }

    Network(const convex_ports::Compiler& geometry,const vg::R& scale=1,
            Boundary condition=Boundary::Sealed)
        :grid(geometry.grid),box(geometry.box),physicalScale(scale),boundary(condition) {
        CheckRounding();
        if(!grid||grid>4||scale<=0)
            throw std::invalid_argument("Stage17 bounded reference domain/scale is invalid");
        BuildCells(geometry);
        Assemble();
    }

    static void CheckRounding() {
        if(std::fegetround()!=FE_TONEAREST)
            throw std::invalid_argument("Stage17 requires round-to-nearest");
    }

    void BuildCells(const convex_ports::Compiler& geometry) {
        for(const auto& input:geometry.cells) {
            const auto metricStart=Clock::now();
            auto metrics=BuildMetrics(input,physicalScale);
            geometryMs+=Milliseconds(metricStart);
            const auto operatorStart=Clock::now();
            cells.push_back(std::make_shared<Local>(std::move(metrics)));
            localMs+=Milliseconds(operatorStart);
        }
    }

    bool Outer(const PortKey& key) const {
        if(key.kind!=Kind::Background) return false;
        for(unsigned axis=0;axis<3;++axis) {
            bool low=true,high=true;
            for(const auto& point:key.background) {
                low=low&&(point[axis]==0);
                high=high&&(point[axis]==int(grid));
            }
            if(low||high) return true;
        }
        return false;
    }
    bool Open(const PortKey& key) const {
        if(boundary!=Boundary::OpenTop||key.kind!=Kind::Background) return false;
        for(const auto& point:key.background) if(point[1]!=int(grid)) return false;
        return true;
    }
    bool Unknown(const PhysicalFace& face) const {
        return face.kind!=Kind::Solid && (!Outer(face.key)||Open(face.key));
    }

    void DiscoverPorts() {
        interfaces.clear();
        integrationSimplexes=0;
        maxLocalDofs=0;
        for(unsigned owner=0;owner<cells.size();++owner) {
            const auto& local=*cells[owner];
            integrationSimplexes+=local.cell.integrationSimplexes;
            maxLocalDofs=std::max(maxLocalDofs,local.op.dimension);
            for(unsigned face=0;face<local.cell.faces.size();++face) {
                const auto& patch=local.cell.faces[face];
                if(!Unknown(patch)) continue;
                auto [at,inserted]=interfaces.emplace(patch.key,FaceOwners{owner,face});
                if(!inserted) {
                    auto& record=at->second;
                    if(record.secondCell!=~0u)
                        throw std::runtime_error("Stage17 port has more than two fluid owners");
                    record.secondCell=owner;
                    record.secondFace=face;
                }
            }
        }
        unsigned id=0;
        for(auto& [key,record]:interfaces) {
            record.id=id++;
            if(record.secondCell==~0u) {
                if(!Open(key)) throw std::runtime_error("Stage17 interior port has no opposite fluid owner");
                continue;
            }
            const auto& a=*cells[record.firstCell];
            const auto& b=*cells[record.secondCell];
            if(!SameFrame(a.cell.faces[record.firstFace],b.cell.faces[record.secondFace]))
                throw std::runtime_error("Stage17 opposite port geometry certificates differ");
            const auto normal=a.op.geometry.faces[record.firstFace].normal+
                              b.op.geometry.faces[record.secondFace].normal;
            if(normal.norm()>1e-15L)
                throw std::runtime_error("Stage17 opposite port normals are not opposing");
        }
    }

    FaceMap BuildMap(unsigned owner) const {
        const auto& local=*cells[owner];
        const unsigned count=local.cell.faces.size();
        FaceMap result;
        result.column.assign(count,-1);
        result.sign.assign(count,0);
        result.body=Matrix::Zero(3*count,6);
        vm::Vec3 center;
        for(unsigned axis=0;axis<3;++axis)
            center[axis]=local.cell.center[axis].convert_to<Real>();
        for(unsigned face=0;face<count;++face) {
            const auto& patch=local.cell.faces[face];
            if(patch.kind==Kind::Solid) {
                for(unsigned degree=0;degree<6;++degree) {
                    vm::Vec3 linear=vm::Vec3::Zero(),angular=vm::Vec3::Zero();
                    if(degree<3) linear[degree]=1;
                    else {
                        angular[degree-3]=1;
                        linear=angular.cross(center);
                    }
                    result.body.block(3*face,degree,3,1)=
                        (local.op.polynomialDofs*vm::RigidAffine(linear,angular)).segment(3*face,3);
                }
            } else if(Unknown(patch)) {
                const auto& port=interfaces.at(patch.key);
                result.column[face]=3*port.id;
                result.sign[face]=port.firstCell==owner?1:-1;
            }
        }
        return result;
    }

    void Assemble() {
        CheckRounding();
        const auto start=Clock::now();
        DiscoverPorts();
        maps.clear();
        const unsigned variables=3*interfaces.size();
        bodyContinuity=Matrix::Zero(cells.size(),6);
        mixedBody=Matrix::Zero(variables,6);
        bodyMass=Matrix::Zero(6,6);
        std::vector<Triplet> kineticEntries,continuityEntries;
        for(unsigned owner=0;owner<cells.size();++owner) {
            const auto& local=*cells[owner];
            auto map=BuildMap(owner);
            const auto& kinetic=local.condensed.faceMass;
            const Matrix kineticBody=kinetic*map.body;
            bodyMass+=map.body.transpose()*kineticBody;
            bodyContinuity.row(owner)=local.condensed.closure*map.body;
            for(unsigned face=0;face<local.cell.faces.size();++face) {
                if(map.column[face]<0) continue;
                for(unsigned component=0;component<3;++component) {
                    const unsigned row=map.column[face]+component;
                    const unsigned localRow=3*face+component;
                    const Real sign=map.sign[face];
                    const Real rate=local.condensed.closure[localRow]*sign;
                    if(rate!=0) continuityEntries.emplace_back(owner,row,rate);
                    mixedBody.row(row)+=sign*kineticBody.row(localRow);
                    for(unsigned other=0;other<local.cell.faces.size();++other) {
                        if(map.column[other]<0) continue;
                        for(unsigned axis=0;axis<3;++axis) {
                            const Real value=sign*map.sign[other]*kinetic(localRow,3*other+axis);
                            if(value!=0) kineticEntries.emplace_back(row,map.column[other]+axis,value);
                        }
                    }
                }
            }
            maps.push_back(std::move(map));
        }
        mass.resize(variables,variables);
        mass.setFromTriplets(kineticEntries.begin(),kineticEntries.end());
        continuity.resize(cells.size(),variables);
        continuity.setFromTriplets(continuityEntries.begin(),continuityEntries.end());
        assemblyMs=Milliseconds(start);
        BuildFactor();
    }

    void BuildComponents() {
        std::vector<unsigned> parent(cells.size());
        std::iota(parent.begin(),parent.end(),0);
        const auto root=[&](unsigned cell) {
            while(parent[cell]!=cell) cell=parent[cell];
            return cell;
        };
        for(const auto& [key,port]:interfaces)
            if(port.secondCell!=~0u)
                parent[root(port.secondCell)]=root(port.firstCell);
        std::set<unsigned> openRoots;
        for(const auto& [key,port]:interfaces)
            if(port.secondCell==~0u) openRoots.insert(root(port.firstCell));
        components.clear();
        componentOpen.clear();
        std::map<unsigned,unsigned> groups;
        factor->retainedRows.clear();
        for(unsigned cell=0;cell<cells.size();++cell) {
            auto [at,inserted]=groups.emplace(root(cell),components.size());
            if(inserted) {
                components.emplace_back();
                componentOpen.push_back(openRoots.count(root(cell))!=0);
            }
            components[at->second].push_back(cell);
            // Exactly one redundant constant pressure is removed per SEALED
            // connected component. Open components retain every pressure row.
            if(!inserted||componentOpen[at->second]) factor->retainedRows.push_back(cell);
        }
    }

    void BuildFactor() {
        const auto start=Clock::now();
        factor=std::make_shared<Factor>();
        BuildComponents();
        auto& prepared=*factor;
        const unsigned variables=mass.rows();
        prepared.velocityScale.resize(variables);
        for(unsigned column=0;column<variables;++column) {
            const Real diagonal=mass.coeff(column,column);
            if(!(diagonal>0)||!std::isfinite(diagonal))
                throw std::runtime_error("Stage17 global kinetic metric has a nonpositive diagonal");
            prepared.velocityScale[column]=1/std::sqrt(diagonal);
        }
        const Sparse scaledMass=prepared.velocityScale.asDiagonal()*mass*prepared.velocityScale.asDiagonal();
        if(variables) {
            Eigen::SimplicialLDLT<Sparse> positivity;
            positivity.compute(scaledMass);
            if(positivity.info()!=Eigen::Success||(positivity.vectorD().array()<=0).any())
                throw std::runtime_error("Stage17 global kinetic metric is not positive");
        }
        const unsigned pressures=prepared.retainedRows.size();
        prepared.pressureIndex.assign(cells.size(),-1);
        prepared.pressureScale.resize(pressures);
        for(unsigned row=0;row<pressures;++row)
            prepared.pressureIndex[prepared.retainedRows[row]]=row;
        std::vector<Real> squaredNorm(pressures,0);
        for(unsigned column=0;column<unsigned(continuity.outerSize());++column)
            for(Sparse::InnerIterator item(continuity,column);item;++item) {
                const int pressure=prepared.pressureIndex[item.row()];
                if(pressure<0) continue;
                const Real value=item.value()*prepared.velocityScale[item.col()];
                squaredNorm[pressure]+=value*value;
            }
        for(unsigned row=0;row<pressures;++row) {
            if(!(squaredNorm[row]>0))
                throw std::runtime_error("Stage17 non-gauge continuity row has no fluid port");
            prepared.pressureScale[row]=1/std::sqrt(squaredNorm[row]);
        }
        std::vector<Triplet> entries;
        for(unsigned column=0;column<unsigned(scaledMass.outerSize());++column)
            for(Sparse::InnerIterator item(scaledMass,column);item;++item)
                entries.emplace_back(item.row(),item.col(),item.value());
        for(unsigned column=0;column<unsigned(continuity.outerSize());++column)
            for(Sparse::InnerIterator item(continuity,column);item;++item) {
                const int pressure=prepared.pressureIndex[item.row()];
                if(pressure<0) continue;
                const Real value=prepared.pressureScale[pressure]*item.value()*prepared.velocityScale[item.col()];
                entries.emplace_back(variables+pressure,item.col(),value);
                entries.emplace_back(item.col(),variables+pressure,value);
            }
        prepared.saddle.resize(variables+pressures,variables+pressures);
        prepared.saddle.setFromTriplets(entries.begin(),entries.end());
        prepared.saddle.makeCompressed();
        if(prepared.saddle.rows()) {
            prepared.solver.compute(prepared.saddle);
            if(prepared.solver.info()!=Eigen::Success)
                throw std::runtime_error("Stage17 sparse pressure/kinetic factor failed");
            prepared.hasSystem=true;
        }
        factorMs=Milliseconds(start);
    }

    void CheckPrescribedFlux(const Twist& twist) const {
        for(unsigned group=0;group<components.size();++group) {
            if(componentOpen[group]) continue;
            Real sum=0,magnitude=0;
            for(unsigned cell:components[group]) {
                const Real rate=(bodyContinuity.row(cell)*twist)[0];
                sum+=rate;
                magnitude+=std::abs(rate);
            }
            if(std::abs(sum)>128*std::numeric_limits<Real>::epsilon()*magnitude)
                throw std::invalid_argument("Stage17 prescribed body flux changes sealed component volume");
        }
    }

    Result SolveRaw(const std::vector<Vector>& predictors,const Twist& twist=Twist::Zero()) const {
        CheckRounding();
        const auto start=Clock::now();
        if(predictors.size()!=cells.size()||!twist.allFinite())
            throw std::invalid_argument("Stage17 physical source has invalid size or value");
        CheckPrescribedFlux(twist);
        Result result;
        std::vector<vm::CondensedSource> sources;
        sources.reserve(cells.size());
        Vector load=Vector::Zero(mass.rows());
        for(unsigned owner=0;owner<cells.size();++owner) {
            const auto& local=*cells[owner];
            if(predictors[owner].size()!=local.op.dimension||!predictors[owner].allFinite())
                throw std::invalid_argument("Stage17 raw kinetic predictor is invalid");
            auto source=local.condensed.SourceFromPredictor(predictors[owner]);
            result.predictorEnergy+=source.predictorEnergyConstant;
            for(unsigned face=0;face<local.cell.faces.size();++face)
                if(maps[owner].column[face]>=0)
                    load.segment(maps[owner].column[face],3)+=
                        maps[owner].sign[face]*source.faceLoad.segment(3*face,3);
            sources.push_back(std::move(source));
        }
        if(!std::isfinite(result.predictorEnergy)||result.predictorEnergy>std::numeric_limits<double>::max())
            throw std::invalid_argument("Stage17 physical source energy is not representable");
        load-=mixedBody*twist;
        const auto& prepared=*factor;
        const unsigned variables=mass.rows(),pressures=prepared.retainedRows.size();
        Vector rhs=Vector::Zero(variables+pressures);
        rhs.head(variables)=prepared.velocityScale.asDiagonal()*load;
        for(unsigned row=0;row<pressures;++row)
            rhs[variables+row]=-prepared.pressureScale[row]*
                (bodyContinuity.row(prepared.retainedRows[row])*twist)[0];
        Vector solution=Vector::Zero(rhs.size());
        if(prepared.hasSystem) {
            solution=prepared.solver.solve(rhs);
            if(prepared.solver.info()!=Eigen::Success||!solution.allFinite())
                throw std::runtime_error("Stage17 sparse pressure/kinetic solve failed");
        }
        result.scaledEquationResidual=(prepared.saddle*solution-rhs).norm()/
                                      std::max<Real>(1,rhs.norm());
        result.flux=prepared.velocityScale.asDiagonal()*solution.head(variables);
        result.pressure=Vector::Zero(cells.size());
        for(unsigned row=0;row<pressures;++row)
            result.pressure[prepared.retainedRows[row]]=prepared.pressureScale[row]*solution[variables+row];
        result.stationarity=(mass*result.flux-load+continuity.transpose()*result.pressure).norm()/
                            std::max<Real>(1,load.norm());
        for(unsigned owner=0;owner<cells.size();++owner) {
            const auto& local=*cells[owner];
            const auto& map=maps[owner];
            Vector faces=map.body*twist;
            for(unsigned face=0;face<local.cell.faces.size();++face)
                if(map.column[face]>=0)
                    faces.segment(3*face,3)+=map.sign[face]*result.flux.segment(map.column[face],3);
            auto raw=local.condensed.Reconstruct(faces,sources[owner]);
            result.energy+=local.op.Energy(raw);
            result.objective+=local.condensed.FullObjective(raw,sources[owner]);
            result.balance=std::max(result.balance,(local.op.divergenceMoments*raw).cwiseAbs().maxCoeff());
            result.reaction-=map.body.transpose()*local.condensed.Gradient(faces,sources[owner]);
            result.local.push_back(std::move(raw));
        }
        result.reaction-=bodyContinuity.transpose()*result.pressure;
        result.energyIdentity=std::abs(result.objective+result.energy+
                                      twist.dot(result.reaction)-result.predictorEnergy);
        result.solveMs=Milliseconds(start);
        if(!result.flux.allFinite()||!result.reaction.allFinite()||!std::isfinite(result.energy))
            throw std::runtime_error("Stage17 physical result is nonfinite");
        if(result.scaledEquationResidual>1e-10L || result.stationarity>1e-10L ||
           result.balance>1e-10L*std::max<Real>(1,result.flux.norm()) ||
           result.energyIdentity>1e-10L*std::max<Real>(1,result.predictorEnergy+
                                                   std::abs(twist.dot(result.reaction))))
            throw std::runtime_error("Stage17 physical projection violates continuity/work acceptance");
        return result;
    }

    Result Solve(const std::vector<vm::Affine>& predictors,const Twist& twist=Twist::Zero()) const {
        if(predictors.size()!=cells.size())
            throw std::invalid_argument("Stage17 affine predictor count does not match physical cells");
        std::vector<Vector> raw;
        raw.reserve(cells.size());
        for(unsigned owner=0;owner<cells.size();++owner) {
            if(!predictors[owner].allFinite()) throw std::invalid_argument("Stage17 nonfinite affine predictor");
            raw.push_back(cells[owner]->op.InterpolateAffineDOFs(predictors[owner]));
        }
        return SolveRaw(raw,twist);
    }

    std::vector<vm::Affine> Constant(const vm::Vec3& velocity) const {
        std::vector<vm::Affine> result(cells.size(),vm::Affine::Zero());
        for(auto& coefficients:result)
            for(unsigned axis=0;axis<3;++axis) coefficients[4*axis]=velocity[axis];
        return result;
    }
};
using Epoch=Network;
} // namespace stage17_network
