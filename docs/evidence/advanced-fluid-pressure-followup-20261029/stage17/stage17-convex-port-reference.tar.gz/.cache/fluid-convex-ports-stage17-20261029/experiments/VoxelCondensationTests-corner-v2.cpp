#include "VoxelConservativeNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace voxel=stage17_voxel;
namespace local=stage17_condensed;
namespace exact=stage17_voxel_conservative;
using namespace stage17_network;
unsigned checks=0,legacyBaselineRefusals=0;
void Check(bool condition,const char* what) {
    ++checks;if(!condition) throw std::runtime_error(what);
}
vg::R BodyVolume(const Box& box) {
    std::array<vg::RV,3> n;vg::RV width;
    for(unsigned a=0;a<3;++a) {
        for(unsigned b=0;b<3;++b)n[a][b]=vg::R(box[2*a+1].normal[b]);
        width[a]=vg::R(box[2*a].coordinate)+vg::R(box[2*a+1].coordinate);
    }
    return width[0]*width[1]*width[2]/abs(owned_metrics::Dot(n[0],owned_metrics::Cross(n[1],n[2])));
}
void Run(unsigned n,glm::dvec3 center,glm::dvec3 half,double angle,const char* name) {
    using V=glm::dvec3;
    const auto box=owned_cut::BoxPlanes(center,half,
        glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
    voxel_ports::Compiler geometry;geometry.Build(n,box);
    const vg::R scale=vg::R(1)/n;
    voxel::Epoch full(geometry,scale);
    local::Epoch condensed(full);
    exact::Epoch conservative(condensed);
    for(const auto& domain:conservative.subdomains)
        for(unsigned cell:domain.cells)
            Check(conservative.cells[cell]->cell.seed==domain.seed,
                  "local condensation crosses an original physical voxel boundary");
    for(unsigned scenario=0;scenario<3;++scenario) {
        const auto input=scenario?vm::Vec3::Zero():vm::Vec3(0,-.04L,0);
        Twist body=Twist::Zero();if(scenario==1)body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        auto source=full.Constant(input);
        if(scenario==2) for(unsigned c=0;c<source.size();++c) {
            source[c][0]=.001L*(1+full.cells[c]->cell.seed+3*full.cells[c]->cell.piece);
            source[c][3]=.015L;source[c][6]=-.01L;source[c][9]=.012L;
        }
        const auto a=full.Solve(source,body);
        const auto c=conservative.Solve(source,body);
        local::Result b;bool oldMacroAccepted=true;
        try { b=condensed.Solve(source,body); }
        catch(const std::invalid_argument& error) {
            if(std::string(error.what()).find("body flow changes a sealed component volume")==std::string::npos) throw;
            oldMacroAccepted=false;++legacyBaselineRefusals;
            printf("LEGACY_MACRO_BASELINE_REFUSAL fixture=%s n=%u angle=%.17g scenario=%u reason=%s candidate_against_full_reference=still_required\n",
                name,n,angle,scenario,error.what());
        }
        Real field=0,energy=0,wrench=0,normalizedDiv=0,pointDiv=0,calm=0,rms=0,trace=0;
        for(unsigned owner=0;owner<full.cells.size();++owner) {
            const auto& cell=*full.cells[owner];const auto& mass=cell.op.mass;
            const Vector difference=a.local[owner]-c.local[owner];
            field=std::max(field,std::sqrt(std::abs(difference.dot(mass*difference)))/
                std::max<Real>(1,std::sqrt(std::abs(a.local[owner].dot(mass*a.local[owner])))));
            const auto moment=(cell.op.divergenceMoments*c.local[owner]).eval();
            normalizedDiv=std::max(normalizedDiv,moment.cwiseAbs().maxCoeff()/cell.op.geometry.volume[0]);
            const auto div=cell.op.Divergence(c.local[owner]);
            const auto projected=cell.op.Project(c.local[owner]);
            if(scenario==0)rms=std::max(rms,std::sqrt(2*cell.op.Energy(c.local[owner])/(1000*cell.op.geometry.volume[0])));
            for(unsigned face=0;face<cell.cell.faces.size();++face)
                for(const auto& triangle:cell.cell.faces[face].triangles)
                    for(const auto& point:triangle.points) {
                        vm::Vec3 r;for(unsigned axis=0;axis<3;++axis)r[axis]=point[axis].convert_to<Real>();
                        Eigen::Matrix<Real,4,1> p;p<<1,r.x(),r.y(),r.z();
                        pointDiv=std::max(pointDiv,std::abs(div.dot(p)));
                        if(scenario==0)calm=std::max(calm,vm::EvaluateAffine(projected,r).norm());
                        if(cell.cell.faces[face].kind==Kind::Solid) {
                            vm::Vec3 origin;for(unsigned axis=0;axis<3;++axis)origin[axis]=cell.cell.center[axis].convert_to<Real>();
                            const auto rigid=(body.head<3>()+body.tail<3>().cross(origin+r)).eval();
                            trace=std::max(trace,std::abs(cell.op.EvaluateFaceNormal(face,c.local[owner],r)-
                                cell.op.geometry.faces[face].normal.dot(rigid)));
                        }
                    }
        }
        energy=std::abs(a.energy-c.energy)/std::max<Real>(1,a.energy);
        wrench=(a.reaction-c.reaction).norm()/std::max<Real>(1,a.reaction.norm());
        Check(field<1e-10L&&energy<1e-10L&&wrench<1e-10L,
              "voxel-local exact condensation changes physical state or native wrench");
        if(oldMacroAccepted)
            Check(std::abs(a.energy-b.energy)<1e-10L&&(a.reaction-b.reaction).norm()<1e-10L,
                  "voxel-local KKT condensation changes physical state");
        Check(c.exactTotalMean==0,"voxel conservative state changes total mean volume");
        for(const auto& [key,port]:conservative.allPorts)if(port.secondCell!=~0u)
            Check(c.exactFaceMeans[port.firstCell][port.firstFace]+c.exactFaceMeans[port.secondCell][port.secondFace]==0,
                  "voxel boundary or internal primary means do not cancel exactly");
        Check(c.maximumRootMeanDivergence<1e-12L,"voxel root has excessive actual mean divergence");
        Check(c.energyIdentity<1e-10L&&c.stationarity<1e-10L,
              "voxel pressure work or stationarity fails");
        Check(normalizedDiv<1e-8L&&pointDiv<1e-8L&&trace<1e-8L,
              "voxel physical velocity violates local divergence or solid trace");
        if(scenario==0) {
            const Real volume=(BodyVolume(box)*scale*scale*scale).convert_to<Real>();
            Check((c.reaction.head<3>()+1000*volume*input).norm()<1e-10L,
                  "voxel hydrostatic force disagrees with independent physical displacement");
            Check(c.energy<1e-18L&&calm<1e-8L&&rms<1e-8L,
                  "voxel hydrostatic state is not actually locally calm");
        }
        printf("VOXEL_CONDENSATION fixture=%s n=%u angle=%.17g scenario=%u cells=%zu voxel_components=%zu full_vars=%ld reduced_vars=%ld field_error=%Lg energy_error=%Lg wrench_error=%Lg exact_total_mean=0 root_mean_div=%Lg normalized_div=%Lg point_div=%Lg trace=%Lg calm=%Lg rms=%Lg full_ms=%g exact_ms=%g\n",
            name,n,angle,scenario,full.cells.size(),conservative.subdomains.size(),long(full.mass.rows()),long(conservative.mass.rows()),
            field,energy,wrench,c.maximumRootMeanDivergence,normalizedDiv,pointDiv,trace,calm,rms,a.solveMs,c.solveMs);
    }
}
int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        if(argc>1&&std::string(argv[1])=="corner") {
            // Adversarial true voxel-corner cut. It is NOT an integration
            // diagonal. Preserve a physical failure/rejection if uncovered.
            Run(2,V(.75),V(.25),3.2137858346770188e-11,"true_corner_cut");
        } else {
            for(double angle:{0.,.17,3.2137858346770188e-11})Run(1,V(.5),V(.2),angle,"contained_voxel");
            Run(2,V(1),V(.4),3.2137858346770188e-11,"eight_voxel_boundary");
            const auto slab=owned_cut::BoxPlanes(V(.5),V(.1,2,2),glm::dquat(1,0,0,0));
            exact::Epoch disconnected(1,slab);
            Check(disconnected.components.size()==2&&disconnected.subdomains.size()==2,
                  "voxel-local condensation joins two physical water components");
            Twist entering=Twist::Zero();entering[0]=.1L;bool rejected=false;
            try { disconnected.Solve(disconnected.Constant(vm::Vec3::Zero()),entering); }
            catch(const std::invalid_argument&) { rejected=true; }
            Check(rejected,"voxel components exchange incompatible body displacement illegally");
            Check(disconnected.Solve(disconnected.Constant(vm::Vec3::Zero())).exactTotalMean==0,
                  "rejected voxel component transaction poisons mean state");
        }
        printf("VOXEL_CONDENSATION_SUMMARY candidate_checks=%u candidate_failures=0 preserved_legacy_macro_refusals=%u\n",checks,legacyBaselineRefusals);return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
