#include "PortMomentumTransport.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace port_momentum;
unsigned checks=0;
void Check(bool pass,const char* text){++checks;if(!pass)throw std::runtime_error(text);}
Real MeanEnergy(const World& w,const std::vector<Vector>& raw){Real total=0;for(unsigned c=0;c<w.cells.size();++c){const auto& local=*w.cells[c];vm::Vec3 mean;for(unsigned a=0;a<3;++a)mean[a]=raw[c][local.op.MeanOffset()+a]/local.op.geometry.volume[0];total+=local.op.geometry.density*local.op.geometry.volume[0]*mean.squaredNorm()/2;}return total;}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
 using V=glm::dvec3;const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::dquat(1,0,0,0));stage17_voxel_conservative::Epoch world(1,box);
 Transport transport(world);auto predictor=world.Constant(vm::Vec3::Zero());const vm::Vec3 omega(.12,.09,-.17);
 for(unsigned c=0;c<world.cells.size();++c){vm::Vec3 center;for(unsigned a=0;a<3;++a)center[a]=world.cells[c]->cell.center[a].convert_to<Real>()-.5L;predictor[c]=vm::RigidAffine(omega.cross(center),omega);}
 auto state=world.Solve(predictor);const Real initial=state.energy;Check(initial>1e-5L,"actual fixed-tank vortex must have nonzero retained flow");Check(!transport.ports.empty(),"actual fixed tank must contain connected physical fluid ports");
 const auto& port=transport.ports.front();const auto counter=port.Directed({R(0),R(1)/100,R(0)});Check(counter[0]==counter[1]&&counter[0]>0,"zero-net primary port must retain actual bidirectional material exchange");
 const auto old=state.local;bool rejected=false;try{transport.Apply(state,R(1000000));}catch(const std::invalid_argument& error){rejected=std::string(error.what()).find("donor availability")!=std::string::npos;}
 Check(rejected,"oversized actual outflow must be rejected without a clamp or hidden substep");for(unsigned c=0;c<old.size();++c)Check((old[c]-state.local[c]).squaredNorm()==0,"failed transport must not publish partial kinetic state");
 Real maximumMomentumError=0,maximumEnergyIncrease=0,maximumFluctuationError=0,maximumDivergence=0;
 unsigned packets=0;const auto begin=Clock::now();
 for(unsigned step=0;step<240;++step){const auto transported=transport.Apply(state,R(1)/240);Check(transported.exactTransportImpulse==RV{},"actual paired packets create momentum");maximumMomentumError=std::max(maximumMomentumError,transported.momentumError);maximumEnergyIncrease=std::max(maximumEnergyIncrease,transported.energyAfter-transported.energyBefore);
  const Real fluctuation=std::abs((transported.energyAfter-MeanEnergy(world,transported.raw))-(transported.energyBefore-MeanEnergy(world,state.local)));maximumFluctuationError=std::max(maximumFluctuationError,fluctuation);Check(fluctuation<1e-12L,"mean advection unexpectedly discards complementary or resolved local kinetic modes");
  const auto next=world.SolveRaw(transported.raw);Check(next.energy<=transported.energyAfter+1e-12L,"closed stationary pressure step creates energy after actual momentum advection");Check(next.exactTotalMean==0,"actual pressure/advection cycle changes conserved capacity");
  for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];for(const auto& face:local.cell.faces)for(const auto& triangle:face.triangles)for(const auto& exact:triangle.points){vm::Vec3 r;for(unsigned a=0;a<3;++a)r[a]=exact[a].convert_to<Real>();Eigen::Matrix<Real,4,1> p;p<<1,r[0],r[1],r[2];maximumDivergence=std::max(maximumDivergence,std::abs(local.op.Divergence(next.local[c]).dot(p)));}}
  packets+=transported.directedPackets;state=next;
  if(step%60==59)printf("MOMENTUM_CYCLE step=%u energy=%Lg retained=%Lg momentum_error=%Lg mean_transport_increase=%Lg fluctuation_error=%Lg point_div=%Lg directed_packets=%u\n",step+1,state.energy,state.energy/initial,maximumMomentumError,maximumEnergyIncrease,maximumFluctuationError,maximumDivergence,packets);
 }
 Check(maximumMomentumError<1e-12L,"material advection creates actual kinetic-field momentum");Check(maximumEnergyIncrease<1e-12L,"mean momentum advection creates actual kinetic energy");Check(maximumDivergence<1e-8L,"pressure cycle violates actual physical divergence");Check(state.energy>initial*1e-6L,"actual circulation was globally reset instead of evolved");Check(packets>240,"actual momentum transport did not exercise repeated directed exchange");
 printf("MOMENTUM_TRANSPORT_SUMMARY checks=%u failures=0 elapsed_ms=%g initial_energy=%Lg final_energy=%Lg scope=fixed_geometry_mean_momentum_actual_P1_counterflow\n",checks,Milliseconds(begin),initial,state.energy);return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL after%uchecks %s\n",checks,error.what());return 1;}}
