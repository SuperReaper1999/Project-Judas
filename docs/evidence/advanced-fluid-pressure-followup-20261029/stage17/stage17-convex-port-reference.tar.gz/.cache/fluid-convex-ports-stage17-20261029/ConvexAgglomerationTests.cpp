#include "ConvexAgglomeration.h"
#include "ConservativeCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace ag=convex_agglomeration;
namespace net=stage17_network;
namespace local=stage17_condensed;
namespace conservative=stage17_conservative_network;
unsigned checks=0;
void Check(bool condition,const char* what) {
    ++checks;if(!condition)throw std::runtime_error(what);
}
using TriangleKey=std::pair<std::array<ag::RV,3>,ag::RV>;
std::multiset<TriangleKey> SolidTriangles(const convex_ports::Compiler& geometry) {
    std::multiset<TriangleKey> result;
    for(const auto& cell:geometry.cells)for(const auto& face:cell.faces)
        if(face.kind==convex_ports::Kind::Solid)for(const auto& triangle:face.triangles) {
            auto points=triangle.points;std::sort(points.begin(),points.end());
            result.emplace(points,triangle.areaVector);
        }
    return result;
}
ag::R BodyVolume(const convex_ports::Box& box) {
    std::array<ag::RV,3> normal;ag::RV width;
    for(unsigned a=0;a<3;++a){for(unsigned b=0;b<3;++b)normal[a][b]=ag::R(box[2*a+1].normal[b]);
        width[a]=ag::R(box[2*a].coordinate)+ag::R(box[2*a+1].coordinate);}
    return width[0]*width[1]*width[2]/abs(owned_metrics::Dot(normal[0],owned_metrics::Cross(normal[1],normal[2])));
}
void Run(unsigned n,glm::dvec3 center,glm::dvec3 half,double angle,const char* fixture,bool anyConvex=false) {
    using V=glm::dvec3;
    const auto box=owned_cut::BoxPlanes(center,half,
        glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
    voxel_ports::Compiler source;source.Build(n,box);
    const auto started=net::Clock::now();ag::Compiler geometry;
    geometry.sameFirstExclusionOnly=!anyConvex;geometry.Build(source);
    const double agglomerationMs=net::Milliseconds(started);
    Check(geometry.inputVolume==geometry.outputVolume,"agglomeration changes exact wet quantity");
    Check(SolidTriangles(source)==SolidTriangles(geometry),"agglomeration changes a physical wetted-solid patch");
    Check(geometry.minCompactnessAfter>=geometry.minCompactnessBefore,
          "geometry-only policy worsens minimum dimensionless shape regularity");
    for(const auto& merge:geometry.merges)
        Check(merge.after>merge.worseBefore,"merge was not selected by exact geometric improvement");
    for(const auto& cell:geometry.cells) {
        const auto vertices=ag::Vertices(cell);ag::RV area{};ag::R volume=0;
        for(const auto& face:cell.faces)for(const auto& triangle:face.triangles) {
            for(unsigned a=0;a<3;++a)area[a]+=triangle.areaVector[a];
            volume+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
            for(const auto& p:vertices)
                Check(owned_metrics::Dot(ag::Sub(p,triangle.points[0]),triangle.areaVector)<=0,
                      "claimed union is not exactly convex");
        }
        Check(area==ag::RV{}&&volume==cell.volume,"agglomerated physical exterior is not closed");
    }
    unsigned badlyShaped=0;
    for(const auto& cell:geometry.cells) {
        const auto quality=ag::Compactness(cell);
        if(quality<ag::R(1)/1000000) {
            ++badlyShaped;const auto points=ag::Vertices(cell);
            auto low=*points.begin(),high=low;
            for(const auto& point:points)for(unsigned axis=0;axis<3;++axis) {
                low[axis]=std::min(low[axis],point[axis]);high[axis]=std::max(high[axis],point[axis]);
            }
            printf("AGGLOMERATION_SHAPE_DIAGNOSTIC fixture=%s policy=%s seed=%u piece_label=%u volume=%Lg compactness=%Lg vertices=%zu bbox=%Lg,%Lg,%Lg..%Lg,%Lg,%Lg\n",
                fixture,anyConvex?"any_convex":"same_exclusion",cell.seed,cell.piece,cell.volume.convert_to<net::Real>(),
                quality.convert_to<net::Real>(),points.size(),low[0].convert_to<net::Real>(),low[1].convert_to<net::Real>(),low[2].convert_to<net::Real>(),
                high[0].convert_to<net::Real>(),high[1].convert_to<net::Real>(),high[2].convert_to<net::Real>());
        }
    }
    // The 1e-6 value above labels a diagnostic ONLY. It does not select,
    // delete, merge, reject or alter any physical cell or acceptance threshold.
    printf("AGGLOMERATION_SHAPE_COUNT fixture=%s policy=%s cells=%zu diagnostic_below_1e-6=%u\n",
        fixture,anyConvex?"any_convex":"same_exclusion",geometry.cells.size(),badlyShaped);
    net::Network physical(geometry,net::vg::R(1)/n);
    local::Epoch condensed(physical);conservative::Epoch world(condensed);
    for(unsigned scenario=0;scenario<3;++scenario) {
        const net::vm::Vec3 input=scenario==0?net::vm::Vec3(0,-.04L,0):
            (scenario==2?net::vm::Vec3(.02L,-.035L,.01L):net::vm::Vec3::Zero());
        net::Twist body=net::Twist::Zero();if(scenario==1)body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto result=world.Solve(world.Constant(input),body);
        net::Real normalized=0,pointDiv=0,calm=0,rms=0,trace=0;
        for(unsigned c=0;c<world.cells.size();++c) {
            const auto& cell=*world.cells[c];const auto& raw=result.local[c];
            const auto moments=(cell.op.divergenceMoments*raw).eval();
            normalized=std::max(normalized,moments.cwiseAbs().maxCoeff()/cell.op.geometry.volume[0]);
            const auto div=cell.op.Divergence(raw);
            const auto projected=cell.op.Project(raw);
            if(scenario!=1)rms=std::max(rms,std::sqrt(2*cell.op.Energy(raw)/(1000*cell.op.geometry.volume[0])));
            for(unsigned f=0;f<cell.cell.faces.size();++f)
                for(const auto& triangle:cell.cell.faces[f].triangles)
                    for(const auto& exact:triangle.points) {
                        net::vm::Vec3 r,origin;
                        for(unsigned a=0;a<3;++a){r[a]=exact[a].convert_to<net::Real>();origin[a]=cell.cell.center[a].convert_to<net::Real>();}
                        Eigen::Matrix<net::Real,4,1> p;p<<1,r.x(),r.y(),r.z();
                        pointDiv=std::max(pointDiv,std::abs(div.dot(p)));
                        if(scenario!=1)calm=std::max(calm,net::vm::EvaluateAffine(projected,r).norm());
                        if(cell.cell.faces[f].kind==net::Kind::Solid) {
                            const auto velocity=(body.head<3>()+body.tail<3>().cross(origin+r)).eval();
                            trace=std::max(trace,std::abs(cell.op.EvaluateFaceNormal(f,raw,r)-cell.op.geometry.faces[f].normal.dot(velocity)));
                        }
                    }
        }
        const net::Real displaced=(BodyVolume(box)/(ag::R(n)*n*n)).convert_to<net::Real>();
        const net::Real force=(result.reaction.head<3>()+1000*displaced*input).norm();
        printf("AGGLOMERATION fixture=%s n=%u angle=%.17g scenario=%u cells_before=%u cells_after=%zu merges=%zu min_shape_before=%Lg min_shape_after=%Lg geometry_ms=%g variables=%ld energy=%Lg normalized_div=%Lg point_div=%Lg trace=%Lg calm=%Lg rms=%Lg force_error=%Lg root_mean_div=%Lg exact_total_mean=%u solve_ms=%g\n",
            fixture,n,angle,scenario,geometry.inputCells,geometry.cells.size(),geometry.merges.size(),
            geometry.minCompactnessBefore.convert_to<net::Real>(),geometry.minCompactnessAfter.convert_to<net::Real>(),
            agglomerationMs,long(world.mass.rows()),result.energy,normalized,pointDiv,trace,calm,rms,force,
            result.maximumRootMeanDivergence,unsigned(result.exactTotalMean==0),result.solveMs);
        Check(result.exactTotalMean==0&&result.maximumRootMeanDivergence<1e-12L,
              "agglomerated world loses exact global quantity or root continuity");
        for(const auto& [key,owners]:world.allPorts)if(owners.secondCell!=~0u)
            Check(result.exactFaceMeans[owners.firstCell][owners.firstFace]+result.exactFaceMeans[owners.secondCell][owners.secondFace]==0,
                  "agglomeration joins or leaks between distinct physical ports");
        Check(normalized<1e-8L&&pointDiv<1e-8L&&trace<1e-8L,
              "agglomerated physical divergence or boundary trace is incorrect");
        Check(result.energyIdentity<1e-10L&&result.stationarity<1e-10L,
              "agglomerated physical work or stationarity is incorrect");
        if(scenario!=1) {
            Check(force<1e-10L,"agglomerated hydrostatic displacement load is wrong");
            Check(result.energy<1e-18L&&calm<1e-8L&&rms<1e-8L,
                  "agglomerated hydrostatic state is not locally calm");
        }
    }
}
void NegativeUnions() {
    using V=glm::dvec3;
    voxel_ports::Compiler cubes;cubes.Build(2,owned_cut::BoxPlanes(V(10),V(1),glm::dquat(1,0,0,0)));
    const auto find=[&](unsigned seed)->convex_ports::Cell {
        for(const auto& cell:cubes.cells)if(cell.seed==seed)return cell;
        throw std::runtime_error("negative union cube missing");
    };
    std::vector<ag::Compiler::Node> nodes{{find(0),{0},true},{find(1),{1},true}};
    auto owners=ag::Compiler::PortOwners(nodes);convex_ports::Cell rectangle;unsigned removed=0;
    Check(ag::Compiler::TryUnion(nodes[0],nodes[1],owners,0,1,rectangle,removed),
          "positive rectangular union control was rejected");
    nodes={{rectangle,{0,1},true},{find(2),{2},true}};owners=ag::Compiler::PortOwners(nodes);
    convex_ports::Cell concave;
    Check(!ag::Compiler::TryUnion(nodes[0],nodes[1],owners,0,1,concave,removed),
          "concave L-shaped union was silently filled");
    nodes={{find(0),{0},true},{find(3),{3},true}};owners=ag::Compiler::PortOwners(nodes);
    bool rejected=false;
    try {ag::Compiler::TryUnion(nodes[0],nodes[1],owners,0,1,concave,removed);}
    catch(const std::runtime_error&) {rejected=true;}
    Check(rejected,"edge-only contact invented a positive-area fluid connection");
}
int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;NegativeUnions();
        if(argc>1&&(std::string(argv[1])=="corner"||std::string(argv[1])=="corner-any"))
            Run(2,V(.75),V(.25),3.2137858346770188e-11,"true_corner",std::string(argv[1])=="corner-any");
        else {
            Run(1,V(.5),V(.2),.17,"contained_oblique");
            Run(2,V(1),V(.4),3.2137858346770188e-11,"eight_voxel_boundary");
            Run(2,V(.75),V(.25),3.2137858346770188e-11,"true_corner");
        }
        printf("AGGLOMERATION_SUMMARY checks=%u failures=0\n",checks);return 0;
    } catch(const std::exception& error) {fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;}
}
