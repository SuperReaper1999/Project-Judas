#include "VoxelPorts.h"
#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <limits>

namespace net=stage17_network;
using Real=net::Real;
using R=voxel_ports::R;
using RV=voxel_ports::RV;
using Vec=net::vm::Vec3;
using Mat=net::vm::Mat3;
using Twist=net::Twist;
unsigned checks=0;
void Check(bool pass,const char* what) {++checks;if(!pass)throw std::runtime_error(what);}
const Vec center(.5L,.5L,.5L);
constexpr Real bodyLength=.2L;

Twist WorldTwist(const Twist& com) {
    Twist world=com;
    world.head<3>()=com.head<3>()-com.tail<3>().cross(center);
    return world;
}
Twist ComWrench(const Twist& world) {
    Twist com=world;
    com.tail<3>()-=center.cross(world.head<3>());
    return com;
}
Vec Cycle(const Vec& v) {return {v.z(),v.x(),v.y()};}
Twist Cycle(const Twist& v) {
    Twist out;out.head<3>()=Cycle(Vec(v.head<3>()));out.tail<3>()=Cycle(Vec(v.tail<3>()));return out;
}
std::vector<net::vm::Affine> Predict(const net::Network& world,const Vec& atWorldOrigin,const Mat& gradient) {
    std::vector<net::vm::Affine> out;
    for(const auto& local:world.cells) {
        Vec origin;
        for(unsigned a=0;a<3;++a) origin[a]=local->cell.center[a].convert_to<Real>();
        const Vec value=atWorldOrigin+gradient*origin;
        net::vm::Affine coefficients;
        for(unsigned a=0;a<3;++a) {
            coefficients[4*a]=value[a];
            for(unsigned b=0;b<3;++b) coefficients[4*a+b+1]=gradient(a,b);
        }
        out.push_back(coefficients);
    }
    return out;
}

// Independent physical boundary lift from actual oriented triangle geometry.
// n*dA is an exact area vector; no candidate polynomialDofs/body map is used.
net::Matrix BoundaryLift(const net::PhysicalFace& face,const RV& exactCenter) {
    std::array<std::array<R,6>,3> integral{};
    for(const auto& triangle:face.triangles) {
        std::array<RV,3> positions;
        std::array<std::array<R,3>,3> psi{};
        for(unsigned vertex=0;vertex<3;++vertex) {
            positions[vertex]=triangle.points[vertex];
            for(unsigned a=0;a<3;++a) positions[vertex][a]+=exactCenter[a];
            const auto& p=positions[vertex];
            const auto delta=convex_ports::Sub(p,face.frame.origin);
            psi[0][vertex]=1;
            psi[1][vertex]=(owned_metrics::Dot(face.frame.edge,delta)-face.frame.midU)/face.frame.spanU;
            psi[2][vertex]=(owned_metrics::Dot(face.frame.transverse,delta)-face.frame.midV)/face.frame.spanV;
        }
        for(unsigned row=0;row<3;++row) {
            const R sum=psi[row][0]+psi[row][1]+psi[row][2];
            RV weighted{};
            for(unsigned a=0;a<3;++a) {
                R positionSum=0,diagonal=0;
                for(unsigned vertex=0;vertex<3;++vertex) {
                    positionSum+=positions[vertex][a];diagonal+=psi[row][vertex]*positions[vertex][a];
                }
                weighted[a]=(sum*positionSum+diagonal)/12;
                integral[row][a]+=triangle.areaVector[a]*sum/3;
            }
            const auto angular=owned_metrics::Cross(weighted,triangle.areaVector);
            for(unsigned a=0;a<3;++a) integral[row][a+3]+=angular[a];
        }
    }
    net::Matrix out(3,6);
    for(unsigned a=0;a<3;++a) for(unsigned b=0;b<6;++b) out(a,b)=integral[a][b].convert_to<Real>();
    return out;
}

struct Balances {Twist body=Twist::Zero(),wall=Twist::Zero(),fluidChange=Twist::Zero();};
Balances BoundaryBalances(const net::Network& world,const std::vector<net::vm::Affine>& predictors,
                          const net::Result& solved) {
    Balances out;
    for(unsigned c=0;c<world.cells.size();++c) {
        const auto& local=*world.cells[c];
        const auto rawPredictor=local.op.InterpolateAffineDOFs(predictors[c]);
        const auto source=local.condensed.SourceFromPredictor(rawPredictor);
        const auto face=solved.local[c].head(local.condensed.faceDimension).eval();
        const auto residual=(local.condensed.Gradient(face,source)
            +local.condensed.closure.transpose()*solved.pressure[c]).eval();
        for(unsigned f=0;f<local.cell.faces.size();++f) {
            const auto& patch=local.cell.faces[f];
            const auto lift=BoundaryLift(patch,local.cell.center);
            const Twist reaction=-lift.transpose()*residual.segment(3*f,3);
            if(patch.kind==net::Kind::Solid) out.body+=reaction;
            else if(world.Outer(patch.key) && !world.Open(patch.key)) out.wall+=reaction;
        }
        Vec position;
        for(unsigned a=0;a<3;++a) position[a]=local.cell.center[a].convert_to<Real>();
        const Vec mean=(solved.local[c].segment<3>(local.op.MeanOffset())
                       -rawPredictor.segment<3>(local.op.MeanOffset())).eval();
        const Vec angular=(solved.local[c].segment<3>(local.op.AngularOffset())
                          -rawPredictor.segment<3>(local.op.AngularOffset())).eval();
        out.fluidChange.head<3>()+=1000*mean;
        out.fluidChange.tail<3>()+=1000*(angular+position.cross(mean));
    }
    return out;
}

void WorkChecks(const net::Network& world,double angle) {
    const Vec uniform(.03L,-.02L,.01L);
    const auto source=Predict(world,uniform,Mat::Zero());
    const auto calm=world.Solve(source);
    Check(calm.energy<1e-18L,"gradient-source pressure projection does not remain calm");
    const auto balance=BoundaryBalances(world,source,calm);
    const Vec expectedBody=-64.L*uniform,expectedWall=1000.L*uniform;
    Check((balance.body.head<3>()-expectedBody).norm()<1e-9L,"independent hydrostatic body traction is wrong");
    Check((balance.wall.head<3>()-expectedWall).norm()<1e-9L,"independent container-wall traction is wrong");
    Check((balance.body-calm.reaction).norm()<1e-9L,"reported body reaction differs from independent boundary virtual work");
    Check((balance.fluidChange+balance.body+balance.wall).norm()<1e-9L,"body+wall+fluid linear/angular impulse do not balance");
    Check((balance.fluidChange+balance.body).norm()>1,
          "omitted-wall negative control did not expose missing physical reaction");

    Twist com;com<<.01L,-.02L,.03L,.02L,.03L,-.01L;
    const Twist twist=WorldTwist(com);
    const auto zero=world.Constant(Vec::Zero());
    const auto moving=world.Solve(zero,twist);
    const auto movingBalance=BoundaryBalances(world,zero,moving);
    Check((movingBalance.fluidChange+movingBalance.body+movingBalance.wall).norm()<1e-9L,
          "moving body and wall impulses violate actual fluid momentum");
    Check(std::abs(2*moving.energy+twist.dot(movingBalance.body))<1e-9L,
          "moving body physical work differs from kinetic energy");
    const Twist reverse=-twist;
    const auto backwards=world.Solve(zero,reverse);
    Check(std::abs(backwards.energy-moving.energy)<1e-10L,
          "linear physical response energy changes under sign reversal");
    Check((backwards.reaction+moving.reaction).norm()<1e-9L,
          "linear physical response wrench is not odd");
    Real maxDerivative=0;
    for(unsigned axis=0;axis<6;++axis) {
        Twist delta=Twist::Zero();delta[axis]=1e-4L;
        const auto plus=world.Solve(zero,WorldTwist(com+delta));
        const auto minus=world.Solve(zero,WorldTwist(com-delta));
        const Real derivative=(plus.energy-minus.energy)/(2e-4L);
        const Real expected=-ComWrench(movingBalance.body)[axis];
        maxDerivative=std::max(maxDerivative,std::abs(derivative-expected));
        Check(std::abs(derivative-expected)<1e-9L,"finite physical body-work derivative fails");
    }

    Mat rotation;rotation<<0,-.1L,.07L,.1L,0,-.03L,-.07L,.03L,0;
    const auto vortex=world.Solve(Predict(world,-rotation*center,rotation));
    Check(vortex.energy>1e-10L,"pressure projection flattened a genuine vortical disturbance");
    Check(vortex.energy<=vortex.predictorEnergy+1e-10L,"fixed-boundary pressure projection creates kinetic energy");

    auto invalid=zero;invalid[0][0]=std::numeric_limits<Real>::quiet_NaN();
    bool rejected=false;
    try {(void)world.Solve(invalid);}catch(const std::exception&){rejected=true;}
    Check(rejected,"nonfinite source was not rejected");
    const auto after=world.Solve(zero,twist);
    Check((after.flux.array()==moving.flux.array()).all() && after.reaction==moving.reaction,
          "rejected source contaminated reusable physical factors");
    std::printf("VOXEL_WORK angle=%.17g impulse_balance=%Lg moving_impulse_balance=%Lg derivative_error=%Lg "
                "vortex_retained_fraction=%Lg omitted_wall_negative=rejected invalid_source_negative=rejected\n",
                angle,(balance.fluidChange+balance.body+balance.wall).norm(),
                (movingBalance.fluidChange+movingBalance.body+movingBalance.wall).norm(),maxDerivative,
                vortex.energy/vortex.predictorEnergy);
}

net::Matrix AddedMass(const net::Network& world) {
    net::Matrix response(6,6);
    const auto zero=world.Constant(Vec::Zero());
    for(unsigned column=0;column<6;++column) {
        Twist com=Twist::Zero();com[column]=column<3?1:1/bodyLength;
        const auto result=world.Solve(zero,WorldTwist(com));
        Twist wrench=ComWrench(result.reaction);wrench.tail<3>()/=bodyLength;
        response.col(column)=-wrench;
        Check(std::abs(2*result.energy-response(column,column))<1e-9L,
              "added-mass energy differs from physical COM reaction");
    }
    const Real scale=response.norm();
    Check((response-response.transpose()).norm()<1e-10L*scale,"physical added-mass reciprocity fails");
    Eigen::SelfAdjointEigenSolver<net::Matrix> spectrum((response+response.transpose()).eval()/2);
    Check(spectrum.info()==Eigen::Success && spectrum.eigenvalues().minCoeff()>-1e-10L*scale,
          "physical added-mass response has a negative kinetic mode");
    return response;
}

void Reordering(const voxel_ports::Compiler& geometry,const net::Network& original,double angle) {
    auto reversed=geometry;
    std::reverse(reversed.cells.begin(),reversed.cells.end());
    for(auto& cell:reversed.cells) std::reverse(cell.faces.begin(),cell.faces.end());
    const net::Network reordered(reversed);
    const Vec source(.01L,-.02L,.03L);
    Twist com;com<<.02L,.01L,-.03L,.03L,-.02L,.01L;
    const auto a=original.Solve(original.Constant(source),WorldTwist(com));
    const auto b=reordered.Solve(reordered.Constant(source),WorldTwist(com));
    Check(std::abs(a.energy-b.energy)<1e-10L && (a.reaction-b.reaction).norm()<1e-9L,
          "physical response changes with piece/face iteration order");
    std::printf("VOXEL_REORDER angle=%.17g energy_delta=%Lg wrench_delta=%Lg\n",
                angle,std::abs(a.energy-b.energy),(a.reaction-b.reaction).norm());
}

void PlaneCovariance(const voxel_ports::Box& original,const net::Network& world) {
    auto cycled=original;
    for(unsigned plane=0;plane<6;++plane)
        for(unsigned a=0;a<3;++a) cycled[plane].normal[a]=original[plane].normal[(a+2)%3];
    voxel_ports::Compiler geometry;geometry.Build(1,cycled);
    const net::Network rotated(geometry);
    Twist com;com<<.02L,.01L,-.03L,.03L,-.02L,.01L;
    const auto a=world.Solve(world.Constant(Vec::Zero()),WorldTwist(com));
    const auto b=rotated.Solve(rotated.Constant(Vec::Zero()),WorldTwist(Cycle(com)));
    const auto expected=Cycle(ComWrench(a.reaction));
    const auto actual=ComWrench(b.reaction);
    Check(std::abs(a.energy-b.energy)<1e-9L && (expected-actual).norm()<1e-8L,
          "coordinate and plane-order cycling breaks physical covariance");
    const auto added=AddedMass(world);
    Check(added.topRightCorner(3,3).norm()<1e-10L*added.norm(),
          "centrally symmetric mesh has spurious COM translation/rotation coupling");
    const Real translationMean=added.topLeftCorner(3,3).trace()/3;
    const Real rotationMean=added.bottomRightCorner(3,3).trace()/3;
    Real translationBias=0,rotationBias=0;
    for(unsigned a=0;a<3;++a) {
        translationBias=std::max(translationBias,std::abs(added(a,a)-translationMean)/translationMean);
        rotationBias=std::max(rotationBias,std::abs(added(a+3,a+3)-rotationMean)/rotationMean);
    }
    // Report continuum symmetry error, do not disguise a coarse approximation
    // as exact simply because covariance and linear algebra pass.
    std::printf("VOXEL_SYMMETRY mass_diag=%Lg,%Lg,%Lg scaled_inertia_diag=%Lg,%Lg,%Lg "
                "coarse_translation_axis_bias=%Lg coarse_rotation_axis_bias=%Lg "
                "coordinate_cycle_energy_delta=%Lg coordinate_cycle_wrench_delta=%Lg\n",
                added(0,0),added(1,1),added(2,2),added(3,3),added(4,4),added(5,5),
                translationBias,rotationBias,std::abs(a.energy-b.energy),(expected-actual).norm());
}

int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(double angle:{0.,.17,3.2137858346770188e-11}) {
            const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
            voxel_ports::Compiler geometry;geometry.Build(1,box);
            const net::Network world(geometry);
            WorkChecks(world,angle);
            (void)AddedMass(world);
            Reordering(geometry,world,angle);
            if(angle==0) PlaneCovariance(box,world);
        }
        std::printf("VOXEL_PHYSICAL_SUMMARY checks=%u failures=0 scope=work_covariance_reciprocity "
                    "dynamic_resolution_accuracy=reported_separately\n",checks);
        return 0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"VOXEL_PHYSICAL_FAIL checks=%u %s\n",checks,error.what());return 1;
    }
}
