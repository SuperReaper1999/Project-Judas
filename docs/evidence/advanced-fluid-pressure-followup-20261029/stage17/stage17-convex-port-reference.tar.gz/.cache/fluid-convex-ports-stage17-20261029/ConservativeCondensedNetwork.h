#pragma once

// PRIVATE global integration of conservative internal coordinates. The base
// class supplies immutable geometry/topology and the existing global factor;
// its old local KKT reconstruction is NEVER used by this derived solve.
// This corrects mean-flux coordinates, not the separate polynomial-conditioning
// defect. Rounded kinetic local[] is diagnostic; exactFaceMeans is authoritative.
#include "ConservativeInternalCoordinates.h"

namespace stage17_conservative_network {
using namespace stage17_network;
using Baseline=stage17_condensed::LocalCondensedNetwork;
namespace cc=stage17_conservative;

struct Result : stage17_network::Result {
    std::vector<cc::ExactRow> exactFaceMeans;
    cc::ExactRow exactMeanSums;
    cc::Exact exactTotalMean=0;
    Real maximumRootMeanDivergence=0;
    Real objectiveReconstructionError=0;
};
struct Epoch : Baseline {
    std::vector<cc::Coordinates> conservative;
    double conservativePreparationMs=0;
    // Correctness prototype convenience: this constructor first prepares the
    // unchanged baseline topology. Do not advertise its cost as an optimized
    // runtime build until that redundant baseline factor is removed separately.
    Epoch(unsigned grid,const Box& box,const vg::R& scale=1,
          Boundary condition=Boundary::Sealed)
        :Epoch(Baseline(grid,box,scale,condition)) {}
    explicit Epoch(const Baseline& reference):Baseline(reference) {
        const auto start=Clock::now();
        for(unsigned group=0;group<subdomains.size();++group)
            conservative.emplace_back(reference,group);
        AssembleConservative();
        conservativePreparationMs=Milliseconds(start);
    }
    void AssembleConservative() {
        const unsigned variables=3*interfaces.size();
        mixedBody=Matrix::Zero(variables,6);bodyMass=Matrix::Zero(6,6);
        bodyContinuity=Matrix::Zero(conservative.size(),6);
        std::vector<Triplet> kineticEntries,continuityEntries;
        for(unsigned group=0;group<conservative.size();++group) {
            const auto& local=conservative[group];const auto& h=local.reducedMass;
            const unsigned ne=local.boundaryKeys.size(),body=local.externalVariables-6;
            bodyMass+=h.bottomRightCorner(6,6);
            for(unsigned degree=0;degree<6;++degree)
                bodyContinuity(group,degree)=local.macroClosure[body+degree].convert_to<Real>();
            for(unsigned face=0;face<ne;++face) for(unsigned axis=0;axis<3;++axis) {
                const unsigned row=maps[group].columns[face]+axis,index=3*face+axis;
                const Real sign=maps[group].signs[face];
                const Real rate=local.macroClosure[index].convert_to<Real>()*sign;
                if(rate!=0) continuityEntries.emplace_back(group,row,rate);
                mixedBody.row(row)+=sign*h.block(index,body,1,6);
                for(unsigned other=0;other<ne;++other) for(unsigned component=0;component<3;++component) {
                    const Real value=sign*maps[group].signs[other]*h(index,3*other+component);
                    if(value!=0) kineticEntries.emplace_back(row,maps[group].columns[other]+component,value);
                }
            }
        }
        mass.resize(variables,variables);mass.setFromTriplets(kineticEntries.begin(),kineticEntries.end());
        continuity.resize(conservative.size(),variables);
        continuity.setFromTriplets(continuityEntries.begin(),continuityEntries.end());
        BuildFactor(); // Existing global topology/gauges; NEW conservative H/C.
    }
    void CheckExactPrescribedFlux(const Twist& twist) const {
        for(unsigned component=0;component<components.size();++component) {
            if(componentOpen[component]) continue;
            std::array<cc::Exact,6> coefficients{};
            for(unsigned group:components[component]) {
                const auto& local=conservative[group];
                for(unsigned degree=0;degree<6;++degree)
                    coefficients[degree]+=local.macroClosure[local.externalVariables-6+degree];
            }
            cc::Exact rate=0;
            for(unsigned degree=0;degree<6;++degree) rate+=coefficients[degree]*cc::Exact(twist[degree]);
            if(rate!=0) throw std::invalid_argument("conservative prescribed body flow changes a sealed component volume");
        }
    }
    Result SolveRaw(const std::vector<Vector>& predictors,const Twist& twist=Twist::Zero()) const {
        Network::CheckRounding();const auto start=Clock::now();
        if(predictors.size()!=cells.size()||!twist.allFinite())
            throw std::invalid_argument("conservative global source is invalid");
        for(unsigned cell=0;cell<cells.size();++cell)
            if(predictors[cell].size()!=cells[cell]->op.dimension||!predictors[cell].allFinite())
                throw std::invalid_argument("conservative raw predictor is invalid");
        CheckExactPrescribedFlux(twist);
        Result result;
        std::vector<cc::Source> sources;Vector load=Vector::Zero(mass.rows());
        for(unsigned group=0;group<conservative.size();++group) {
            const auto& local=conservative[group];auto source=local.Prepare(predictors);
            result.predictorEnergy+=source.predictorEnergy;
            for(unsigned face=0;face<local.boundaryKeys.size();++face)
                load.segment(maps[group].columns[face],3)+=
                    maps[group].signs[face]*source.reducedLoad.segment(3*face,3);
            sources.push_back(std::move(source));
        }
        if(!std::isfinite(result.predictorEnergy)||result.predictorEnergy>std::numeric_limits<double>::max())
            throw std::invalid_argument("conservative predictor energy is not representable");
        load-=mixedBody*twist;
        const auto& prepared=*factor;const unsigned nv=mass.rows(),np=prepared.retainedRows.size();
        Vector rhs=Vector::Zero(nv+np);rhs.head(nv)=prepared.velocityScale.asDiagonal()*load;
        for(unsigned row=0;row<np;++row)
            rhs[nv+row]=-prepared.pressureScale[row]*(bodyContinuity.row(prepared.retainedRows[row])*twist)[0];
        Vector solved=Vector::Zero(rhs.size());
        if(prepared.hasSystem) {
            solved=prepared.solver.solve(rhs);
            if(prepared.solver.info()!=Eigen::Success||!solved.allFinite())
                throw std::runtime_error("conservative global pressure solve failed");
        }
        result.scaledEquationResidual=(prepared.saddle*solved-rhs).norm()/std::max<Real>(1,rhs.norm());
        result.flux=prepared.velocityScale.asDiagonal()*solved.head(nv);
        Vector pressure=Vector::Zero(conservative.size());
        for(unsigned row=0;row<np;++row)
            pressure[prepared.retainedRows[row]]=prepared.pressureScale[row]*solved[nv+row];
        result.stationarity=(mass*result.flux-load+continuity.transpose()*pressure).norm()/std::max<Real>(1,load.norm());
        result.local.resize(cells.size());result.pressure=Vector::Zero(cells.size());
        result.exactFaceMeans.resize(cells.size());result.exactMeanSums.resize(cells.size());
        Real reducedObjective=0;
        for(unsigned group=0;group<conservative.size();++group) {
            const auto& local=conservative[group];Vector boundary(local.externalVariables);
            for(unsigned face=0;face<local.boundaryKeys.size();++face)
                boundary.segment(3*face,3)=maps[group].signs[face]*result.flux.segment(maps[group].columns[face],3);
            boundary.tail(6)=twist;
            const auto state=local.Reconstruct(sources[group],boundary);
            result.reaction-=state.boundaryGradient.tail(6);
            result.reaction-=bodyContinuity.row(group).transpose()*pressure[group];
            result.energy+=state.energy;result.objective+=state.objective;
            reducedObjective+=state.reducedObjective;
            // Recover the local pressure gauge from internal edge stationarity
            // for diagnostics. The authoritative reaction above is the direct
            // derivative of the pre-parameterized kinetic objective.
            Vector gradient=Vector::Zero(local.internalVariables);
            for(unsigned piece=0;piece<local.pieces.size();++piece) {
                const auto& binding=local.pieces[piece];
                gradient+=binding.originalInternal.transpose()*binding.physical->condensed.Gradient(
                    state.faces[piece],sources[group].pieces[piece]);
            }
            Vector piecePressure=Vector::Zero(local.pieces.size());
            for(unsigned index=1;index<local.order.size();++index) {
                const unsigned piece=local.order[index],edge=local.parentEdge[piece];
                piecePressure[piece]=piecePressure[local.parent[piece]]-local.parentSign[piece]*gradient[3*edge];
            }
            for(unsigned piece=0;piece<local.pieces.size();++piece) {
                const unsigned cell=local.pieces[piece].cell;
                result.local[cell]=state.roundedKineticLocal[piece];
                result.pressure[cell]=piecePressure[piece]+pressure[group];
                result.exactFaceMeans[cell]=state.conservative.faceMeans[piece];
                result.exactMeanSums[cell]=state.conservative.cellSums[piece];
                result.exactTotalMean+=state.conservative.cellSums[piece];
                if(piece!=local.root && state.conservative.cellSums[piece]!=0)
                    throw std::runtime_error("conservative non-root mean state lost exact closure");
                if(piece==local.root) {
                    const Real rate=abs(state.conservative.cellSums[piece]/local.pieces[piece].physical->cell.exactVolume).convert_to<Real>();
                    result.maximumRootMeanDivergence=std::max(result.maximumRootMeanDivergence,rate);
                }
                // Retain the legacy integrated-moment diagnostic separately.
                // It is NOT the exact conservative primary mean certificate.
                result.balance=std::max(result.balance,
                    (cells[cell]->op.divergenceMoments*result.local[cell]).cwiseAbs().maxCoeff());
            }
        }
        result.objectiveReconstructionError=std::abs(result.objective-reducedObjective);
        result.energyIdentity=std::abs(result.objective+result.energy+twist.dot(result.reaction)-result.predictorEnergy);
        result.solveMs=Milliseconds(start);
        const Real scale=std::max<Real>(1,result.predictorEnergy+std::abs(twist.dot(result.reaction)));
        if(!result.reaction.allFinite()||!std::isfinite(result.energy)||result.scaledEquationResidual>1e-10L||
           result.stationarity>1e-10L||result.objectiveReconstructionError>1e-10L*scale||
           result.energyIdentity>1e-10L*scale||result.maximumRootMeanDivergence>1e-10L)
            throw std::runtime_error("conservative physical state violates pressure/work/mean-divergence acceptance");
        return result;
    }
    Result Solve(const std::vector<vm::Affine>& predictors,const Twist& twist=Twist::Zero()) const {
        if(predictors.size()!=cells.size()) throw std::invalid_argument("conservative affine predictor count is invalid");
        std::vector<Vector> raw;raw.reserve(cells.size());
        for(unsigned cell=0;cell<cells.size();++cell) {
            if(!predictors[cell].allFinite()) throw std::invalid_argument("conservative affine predictor is nonfinite");
            raw.push_back(cells[cell]->op.InterpolateAffineDOFs(predictors[cell]));
        }
        return SolveRaw(raw,twist);
    }
};
} // namespace stage17_conservative_network
