#include "LocalCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace net=stage17_network;
namespace lc=stage17_condensed;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;
    if(!condition) throw std::runtime_error(message);
}
struct Error {
    long double field=0,energy=0,wrench=0;
};
Error Compare(const net::Network& original,const net::Result& full,const lc::Result& reduced) {
    Error error;
    for(unsigned cell=0;cell<original.cells.size();++cell) {
        const auto& op=original.cells[cell]->op;
        const net::Vector difference=full.local[cell]-reduced.local[cell];
        const auto kinetic=std::abs(difference.dot(op.mass*difference));
        const auto scale=std::max<net::Real>(1,std::sqrt(std::abs(full.local[cell].dot(op.mass*full.local[cell]))));
        error.field=std::max(error.field,std::sqrt(kinetic)/scale);
        Check(std::sqrt(kinetic)/scale<1e-10L,
              "exact local condensation changes an actual physical cell endpoint");
    }
    error.energy=std::abs(full.energy-reduced.energy)/std::max<net::Real>(1,full.energy);
    error.wrench=(full.reaction-reduced.reaction).norm()/std::max<net::Real>(1,full.reaction.norm());
    Check(error.energy<1e-10L,"exact local condensation changes kinetic energy");
    Check(error.wrench<1e-10L,"exact local condensation changes native wrench");
    Check(reduced.balance<1e-12L&&reduced.stationarity<1e-12L,
          "local-condensed endpoints violate physical continuity/stationarity");
    Check(reduced.energyIdentity<1e-12L&&reduced.objectiveReconstructionError<1e-12L,
          "local condensation loses source energy or body work");
    Check(reduced.reactionReconstructionError<1e-12L&&reduced.localEquationResidual<1e-12L,
          "reconstructed local pressure or reaction is inconsistent");
    return error;
}
int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(double angle:{0.,.17}) {
            const auto box=owned_cut::BoxPlanes(V(.5),V(.2),
                glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
            net::Network original(1,box);
            const auto start=net::Clock::now();
            lc::LocalCondensedNetwork reduced(original);
            const double prepare=net::Milliseconds(start);
            for(unsigned scenario=0;scenario<4;++scenario) {
                auto predictor=original.Constant(net::vm::Vec3(0,-.04L,0));
                if(scenario==1||scenario==2)
                    for(unsigned cell=0;cell<predictor.size();++cell) {
                        predictor[cell][0]=.01L*(1+original.cells[cell]->cell.seed+3*original.cells[cell]->cell.piece);
                        predictor[cell][3]=.015L;
                        predictor[cell][6]=-.01L;
                        predictor[cell][9]=.012L;
                    }
                net::Twist body=net::Twist::Zero();
                if(scenario==2) body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
                std::vector<net::Vector> raw;
                for(unsigned cell=0;cell<original.cells.size();++cell) {
                    auto value=original.cells[cell]->op.InterpolateAffineDOFs(predictor[cell]);
                    if(scenario==3)
                        for(unsigned degree=0;degree<unsigned(value.size());++degree)
                            value[degree]=.001L*std::sin(net::Real(1+degree+11*cell));
                    raw.push_back(std::move(value));
                }
                const auto full=original.SolveRaw(raw,body);
                const auto small=reduced.SolveRaw(raw,body);
                const auto error=Compare(original,full,small);
                printf("LOCAL_CONDENSED angle=%g scenario=%u cells=%zu subdomains=%zu full_variables=%ld reduced_variables=%ld max_local_kkt=%u prepare_ms=%g condensation_ms=%g global_factor_ms=%g full_solve_ms=%g reduced_solve_ms=%g field_error=%Lg energy_error=%Lg wrench_error=%Lg balance=%Lg work=%Lg objective_error=%Lg\n",
                    angle,scenario,original.cells.size(),reduced.subdomains.size(),long(original.mass.rows()),long(reduced.mass.rows()),
                    reduced.maxLocalKkt,prepare,reduced.condensationMs,reduced.factorMs,full.solveMs,small.solveMs,
                    error.field,error.energy,error.wrench,small.balance,small.energyIdentity,small.objectiveReconstructionError);
            }
            Check(reduced.mass.rows()<original.mass.rows(),"local condensation did not remove internal ports");
            auto invalid=reduced.Constant(net::vm::Vec3::Zero());invalid[0][0]=NAN;
            bool rejected=false;
            try { reduced.Solve(invalid); } catch(const std::invalid_argument&) { rejected=true; }
            Check(rejected&&reduced.Solve(reduced.Constant(net::vm::Vec3::Zero())).energy==0,
                  "invalid local-condensed source poisons prepared state");
            net::Network open(1,box,1,net::Boundary::OpenTop);
            lc::LocalCondensedNetwork openReduced(open);
            net::Twist body;body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
            const auto a=open.Solve(open.Constant(net::vm::Vec3::Zero()),body);
            const auto b=openReduced.Solve(openReduced.Constant(net::vm::Vec3::Zero()),body);
            Compare(open,a,b);
        }
        const auto slab=owned_cut::BoxPlanes(V(.5),V(.1,2,2),glm::dquat(1,0,0,0));
        net::Network divided(1,slab);
        lc::LocalCondensedNetwork reduced(divided);
        Check(reduced.components.size()==2,"local condensation joins disconnected hydraulic components");
        net::Twist entering=net::Twist::Zero();entering[0]=.1L;
        bool rejected=false;
        try { reduced.Solve(reduced.Constant(net::vm::Vec3::Zero()),entering); }
        catch(const std::invalid_argument&) { rejected=true; }
        Check(rejected,"local elimination hides incompatible closed-component volume flow");
        Check(reduced.Solve(reduced.Constant(net::vm::Vec3::Zero())).energy==0,
              "failed component transaction leaves local fluid motion");
        printf("LOCAL_CONDENSED_SUMMARY checks=%u failures=0\n",checks);
        return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
