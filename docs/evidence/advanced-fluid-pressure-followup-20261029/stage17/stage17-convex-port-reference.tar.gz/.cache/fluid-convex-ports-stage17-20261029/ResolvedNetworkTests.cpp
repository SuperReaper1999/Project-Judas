#include "ResolvedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using namespace stage17_resolved_network;
unsigned checks=0,failures=0;
void Check(bool pass,const char* label){++checks;if(!pass){++failures;printf("FAIL %s\n",label);}}

R BodyVolume(const Box& box){std::array<RV,3> n;RV width;for(unsigned a=0;a<3;++a){for(unsigned b=0;b<3;++b)n[a][b]=R(box[2*a+1].normal[b]);width[a]=R(box[2*a].coordinate)+R(box[2*a+1].coordinate);}return width[0]*width[1]*width[2]/abs(owned_metrics::Dot(n[0],owned_metrics::Cross(n[1],n[2])));}

int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
    for(double angle:{0.,.17,3.2137858346770188e-11}){
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));Epoch epoch(1,box);
        for(unsigned scenario=0;scenario<3;++scenario){
            Twist body=Twist::Zero();if(scenario==1)body<<.01,-.02,.03,0,0,0;if(scenario==2)body<<.01,-.02,.03,.02,.03,-.01;
            const Vec source=scenario?Vec::Zero():Vec(0,-.04L,0);const auto result=epoch.Solve(epoch.Constant(source),body);
            Real maximumTrace=0,maximumCalm=0;
            for(const auto& [key,owners]:epoch.ports){
                const auto [c,f]=owners[0];const auto& local=*epoch.cells[c];
                for(const auto& triangle:local.source.faces[f].triangles)for(const auto& p:triangle.points){
                    const RV point=fr::Mul(p,epoch.scale);const Real normal=local.cell.PhysicalNormal(f,result.residual[c],point);
                    Real error=0;
                    if(owners.size()==2){const auto [d,g]=owners[1];error=std::abs(normal+epoch.cells[d]->cell.PhysicalNormal(g,result.residual[d],point));}
                    else if(key.kind==Kind::Solid)error=std::abs(normal);
                    else if(!epoch.Open(key)){const Vec x=fr::Rounded(point);const Vec rigid=body.head<3>()+body.tail<3>().cross(x);error=std::abs(normal+local.cell.framed.physicalNormals[f].dot(rigid));}
                    maximumTrace=std::max(maximumTrace,error);
                    if(scenario==0)maximumCalm=std::max(maximumCalm,local.cell.EvaluateProjectedPhysical(result.residual[c],point).norm());
                }
            }
            Check(result.stationarity<1e-10L && result.constraint<1e-10L,"uncondensed resolved kinetic KKT endpoint");
            Check(maximumTrace<1e-8L,"actual primary normal traces satisfy shared wall and solid conditions");
            Check(result.normalizedDivergence<1e-8L && result.pointDivergence<1e-8L,"actual normalized physical divergence endpoint");
            Check(result.roundedFaceRate<1e-8L,"actual rounded primary face-volume rates remain normalized conservative");
            Check(result.energyIdentity<1e-10L && (result.reaction-result.variationalReaction).norm()<1e-10L,"actual body wrench and complete kinetic work identity");
            if(scenario==0){const Vec expected=-1000*BodyVolume(box).convert_to<Real>()*source;Check(result.energy<1e-18L && maximumCalm<1e-8L,"uniform hydrostatic predictor remains physically calm");Check((result.reaction.head<3>()-expected).norm()<1e-9L,"independently correct hydrostatic native body impulse");}
            printf("RESOLVED_NETWORK angle=%.17g scenario=%u cells=%zu variables=%u constraints=%u build_ms=%g solve_ms=%g energy=%Lg force=%Lg,%Lg,%Lg trace=%Lg normalized_div=%Lg point_div=%Lg rounded_face_rate=%Lg kkt=%Lg constraint=%Lg work=%Lg reaction_gap=%Lg calm=%Lg\n",angle,scenario,epoch.cells.size(),epoch.variables,epoch.rows,epoch.buildMs,result.solveMs,result.energy,result.reaction[0],result.reaction[1],result.reaction[2],maximumTrace,result.normalizedDivergence,result.pointDivergence,result.roundedFaceRate,result.stationarity,result.constraint,result.energyIdentity,(result.reaction-result.variationalReaction).norm(),maximumCalm);
        }
    }
    printf("RESOLVED_NETWORK_SUMMARY checks=%u failures=%u\n",checks,failures);return failures?1:0;
}catch(const std::exception& error){fprintf(stderr,"ERROR after%uchecks %s\n",checks,error.what());return 1;}}
