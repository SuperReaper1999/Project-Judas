#include "SymmetricVoxelPorts.h"
#include "Network.h"
#include "LocalCondensedNetwork.h"
#include "ConservativeCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

// Private adversarial admission proof. The original physical gates are kept;
// a solver success is not itself permission to publish its physical state.
// Every failed assertion remains a failure, even when other controls pass.
namespace net = stage17_network;
namespace sy = symmetric_voxel_ports;
namespace condensed = stage17_condensed;
namespace exact = stage17_conservative_network;
unsigned checks = 0, failures = 0;
void Check(bool condition, const char* description) {
    ++checks;
    if (!condition) {
        ++failures;
        std::printf("FAIL %s\n", description);
    }
}

sy::R BodyVolume(const sy::Box& box) {
    std::array<sy::RV, 3> normal;
    sy::RV width;
    for (unsigned a = 0; a < 3; ++a) {
        for (unsigned b = 0; b < 3; ++b)
            normal[a][b] = sy::R(box[2 * a + 1].normal[b]);
        width[a] = sy::R(box[2 * a].coordinate) + sy::R(box[2 * a + 1].coordinate);
    }
    return width[0] * width[1] * width[2] /
        abs(owned_metrics::Dot(normal[0], owned_metrics::Cross(normal[1], normal[2])));
}

template<class World, class Result>
void Inspect(const World& world, const Result& solved, const net::Twist& motion,
             const net::vm::Vec3& input, const sy::R& displaced,
             const char* fixture, const char* solver, unsigned scenario) {
    net::Real normalized = 0, point = 0, trace = 0, calm = 0, rms = 0;
    net::Real smallest = INFINITY;
    unsigned worstCell = ~0u;
    for (unsigned c = 0; c < world.cells.size(); ++c) {
        const auto& cell = *world.cells[c];
        const auto& raw = solved.local[c];
        const net::Real volume = cell.op.geometry.volume[0];
        smallest = std::min(smallest, volume);
        const net::Real rate = (cell.op.divergenceMoments * raw).cwiseAbs().maxCoeff() / volume;
        if (rate > normalized) { normalized = rate; worstCell = c; }
        const auto divergence = cell.op.Divergence(raw);
        const auto projected = cell.op.Project(raw);
        if (scenario == 0)
            rms = std::max(rms, std::sqrt(2 * cell.op.Energy(raw) / (1000 * volume)));
        for (unsigned f = 0; f < cell.cell.faces.size(); ++f) {
            for (const auto& triangle : cell.cell.faces[f].triangles) {
                for (const auto& exactPoint : triangle.points) {
                    net::vm::Vec3 r, origin;
                    for (unsigned a = 0; a < 3; ++a) {
                        r[a] = exactPoint[a].template convert_to<net::Real>();
                        origin[a] = cell.cell.center[a].template convert_to<net::Real>();
                    }
                    Eigen::Matrix<net::Real, 4, 1> polynomial;
                    polynomial << 1, r.x(), r.y(), r.z();
                    point = std::max(point, std::abs(divergence.dot(polynomial)));
                    if (scenario == 0)
                        calm = std::max(calm, net::vm::EvaluateAffine(projected, r).norm());
                    if (cell.cell.faces[f].kind == net::Kind::Solid) {
                        const auto rigid = (motion.template head<3>() +
                            motion.template tail<3>().cross(origin + r)).eval();
                        trace = std::max(trace, std::abs(cell.op.EvaluateFaceNormal(f, raw, r) -
                            cell.op.geometry.faces[f].normal.dot(rigid)));
                    }
                }
            }
        }
    }
    const auto hydroError = (solved.reaction.template head<3>() +
        1000 * displaced.convert_to<net::Real>() * input).norm();
    std::printf("SYMMETRIC_ADMISSION fixture=%s solver=%s scenario=%u cells=%zu min_volume=%Lg "
        "energy=%Lg normalized_div=%Lg point_div=%Lg trace=%Lg calm=%Lg rms=%Lg "
        "hydro_error=%Lg work=%Lg stationarity=%Lg worst_cell=%u\n",
        fixture, solver, scenario, world.cells.size(), smallest, solved.energy, normalized,
        point, trace, calm, rms, hydroError, solved.energyIdentity, solved.stationarity, worstCell);
    Check(normalized < 1e-8L && point < 1e-8L && trace < 1e-8L,
          "actual thin-cell divergence and body boundary trace remain below unchanged 1e-8 gates");
    Check(solved.energyIdentity < 1e-10L && solved.stationarity < 1e-10L,
          "actual thin-cell kinetic work and stationarity remain valid");
    if (scenario == 0) {
        Check(hydroError < 1e-10L, "actual thin-cell hydrostatic body load is correct");
        Check(solved.energy < 1e-18L && calm < 1e-8L && rms < 1e-8L,
              "actual thin-cell hydrostatic physical state is locally calm");
    }
}

void Run(unsigned n, const sy::Box& box, const char* fixture) {
    sy::Compiler geometry;
    geometry.Build(n, box);
    const sy::R scale = sy::R(1) / n;
    const sy::R displaced = BodyVolume(box) * scale * scale * scale;
    sy::R exactWater = 0;
    for (const auto& cell : geometry.cells) exactWater += cell.volume;
    Check(exactWater == sy::R(n) * n * n - BodyVolume(box),
          "adversarial symmetric geometry retains every exact physical fluid volume");
    net::Network full(geometry, scale);
    condensed::Epoch local(full);
    exact::Epoch conservative(local);
    for (unsigned scenario = 0; scenario < 2; ++scenario) {
        const net::vm::Vec3 input = scenario ? net::vm::Vec3::Zero() : net::vm::Vec3(0, -.04L, 0);
        net::Twist motion = net::Twist::Zero();
        if (scenario) motion << .01L, -.02L, .03L, .02L, .03L, -.01L;
        const auto source = full.Constant(input);
        try {
            const auto result = full.Solve(source, motion);
            Inspect(full, result, motion, input, displaced, fixture, "uncondensed", scenario);
        } catch (const std::exception& error) {
            std::printf("SYMMETRIC_ADMISSION_REJECT fixture=%s solver=uncondensed scenario=%u reason=%s\n",
                        fixture, scenario, error.what());
            Check(false, "adversarial full pressure state was rejected");
        }
        try {
            const auto result = conservative.Solve(source, motion);
            Inspect(conservative, result, motion, input, displaced, fixture, "conservative", scenario);
            Check(result.exactTotalMean == 0 && result.maximumRootMeanDivergence < 1e-12L,
                  "adversarial conservative state preserves exact mean continuity");
        } catch (const std::exception& error) {
            std::printf("SYMMETRIC_ADMISSION_REJECT fixture=%s solver=conservative scenario=%u reason=%s\n",
                        fixture, scenario, error.what());
            Check(false, "adversarial conservative pressure state was rejected");
        }
    }
}

int main(int argc, char** argv) {
    std::setvbuf(stdout, nullptr, _IOLBF, 0);
    try {
        using V = glm::dvec3;
        const bool gap = argc > 1 && std::string(argv[1]) == "gap";
        if (gap) {
            Run(1, owned_cut::BoxPlanes(V(.2 + std::ldexp(1., -40), .5, .5), V(.2),
                                       glm::dquat(1, 0, 0, 0)), "true_wall_gap_2pow-40");
        } else {
            Run(2, owned_cut::BoxPlanes(V(.75), V(.25),
                glm::angleAxis(3.2137858346770188e-11, glm::normalize(V(1, 2, -.3)))),
                "true_voxel_corner");
        }
        std::printf("SYMMETRIC_ADMISSION_SUMMARY checks=%u failures=%u\n", checks, failures);
        return failures ? 1 : 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "SYMMETRIC_ADMISSION_ERROR checks=%u failures=%u reason=%s\n",
                     checks, failures, error.what());
        return 1;
    }
}
