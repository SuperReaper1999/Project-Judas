#pragma once

// PRIVATE basis-construction experiment, BEFORE any field or fluid solve.
// Native/resolved states are not changed. Primary kernel coefficients remain
// rational; casting them back to one float cannot claim the exact identities.
#include "ResolvedCell.h"
#include "acceptance/ExactKernelMoments.h"

namespace exact_kernel_basis {
using R=exact_kernel::R;
using Real=JudasFluidVem::Real;
using Matrix=std::vector<std::vector<R>>;

struct Basis {
    unsigned rows=0,columns=0;
    std::array<unsigned,6> pivot{};
    Matrix original,primary,kineticFactor;
    std::array<std::vector<R>,6> constraints;
    Real maxColumnCorrectionNorm=0,correctionFrobeniusNorm=0,maxOriginalConstraint=0,
         originalGramError=0,correctedGramError=0,pivotRatio=0;

    Basis(const stage17_resolved::Cell& candidate,const exact_kernel::Oracle& oracle) {
        rows=candidate.faceDimension;columns=candidate.kernelDimension;
        if(rows<6 || columns!=rows-6) throw std::runtime_error("exact kernel basis dimensions are inconsistent");
        constraints=oracle.SymmetricConstraints();
        JudasFluidVem::Matrix floating(6,rows);
        for(unsigned i=0;i<6;++i)
            for(unsigned j=0;j<rows;++j) floating(i,j)=constraints[i][j].convert_to<Real>();
        if(!floating.allFinite()) throw std::runtime_error("exact kernel constraints are not representable for pivot discovery");
        Eigen::FullPivLU<JudasFluidVem::Matrix> discovery(floating);
        const auto order=discovery.permutationQ().indices();
        Real smallest=std::numeric_limits<Real>::infinity(),largest=0;
        for(unsigned i=0;i<6;++i) {
            pivot[i]=order[i];
            const Real diagonal=std::abs(discovery.matrixLU()(i,i));
            smallest=std::min(smallest,diagonal);largest=std::max(largest,diagonal);
        }
        pivotRatio=smallest/largest;
        // Numerical rank is NOT used to delete a weak constraint. The six
        // chosen columns must instead be independently invertible in R.
        exact_kernel::Matrix<6> exactPivot{};
        for(unsigned i=0;i<6;++i)
            for(unsigned j=0;j<6;++j) exactPivot[i][j]=constraints[i][pivot[j]];
        const auto inverse=exact_kernel::Inverse<6>(exactPivot);

        original.assign(rows,std::vector<R>(columns,R(0)));
        for(unsigned i=0;i<rows;++i)
            for(unsigned j=0;j<columns;++j) original[i][j]=R(candidate.kernelFace(i,j));
        primary=original;
        for(unsigned column=0;column<columns;++column) {
            std::array<R,6> residual{};
            for(unsigned i=0;i<6;++i) {
                for(unsigned j=0;j<rows;++j) residual[i]+=constraints[i][j]*original[j][column];
                maxOriginalConstraint=std::max(maxOriginalConstraint,abs(residual[i]).convert_to<Real>());
            }
            for(unsigned p=0;p<6;++p) {
                R delta=0;
                for(unsigned i=0;i<6;++i) delta-=inverse[p][i]*residual[i];
                primary[pivot[p]][column]+=delta;
            }
        }
        for(unsigned column=0;column<columns;++column)
            for(unsigned i=0;i<6;++i) {
                R residual=0;
                for(unsigned j=0;j<rows;++j) residual+=constraints[i][j]*primary[j][column];
                if(residual!=0) throw std::runtime_error("constructed primary basis does not satisfy exact Green constraint");
            }
        for(unsigned row=0;row<rows;++row)
            if(std::find(pivot.begin(),pivot.end(),row)==pivot.end())
                for(unsigned column=0;column<columns;++column)
                    if(primary[row][column]!=original[row][column])
                        throw std::runtime_error("nonpivot primary coefficient changed during exact basis construction");

        // Full ACTUAL Sroot*K factor. Do not replace it by identity or fit S.
        kineticFactor.assign(rows,std::vector<R>(columns,R(0)));
        Matrix oldFactor(rows,std::vector<R>(columns,R(0)));
        R frobenius=0;
        for(unsigned row=0;row<rows;++row)
            for(unsigned column=0;column<columns;++column)
                for(unsigned local=0;local<3;++local) {
                    const unsigned source=(row/3)*3+local;
                    const R weight=R(candidate.faceRoot(row,source));
                    kineticFactor[row][column]+=weight*primary[source][column];
                    oldFactor[row][column]+=weight*original[source][column];
                }
        for(unsigned column=0;column<columns;++column) {
            R correction=0;
            for(unsigned row=0;row<rows;++row) {
                const R delta=kineticFactor[row][column]-oldFactor[row][column];
                correction+=delta*delta;
            }
            frobenius+=correction;
            maxColumnCorrectionNorm=std::max(maxColumnCorrectionNorm,std::sqrt(correction.convert_to<Real>()));
        }
        correctionFrobeniusNorm=std::sqrt(frobenius.convert_to<Real>());
        std::vector<R> diagonal(columns,R(0)),offDiagonal(columns,R(0));
        for(unsigned a=0;a<columns;++a)
            for(unsigned b=0;b<columns;++b) {
                R oldGram=0,newGram=0;
                for(unsigned row=0;row<rows;++row) {
                    oldGram+=oldFactor[row][a]*oldFactor[row][b];
                    newGram+=kineticFactor[row][a]*kineticFactor[row][b];
                }
                const R target=a==b?R(1):R(0);
                if(a==b) diagonal[a]=oldGram;
                else offDiagonal[a]+=abs(oldGram);
                originalGramError=std::max(originalGramError,abs(oldGram-target).convert_to<Real>());
                correctedGramError=std::max(correctedGramError,abs(newGram-target).convert_to<Real>());
            }
        R lower=diagonal[0]-offDiagonal[0];
        for(unsigned i=1;i<columns;++i) lower=std::min(lower,R(diagonal[i]-offDiagonal[i]));
        // Exact Gershgorin lower bound plus Weyl/Frobenius perturbation:
        // sigma_min(Fold)>=sqrt(lower), ||Fnew-Fold||2<=sqrt(frobenius).
        // This proves no kinetic/kernel mode was lost without a floating rank
        // threshold or an expensive exact inverse of the full kernel basis.
        if(lower<=0 || frobenius>=lower)
            throw std::runtime_error("cannot certify preservation of every exact kernel mode");
    }

    std::vector<R> Flux(const JudasFluidVem::Vector& coordinates) const {
        if(coordinates.size()!=columns) throw std::invalid_argument("exact kernel coordinate count mismatch");
        std::vector<R> q(rows,R(0));
        for(unsigned row=0;row<rows;++row)
            for(unsigned column=0;column<columns;++column)
                q[row]+=primary[row][column]*R(coordinates[column]);
        return q;
    }
    R EnergyExact(const JudasFluidVem::Vector& coordinates) const {
        if(coordinates.size()!=columns) throw std::invalid_argument("exact kinetic coordinate count mismatch");
        R energy=0;
        for(unsigned row=0;row<rows;++row) {
            R value=0;
            for(unsigned column=0;column<columns;++column)
                value+=kineticFactor[row][column]*R(coordinates[column]);
            energy+=value*value/2;
        }
        return energy;
    }
};
} // namespace exact_kernel_basis
