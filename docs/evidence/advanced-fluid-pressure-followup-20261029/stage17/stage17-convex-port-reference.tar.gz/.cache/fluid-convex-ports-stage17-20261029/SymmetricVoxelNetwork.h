#pragma once
#include "SymmetricVoxelPorts.h"
#include "Network.h"
namespace stage17_symmetric_voxel {
using namespace stage17_network;
struct Epoch : Network {
    static symmetric_voxel_ports::Compiler Geometry(unsigned grid,const Box& box) {
        symmetric_voxel_ports::Compiler geometry;geometry.Build(grid,box);return geometry;
    }
    Epoch(unsigned grid,const Box& box,const vg::R& scale=1,Boundary condition=Boundary::Sealed)
        :Epoch(Geometry(grid,box),scale,condition) {}
    Epoch(const symmetric_voxel_ports::Compiler& geometry,const vg::R& scale=1,Boundary condition=Boundary::Sealed)
        :Network(geometry,scale,condition) {}
};
} // namespace stage17_symmetric_voxel
