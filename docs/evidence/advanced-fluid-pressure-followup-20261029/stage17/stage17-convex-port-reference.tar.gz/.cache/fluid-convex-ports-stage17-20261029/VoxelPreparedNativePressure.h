#pragma once
#include "VoxelNetwork.h"
#include "PreparedMechanicalSchur.h"
#include "../fluid-moving-geometry-stage13-20261029/LocalizedGeometry.h"
#include "PhysicsConstraintBatch.h"

namespace stage17_voxel_prepared_native {

using namespace stage17_network;
using Epoch=stage17_voxel::Epoch;
namespace mg=moving_geometry;
inline double Ms(Clock::time_point t){return Milliseconds(t);}
using Mat6=Eigen::Matrix<Real,6,6>;
using Vec3=vm::Vec3;

inline Eigen::Matrix<Real,3,3> CrossMatrix(const Vec3& a) {
    Eigen::Matrix<Real,3,3> result;
    result<<0,-a.z(),a.y(), a.z(),0,-a.x(), -a.y(),a.x(),0;
    return result;
}

// One geometry epoch, exactly reduced to native center-of-mass twist variables.
// The six zero-source unit probes are linear solves of the SAME prepared
// operator, not finite differences of geometry or a fitted acceleration curve.
struct FluidSchur {
    const Epoch& epoch;
    std::vector<vm::Affine> predictors;
    Mat6 comToOrigin=Mat6::Identity();
    Mat6 addedMass=Mat6::Zero();
    Twist load=Twist::Zero();
    Real symmetryError=0;

    FluidSchur(const Epoch& source,const std::vector<vm::Affine>& predictor,const Vec3& center)
        :epoch(source),predictors(predictor) {
        comToOrigin.topRightCorner<3,3>()=CrossMatrix(center);
        const stage17_mechanical::Operator reduced(epoch);
        load=comToOrigin.transpose()*reduced.Source(predictors);
        const Mat6 originMass=reduced.addedMass;
        const Mat6 raw=comToOrigin.transpose()*originMass*comToOrigin;
        symmetryError=(raw-raw.transpose()).norm()/std::max<Real>(1,raw.norm());
        if(symmetryError>1e-10L) throw std::runtime_error("native VEM added-mass operator lost work symmetry");
        addedMass=(raw+raw.transpose()).eval()/2;
    }
    Result Reconstruct(const Twist& comVelocity) const {
        return epoch.Solve(predictors,comToOrigin*comVelocity);
    }
    Twist ReactionAtCom(const Result& fluid) const {
        return comToOrigin.transpose()*fluid.reaction;
    }
};

struct Solution {
    Twist velocity=Twist::Zero(),reaction=Twist::Zero(),predictor=Twist::Zero();
    Mat6 bodyMass=Mat6::Zero();
    Vector jointImpulses,jointTargets;
    Matrix joints;
    Result fluid;
    Real energyBefore=0,energyAfter=0,projectionLoss=0,jointWork=0,energyDefect=0,stationarity=0;
};

inline Solution Solve(const FluidSchur& pressure,const PhysicsConstraintBatch& batch,unsigned owner) {
    if(owner>=batch.bodies.size() || !(batch.bodies[owner].inverseMass>0))
        throw std::runtime_error("native VEM fixture requires one dynamic owning body");
    if(!batch.contacts.empty()) throw std::runtime_error("native VEM bilateral proof does not silently substitute floor contacts");
    for(unsigned b=0;b<batch.bodies.size();++b)
        if(b!=owner && batch.bodies[b].inverseMass>0)
            throw std::runtime_error("native VEM bounded proof has an unrepresented dynamic neighbor");
    const auto& body=batch.bodies[owner];
    Solution result;
    for(unsigned a=0;a<3;++a) {
        result.bodyMass(a,a)=1/Real(body.inverseMass);
        result.predictor(a)=body.linearVelocity[a];
        result.predictor(a+3)=body.angularVelocity[a];
    }
    Eigen::Matrix<Real,3,3> inverseInertia;
    for(unsigned a=0;a<3;++a)for(unsigned b=0;b<3;++b)
        inverseInertia(a,b)=body.inverseInertia[b][a];
    result.bodyMass.bottomRightCorner<3,3>()=vm::PositiveInverse(inverseInertia,"native body inverse inertia is not positive");
    const Mat6 kinetic=result.bodyMass+pressure.addedMass;
    Eigen::LLT<Mat6> factor(kinetic);
    if(factor.info()!=Eigen::Success) throw std::runtime_error("native coupled mass metric is not positive");
    const Twist source=result.bodyMass*result.predictor+pressure.load;
    result.velocity=factor.solve(source);
    result.joints=Matrix::Zero(batch.joints.size(),6);
    result.jointTargets=Vector::Zero(batch.joints.size());
    for(unsigned j=0;j<batch.joints.size();++j) {
        const auto& row=batch.joints[j];
        result.jointTargets(j)=-row.bias;
        for(bool side:{false,true}) {
            const unsigned b=side?row.b:row.a;
            if(b>=batch.bodies.size()) throw std::runtime_error("native joint snapshot has invalid body index");
            const auto linear=side?row.linearB:row.linearA,angular=side?row.angularB:row.angularA;
            if(b==owner) {
                for(unsigned a=0;a<3;++a) {
                    result.joints(j,a)+=linear[a];
                    result.joints(j,a+3)+=angular[a];
                }
            } else {
                const auto& fixed=batch.bodies[b];
                result.jointTargets(j)-=glm::dot(linear,fixed.linearVelocity)+glm::dot(angular,fixed.angularVelocity);
            }
        }
    }
    if(!batch.joints.empty()) {
        const Matrix response=factor.solve(result.joints.transpose());
        Matrix schur=result.joints*response;
        schur=(schur+schur.transpose()).eval()/2;
        Eigen::LLT<Matrix> jointFactor(schur);
        if(jointFactor.info()!=Eigen::Success)
            throw std::runtime_error("native VEM proof requires independent actual bilateral rows");
        const Vector multiplier=jointFactor.solve(result.joints*result.velocity-result.jointTargets);
        result.velocity-=response*multiplier;
        result.jointImpulses=-multiplier;
    } else result.jointImpulses=Vector(0);
    result.fluid=pressure.Reconstruct(result.velocity);
    result.reaction=pressure.ReactionAtCom(result.fluid);
    const Twist nativeResidual=result.bodyMass*(result.velocity-result.predictor)-result.reaction-result.joints.transpose()*result.jointImpulses;
    result.stationarity=nativeResidual.norm();
    result.energyBefore=result.fluid.predictorEnergy+result.predictor.dot(result.bodyMass*result.predictor)/2;
    result.energyAfter=result.fluid.energy+result.velocity.dot(result.bodyMass*result.velocity)/2;
    const Twist difference=result.velocity-result.predictor;
    result.projectionLoss=result.fluid.objective+difference.dot(result.bodyMass*difference)/2;
    result.jointWork=result.jointImpulses.dot(result.jointTargets);
    result.energyDefect=std::abs(result.projectionLoss+result.energyAfter-result.energyBefore-result.jointWork);
    if(!result.velocity.allFinite() || !result.reaction.allFinite() || !std::isfinite(result.energyAfter))
        throw std::runtime_error("native coupled VEM result is nonfinite");
    return result;
}

} // namespace stage17_voxel_prepared_native
