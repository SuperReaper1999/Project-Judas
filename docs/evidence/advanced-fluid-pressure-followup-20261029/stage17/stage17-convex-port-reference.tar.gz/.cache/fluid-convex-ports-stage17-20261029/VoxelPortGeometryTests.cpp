// Independent voxel oracle: frozen fine tetrahedra are summed by seed/6.
// Three-corner BG labels identify FULL SQUARES, never half-triangle apertures.
#include "VoxelPorts.h"
#include "acceptance/ExactPatchOracle.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>

namespace cp=convex_ports;
namespace pa=port_acceptance;
using pa::R;
using pa::RV;
using pa::Patch;
using pa::Moments;
using BgKey=std::array<motion_mesh::Lattice,3>;
unsigned checks=0,pairedPorts=0;
void Check(bool value,const char* description) {
    ++checks;
    if(!value) throw std::runtime_error(description);
}

struct Dsu {
    std::vector<unsigned> parent;
    explicit Dsu(unsigned n):parent(n) { std::iota(parent.begin(),parent.end(),0); }
    unsigned Root(unsigned n) const { while(parent[n]!=n) n=parent[n];return n; }
    void Join(unsigned a,unsigned b) { parent[Root(a)]=Root(b); }
};

R PlaneValue(const fluid_exact::Plane& plane,const RV& point) {
    R value=-R(plane.coordinate);
    for(unsigned axis=0;axis<3;++axis) value+=R(plane.normal[axis])*point[axis];
    return value;
}
RV Position(motion_mesh::Lattice point) { return {R(point[0]),R(point[1]),R(point[2])}; }

std::array<BgKey,6> CubeFaces(unsigned grid,unsigned voxel) {
    const unsigned xyz[3]={voxel%grid,(voxel/grid)%grid,voxel/(grid*grid)};
    std::array<BgKey,6> result;
    for(unsigned axis=0;axis<3;++axis)
        for(unsigned side=0;side<2;++side) {
            motion_mesh::Lattice ll{int(xyz[0]),int(xyz[1]),int(xyz[2])};
            ll[axis]+=side;
            auto hl=ll,lh=ll;
            ++hl[(axis+1)%3];++lh[(axis+2)%3];
            result[2*axis+side]={ll,hl,lh};
            std::sort(result[2*axis+side].begin(),result[2*axis+side].end());
        }
    return result;
}
bool On(const pa::Triangle& triangle,const BgKey& background) {
    const auto a=Position(background[0]);
    const auto n=owned_metrics::Cross(pa::Sub(Position(background[1]),a),pa::Sub(Position(background[2]),a));
    for(const auto& p:triangle.points) if(owned_metrics::Dot(n,pa::Sub(p,a))!=0) return false;
    return true;
}
bool InsideCube(unsigned grid,unsigned voxel,const RV& point) {
    const unsigned xyz[3]={voxel%grid,(voxel/grid)%grid,voxel/(grid*grid)};
    for(unsigned axis=0;axis<3;++axis)
        if(point[axis]<R(xyz[axis]) || point[axis]>R(xyz[axis]+1)) return false;
    return true;
}

struct Surface {
    unsigned seed=0;
    int solid=-1;
    BgKey background{};
    bool operator<(const Surface& b) const { return std::tie(seed,solid,background)<std::tie(b.seed,b.solid,b.background); }
};
using Surfaces=std::map<Surface,Patch>;

Surface Classify(unsigned grid,unsigned seed,const pa::Triangle& triangle,const cp::Box& box) {
    bool inside=true;
    for(const auto& plane:box)
        for(const auto& p:triangle.points) inside&=PlaneValue(plane,p)<=0;
    if(inside)
        for(unsigned solid=0;solid<6;++solid) {
            bool on=true;
            for(const auto& p:triangle.points) on&=PlaneValue(box[solid],p)==0;
            if(on) return {seed,int(solid),{}};
        }
    for(const auto& background:CubeFaces(grid,seed)) if(On(triangle,background)) return {seed,-1,background};
    throw std::runtime_error("fine physical boundary has neither true solid nor original background ownership");
}

struct Reference {
    std::map<unsigned,Moments> perVoxel;
    Surfaces surfaces;
    std::vector<Moments> components;
    unsigned tetrahedra=0;
};

Reference FineReference(unsigned grid,const cp::Box& box,const std::vector<unsigned>& seeds) {
    motion_mesh::Compiler mesh;
    std::vector<unsigned> fineSeeds;
    for(unsigned voxel:seeds) for(unsigned local=0;local<6;++local) fineSeeds.push_back(6*voxel+local);
    mesh.BuildSelected(grid,box,fineSeeds);
    Reference reference;
    reference.tetrahedra=mesh.tetrahedra.size();
    struct Owner { unsigned tet,opposite; };
    std::map<std::array<unsigned,3>,std::vector<Owner>> faces;
    std::vector<Moments> moments;
    Dsu components(mesh.tetrahedra.size());
    for(unsigned t=0;t<mesh.tetrahedra.size();++t) {
        const auto& tet=mesh.tetrahedra[t];
        std::array<RV,4> p;
        for(unsigned i=0;i<4;++i) p[i]=owned_metrics::Position(mesh.vertices[tet.vertices[i]].exact);
        moments.push_back(pa::TetraP2(p));
        pa::Add(reference.perVoxel[tet.seed/6],moments.back());
        for(unsigned opposite=0;opposite<4;++opposite) {
            std::array<unsigned,3> key;
            unsigned at=0;
            for(unsigned i=0;i<4;++i) if(i!=opposite) key[at++]=tet.vertices[i];
            std::sort(key.begin(),key.end());
            auto& owners=faces[key];
            if(!owners.empty()) components.Join(t,owners[0].tet);
            owners.push_back({t,opposite});
            Check(owners.size()<=2,"independent fine oracle found nonmanifold geometry");
        }
    }
    std::map<unsigned,Moments> sums;
    for(unsigned t=0;t<moments.size();++t) pa::Add(sums[components.Root(t)],moments[t]);
    for(const auto& entry:sums) reference.components.push_back(entry.second);
    std::sort(reference.components.begin(),reference.components.end());

    for(const auto& [key,owners]:faces) {
        if(owners.size()==2 && mesh.tetrahedra[owners[0].tet].seed/6==mesh.tetrahedra[owners[1].tet].seed/6) continue;
        for(const auto& owner:owners) {
            pa::Triangle triangle;
            for(unsigned i=0;i<3;++i) triangle.points[i]=owned_metrics::Position(mesh.vertices[key[i]].exact);
            triangle.areaVector=pa::Scale(owned_metrics::Cross(pa::Sub(triangle.points[1],triangle.points[0]),
                pa::Sub(triangle.points[2],triangle.points[0])),R(1)/2);
            const auto& tet=mesh.tetrahedra[owner.tet];
            const auto opposite=owned_metrics::Position(mesh.vertices[tet.vertices[owner.opposite]].exact);
            if(owned_metrics::Dot(triangle.areaVector,pa::Sub(opposite,triangle.points[0]))>0) {
                std::swap(triangle.points[1],triangle.points[2]);
                triangle.areaVector=pa::Scale(triangle.areaVector,-R(1));
            }
            const auto surface=Classify(grid,tet.seed/6,triangle,box);
            reference.surfaces[surface].push_back(std::move(triangle));
        }
    }
    return reference;
}

void OracleControls() {
    auto triangle=[](RV a,RV b,RV c) {
        pa::Triangle out;
        out.points={a,b,c};
        out.areaVector=pa::Scale(owned_metrics::Cross(pa::Sub(b,a),pa::Sub(c,a)),R(1)/2);
        return out;
    };
    const Patch squareA{triangle({0,0,0},{1,0,0},{1,1,0}),triangle({0,0,0},{1,1,0},{0,1,0})};
    const Patch squareB{triangle({0,0,0},{1,0,0},{0,1,0}),triangle({1,0,0},{1,1,0},{0,1,0})};
    Check(pa::SelfOverlap(squareA,2)==0 && pa::SelfOverlap(squareB,2)==0,"oracle square triangulation overlap");
    Check(pa::SymmetricDifference(squareA,squareB,2)==0,"different triangulations of same actual aperture");
    Patch shifted=squareB;
    for(auto& t:shifted) for(auto& p:t.points) p[0]+=R(1)/4;
    Check(pa::Area(squareA,2)==pa::Area(shifted,2),"negative aperture control must have same area");
    Check(pa::SymmetricDifference(squareA,shifted,2)>0,"same-area different aperture must be detected");
    Patch missing{squareA[0]};
    Check(pa::SymmetricDifference(squareA,missing,2)>0,"missing half-port must be detected");
}

void VerifyTriangle(const pa::Triangle& triangle) {
    const auto area=pa::Scale(owned_metrics::Cross(pa::Sub(triangle.points[1],triangle.points[0]),
        pa::Sub(triangle.points[2],triangle.points[0])),R(1)/2);
    Check(area==triangle.areaVector,"published area vector disagrees with actual vertices");
    Check(area!=RV{},"published port triangle has zero physical area");
}

void Verify(unsigned grid,const cp::Box& box,const std::vector<unsigned>& selected,
            const cp::Compiler& candidate,const Reference& reference,unsigned fixture) {
    std::map<unsigned,Moments> perVoxel;
    Surfaces surfaces;
    std::vector<Moments> cellMoments;
    std::map<cp::PortKey,std::vector<std::pair<unsigned,const cp::Face*>>> ports;
    std::map<BgKey,unsigned> backgroundOwners;
    for(unsigned seed:selected) for(const auto& key:CubeFaces(grid,seed)) ++backgroundOwners[key];
    std::map<unsigned,unsigned> pieceCounts;
    for(unsigned c=0;c<candidate.cells.size();++c) {
        const auto& cell=candidate.cells[c];
        Check(++pieceCounts[cell.seed]<=6,"more than six sequential convex cells in one seed");
        Check(cell.piece<6,"cell lost actual first excluding cut identity");
        Moments volume{};
        for(const auto& tet:cell.integration) {
            const auto m=pa::TetraP2(tet.points);
            Check(m[0]==tet.volume && tet.volume>0,"positive integration volume differs from actual tetrahedron");
            pa::Add(volume,m);
            bool strictlyOutside=false;
            for(const auto& point:tet.points) {
                Check(InsideCube(grid,cell.seed,point),"positive physical piece extends outside its original seed");
                for(unsigned previous=0;previous<cell.piece;++previous)
                    Check(PlaneValue(box[previous],point)<=0,"convex piece crosses an earlier excluding plane");
                Check(PlaneValue(box[cell.piece],point)>=0,"convex piece crosses its own outside halfspace");
                strictlyOutside|=PlaneValue(box[cell.piece],point)>0;
            }
            Check(strictlyOutside,"positive volume piece is only a zero-thickness cut contact");
        }
        Check(volume[0]==cell.volume && cell.volume>0,"cell actual capacity differs from integration");
        cellMoments.push_back(volume);
        pa::Add(perVoxel[cell.seed],volume);
        Patch boundary;
        RV areaSum{};
        for(const auto& face:cell.faces) {
            Check(!face.triangles.empty(),"published port is empty");
            Check(face.kind==face.key.kind,"physical face kind disagrees with its public port identity");
            if(face.kind==cp::Kind::Background) {
                const auto original=CubeFaces(grid,cell.seed);
                Check(std::find(original.begin(),original.end(),face.key.background)!=original.end(),
                      "background identity is not an original face of this seed");
            }
            const auto& first=face.triangles.front();
            for(const auto& triangle:face.triangles) {
                VerifyTriangle(triangle);
                for(const auto& point:triangle.points) {
                    Check(InsideCube(grid,cell.seed,point),"physical port extends outside its original seed triangle");
                    for(unsigned previous=0;previous<cell.piece;++previous)
                        Check(PlaneValue(box[previous],point)<=0,"physical port crosses an earlier piece halfspace");
                    Check(PlaneValue(box[cell.piece],point)>=0,"physical port extends beyond its convex piece");
                    Check(owned_metrics::Dot(first.areaVector,pa::Sub(point,first.points[0]))==0,
                          "one port contains noncoplanar pieces");
                }
                boundary.push_back(triangle);
                areaSum=pa::Sum(areaSum,triangle.areaVector);
                if(face.kind==cp::Kind::Solid) {
                    Check(face.solid>=0 && face.solid<6,"solid port lost actual body-plane identity");
                    for(const auto& point:triangle.points) {
                        for(const auto& plane:box) Check(PlaneValue(plane,point)<=0,"solid patch extends outside body");
                        Check(PlaneValue(box[face.solid],point)==0,"solid patch not on claimed body plane");
                    }
                    RV normal{R(box[face.solid].normal[0]),R(box[face.solid].normal[1]),R(box[face.solid].normal[2])};
                    Check(owned_metrics::Dot(triangle.areaVector,normal)<0,"solid normal does not point into body");
                } else if(face.kind==cp::Kind::Background) {
                    Check(On(triangle,face.key.background),"background patch moved off original plane");
                    RV center=pa::Scale(pa::Sum(pa::Sum(triangle.points[0],triangle.points[1]),triangle.points[2]),R(1)/3);
                    unsigned firstOutside=6;
                    for(unsigned i=0;i<6;++i) if(PlaneValue(box[i],center)>0) {firstOutside=i;break;}
                    Check(firstOutside<6 && firstOutside==face.key.exclusion,
                          "background key is not the actual first STRICTLY excluding cut");
                    for(const auto& point:triangle.points) {
                        for(unsigned previous=0;previous<face.key.exclusion;++previous)
                            Check(PlaneValue(box[previous],point)<=0,"background aperture spans a different exclusion region");
                        Check(PlaneValue(box[face.key.exclusion],point)>=0,"background aperture includes solid material");
                    }
                } else {
                    Check(face.key.seed==cell.seed && face.key.first<face.key.second,
                          "internal port has unrelated or unordered ownership");
                    Check(cell.piece==face.key.first || cell.piece==face.key.second,
                          "internal port joined unrelated physical piece");
                    for(const auto& point:triangle.points)
                        Check(PlaneValue(box[face.key.first],point)==0,"internal aperture not on actual shared cap");
                }
            }
            // Convexity is checked independently from candidate volume/closure:
            // every positive integration vertex lies behind every actual port.
            for(const auto& tet:cell.integration) for(const auto& point:tet.points)
                Check(owned_metrics::Dot(first.areaVector,pa::Sub(point,first.points[0]))<=0,
                      "published physical cell is not convex");
            if(face.kind==cp::Kind::Solid)
                surfaces[{cell.seed,face.solid,{}}].insert(surfaces[{cell.seed,face.solid,{}}].end(),face.triangles.begin(),face.triangles.end());
            else {
                ports[face.key].push_back({c,&face});
                if(face.kind==cp::Kind::Background) {
                    auto& patch=surfaces[{cell.seed,-1,face.key.background}];
                    patch.insert(patch.end(),face.triangles.begin(),face.triangles.end());
                }
            }
        }
        Check(areaSum==RV{},"physical convex cell boundary does not close");
        Check(pa::BoundaryVolumeP2(boundary)==volume,"independent boundary volume/first/P2 differs from positive integration");
    }
    Check(perVoxel==reference.perVoxel,"actual per-voxel volume/first/P2 differs from frozen six-tet sum");
    if(fixture==1 || fixture==2 || fixture==3) {
        R actualVolume=0;
        R minimum=candidate.cells.front().volume;
        for(const auto& cell:candidate.cells) {
            actualVolume+=cell.volume;
            minimum=std::min(minimum,cell.volume);
        }
        Check(candidate.cells.size()==6,"interior .4-box should leave six actual convex voxel pieces");
        Check(abs(actualVolume-R(.936))<R(1)/100000000000000L,"unit-voxel physical water capacity is not .936");
        // This is a measurable consequence of THIS authored geometry, never a
        // runtime cutoff: the interior box is separated from all cube walls.
        Check(minimum>R(1)/100,"background diagonals manufactured microscopic physical cells");
        std::printf("VOXEL_INTERIOR_CAPACITY fixture=%u volume=%Lg minimum_piece_volume=%Lg\n",
                    fixture,actualVolume.convert_to<long double>(),minimum.convert_to<long double>());
    }
    Check(surfaces.size()==reference.surfaces.size(),"wetted solid/background coverage owner count differs");
    for(const auto& [surface,actual]:surfaces) {
        const auto at=reference.surfaces.find(surface);
        Check(at!=reference.surfaces.end(),"physical surface has no frozen independent reference owner");
        const unsigned pivot=pa::Pivot(actual.front());
        Check(pa::SelfOverlap(actual,pivot)==0,"physical patch partition overlaps itself");
        Check(pa::PatchP2(actual,pivot)==pa::PatchP2(at->second,pivot),
              "wetted solid/background projected area/first/P2 coverage differs");
        if(fixture==0 && surface.solid<0) {
            pa::Triangle identifierTriangle;
            for(unsigned i=0;i<3;++i) identifierTriangle.points[i]=Position(surface.background[i]);
            identifierTriangle.areaVector=pa::Scale(owned_metrics::Cross(
                pa::Sub(identifierTriangle.points[1],identifierTriangle.points[0]),
                pa::Sub(identifierTriangle.points[2],identifierTriangle.points[0])),R(1)/2);
            Check(pa::Area(actual,pivot)==1,"uncut logical cube face is not a full unit square");
            Check(pa::Area(Patch{identifierTriangle},pivot)==R(1)/2,
                  "three-corner identifier negative control is not a half square");
            Check(pa::SymmetricDifference(actual,Patch{identifierTriangle},pivot)>0,
                  "quad aperture oracle incorrectly treats label triangle as actual geometry");
        }
    }
    Dsu islands(candidate.cells.size());
    for(const auto& [key,owners]:ports) {
        const bool paired=key.kind==cp::Kind::Internal || backgroundOwners[key.background]==2;
        Check(owners.size()==(paired?2u:1u),"port has missing or excess physical fluid owner");
        if(!paired) continue;
        Check(owners[0].first!=owners[1].first,"port connects a physical cell to itself");
        const auto& left=owners[0].second->triangles;
        const auto& right=owners[1].second->triangles;
        const unsigned pivot=pa::Pivot(left.front());
        Check(pa::SelfOverlap(left,pivot)==0 && pa::SelfOverlap(right,pivot)==0,"paired port has overlapping fragments");
        for(const auto& triangle:right) for(const auto& p:triangle.points)
            Check(owned_metrics::Dot(left[0].areaVector,pa::Sub(p,left[0].points[0]))==0,
                  "paired ports are not on the same exact supporting plane");
        Check(pa::SymmetricDifference(left,right,pivot)==0,"paired actual apertures differ despite any equal area");
        RV summed{};
        for(const auto& triangle:left) summed=pa::Sum(summed,triangle.areaVector);
        for(const auto& triangle:right) summed=pa::Sum(summed,triangle.areaVector);
        Check(summed==RV{},"paired port outward normals are not opposite");
        Check(pa::Area(left,pivot)>0,"edge/vertex-only contact became a hydraulic port");
        islands.Join(owners[0].first,owners[1].first);
        ++pairedPorts;
    }
    std::map<unsigned,Moments> componentMoments;
    for(unsigned c=0;c<candidate.cells.size();++c) pa::Add(componentMoments[islands.Root(c)],cellMoments[c]);
    std::vector<Moments> signatures;
    for(const auto& entry:componentMoments) signatures.push_back(entry.second);
    std::sort(signatures.begin(),signatures.end());
    Check(signatures==reference.components,"physical port DOF islands merge or split independent wet components");
    if(fixture==6) Check(signatures.size()==2,"slab negative control must contain two genuinely disconnected wet regions");
    std::printf("VOXEL_PORT_GEOMETRY fixture=%u cells=%zu components=%zu fine_reference_tets=%u paired_ports=%u\n",
                fixture,candidate.cells.size(),signatures.size(),reference.tetrahedra,pairedPorts);
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        OracleControls();
        using V=glm::dvec3;
        const unsigned chosen=argc>1?unsigned(std::strtoul(argv[1],nullptr,10)):99;
        for(unsigned fixture=0;fixture<9;++fixture) {
            if(chosen!=99 && chosen!=fixture) continue;
            const unsigned grid=fixture==5?2:1;
            std::vector<unsigned> selected(fixture==5?8:1);
            std::iota(selected.begin(),selected.end(),0);
            V center(.5),half(.2);
            auto rotation=glm::dquat(1,0,0,0);
            if(fixture==0) center=V(3);
            if(fixture==2) rotation=glm::angleAxis(.17,glm::normalize(V(1,2,-.3)));
            if(fixture==3) rotation=glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3)));
            if(fixture==4) {center=V(1.25,.5,.5);half=V(.25);}
            if(fixture==5) center=V(.95,.5,.5);
            if(fixture==6) half=V(.0625,2,2);
            if(fixture==7) half=V(2);
            if(fixture==8) half=V(.499999999,.2,.17);
            const auto box=owned_cut::BoxPlanes(center,half,rotation);
            auto begin=std::chrono::steady_clock::now();
            const auto reference=FineReference(grid,box,selected);
            const double referenceMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
            begin=std::chrono::steady_clock::now();
            voxel_ports::Compiler candidate;
            candidate.BuildSelected(grid,box,selected);
            const double candidateMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
            Verify(grid,box,selected,candidate,reference,fixture);
            if(fixture==1) {
                auto missing=candidate;
                Check(!missing.cells.empty() && !missing.cells[0].faces.empty(),
                      "missing-publication negative control lacks a real physical face");
                missing.cells[0].faces.pop_back();
                bool rejected=false;
                try { Verify(grid,box,selected,missing,reference,fixture); }
                catch(const std::runtime_error&) { rejected=true; }
                Check(rejected,"removing an actual published face must fail independent acceptance");
                std::printf("VOXEL_PORT_NEGATIVE missing_published_face=rejected\n");
            }
            std::printf("VOXEL_PORT_GEOMETRY_COST fixture=%u reference_ms=%g candidate_ms=%g\n",fixture,referenceMs,candidateMs);
        }
        std::printf("VOXEL_PORT_GEOMETRY_SUMMARY checks=%u failures=0 paired_ports=%u\n",checks,pairedPorts);
        return 0;
    } catch(const std::exception& e) {
        std::fprintf(stderr,"VOXEL_PORT_GEOMETRY_FAIL checks=%u %s\n",checks,e.what());
        return 1;
    }
}
