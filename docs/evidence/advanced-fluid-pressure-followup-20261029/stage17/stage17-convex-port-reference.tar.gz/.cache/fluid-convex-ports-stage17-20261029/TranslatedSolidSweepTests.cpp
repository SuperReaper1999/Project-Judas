#include "TranslatedSolidSweep.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace translated_sweep;
using V=glm::dvec3;
unsigned checks=0;
void Check(bool pass,const char* text){++checks;if(!pass)throw std::runtime_error(text);}
R FullBoxVolume(const Box& box){std::array<std::array<R,3>,3> normals;RV width;for(unsigned a=0;a<3;++a){for(unsigned b=0;b<3;++b)normals[a][b]=R(box[2*a+1].normal[b]);width[a]=R(box[2*a].coordinate)+R(box[2*a+1].coordinate);}return width[0]*width[1]*width[2]/abs(Det3(normals));}
RV ExactCenter(const Box& box){std::array<std::array<R,3>,3> normals;RV rhs,center;for(unsigned a=0;a<3;++a){for(unsigned b=0;b<3;++b)normals[a][b]=R(box[2*a+1].normal[b]);rhs[a]=(R(box[2*a+1].coordinate)-R(box[2*a].coordinate))/2;}const R det=Det3(normals);for(unsigned a=0;a<3;++a){auto numerator=normals;for(unsigned b=0;b<3;++b)numerator[b][a]=rhs[b];center[a]=Det3(numerator)/det;}return center;}
Result Run(unsigned grid,const V& center,const V& half,double angle,const RV& movement,const char* name){
 const auto box=owned_cut::BoxPlanes(center,half,glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));const Path path(grid,box,movement,R(1)/240);const auto result=path.Run();
 R oldVolume=0,newVolume=0,swept=0,absolute=0;RV before{},after{},moment{};
 for(const auto& cell:result.cells){Check(cell.sweptVolume==cell.newState.volume-cell.oldState.volume,"actual integrated native wall flux violates voxel geometric conservation");Check(cell.oldState.volume>=0&&cell.newState.volume>=0,"swept solid has negative endpoint volume");R sum=0;for(const auto& x:cell.nativeFaceVolumes)sum+=x;Check(sum==cell.sweptVolume,"actual six native faces do not compose swept-volume balance");oldVolume+=cell.oldState.volume;newVolume+=cell.newState.volume;swept+=cell.sweptVolume;absolute+=abs(cell.sweptVolume);for(unsigned a=0;a<3;++a){Check(cell.sweptFirst[a]==cell.newState.first[a]-cell.oldState.first[a],"actual integrated pressure-potential work violates first-moment GCL");before[a]+=cell.oldState.first[a];after[a]+=cell.newState.first[a];moment[a]+=cell.sweptFirst[a];}}
 const R volume=FullBoxVolume(box);const auto exactCenter=ExactCenter(box);
 Check(oldVolume==volume&&newVolume==volume,"test box must remain entirely inside the same physical tank");Check(swept==0,"rigid translation changes global physical capacity");for(unsigned a=0;a<3;++a){Check(before[a]==volume*exactCenter[a],"independent native-box first moment at beginning");Check(after[a]==volume*(exactCenter[a]+movement[a]),"independent native-box first moment at end");Check(moment[a]==volume*movement[a],"native swept geometry misses actual body displacement moment");}
 const RV gravity={R(5)/4,R(-981)/100,R(3)/8};
 Check(-1000*Dot(gravity,moment)==1000*Dot(gravity,Difference(before,after)),"arbitrary-gravity hydrostatic work is not physically equivalent to exact fluid-capacity potential change");
 printf("TRANSLATED_SWEEP name=%s n=%u angle=%.17g intervals=%u samples=%u solid_volume=%Lg total_swept=%Lg absolute_voxel_exchange=%Lg moment=%Lg,%Lg,%Lg time_ms=%g\n",name,grid,angle,result.intervals,result.samples,volume.convert_to<long double>(),swept.convert_to<long double>(),absolute.convert_to<long double>(),moment[0].convert_to<long double>(),moment[1].convert_to<long double>(),moment[2].convert_to<long double>(),result.milliseconds);
 return result;
}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
 Run(1,V(.5),V(.15),0,{R(1)/10,R(0),R(0)},"axis_inside");
 Run(2,V(.8,.7,.8),V(.2),0,{R(2)/5,R(1)/4,R(1)/8},"axis_grid_crossing");
 Run(2,V(.8,.7,.8),V(.2),.37,{R(2)/5,R(1)/4,R(1)/8},"oblique_grid_crossing");
 Run(2,V(.75),V(.25),3.2137858346770188e-11,{R(1)/10,R(-1)/8,R(1)/7},"tiny_true_corner");
 const auto forward=Run(2,V(.8,.7,.8),V(.2),.17,{R(2)/5,R(1)/4,R(1)/8},"return_forward");
 const auto box=owned_cut::BoxPlanes(V(.8,.7,.8),V(.2),glm::angleAxis(.17,glm::normalize(V(1,2,-.3))));
 const auto backPath=Path(2,box,{R(2)/5,R(1)/4,R(1)/8}).Reversed();const auto back=backPath.Run();
 R exchange=0;for(unsigned i=0;i<forward.cells.size();++i){const auto& a=forward.cells[i];const auto& b=back.cells[i];exchange+=abs(a.sweptVolume);Check(a.newState.volume==b.oldState.volume&&a.oldState.volume==b.newState.volume,"exact reverse path has different endpoint geometry");Check(a.sweptVolume+b.sweptVolume==0,"actual reverse swept wall volume does not cancel");for(unsigned axis=0;axis<3;++axis)Check(a.sweptFirst[axis]+b.sweptFirst[axis]==0,"actual reverse swept wall moment does not cancel");}
 Check(exchange>0,"out-and-back control must actually cross voxel ownership");
 const Path unsplit(2,box,{R(2)/5,R(1)/4,R(1)/8});bool missedTopology=false;
 for(unsigned voxel=0;voxel<8;++voxel){R oneInterval=0;const std::array<R,3> nodes={R(1)/6,R(1)/2,R(5)/6},weights={R(3)/8,R(1)/4,R(3)/8};for(unsigned sample=0;sample<3;++sample)for(const auto& face:unsplit.Body(voxel,nodes[sample]).faces)if(face.plane<6)for(const auto& t:exact_convex::Triangulate(face))oneInterval+=weights[sample]*Dot(unsplit.displacement,t.areaVector);missedTopology|=oneInterval!=forward.cells[voxel].sweptVolume;}
 Check(missedTopology,"negative control ignoring actual topology events must detect missed swept volume");
 Run(1,V(.5),V(.2),.17,{R(0),R(0),R(0)},"no_motion");
 bool rejected=false;try{Path invalid(2,box,{R(0),R(0),R(0)},R(0));}catch(const std::invalid_argument&){rejected=true;}Check(rejected,"zero-duration wall motion must not be accepted");
 auto bad=box;bad[0].coordinate=std::numeric_limits<double>::quiet_NaN();rejected=false;try{Path invalid(2,bad,{R(0),R(0),R(0)});}catch(const std::invalid_argument&){rejected=true;}Check(rejected,"nonfinite native geometry must not reach sweep publication");
 printf("TRANSLATED_SWEEP_SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;}}
