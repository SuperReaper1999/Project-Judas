#pragma once

// Isolated Stage17 representation prototype. Physical world-vector P1
// coefficients in bounded spatial coordinates are PRIMARY, along with a
// normalized moment-kernel coordinate. No raw contravariant DOF round trip is
// used to recover an already known physical polynomial.
#include "FramedCell.h"
#include <Eigen/SVD>

namespace stage17_resolved {
namespace fr=stage17_framed;
namespace vm=JudasFluidVem;
using Real=fr::Real;using R=fr::R;using RV=fr::RV;
using Vec=fr::Vec;using Mat=fr::Mat;using Matrix=fr::Matrix;using Vector=fr::Vector;using Affine=fr::Affine;

struct State {
    Affine polynomial=Affine::Zero(); // physical world-vector components over [1,xi]
    Vector kernel; // normalized complementary kinetic coordinates
};

inline R ProductAverage(const std::array<R,3>& a,const std::array<R,3>& b) {
    R sumA=0,sumB=0,diagonal=0;
    for(unsigned v=0;v<3;++v){sumA+=a[v];sumB+=b[v];diagonal+=a[v]*b[v];}
    return (sumA*sumB+diagonal)/12;
}

inline std::array<R,3> ExactFactors(const stage16_factored::CanonicalFrame& face,const RV& point) {
    const RV delta=convex_ports::Sub(point,face.origin);
    return {R(1),(owned_metrics::Dot(face.edge,delta)-face.midU)/face.spanU,
                 (owned_metrics::Dot(face.transverse,delta)-face.midV)/face.spanV};
}

struct Cell {
    fr::Cell framed;
    Matrix polynomialFactor,facePolynomial;
    Matrix faceRoot,inverseFaceRoot,constraints,scaledConstraints,nullBasis,kernelFace;
    Matrix kernelPolynomialLeak;
    Real nullResidual=0,kernelMassError=0,constraintSingularRatio=0;
    unsigned faceDimension=0,kernelDimension=0;

    explicit Cell(const convex_ports::Cell& input,const R& scale=R(1)):framed(input,scale) {
        faceDimension=3*input.faces.size();
        if(faceDimension<6)throw std::runtime_error("resolved cell lacks six independent symmetric moment constraints");
        facePolynomial=Matrix::Zero(faceDimension,12);
        for(unsigned f=0;f<input.faces.size();++f) {
            std::array<std::array<R,12>,3> exact{};
            for(const auto& triangle:input.faces[f].triangles) {
                std::array<RV,3> physical,xi;
                std::array<std::array<R,3>,3> psi;
                for(unsigned v=0;v<3;++v) {
                    physical[v]=fr::Mul(triangle.points[v],scale);
                    xi[v]=framed.frame.Coordinates(physical[v]);
                    const auto p=ExactFactors(framed.faces[f],physical[v]);
                    for(unsigned i=0;i<3;++i)psi[i][v]=p[i];
                }
                const RV area=fr::Mul(triangle.areaVector,scale*scale);
                for(unsigned basis=0;basis<4;++basis) {
                    std::array<R,3> coordinate{R(1),R(1),R(1)};
                    if(basis)for(unsigned v=0;v<3;++v)coordinate[v]=xi[v][basis-1];
                    for(unsigned i=0;i<3;++i) {
                        const R average=ProductAverage(psi[i],coordinate);
                        for(unsigned a=0;a<3;++a)exact[i][4*a+basis]+=area[a]*average;
                    }
                }
            }
            for(unsigned i=0;i<3;++i)for(unsigned j=0;j<12;++j)
                facePolynomial(3*f+i,j)=exact[i][j].convert_to<Real>();
        }
        // On ker(L), all volume P1 moments vanish: mean AND angular moments
        // are exactly zero. Thus only the FACE block of the original S can
        // contribute. Omitting its identically zero interior rows is an exact
        // algebraic identity, not a stabilization adjustment or energy repair.
        faceRoot=framed.stabilizationFactor.topLeftCorner(faceDimension,faceDimension);
        inverseFaceRoot=Matrix::Zero(faceDimension,faceDimension);
        for(unsigned f=0;f<input.faces.size();++f) {
            const Mat block=faceRoot.block(3*f,3*f,3,3);
            inverseFaceRoot.block(3*f,3*f,3,3)=block.template triangularView<Eigen::Upper>().solve(Mat::Identity());
        }
        constraints.resize(6,faceDimension);
        unsigned row=0;
        for(unsigned a=0;a<3;++a)for(unsigned b=a;b<3;++b)
            constraints.row(row++)=framed.reference.momentOperator.row(4*a+b+1).head(faceDimension);
        scaledConstraints=constraints*inverseFaceRoot;
        for(unsigned r=0;r<6;++r) {
            const Real norm=scaledConstraints.row(r).norm();
            if(!(norm>0))throw std::runtime_error("resolved symmetric moment constraint has zero rank");
            scaledConstraints.row(r)/=norm;
        }
        Eigen::JacobiSVD<Matrix> factor(scaledConstraints,Eigen::ComputeFullV);
        if(factor.info()!=Eigen::Success || factor.singularValues().size()!=6 || !(factor.singularValues()(5)>0))
            throw std::runtime_error("resolved symmetric moment null space lost its six known constraints");
        // Geometry fixes the rank at six. No epsilon rank deletion removes a
        // weak moment, tiny face or physical degree of freedom.
        constraintSingularRatio=factor.singularValues()(5)/factor.singularValues()(0);
        kernelDimension=faceDimension-6;
        nullBasis=factor.matrixV().rightCols(kernelDimension);
        kernelFace=inverseFaceRoot*nullBasis;
        nullResidual=(scaledConstraints*nullBasis).cwiseAbs().maxCoeff();
        const Matrix weighted=faceRoot*kernelFace;
        kernelMassError=(weighted.transpose()*weighted-Matrix::Identity(kernelDimension,kernelDimension)).cwiseAbs().maxCoeff();
        // Independent numerical-quality diagnostic: a nominal kernel mode must
        // not carry physical polynomial kinetic energy merely because a small
        // reference constraint was lost in the null-space calculation.
        kernelPolynomialLeak=framed.consistentPolynomialFactor*framed.reference.projection.leftCols(faceDimension)*kernelFace;
        Eigen::Matrix<Real,4,4> normalizedGram;
        for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)
            normalizedGram(i,j)=framed.referenceGeometry.volume[vm::ProductIndex(i,j)]/framed.physicalVolume;
        Eigen::LLT<Eigen::Matrix<Real,4,4>> scalarFactor(normalizedGram);
        if(scalarFactor.info()!=Eigen::Success)throw std::runtime_error("resolved physical polynomial metric is not positive");
        polynomialFactor=Matrix::Zero(12,12);
        for(unsigned a=0;a<3;++a)
            polynomialFactor.block(4*a,4*a,4,4)=std::sqrt(framed.density*framed.physicalVolume)
                *Eigen::Matrix<Real,4,4>(scalarFactor.matrixL()).transpose();
    }

    State PhysicalAffine(const Vec& valueAtFrameOrigin,const Mat& worldGradient) const {
        State state;state.kernel=Vector::Zero(kernelDimension);
        const Mat referenceGradient=worldGradient*framed.frame.J;
        for(unsigned a=0;a<3;++a){state.polynomial(4*a)=valueAtFrameOrigin(a);for(unsigned b=0;b<3;++b)state.polynomial(4*a+b+1)=referenceGradient(a,b);}
        return state;
    }
    Vec EvaluateProjectedPhysical(const State& state,const RV& exactWorldPoint) const {
        return vm::EvaluateAffine(state.polynomial,framed.frame.CoordinatesReal(exactWorldPoint));
    }
    Vector FaceFlux(const State& state) const {
        if(state.kernel.size()!=kernelDimension)throw std::invalid_argument("resolved kernel coordinate dimension mismatch");
        return facePolynomial*state.polynomial+kernelFace*state.kernel;
    }
    Real PhysicalNormal(unsigned face,const State& state,const RV& exactWorldPoint) const {
        const auto q=FaceFlux(state);
        const auto p=framed.faces.at(face).Factors(exactWorldPoint);
        const Vec coefficients=framed.physicalFaceGramInverse.at(face)*q.template segment<3>(3*face);
        return Vec(p[0],p[1],p[2]).dot(coefficients);
    }
    Vector Coordinates(const State& state) const {
        Vector result(12+kernelDimension);result.head(12)=polynomialFactor*state.polynomial;result.tail(kernelDimension)=state.kernel;return result;
    }
    Real Energy(const State& state) const{return Coordinates(state).squaredNorm()/2;}
    Real Inner(const State& a,const State& b) const{return Coordinates(a).dot(Coordinates(b));}
    Real SourceWork(const State& candidate,const Vector& predictorCoordinates) const{return Coordinates(candidate).dot(predictorCoordinates);}
    Vector PredictorCoordinates(const State& predictor) const{return Coordinates(predictor);}
    fr::Moments PhysicalMoments(const State& state) const {
        fr::Moments result;Mat firstXi;
        for(unsigned a=0;a<3;++a) {
            Real mean=0;
            for(unsigned j=0;j<4;++j)mean+=framed.referenceGeometry.volume[j]*state.polynomial(4*a+j);
            result.mean(a)=mean;
            for(unsigned b=0;b<3;++b){Real moment=0;for(unsigned j=0;j<4;++j)moment+=framed.referenceGeometry.volume[vm::ProductIndex(b+1,j)]*state.polynomial(4*a+j);firstXi(a,b)=moment;}
        }
        result.first=firstXi*framed.frame.J.transpose()+result.mean*fr::Rounded(framed.frame.offset).transpose();
        return result;
    }
    // Ordinary-geometry equivalence/debug conversion only. It cannot recover
    // information that was already lost by rounding a near-null raw DOF state.
    State DebugFromReferenceDOFs(const Vector& raw) const {
        const auto p=framed.reference.Project(raw);State state;
        for(unsigned j=0;j<4;++j){Vec value;for(unsigned a=0;a<3;++a)value(a)=p(4*a+j);value=framed.frame.J*value;for(unsigned a=0;a<3;++a)state.polynomial(4*a+j)=value(a);}
        const Vector residual=raw.head(faceDimension)-facePolynomial*state.polynomial;
        state.kernel=nullBasis.transpose()*faceRoot*residual;
        return state;
    }
};
} // namespace stage17_resolved
