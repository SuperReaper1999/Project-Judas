#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <sys/resource.h>
using namespace stage17_network;
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
 for(unsigned n:{1,2,3,4}){const auto b=owned_cut::BoxPlanes(V(.5*n),V(.2*n),glm::angleAxis(.17,glm::normalize(V(1,2,-.3))));auto t=Clock::now();Epoch e(n,b,vg::R(1)/n,Boundary::OpenTop);const double build=Milliseconds(t);Twist twist;twist<<.01,-.02,.03,.02,.03,-.01;const auto a=e.Solve(e.Constant(vm::Vec3::Zero()),twist);Real poly=0,volume=0;for(unsigned c=0;c<e.cells.size();++c){const auto& op=e.cells[c]->op;auto p=op.Project(a.local[c]);poly+=op.geometry.density*p.dot(op.polynomialGram*p)/2;volume+=op.geometry.volume[0];}if(std::abs(volume-.936L)>1e-13L)throw std::runtime_error("resolution changes physical wet volume");const auto hydro=e.Solve(e.Constant(vm::Vec3(0,-.04,0)));if((hydro.reaction.head<3>()-vm::Vec3(0,2.56,0)).norm()>1e-10L)throw std::runtime_error("resolution changes actual hydrostatic wrench");printf("CONVEX_RESOLUTION grid=%u h=%g extent=1 build_ms=%g geom_ms=%g local_ms=%g factor_ms=%g variables=%ld cells=%zu energy=%Lg affine=%Lg complement=%Lg volume=%Lg balance=%Lg solve_ms=%g\n",n,1./n,build,e.geometryMs,e.localMs,e.factorMs,long(e.mass.rows()),e.cells.size(),a.energy,poly,a.energy-poly,volume,a.balance,a.solveMs);}
 rusage u{};getrusage(RUSAGE_SELF,&u);printf("RESOLUTION_COMPLETE peak_rss_kib=%ld\n",u.ru_maxrss);return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL %s\n",error.what());return 1;}}
