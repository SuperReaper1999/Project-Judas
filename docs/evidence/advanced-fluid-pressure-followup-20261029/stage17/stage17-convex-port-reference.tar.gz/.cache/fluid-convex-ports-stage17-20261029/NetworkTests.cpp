#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using namespace stage17_network;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;
    if(!condition) throw std::runtime_error(message);
}
std::vector<vm::Affine> Disturbance(const Epoch& epoch) {
    auto result=epoch.Constant(vm::Vec3(.03L,-.04L,.02L));
    for(unsigned cell=0;cell<epoch.cells.size();++cell) {
        const auto& physical=epoch.cells[cell]->cell;
        const Real phase=Real(1+physical.seed+3*physical.piece);
        result[cell][0]+=.001L*phase;
        result[cell][3]=.015L;
        result[cell][6]=-.01L;
        result[cell][9]=.012L;
    }
    return result;
}
void Case(unsigned fixture) {
    using V=glm::dvec3;
    const auto rotation=fixture==1?glm::angleAxis(.17,glm::normalize(V(1,2,-.3))):glm::dquat(1,0,0,0);
    const auto box=owned_cut::BoxPlanes(V(.5),V(.2),rotation);
    const auto start=Clock::now();
    Epoch epoch(1,box);
    const double built=Milliseconds(start);
    const auto zero=epoch.Solve(epoch.Constant(vm::Vec3::Zero()));
    Check(zero.energy==0&&zero.reaction.norm()==0&&zero.flux.norm()==0,
          "zero source retains convex-cell motion");
    const vm::Vec3 gravity=fixture==2?vm::Vec3(.02L,-.035L,.01L):vm::Vec3(0,-.04L,0);
    const auto hydro=epoch.Solve(epoch.Constant(gravity));
    const vm::Vec3 expected=-64*gravity;
    const vm::Vec3 center(.5L,.5L,.5L);
    const Real force=(hydro.reaction.head<3>()-expected).norm();
    const Real torque=(hydro.reaction.tail<3>()-center.cross(expected)).norm();
    Check(hydro.energy<1e-18L,"calm hydrostatics generate velocity");
    Check(force<1e-10L&&torque<1e-10L,"convex-port buoyancy wrench is incorrect");
    Check(hydro.balance<1e-12L&&hydro.stationarity<1e-12L,
          "hydrostatic pressure violates continuity or stationarity");
    Twist twist;
    twist<<.01L,-.02L,.03L,.02L,.03L,-.01L;
    const auto moving=epoch.Solve(epoch.Constant(gravity),twist);
    Check(moving.balance<1e-12L&&moving.stationarity<1e-12L,
          "moving solid violates convex-cell continuity");
    Check(moving.energyIdentity<1e-12L,"moving-solid kinetic work identity fails");
    for(unsigned owner=0;owner<epoch.cells.size();++owner) {
        const auto& local=*epoch.cells[owner];
        const Vector imposed=epoch.maps[owner].body*twist;
        for(unsigned face=0;face<local.cell.faces.size();++face)
            if(local.cell.faces[face].kind==Kind::Solid)
                Check((moving.local[owner].segment(3*face,3)-imposed.segment(3*face,3)).norm()<1e-16L,
                      "actual primary solid port does not match rigid motion");
    }
    for(const auto& [key,port]:epoch.interfaces) {
        if(port.secondCell==~0u) continue;
        const auto sum=moving.local[port.firstCell].segment(3*port.firstFace,3)+
                       moving.local[port.secondCell].segment(3*port.secondFace,3);
        Check(sum.norm()<1e-16L,"opposite physical ports exchange unequal primary flux");
    }
    const auto disturbed=epoch.Solve(Disturbance(epoch));
    Check(disturbed.energy<=disturbed.predictorEnergy*(1+1e-12L),
          "fixed boundaries create kinetic energy");
    Check(disturbed.balance<1e-12L&&disturbed.energyIdentity<1e-12L,
          "disturbed convex projection violates physical identities");
    std::vector<Vector> arbitrary;
    for(unsigned owner=0;owner<epoch.cells.size();++owner) {
        Vector raw(epoch.cells[owner]->op.dimension);
        for(unsigned degree=0;degree<unsigned(raw.size());++degree)
            raw[degree]=.001L*std::sin(Real(1+degree+11*owner));
        arbitrary.push_back(std::move(raw));
    }
    const auto rawProjection=epoch.SolveRaw(arbitrary);
    Check(rawProjection.energy<=rawProjection.predictorEnergy*(1+1e-12L),
          "raw non-polynomial kinetic projection creates energy");
    Check(rawProjection.balance<1e-12L&&rawProjection.energyIdentity<1e-12L,
          "raw non-polynomial kinetic projection violates work or continuity");
    auto bad=epoch.Constant(vm::Vec3::Zero());
    bad[0][0]=NAN;
    bool rejected=false;
    try { epoch.Solve(bad); } catch(const std::invalid_argument&) { rejected=true; }
    Check(rejected&&epoch.Solve(epoch.Constant(vm::Vec3::Zero())).energy==0,
          "invalid source mutates a prepared pressure network");
    printf("NETWORK fixture=%u cells=%zu ports=%zu variables=%ld build_ms=%g geometry_ms=%g local_ms=%g assembly_ms=%g factor_ms=%g warm_ms=%g force_error=%Lg torque_error=%Lg balance=%Lg work=%Lg\n",
           fixture,epoch.cells.size(),epoch.interfaces.size(),long(epoch.mass.rows()),built,
           epoch.geometryMs,epoch.localMs,epoch.assemblyMs,epoch.factorMs,moving.solveMs,
           force,torque,moving.balance,moving.energyIdentity);
}

int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(unsigned fixture=0;fixture<3;++fixture) Case(fixture);
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(.17,glm::normalize(V(1,2,-.3))));
        convex_ports::Compiler geometry;
        geometry.Build(1,box);
        Epoch ordered(geometry);
        std::reverse(geometry.cells.begin(),geometry.cells.end());
        for(auto& cell:geometry.cells) std::reverse(cell.faces.begin(),cell.faces.end());
        Epoch reversed(geometry);
        Twist body;
        body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto a=ordered.Solve(Disturbance(ordered),body);
        const auto b=reversed.Solve(Disturbance(reversed),body);
        Check(std::abs(a.energy-b.energy)<1e-12L,
              "convex-cell/port ordering changes physical kinetic energy");
        Check((a.reaction-b.reaction).norm()<1e-12L,
              "convex-cell/port ordering changes solid wrench");
        bool removed=false;
        for(auto& cell:geometry.cells) {
            auto at=std::find_if(cell.faces.begin(),cell.faces.end(),[](const auto& face) {
                return face.kind==Kind::Internal;
            });
            if(at!=cell.faces.end()) { cell.faces.erase(at);removed=true;break; }
        }
        Check(removed,"missing-port negative control was not constructed");
        bool rejected=false;
        try { Epoch bad(geometry); }
        catch(const std::runtime_error&) { rejected=true; }
        Check(rejected,"missing physical interface port was silently accepted");
        const auto slab=owned_cut::BoxPlanes(V(.5),V(.1,2,2),glm::dquat(1,0,0,0));
        Epoch divided(1,slab);
        Check(divided.components.size()==2,"solid slab did not preserve two hydraulic components");
        Check(divided.Solve(divided.Constant(vm::Vec3::Zero())).energy==0,
              "disconnected zero source creates flow");
        Twist incompatible=Twist::Zero();incompatible[0]=.1L;
        rejected=false;
        try { divided.Solve(divided.Constant(vm::Vec3::Zero()),incompatible); }
        catch(const std::invalid_argument&) { rejected=true; }
        Check(rejected,"opposite sealed-component volume changes canceled illegally");
        Check(divided.Solve(divided.Constant(vm::Vec3::Zero())).energy==0,
              "incompatible component-flow rejection poisons later solve");
        Epoch open(1,box,vg::R(1),Boundary::OpenTop);
        const auto free=open.Solve(open.Constant(vm::Vec3::Zero()),body);
        Check(free.balance<1e-12L&&free.stationarity<1e-12L,
              "pressure-free open top violates fluid equations");
        printf("NETWORK_SUMMARY checks=%u failures=0\n",checks);
        return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());
        return 1;
    }
}
