#include "VoxelPorts.h"
#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

// Diagnostic, not an acceptance test. Rejections and endpoint failures are
// printed verbatim; no tiny cell is removed, merged, repaired or retuned here.
namespace net=stage17_network;
void Probe(const char* label,unsigned n,const voxel_ports::Box& box){
    voxel_ports::Compiler geometry;geometry.Build(n,box);net::Real minimum=INFINITY,total=0;
    for(const auto& cell:geometry.cells){minimum=std::min(minimum,cell.volume.convert_to<net::Real>());total+=cell.volume.convert_to<net::Real>();}
    printf("VOXEL_BOUNDARY label=%s cells=%zu min_volume=%Lg wet_volume=%Lg ",label,geometry.cells.size(),minimum,total);
    try{net::Network world(geometry);const auto hydro=world.Solve(world.Constant(net::vm::Vec3(0,-.04L,0)));net::Real div=0,calm=0;
        for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];div=std::max(div,(local.op.divergenceMoments*hydro.local[c]).cwiseAbs().maxCoeff()/local.cell.geometry.volume[0]);calm=std::max(calm,std::sqrt(2*local.op.Energy(hydro.local[c])/(1000*local.cell.geometry.volume[0])));}
        printf("network=accepted actual_normalized_div=%Lg calm_local_rms=%Lg\n",div,calm);
    }catch(const std::exception& e){printf("network=rejected reason=%s\n",e.what());}
}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
    const auto original=owned_cut::BoxPlanes(V(.5),V(.2),glm::dquat(1,0,0,0));
    for(const auto permutation:{std::array<unsigned,3>{0,1,2},{1,2,0},{2,0,1}}){voxel_ports::Box box;for(unsigned a=0;a<3;++a)for(unsigned side=0;side<2;++side)box[2*a+side]=original[2*permutation[a]+side];voxel_ports::Compiler geometry;geometry.Build(1,box);net::Network world(geometry);net::Matrix added=net::Matrix::Zero(3,3);for(unsigned axis=0;axis<3;++axis){net::Twist motion=net::Twist::Zero();motion(axis)=.01L;const auto out=world.Solve(world.Constant(net::vm::Vec3::Zero()),motion);added.col(axis)=-out.reaction.head<3>()/.01L;}printf("VOXEL_PERMUTATION order=%u%u%u geometry_exactly_same=1 added_diagonal=%Lg,%Lg,%Lg off_diagonal_norm=%Lg\n",permutation[0],permutation[1],permutation[2],added(0,0),added(1,1),added(2,2),(added-added.diagonal().asDiagonal().toDenseMatrix()).norm());}
    Probe("coincident_lower_x",2,owned_cut::BoxPlanes(V(1.25,.5,.5),V(.25),glm::dquat(1,0,0,0)));
    Probe("coincident_upper_x",2,owned_cut::BoxPlanes(V(.75,.5,.5),V(.25),glm::dquat(1,0,0,0)));
    for(int exponent:{-12,-30,-40}){const double delta=std::ldexp(1.,exponent);char label[100];snprintf(label,sizeof(label),"grid_plane_positive_delta_2pow%d",exponent);Probe(label,2,owned_cut::BoxPlanes(V(1.25+delta,.5,.5),V(.25),glm::dquat(1,0,0,0)));snprintf(label,sizeof(label),"grid_plane_negative_delta_2pow%d",exponent);Probe(label,2,owned_cut::BoxPlanes(V(1.25-delta,.5,.5),V(.25),glm::dquat(1,0,0,0)));}
    Probe("true_outer_wall_gap_2pow-40",1,owned_cut::BoxPlanes(V(.2+std::ldexp(1.,-40),.5,.5),V(.2),glm::dquat(1,0,0,0)));
    return 0;
}catch(const std::exception& e){fprintf(stderr,"VOXEL_AUDIT_ERROR %s\n",e.what());return 1;}}
