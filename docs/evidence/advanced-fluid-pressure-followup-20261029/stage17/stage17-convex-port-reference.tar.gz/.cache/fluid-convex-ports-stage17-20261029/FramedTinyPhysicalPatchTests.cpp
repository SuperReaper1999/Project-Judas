// Independent exact physical DOFs are transformed into reference coordinates
// BEFORE conversion. Never feed InterpolatePhysicalAffine into its own oracle.
// Original TinyNetworkTests/Stage17TinyPhysicalPatchTests remain unchanged.
#include "FramedCell.h"
#include "acceptance/ExactPatchOracle.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <cstdlib>

namespace ff=stage17_framed;
namespace pa=port_acceptance;
namespace vm=JudasFluidVem;
using pa::R;
using pa::RV;
using Real=vm::Real;
using Coefficients=std::array<R,12>;

RV Field(const Coefficients& coefficients,const RV& local) {
    RV value{};
    for(unsigned a=0;a<3;++a) {
        value[a]=coefficients[4*a];
        for(unsigned b=0;b<3;++b) value[a]+=coefficients[4*a+b+1]*local[b];
    }
    return value;
}
Real Magnitude(const RV& vector) {
    Real square=0;
    for(const auto& value:vector) {const Real x=value.convert_to<Real>();square+=x*x;}
    return std::sqrt(square);
}

struct Oracle {
    pa::Moments volume{};
    std::vector<RV> vertices;
    explicit Oracle(const convex_ports::Cell& input) {
        std::set<RV> unique;
        for(const auto& tet:input.integration) {
            std::array<RV,4> local;
            for(unsigned i=0;i<4;++i) {local[i]=pa::Sub(tet.points[i],input.center);unique.insert(tet.points[i]);}
            pa::Add(volume,pa::TetraP2(local));
        }
        vertices.assign(unique.begin(),unique.end());
    }
    R Moment(unsigned a,unsigned b) const {return volume[vm::ProductIndex(a,b)];}
    std::array<R,12> Moments(const Coefficients& field) const {
        std::array<R,12> result{};
        for(unsigned a=0;a<3;++a)
            for(unsigned moment=0;moment<4;++moment)
                for(unsigned coefficient=0;coefficient<4;++coefficient)
                    result[4*a+moment]+=field[4*a+coefficient]*Moment(moment,coefficient);
        return result;
    }
    R Kinetic(const Coefficients& a,const Coefficients& b) const {
        R result=0;
        for(unsigned component=0;component<3;++component)
            for(unsigned i=0;i<4;++i)
                for(unsigned j=0;j<4;++j)
                    result+=1000*a[4*component+i]*b[4*component+j]*Moment(i,j);
        return result;
    }
};

std::array<R,3> Factors(const stage16_factored::CanonicalFrame& frame,const RV& global) {
    const RV d=pa::Sub(global,frame.origin);
    return {R(1),(owned_metrics::Dot(frame.edge,d)-frame.midU)/frame.spanU,
                (owned_metrics::Dot(frame.transverse,d)-frame.midV)/frame.spanV};
}

std::vector<R> ExactPhysicalDofs(const convex_ports::Cell& input,const ff::Cell& framed,
                                 const Oracle& oracle,const Coefficients& field) {
    const unsigned mean=3*input.faces.size();
    std::vector<R> dofs(mean+6,R(0));
    for(unsigned face=0;face<input.faces.size();++face)
        for(const auto& triangle:input.faces[face].triangles) {
            std::array<std::array<R,3>,3> psi{};
            std::array<RV,3> velocity;
            for(unsigned corner=0;corner<3;++corner) {
                const auto test=Factors(framed.faces[face],triangle.points[corner]);
                for(unsigned row=0;row<3;++row) psi[row][corner]=test[row];
                velocity[corner]=Field(field,pa::Sub(triangle.points[corner],input.center));
            }
            for(unsigned row=0;row<3;++row) {
                const R testSum=psi[row][0]+psi[row][1]+psi[row][2];
                for(unsigned component=0;component<3;++component) {
                    R sum=0,diagonal=0;
                    for(unsigned corner=0;corner<3;++corner) {
                        sum+=velocity[corner][component];
                        diagonal+=psi[row][corner]*velocity[corner][component];
                    }
                    dofs[3*face+row]+=triangle.areaVector[component]*(testSum*sum+diagonal)/12;
                }
            }
        }
    const auto moments=oracle.Moments(field);
    RV angular{};
    for(unsigned component=0;component<3;++component) {
        dofs[mean+component]=moments[4*component];
        RV unit{};unit[component]=1;
        angular=pa::Sum(angular,owned_metrics::Cross(
            RV{moments[4*component+1],moments[4*component+2],moments[4*component+3]},unit));
    }
    for(unsigned i=0;i<3;++i) dofs[mean+3+i]=angular[i];
    return dofs;
}

vm::Vector ExactReferenceDofs(const std::vector<R>& physical,const ff::Frame& frame,unsigned mean) {
    std::vector<R> transformed=physical;
    const RV momentum{physical[mean],physical[mean+1],physical[mean+2]};
    const RV angular{physical[mean+3],physical[mean+4],physical[mean+5]};
    const RV shifted=pa::Sub(angular,owned_metrics::Cross(frame.offset,momentum));
    for(unsigned i=0;i<3;++i) {
        transformed[mean+i]=owned_metrics::Dot(frame.inverseRows[i],momentum);
        transformed[mean+3+i]=owned_metrics::Dot(frame.columns[i],shifted)/frame.determinant;
    }
    vm::Vector result(transformed.size());
    // These are the first conversions anywhere in the physical->reference
    // transform. Face fluxes retain precisely their physical integrated units.
    for(unsigned i=0;i<transformed.size();++i) result[i]=transformed[i].convert_to<Real>();
    return result;
}

struct Stats {
    Real velocity=0,normal=0,energy=0,crossWork=0,moments=0,energyAbs=0;
    unsigned checks=0,failures=0;
    void Observe(Real error,Real& maximum,bool gate=true) {
        maximum=std::max(maximum,std::abs(error));++checks;
        if(gate && (!std::isfinite(error)||std::abs(error)>1e-8L)) ++failures;
    }
    void Merge(const Stats& b) {
        velocity=std::max(velocity,b.velocity);normal=std::max(normal,b.normal);
        energy=std::max(energy,b.energy);crossWork=std::max(crossWork,b.crossWork);
        moments=std::max(moments,b.moments);energyAbs=std::max(energyAbs,b.energyAbs);
        checks+=b.checks;failures+=b.failures;
    }
};

std::vector<Coefficients> PhysicalFields() {
    std::vector<Coefficients> fields(15);
    for(unsigned i=0;i<12;++i) fields[i][i]=1;
    fields[12][7]=-1;fields[12][10]=1;
    fields[13][3]=1;fields[13][9]=-1;
    fields[14][2]=-1;fields[14][5]=1;
    return fields;
}

Stats CheckCell(const convex_ports::Cell& input,const ff::Cell& framed,
                const std::vector<Coefficients>& fields) {
    Stats stats;
    const Oracle oracle(input);
    std::vector<vm::Vector> dofs;
    std::vector<Real> exactNorm;
    Real radius=0;
    for(const auto& point:oracle.vertices) radius=std::max(radius,Magnitude(pa::Sub(point,input.center)));
    for(const auto& field:fields) {
        const auto physical=ExactPhysicalDofs(input,framed,oracle,field);
        dofs.push_back(ExactReferenceDofs(physical,framed.frame,3*input.faces.size()));
        const auto& d=dofs.back();
        Real amplitude=0;
        for(const auto& point:oracle.vertices) {
            const RV expected=Field(field,pa::Sub(point,input.center));
            const auto actual=framed.EvaluateProjectedPhysical(d,point);
            const RV difference{R(actual.x())-expected[0],R(actual.y())-expected[1],R(actual.z())-expected[2]};
            stats.Observe(Magnitude(difference),stats.velocity);
            amplitude=std::max(amplitude,Magnitude(expected));
        }
        for(unsigned face=0;face<input.faces.size();++face)
            for(const auto& triangle:input.faces[face].triangles) {
                const Real area=std::sqrt(owned_metrics::Dot(triangle.areaVector,triangle.areaVector).convert_to<Real>());
                for(const auto& point:triangle.points) {
                    const RV expected=Field(field,pa::Sub(point,input.center));
                    const Real expectedNormal=owned_metrics::Dot(triangle.areaVector,expected).convert_to<Real>()/area;
                    stats.Observe(framed.PhysicalNormal(face,d,point)-expectedNormal,stats.normal);
                }
            }
        const Real kinetic=oracle.Kinetic(field,field).convert_to<Real>();
        exactNorm.push_back(kinetic);
        const Real actualEnergy=framed.Energy(d);
        stats.Observe(actualEnergy-kinetic/2,stats.energyAbs,false);
        stats.Observe((actualEnergy-kinetic/2)/(kinetic/2),stats.energy);
        const auto expectedMoments=oracle.Moments(field);
        const auto actualMoments=framed.PhysicalMoments(d);
        const Real volume=oracle.volume[0].convert_to<Real>();
        for(unsigned a=0;a<3;++a) {
            stats.Observe((actualMoments.mean[a]-expectedMoments[4*a].convert_to<Real>())/(volume*amplitude),stats.moments);
            for(unsigned b=0;b<3;++b)
                stats.Observe((actualMoments.first(a,b)-expectedMoments[4*a+b+1].convert_to<Real>())/
                              (volume*amplitude*radius),stats.moments);
        }
    }
    for(unsigned a=0;a<fields.size();++a)
        for(unsigned b=0;b<fields.size();++b) {
            const Real expected=oracle.Kinetic(fields[a],fields[b]).convert_to<Real>();
            stats.Observe((framed.Inner(dofs[a],dofs[b])-expected)/std::sqrt(exactNorm[a]*exactNorm[b]),stats.crossWork);
        }
    return stats;
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        const double angle=argc>1?std::strtod(argv[1],nullptr):3.2137858346770188e-11;
        using V=glm::dvec3;
        convex_ports::Compiler geometry;
        geometry.Build(1,owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))));
        const auto fields=PhysicalFields();
        Stats total;
        for(const auto& cell:geometry.cells) {
            const ff::Cell framed(cell);
            const auto stats=CheckCell(cell,framed,fields);
            total.Merge(stats);
            std::printf("FRAMED_PHYSICAL_PATCH seed=%u piece=%u volume=%Lg velocity_abs=%Lg normal_abs=%Lg "
                        "energy_relative=%Lg energy_abs=%Lg cross_work_relative=%Lg moments_relative=%Lg "
                        "checks=%u failures=%u\n",cell.seed,cell.piece,cell.volume.convert_to<Real>(),
                        stats.velocity,stats.normal,stats.energy,stats.energyAbs,stats.crossWork,stats.moments,
                        stats.checks,stats.failures);
        }
        std::printf("FRAMED_PHYSICAL_SUMMARY angle=%.17g fields=%zu checks=%u failures=%u "
                    "velocity_abs=%Lg normal_abs=%Lg energy_relative=%Lg cross_work_relative=%Lg "
                    "moments_relative=%Lg threshold=1e-8 "
                    "oracle_input=exact_physical_dofs_transformed_before_cast "
                    "original_failures=preserved global_continuity_not_tested=1\n",
                    angle,fields.size(),total.checks,total.failures,total.velocity,total.normal,
                    total.energy,total.crossWork,total.moments);
        return total.failures?1:0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"FRAMED_PHYSICAL_PATCH_ERROR %s\n",error.what());
        return 1;
    }
}
