#include "VoxelPorts.h"
#include "Network.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
namespace net=stage17_network;
using R=voxel_ports::R;using RV=voxel_ports::RV;
unsigned checks=0,failures=0;
void Check(bool pass,const char* text){++checks;if(!pass){++failures;printf("FAIL %s\n",text);}}
R BodyVolume(const voxel_ports::Box& box){std::array<RV,3> n;RV w;for(unsigned a=0;a<3;++a){for(unsigned b=0;b<3;++b)n[a][b]=R(box[2*a+1].normal[b]);w[a]=R(box[2*a].coordinate)+R(box[2*a+1].coordinate);}return w[0]*w[1]*w[2]/abs(owned_metrics::Dot(n[0],owned_metrics::Cross(n[1],n[2])));}

int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;
    for(double angle:{0.,.17,3.2137858346770188e-11}){
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));voxel_ports::Compiler geometry;geometry.Build(1,box);
        R volume=0,bgArea=0,solidVolume=0;net::Real minimum=1;
        for(const auto& c:geometry.cells){volume+=c.volume;minimum=std::min(minimum,c.volume.convert_to<net::Real>());Check(c.seed==0,"physical pressure-cell identity is original voxel, not integration tetrahedron");for(const auto& f:c.faces)for(const auto& t:f.triangles){if(f.kind==convex_ports::Kind::Background){const auto area=t.areaVector;bgArea+=abs(area[0])+abs(area[1])+abs(area[2]);}if(f.kind==convex_ports::Kind::Solid)solidVolume+=owned_metrics::Dot(t.points[0],t.areaVector)/3;}}
        Check(geometry.cells.size()<=6 && geometry.cells.size()>0,"at most six actual convex outside pieces per voxel");Check(volume==R(1)-BodyVolume(box),"exact wet volume preserved across integration-seed removal");Check(bgArea==6,"quad background identifier retains whole six-square exterior area");Check(solidVolume==-BodyVolume(box),"actual wetted solid triangles preserve exact enclosed body volume");Check(minimum>.01L,"tiny-diagonal fixture has no invented subatomic physical cells");
        net::Network world(geometry,R(1),net::Boundary::Sealed);
        for(unsigned scenario=0;scenario<3;++scenario){const net::vm::Vec3 source=scenario?net::vm::Vec3::Zero():net::vm::Vec3(0,-.04L,0);net::Twist body=net::Twist::Zero();if(scenario==1)body<<.01,-.02,.03,0,0,0;if(scenario==2)body<<.01,-.02,.03,.02,.03,-.01;const auto result=world.Solve(world.Constant(source),body);net::Real div=0,pointDiv=0,trace=0,calm=0,calmRms=0;
            for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];const auto& raw=result.local[c];const auto moments=(local.op.divergenceMoments*raw).eval();div=std::max(div,moments.cwiseAbs().maxCoeff()/local.cell.geometry.volume[0]);const auto coeff=local.op.Divergence(raw);for(unsigned f=0;f<local.cell.faces.size();++f)for(const auto& triangle:local.cell.faces[f].triangles)for(const auto& exact:triangle.points){const net::vm::Vec3 r(exact[0].convert_to<net::Real>(),exact[1].convert_to<net::Real>(),exact[2].convert_to<net::Real>());Eigen::Matrix<net::Real,4,1> p;p<<1,r.x(),r.y(),r.z();pointDiv=std::max(pointDiv,std::abs(coeff.dot(p)));if(local.cell.faces[f].kind==convex_ports::Kind::Solid){net::vm::Vec3 center;for(unsigned a=0;a<3;++a)center(a)=local.cell.center[a].convert_to<net::Real>();const auto velocity=(body.head<3>()+body.tail<3>().cross(center+r)).eval();trace=std::max(trace,std::abs(local.op.EvaluateFaceNormal(f,raw,r)-local.op.geometry.faces[f].normal.dot(velocity)));}if(scenario==0)calm=std::max(calm,net::vm::EvaluateAffine(local.op.Project(raw),r).norm());}if(scenario==0)calmRms=std::max(calmRms,std::sqrt(2*local.op.Energy(raw)/(1000*local.cell.geometry.volume[0])));}
            Check(div<1e-8L && pointDiv<1e-8L,"actual normalized and pointwise physical divergence");Check(trace<1e-8L,"actual primary rigid-body boundary trace");Check(result.energyIdentity<1e-10L && result.stationarity<1e-10L,"unchanged pressure source work and kinetic stationarity");if(scenario==0){const auto expected=-1000*BodyVolume(box).convert_to<net::Real>()*source;Check(result.energy<1e-18L && calm<1e-8L && calmRms<1e-8L,"hydrostatic state remains locally calm including complementary kinetic modes");Check((result.reaction.head<3>()-expected).norm()<1e-9L,"independent correct hydrostatic body load");}
            printf("VOXEL_PRESSURE angle=%.17g scenario=%u cells=%zu variables=%ld min_volume=%Lg energy=%Lg force=%Lg,%Lg,%Lg normalized_div=%Lg point_div=%Lg trace=%Lg calm=%Lg calm_rms=%Lg work=%Lg solve_ms=%g\n",angle,scenario,world.cells.size(),long(world.mass.rows()),minimum,result.energy,result.reaction[0],result.reaction[1],result.reaction[2],div,pointDiv,trace,calm,calmRms,result.energyIdentity,result.solveMs);
        }
    }
    printf("VOXEL_PORTS_SUMMARY checks=%u failures=%u\n",checks,failures);return failures?1:0;
}catch(const std::exception& error){fprintf(stderr,"ERROR after%uchecks %s\n",checks,error.what());return 1;}}
