#include "PreparedMechanicalSchur.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace stage17_network;
using V=glm::dvec3;
unsigned checks=0;
void Check(bool pass,const char* text){++checks;if(!pass)throw std::runtime_error(text);}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
 for(unsigned n:{1,2})for(double angle:{0.,.17,3.2137858346770188e-11}) {
  auto b=owned_cut::BoxPlanes(V(.5*n),V(.2*n),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
  stage17_voxel::Epoch e(n,b,vg::R(1)/n,Boundary::Sealed);
  const auto t=Clock::now();Eigen::Matrix<Real,6,6> reference;
  for(unsigned axis=0;axis<6;++axis){Twist u=Twist::Zero();u[axis]=1;reference.col(axis)=-e.Solve(e.Constant(vm::Vec3::Zero()),u).reaction;}
  const double probes=Milliseconds(t);
  stage17_mechanical::Operator reduced(e);
  Check((reduced.addedMass-reference).norm()<1e-10L*std::max<Real>(1,reference.norm()),"native reduced operator differs from full six physical solves");
  Real sourceError=0,workError=0;
  for(unsigned scenario=0;scenario<3;++scenario){auto predictors=e.Constant(scenario?vm::Vec3(.017,-.04,.03):vm::Vec3::Zero());
   if(scenario==2)for(unsigned c=0;c<e.cells.size();++c){predictors[c][1]=.02;predictors[c][6]=-.02;predictors[c][10]=.01;}
   const auto load=reduced.Source(predictors);Twist twist;twist<<.01,-.02,.03,.02,.03,-.01;
   const auto zero=e.Solve(predictors);const auto actual=e.Solve(predictors,twist);
   sourceError=std::max(sourceError,(load-zero.reaction).norm());
   const auto expected=(load-reduced.addedMass*twist).eval();
   Check((expected-actual.reaction).norm()<1e-10L,"arbitrary source and nonzero rigid motion preserve actual body wrench");
   workError=std::max(workError,std::abs(twist.dot(expected-actual.reaction)));
  }
  bool rejected=false;auto bad=e.Constant(vm::Vec3::Zero());bad[0][0]=std::numeric_limits<Real>::quiet_NaN();try{reduced.Source(bad);}catch(const std::invalid_argument&){rejected=true;}
  Check(rejected,"nonfinite source rejected before any native publication");
  Check((reduced.Source(e.Constant(vm::Vec3::Zero()))).norm()<1e-15L,"rejected source does not poison prepared mechanical operator");
  printf("PREPARED_MECHANICAL n=%u angle=%.17g physical_six_probes_ms=%g reduced_ms=%g mass_error=%Lg source_error=%Lg work_error=%Lg residual=%Lg\n",n,angle,probes,reduced.preparationMs,(reduced.addedMass-reference).norm(),sourceError,workError,reduced.residual);
  e=stage17_voxel::Epoch(n,b,vg::R(1)/n,Boundary::Sealed);
  rejected=false;try{reduced.Source(e.Constant(vm::Vec3::Zero()));}catch(const std::invalid_argument&){rejected=true;}
  Check(rejected,"cached mechanical response rejects a superseded geometry/factor generation");

 }
 printf("PREPARED_MECHANICAL_SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL after%uchecks %s\n",checks,error.what());return 1;}}
