#pragma once

// Independent Stage17 acceptance geometry. The clipping algorithm below is a
// small rational 2D triangle intersection oracle, NOT the candidate's native
// polyhedron clipping or its port-key/coverage construction.
#include "../../fluid-runtime-candidates-stage16-20261029/geometry/PolyhedralMoments.h"

namespace port_acceptance {
using stage16_geometry::R;
using stage16_geometry::RV;
using stage16_geometry::Sub;
using Triangle=stage16_geometry::BoundaryTriangle;
using Patch=std::vector<Triangle>;
using Moments=std::array<R,10>;

inline RV Sum(RV a,const RV& b) {
    for(unsigned i=0;i<3;++i) a[i]+=b[i];
    return a;
}
inline RV Scale(RV a,const R& scale) {
    for(auto& x:a) x*=scale;
    return a;
}
inline void Add(Moments& a,const Moments& b) {
    for(unsigned i=0;i<10;++i) a[i]+=b[i];
}

template<unsigned N>
inline Moments SimplexP2(const std::array<RV,N>& points,const R& measure) {
    Moments out{};
    out[0]=measure;
    RV sum{};
    for(const auto& point:points) sum=Sum(sum,point);
    for(unsigned axis=0;axis<3;++axis) out[axis+1]=measure*sum[axis]/N;
    for(unsigned a=0;a<3;++a)
        for(unsigned b=a;b<3;++b) {
            R second=sum[a]*sum[b];
            for(const auto& point:points) second+=point[a]*point[b];
            out[JudasFluidVem::ProductIndex(a+1,b+1)]=measure*second/(N*(N+1));
        }
    return out;
}

inline Moments TetraP2(const std::array<RV,4>& points) {
    const R measure=owned_metrics::Dot(Sub(points[1],points[0]),
        owned_metrics::Cross(Sub(points[2],points[0]),Sub(points[3],points[0])))/6;
    if(measure<=0) throw std::runtime_error("independent oracle requires positive tetrahedron");
    return SimplexP2<4>(points,measure);
}

inline unsigned Pivot(const Triangle& triangle) {
    unsigned pivot=0;
    for(unsigned a=1;a<3;++a)
        if(abs(triangle.areaVector[a])>abs(triangle.areaVector[pivot])) pivot=a;
    if(triangle.areaVector[pivot]==0) throw std::runtime_error("independent oracle found zero-area triangle");
    return pivot;
}

inline Moments PatchP2(const Patch& patch,unsigned pivot) {
    Moments out{};
    for(const auto& triangle:patch)
        Add(out,SimplexP2<3>(triangle.points,abs(triangle.areaVector[pivot])));
    return out;
}

struct Point2 { R x=0,y=0; };
inline Point2 Project(const RV& point,unsigned pivot) {
    return {point[(pivot+1)%3],point[(pivot+2)%3]};
}
inline R Side(const Point2& a,const Point2& b,const Point2& point) {
    return (b.x-a.x)*(point.y-a.y)-(b.y-a.y)*(point.x-a.x);
}
inline Point2 Crossing(const Point2& a,const Point2& b,const R& sa,const R& sb) {
    const R t=sa/(sa-sb);
    return {a.x+t*(b.x-a.x),a.y+t*(b.y-a.y)};
}

inline R IntersectionArea(const Triangle& a,const Triangle& b,unsigned pivot) {
    std::vector<Point2> polygon;
    for(const auto& point:a.points) polygon.push_back(Project(point,pivot));
    std::array<Point2,3> clip;
    for(unsigned i=0;i<3;++i) clip[i]=Project(b.points[i],pivot);
    if(Side(clip[0],clip[1],clip[2])<0) std::swap(clip[1],clip[2]);
    if(Side(clip[0],clip[1],clip[2])==0) return 0;
    for(unsigned edge=0;edge<3 && !polygon.empty();++edge) {
        std::vector<Point2> next;
        const auto& ca=clip[edge];
        const auto& cb=clip[(edge+1)%3];
        for(unsigned i=0;i<polygon.size();++i) {
            const auto& p=polygon[i];
            const auto& q=polygon[(i+1)%polygon.size()];
            const R sp=Side(ca,cb,p),sq=Side(ca,cb,q);
            if(sp>=0) next.push_back(p);
            if((sp<0 && sq>0) || (sp>0 && sq<0)) next.push_back(Crossing(p,q,sp,sq));
        }
        polygon=std::move(next);
    }
    R twice=0;
    for(unsigned i=0;i<polygon.size();++i) {
        const auto& p=polygon[i];
        const auto& q=polygon[(i+1)%polygon.size()];
        twice+=p.x*q.y-p.y*q.x;
    }
    return abs(twice)/2;
}

inline R Area(const Patch& patch,unsigned pivot) {
    R area=0;
    for(const auto& triangle:patch) area+=abs(triangle.areaVector[pivot]);
    return area;
}
inline R SelfOverlap(const Patch& patch,unsigned pivot) {
    R overlap=0;
    for(unsigned a=0;a<patch.size();++a)
        for(unsigned b=a+1;b<patch.size();++b)
            overlap+=IntersectionArea(patch[a],patch[b],pivot);
    return overlap;
}
inline R SymmetricDifference(const Patch& a,const Patch& b,unsigned pivot) {
    R intersection=0;
    for(const auto& left:a)
        for(const auto& right:b) intersection+=IntersectionArea(left,right,pivot);
    return Area(a,pivot)+Area(b,pivot)-2*intersection;
}

// Independent homogeneous-divergence identities through degree two. Every
// actual port patch is included, including internal convex-piece interfaces.
inline Moments BoundaryVolumeP2(const Patch& boundary) {
    Moments out{};
    for(const auto& triangle:boundary) {
        const R radial=owned_metrics::Dot(triangle.points[0],triangle.areaVector);
        const auto average=SimplexP2<3>(triangle.points,R(1));
        for(unsigned m=0;m<10;++m) {
            const auto& p=JudasFluidVem::Powers[m];
            out[m]+=radial*average[m]/(p[0]+p[1]+p[2]+3);
        }
    }
    return out;
}

} // namespace port_acceptance
