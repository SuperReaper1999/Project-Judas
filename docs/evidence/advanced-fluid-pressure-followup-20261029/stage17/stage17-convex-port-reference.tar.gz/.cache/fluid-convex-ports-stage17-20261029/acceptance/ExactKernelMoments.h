#pragma once

// Independent exact Green-identity reconstruction from ACTUAL primary face
// fluxes. Does not import the candidate's momentOperator/projection, SVD rows,
// supplied face Gram, mixed moments or claim that a named kernel is exact.
#include "ExactPatchOracle.h"
#include "../FramedCell.h"

namespace exact_kernel {
using R=port_acceptance::R;
using RV=port_acceptance::RV;
using Real=JudasFluidVem::Real;
using Moments=std::array<R,20>;
using P1=std::array<R,4>;
using P2=std::array<R,10>;
template<unsigned N>using Matrix=std::array<std::array<R,N>,N>;

template<unsigned N>
inline std::array<R,N> Solve(Matrix<N> a,std::array<R,N> b) {
    for(unsigned column=0;column<N;++column) {
        unsigned pivot=column;
        while(pivot<N && a[pivot][column]==0) ++pivot;
        if(pivot==N) throw std::runtime_error("exact independent geometry Gram is singular");
        if(pivot!=column) {std::swap(a[pivot],a[column]);std::swap(b[pivot],b[column]);}
        const R diagonal=a[column][column];
        for(unsigned j=column;j<N;++j) a[column][j]/=diagonal;
        b[column]/=diagonal;
        for(unsigned row=0;row<N;++row) if(row!=column) {
            const R factor=a[row][column];
            if(factor==0) continue;
            for(unsigned j=column;j<N;++j) a[row][j]-=factor*a[column][j];
            b[row]-=factor*b[column];
        }
    }
    return b;
}
template<unsigned N>
inline Matrix<N> Inverse(const Matrix<N>& a) {
    Matrix<N> inverse{};
    for(unsigned column=0;column<N;++column) {
        std::array<R,N> rhs{};rhs[column]=1;
        const auto value=Solve<N>(a,rhs);
        for(unsigned row=0;row<N;++row) inverse[row][column]=value[row];
    }
    return inverse;
}

template<unsigned N>
inline R Average(const std::array<std::array<R,N>,3>& factors,unsigned degree) {
    if(degree==0) return 1;
    std::array<R,3> sums{};
    for(unsigned i=0;i<degree;++i) for(const auto& value:factors[i]) sums[i]+=value;
    if(degree==1) return sums[0]/N;
    R q01=0;
    for(unsigned vertex=0;vertex<N;++vertex) q01+=factors[0][vertex]*factors[1][vertex];
    if(degree==2) return (sums[0]*sums[1]+q01)/(N*(N+1));
    if(degree!=3) throw std::runtime_error("exact independent moment exceeds P3");
    R q02=0,q12=0,triple=0;
    for(unsigned vertex=0;vertex<N;++vertex) {
        q02+=factors[0][vertex]*factors[2][vertex];
        q12+=factors[1][vertex]*factors[2][vertex];
        triple+=factors[0][vertex]*factors[1][vertex]*factors[2][vertex];
    }
    return (sums[0]*sums[1]*sums[2]+q01*sums[2]+q02*sums[1]+q12*sums[0]+2*triple)
            /(N*(N+1)*(N+2));
}
template<unsigned N>
inline R Monomial(const std::array<RV,N>& points,unsigned m) {
    std::array<std::array<R,N>,3> factors{};
    unsigned degree=0;
    for(unsigned axis=0;axis<3;++axis)
        for(unsigned power=0;power<JudasFluidVem::Powers[m][axis];++power) {
            for(unsigned vertex=0;vertex<N;++vertex) factors[degree][vertex]=points[vertex][axis];
            ++degree;
        }
    return Average<N>(factors,degree);
}
inline R Weighted(const std::array<RV,3>& points,const std::array<R,3>& psi,unsigned m) {
    std::array<std::array<R,3>,3> factors{};
    factors[0]=psi;
    unsigned degree=1;
    for(unsigned axis=0;axis<3;++axis)
        for(unsigned power=0;power<JudasFluidVem::Powers[m][axis];++power) {
            for(unsigned vertex=0;vertex<3;++vertex) factors[degree][vertex]=points[vertex][axis];
            ++degree;
        }
    return Average<3>(factors,degree);
}
inline std::array<R,3> Factors(const stage16_factored::CanonicalFrame& face,const RV& point) {
    const RV delta=convex_ports::Sub(point,face.origin);
    return {R(1),(owned_metrics::Dot(face.edge,delta)-face.midU)/face.spanU,
                (owned_metrics::Dot(face.transverse,delta)-face.midV)/face.spanV};
}

struct Face {
    Matrix<3> inverseGram;
    std::array<std::array<R,3>,10> mixed{};
};
struct Result {
    std::array<P1,3> physicalMoments{}; // integral v_a * [1,xi], physical dV
    std::array<P1,3> physicalPolynomial{};
    R projectionEnergy=0;
    Real maxPointLeak=0,maxScaledMoment=0,energyFraction=0;
};

struct Oracle {
    stage17_framed::Frame frame;
    Moments volume{};
    Matrix<4> inverseScalarGram;
    std::vector<Face> faces;
    std::vector<RV> vertices;

    Oracle(const convex_ports::Cell& input,const stage17_framed::Cell& geometry):frame(geometry.frame) {
        std::set<RV> unique;
        for(const auto& tetrahedron:input.integration) {
            std::array<RV,4> xi;
            for(unsigned vertex=0;vertex<4;++vertex) {
                xi[vertex]=frame.Coordinates(tetrahedron.points[vertex]);
                unique.insert(xi[vertex]);
            }
            for(unsigned m=0;m<20;++m) volume[m]+=tetrahedron.volume*Monomial<4>(xi,m);
        }
        vertices.assign(unique.begin(),unique.end());
        Matrix<4> normalized{};
        for(unsigned i=0;i<4;++i)
            for(unsigned j=0;j<4;++j)
                normalized[i][j]=volume[JudasFluidVem::ProductIndex(i,j)]/volume[0];
        inverseScalarGram=Inverse<4>(normalized);

        for(unsigned faceIndex=0;faceIndex<input.faces.size();++faceIndex) {
            const auto& source=input.faces[faceIndex];
            const auto& canonical=geometry.faces[faceIndex];
            Face out;
            Matrix<3> gram{};
            R total=0;
            for(const auto& triangle:source.triangles) {
                // Weighted reference surface scale is constant on the plane
                // and cancels exactly in H^T G^-1. Work in projected area to
                // avoid ever approximating its irrational normal factor.
                const unsigned pivot=port_acceptance::Pivot(triangle);
                const R measure=abs(triangle.areaVector[pivot]);
                if(measure<=0) throw std::runtime_error("independent kernel face measure is not positive");
                total+=measure;
                std::array<RV,3> xi;
                std::array<std::array<R,3>,3> psi{};
                for(unsigned vertex=0;vertex<3;++vertex) {
                    xi[vertex]=frame.Coordinates(triangle.points[vertex]);
                    const auto factors=Factors(canonical,triangle.points[vertex]);
                    for(unsigned row=0;row<3;++row) psi[row][vertex]=factors[row];
                }
                for(unsigned row=0;row<3;++row) {
                    for(unsigned col=0;col<3;++col) {
                        std::array<std::array<R,3>,3> factors{};
                        factors[0]=psi[row];factors[1]=psi[col];
                        gram[row][col]+=measure*Average<3>(factors,2);
                    }
                    for(unsigned m=0;m<10;++m) out.mixed[m][row]+=measure*Weighted(xi,psi[row],m);
                }
            }
            for(auto& row:gram) for(auto& value:row) value/=total;
            for(auto& row:out.mixed) for(auto& value:row) value/=total;
            out.inverseGram=Inverse<3>(gram);
            faces.push_back(std::move(out));
        }
    }

    // Six EXACT symmetric Green constraints for face coordinates with the
    // independently declared Mhat=Lhat=0. Extraction does not use a floating
    // projection or evaluate the reconstruction at six selected flow states.
    std::array<std::vector<R>,6> SymmetricConstraints() const {
        std::array<std::vector<R>,6> constraints;
        for(auto& row:constraints) row.resize(3*faces.size(),R(0));
        for(unsigned face=0;face<faces.size();++face)
            for(unsigned local=0;local<3;++local) {
                std::array<R,10> boundary{};
                for(unsigned m=0;m<10;++m)
                    for(unsigned j=0;j<3;++j)
                        boundary[m]+=faces[face].mixed[m][j]*faces[face].inverseGram[j][local];
                P1 divergence{};
                for(unsigned i=0;i<4;++i)
                    for(unsigned j=0;j<4;++j)
                        divergence[i]+=inverseScalarGram[i][j]*(boundary[j]/volume[0]);
                unsigned row=0;
                for(unsigned a=0;a<3;++a)
                    for(unsigned b=a;b<3;++b) {
                        const unsigned monomial=JudasFluidVem::ProductIndex(a+1,b+1);
                        R value=boundary[monomial];
                        for(unsigned j=0;j<4;++j)
                            value-=divergence[j]*volume[JudasFluidVem::ProductIndex(monomial,j)];
                        constraints[row++][3*face+local]=value;
                    }
            }
        return constraints;
    }

    Result Reconstruct(const std::vector<R>& physicalFaceFlux,Real declaredEnergy) const {
        if(physicalFaceFlux.size()!=3*faces.size())
            throw std::runtime_error("independent kernel face flux count mismatch");
        std::array<R,10> boundary{};
        for(unsigned face=0;face<faces.size();++face) {
            std::array<R,3> coefficients{};
            for(unsigned i=0;i<3;++i)
                for(unsigned j=0;j<3;++j)
                    coefficients[i]+=faces[face].inverseGram[i][j]*physicalFaceFlux[3*face+j];
            for(unsigned m=0;m<10;++m)
                for(unsigned j=0;j<3;++j) boundary[m]+=faces[face].mixed[m][j]*coefficients[j];
        }
        // Declared reference Mhat=Lhat=0, hence all divergence moments are the
        // actual boundary moments. No named-kernel assumption zeroes them.
        P1 divergence{};
        for(unsigned i=0;i<4;++i)
            for(unsigned j=0;j<4;++j)
                divergence[i]+=inverseScalarGram[i][j]*(boundary[j]/volume[0]);
        std::array<RV,3> first{};
        for(unsigned a=0;a<3;++a)
            for(unsigned b=a;b<3;++b) {
                const unsigned monomial=JudasFluidVem::ProductIndex(a+1,b+1);
                R sum=boundary[monomial];
                for(unsigned j=0;j<4;++j)
                    sum-=divergence[j]*volume[JudasFluidVem::ProductIndex(monomial,j)];
                // With Lhat=0 the skew moments vanish; the symmetric Green
                // moment therefore splits equally, including diagonal rows.
                first[a][b]=first[b][a]=sum/2;
            }
        Result result;
        for(unsigned physical=0;physical<3;++physical)
            for(unsigned coordinate=0;coordinate<3;++coordinate)
                for(unsigned reference=0;reference<3;++reference)
                    result.physicalMoments[physical][coordinate+1]
                        +=frame.columns[reference][physical]*first[reference][coordinate];
        for(unsigned a=0;a<3;++a) {
            for(unsigned i=0;i<4;++i)
                for(unsigned j=0;j<4;++j)
                    result.physicalPolynomial[a][i]+=inverseScalarGram[i][j]
                        *result.physicalMoments[a][j]/volume[0];
            for(unsigned i=0;i<4;++i)
                result.projectionEnergy+=500*result.physicalPolynomial[a][i]*result.physicalMoments[a][i];
        }
        if(result.projectionEnergy<0) throw std::runtime_error("exact reconstructed polynomial energy became negative");
        for(const auto& xi:vertices) {
            Real speedSquared=0;
            for(unsigned a=0;a<3;++a) {
                R value=result.physicalPolynomial[a][0];
                for(unsigned j=0;j<3;++j) value+=result.physicalPolynomial[a][j+1]*xi[j];
                const Real rounded=value.convert_to<Real>();speedSquared+=rounded*rounded;
            }
            result.maxPointLeak=std::max(result.maxPointLeak,std::sqrt(speedSquared));
        }
        for(unsigned a=0;a<3;++a)
            for(unsigned m=0;m<4;++m) {
                const Real testNorm=volume[JudasFluidVem::ProductIndex(m,m)].convert_to<Real>();
                const Real scale=std::sqrt(2*declaredEnergy*testNorm/1000);
                const Real error=abs(result.physicalMoments[a][m]).convert_to<Real>();
                if(scale>0) result.maxScaledMoment=std::max(result.maxScaledMoment,error/scale);
            }
        result.energyFraction=result.projectionEnergy.convert_to<Real>()/declaredEnergy;
        return result;
    }
};
} // namespace exact_kernel
