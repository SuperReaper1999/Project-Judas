from pathlib import Path
import subprocess,time,json,hashlib,sys
root=Path('.cache/fluid-convex-ports-stage17-20261029')
results=[]
tasks=[('prepared-mechanical-final',['python3',str(root/'run_probe.py'),'PreparedMechanicalTests.cpp'],'PreparedMechanicalTests.exe'),('symmetric-resolution-final',['python3',str(root/'run_probe.py'),'SymmetricVoxelResolutionProbe.cpp'],'SymmetricVoxelResolutionProbe.exe'),('translated-sweep-final',['python3',str(root/'run_probe.py'),'TranslatedSolidSweepTests.cpp'],'TranslatedSolidSweepTests.exe'),('momentum-transport-v1',['python3',str(root/'run_probe.py'),'PortMomentumTransportTests.cpp'],'PortMomentumTransportTests.exe'),('symmetric-native-final',['python3',str(root/'run_symmetric_prepared_native.py')],None),('voxel-condensation-final',['python3',str(root/'run_probe.py'),'VoxelCondensationTests.cpp'],'VoxelCondensationTests.exe')]
for name,command,binary in tasks:
    start=time.time();print('START',name,flush=True)
    with (root/'logs'/f'{name}.log').open('w') as log:
        completed=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    entry={'name':name,'command':command,'returncode':completed.returncode,'startedUnix':start,'elapsedSeconds':time.time()-start,'log':str(root/'logs'/f'{name}.log')}
    if binary and (root/binary).exists():entry['binarySha256']=hashlib.sha256((root/binary).read_bytes()).hexdigest()
    results.append(entry);(root/'current-batch-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print('DONE',name,'status',completed.returncode,'seconds',entry['elapsedSeconds'],flush=True)
print('BATCH_COMPLETE',len(results),'failed',sum(x['returncode']!=0 for x in results),flush=True)
