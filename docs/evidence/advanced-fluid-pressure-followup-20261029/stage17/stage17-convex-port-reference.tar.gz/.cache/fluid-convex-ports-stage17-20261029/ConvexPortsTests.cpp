#include "ConvexPorts.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

using namespace convex_ports;
unsigned checks=0;
void Check(bool condition,const char* message) {++checks;if(!condition) throw std::runtime_error(message);}

R BoxVolume(const Box& box) {
    std::array<RV,3> n;RV width;
    for(unsigned a=0;a<3;++a) {
        for(unsigned b=0;b<3;++b) n[a][b]=R(box[2*a+1].normal[b]);
        width[a]=R(box[2*a].coordinate)+R(box[2*a+1].coordinate);
    }
    return width[0]*width[1]*width[2]/abs(owned_metrics::Dot(n[0],owned_metrics::Cross(n[1],n[2])));
}

bool Outer(const PortKey& key,unsigned grid) {
    for(unsigned a=0;a<3;++a) {
        bool low=true,high=true;
        for(const auto& p:key.background) {low&=p[a]==0;high&=p[a]==int(grid);}
        if(low||high) return true;
    }
    return false;
}

void Run(unsigned fixture,unsigned grid,const Box& box,const R& expected,unsigned expectedComponents) {
    Compiler geometry;geometry.Build(grid,box);
    std::map<PortKey,std::vector<std::pair<unsigned,unsigned>>> ports;
    R volume=0;
    std::vector<unsigned> parent(geometry.cells.size());std::iota(parent.begin(),parent.end(),0);
    const auto root=[&](unsigned p){while(parent[p]!=p)p=parent[p];return p;};
    unsigned solid=0;
    for(unsigned c=0;c<geometry.cells.size();++c) {
        const auto& cell=geometry.cells[c];volume+=cell.volume;
        Check(cell.piece<6 && cell.volume>0,"physical convex cell has positive volume and true exclusion label");
        std::set<PortKey> local;
        for(unsigned f=0;f<cell.faces.size();++f) {
            const auto& face=cell.faces[f];
            Check(local.insert(face.key).second,"one physical cell contains duplicate port identity");
            Check(!face.triangles.empty(),"physical port has actual geometry");
            ports[face.key].push_back({c,f});
            if(face.kind==Kind::Solid) ++solid;
        }
    }
    Check(volume==expected,"sum of convex physical cells equals independent exact wet volume");
    for(const auto& [key,owners]:ports) {
        const bool boundary=key.kind==Kind::Solid || (key.kind==Kind::Background && Outer(key,grid));
        Check(owners.size()==(boundary?1u:2u),"physical port has correct boundary or pairwise incidence");
        if(owners.size()==2) {
            const auto [a,fa]=owners[0];const auto [b,fb]=owners[1];
            const RV first=Compiler::Area(geometry.cells[a].faces[fa].triangles);
            const RV second=Compiler::Area(geometry.cells[b].faces[fb].triangles);
            for(unsigned axis=0;axis<3;++axis) Check(first[axis]+second[axis]==0,"shared port has exactly opposite oriented area");
            parent[root(b)]=root(a);
        }
    }
    std::set<unsigned> components;
    for(unsigned c=0;c<geometry.cells.size();++c) components.insert(root(c));
    Check(components.size()==expectedComponents,"actual primary-port connectivity matches physical wet topology");
    std::printf("CONVEX_PORTS fixture=%u grid=%u cells=%zu ports=%zu solid_patches=%u components=%zu\n",fixture,grid,geometry.cells.size(),ports.size(),solid,components.size());
}

int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
    using V=glm::dvec3;
    const auto axis=owned_cut::BoxPlanes(V(.5),V(.2),glm::dquat(1,0,0,0));
    Run(0,1,axis,R(1)-BoxVolume(axis),1);
    const auto oblique=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(.17,glm::normalize(V(1,2,-.3))));
    Run(1,1,oblique,R(1)-BoxVolume(oblique),1);
    const auto tiny=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(1e-10,glm::normalize(V(1,2,-.3))));
    Run(2,1,tiny,R(1)-BoxVolume(tiny),1);
    const auto touch=owned_cut::BoxPlanes(V(1.25,.5,.5),V(.25),glm::dquat(1,0,0,0));
    Run(3,2,touch,R(8)-BoxVolume(touch),1);
    const auto edge=owned_cut::BoxPlanes(V(1.25,1.25,.5),V(.25),glm::dquat(1,0,0,0));
    Run(4,2,edge,R(8)-BoxVolume(edge),1);
    const auto slab=owned_cut::BoxPlanes(V(.5),V(.0625,2,2),glm::dquat(1,0,0,0));
    Run(5,1,slab,R(7)/8,2);
    const auto full=owned_cut::BoxPlanes(V(.5),V(2),glm::dquat(1,0,0,0));
    Run(6,1,full,R(0),0);
    for(unsigned grid:{0u,9u,~0u}) {
        bool rejected=false;
        try {Compiler invalid;invalid.Build(grid,axis);}
        catch(const std::invalid_argument&) {rejected=true;}
        Check(rejected,"invalid grid rejected before allocating seed storage");
    }
    std::printf("CONVEX_PORTS_SUMMARY checks=%u failures=0\n",checks);return 0;
}catch(const std::exception& error){std::fprintf(stderr,"FAIL after%uchecks %s\n",checks,error.what());return 1;}}
