#pragma once

// Isolated conditioning prototype. Stage16 and Network are deliberately not
// changed. This stores reference DOFs and a positive kinetic factor. It is an
// affine congruence of the already chosen physical VEM metric, including its
// stabilization about the ORIGINAL physical bounding-box origin.
#include "ConvexPorts.h"
#include "../fluid-runtime-candidates-stage16-20261029/geometry/FactoredFaceMetrics.h"
#include "../fluid-runtime-candidates-stage16-20261029/vem/VemLocal.h"

namespace stage17_framed {
namespace vm=JudasFluidVem;
namespace fast=stage16_fast_geometry;
namespace fm=stage16_factored;
using Real=vm::Real;
using Vec=vm::Vec3;
using Mat=vm::Mat3;
using Matrix=vm::Matrix;
using Vector=vm::Vector;
using Affine=vm::Affine;
using R=convex_ports::R;
using RV=convex_ports::RV;
using ExactMatrix=std::array<RV,3>; // rows, unless explicitly called columns
using convex_ports::Sub;

inline RV Add(RV a,const RV& b){for(unsigned i=0;i<3;++i)a[i]+=b[i];return a;}
inline RV Mul(RV a,const R& scale){for(auto& x:a)x*=scale;return a;}
inline RV ExactApply(const ExactMatrix& rows,const RV& x){RV r;for(unsigned i=0;i<3;++i)r[i]=owned_metrics::Dot(rows[i],x);return r;}
inline Vec Rounded(const RV& a){return {a[0].convert_to<Real>(),a[1].convert_to<Real>(),a[2].convert_to<Real>()};}
inline Mat Cross(const Vec& a){Mat r;r<<0,-a.z(),a.y(),a.z(),0,-a.x(),-a.y(),a.x(),0;return r;}

struct Frame {
    RV origin{},oldOrigin{},offset{};
    std::array<RV,3> columns{},inverseRows{},cofactorColumns{};
    std::array<R,3> squaredLengths{};
    R determinant=0;
    Mat J=Mat::Zero(),inverse=Mat::Zero(),cofactor=Mat::Zero(),offsetCrossJ=Mat::Zero();

    RV Coordinates(const RV& global) const {return ExactApply(inverseRows,Sub(global,origin));}
    Vec CoordinatesReal(const RV& global) const{return Rounded(Coordinates(global));}
    RV VectorCoordinates(const RV& physical) const{return ExactApply(inverseRows,physical);}

    static Frame Build(const std::set<RV>& vertices,const RV& old) {
        if(vertices.size()<4)throw std::runtime_error("framed cell lacks independent exact geometry");
        Frame f;f.origin=*vertices.begin();f.oldOrigin=old;f.offset=Sub(f.origin,old);
        for(unsigned axis=0;axis<3;++axis) {
            R largest=0;RV selected{};
            for(const auto& point:vertices) {
                RV residual=Sub(point,f.origin);
                for(unsigned previous=0;previous<axis;++previous)
                    residual=Sub(residual,Mul(f.columns[previous],owned_metrics::Dot(f.columns[previous],residual)/f.squaredLengths[previous]));
                const R length=owned_metrics::Dot(residual,residual);
                if(length>largest){largest=length;selected=residual;}
            }
            if(largest<=0)throw std::runtime_error("framed cell exact orthogonal frame lost rank");
            f.columns[axis]=selected;f.squaredLengths[axis]=largest;
        }
        f.determinant=owned_metrics::Dot(f.columns[0],owned_metrics::Cross(f.columns[1],f.columns[2]));
        if(f.determinant<0){f.columns[2]=Mul(f.columns[2],R(-1));f.determinant=-f.determinant;}
        if(f.determinant<=0)throw std::runtime_error("framed cell orientation is not positive");
        for(unsigned i=0;i<3;++i) {
            f.inverseRows[i]=Mul(f.columns[i],R(1)/f.squaredLengths[i]);
            f.cofactorColumns[i]=owned_metrics::Cross(f.columns[(i+1)%3],f.columns[(i+2)%3]);
            const RV shifted=owned_metrics::Cross(f.offset,f.columns[i]);
            for(unsigned a=0;a<3;++a) {
                f.J(a,i)=f.columns[i][a].convert_to<Real>();
                f.inverse(i,a)=f.inverseRows[i][a].convert_to<Real>();
                f.cofactor(a,i)=f.cofactorColumns[i][a].convert_to<Real>();
                f.offsetCrossJ(a,i)=shifted[a].convert_to<Real>();
            }
        }
        return f;
    }
};

struct Moments {
    Vec mean=Vec::Zero(); // integral physical velocity dV
    Mat first=Mat::Zero(); // integral physical velocity * (x-oldOrigin)^T dV
};

struct Cell {
    Frame frame;
    vm::CellGeometry referenceGeometry;
    vm::LocalOperator reference;
    std::vector<fm::CanonicalFrame> faces;
    std::vector<Mat> physicalFaceGramInverse;
    std::vector<Vec> physicalNormals;
    std::vector<Real> normalScale;
    Matrix consistentPolynomialFactor,stabilizationFactor;
    Matrix kineticFactor; // reference DOFs only; do not form an unframed mass
    Real physicalVolume=0,density=1000;

    explicit Cell(const convex_ports::Cell& input,const R& physicalScale=R(1)) {
        if(physicalScale<=0)throw std::invalid_argument("framed cell physical scale must be positive");
        std::set<RV> points;
        for(const auto& simplex:input.integration)for(const auto& p:simplex.points)points.insert(Mul(p,physicalScale));
        frame=Frame::Build(points,Mul(input.center,physicalScale));
        const R exactVolume=input.volume*physicalScale*physicalScale*physicalScale;
        physicalVolume=exactVolume.convert_to<Real>();
        if(!(physicalVolume>0) || !std::isfinite(physicalVolume))throw std::runtime_error("framed cell physical volume is not representable");
        std::array<fast::Sum,20> volume;
        for(const auto& simplex:input.integration) {
            std::array<fast::Point,4> local;
            for(unsigned v=0;v<4;++v)local[v]=fast::Rounded(frame.Coordinates(Mul(simplex.points[v],physicalScale)));
            const Real measure=(simplex.volume*physicalScale*physicalScale*physicalScale).convert_to<Real>();
            for(unsigned m=0;m<20;++m)volume[m].Add(measure*fast::MonomialAverage<4>(local,m));
        }
        for(unsigned m=0;m<20;++m)referenceGeometry.volume[m]=volume[m].Get();
        referenceGeometry.volume[0]=physicalVolume;
        referenceGeometry.density=density;

        for(const auto& source:input.faces) {
            std::vector<convex_ports::BoundaryTriangle> triangles=source.triangles;
            for(auto& triangle:triangles) {
                for(auto& point:triangle.points)point=Mul(point,physicalScale);
                triangle.areaVector=Mul(triangle.areaVector,physicalScale*physicalScale);
            }
            const auto canonical=fm::BuildFrame(triangles);faces.push_back(canonical);
            const RV area=triangles[0].areaVector;
            RV weightedArea{};
            for(unsigned i=0;i<3;++i)weightedArea[i]=owned_metrics::Dot(frame.columns[i],area);
            const Vec physicalArea=Rounded(area),refArea=Rounded(weightedArea);
            const Real physicalNorm=physicalArea.norm(),referenceNorm=refArea.norm();
            if(!(physicalNorm>0) || !(referenceNorm>0))throw std::runtime_error("framed face weighted area is not representable");
            const Real alpha=referenceNorm/physicalNorm;
            physicalNormals.push_back(physicalArea/physicalNorm);normalScale.push_back(alpha);
            vm::FaceGeometry face;
            face.normal=refArea/referenceNorm;
            const auto physicalBasis=canonical.LocalBasis(frame.origin);
            for(unsigned i=0;i<3;++i) {
                face.basis(i,0)=physicalBasis[i][0].convert_to<Real>();
                for(unsigned j=0;j<3;++j) {
                    R coefficient=0;
                    for(unsigned a=0;a<3;++a)coefficient+=physicalBasis[i][a+1]*frame.columns[j][a];
                    face.basis(i,j+1)=coefficient.convert_to<Real>();
                }
            }
            face.anchoredBasis=true;
            face.evaluationOrigin=frame.CoordinatesReal(canonical.origin);
            const auto psiOrigin=canonical.Factors(canonical.origin);
            face.basisAtOrigin=Vec(psiOrigin[0],psiOrigin[1],psiOrigin[2]);
            std::array<fast::Sum,20> raw;
            std::array<std::array<fast::Sum,10>,3> mixed;
            std::array<std::array<fast::Sum,3>,3> gram;
            for(const auto& triangle:triangles) {
                std::array<fast::Point,3> local;
                std::array<std::array<Real,3>,3> psi;
                for(unsigned v=0;v<3;++v) {
                    local[v]=fast::Rounded(frame.Coordinates(triangle.points[v]));
                    const auto p=canonical.Factors(triangle.points[v]);
                    for(unsigned i=0;i<3;++i)psi[i][v]=p[i];
                }
                RV transformed{};
                for(unsigned i=0;i<3;++i)transformed[i]=owned_metrics::Dot(frame.columns[i],triangle.areaVector);
                const Real measure=Rounded(transformed).norm();
                for(unsigned m=0;m<20;++m)raw[m].Add(measure*fast::MonomialAverage<3>(local,m));
                for(unsigned i=0;i<3;++i) {
                    for(unsigned m=0;m<10;++m)mixed[i][m].Add(measure*fast::WeightedFaceAverage(local,psi[i],m));
                    for(unsigned j=0;j<3;++j) {
                        std::array<std::array<Real,3>,3> factors{};factors[0]=psi[i];factors[1]=psi[j];
                        gram[i][j].Add(measure*fast::ProductAverage<3>(factors,2));
                    }
                }
            }
            for(unsigned m=0;m<20;++m)face.area[m]=raw[m].Get();
            for(unsigned i=0;i<3;++i) {
                for(unsigned j=0;j<3;++j)face.gram(i,j)=gram[i][j].Get();
                for(unsigned m=0;m<10;++m)face.mixed(i,m)=mixed[i][m].Get();
            }
            physicalFaceGramInverse.push_back(alpha*vm::PositiveInverse(face.gram,"framed face Gram is not positive"));
            referenceGeometry.faces.push_back(std::move(face));
        }
        reference=vm::Build(referenceGeometry);
        const unsigned d=reference.dimension;
        const Real h=std::cbrt(physicalVolume);
        stabilizationFactor=Matrix::Zero(d,d);
        for(unsigned f=0;f<faces.size();++f) {
            Eigen::LLT<Mat> factor(physicalFaceGramInverse[f]);
            if(factor.info()!=Eigen::Success)throw std::runtime_error("physical face stabilization factor failed");
            stabilizationFactor.block(3*f,3*f,3,3)=std::sqrt(density*h)*Mat(factor.matrixL()).transpose();
        }
        const unsigned mean=reference.MeanOffset(),angular=reference.AngularOffset();
        stabilizationFactor.block(mean,mean,3,3)=std::sqrt(density/physicalVolume)*frame.J;
        stabilizationFactor.block(angular,mean,3,3)=std::sqrt(density/(physicalVolume*h*h))*frame.offsetCrossJ;
        stabilizationFactor.block(angular,angular,3,3)=std::sqrt(density/(physicalVolume*h*h))*frame.cofactor;
        Eigen::Matrix<Real,4,4> scalarGram;
        for(unsigned a=0;a<4;++a)for(unsigned b=0;b<4;++b)
            scalarGram(a,b)=referenceGeometry.volume[vm::ProductIndex(a,b)]/physicalVolume;
        Eigen::LLT<Eigen::Matrix<Real,4,4>> scalarFactor(scalarGram);
        if(scalarFactor.info()!=Eigen::Success)throw std::runtime_error("bounded reference polynomial factor failed");
        consistentPolynomialFactor=Matrix::Zero(12,12);
        for(unsigned a=0;a<3;++a) {
            const Real lengthSquared=frame.squaredLengths[a].convert_to<Real>();
            consistentPolynomialFactor.block(4*a,4*a,4,4)=std::sqrt(density*physicalVolume*lengthSquared)
                *Eigen::Matrix<Real,4,4>(scalarFactor.matrixL()).transpose();
        }
        kineticFactor.resize(12+d,d);
        kineticFactor.topRows(12)=consistentPolynomialFactor*reference.projection;
        kineticFactor.bottomRows(d)=stabilizationFactor*(Matrix::Identity(d,d)-reference.polynomialDofs*reference.projection);
    }

    // Physical input value is at this frame's EXACT vertex origin. Gradient is
    // world-space dv_a/dx_b. The returned DOFs are reference means/angular
    // moments and the ORIGINAL physical integrated face fluxes.
    Vector InterpolatePhysicalAffine(const Vec& valueAtFrameOrigin,const Mat& worldGradient) const {
        Affine coefficients;
        const Vec value=frame.inverse*valueAtFrameOrigin;
        const Mat gradient=frame.inverse*worldGradient*frame.J;
        for(unsigned a=0;a<3;++a){coefficients(4*a)=value(a);for(unsigned b=0;b<3;++b)coefficients(4*a+b+1)=gradient(a,b);}
        return reference.InterpolateAffineDOFs(coefficients);
    }

    Affine ReferenceProjection(const Vector& dofs) const{return reference.Project(dofs);}
    Vec EvaluateProjectedPhysical(const Vector& dofs,const RV& exactWorldPoint) const {
        return frame.J*vm::EvaluateAffine(ReferenceProjection(dofs),frame.CoordinatesReal(exactWorldPoint));
    }
    Real PhysicalNormal(unsigned face,const Vector& dofs,const RV& exactWorldPoint) const {
        const auto p=faces.at(face).Factors(exactWorldPoint);
        const Vec coefficients=physicalFaceGramInverse.at(face)*dofs.template segment<3>(3*face);
        return Vec(p[0],p[1],p[2]).dot(coefficients);
    }
    Moments PhysicalMoments(const Vector& dofs) const {
        const Vector b=reference.momentOperator*dofs;
        Vec mean;Mat first;
        for(unsigned a=0;a<3;++a){mean(a)=b(4*a);for(unsigned j=0;j<3;++j)first(a,j)=b(4*a+j+1);}
        Moments result;result.mean=frame.J*mean;
        result.first=frame.J*first*frame.J.transpose()+result.mean*Rounded(frame.offset).transpose();
        return result;
    }
    Vector Coordinates(const Vector& dofs) const {
        const Affine projected=ReferenceProjection(dofs);
        Vector result(12+dofs.size());
        result.head(12)=consistentPolynomialFactor*projected;
        result.tail(dofs.size())=stabilizationFactor*(dofs-reference.polynomialDofs*projected);
        return result;
    }
    Real Energy(const Vector& dofs) const{return Coordinates(dofs).squaredNorm()/2;}
    Real Inner(const Vector& a,const Vector& b) const{return Coordinates(a).dot(Coordinates(b));}
    // Primary source representation is in positive kinetic coordinates. A raw
    // adjoint vector followed by an ill-conditioned dot product can discard a
    // tiny physical work even though its factored representation is accurate.
    Vector PredictorCoordinates(const Vector& predictor) const{return Coordinates(predictor);}
    Real SourceWork(const Vector& candidate,const Vector& predictorCoordinates) const {
        return Coordinates(candidate).dot(predictorCoordinates);
    }
    Vector DebugRawSourceFromPredictor(const Vector& predictor) const{return kineticFactor.transpose()*Coordinates(predictor);}
    Real MeanDivergence(const Vector& dofs) const{return (reference.divergenceMoments*dofs)(0)/physicalVolume;}
    Real ProjectedDivergence(const Vector& dofs,const RV& exactWorldPoint) const {
        Eigen::Matrix<Real,4,1> p;const Vec xi=frame.CoordinatesReal(exactWorldPoint);p<<1,xi.x(),xi.y(),xi.z();
        return reference.Divergence(dofs).dot(p);
    }
};

} // namespace stage17_framed
