#include "FramedCell.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace fr=stage17_framed;
using fr::R;using fr::RV;using fr::Real;using fr::Vec;using fr::Mat;
struct Field {RV value{};fr::ExactMatrix gradient{};};
RV ExactValue(const Field& field,const RV& point){return fr::Add(field.value,fr::ExactApply(field.gradient,point));}
Mat Gradient(const Field& field){Mat a;for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)a(i,j)=field.gradient[i][j].convert_to<Real>();return a;}

Real ExactInner(const convex_ports::Cell& cell,const Field& a,const Field& b){
    Real total=0;
    for(const auto& simplex:cell.integration){
        Vec sumA=Vec::Zero(),sumB=Vec::Zero();Real diagonal=0;
        for(const auto& point:simplex.points){const Vec x=fr::Rounded(ExactValue(a,point)),y=fr::Rounded(ExactValue(b,point));sumA+=x;sumB+=y;diagonal+=x.dot(y);}
        total+=1000*simplex.volume.convert_to<Real>()*(sumA.dot(sumB)+diagonal)/20;
    }
    return total;
}

int main(){setvbuf(stdout,nullptr,_IOLBF,0);unsigned checks=0,failures=0;auto check=[&](bool p,const char* label){++checks;if(!p){++failures;printf("FAIL %s\n",label);}};try{
    using V=glm::dvec3;
    Real maximumVelocity=0,maximumMass=0,maximumWork=0,minimumVolume=1;
    for(double angle:{0.,.17,3.2137858346770188e-11}){
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
        convex_ports::Compiler geometry;geometry.Build(1,box);
        unsigned thin=0;
        for(const auto& source:geometry.cells){
            fr::Cell cell(source);
            minimumVolume=std::min(minimumVolume,cell.physicalVolume);thin+=cell.physicalVolume<1e-15L;
            std::vector<Field> fields;
            for(unsigned a=0;a<3;++a){Field f;f.value[a]=R(1)/10;fields.push_back(f);}
            for(unsigned trial=0;trial<12;++trial){Field f;for(unsigned a=0;a<3;++a){f.value[a]=R(int((trial+2*a)%7)-3)/17;for(unsigned b=0;b<3;++b)f.gradient[a][b]=R(int((3*trial+2*a+b)%9)-4)/19;}fields.push_back(f);}
            std::set<RV> points;
            for(const auto& simplex:source.integration)points.insert(simplex.points.begin(),simplex.points.end());
            for(const auto& field:fields){
                const auto dofs=cell.InterpolatePhysicalAffine(fr::Rounded(ExactValue(field,cell.frame.origin)),Gradient(field));
                for(const auto& point:points){const Real error=(cell.EvaluateProjectedPhysical(dofs,point)-fr::Rounded(ExactValue(field,point))).norm();maximumVelocity=std::max(maximumVelocity,error);check(error<1e-8L,"projected physical affine velocity at exact owned point");}
                const Real expected=ExactInner(source,field,field)/2,actual=cell.Energy(dofs);
                const Real relative=std::abs(actual-expected)/std::max(expected,cell.physicalVolume*1e-30L);
                maximumMass=std::max(maximumMass,relative);check(relative<1e-8L,"physical polynomial kinetic energy via positive reference factor");
                const Field& other=fields[(checks+3)%fields.size()];
                const auto otherDofs=cell.InterpolatePhysicalAffine(fr::Rounded(ExactValue(other,cell.frame.origin)),Gradient(other));
                const Real expectedWork=ExactInner(source,field,other);
                const Real work=cell.SourceWork(dofs,cell.PredictorCoordinates(otherDofs));
                const Real relativeWork=std::abs(work-expectedWork)/std::max(cell.physicalVolume*1e-4L,std::abs(expectedWork));
                maximumWork=std::max(maximumWork,relativeWork);check(relativeWork<1e-8L,"physical affine predictor work in positive kinetic coordinates");
            }
        }
        printf("FRAMED_LOCAL angle=%.17g cells=%zu thin=%u velocity=%Lg energy_relative=%Lg source_work=%Lg\n",angle,geometry.cells.size(),thin,maximumVelocity,maximumMass,maximumWork);
    }
    printf("FRAMED_SUMMARY checks=%u failures=%u velocity=%Lg energy_relative=%Lg source_work=%Lg min_volume=%Lg\n",checks,failures,maximumVelocity,maximumMass,maximumWork,minimumVolume);return failures?1:0;
}catch(const std::exception& error){fprintf(stderr,"ERROR after%uchecks %s\n",checks,error.what());return 1;}}
