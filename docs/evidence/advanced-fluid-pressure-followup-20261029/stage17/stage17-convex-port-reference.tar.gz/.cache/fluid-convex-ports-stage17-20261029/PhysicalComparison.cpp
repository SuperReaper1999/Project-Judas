#include "Network.h"
#include "../fluid-runtime-candidates-stage16-20261029/runtime/FaceEpoch.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{using V=glm::dvec3;namespace net=stage17_network;namespace old=stage16_runtime;
 for(double angle:{0.,.17}){const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));auto t=net::Clock::now();net::Epoch split(1,box,1,net::Boundary::Sealed);double build=net::Milliseconds(t);old::Epoch merged(1,box);
  for(unsigned scenario=0;scenario<3;++scenario){net::Twist body=net::Twist::Zero();if(scenario==1)body<<.01,-.02,.03,0,0,0;if(scenario==2)body<<.01,-.02,.03,.02,.03,-.01;const net::vm::Vec3 source=scenario?net::vm::Vec3::Zero():net::vm::Vec3(0,-.04,0);const auto a=split.Solve(split.Constant(source),body);const auto b=merged.Solve(merged.Constant(source),body);long double poly=0;for(unsigned c=0;c<split.cells.size();++c){const auto& op=split.cells[c]->op;auto p=op.Project(a.local[c]);poly+=op.geometry.density*p.dot(op.polynomialGram*p)/2;}
   printf("CONVEX_PHYSICAL angle=%g scenario=%u cells=%zu variables=%ld build_ms=%g warm_ms=%g split_energy=%Lg merged_energy=%Lg affine=%Lg complement=%Lg force=%Lg,%Lg,%Lg balance=%Lg work=%Lg\n",angle,scenario,split.cells.size(),long(split.mass.rows()),build,a.solveMs,a.energy,b.energy,poly,a.energy-poly,a.reaction[0],a.reaction[1],a.reaction[2],a.balance,a.energyIdentity);}
 }
 return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
