#include "ResolvedCell.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace rs=stage17_resolved;namespace fr=stage17_framed;
using fr::R;using fr::RV;using fr::Real;using fr::Vec;using fr::Mat;
struct Field {RV value{};fr::ExactMatrix gradient{};};
RV Value(const Field& f,const RV& p){return fr::Add(f.value,fr::ExactApply(f.gradient,p));}
Mat Gradient(const Field& f){Mat a;for(unsigned i=0;i<3;++i)for(unsigned j=0;j<3;++j)a(i,j)=f.gradient[i][j].convert_to<Real>();return a;}
Real ExpectedInner(const convex_ports::Cell& c,const Field& a,const Field& b){Real total=0;for(const auto& t:c.integration){Vec sa=Vec::Zero(),sb=Vec::Zero();Real diagonal=0;for(const auto& p:t.points){const Vec x=fr::Rounded(Value(a,p)),y=fr::Rounded(Value(b,p));sa+=x;sb+=y;diagonal+=x.dot(y);}total+=1000*t.volume.convert_to<Real>()*(sa.dot(sb)+diagonal)/20;}return total;}

int main(){setvbuf(stdout,nullptr,_IOLBF,0);unsigned checks=0,failures=0;auto check=[&](bool pass,const char* label){++checks;if(!pass){++failures;printf("FAIL %s\n",label);}};try{
    using V=glm::dvec3;
    Real maxVelocity=0,maxEnergy=0,maxWork=0,maxNormal=0,maxCongruence=0,maxNull=0,maxKernelMass=0,maxKernelLeak=0,minSingular=1;
    for(double angle:{0.,.17,3.2137858346770188e-11}){
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));convex_ports::Compiler geometry;geometry.Build(1,box);
        for(const auto& source:geometry.cells){
            rs::Cell cell(source);const Real volume=cell.framed.physicalVolume;
            maxNull=std::max(maxNull,cell.nullResidual);maxKernelMass=std::max(maxKernelMass,cell.kernelMassError);
            maxKernelLeak=std::max(maxKernelLeak,cell.kernelPolynomialLeak.cwiseAbs().maxCoeff());minSingular=std::min(minSingular,cell.constraintSingularRatio);
            check(cell.nullResidual<1e-12L,"six symmetric reference moment kernel constraints");
            check(cell.kernelMassError<1e-12L,"normalized kernel retains original physical face stabilization metric");
            check(cell.kernelPolynomialLeak.cwiseAbs().maxCoeff()<1e-8L,"nominal kernel carries no spurious physical polynomial kinetic energy");
            std::vector<Field> fields;for(unsigned a=0;a<3;++a){Field f;f.value[a]=R(1)/10;fields.push_back(f);}
            for(unsigned trial=0;trial<12;++trial){Field f;for(unsigned a=0;a<3;++a){f.value[a]=R(int((trial+2*a)%7)-3)/17;for(unsigned b=0;b<3;++b)f.gradient[a][b]=R(int((3*trial+2*a+b)%9)-4)/19;}fields.push_back(f);}
            std::set<RV> points;for(const auto& t:source.integration)points.insert(t.points.begin(),t.points.end());
            for(const auto& field:fields){
                const auto state=cell.PhysicalAffine(fr::Rounded(Value(field,cell.framed.frame.origin)),Gradient(field));
                for(const auto& p:points){const Real error=(cell.EvaluateProjectedPhysical(state,p)-fr::Rounded(Value(field,p))).norm();maxVelocity=std::max(maxVelocity,error);check(error<1e-8L,"resolved physical affine velocity at exact owned point");}
                const Real expected=ExpectedInner(source,field,field)/2,energy=cell.Energy(state);const Real relative=std::abs(energy-expected)/std::max(expected,volume*1e-30L);maxEnergy=std::max(maxEnergy,relative);check(relative<1e-8L,"resolved physical polynomial energy without raw DOF reconstruction");
                const Field& other=fields[(checks+3)%fields.size()];const auto second=cell.PhysicalAffine(fr::Rounded(Value(other,cell.framed.frame.origin)),Gradient(other));
                const Real expectedWork=ExpectedInner(source,field,other),work=cell.SourceWork(state,cell.PredictorCoordinates(second));const Real error=std::abs(work-expectedWork)/std::max(volume*1e-4L,std::abs(expectedWork));maxWork=std::max(maxWork,error);check(error<1e-8L,"resolved physical source work with independent exact-point mass integral");
                for(unsigned f=0;f<source.faces.size();++f)for(const auto& t:source.faces[f].triangles)for(const auto& p:t.points){const Real normal=cell.PhysicalNormal(f,state,p),expectedNormal=cell.framed.physicalNormals[f].dot(fr::Rounded(Value(field,p)));const Real e=std::abs(normal-expectedNormal);maxNormal=std::max(maxNormal,e);check(e<1e-8L,"resolved primary physical face normal trace");}
            }
            if(angle!=3.2137858346770188e-11){
                for(unsigned trial=0;trial<2;++trial){fr::Vector raw(cell.framed.reference.dimension);for(Eigen::Index j=0;j<raw.size();++j)raw(j)=volume*Real(int((13*j+7*trial)%19)-9)/100;
                    const auto state=cell.DebugFromReferenceDOFs(raw);const Real before=cell.framed.Energy(raw),after=cell.Energy(state),relative=std::abs(after-before)/std::max(before,volume*1e-20L);maxCongruence=std::max(maxCongruence,relative);check(relative<1e-10L,"ordinary arbitrary-state exact chosen-metric congruence including original stabilization");
                    const Real faceError=(cell.FaceFlux(state)-raw.head(cell.faceDimension)).norm()/std::max(volume,raw.head(cell.faceDimension).norm());check(faceError<1e-10L,"ordinary arbitrary-state primary face flux reconstruction");
                }
            }
        }
        printf("RESOLVED_CELL angle=%.17g cells=%zu velocity=%Lg energy=%Lg work=%Lg normal=%Lg congruence=%Lg null=%Lg kernel_mass=%Lg kernel_leak=%Lg min_singular_ratio=%Lg\n",angle,geometry.cells.size(),maxVelocity,maxEnergy,maxWork,maxNormal,maxCongruence,maxNull,maxKernelMass,maxKernelLeak,minSingular);
    }
    printf("RESOLVED_SUMMARY checks=%u failures=%u velocity=%Lg energy=%Lg work=%Lg normal=%Lg congruence=%Lg null=%Lg kernel_mass=%Lg kernel_leak=%Lg min_singular_ratio=%Lg\n",checks,failures,maxVelocity,maxEnergy,maxWork,maxNormal,maxCongruence,maxNull,maxKernelMass,maxKernelLeak,minSingular);return failures?1:0;
}catch(const std::exception& error){fprintf(stderr,"ERROR after%uchecks %s\n",checks,error.what());return 1;}}
