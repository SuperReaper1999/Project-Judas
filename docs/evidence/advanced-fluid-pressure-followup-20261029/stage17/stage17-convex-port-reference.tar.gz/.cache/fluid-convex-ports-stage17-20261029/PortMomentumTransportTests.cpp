#include "PortMomentumTransport.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace port_momentum;
unsigned checks=0;
void Check(bool pass,const char* text){++checks;if(!pass)throw std::runtime_error(text);}
Real MeanEnergy(const World& w,const std::vector<Vector>& raw){Real total=0;for(unsigned c=0;c<w.cells.size();++c){const auto& local=*w.cells[c];vm::Vec3 mean;for(unsigned a=0;a<3;++a)mean[a]=raw[c][local.op.MeanOffset()+a]/local.op.geometry.volume[0];total+=local.op.geometry.density*local.op.geometry.volume[0]*mean.squaredNorm()/2;}return total;}
// Independent closed-form integral of a positive affine scalar on a triangle.
// No polygon clipping, vertex-walk or packet accumulation helper is reused.
R PositiveTriangle(const R& area,std::array<R,3> f) {
    std::sort(f.begin(),f.end());
    if(f[2]<=0)return R(0);
    if(f[0]>=0)return area*(f[0]+f[1]+f[2])/3;
    if(f[1]<=0)return area*f[2]*f[2]*f[2]/(3*(f[2]-f[0])*(f[2]-f[1]));
    return area*(f[0]+f[1]+f[2])/3+area*(-f[0])*(-f[0])*(-f[0])/(3*(f[1]-f[0])*(f[2]-f[0]));
}
std::array<R,2> OracleDirected(const Face& face,const std::array<R,3>& q) {
    const auto coeff=face.Coefficients(q);std::array<R,2> result{};
    for(const auto& t:face.triangles){std::array<R,3> values;for(unsigned i=0;i<3;++i)values[i]=face.Value(t.points[i],coeff);const R area=abs(t.areaVector[face.pivot]);result[0]+=PositiveTriangle(area,values);for(auto& value:values)value=-value;result[1]+=PositiveTriangle(area,values);}return result;
}
vm::Vec3 AngularMoment(const World& world,const std::vector<Vector>& raw) {
    vm::Vec3 total=vm::Vec3::Zero();
    for(unsigned c=0;c<world.cells.size();++c){const auto& cell=*world.cells[c];vm::Vec3 center,mean,local;for(unsigned a=0;a<3;++a){center[a]=cell.cell.center[a].convert_to<Real>();mean[a]=raw[c][cell.op.MeanOffset()+a];local[a]=raw[c][cell.op.AngularOffset()+a];}total+=cell.op.geometry.density*(center.cross(mean)+local);}return total;
}
void OneStepOracle(const Transport& transport,const State& state) {
    const auto& world=transport.world;const R dt=R(1)/240;
    std::vector<RV> impulse(world.cells.size());
    for(const auto& face:transport.ports){const std::array<R,3> q={state.exactFaceMeans[face.a][face.fa],R(state.local[face.a][3*face.fa+1]),R(state.local[face.a][3*face.fa+2])};const auto flux=OracleDirected(face,q);Check(flux==face.Directed(q),"exact clipped counterflow disagrees with independent closed-form affine integration");for(unsigned direction=0;direction<2;++direction){const unsigned a=direction?face.b:face.a,b=direction?face.a:face.b;const auto& cell=*world.cells[a];for(unsigned axis=0;axis<3;++axis){const R mean=R(state.local[a][cell.op.MeanOffset()+axis]/cell.op.geometry.volume[0]);const R dp=dt*flux[direction]*R(cell.op.geometry.density)*mean;impulse[a][axis]-=dp;impulse[b][axis]+=dp;}}}
    const auto actual=transport.Apply(state,dt);Real largestChange=0,error=0;vm::Vec3 angularPrediction=vm::Vec3::Zero();
    for(unsigned c=0;c<world.cells.size();++c){const auto& cell=*world.cells[c];vm::Vec3 centroid,dp;for(unsigned axis=0;axis<3;++axis){const Real before=state.local[c][cell.op.MeanOffset()+axis]/cell.op.geometry.volume[0];const Real change=(impulse[c][axis]/(R(cell.op.geometry.density)*cell.cell.exactVolume)).convert_to<Real>();const Real next=actual.raw[c][cell.op.MeanOffset()+axis]/cell.op.geometry.volume[0];largestChange=std::max(largestChange,std::abs(change));error=std::max(error,std::abs(next-before-change));centroid[axis]=cell.cell.center[axis].convert_to<Real>()+cell.op.geometry.volume[axis+1]/cell.op.geometry.volume[0];dp[axis]=impulse[c][axis].convert_to<Real>();}angularPrediction+=centroid.cross(dp);}
    Check(largestChange>1e-9L,"advection oracle must exercise an actual nonzero mean update; a no-op must fail");Check(error<1e-12L,"actual mean update disagrees with independent paired-momentum oracle");
    const auto actualAngular=(AngularMoment(world,actual.raw)-AngularMoment(world,state.local)).eval();Check((actualAngular-angularPrediction).norm()<1e-12L,"angular diagnostic disagrees with independent mean-only transport model");
    printf("MOMENTUM_INDEPENDENT_ORACLE max_mean_change=%Lg mean_update_error=%Lg actual_angular_change=%Lg angular_diagnostic_error=%Lg limitation=mean_only_transport_does_not_conserve_angular_momentum\n",largestChange,error,actualAngular.norm(),(actualAngular-angularPrediction).norm());
}
int main(){setvbuf(stdout,nullptr,_IOLBF,0);try{
 using V=glm::dvec3;const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::dquat(1,0,0,0));stage17_voxel_conservative::Epoch world(1,box);
 Transport transport(world);auto predictor=world.Constant(vm::Vec3::Zero());const vm::Vec3 omega(.12,.09,-.17);
 for(unsigned c=0;c<world.cells.size();++c){vm::Vec3 center;for(unsigned a=0;a<3;++a)center[a]=world.cells[c]->cell.center[a].convert_to<Real>()-.5L;predictor[c]=vm::RigidAffine(omega.cross(center),omega);}
 auto state=world.Solve(predictor);const Real initial=state.energy;Check(initial>1e-5L,"actual fixed-tank vortex must have nonzero retained flow");Check(!transport.ports.empty(),"actual fixed tank must contain connected physical fluid ports");
 // Independent exact magnitude oracle: square [-1,1]^2, trace=x.
 Face square=transport.ports.front();square.pivot=2;square.geometry.frame={};square.geometry.frame.edge={R(1),R(0),R(0)};square.geometry.frame.transverse={R(0),R(1),R(0)};square.geometry.frame.spanU=1;square.geometry.frame.spanV=1;
 square.gram={{{R(4),R(0),R(0)},{R(0),R(4)/3,R(0)},{R(0),R(0),R(4)/3}}};
 const RV a={R(-1),R(-1),R(0)},b={R(1),R(-1),R(0)},c={R(1),R(1),R(0)},d={R(-1),R(1),R(0)};
 square.triangles={{{a,b,c},{R(0),R(0),R(2)},0},{{a,c,d},{R(0),R(0),R(2)},0}};
 Check(square.Directed({R(0),R(4)/3,R(0)})==std::array<R,2>{R(1),R(1)},"known square trace x must exchange exactly one cubic metre per second in each direction");
 Check(square.Directed({R(2),R(0),R(0)})==std::array<R,2>{R(2),R(0)},"known positive constant trace has independently correct absolute flux");
 Check(square.Directed({R(-2),R(0),R(0)})==std::array<R,2>{R(0),R(2)},"reversing the constant primary trace swaps exact directed flow");
 const auto& port=transport.ports.front();const auto counter=port.Directed({R(0),R(1)/100,R(0)});Check(counter[0]==counter[1]&&counter[0]>0,"zero-net primary port must retain actual bidirectional material exchange");
 const auto oracleCounter=OracleDirected(port,{R(0),R(1)/100,R(0)});Check(counter==oracleCounter,"zero-net counterflow has the independently correct absolute magnitude");
 OneStepOracle(transport,state);
 auto malformed=state;malformed.exactFaceMeans[0].clear();bool malformedRejected=false;try{transport.Apply(malformed,R(1)/240);}catch(const std::invalid_argument&){malformedRejected=true;}Check(malformedRejected,"malformed inner primary-face state must be rejected before indexing");
 const auto old=state.local;bool rejected=false;try{transport.Apply(state,R(1000000));}catch(const std::invalid_argument& error){rejected=std::string(error.what()).find("donor availability")!=std::string::npos;}
 Check(rejected,"oversized actual outflow must be rejected without a clamp or hidden substep");for(unsigned c=0;c<old.size();++c)Check((old[c]-state.local[c]).squaredNorm()==0,"failed transport must not publish partial kinetic state");
 Real maximumMomentumError=0,maximumEnergyIncrease=0,maximumFluctuationError=0,maximumDivergence=0;
 unsigned packets=0;const auto begin=Clock::now();
 for(unsigned step=0;step<240;++step){const auto transported=transport.Apply(state,R(1)/240);Check(transported.exactTransportImpulse==RV{},"actual paired packets create momentum");maximumMomentumError=std::max(maximumMomentumError,transported.momentumError);maximumEnergyIncrease=std::max(maximumEnergyIncrease,transported.energyAfter-transported.energyBefore);
  const Real fluctuation=std::abs((transported.energyAfter-MeanEnergy(world,transported.raw))-(transported.energyBefore-MeanEnergy(world,state.local)));maximumFluctuationError=std::max(maximumFluctuationError,fluctuation);Check(fluctuation<1e-12L,"mean advection unexpectedly discards complementary or resolved local kinetic modes");
  const auto next=world.SolveRaw(transported.raw);Check(next.energy<=transported.energyAfter+1e-12L,"closed stationary pressure step creates energy after actual momentum advection");Check(next.exactTotalMean==0,"actual pressure/advection cycle changes conserved capacity");
  for(unsigned c=0;c<world.cells.size();++c){const auto& local=*world.cells[c];for(const auto& face:local.cell.faces)for(const auto& triangle:face.triangles)for(const auto& exact:triangle.points){vm::Vec3 r;for(unsigned a=0;a<3;++a)r[a]=exact[a].convert_to<Real>();Eigen::Matrix<Real,4,1> p;p<<1,r[0],r[1],r[2];maximumDivergence=std::max(maximumDivergence,std::abs(local.op.Divergence(next.local[c]).dot(p)));}}
  packets+=transported.directedPackets;state=next;
  if(step%60==59)printf("MOMENTUM_CYCLE step=%u energy=%Lg retained=%Lg momentum_error=%Lg mean_transport_increase=%Lg fluctuation_error=%Lg point_div=%Lg directed_packets=%u\n",step+1,state.energy,state.energy/initial,maximumMomentumError,maximumEnergyIncrease,maximumFluctuationError,maximumDivergence,packets);
 }
 Check(maximumMomentumError<1e-12L,"material advection creates actual kinetic-field momentum");Check(maximumEnergyIncrease<1e-12L,"mean momentum advection creates actual kinetic energy");Check(maximumDivergence<1e-8L,"pressure cycle violates actual physical divergence");Check(state.energy>initial*1e-6L,"actual circulation was globally reset instead of evolved");Check(packets>240,"actual momentum transport did not exercise repeated directed exchange");
 printf("MOMENTUM_TRANSPORT_SUMMARY checks=%u failures=0 elapsed_ms=%g initial_energy=%Lg final_energy=%Lg scope=fixed_geometry_mean_linear_momentum_actual_P1_counterflow_angular_not_conserved\n",checks,Milliseconds(begin),initial,state.energy);return 0;
}catch(const std::exception& error){fprintf(stderr,"FAIL after%uchecks %s\n",checks,error.what());return 1;}}
