#include "ConservativeCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace baseline=stage17_condensed;
namespace conservative=stage17_conservative_network;
using namespace stage17_network;
unsigned checks=0;
void Check(bool condition,const char* message) {
    ++checks;if(!condition) throw std::runtime_error(message);
}
int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        for(double angle:{0.,.17,3.2137858346770188e-11}) {
            const auto box=owned_cut::BoxPlanes(V(.5),V(.2),
                glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
            baseline::Epoch reference(1,box);
            conservative::Epoch candidate(reference);
            for(unsigned scenario=0;scenario<3;++scenario) {
                auto source=reference.Constant(scenario?vm::Vec3::Zero():vm::Vec3(0,-.04L,0));
                if(scenario==2) for(unsigned cell=0;cell<source.size();++cell) {
                    source[cell][0]=.001L*(1+reference.cells[cell]->cell.seed+3*reference.cells[cell]->cell.piece);
                    source[cell][3]=.015L;source[cell][6]=-.01L;source[cell][9]=.012L;
                }
                Twist body=Twist::Zero();if(scenario==1) body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
                const auto old=reference.Solve(source,body);
                const auto next=candidate.Solve(source,body);
                Real field=0;
                for(unsigned cell=0;cell<reference.cells.size();++cell) {
                    const Vector difference=old.local[cell]-next.local[cell];
                    const auto& h=reference.cells[cell]->op.mass;
                    field=std::max(field,std::sqrt(std::abs(difference.dot(h*difference)))/
                        std::max<Real>(1,std::sqrt(std::abs(old.local[cell].dot(h*old.local[cell])))));
                }
                const Real energy=std::abs(old.energy-next.energy)/std::max<Real>(1,old.energy);
                const Real wrench=(old.reaction-next.reaction).norm()/std::max<Real>(1,old.reaction.norm());
                Check(field<1e-10L,"conservative global parameterization changes physical kinetic endpoints");
                Check(energy<1e-10L,"conservative global parameterization changes physical energy");
                Check(wrench<1e-10L,"conservative global parameterization changes actual native wrench");
                Check(next.energyIdentity<1e-10L&&next.objectiveReconstructionError<1e-10L,
                      "conservative global source/work identity fails");
                Check(next.exactTotalMean==0,"sealed conservative state creates total mean volume");
                for(const auto& [key,port]:candidate.allPorts) {
                    if(port.secondCell==~0u) continue;
                    Check(next.exactFaceMeans[port.firstCell][port.firstFace]+
                          next.exactFaceMeans[port.secondCell][port.secondFace]==0,
                          "opposite physical primary means do not cancel exactly");
                }
                unsigned exactNonroots=0;
                for(const auto& coordinates:candidate.conservative)
                    for(unsigned piece=0;piece<coordinates.pieces.size();++piece) if(piece!=coordinates.root) {
                        Check(next.exactMeanSums[coordinates.pieces[piece].cell]==0,
                              "global solve loses exact non-root cell closure");++exactNonroots;
                    }
                printf("CONSERVATIVE_NETWORK angle=%.17g scenario=%u cells=%zu exact_nonroots=%u energy=%Lg field_error=%Lg energy_error=%Lg native_wrench_error=%Lg max_root_mean_div=%Lg work=%Lg global_exact_mean=0 solve_ms=%g\n",
                    angle,scenario,candidate.cells.size(),exactNonroots,next.energy,field,energy,wrench,
                    next.maximumRootMeanDivergence,next.energyIdentity,next.solveMs);
            }
            const auto zero=candidate.Solve(candidate.Constant(vm::Vec3::Zero()));
            Check(zero.energy==0&&zero.reaction.norm()==0&&zero.exactTotalMean==0,
                  "conservative zero source invents physical or mean state");
            auto invalid=candidate.Constant(vm::Vec3::Zero());invalid[0][0]=NAN;
            bool rejected=false;
            try { candidate.Solve(invalid); } catch(const std::invalid_argument&) { rejected=true; }
            Check(rejected&&candidate.Solve(candidate.Constant(vm::Vec3::Zero())).energy==0,
                  "invalid conservative transaction changes prepared state");
        }
        const auto slab=owned_cut::BoxPlanes(V(.5),V(.1,2,2),glm::dquat(1,0,0,0));
        conservative::Epoch divided(1,slab);
        Check(divided.components.size()==2,"conservative graph joins disconnected water");
        Twist entering=Twist::Zero();entering[0]=.1L;
        bool rejected=false;
        try { divided.Solve(divided.Constant(vm::Vec3::Zero()),entering); }
        catch(const std::invalid_argument&) { rejected=true; }
        Check(rejected,"exact component volume incompatibility was silently accepted");
        printf("CONSERVATIVE_NETWORK_SUMMARY checks=%u failures=0\n",checks);return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
