#pragma once

// PRIVATE, face-order-equivariant voxel partition. For the original native
// affine face functions fi=ni.x-di, physical region i is
// voxel AND fi>=0 AND fi>=fj for every j. Exact rational difference planes are
// essential: rounding ni-nj can break comparison transitivity and leave gaps.
// Native solids and all original binary64 coefficients remain unchanged.
#include "ConvexPorts.h"
#include "ExactConvexClip.h"

namespace symmetric_voxel_ports {
namespace ec=exact_convex;
using R=convex_ports::R;using RV=convex_ports::RV;using Box=convex_ports::Box;
using Lattice=convex_ports::Lattice;using Kind=convex_ports::Kind;using Key=convex_ports::PortKey;

struct Compiler : convex_ports::Compiler {
    struct Background {unsigned plane=~0u;std::array<Lattice,3> key{};};
    static ec::Polyhedron Cube(unsigned n,unsigned voxel,std::vector<ec::Plane>& planes,std::vector<Background>& background){
        const unsigned xyz[3]={voxel%n,(voxel/n)%n,voxel/(n*n)};
        std::array<RV,8> points;for(unsigned mask=0;mask<8;++mask)for(unsigned a=0;a<3;++a)points[mask][a]=R(xyz[a]+((mask>>a)&1));
        ec::Polyhedron cube;
        for(unsigned axis=0;axis<3;++axis)for(unsigned side=0;side<2;++side){
            const unsigned u=(axis+1)%3,v=(axis+2)%3,base=side<<axis;
            ec::Plane plane;plane.normal[axis]=side?1:-1;plane.coordinate=plane.normal[axis]*R(xyz[axis]+side);
            const unsigned id=planes.size();planes.push_back(plane);
            ec::Face face{id,{points[base],points[base|(1u<<u)],points[base|(1u<<u)|(1u<<v)],points[base|(1u<<v)]}};
            if(!side)std::reverse(face.vertices.begin(),face.vertices.end());cube.faces.push_back(std::move(face));
            Lattice ll={int(xyz[0]),int(xyz[1]),int(xyz[2])};ll[axis]+=side;auto hl=ll,lh=ll;++hl[u];++lh[v];Background bg{id,{ll,hl,lh}};std::sort(bg.key.begin(),bg.key.end());background.push_back(std::move(bg));
        }
        return cube;
    }
    void BuildVoxel(unsigned n,unsigned voxel,const Box& definition){
        std::vector<ec::Plane> planes;
        for(const auto& source:definition){ec::Plane plane;for(unsigned a=0;a<3;++a)plane.normal[a]=R(source.normal[a]);plane.coordinate=R(source.coordinate);if(plane.normal==RV{})throw std::invalid_argument("symmetric partition native plane is invalid");planes.push_back(std::move(plane));}
        std::array<std::array<unsigned,6>,6> pair{};
        std::map<unsigned,std::pair<unsigned,unsigned>> pairOwner;
        for(unsigned i=0;i<6;++i)for(unsigned j=i+1;j<6;++j){const unsigned id=planes.size();ec::Plane difference{ec::Sub(planes[i].normal,planes[j].normal),planes[i].coordinate-planes[j].coordinate};if(difference.normal==RV{})throw std::invalid_argument("symmetric native faces have identical normals");planes.push_back(std::move(difference));pair[i][j]=pair[j][i]=id;pairOwner.emplace(id,std::make_pair(i,j));}
        std::vector<Background> background;const auto cube=Cube(n,voxel,planes,background);
        for(unsigned region=0;region<6;++region){
            auto poly=ec::Clip(cube,planes,region,-1);
            for(unsigned other=0;other<6 && !poly.faces.empty();++other)if(other!=region)
                poly=ec::Clip(poly,planes,pair[region][other],region<other?-1:1);
            if(poly.faces.empty())continue;
            convex_ports::Cell cell;cell.seed=voxel;cell.piece=region;
            const auto cones=ec::PositiveCones(poly);std::set<RV> vertices;
            for(const auto& simplex:cones){cell.integration.push_back({simplex.points,simplex.volume});cell.volume+=simplex.volume;vertices.insert(simplex.points.begin(),simplex.points.end());}
            RV low=*vertices.begin(),high=low;for(const auto& p:vertices)for(unsigned a=0;a<3;++a){low[a]=std::min(low[a],p[a]);high[a]=std::max(high[a],p[a]);}for(unsigned a=0;a<3;++a)cell.center[a]=(low[a]+high[a])/2;
            for(const auto& face:poly.faces){if(!ec::PositiveArea(face))continue;convex_ports::Face patch;patch.plane=face.plane;
                if(face.plane<6){if(face.plane!=region)throw std::runtime_error("symmetric physical region has an unowned native face");patch.kind=Kind::Solid;patch.solid=int(region);patch.key.seed=voxel;patch.key.first=region;patch.key.second=region;}
                else if(auto found=pairOwner.find(face.plane);found!=pairOwner.end()){patch.kind=Kind::Internal;patch.key.seed=voxel;patch.key.first=found->second.first;patch.key.second=found->second.second;}
                else{const auto bg=std::find_if(background.begin(),background.end(),[&](const Background& b){return b.plane==face.plane;});if(bg==background.end())throw std::runtime_error("symmetric physical face has no owner");
                    bool contact=true;for(const auto& p:face.vertices)contact&=ec::Side(p,planes[region])==0;
                    if(contact){if(owned_metrics::Dot(ec::AreaVector(face),planes[region].normal)>=0)throw std::runtime_error("symmetric coincident body contact normal is inconsistent");patch.kind=Kind::Solid;patch.solid=int(region);patch.plane=region;patch.key.seed=voxel;patch.key.first=region;patch.key.second=region;}
                    else{patch.kind=Kind::Background;patch.key.background=bg->key;unsigned label=region;
                        // If this entire BG plane is a dominance tie, the
                        // positive-volume owner can be i on one side and j on
                        // the other. Canonicalize the PORT, not the cells.
                        for(unsigned other=0;other<6;++other){bool tied=true;for(const auto& p:face.vertices)tied&=ec::Evaluate(p,planes[region])==ec::Evaluate(p,planes[other]);if(tied)label=std::min(label,other);}patch.key.exclusion=label;
                    }
                }
                patch.key.kind=patch.kind;
                for(const auto& triangle:ec::Triangulate(face))patch.triangles.push_back({triangle.points,triangle.areaVector,patch.plane});
                cell.faces.push_back(std::move(patch));
            }
            RV sum{};R enclosed=0;std::set<Key> unique;
            for(const auto& face:cell.faces){if(!unique.insert(face.key).second)throw std::runtime_error("symmetric physical cell has duplicate port identities");for(const auto& triangle:face.triangles){for(unsigned a=0;a<3;++a)sum[a]+=triangle.areaVector[a];enclosed+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;}}
            if(sum!=RV{} || enclosed!=cell.volume)throw std::runtime_error("symmetric physical cell is not exactly closed");cells.push_back(std::move(cell));
        }
    }
    void BuildSelected(unsigned n,const Box& definition,const std::vector<unsigned>& selected){if(grid||!cells.empty()||!n||n>8)throw std::invalid_argument("invalid/reused symmetric voxel compiler");grid=n;box=definition;std::set<unsigned> seen;for(unsigned voxel:selected){if(voxel>=n*n*n||!seen.insert(voxel).second)throw std::invalid_argument("invalid/duplicate symmetric voxel identifier");BuildVoxel(n,voxel,definition);}}
    void Build(unsigned n,const Box& definition){if(grid||!cells.empty()||!n||n>8)throw std::invalid_argument("invalid/reused symmetric voxel compiler");std::vector<unsigned> selected(n*n*n);std::iota(selected.begin(),selected.end(),0);BuildSelected(n,definition,selected);}
};
} // namespace symmetric_voxel_ports
