#include "ExactKernelBasis.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>

namespace kb=exact_kernel_basis;
namespace pa=port_acceptance;
namespace rc=stage17_resolved;
using R=pa::R;
using RV=pa::RV;
using Real=JudasFluidVem::Real;
using Coefficients=std::array<R,12>;
unsigned checks=0;
void Check(bool condition,const char* text) {++checks;if(!condition)throw std::runtime_error(text);}

RV Evaluate(const Coefficients& field,const RV& r) {
    RV result{};
    for(unsigned a=0;a<3;++a) {
        result[a]=field[4*a];
        for(unsigned b=0;b<3;++b) result[a]+=field[4*a+b+1]*r[b];
    }
    return result;
}

Real PolynomialControls(const convex_ports::Cell& input,const rc::Cell& cell) {
    std::vector<Coefficients> fields(15);
    for(unsigned i=0;i<12;++i) fields[i][i]=1;
    fields[12][7]=-1;fields[12][10]=1;
    fields[13][3]=1;fields[13][9]=-1;
    fields[14][2]=-1;fields[14][5]=1;
    pa::Moments volume{};
    std::set<RV> vertices;
    for(const auto& simplex:input.integration) {
        std::array<RV,4> local;
        for(unsigned i=0;i<4;++i) {local[i]=pa::Sub(simplex.points[i],input.center);vertices.insert(simplex.points[i]);}
        pa::Add(volume,pa::TetraP2(local));
    }
    Real maximum=0;
    for(const auto& field:fields) {
        rc::State state;state.kernel=JudasFluidVem::Vector::Zero(cell.kernelDimension);
        const auto atOrigin=Evaluate(field,cell.framed.frame.offset);
        for(unsigned a=0;a<3;++a) {
            state.polynomial[4*a]=atOrigin[a].convert_to<Real>();
            for(unsigned b=0;b<3;++b) {
                R coefficient=0;
                for(unsigned c=0;c<3;++c) coefficient+=field[4*a+c+1]*cell.framed.frame.columns[b][c];
                state.polynomial[4*a+b+1]=coefficient.convert_to<Real>();
            }
        }
        for(const auto& point:vertices) {
            const auto expected=Evaluate(field,pa::Sub(point,input.center));
            const auto actual=cell.EvaluateProjectedPhysical(state,point);
            Real error=0;
            for(unsigned a=0;a<3;++a) {const Real x=(R(actual[a])-expected[a]).convert_to<Real>();error+=x*x;}
            maximum=std::max(maximum,std::sqrt(error));
            Check(std::sqrt(error)<1e-8L,"retained physical polynomial point control failed");
        }
        R kinetic=0;
        for(unsigned a=0;a<3;++a)
            for(unsigned i=0;i<4;++i)
                for(unsigned j=0;j<4;++j)
                    kinetic+=1000*field[4*a+i]*field[4*a+j]*volume[JudasFluidVem::ProductIndex(i,j)];
        const Real expected=kinetic.convert_to<Real>()/2;
        Check(std::abs(cell.Energy(state)-expected)<1e-8L*expected,
              "retained physical polynomial kinetic control failed");
    }
    return maximum;
}

R PhysicalKernelEnergy(const rc::Cell& cell,const std::vector<R>& q) {
    R energy=0;
    for(unsigned row=0;row<q.size();++row) {
        R value=0;
        for(unsigned local=0;local<3;++local) {
            const unsigned col=3*(row/3)+local;
            value+=R(cell.faceRoot(row,col))*q[col];
        }
        energy+=value*value/2;
    }
    return energy;
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        const unsigned seed=argc>1?unsigned(std::strtoul(argv[1],nullptr,10)):0;
        const unsigned piece=argc>2?unsigned(std::strtoul(argv[2],nullptr,10)):3;
        const double angle=argc>3?std::strtod(argv[3],nullptr):3.2137858346770188e-11;
        using V=glm::dvec3;
        convex_ports::Compiler geometry;
        geometry.Build(1,owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))));
        const auto found=std::find_if(geometry.cells.begin(),geometry.cells.end(),[&](const auto& cell) {
            return cell.seed==seed && cell.piece==piece;
        });
        Check(found!=geometry.cells.end(),"requested physical cell does not exist");
        using Clock=std::chrono::steady_clock;
        auto begin=Clock::now();
        const rc::Cell cell(*found);
        const double resolvedMs=std::chrono::duration<double,std::milli>(Clock::now()-begin).count();
        begin=Clock::now();
        const exact_kernel::Oracle oracle(*found,cell.framed);
        const double oracleMs=std::chrono::duration<double,std::milli>(Clock::now()-begin).count();
        begin=Clock::now();
        const kb::Basis exact(cell,oracle);
        const double basisMs=std::chrono::duration<double,std::milli>(Clock::now()-begin).count();
        std::printf("EXACT_KERNEL_BUILD seed=%u piece=%u volume=%Lg rows=%u columns=%u "
                    "resolved_ms=%g exact_oracle_ms=%g exact_basis_ms=%g pivot_ratio=%Lg "
                    "max_original_CK=%Lg correction_S_column_norm=%Lg correction_S_frobenius=%Lg "
                    "original_factor_gram_error=%Lg corrected_factor_gram_error=%Lg\n",
                    seed,piece,found->volume.convert_to<Real>(),exact.rows,exact.columns,resolvedMs,oracleMs,basisMs,
                    exact.pivotRatio,exact.maxOriginalConstraint,exact.maxColumnCorrectionNorm,
                    exact.correctionFrobeniusNorm,exact.originalGramError,exact.correctedGramError);
        const auto pointError=PolynomialControls(*found,cell);
        for(unsigned scaling=0;scaling<2;++scaling) {
            JudasFluidVem::Vector coordinates(exact.columns);
            for(unsigned i=0;i<exact.columns;++i) coordinates[i]=(int(i%11)-5)/16.L;
            if(scaling) {
                const Real current=exact.EnergyExact(coordinates).convert_to<Real>();
                const Real target=1000*cell.framed.physicalVolume*.1L*.1L/2;
                coordinates*=std::sqrt(target/current);
            }
            std::vector<R> before(exact.rows,R(0));
            for(unsigned row=0;row<exact.rows;++row)
                for(unsigned column=0;column<exact.columns;++column)
                    before[row]+=exact.original[row][column]*R(coordinates[column]);
            const auto q=exact.Flux(coordinates);
            const R oldEnergy=PhysicalKernelEnergy(cell,before);
            const R newEnergy=exact.EnergyExact(coordinates);
            Check(newEnergy==PhysicalKernelEnergy(cell,q),"actual Sroot*K energy factor differs from exact primary basis");
            const auto oldResult=oracle.Reconstruct(before,oldEnergy.convert_to<Real>());
            const auto newResult=oracle.Reconstruct(q,newEnergy.convert_to<Real>());
            Check(newResult.projectionEnergy==0,"corrected primary factors retain an exact physical P1 energy leak");
            for(const auto& row:newResult.physicalMoments)
                for(const auto& value:row) Check(value==0,"corrected primary factors retain an exact physical moment");
            Check(oldResult.projectionEnergy>0,"negative old floating kernel control did not exercise moment leakage");
            std::printf("EXACT_KERNEL_STATE scaling=%s old_point_leak=%Lg new_point_leak=%Lg "
                        "old_scaled_moment=%Lg new_scaled_moment=%Lg old_P1_energy_norm=%Lg new_P1_energy_norm=%Lg "
                        "old_actual_S_energy=%Lg new_actual_S_energy=%Lg relative_energy_change=%Lg "
                        "physical_rms=%Lg primary_coefficients_cast_back=0\n",
                        scaling?"physical_rms_0.1":"original_unit_z",oldResult.maxPointLeak,newResult.maxPointLeak,
                        oldResult.maxScaledMoment,newResult.maxScaledMoment,std::sqrt(oldResult.energyFraction),
                        std::sqrt(newResult.energyFraction),oldEnergy.convert_to<Real>(),newEnergy.convert_to<Real>(),
                        abs((newEnergy-oldEnergy)/oldEnergy).convert_to<Real>(),
                        std::sqrt(2*newEnergy.convert_to<Real>()/(1000*cell.framed.physicalVolume)));
        }
        std::printf("EXACT_KERNEL_SUMMARY checks=%u failures=0 polynomial_fields=15 polynomial_point_error=%Lg "
                    "all_CK_columns_exact_zero=1 all_nonpivot_coefficients_unchanged=1 "
                    "actual_Sroot_factor_retained=1 resolved_baseline_unchanged=1\n",checks,pointError);
        return 0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"EXACT_KERNEL_FAIL checks=%u %s\n",checks,error.what());
        return 1;
    }
}
