// Companion diagnostic. TinyNetworkTests.cpp's ORIGINAL raw-coefficient gate
// remains unchanged. This tests independent actual physical fields instead.
#include "Network.h"
#include "acceptance/ExactPatchOracle.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
#include <cstdlib>

namespace sn=stage17_network;
namespace vm=JudasFluidVem;
namespace pa=port_acceptance;
using pa::R;
using pa::RV;
using Real=vm::Real;
using Coefficients=std::array<R,12>;

RV Evaluate(const Coefficients& coefficients,const RV& r) {
    RV value{};
    for(unsigned component=0;component<3;++component) {
        value[component]=coefficients[4*component];
        for(unsigned axis=0;axis<3;++axis) value[component]+=coefficients[4*component+axis+1]*r[axis];
    }
    return value;
}
Real Norm(const RV& value) {
    Real square=0;
    for(const auto& x:value) {const Real rounded=x.convert_to<Real>();square+=rounded*rounded;}
    return std::sqrt(square);
}

struct IndependentCell {
    pa::Moments volume{};
    std::vector<RV> vertices;
    explicit IndependentCell(const convex_ports::Cell& cell) {
        std::set<RV> unique;
        for(const auto& tet:cell.integration) {
            std::array<RV,4> local;
            for(unsigned i=0;i<4;++i) {local[i]=pa::Sub(tet.points[i],cell.center);unique.insert(local[i]);}
            pa::Add(volume,pa::TetraP2(local));
        }
        vertices.assign(unique.begin(),unique.end());
    }
    R Moment(unsigned a,unsigned b) const {return volume[vm::ProductIndex(a,b)];}
    R Kinetic(const Coefficients& a,const Coefficients& b) const {
        R result=0;
        for(unsigned component=0;component<3;++component)
            for(unsigned i=0;i<4;++i)
                for(unsigned j=0;j<4;++j)
                    result+=1000*a[4*component+i]*b[4*component+j]*Moment(i,j);
        return result;
    }
    std::array<R,12> VelocityMoments(const Coefficients& field) const {
        std::array<R,12> result{};
        for(unsigned component=0;component<3;++component)
            for(unsigned moment=0;moment<4;++moment)
                for(unsigned coefficient=0;coefficient<4;++coefficient)
                    result[4*component+moment]+=field[4*component+coefficient]*Moment(moment,coefficient);
        return result;
    }
};

std::array<R,3> ExactFactors(const stage16_factored::CanonicalFrame& frame,const RV& global) {
    const RV delta=pa::Sub(global,frame.origin);
    return {R(1),(owned_metrics::Dot(frame.edge,delta)-frame.midU)/frame.spanU,
                (owned_metrics::Dot(frame.transverse,delta)-frame.midV)/frame.spanV};
}

std::vector<R> IndependentDofs(const convex_ports::Cell& geometry,
                                const sn::PhysicalCell& metrics,
                                const IndependentCell& oracle,
                                const Coefficients& field) {
    const unsigned mean=3*geometry.faces.size();
    std::vector<R> dofs(mean+6,R(0));
    for(unsigned face=0;face<geometry.faces.size();++face) {
        for(const auto& triangle:geometry.faces[face].triangles) {
            std::array<std::array<R,3>,3> psi;
            std::array<RV,3> velocity;
            for(unsigned corner=0;corner<3;++corner) {
                const auto factors=ExactFactors(metrics.faces[face].frame,triangle.points[corner]);
                for(unsigned row=0;row<3;++row) psi[row][corner]=factors[row];
                velocity[corner]=Evaluate(field,pa::Sub(triangle.points[corner],geometry.center));
            }
            for(unsigned row=0;row<3;++row) {
                const R testSum=psi[row][0]+psi[row][1]+psi[row][2];
                for(unsigned component=0;component<3;++component) {
                    R velocitySum=0,diagonal=0;
                    for(unsigned corner=0;corner<3;++corner) {
                        velocitySum+=velocity[corner][component];
                        diagonal+=psi[row][corner]*velocity[corner][component];
                    }
                    // n*dA is exactly the oriented area vector: no normalized
                    // rounded normal or rounded edge subtraction is involved.
                    dofs[3*face+row]+=triangle.areaVector[component]*(testSum*velocitySum+diagonal)/12;
                }
            }
        }
    }
    const auto moments=oracle.VelocityMoments(field);
    RV angular{};
    for(unsigned component=0;component<3;++component) {
        dofs[mean+component]=moments[4*component];
        const RV positionMoment{moments[4*component+1],moments[4*component+2],moments[4*component+3]};
        RV unit{};unit[component]=1;
        angular=pa::Sum(angular,owned_metrics::Cross(positionMoment,unit));
    }
    for(unsigned component=0;component<3;++component) dofs[mean+3+component]=angular[component];
    return dofs;
}

struct Stats {
    Real velocityAbs=0,velocityAmplitudeRelative=0,energyRelative=0,crossWorkRelative=0,
         momentsRelative=0,energyAbs=0,meanDiv=0,exactMeanDiv=0,pointDiv=0;
    unsigned checks=0,failures=0;
    void Observe(Real value,Real& maximum,bool gate=true) {
        maximum=std::max(maximum,std::abs(value));
        ++checks;
        if(gate && (!std::isfinite(value) || std::abs(value)>1e-8L)) ++failures;
    }
    void Merge(const Stats& other) {
        velocityAbs=std::max(velocityAbs,other.velocityAbs);
        velocityAmplitudeRelative=std::max(velocityAmplitudeRelative,other.velocityAmplitudeRelative);
        energyRelative=std::max(energyRelative,other.energyRelative);
        crossWorkRelative=std::max(crossWorkRelative,other.crossWorkRelative);
        momentsRelative=std::max(momentsRelative,other.momentsRelative);
        energyAbs=std::max(energyAbs,other.energyAbs);
        meanDiv=std::max(meanDiv,other.meanDiv);
        exactMeanDiv=std::max(exactMeanDiv,other.exactMeanDiv);
        pointDiv=std::max(pointDiv,other.pointDiv);
        checks+=other.checks;failures+=other.failures;
    }
};

std::vector<Coefficients> Fields() {
    std::vector<Coefficients> fields(15);
    for(unsigned i=0;i<12;++i) fields[i][i]=1;
    // Three explicit unit rigid rotations about this cell's local origin.
    fields[12][4+3]=-1;fields[12][8+2]=1;
    fields[13][0+3]=1;fields[13][8+1]=-1;
    fields[14][0+2]=-1;fields[14][4+1]=1;
    return fields;
}

Stats PhysicalPatches(const convex_ports::Cell& geometry,const sn::Local& local,
                      const vm::Vector& solved,const std::vector<Coefficients>& fields) {
    Stats stats;
    const IndependentCell oracle(geometry);
    std::vector<vm::Vector> dofs;
    std::vector<Real> exactNorm;
    Real radius=0;
    for(const auto& point:oracle.vertices) radius=std::max(radius,Norm(point));
    for(const auto& field:fields) {
        const auto exactDofs=IndependentDofs(geometry,local.cell,oracle,field);
        vm::Vector d(exactDofs.size());
        for(unsigned i=0;i<exactDofs.size();++i) d[i]=exactDofs[i].convert_to<Real>();
        dofs.push_back(d);
        const auto projected=local.op.Project(d);
        Coefficients physicalProjection;
        for(unsigned i=0;i<12;++i) physicalProjection[i]=R(projected[i]);
        Real amplitude=0,absolute=0;
        for(const auto& point:oracle.vertices) {
            const auto expected=Evaluate(field,point);
            const auto actual=Evaluate(physicalProjection,point);
            amplitude=std::max(amplitude,Norm(expected));
            const Real difference=Norm(pa::Sub(actual,expected));
            stats.Observe(difference,stats.velocityAbs);
            absolute=std::max(absolute,difference);
        }
        if(amplitude>0) stats.Observe(absolute/amplitude,stats.velocityAmplitudeRelative,false);

        const Real physicalNorm=oracle.Kinetic(field,field).convert_to<Real>();
        exactNorm.push_back(physicalNorm);
        const Real actualEnergy=local.op.Energy(d);
        const Real expectedEnergy=physicalNorm/2;
        stats.Observe(std::abs(actualEnergy-expectedEnergy),stats.energyAbs,false);
        stats.Observe((actualEnergy-expectedEnergy)/expectedEnergy,stats.energyRelative);

        const auto expectedMoments=oracle.VelocityMoments(field);
        const auto actualMoments=(local.op.momentOperator*d).eval();
        const Real volume=oracle.volume[0].convert_to<Real>();
        for(unsigned component=0;component<3;++component)
            for(unsigned moment=0;moment<4;++moment) {
                const unsigned index=4*component+moment;
                Real scale=volume*amplitude;
                if(moment) scale*=radius;
                const Real error=actualMoments[index]-expectedMoments[index].convert_to<Real>();
                stats.Observe(scale>0?error/scale:std::abs(error),stats.momentsRelative);
            }
    }
    for(unsigned a=0;a<fields.size();++a)
        for(unsigned b=0;b<fields.size();++b) {
            const Real expected=oracle.Kinetic(fields[a],fields[b]).convert_to<Real>();
            const Real actual=dofs[a].dot(local.op.mass*dofs[b]);
            const Real scale=std::sqrt(exactNorm[a]*exactNorm[b]);
            stats.Observe((actual-expected)/scale,stats.crossWorkRelative);
        }

    // Actual moving-body flow, not a cached status. Mean divergence normalized
    // by physical volume prevents a tiny cell hiding a huge local volume rate.
    const auto integrated=(local.op.divergenceMoments*solved).eval();
    const Real volume=oracle.volume[0].convert_to<Real>();
    stats.Observe(integrated[0]/volume,stats.meanDiv);
    R exactSum=0;
    for(unsigned face=0;face<geometry.faces.size();++face) exactSum+=R(solved[3*face]);
    stats.Observe((exactSum/oracle.volume[0]).convert_to<Real>(),stats.exactMeanDiv);
    const auto divergence=local.op.Divergence(solved);
    for(const auto& point:oracle.vertices) {
        R value=R(divergence[0]);
        for(unsigned a=0;a<3;++a) value+=R(divergence[a+1])*point[a];
        stats.Observe(value.convert_to<Real>(),stats.pointDiv);
    }
    return stats;
}

int main(int argc,char** argv) {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        const double angle=argc>1?std::strtod(argv[1],nullptr):3.2137858346770188e-11;
        using V=glm::dvec3;
        const auto box=owned_cut::BoxPlanes(V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3))));
        convex_ports::Compiler geometry;
        geometry.Build(1,box);
        sn::Network network(geometry);
        sn::Twist twist;
        twist<<.01L,-.02L,.03L,.02L,.03L,-.01L;
        const auto solved=network.Solve(network.Constant(vm::Vec3::Zero()),twist);
        const auto fields=Fields();
        Stats total;
        for(unsigned cell=0;cell<geometry.cells.size();++cell) {
            const auto& input=geometry.cells[cell];
            const auto& local=*network.cells[cell];
            const auto stats=PhysicalPatches(input,local,solved.local[cell],fields);
            total.Merge(stats);
            std::printf("TINY_PHYSICAL_PATCH seed=%u piece=%u volume=%Lg raw_coefficient_error=%Lg "
                        "velocity_abs=%Lg velocity_amplitude_relative=%Lg energy_relative=%Lg energy_abs=%Lg "
                        "cross_work_relative=%Lg moments_relative=%Lg mean_div=%Lg exact_mean_div=%Lg "
                        "point_div=%Lg checks=%u failures=%u\n",input.seed,input.piece,
                        input.volume.convert_to<Real>(),local.op.polynomialReproductionError,
                        stats.velocityAbs,stats.velocityAmplitudeRelative,stats.energyRelative,stats.energyAbs,
                        stats.crossWorkRelative,stats.momentsRelative,stats.meanDiv,stats.exactMeanDiv,
                        stats.pointDiv,stats.checks,stats.failures);
        }
        std::printf("TINY_PHYSICAL_SUMMARY angle=%.17g fields=%zu checks=%u failures=%u "
                    "velocity_abs=%Lg energy_relative=%Lg cross_work_relative=%Lg moments_relative=%Lg "
                    "mean_div=%Lg exact_mean_div=%Lg point_div=%Lg threshold=1e-8 "
                    "original_raw_coefficient_gate=preserved\n",angle,fields.size(),total.checks,total.failures,
                    total.velocityAbs,total.energyRelative,total.crossWorkRelative,total.momentsRelative,
                    total.meanDiv,total.exactMeanDiv,total.pointDiv);
        return total.failures?1:0;
    } catch(const std::exception& error) {
        std::fprintf(stderr,"TINY_PHYSICAL_PATCH_ERROR %s\n",error.what());
        return 1;
    }
}
