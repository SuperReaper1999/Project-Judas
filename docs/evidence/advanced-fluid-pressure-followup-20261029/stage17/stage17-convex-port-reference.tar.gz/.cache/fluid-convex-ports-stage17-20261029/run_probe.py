from pathlib import Path
import subprocess,sys,os
root=Path('.cache/fluid-convex-ports-stage17-20261029')
src=root/sys.argv[1]
exe=root/(src.stem+'.exe')
cmd=['/usr/bin/g++','-std=c++17','-O3','-g0','-DNDEBUG','-I'+str(Path('src').resolve()),'-I'+os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'),'-I'+os.environ.get('EIGEN_INCLUDE_DIR','/tmp/judas-fluid-reference-eigen/extracted/usr/include/eigen3'),str(src),'-o',str(exe)]
subprocess.run(cmd,check=True)
raise SystemExit(subprocess.run([str(exe),*sys.argv[2:]]).returncode)
