from pathlib import Path
import hashlib,json,re,tarfile,gzip,io,subprocess,datetime
repo=Path.cwd(); root=repo/'.cache/fluid-convex-ports-stage17-20261029'; out=repo/'docs/evidence/advanced-fluid-pressure-followup-20261029/stage17'
sha=lambda b:hashlib.sha256(b).hexdigest()
files={p for p in root.rglob('*') if p.is_file() and p.suffix in {'.h','.cpp','.py','.txt','.md','.json','.log'}}
files|={repo/'.cache/fluid-contact-repair/setup_probes.py',repo/'.cache/fluid-coupling-stage5-kernel/VolumeDomain.cpp'}
queue=[p for p in files if p.suffix in {'.cpp','.h'}]
while queue:
 p=queue.pop()
 for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(errors='strict'),re.M):
  candidates=[p.parent/include,repo/'src'/include]
  for candidate in candidates:
   target=candidate.resolve()
   if target.is_file() and target.is_relative_to(repo):
    if target not in files: files.add(target);queue.append(target)
    break
frozen=0
for stage in (14,15,16):
 directory=repo/f'docs/evidence/advanced-fluid-pressure-followup-20261029/stage{stage}'
 fingerprint=json.loads((directory/'FINAL_FINGERPRINTS.json').read_text())['files']
 for name,expected in fingerprint.items():
  assert sha((repo/name).read_bytes())==expected,('historical fingerprint mismatch',name)
 source=json.loads((directory/'SOURCE_MANIFEST.json').read_text())['files']
 for path in files:
  rel=str(path.relative_to(repo))
  if rel in source:
   assert sha(path.read_bytes())==source[rel]['sha256'],('frozen dependency mismatch',rel)
   frozen+=1
manifest={}
archive=out/'stage17-convex-port-reference.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p in sorted(files):
    rel=str(p.relative_to(repo));data=p.read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.uid=info.gid=info.mtime=0;tar.addfile(info,io.BytesIO(data));manifest[rel]={'bytes':len(data),'sha256':sha(data)}
(out/'SOURCE_MANIFEST.json').write_text(json.dumps({'schema':1,'parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'frozenDependencyMatches':frozen,'scope':'Private source, failure snapshots, raw evidence and quote-include dependency closure; excludes executables, objects, native archive, external Boost/Eigen headers.','files':manifest},indent=2)+'\n')
print('Archive',len(files),'files',archive.stat().st_size,'bytes; frozen dependency comparisons',frozen)
