"""Independent standard-library QR replay of one frozen local kinetic system.
No engine, Eigen, Boost, native binaries or external research is required.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse,time,json

def binary_hex(value):
    sign=-1 if value.startswith('-') else 1
    mantissa,exponent=value.lstrip('+-').lower().split('p')
    integer,_,fraction=mantissa.removeprefix('0x').partition('.')
    return Decimal(sign*int(integer+fraction,16))*Decimal(2)**(int(exponent)-4*len(fraction))

def run(path,precision):
    start=time.perf_counter();lines=path.read_text().splitlines();header=lines.pop(0).split()
    assert header[:2]==['JUDAS_FROZEN_LOCAL','1']
    m,n=map(int,header[2:]);assert 0<n<=m and m*n<=2000000
    zero=Decimal(0);columns=[[zero]*m for _ in range(n)]
    vectors={k:[None]*(m if k=='B' else n) for k in 'BFNXYG'};seen=set()
    for line in lines:
        parts=line.split();kind=parts[0]
        if kind=='A':
            r,c=map(int,parts[1:3]);assert 0<=r<m and 0<=c<n and (r,c) not in seen;seen.add((r,c));columns[c][r]=binary_hex(parts[3])
        else:
            assert kind in vectors;i=int(parts[1]);assert 0<=i<len(vectors[kind]) and vectors[kind][i] is None
            vectors[kind][i]=Decimal(parts[2]) if kind=='G' else binary_hex(parts[2])
    assert all(all(v is not None for v in x) for x in vectors.values())
    del lines,seen
    rhs=list(vectors['B']);original=[list(c) for c in columns]
    for k in range(n):
        segment=columns[k][k:];norm=sum((x*x for x in segment),zero).sqrt();assert norm!=0
        diagonal=-norm if segment[0]>=0 else norm
        segment[0]-=diagonal;factor=Decimal(2)/sum((x*x for x in segment),zero)
        for j in range(k+1,n):
            column=columns[j];amount=factor*sum((v*x for v,x in zip(segment,column[k:])),zero)
            if amount:column[k:]=[x-amount*v for x,v in zip(column[k:],segment)]
        amount=factor*sum((v*x for v,x in zip(segment,rhs[k:])),zero)
        rhs[k:]=[x-amount*v for x,v in zip(rhs[k:],segment)]
        columns[k][k]=diagonal;columns[k][k+1:]=[zero]*(m-k-1)
        if k%64==0:print('QR column',k,'of',n,flush=True)
    x=[zero]*n
    for r in range(n-1,-1,-1):x[r]=(rhs[r]-sum((columns[c][r]*x[c] for c in range(r+1,n)),zero))/columns[r][r]
    error=max(abs((a-b)*weight) for a,b,weight in zip(x,vectors['G'],vectors['F']))
    assert error<Decimal('1e-20'),str(error)
    residual=[vectors['B'][r]-sum((original[c][r]*x[c] for c in range(n)),zero) for r in range(m)]
    gradient=max(abs(sum((a*b for a,b in zip(column,residual)),zero)) for column in original)
    assert gradient<Decimal('1e-28'),str(gradient)
    return {'algorithm':'independent Decimal Householder QR, no normal matrix','decimalDigits':precision,'rows':m,'columns':n,'weightedFluxDifferenceFromCpp256':str(error),'actualStationarity':str(gradient),'seconds':time.perf_counter()-start,'passed':True}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('fixture',type=Path);p.add_argument('--precision',type=int,default=100);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert 80<=a.precision<=200
    with localcontext() as ctx:
        ctx.prec=a.precision;result=run(a.fixture,a.precision)
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
