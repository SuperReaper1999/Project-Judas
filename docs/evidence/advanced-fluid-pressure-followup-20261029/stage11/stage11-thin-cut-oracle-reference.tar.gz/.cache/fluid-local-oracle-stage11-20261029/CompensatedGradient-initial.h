#pragma once
#include "../fluid-runtime-viability-stage10-20261029/RuntimeOperators.h"
namespace compatible_flux_extended {
// Private two-binary64 arithmetic experiment. No native physics scalar changes.
// Requires round-to-nearest and finite operands within binary64's exponent range.
struct PairFloat {
 double high=0,low=0;
 static PairFloat Sum(double a,double b){const double sum=a+b,part=sum-a;return {sum,(a-(sum-part))+(b-part)};}
 static PairFloat From(Real value){const double high=double(value);if(!std::isfinite(high))throw std::runtime_error("compensated experiment exceeds binary64 exponent range");return {high,double(value-Real(high))};}
 Real Value()const{return Real(high)+Real(low);}
 friend PairFloat operator+(PairFloat a,PairFloat b){const auto upper=Sum(a.high,b.high),lower=Sum(a.low,b.low);const auto middle=Sum(upper.high,upper.low+lower.high);return Sum(middle.high,middle.low+lower.low);}
 friend PairFloat operator-(PairFloat a,PairFloat b){return a+PairFloat{-b.high,-b.low};}
 friend PairFloat operator*(PairFloat a,PairFloat b){const double product=a.high*b.high,error=std::fma(a.high,b.high,-product);const auto first=Sum(product,error+a.high*b.low+a.low*b.high);return Sum(first.high,first.low+a.low*b.low);}
};
struct PreparedCompensatedGradient {
 struct Term {unsigned column;PairFloat coefficient;};
 std::vector<std::vector<Term>> rows;unsigned columns;
 explicit PreparedCompensatedGradient(const Dense& matrix):rows(matrix.rows()),columns(matrix.cols()){
  for(int r=0;r<matrix.rows();++r)for(int c=0;c<matrix.cols();++c)if(matrix(r,c)!=0)rows[r].push_back({unsigned(c),PairFloat::From(matrix(r,c))});
 }
 Vector Evaluate(const Vector& rhs,const Vector& x)const{
  if(unsigned(rhs.size())!=rows.size()||unsigned(x.size())!=columns)throw std::runtime_error("compensated gradient dimensions differ");
  std::vector<PairFloat> values(columns),gradient(columns);for(unsigned c=0;c<columns;++c)values[c]=PairFloat::From(x[c]);
  for(unsigned r=0;r<rows.size();++r){auto residual=PairFloat::From(rhs[r]);for(const auto& term:rows[r])residual=residual-term.coefficient*values[term.column];for(const auto& term:rows[r])gradient[term.column]=gradient[term.column]+term.coefficient*residual;}
  Vector result(columns);for(unsigned c=0;c<columns;++c)result[c]=gradient[c].Value();return result;
 }
};
}
