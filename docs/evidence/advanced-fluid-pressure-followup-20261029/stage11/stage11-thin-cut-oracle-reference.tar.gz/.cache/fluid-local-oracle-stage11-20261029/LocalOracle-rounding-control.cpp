#include "../fluid-runtime-viability-stage10-20261029/LocalResponses.h"
#include "../fluid-runtime-viability-stage10-20261029/PredictorSampler.h"
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <cstdio>
#include <limits>
using namespace compatible_flux_extended;
template<unsigned Bits>using Number=boost::multiprecision::number<boost::multiprecision::cpp_bin_float<Bits,boost::multiprecision::digit_base_2>>;
struct Frozen {
 Dense matrix,freeMatrix,pivotMatrix,constraint,Y;Vector predicted,boundary;Vector rhs,physicalScale,normalScale;unsigned local=0;
 Vector original,prepared;
};
template<unsigned Bits>std::vector<Number<Bits>> Solve(const Frozen& f,bool omitted=false,unsigned mode=0){
 using N=Number<Bits>;const unsigned n=f.matrix.cols();std::vector<N> gram(size_t(n)*n),rhs(n);
 // Independent normal equations are an ORACLE, not a proposed runtime solver.
 // Frozen Real coefficients convert exactly into both higher-precision formats.
 for(int row=0;row<f.matrix.rows();++row){std::vector<std::pair<unsigned,N>> active;for(unsigned c=0;c<n;++c){N coefficient(f.matrix(row,c));if(mode==2){coefficient=N(f.freeMatrix(row,c));for(int k=0;k<f.pivotMatrix.cols();++k)coefficient-=N(f.pivotMatrix(row,k))*N(f.constraint(k,c));}if(coefficient!=0)active.emplace_back(c,coefficient);}
  N localSource(f.rhs[row]);if(mode){localSource=N(f.predicted[row]);for(int c=0;c<f.Y.cols();++c)localSource-=N(f.Y(row,c))*N(f.boundary[c]);}
  for(unsigned a=0;a<active.size();++a){const auto i=active[a].first;rhs[i]+=active[a].second*localSource;for(unsigned b=a;b<active.size();++b)gram[size_t(i)*n+active[b].first]+=active[a].second*active[b].second;}
 }
 for(unsigned i=0;i<n;++i)for(unsigned j=0;j<i;++j)gram[size_t(i)*n+j]=gram[size_t(j)*n+i];
 const auto before=gram;const auto source=rhs;
 if(omitted)for(unsigned i=0;i<n;++i)for(unsigned j=0;j<n;++j)if(i!=j)gram[size_t(i)*n+j]=0;
 for(unsigned k=0;k<n;++k){unsigned pivot=k;for(unsigned r=k+1;r<n;++r)if(abs(gram[size_t(r)*n+k])>abs(gram[size_t(pivot)*n+k]))pivot=r;
  if(gram[size_t(pivot)*n+k]==0)throw std::runtime_error("high-precision oracle has an exact zero pivot");
  if(pivot!=k){for(unsigned c=0;c<n;++c)std::swap(gram[size_t(pivot)*n+c],gram[size_t(k)*n+c]);std::swap(rhs[pivot],rhs[k]);}
  for(unsigned r=k+1;r<n;++r){const N factor=gram[size_t(r)*n+k]/gram[size_t(k)*n+k];gram[size_t(r)*n+k]=0;for(unsigned c=k+1;c<n;++c)gram[size_t(r)*n+c]-=factor*gram[size_t(k)*n+c];rhs[r]-=factor*rhs[k];}
 }
 std::vector<N> x(n);for(int r=int(n)-1;r>=0;--r){N value=rhs[r];for(unsigned c=r+1;c<n;++c)value-=gram[size_t(r)*n+c]*x[c];x[r]=value/gram[size_t(r)*n+r];}
 N residual=0,scale=1;for(unsigned r=0;r<n;++r){N value=-source[r];for(unsigned c=0;c<n;++c)value+=before[size_t(r)*n+c]*x[c];residual=std::max(residual,N(abs(value)));scale=std::max(scale,N(abs(source[r])));}
 std::printf("ORACLE bits=%u omitted=%d mode=%u local=%u rows=%ld columns=%u normal_relative_residual=%.17g\n",Bits,omitted,mode,f.local,long(f.matrix.rows()),n,double(residual/scale));
 if(residual/scale>N("1e-28"))throw std::runtime_error("high-precision normal oracle did not converge to declared arithmetic residual");return x;
}
int main(int argc,char** argv){std::setvbuf(stdout,nullptr,_IOLBF,0);try{
 const double angle=argc>1?std::stod(argv[1]):3.2137858346770188e-11;
 const auto q=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));ResponseOperators runtime(Condense(Build(owned_cut::Prepare(1,V(.5),V(.2),q),V(0),1)));auto& macro=runtime.operators.reference;
 PredictorSampler sampler(macro.raw);const auto source=sampler.Sample([](V p){return V(.03*std::sin(5*p.y),-.04+.01*std::cos(3*p.z),.02*std::sin(4*p.x));});RefreshResponses(runtime,source);const auto solved=macro.prepared->Solve(macro.coarse.predictor);if(!solved.accepted)throw std::runtime_error(solved.error);
 std::printf("CASE angle=%.17g significand_bits=%d\n",angle,std::numeric_limits<Real>::digits);
 Frozen worst;double largest=-1;
 for(unsigned m=0;m<macro.local.size();++m){const auto& local=macro.local[m];const auto& response=runtime.responses[m];Vector boundary(response.columns.size());for(unsigned i=0;i<response.columns.size();++i)boundary[i]=solved.flux[response.columns[i]];
  const Vector rhs=local.predicted-local.Y*solved.flux;const Vector original=local.qr->solve(rhs),prepared=response.freeSource-response.freeBoundary*boundary;
  Vector scale(original.size());for(unsigned i=0;i<local.freeVariables.size();++i)scale[i]=macro.raw.columnScale[local.inside[local.freeVariables[i]]];const double error=(scale.array()*(prepared-original).array()).abs().maxCoeff();std::printf("LOCAL m=%u rows=%ld free=%ld physical_free_flux_difference=%.17g\n",m,long(rhs.size()),long(original.size()),error);
  if(error>largest){largest=error;worst.local=m;worst.rhs=rhs;worst.original=original;worst.prepared=prepared;worst.physicalScale=scale;}
 }
 const auto& local=macro.local[worst.local];const unsigned nr=local.rows.size(),rank=local.pivotVariables.size(),nf=local.freeVariables.size();Dense Ap(nr,rank),Af(nr,nf);
 for(unsigned r=0;r<nr;++r){for(unsigned c=0;c<rank;++c)Ap(r,c)=macro.raw.fluid.coeff(local.rows[r],local.inside[local.pivotVariables[c]]);for(unsigned c=0;c<nf;++c)Af(r,c)=macro.raw.fluid.coeff(local.rows[r],local.inside[local.freeVariables[c]]);}
 worst.freeMatrix=Af;worst.pivotMatrix=Ap;worst.constraint=local.Cfree;worst.Y=local.Y;worst.predicted=local.predicted;worst.boundary=solved.flux;
 worst.normalScale.resize(nf);
 for(unsigned c=0;c<nf;++c){const auto variable=local.inside[local.freeVariables[c]];Real area=0;for(const auto& face:macro.raw.faces)if(face.variable!=unsigned(-1)&&variable>=face.variable&&variable<face.variable+3){for(unsigned a=0;a<3;++a)area=std::hypot(area,ToDouble(face.areaNormal[a]));break;}if(area<=0)throw std::runtime_error("missing exact owned face for oracle coordinate");worst.normalScale[c]=worst.physicalScale[c]/area;}
 worst.matrix=Af-Ap*local.Cfree;Eigen::ColPivHouseholderQR<Dense> replay(worst.matrix);const Vector reconstructed=replay.solve(worst.rhs);if(!(reconstructed.array()==worst.original.array()).all())throw std::runtime_error("frozen matrix replay does not match original local QR exactly");
 const auto begin=std::chrono::steady_clock::now();const auto x160=Solve<160>(worst);const auto x256=Solve<256>(worst);Number<256> agreement=0,originalError=0,preparedError=0,originalNormalError=0,preparedNormalError=0;
 for(unsigned c=0;c<nf;++c){const Number<256> normal(worst.normalScale[c]);originalNormalError=std::max(originalNormalError,Number<256>(abs(normal*(Number<256>(worst.original[c])-x256[c]))));preparedNormalError=std::max(preparedNormalError,Number<256>(abs(normal*(Number<256>(worst.prepared[c])-x256[c]))));const Number<256> weight(worst.physicalScale[c]);agreement=std::max(agreement,Number<256>(abs(weight*(Number<256>(x160[c])-x256[c]))));originalError=std::max(originalError,Number<256>(abs(weight*(Number<256>(worst.original[c])-x256[c]))));preparedError=std::max(preparedError,Number<256>(abs(weight*(Number<256>(worst.prepared[c])-x256[c]))));}
 std::printf("COMPARISON local=%u original_free_flux_error=%.17g prepared_free_flux_error=%.17g precision_agreement=%.17g oracle_ms=%g\n",worst.local,double(originalError),double(preparedError),double(agreement),std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count());
 Number<256> originalObjective=0,preparedObjective=0,oracleObjective=0,originalFieldError=0,preparedFieldError=0;
 for(unsigned r=0;r<nr;++r){Number<256> original=-Number<256>(worst.rhs[r]),prepared=original,oracle=original;for(unsigned c=0;c<nf;++c){const Number<256> a(worst.matrix(r,c));original+=a*Number<256>(worst.original[c]);prepared+=a*Number<256>(worst.prepared[c]);oracle+=a*x256[c];}originalObjective+=original*original;preparedObjective+=prepared*prepared;oracleObjective+=oracle*oracle;originalFieldError+=(original-oracle)*(original-oracle);preparedFieldError+=(prepared-oracle)*(prepared-oracle);}
 std::printf("PHYSICAL frozen_coefficients=1 original_max_free_normal_error=%g prepared_max_free_normal_error=%g original_mass_root_field_error=%g prepared_mass_root_field_error=%g original_objective_excess=%g prepared_objective_excess=%g\n",double(originalNormalError),double(preparedNormalError),double(sqrt(originalFieldError)),double(sqrt(preparedFieldError)),double(originalObjective-oracleObjective),double(preparedObjective-oracleObjective));
 if(originalObjective<oracleObjective-Number<256>("1e-30")||preparedObjective<oracleObjective-Number<256>("1e-30"))throw std::runtime_error("independent oracle does not minimize original frozen metric");
 Number<256> coefficientError=0,coordinateError=0,maxColumnNorm=0;
 for(unsigned c=0;c<nf;++c){Number<256> norm=0;for(unsigned r=0;r<nr;++r)norm+=Number<256>(worst.matrix(r,c))*Number<256>(worst.matrix(r,c));maxColumnNorm=std::max(maxColumnNorm,Number<256>(sqrt(norm)));const Number<256> delta=Number<256>(worst.original[c])-x256[c];coordinateError+=delta*delta;}
 std::printf("CONDITION frozen_operator_2norm_condition_lower_bound=%g\n",double(maxColumnNorm*sqrt(coordinateError/originalFieldError)));
 const auto accurateSource=Solve<256>(worst,false,1);const auto accurateMatrix=Solve<256>(worst,false,2);Number<256> sourceDelta=0,matrixDelta=0;
 for(unsigned c=0;c<nf;++c){const Number<256> weight(worst.physicalScale[c]);sourceDelta=std::max(sourceDelta,Number<256>(abs(weight*(accurateSource[c]-x256[c]))));matrixDelta=std::max(matrixDelta,Number<256>(abs(weight*(accurateMatrix[c]-accurateSource[c]))));}
 std::printf("ROUNDING high_precision_residual_free_flux_change=%g high_precision_reduced_matrix_additional_free_flux_change=%g\n",double(sourceDelta),double(matrixDelta));
 bool detected=false;try{Solve<160>(worst,true);}catch(const std::runtime_error& e){detected=std::string(e.what())=="high-precision normal oracle did not converge to declared arithmetic residual";}if(!detected)throw std::runtime_error("negative control did not reject omitted kinetic coupling");
 if(agreement>Number<256>("1e-20"))throw std::runtime_error("two oracle precisions disagree");std::puts("SUMMARY frozen_matrix_replay_exact=1 precision_agreement_pass=1 production_claim=0");return 0;
 }catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
