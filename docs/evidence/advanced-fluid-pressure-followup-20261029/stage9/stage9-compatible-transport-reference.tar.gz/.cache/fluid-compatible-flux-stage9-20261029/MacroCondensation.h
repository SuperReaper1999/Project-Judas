#pragma once
#include "MaterialFlux.h"
#include "PreparedConservative.h"
#include <memory>
namespace compatible_flux_extended {
struct MacroPatch {std::array<R,4> plane;unsigned pivot,u,v;std::vector<unsigned> faces;};
struct LocalCondensation {
 std::vector<unsigned> rows,inside,pivotVariables,freeVariables,pivotRows,remainingRows;
 Dense Cfree,Cboundary,Cbody,pivot,remainingPivot,Y,Ybody;
 Vector predicted;std::shared_ptr<Eigen::ColPivHouseholderQR<Dense>> qr;
 unsigned offset=0,tail=0;
};
struct MacroSystem {
 System raw,coarse;std::shared_ptr<const PreparedConservativeSolver> prepared;std::vector<MacroPatch> patches;std::vector<int> patch;
 std::vector<LocalCondensation> local;Dense trace;double preparationMs=0,retainedEnergy=0;
};
inline MacroSystem Condense(System raw){
 const auto start=std::chrono::steady_clock::now();MacroSystem out;out.raw=std::move(raw);const auto& sys=out.raw;
 using Canonical=std::array<R,4>;using Key=std::tuple<unsigned,unsigned,Canonical>;std::map<Key,unsigned> patches;out.patch.assign(sys.faces.size(),-1);
 for(unsigned f=0;f<sys.faces.size();++f){const auto& face=sys.faces[f];if(face.variable==unsigned(-1))continue;
  unsigned a=sys.cells[face.owners[0]].macro,b=face.owners.size()==2?sys.cells[face.owners[1]].macro:unsigned(-1);if(a==b)continue;if(b<a)std::swap(a,b);
  unsigned pivot=0;for(unsigned k=1;k<3;++k)if(abs(face.areaNormal[k])>abs(face.areaNormal[pivot]))pivot=k;
  Canonical plane;for(unsigned k=0;k<3;++k)plane[k]=face.areaNormal[k]/face.areaNormal[pivot];plane[3]=Dot(face.areaNormal,sys.positions[face.vertices[0]])/face.areaNormal[pivot];
  auto [at,inserted]=patches.emplace(Key{a,b,plane},patches.size());if(inserted)out.patches.push_back({plane,pivot,(pivot+1)%3,(pivot+2)%3,{}});out.patch[f]=at->second;out.patches[at->second].faces.push_back(f);
 }
 const unsigned nc=3*out.patches.size();out.trace=Dense::Zero(sys.variables,nc);
 for(unsigned p=0;p<out.patches.size();++p){const auto& patch=out.patches[p];for(auto f:patch.faces){const auto& face=sys.faces[f];const R area=face.areaNormal[patch.pivot];for(unsigned corner=0;corner<3;++corner){const auto& point=sys.positions[face.vertices[corner]];out.trace(face.variable+corner,3*p)=ToDouble(area)/sys.columnScale[face.variable+corner];out.trace(face.variable+corner,3*p+1)=ToDouble(area*point[patch.u])/sys.columnScale[face.variable+corner];out.trace(face.variable+corner,3*p+2)=ToDouble(area*point[patch.v])/sys.columnScale[face.variable+corner];}}}
 std::vector<std::vector<unsigned>> rows(sys.macros),inside(sys.macros);for(unsigned c=0;c<sys.cells.size();++c)for(unsigned j=0;j<12;++j)rows[sys.cells[c].macro].push_back(c*12+j);
 for(unsigned f=0;f<sys.faces.size();++f){const auto& face=sys.faces[f];if(face.variable!=unsigned(-1)&&out.patch[f]<0)for(unsigned j=0;j<3;++j)inside[sys.cells[face.owners[0]].macro].push_back(face.variable+j);}
 const Dense globalBoundary=sys.fluid*out.trace;
 std::vector<Dense> K,Kbody,G,Gbody;std::vector<Vector> b;unsigned totalRows=0,totalPressure=0;
 for(unsigned m=0;m<sys.macros;++m){LocalCondensation local;local.rows=rows[m];local.inside=inside[m];const unsigned nr=local.rows.size(),ni=local.inside.size();if(nr*ni>16000000)throw std::runtime_error("bounded local condensation memory exceeded");
  Dense Ai(nr,ni),Di(4,ni),Ac(nr,nc),Ab(nr,6),Dc(4,nc),Db(4,6);local.predicted.resize(nr);
  for(unsigned r=0;r<nr;++r){local.predicted[r]=sys.predictor[local.rows[r]];Ab.row(r)=sys.body.row(local.rows[r]);Ac.row(r)=globalBoundary.row(local.rows[r]);for(unsigned j=0;j<ni;++j)Ai(r,j)=sys.fluid.coeff(local.rows[r],local.inside[j]);}
  for(unsigned r=0;r<4;++r){Db.row(r)=sys.bodyDivergence.row(4*m+r);Dc.row(r)=sys.divergence.row(4*m+r)*out.trace;for(unsigned j=0;j<ni;++j)Di(r,j)=sys.divergence(4*m+r,local.inside[j]);}
  Eigen::FullPivLU<Dense> eliminator(Di);const unsigned rank=eliminator.rank();const auto cols=eliminator.permutationQ().indices();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverseP=eliminator.permutationP().inverse();const auto rowOrder=inverseP.indices();
  local.pivot.resize(rank,rank);Dense Dfree(rank,ni-rank),Dglobal(rank,nc),Dbody(rank,6),Ap(nr,rank),Afree(nr,ni-rank);
  for(unsigned r=0;r<4;++r){if(r<rank)local.pivotRows.push_back(rowOrder[r]);else local.remainingRows.push_back(rowOrder[r]);}
  for(unsigned j=0;j<ni;++j){if(j<rank){local.pivotVariables.push_back(cols[j]);Ap.col(j)=Ai.col(cols[j]);}else{local.freeVariables.push_back(cols[j]);Afree.col(j-rank)=Ai.col(cols[j]);}}
  for(unsigned r=0;r<rank;++r){for(unsigned j=0;j<rank;++j)local.pivot(r,j)=Di(rowOrder[r],cols[j]);for(unsigned j=rank;j<ni;++j)Dfree(r,j-rank)=Di(rowOrder[r],cols[j]);Dglobal.row(r)=Dc.row(rowOrder[r]);Dbody.row(r)=Db.row(rowOrder[r]);}
  if(rank){local.Cfree=local.pivot.fullPivLu().solve(Dfree);local.Cboundary=local.pivot.fullPivLu().solve(Dglobal);local.Cbody=local.pivot.fullPivLu().solve(Dbody);}else{local.Cfree=Dense::Zero(0,ni);local.Cboundary=Dense::Zero(0,nc);local.Cbody=Dense::Zero(0,6);}
  const Dense reduced=Afree-Ap*local.Cfree;local.Y=Ac-Ap*local.Cboundary;local.Ybody=Ab-Ap*local.Cbody;
  local.qr=std::make_shared<Eigen::ColPivHouseholderQR<Dense>>(reduced);if(unsigned(local.qr->rank())!=ni-rank)throw std::runtime_error("local compatible kinetic rank loss");
  const Dense rotated=local.qr->householderQ().adjoint()*local.Y,rotatedBody=local.qr->householderQ().adjoint()*local.Ybody;const Vector rotatedPred=local.qr->householderQ().adjoint()*local.predicted;
  local.tail=nr-(ni-rank);local.offset=totalRows;totalRows+=local.tail;K.push_back(rotated.bottomRows(local.tail));Kbody.push_back(rotatedBody.bottomRows(local.tail));b.push_back(rotatedPred.tail(local.tail));out.retainedEnergy+=.5*rotatedPred.head(ni-rank).squaredNorm();
  const unsigned remaining=local.remainingRows.size();Dense g(remaining,nc),gb(remaining,6);local.remainingPivot.resize(remaining,rank);
  for(unsigned r=0;r<remaining;++r){const unsigned original=local.remainingRows[r];for(unsigned j=0;j<rank;++j)local.remainingPivot(r,j)=Di(original,cols[j]);g.row(r)=Dc.row(original)-local.remainingPivot.row(r)*local.Cboundary;gb.row(r)=Db.row(original)-local.remainingPivot.row(r)*local.Cbody;}
  G.push_back(g);Gbody.push_back(gb);totalPressure+=remaining;out.local.push_back(std::move(local));
 }
 out.coarse.variables=nc;out.coarse.body=Dense::Zero(totalRows,6);out.coarse.predictor=Vector::Zero(totalRows);out.coarse.divergence=Dense::Zero(totalPressure,nc);out.coarse.bodyDivergence=Dense::Zero(totalPressure,6);out.coarse.columnScale=Vector::Ones(nc);std::vector<Eigen::Triplet<Real>> entries;unsigned offset=0,pOffset=0;
 for(unsigned m=0;m<sys.macros;++m){for(int r=0;r<K[m].rows();++r)for(unsigned j=0;j<nc;++j)if(K[m](r,j)!=0)entries.emplace_back(offset+r,j,K[m](r,j));out.coarse.body.middleRows(offset,Kbody[m].rows())=Kbody[m];out.coarse.predictor.segment(offset,b[m].size())=b[m];out.coarse.divergence.middleRows(pOffset,G[m].rows())=G[m];out.coarse.bodyDivergence.middleRows(pOffset,Gbody[m].rows())=Gbody[m];offset+=K[m].rows();pOffset+=G[m].rows();}
 out.coarse.fluid.resize(totalRows,nc);out.coarse.fluid.setFromTriplets(entries.begin(),entries.end());out.coarse.fluid.makeCompressed();out.prepared=std::make_shared<const PreparedConservativeSolver>(out.coarse);out.preparationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return out;
}
struct MacroResult:ConservativeResult{double reconstructedBalance=0,reactionError=0,fullEnergy=0,fullStepMs=0;Vector primaryFlux;};
inline MacroResult ReconstructMacro(const MacroSystem& sys,const ConservativeResult& solved,const Eigen::Matrix<Real,6,1>& body){
 const auto stepStart=std::chrono::steady_clock::now();MacroResult result;static_cast<ConservativeResult&>(result)=solved;if(!result.accepted)return result;
 const auto& raw=sys.raw;Vector scaled=sys.trace*result.flux;Vector physicalPressure=Vector::Zero(raw.divergence.rows());unsigned pressureOffset=0;
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const Vector residual=local.predicted-local.Y*result.flux-local.Ybody*body;const Vector free=local.qr->solve(residual),dependent=-local.Cfree*free-local.Cboundary*result.flux-local.Cbody*body;
  for(unsigned j=0;j<local.pivotVariables.size();++j)scaled[local.inside[local.pivotVariables[j]]]=dependent[j];for(unsigned j=0;j<local.freeVariables.size();++j)scaled[local.inside[local.freeVariables[j]]]=free[j];
  for(auto r:local.remainingRows)physicalPressure[4*m+r]=result.pressure[pressureOffset++];
 }
 const Vector actual=raw.fluid*scaled+raw.body*body,residual=raw.predictor-actual,gradient=raw.fluid.transpose()*residual;
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const unsigned rank=local.pivotVariables.size();Vector rhs(rank);for(unsigned j=0;j<rank;++j)rhs[j]=gradient[local.inside[local.pivotVariables[j]]];for(unsigned r=0;r<local.remainingRows.size();++r)rhs.noalias()-=local.remainingPivot.row(r).transpose()*physicalPressure[4*m+local.remainingRows[r]];if(rank){const Vector p=local.pivot.transpose().fullPivLu().solve(rhs);for(unsigned r=0;r<rank;++r)physicalPressure[4*m+local.pivotRows[r]]=p[r];}}
 const auto reaction=raw.body.transpose()*residual-raw.bodyDivergence.transpose()*physicalPressure;result.reactionError=(reaction-result.reaction).norm();result.reconstructedBalance=(raw.divergence*scaled+raw.bodyDivergence*body).lpNorm<Eigen::Infinity>();result.primaryFlux=scaled.cwiseProduct(raw.columnScale);result.fullEnergy=.5*actual.squaredNorm();
 if(result.reactionError>1e-8||result.reconstructedBalance>1e-10||std::abs(result.fullEnergy-(result.energyAfter+sys.retainedEnergy))>1e-9){result.accepted=false;result.error="macro reconstruction violates original work/balance";}result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-stepStart).count();return result;
}
inline MacroResult ProjectMacro(const MacroSystem& sys,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 const auto begin=std::chrono::steady_clock::now();auto result=ReconstructMacro(sys,sys.prepared->Solve(sys.coarse.predictor,body),body);result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();return result;
}

}
