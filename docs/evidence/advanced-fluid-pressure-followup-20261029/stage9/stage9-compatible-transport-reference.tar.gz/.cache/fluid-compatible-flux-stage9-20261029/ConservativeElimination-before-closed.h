#pragma once
#include "CompatibleFluxExtended.h"
namespace compatible_flux_extended {
struct ConservativeResult:Result{unsigned pressureRank=0;double stationarity=0;};
// Eliminate the actual conservation equations BEFORE kinetic minimization.
// This is a coordinate parameterization of Dq + Db V = 0, never an end-of-step
// volume repair. It avoids forming H^-1 and a cancellation-prone Schur matrix.
inline ConservativeResult ProjectConservative(const System& sys,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 ConservativeResult result;try{const auto start=std::chrono::steady_clock::now();
  const auto& D=sys.divergence;Eigen::FullPivLU<Dense> elimination(D);const unsigned rank=elimination.rank();result.pressureRank=rank;
  const auto columns=elimination.permutationQ().indices();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverseP=elimination.permutationP().inverse();const auto rowOrder=inverseP.indices();
  Dense pivot(rank,rank),remainder(rank,sys.variables-rank);Vector target(rank);const Vector fullTarget=-sys.bodyDivergence*body;
  for(unsigned i=0;i<rank;++i){target[i]=fullTarget[rowOrder[i]];for(unsigned j=0;j<rank;++j)pivot(i,j)=D(rowOrder[i],columns[j]);for(unsigned j=rank;j<sys.variables;++j)remainder(i,j-rank)=D(rowOrder[i],columns[j]);}
  Eigen::FullPivLU<Dense> pivotFactor(pivot);if(unsigned(pivotFactor.rank())!=rank)throw std::runtime_error("invalid conservation pivot selection");
  const Dense C=pivotFactor.solve(remainder);const Vector particular=pivotFactor.solve(target);
  Dense lift=Dense::Zero(sys.fluid.rows(),rank);std::set<unsigned> supported;
  for(unsigned k=0;k<rank;++k)for(Sparse::InnerIterator it(sys.fluid,columns[k]);it;++it){lift(it.row(),k)=it.value();supported.insert(it.row());}
  std::vector<Eigen::Triplet<Real>> entries;
  for(unsigned j=rank;j<sys.variables;++j){for(Sparse::InnerIterator it(sys.fluid,columns[j]);it;++it)entries.emplace_back(it.row(),j-rank,it.value());for(auto row:supported){Real value=0;for(unsigned k=0;k<rank;++k)value+=lift(row,k)*C(k,j-rank);if(value!=0)entries.emplace_back(row,j-rank,-value);}}
  Sparse reduced(sys.fluid.rows(),sys.variables-rank);reduced.setFromTriplets(entries.begin(),entries.end());reduced.makeCompressed();
  const Vector rhs=sys.predictor-sys.body*body-lift*particular;
  Eigen::SparseQR<Sparse,Eigen::COLAMDOrdering<int>> qr;qr.compute(reduced);if(qr.info()!=Eigen::Success)throw std::runtime_error("conservative kinetic QR failed");result.rank=qr.rank();if(result.rank!=sys.variables-rank)throw std::runtime_error("conservative kinetic rank loss");
  const Vector free=qr.solve(rhs),dependent=particular-C*free;Vector z(sys.variables);for(unsigned j=0;j<rank;++j)z[columns[j]]=dependent[j];for(unsigned j=rank;j<sys.variables;++j)z[columns[j]]=free[j-rank];
  const Vector actual=sys.fluid*z+sys.body*body,residual=sys.predictor-actual,gradient=sys.fluid.transpose()*residual;
  Vector pivotGradient(rank);for(unsigned j=0;j<rank;++j)pivotGradient[j]=gradient[columns[j]];
  const Vector multipliers=pivot.transpose().fullPivLu().solve(pivotGradient);result.pressure=Vector::Zero(D.rows());for(unsigned i=0;i<rank;++i)result.pressure[rowOrder[i]]=multipliers[i];
  result.stationarity=(gradient-D.transpose()*result.pressure).template lpNorm<Eigen::Infinity>();result.residual=(D*z+sys.bodyDivergence*body).template lpNorm<Eigen::Infinity>();
  result.flux=z.cwiseProduct(sys.columnScale);result.reaction=sys.body.transpose()*residual-sys.bodyDivergence.transpose()*result.pressure;
  result.energyBefore=.5*sys.predictor.squaredNorm();result.energyAfter=.5*actual.squaredNorm();result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  if(!z.allFinite()||!result.pressure.allFinite()||!result.reaction.allFinite()||result.stationarity>1e-10||result.residual>1e-10)throw std::runtime_error("conservative kinetic/work verification failed");
  if(body.norm()==0&&result.energyAfter>result.energyBefore+1e-9)throw std::runtime_error("conservative projection creates energy");result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;
}
}
