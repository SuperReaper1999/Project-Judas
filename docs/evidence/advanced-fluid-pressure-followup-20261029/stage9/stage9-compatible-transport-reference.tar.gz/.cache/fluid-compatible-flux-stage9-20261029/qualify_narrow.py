from pathlib import Path
import subprocess,json,hashlib,datetime,platform
root=Path.cwd();here=Path(__file__).resolve().parent;out=here/'final-narrow';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':1,'parentRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'engineSha256':sha(root/'build/libjudas_engine.a'),'engineIdentity':json.loads((root/'build/judas-build-info-Release.json').read_text()),'scope':'Private compatible-flux, fixed-geometry transport and finite native-interaction references. NOT an enabled runtime backend.','cases':[]}
for name,marker in [('NativeMacroTests','SUMMARY checks=93 failures=0'),('WarmBenchmark','immutable_geometry_only=1')]:
 log=out/(name+'.log')
 with log.open('w') as stream:run=subprocess.run(['python3',str(here/'run_probe.py'),name],cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
 binary=root/'.cache/fluid-contact-repair'/('stage9-'+name)
 record={'name':name,'exit':run.returncode,'expectedExit':0,'marker':marker,'expectationMet':run.returncode==0 and marker in log.read_text(),'sourceSha256':sha(here/(name+'.cpp')),'binarySha256':sha(binary) if binary.exists() else None,'logSha256':sha(log)}
 report['cases'].append(record);(here/'NARROW_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(record,flush=True)
 if not record['expectationMet']:raise RuntimeError('unexpected '+name)
print('All eight focused reference expectations met; application backend, moving transport and runtime performance remain unqualified.')
