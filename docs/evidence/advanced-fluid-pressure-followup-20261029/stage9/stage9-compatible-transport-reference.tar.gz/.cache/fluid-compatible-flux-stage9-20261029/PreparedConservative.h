#pragma once
#include "ConservativeElimination.h"
namespace compatible_flux_extended {
// Value-owned immutable operators. A changed geometry/mass/constraint matrix
// requires constructing a NEW instance. Only the predictor and prescribed
// boundary velocity vary between solves; no native handle/pose is cached here.
class PreparedConservativeSolver {
 Sparse fluid,reduced;
 Dense bodyMatrix,D,bodyD,C,lift,pivot;
 Vector scale;
 std::vector<unsigned> columns,rows;
 unsigned rank=0,variables=0;
 Eigen::FullPivLU<Dense> pivotFactor;
 Eigen::SparseQR<Sparse,Eigen::COLAMDOrdering<int>> qr;
public:
 double preparationMs=0;
 explicit PreparedConservativeSolver(const System& sys):fluid(sys.fluid),bodyMatrix(sys.body),D(sys.divergence),bodyD(sys.bodyDivergence),scale(sys.columnScale),variables(sys.variables){
  const auto start=std::chrono::steady_clock::now();Eigen::FullPivLU<Dense> elimination(D);rank=elimination.rank();const auto order=elimination.permutationQ().indices();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverse=elimination.permutationP().inverse();for(unsigned j=0;j<variables;++j)columns.push_back(order[j]);for(unsigned i=0;i<rank;++i)rows.push_back(inverse.indices()[i]);
  pivot.resize(rank,rank);Dense remainder(rank,variables-rank);for(unsigned i=0;i<rank;++i){for(unsigned j=0;j<rank;++j)pivot(i,j)=D(rows[i],columns[j]);for(unsigned j=rank;j<variables;++j)remainder(i,j-rank)=D(rows[i],columns[j]);}
  pivotFactor.compute(pivot);if(unsigned(pivotFactor.rank())!=rank)throw std::runtime_error("prepared conservation pivot failure");C=pivotFactor.solve(remainder);lift=Dense::Zero(fluid.rows(),rank);std::set<unsigned> supported;
  for(unsigned k=0;k<rank;++k)for(Sparse::InnerIterator it(fluid,columns[k]);it;++it){lift(it.row(),k)=it.value();supported.insert(it.row());}
  std::vector<Eigen::Triplet<Real>> entries;for(unsigned j=rank;j<variables;++j){for(Sparse::InnerIterator it(fluid,columns[j]);it;++it)entries.emplace_back(it.row(),j-rank,it.value());for(auto row:supported){Real value=0;for(unsigned k=0;k<rank;++k)value+=lift(row,k)*C(k,j-rank);if(value!=0)entries.emplace_back(row,j-rank,-value);}}
  reduced.resize(fluid.rows(),variables-rank);reduced.setFromTriplets(entries.begin(),entries.end());reduced.makeCompressed();qr.compute(reduced);if(qr.info()!=Eigen::Success||unsigned(qr.rank())!=variables-rank)throw std::runtime_error("prepared compatible kinetic rank loss");preparationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 }
 ConservativeResult Solve(const Vector& predictor,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero())const{
  ConservativeResult result;try{const auto start=std::chrono::steady_clock::now();if(predictor.size()!=fluid.rows()||!predictor.allFinite()||!body.allFinite())throw std::invalid_argument("invalid prepared kinetic predictor");result.pressureRank=rank;result.rank=qr.rank();Vector target(rank);const Vector fullTarget=-bodyD*body;for(unsigned i=0;i<rank;++i)target[i]=fullTarget[rows[i]];const Vector particular=pivotFactor.solve(target);
   const Vector rhs=predictor-bodyMatrix*body-lift*particular;const Vector free=qr.solve(rhs),dependent=particular-C*free;Vector z(variables);for(unsigned j=0;j<rank;++j)z[columns[j]]=dependent[j];for(unsigned j=rank;j<variables;++j)z[columns[j]]=free[j-rank];
   const Vector actual=fluid*z+bodyMatrix*body,residual=predictor-actual,gradient=fluid.transpose()*residual;Vector g(rank);for(unsigned j=0;j<rank;++j)g[j]=gradient[columns[j]];const Vector pressure=pivot.transpose().fullPivLu().solve(g);result.pressure=Vector::Zero(D.rows());for(unsigned i=0;i<rank;++i)result.pressure[rows[i]]=pressure[i];
   result.stationarity=(gradient-D.transpose()*result.pressure).lpNorm<Eigen::Infinity>();result.residual=(D*z+bodyD*body).lpNorm<Eigen::Infinity>();result.flux=z.cwiseProduct(scale);result.reaction=bodyMatrix.transpose()*residual-bodyD.transpose()*result.pressure;result.energyBefore=.5*predictor.squaredNorm();result.energyAfter=.5*actual.squaredNorm();result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
   if(!z.allFinite()||!result.pressure.allFinite()||!result.reaction.allFinite()||result.stationarity>1e-10||result.residual>1e-10)throw std::runtime_error("prepared compatible work/balance failure");if(body.norm()==0&&result.energyAfter>result.energyBefore+1e-9)throw std::runtime_error("prepared compatible projection creates energy");result.accepted=true;
  }catch(const std::exception& e){result.error=e.what();}return result;
 }
};
}
