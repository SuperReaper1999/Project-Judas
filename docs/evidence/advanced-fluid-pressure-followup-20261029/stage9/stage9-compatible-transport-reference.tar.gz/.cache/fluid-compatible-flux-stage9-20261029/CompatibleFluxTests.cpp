#include "CompatibleFlux.h"
#include <cstdio>
int main(){unsigned checks=0;try{for(double angle:{0.,3.2137858346770188e-11,.37}){const auto q=glm::angleAxis(angle,glm::normalize(compatible_flux::V(1,2,-.3)));auto geometry=owned_cut::Prepare(1,{.5,.5,.5},{.2,.2,.2},q);auto sys=compatible_flux::Build(std::move(geometry),{0,-9.81/240,0},1);auto r=compatible_flux::Project(sys);
 std::printf("COMPATIBLE angle=%.17g tets=%zu macros=%u variables=%u rank=%u accepted=%d balance=%g force=(%.17g %.17g %.17g) torque=%g energy_before=%g energy_after=%g assembly_ms=%g solve_ms=%g error=%s\n",angle,sys.cells.size(),sys.macros,sys.variables,r.rank,r.accepted,r.residual,r.reaction[0],r.reaction[1],r.reaction[2],r.reaction.tail(3).norm(),r.energyBefore,r.energyAfter,sys.assemblyMs,r.solveMs,r.error.c_str());std::fflush(stdout);
 if(!r.accepted)throw std::runtime_error("compatible projection rejected");++checks;
 if((r.reaction.head(3)-Eigen::Vector3d(0,.064*1000*9.81/240,0)).norm()>1e-6||r.reaction.tail(3).norm()>1e-6||r.energyAfter>1e-12)throw std::runtime_error("independent compatible hydrostatic force and calm contract");++checks;
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
