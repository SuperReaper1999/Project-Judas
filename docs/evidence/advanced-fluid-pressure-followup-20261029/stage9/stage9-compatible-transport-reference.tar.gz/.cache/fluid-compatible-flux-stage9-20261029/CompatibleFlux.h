#pragma once
#include "OwnedCutGeometry.h"
#include <Eigen/SparseQR>
#include <Eigen/Dense>
#include <numeric>
#include <chrono>
namespace compatible_flux {
using V=glm::dvec3;using R=owned_metrics::R;using RV=owned_metrics::RV;
using Dense=Eigen::MatrixXd;using Vector=Eigen::VectorXd;using Sparse=Eigen::SparseMatrix<double>;
using RationalMatrix=std::vector<std::vector<R>>;
inline RV Sub(RV a,const RV& b){for(unsigned k=0;k<3;++k)a[k]-=b[k];return a;}
inline RV Cross(const RV& a,const RV& b){return owned_metrics::Cross(a,b);}
inline R Dot(const RV& a,const RV& b){return owned_metrics::Dot(a,b);}
struct Face {std::array<unsigned,3> vertices;std::vector<unsigned> owners;unsigned variable=unsigned(-1);bool solid=false,wall=false;RV areaNormal;};
struct Cell {std::array<unsigned,4> vertices;std::array<unsigned,4> faces;unsigned macro;double volume;};
struct System {
 owned_cut::Snapshot geometry;std::vector<Face> faces;std::vector<Cell> cells;
 std::vector<RV> positions;std::vector<double> volume;
 Sparse fluid;Dense body,divergence,bodyDivergence;Vector predictor,columnScale;
 double assemblyMs=0;unsigned macros=0,variables=0;
};
inline double ToDouble(const R& x){const double y=x.convert_to<double>();if(!std::isfinite(y))throw std::runtime_error("unrepresentable compatible flux metric");return y;}
// Exact rigid-velocity Jacobian at a physical point. Keeping rational geometry
// through lifting prevents thin-cell Piola cancellation from corrupting the
// body boundary before any physical velocity is published.
inline std::array<std::array<R,6>,3> Rigid(const RV& p,const RV& center){std::array<std::array<R,6>,3> out{};RV r=Sub(p,center);for(unsigned a=0;a<3;++a){out[a][a]=1;out[a][3+(a+1)%3]=r[(a+2)%3];out[a][3+(a+2)%3]=-r[(a+1)%3];}return out;}
inline System Build(owned_cut::Snapshot geometry,V predicted,double top=2,bool closed=false){
 const auto start=std::chrono::steady_clock::now();System sys;sys.geometry=std::move(geometry);const auto& mesh=sys.geometry.mesh;const unsigned nt=mesh.tetrahedra.size();
 if(nt>2048)throw std::runtime_error("bounded compatible-flux integration mesh exceeded");
 for(const auto& p:mesh.vertices)sys.positions.push_back(owned_metrics::Position(p.exact));
 constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};std::map<std::array<unsigned,3>,unsigned> faceMap;
 for(unsigned c=0;c<nt;++c){const auto& t=mesh.tetrahedra[c];Cell cell;cell.vertices=t.vertices;
  for(unsigned f=0;f<4;++f){std::array<unsigned,3> key{t.vertices[tri[f][0]],t.vertices[tri[f][1]],t.vertices[tri[f][2]]};std::sort(key.begin(),key.end());auto [at,inserted]=faceMap.emplace(key,sys.faces.size());if(inserted){Face face;face.vertices=key;sys.faces.push_back(std::move(face));}cell.faces[f]=at->second;sys.faces[at->second].owners.push_back(c);}
  sys.cells.push_back(cell);
 }
 std::vector<unsigned> parent(nt);std::iota(parent.begin(),parent.end(),0);const auto find=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};
 for(const auto& f:sys.faces)if(f.owners.size()==2){const auto a=f.owners[0],b=f.owners[1];if(mesh.tetrahedra[a].seed==mesh.tetrahedra[b].seed)parent[find(a)]=find(b);}
 std::map<unsigned,unsigned> groups;
 for(unsigned c=0;c<nt;++c){auto [at,inserted]=groups.emplace(find(c),groups.size());sys.cells[c].macro=at->second;}
 sys.macros=groups.size();sys.volume.assign(sys.macros,0);
 for(auto& face:sys.faces){const auto& ids=face.vertices;const RV a=sys.positions[ids[0]],b=sys.positions[ids[1]],c=sys.positions[ids[2]];face.areaNormal=Cross(Sub(b,a),Sub(c,a));
  for(auto v:sys.cells[face.owners[0]].vertices)if(std::find(ids.begin(),ids.end(),v)==ids.end())if(Dot(face.areaNormal,Sub(sys.positions[v],a))>0)for(auto& x:face.areaNormal)x=-x;
  if(face.owners.size()==1){bool inside=true;for(auto p:mesh.bodyPlanes)for(auto v:ids)inside&=mesh.Side(v,p)<=0;
   if(inside)for(auto p:mesh.bodyPlanes){bool on=true;for(auto v:ids)on&=mesh.Side(v,p)==0;face.solid|=on;}
   bool free=!closed;for(auto v:ids)free&=sys.positions[v][1]==R(top); // grid2 top; unit fixture adapted below
   face.wall=!face.solid&&!free;
  }
  if(!face.solid&&!face.wall){face.variable=sys.variables;sys.variables+=3;}
 }
 if(sys.variables>12000)throw std::runtime_error("bounded compatible flux variable count exceeded");
 std::vector<Eigen::Triplet<double>> entries;sys.body=Dense::Zero(nt*12,6);sys.predictor=Vector::Zero(nt*12);
 RationalMatrix div(sys.macros*4,std::vector<R>(sys.variables+6));
 const RV center{R(sys.geometry.solidCenter.x),R(sys.geometry.solidCenter.y),R(sys.geometry.solidCenter.z)};
 Eigen::Matrix4d reference=Eigen::Matrix4d::Constant(1./20);reference.diagonal().array()+=1./20;const Eigen::Matrix4d root=reference.llt().matrixL();
 constexpr int normal[4][3]={{1,1,1},{-1,0,0},{0,-1,0},{0,0,-1}};
 for(unsigned c=0;c<nt;++c){auto& cell=sys.cells[c];const RV a=sys.positions[cell.vertices[0]];std::array<RV,3> edge;for(unsigned j=0;j<3;++j)edge[j]=Sub(sys.positions[cell.vertices[j+1]],a);const R det=Dot(edge[0],Cross(edge[1],edge[2]));if(det<=0)throw std::runtime_error("nonpositive compatible element");cell.volume=ToDouble(det/6);sys.volume[cell.macro]+=cell.volume;
  std::array<std::array<R,3>,3> piola,cofactor;for(unsigned i=0;i<3;++i){const auto cross=Cross(edge[(i+1)%3],edge[(i+2)%3]);for(unsigned axis=0;axis<3;++axis){piola[axis][i]=edge[i][axis]/det;cofactor[axis][i]=cross[axis];}}
  std::array<std::array<std::map<unsigned,R>,3>,4> velocity;
  for(unsigned v=0;v<4;++v){const auto lift=Rigid(sys.positions[cell.vertices[v]],center);for(unsigned axis=0;axis<3;++axis)for(unsigned b=0;b<6;++b)velocity[v][axis][sys.variables+b]=lift[axis][b];
   for(unsigned f=0;f<4;++f)if(f!=v){const auto& face=sys.faces[cell.faces[f]];
    std::array<R,3> transform{};for(unsigned r=0;r<3;++r){const int value=v==r+1?1:(f==r+1?-1:0);for(unsigned axis=0;axis<3;++axis)transform[axis]+=piola[axis][r]*value;}
    if(face.variable!=unsigned(-1)){unsigned corner=0;while(face.vertices[corner]!=cell.vertices[v])++corner;const int sign=face.owners[0]==c?1:-1;for(unsigned axis=0;axis<3;++axis)velocity[v][axis][face.variable+corner]+=sign*transform[axis];}
    else if(face.wall){RV area{};for(unsigned axis=0;axis<3;++axis)for(unsigned r=0;r<3;++r)area[axis]+=cofactor[axis][r]*normal[f][r];
     for(unsigned b=0;b<6;++b){R prescribed=0;for(unsigned axis=0;axis<3;++axis)prescribed-=area[axis]*lift[axis][b];for(unsigned axis=0;axis<3;++axis)velocity[v][axis][sys.variables+b]+=transform[axis]*prescribed;}
    }
   }
  }
  const double massRoot=std::sqrt(1000*cell.volume);
  for(unsigned axis=0;axis<3;++axis)for(unsigned k=0;k<4;++k){std::map<unsigned,double> row;double constant=0;for(unsigned v=0;v<4;++v){const double weight=massRoot*root(v,k);constant+=weight*predicted[axis];for(const auto& [j,value]:velocity[v][axis])row[j]+=weight*ToDouble(value);}const unsigned r=c*12+axis*4+k;sys.predictor[r]=constant;for(auto [j,value]:row)if(value!=0){if(j<sys.variables)entries.emplace_back(r,j,value);else sys.body(r,j-sys.variables)=value;}}
  // Divergence of the affine reconstructed velocity is constant on a cut tet.
  // Integrate four actual macro moments, collecting rational cancellations
  // BEFORE casting. Constant moment is the exact material volume balance.
  std::array<RV,4> grad;for(unsigned i=1;i<4;++i){const RV cross=Cross(edge[i%3],edge[(i+1)%3]);for(unsigned axis=0;axis<3;++axis)grad[i][axis]=cross[axis]/det;}for(unsigned axis=0;axis<3;++axis)grad[0][axis]=-grad[1][axis]-grad[2][axis]-grad[3][axis];
  std::map<unsigned,R> divergence;for(unsigned v=0;v<4;++v)for(unsigned axis=0;axis<3;++axis)for(const auto& [j,value]:velocity[v][axis])divergence[j]+=grad[v][axis]*value;
  RV centroid{};for(auto v:cell.vertices)for(unsigned axis=0;axis<3;++axis)centroid[axis]+=sys.positions[v][axis]/4;
  for(unsigned test=0;test<4;++test){const R moment=det/6*(test?centroid[test-1]:R(1));for(const auto& [j,value]:divergence)div[cell.macro*4+test][j]+=moment*value;}
 }
 sys.fluid.resize(nt*12,sys.variables);sys.fluid.setFromTriplets(entries.begin(),entries.end());sys.fluid.makeCompressed();sys.columnScale=Vector::Zero(sys.variables);
 for(int j=0;j<sys.fluid.outerSize();++j){double norm=0;for(Sparse::InnerIterator it(sys.fluid,j);it;++it)norm=std::hypot(norm,it.value());if(!(norm>0))throw std::runtime_error("empty compatible flux kinetic column");sys.columnScale[j]=1/norm;for(Sparse::InnerIterator it(sys.fluid,j);it;++it)it.valueRef()*=sys.columnScale[j];}
 sys.divergence=Dense::Zero(sys.macros*4,sys.variables);sys.bodyDivergence=Dense::Zero(sys.macros*4,6);
 for(unsigned i=0;i<sys.macros*4;++i)for(unsigned j=0;j<sys.variables+6;++j){const double v=ToDouble(div[i][j]);if(j<sys.variables)sys.divergence(i,j)=v*sys.columnScale[j];else sys.bodyDivergence(i,j-sys.variables)=v;}
 sys.assemblyMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return sys;
}
struct Result {bool accepted=false;std::string error;Vector flux,pressure;Eigen::Matrix<double,6,1> reaction=Eigen::Matrix<double,6,1>::Zero();double residual=0,energyBefore=0,energyAfter=0,solveMs=0;unsigned rank=0;};
inline Result Project(const System& sys,const Eigen::Matrix<double,6,1>& body=Eigen::Matrix<double,6,1>::Zero()){
 Result result;try{const auto start=std::chrono::steady_clock::now();Eigen::SparseQR<Sparse,Eigen::COLAMDOrdering<int>> qr;qr.compute(sys.fluid);if(qr.info()!=Eigen::Success)throw std::runtime_error("compatible kinetic QR failed");result.rank=qr.rank();if(result.rank!=sys.variables)throw std::runtime_error("compatible flux kinetic rank loss");
 const Vector rhs=sys.predictor-sys.body*body;const Vector unconstrained=qr.solve(rhs);
 const Eigen::SparseMatrix<double,Eigen::RowMajor> sorted=qr.matrixR();const Sparse fullR=sorted;Sparse upper=fullR.topLeftCorner(sys.variables,sys.variables);
 const Dense permuted=qr.colsPermutation().transpose()*sys.divergence.transpose();const Sparse lower=upper.transpose();const Dense y=lower.triangularView<Eigen::Lower>().solve(permuted);const Dense response=qr.colsPermutation()*upper.triangularView<Eigen::Upper>().solve(y);
 Dense schur=sys.divergence*response;schur=.5*(schur+schur.transpose()).eval();const Vector violation=sys.divergence*unconstrained+sys.bodyDivergence*body;
 Eigen::CompleteOrthogonalDecomposition<Dense> pressureFactor(schur);result.pressure=pressureFactor.solve(violation);const Vector z=unconstrained-response*result.pressure;result.flux=z.cwiseProduct(sys.columnScale);
 result.residual=(sys.divergence*z+sys.bodyDivergence*body).lpNorm<Eigen::Infinity>();const Vector actual=sys.fluid*z+sys.body*body;
 result.reaction=sys.body.transpose()*(sys.predictor-actual)-sys.bodyDivergence.transpose()*result.pressure;
 result.energyBefore=.5*sys.predictor.squaredNorm();result.energyAfter=.5*actual.squaredNorm();result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 if(!z.allFinite()||!result.pressure.allFinite()||!result.reaction.allFinite()||result.residual>1e-10)throw std::runtime_error("compatible material balance verification failed");if(body.norm()==0&&result.energyAfter>result.energyBefore+1e-9)throw std::runtime_error("compatible projection creates energy");result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;
}
}
