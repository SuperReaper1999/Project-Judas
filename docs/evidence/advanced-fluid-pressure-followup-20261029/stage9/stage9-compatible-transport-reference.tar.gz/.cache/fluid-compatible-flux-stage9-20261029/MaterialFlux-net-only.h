#pragma once
#include "ConservativeElimination.h"
namespace compatible_flux_extended {
inline std::array<R,6> BodyCoordinates(const Eigen::Matrix<Real,6,1>& body){std::array<R,6> out;for(unsigned j=0;j<6;++j)out[j]=R(body[j]);return out;}
inline RV RigidVelocity(const RV& p,const RV& center,const std::array<R,6>& body){const auto lift=Rigid(p,center);RV out{};for(unsigned a=0;a<3;++a)for(unsigned j=0;j<6;++j)out[a]+=lift[a][j]*body[j];return out;}
inline R FaceDensity(const System& sys,const Face& face,unsigned corner,const Vector& flux,const std::array<R,6>& body){
 if(face.wall)return 0;const RV center{R(sys.geometry.solidCenter.x),R(sys.geometry.solidCenter.y),R(sys.geometry.solidCenter.z)};
 R value=Dot(face.areaNormal,RigidVelocity(sys.positions[face.vertices[corner]],center,body));if(face.variable!=unsigned(-1))value+=R(flux[face.variable+corner]);return value;
}
// Independent Cramer reconstruction of the affine BDM1 field at one tetra
// vertex. It does NOT use the assembly's precomputed interpolation matrix.
inline RV VertexVelocity(const System& sys,unsigned cell,unsigned vertex,const Vector& flux,const std::array<R,6>& body){
 const auto& t=sys.cells[cell];const RV p0=sys.positions[t.vertices[0]],p=sys.positions[t.vertices[vertex]];std::array<RV,3> edge;for(unsigned j=0;j<3;++j)edge[j]=Sub(sys.positions[t.vertices[j+1]],p0);const R det=Dot(edge[0],Cross(edge[1],edge[2]));
 constexpr int normals[4][3]={{1,1,1},{-1,0,0},{0,-1,0},{0,0,-1}};
 std::array<RV,3> equations;std::array<R,3> rhs;unsigned row=0;const RV center{R(sys.geometry.solidCenter.x),R(sys.geometry.solidCenter.y),R(sys.geometry.solidCenter.z)};const RV lift=RigidVelocity(p,center,body);
 for(unsigned f=0;f<4;++f)if(f!=vertex){for(unsigned a=0;a<3;++a)equations[row][a]=normals[f][a];const auto& face=sys.faces[t.faces[f]];
  if(face.solid)rhs[row]=0;
  else if(face.wall){RV area{};for(unsigned a=0;a<3;++a){const auto cross=Cross(edge[(a+1)%3],edge[(a+2)%3]);for(unsigned k=0;k<3;++k)area[k]+=cross[k]*normals[f][a];}rhs[row]=-Dot(area,lift);}
  else{unsigned corner=0;while(face.vertices[corner]!=t.vertices[vertex])++corner;rhs[row]=(face.owners[0]==cell?1:-1)*R(flux[face.variable+corner]);}++row;
 }
 const R determinant=Dot(equations[0],Cross(equations[1],equations[2]));RV reference{};
 for(unsigned j=0;j<3;++j){const auto cofactor=Cross(equations[(j+1)%3],equations[(j+2)%3]);for(unsigned a=0;a<3;++a)reference[a]+=rhs[j]*cofactor[a]/determinant;}
 RV result=lift;for(unsigned a=0;a<3;++a)for(unsigned j=0;j<3;++j)result[a]+=edge[j][a]*reference[j]/det;return result;
}
inline R IntegratedFlux(const System& sys,const Face& f,const Vector& flux,const std::array<R,6>& body){R value=0;for(unsigned corner=0;corner<3;++corner)value+=FaceDensity(sys,f,corner,flux,body)/6;return value;}
inline std::vector<R> ExactVolumes(const System& sys){std::vector<R> volumes(sys.macros);for(const auto& t:sys.cells){const RV a=sys.positions[t.vertices[0]];volumes[t.macro]+=Dot(Sub(sys.positions[t.vertices[1]],a),Cross(Sub(sys.positions[t.vertices[2]],a),Sub(sys.positions[t.vertices[3]],a)))/6;}return volumes;}
struct Material {std::vector<R> quantity,tracer;};
struct MaterialStep {bool accepted=false;std::string error;Material next;unsigned transfers=0;};
inline MaterialStep Advance(const System& sys,const Vector& flux,const Material& current,double dt){MaterialStep result;try{
 if(!std::isfinite(dt)||dt<=0||current.quantity.size()!=sys.macros||current.tracer.size()!=sys.macros)throw std::invalid_argument("invalid material transport input");
 struct Transfer{unsigned donor,receiver;R volume;};std::vector<Transfer> transfers;std::vector<R> outgoing(sys.macros);
 const std::array<R,6> stationary{};
 for(const auto& f:sys.faces){const R volume=R(dt)*IntegratedFlux(sys,f,flux,stationary);if(f.owners.size()==1){if(volume!=0)throw std::runtime_error("external/free-boundary material owner is not supplied");continue;}
  unsigned a=sys.cells[f.owners[0]].macro,b=sys.cells[f.owners[1]].macro;if(a==b||volume==0)continue;
  if(volume<0){std::swap(a,b);transfers.push_back({a,b,-volume});outgoing[a]-=volume;}else{transfers.push_back({a,b,volume});outgoing[a]+=volume;}
 }
 Material staged=current;for(unsigned c=0;c<sys.macros;++c){if(current.quantity[c]<0||current.tracer[c]<0||current.tracer[c]>current.quantity[c])throw std::invalid_argument("invalid owned material state");if(outgoing[c]>current.quantity[c])throw std::runtime_error("material outflow exceeds donor quantity at fixed timestep");}
 for(const auto& transfer:transfers){const R concentration((current.tracer[transfer.donor]/current.quantity[transfer.donor]).convert_to<double>());const R tracer=concentration*transfer.volume;staged.quantity[transfer.donor]-=transfer.volume;staged.quantity[transfer.receiver]+=transfer.volume;staged.tracer[transfer.donor]-=tracer;staged.tracer[transfer.receiver]+=tracer;}
 R before=0,after=0,oldTracer=0,newTracer=0;for(unsigned c=0;c<sys.macros;++c){before+=current.quantity[c];after+=staged.quantity[c];oldTracer+=current.tracer[c];newTracer+=staged.tracer[c];if(staged.quantity[c]<0||staged.tracer[c]<0||staged.tracer[c]>staged.quantity[c])throw std::runtime_error("negative/invalid transported material");}
 if(before!=after||oldTracer!=newTracer)throw std::runtime_error("paired material conservation failed");result.next=std::move(staged);result.transfers=transfers.size();result.accepted=true;
 }catch(const std::exception& e){result.error=e.what();}return result;}
}
