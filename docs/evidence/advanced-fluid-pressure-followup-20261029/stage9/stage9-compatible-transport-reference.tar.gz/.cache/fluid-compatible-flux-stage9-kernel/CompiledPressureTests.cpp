#include "AffineModel.h"
#include "SparseInterior.h"
#include "FluidPressure.h"
#include "ConformingCutMesh.h"
#include "../fluid-pressure-space-stage8-20261029/OwnedCutGeometry.h"
#include <cstdio>
struct CompiledFace{unsigned cell;std::array<unsigned,3> ids;std::array<V,3> points;V normal;};
void BuildCompiled(Model& m,fluid_mesh::Compiler& compiler,bool fixed,V half=V(.2),glm::dquat rotation={1,0,0,0},V center=V(.5),double domainSize=1,V wallMaximum=V(0),bool finalize=true,V wallMinimum=V(0)){
 m.center=center;m.half=half;m.bodyVolume=8*half.x*half.y*half.z;m.bodyMass=1000*m.bodyVolume;
 M inverse(0);if(!fixed){for(unsigned axis=0;axis<3;++axis){unsigned b=(axis+1)%3,c=(axis+2)%3;inverse[axis][axis]=3/(m.bodyMass*(half[b]*half[b]+half[c]*half[c]));}M frame=glm::mat3_cast(rotation);inverse=frame*inverse*glm::transpose(frame);}m.bodies.push_back({V(0),V(0),fixed?0:1/m.bodyMass,inverse});std::map<std::array<unsigned,3>,std::vector<CompiledFace>> faces;constexpr unsigned tri[4][3]={{0,1,2},{0,1,3},{0,2,3},{1,2,3}};
 for(const auto& source:compiler.tetrahedra){const auto& t=source.geometry;const auto& originExact=compiler.vertices[source.vertices[0]].exact;const auto metrics=owned_metrics::Tetra({originExact,compiler.vertices[source.vertices[1]].exact,compiler.vertices[source.vertices[2]].exact,compiler.vertices[source.vertices[3]].exact});const M exactEdges=metrics.edge;double volume=metrics.volume;V centroid=t[0]+(exactEdges[0]+exactEdges[1]+exactEdges[2])*.25;// Uniform tetra covariance is E C_reference E^T. Factoring it through
 // the reference simplex avoids subtracting almost equal world covariance
 // entries for genuine thin cells. This is an algebraic basis change, not
 // a minimum thickness, discarded fragment or added mass.
 const M edge=exactEdges;
 const M referenceCovariance(V(3,-1,-1)/80.,V(-1,3,-1)/80.,V(-1,-1,3)/80.);
 M referenceFactor(0);
 for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){
  double value=referenceCovariance[j][i];
  for(unsigned k=0;k<j;++k)value-=referenceFactor[k][i]*referenceFactor[k][j];
  referenceFactor[j][i]=i==j?std::sqrt(value):value/referenceFactor[j][j];
 }
 const M factor=edge*referenceFactor;
  const unsigned ci=m.cells.size();FluidCell cell{{int(ci),0,0},centroid,factor,glm::inverse(referenceFactor)*metrics.inverse,1000*volume,unsigned(m.points.size()),{}};for(auto p:t)cell.samples.push_back(p);for(unsigned k=0;k<4;++k)m.points.push_back({V(0),1/cell.mass});m.cells.push_back(cell);Row trace;for(unsigned k=0;k<3;++k)trace.points.push_back({cell.first+1+k,V(cell.inverse[0][k],cell.inverse[1][k],cell.inverse[2][k])*volume});m.traceRows.push_back(m.rows.size());m.Add(trace,true);
  for(auto& indices:tri){std::array<unsigned,3> ids{source.vertices[indices[0]],source.vertices[indices[1]],source.vertices[indices[2]]};std::array<V,3> points{t[indices[0]],t[indices[1]],t[indices[2]]};V n=owned_metrics::Triangle({compiler.vertices[ids[0]].exact,compiler.vertices[ids[1]].exact,compiler.vertices[ids[2]].exact}).normal;if(glm::dot(n,centroid-points[0])>0)n=-n;auto key=ids;std::sort(key.begin(),key.end());faces[key].push_back({ci,ids,points,n});}
 }
 const M referenceCovariance(V(3,-1,-1)/80.,V(-1,3,-1)/80.,V(-1,-1,3)/80.);M referenceFactor(0);
 for(unsigned i=0;i<3;++i)for(unsigned j=0;j<=i;++j){double value=referenceCovariance[j][i];for(unsigned k=0;k<j;++k)value-=referenceFactor[k][i]*referenceFactor[k][j];referenceFactor[j][i]=i==j?std::sqrt(value):value/referenceFactor[j][j];}
 const M inverseReference=glm::inverse(referenceFactor);
 const auto evaluate=[&](Row& row,unsigned cell,unsigned vertex,V normal,double sign=1){
  const auto& ids=compiler.tetrahedra[cell].vertices;unsigned corner=0;while(corner<4&&ids[corner]!=vertex)++corner;
  if(corner==4)throw std::runtime_error("face vertex escaped owned tetrahedron");
  V reference(-.25);if(corner)reference[corner-1]+=1;const V phi=inverseReference*reference;
  row.points.push_back({m.cells[cell].first,normal*sign});
  for(unsigned k=0;k<3;++k)row.points.push_back({m.cells[cell].first+1+k,normal*(sign*phi[k])});
 };
 for(const auto& [key,owners]:faces){if(owners.size()>2)throw std::runtime_error("nonmanifold pressure assembly");auto first=owners[0];bool body=false,free=false;if(owners.size()==1){bool wall=false;for(unsigned axis=0;axis<3;++axis)for(double coordinate:{wallMinimum[axis],wallMaximum[axis]>wallMinimum[axis]?wallMaximum[axis]:domainSize}){if(axis==1&&coordinate==(wallMaximum[axis]>wallMinimum[axis]?wallMaximum[axis]:domainSize))continue;fluid_exact::Plane boundary{{0,0,0},coordinate};boundary.normal[axis]=1;bool on=true;for(unsigned v:key)on&=compiler.vertices[v].exact.Side(boundary)==0;wall|=on;}free=!wall;bool inside=true;for(unsigned plane:compiler.bodyPlanes)for(unsigned v:key)inside&=compiler.Side(v,plane)<=0;for(unsigned plane:compiler.bodyPlanes){bool on=true;for(unsigned v:key)on&=compiler.Side(v,plane)==0;if(on&&inside){body=true;const auto& n=compiler.planes[plane].normal;first.normal=-glm::normalize(V(n[0],n[1],n[2]));}}}
  if(free&&!body)continue;
  for(auto vertex:first.ids){const auto p=compiler.vertices[vertex].position;Row row;evaluate(row,first.cell,vertex,first.normal);if(owners.size()==2)evaluate(row,owners[1].cell,vertex,first.normal,-1);else if(body)row.bodies.push_back({0,-first.normal,-glm::cross(p-m.center,first.normal)});m.Add(row,owners.size()==2);}
 }
 if(finalize)m.CondenseDivergence();
}
int main(){unsigned failures=0,checks=0;auto check=[&](bool ok,const char* text){++checks;if(!ok){++failures;std::printf("FAIL %s\n",text);}};for(auto half:{V(.2),V(.25,.15,.2)})for(double angle:{0.,.37})for(bool fixed:{false,true}){try{fluid_mesh::Compiler compiler;std::array<fluid_exact::Plane,6> box;auto q=glm::angleAxis(angle,glm::normalize(V(1,2,-.3)));unsigned at=0;for(unsigned axis=0;axis<3;++axis)for(double sign:{-1.,1.}){V n(0);n[axis]=sign;n=q*n;box[at++]={{n.x,n.y,n.z},glm::dot(n,V(.5))+half[axis]};}compiler.Build(1,box);Model m;BuildCompiled(m,compiler,fixed,half,q);double minimum=INFINITY;for(const auto& c:m.cells){minimum=std::min(minimum,c.mass/1000);m.points[c.first].velocity={0,-9.81/90,0};}m.bodies[0].velocity=fixed?V(0):V(0,-9.81/90,0);std::printf("COMPILED_START half_x=%g angle=%g fixed=%d tets=%zu rows=%zu min_volume=%.12g\n",half.x,angle,fixed,m.cells.size(),m.rows.size(),minimum);std::fflush(stdout);auto start=std::chrono::steady_clock::now();auto result=ProjectFluidPressure(m,64,1e-10);V reaction(0),torque(0);for(unsigned i=0;i<m.rows.size();++i)for(auto g:m.rows[i].bodies){reaction-=g.linear*result.pressureImpulse[i];torque-=g.angular*result.pressureImpulse[i];}check(result.converged,"compiled pressure physical residual");check(std::abs(reaction.y-m.bodyVolume*1000*9.81/90)<1e-6,"compiled native buoyancy force");check(glm::length(V(reaction.x,0,reaction.z))<1e-6&&glm::length(torque)<1e-6,"compiled native pressure no spurious sideways load or torque");check(m.MaxSpeed()<1e-8,"compiled native actual liquid calm endpoint");std::printf("COMPILED_RESULT angle=%g fixed=%d converged=%d iterations=%u residual=%g force_y=%.12g torque=%g fluid_max=%g ms=%.6f\n",angle,fixed,result.converged,result.sweeps,result.maximumResidual,reaction.y,glm::length(torque),m.MaxSpeed(),std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count());}catch(const std::exception& error){++failures;std::printf("ERROR angle=%g fixed=%d %s\n",angle,fixed,error.what());}}
 std::printf("COMPILED_PRESSURE checks=%u failures=%u\n",checks,failures);return failures?1:0;}
