#pragma once
#include "Deformable.h"
#include "PlanetTerrain.h"
#include "Weather.h"
#include "BasicWater.h"
#include "Classification.h"
#include "Material.h"
#include "GravitySelection.h"
#include "NavigationTypes.h"
#include "LiquidTypes.h"
#include "AudioTypes.h"
#include "JointTypes.h"
#include "PoseComposition.h"
#include "FullBodyIK.h"
#include "Ragdoll.h"

#include <cstdint>
#include <map>
#include <optional>
#include "CharacterMotor.h"
#include "Wheel.h"
#include "Powertrain.h"
#include "VisualParticles.h"
#include <string>
#include <vector>

#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>

#include "CollisionShapes.h"

// Milestone 28: Judas's authored scene representation.
//
// A Scene is AUTHORED content only — what an editor or a scene file says
// the world should look like before simulation starts. It is deliberately
// not the running world: no PhysicsWorld handle, no GPU mesh handle, no
// velocity read back from an integrator, no fluid particle position, no
// thermal temperature ever lives here. RuntimeWorld (src/RuntimeWorld.h)
// instantiates a Scene into those engine systems and owns everything
// transient; stopping Play simply discards that instance and the Scene is
// untouched. See docs/ARCHITECTURE.md, "Milestone 28, Authored vs runtime
// state."
//
// This is not an entity/component framework. A SceneObject is a plain
// struct with a fixed, small set of optional component structs — exactly
// the engine capabilities that exist today, no registry, no dynamic
// component types. Script slots contain authored data only. Names here are engine
// concepts (a body, a light, a gravity region); nothing here knows that a
// particular sphere is "Planet A" or a particular box is "the plank" —
// those are scene content, authored in a scene file.

using SceneObjectId = std::uint64_t;
constexpr SceneObjectId kInvalidSceneObjectId = 0;

struct SceneTransform {
    glm::vec3 position{0.0f};
    glm::quat rotation{1.0f, 0.0f, 0.0f, 0.0f};
    // Applies to rendering of mesh shapes only. Collision primitives and
    // box/sphere renderables carry explicit half-extents/radii, so a
    // physics body is never silently rescaled by a visual-only value.
    glm::vec3 scale{1.0f};
};

enum class SceneShape { Box, Sphere, Compound, Mesh, Terrain, ConvexHull, TriangleMesh };

// What Renderer draws for the object. Compound and Terrain reuse the body
// component's geometry (there is nothing sensible to draw otherwise);
// Box/Sphere/Mesh are self-contained and need no body at all.
struct SceneRenderComponent {
    bool visible=true;
    MaterialOverride instanceOverrides; // authored whole-renderable factors
    std::map<std::string,MaterialSlot> partMaterials; // stable imported part identity
    // Runtime intent is separate from authored defaults; clear restores the authored state.
    // Keys: * (whole), #<legacy primitive slot>, or stable imported part identity.
    std::map<std::string,MaterialSlot> runtimeMaterials;
    std::vector<MaterialSlot> materials;
    std::vector<std::string> hiddenParts;
    SceneShape shape = SceneShape::Box;
    glm::vec3 halfExtents{0.5f};   // Box
    float radius = 0.5f;           // Sphere
    glm::vec3 color{0.8f};
    float alpha = 1.0f;
    float lodMultiplier=1.0f; // cooked pixel-error tolerance multiplier; 0 forces base detail
    // Compound only: colour/alpha for every child box after the first
    // (an open container drawn with an opaque base and translucent walls).
    glm::vec3 secondaryColor{0.8f};
    float secondaryAlpha = 1.0f;
    // Mesh only (Milestone 30): stable AssetIds resolved through the
    // project's AssetDatabase (src/AssetDatabase.h), never file paths — a
    // renamed or moved asset keeps its id, so the scene keeps its mesh.
    // Empty texture id draws untextured.
    std::string meshAsset;
    std::string textureAsset;
    // Generated runtime texture; stable camera object ID, never an AssetDatabase ID.
    SceneObjectId textureCamera = kInvalidSceneObjectId;
};

enum class SceneBodyMotion { Static, Dynamic, Kinematic };

// Explicit body-local fluid interior. Membership is geometric; it never
// depends on an object name, particle velocity or body mass. The bounds
// describe a resolved cavity, not an additional collision shape.
struct SceneFluidCavity {
    glm::vec3 localCenter{0.0f};
    glm::vec3 halfExtents{0.5f};
};

struct SceneBodyComponent {
    bool sensor=false;
    bool enabled=true;
    unsigned collisionLayer = 0;
    CategoryMask collisionMask = kAllCategories;
    SceneBodyMotion motion = SceneBodyMotion::Static;
    SceneShape shape = SceneShape::Box;  // Box, Sphere, Compound or Terrain
    glm::vec3 halfExtents{0.5f};
    float radius = 0.5f;
    std::string collisionAsset;
    std::string physicalMaterial; // shared identity; empty keeps legacy factors
    bool physicalMaterialOverride=false; // explicit instance coefficients override shared defaults
    std::vector<CompoundBox> compoundBoxes;
    std::vector<SceneFluidCavity> fluidCavities;
    // Terrain: identifier of a surface the engine can construct (see
    // src/TerrainLibrary.h). A scene never embeds the elevation function.
    std::string terrainSurface;
    float mass = 1.0f;  // Dynamic, or the mass to use on an explicit authority change.
    float friction = 0.6f;
    float restitution = 0.1f;
    glm::vec3 initialLinearVelocity{0.0f};  // World COM m/s; dynamic or prescribed velocity.
    glm::vec3 initialAngularVelocity{0.0f}; // World rad/s; zero keeps legacy content unchanged.
    // Gameplay eligibility for the existing M18 pick-up/throw interaction.
    bool pickable = false;
    // Milestone 29: whether the scene's fidelity policy may move this
    // entity between Full, Coarse and Dormant simulation. Default false: an
    // unmanaged entity is Full forever and the lifecycle machinery never
    // touches it, which is exactly what a small conventional game wants.
    // Explicit commands (editor debug, tests) can still transition an
    // unmanaged entity; `managed` only gates the automatic policy.
    bool managed = false;
};

enum class SceneGravityKind { Radial, Uniform };
enum class SceneRegionShape { Sphere, Box };

// A bounded local gravity context, centred on the object. Radial pulls
// toward the object's position (RadicalGravity); Uniform pulls along the
// object's local -Y (FaithfulGravity when that is world -Y at 9.81 m/s^2,
// UniformGravity otherwise). Regions are registered with GravityContextMap
// in scene order, so an earlier object wins where two regions overlap.
struct SceneGravityComponent {
    SceneGravityKind kind = SceneGravityKind::Radial;
    float magnitude = 9.81f;
    SceneRegionShape regionShape = SceneRegionShape::Sphere;
    float regionRadius = 10.0f;
    glm::vec3 regionHalfExtents{5.0f};
};

enum class SceneLightKind { Point, Spot };

// A standalone dynamic light at the object's transform; a spot light
// faces the object's local -Z.
struct SceneLightComponent {
    bool enabled=true,castsShadow=false;
    float intensity=1,shadowPriority=0;
    SceneLightKind kind = SceneLightKind::Point;
    glm::vec3 color{1.0f};
    float range = 10.0f;
    float innerConeDegrees = 15.0f;
    float outerConeDegrees = 25.0f;
};

// The M16 hinged door. Uses the render component's box half-extents and
// colour; Door owns its own static physics body, so no body component.
struct SceneDoorComponent {
    unsigned collisionLayer=0;
    CategoryMask collisionMask=kAllCategories;
    glm::vec3 localHingeAxis{0.0f, 1.0f, 0.0f};
    float openAngleDegrees = 90.0f;
    float angularSpeedDegreesPerSecond = 120.0f;
};

// The M16 lever that toggles one lamp. Lamp offset is in the object's
// local frame.
struct SceneLightSwitchComponent {
    glm::vec3 localHingeAxis{0.0f, 0.0f, 1.0f};
    float toggleAngleDegrees = 40.0f;
    float angularSpeedDegreesPerSecond = 220.0f;
    glm::vec3 lampLocalOffset{0.0f, 1.0f, 0.0f};
    glm::vec3 lampColor{3.0f};
    float lampRange = 10.0f;
};

enum class SceneVehicleGravity { Local, Celestial };

// The M8/M11/M12 pilotable rigid body. Requires a dynamic box body.
// `Local`: samples the scene's gravity contexts like any other body and
// also joins pairwise celestial gravity. `Celestial`: receives only the
// point-mass fields of static celestial sources (the M26 terrain planet).
struct SceneVehicleComponent {
    SceneVehicleGravity gravity = SceneVehicleGravity::Local;
    bool headlight = true;
    bool navigationLights = true;
    float dragCoefficient = 1.0f;
    // Start the run with the player already secured as pilot (M26 pass).
    bool initialPilotAttached = false;
};

// Newtonian gravitation participant. A dynamic body joins the pairwise
// N-body set using its own mass; a static body is a point-mass source with
// this gravitational parameter acting on Celestial-gravity vehicles.
struct SceneCelestialComponent {
    float gravitationalParameter = 0.0f;  // m^3/s^2, static sources only
    // Operator thrust demonstration (M20): force applied by the P/M/N
    // keys. Zero disables it.
    float operatorThrustForce = 0.0f;
};

// The M26 hydrostatic gas around a celestial object; the object's
// transform is the planet frame.
struct SceneAtmosphereComponent {
    float referenceRadius = 80.0f;
    float topRadius = 110.0f;
    float referenceDensity = 0.05f;
    float polytropicExponent = 1.4f;
    float oxidizerMassFraction = 0.21f;
    float referenceTemperatureKelvin = 300.0f;
};

// The M27 combustible coating on a dynamic body.
struct SceneCombustibleComponent {
    float heatCapacityJPerK = 150.0f;
    float initialFuelMassKg = 0.12f;
    float ignitionTemperatureK = 550.0f;
    float maximumFuelRateKgPerSecond = 0.003f;
    float radiativeAreaSquareMeters = 1.5f;
    float retainedCombustionHeatFraction = 0.75f;
};

// Authored liquid: a lattice of particles centred on the object. The
// solver settings live in SceneSettings; particle mass follows rest
// density and spacing. An emitter adds particles on demand at
// `emitterLocalOffset` until `maxParticles` (M25's held-B water source).
struct SceneFluidVolumeComponent {
    float spacing = 0.05f;
    int countX = 5;
    int countY = 5;
    int countZ = 5;
    bool emitter = false;
    glm::vec3 emitterLocalOffset{0.0f};
    int maxParticles = 0;
};

enum class ScenePlayerView { ThirdPerson, FirstPerson };

// Where the player starts. Exactly one object may carry this.
struct ScenePlayerStartComponent {
    unsigned collisionLayer = 0;
    CategoryMask collisionMask = kAllCategories;
    float yawDegrees = 0.0f;
    ScenePlayerView view = ScenePlayerView::ThirdPerson;
    float density = 950.0f;          // kg/m^3; approximate fluid response
    float fluidDrag = 2.0f;          // inverse seconds
    float swimAcceleration = 4.0f;  // m/s^2 at full immersion
};

// Perspective camera, local -Z forward and +Y up, matching existing views.
struct SceneRenderCameraComponent {
    CategoryMask renderMask = kAllCategories;
    bool enabled = true;
    int width = 256;
    int height = 256;
    int updateEveryFrames = 1;
    float verticalFovDegrees = 60.0f;
    float nearPlane = 0.1f;
    float farPlane = 1000.0f;
};

struct SceneAudioEmitterComponent : AudioSettings {
    std::string asset;
    bool enabled=true, playOnStart=true;
};
struct SceneAudioListenerComponent {
    bool enabled=true;
    // Binds the active presentation camera, independent of any controller.
    bool followActiveView=false;
};

struct SceneAudioZoneComponent {
 std::string asset;
 bool enabled=true;
 SceneRegionShape shape=SceneRegionShape::Box;
 glm::vec3 halfExtents{4};float radius=4,blendDistance=1,amount=1;
 int priority=0;
};

struct SceneUIComponent {std::string asset,name;bool enabled=true;};

struct SceneScriptSlot {
    std::uint64_t id = 1;
    std::string asset;
    bool enabled = true;
    // Bounded JSON object, not arbitrary VM state. Properties are authored.
    std::string properties = "{}";
    bool operator==(const SceneScriptSlot& b) const {
        return id==b.id && asset==b.asset && enabled==b.enabled && properties==b.properties;
    }
};

struct SceneAnimationComponent {bool enabled=true,playOnStart=true,loop=true;std::string clip;float speed=1,time=0;std::vector<AnimationLayerSettings> layers;std::vector<LimbIKSettings> limbs;std::optional<FullBodyIKSettings> fullBodyIK;};

struct SceneSocketComponent {SceneObjectId target=0;std::string joint;SceneTransform offset;bool enabled=true;};

struct SceneJointComponent {SceneObjectId bodyA=0,bodyB=0;JointSettings settings;};

struct SceneObject {
    std::optional<BasicWaterSettings> basicWater;
    std::optional<PlanetSettings> planet;
    // M86 profiles are ordinary authored components. Runtime interpolation,
    // storms and sampled wind belong to RuntimeWorld's WeatherSystem.
    std::optional<WeatherSettings> weather;
    std::optional<WeatherResponseSettings> weatherResponse;
    std::optional<GravitySelection> gravitySelection;
    bool renderVisible=true; // local entity scope; does not deactivate children or simulation
    std::optional<DeformableSettings> deformable;
    std::optional<LiquidBasinSettings> liquidBasin;
    std::optional<LiquidContainerSettings> liquidContainer;
    std::optional<LiquidConnectionSettings> liquidConnection;
    std::optional<LiquidInteractionSettings> liquidInteraction;
    std::optional<NavigationSurfaceSettings> navigationSurface;
    std::optional<NavigationAgentSettings> navigationAgent;
    std::optional<NavigationObstacleSettings> navigationObstacle;
    std::optional<NavigationLinkSettings> navigationLink;
    std::optional<NavigationModifierSettings> navigationModifier;
    std::optional<CharacterMotorSettings> characterMotor;
    std::optional<WheelSettings> wheel;
    std::optional<PowertrainSettings> powertrain;
    std::optional<RagdollDefinition> ragdoll;
    std::optional<SceneJointComponent> joint;
    std::optional<SceneAnimationComponent> animation;
    std::optional<SceneSocketComponent> socket;
    std::vector<SceneScriptSlot> scripts;
    std::optional<SceneUIComponent> ui;
    CategoryMask tags = 0;
    unsigned renderLayer = 0;
    SceneObjectId id = kInvalidSceneObjectId;
    std::string name;
    std::string authoringFolder; // organization only, never a transform parent
    // Authored parent-local transform. No implied rigid constraint.
    SceneObjectId parent = 0;
    // Provenance is authored bookkeeping only; components remain ordinary.
    std::string prefabAsset; // only instance root
    SceneObjectId prefabRoot = 0, prefabSource = 0;
    std::map<SceneObjectId, SceneObjectId> prefabIds; // only root: source -> scene IDs
    std::map<std::string, std::string> prefabOverrides;
    SceneTransform transform;
    std::optional<SceneRenderComponent> render;
    std::optional<SceneRenderCameraComponent> renderCamera;
    std::optional<SceneAudioEmitterComponent> audioEmitter;
    std::optional<ParticleEmitterSettings> particleEmitter;
    std::optional<SceneAudioListenerComponent> audioListener;
    std::optional<SceneAudioZoneComponent> audioZone;
    std::optional<SceneBodyComponent> body;
    std::optional<SceneGravityComponent> gravity;
    std::optional<SceneLightComponent> light;
    std::optional<SceneDoorComponent> door;
    std::optional<SceneLightSwitchComponent> lightSwitch;
    std::optional<SceneVehicleComponent> vehicle;
    std::optional<SceneCelestialComponent> celestial;
    std::optional<SceneAtmosphereComponent> atmosphere;
    std::optional<SceneCombustibleComponent> combustible;
    std::optional<SceneFluidVolumeComponent> fluidVolume;
    std::optional<ScenePlayerStartComponent> playerStart;
};

enum class SceneFidelityPolicy { None, Distance };

// Scene-wide authored settings.
struct SceneSettings {
    std::map<std::string,std::string> authoringRecipes; // scene-owned recipes, excluded from runtime fingerprint

    bool linearRendering=false,environmentBackground=false;
    glm::vec3 backgroundColor{.08f,.09f,.11f};
    float exposure=1,environmentIntensity=1;
    glm::quat environmentRotation{1,0,0,0};
    std::string environmentAsset;
    CategoryMask mainCameraRenderMask = kAllCategories;
    std::string name;
    // M23 absolute world origin of this local scene, metres.
    glm::dvec3 worldOrigin{0.0};
    std::string appearanceResetState; // durable authored reset baseline; empty until a runtime write
    bool sunEnabled=true;
    float sunIntensity=1.0f;
    glm::vec3 sunDirection{0.4f, 0.7f, 0.35f};
    glm::vec3 sunColor{1.0f, 0.98f, 0.92f};
    glm::vec3 ambientColor{0.16f, 0.17f, 0.19f};
    // Multiplies the fluid solver's default length scales (M25 used 10x
    // for the lake). 1 is the M24 cup resolution.
    float fluidScale = 1.0f;
    float fluidUpdateRateHz = 30.0f;
    float fluidHydrostaticDragRate = 2.0f;  // inverse seconds
    // Milestone 29: the fidelity policy this scene asks the runtime to run
    // over its managed entities. None (the default) leaves everything at
    // Full simulation. Distance is the demonstration policy: Full within
    // `fidelityFullRadius` of the focus, Coarse within `fidelityCoarseRadius`,
    // Dormant beyond (see src/FidelityPolicy.h).
    SceneFidelityPolicy fidelityPolicy = SceneFidelityPolicy::None;
    float fidelityFullRadius = 50.0f;
    float fidelityCoarseRadius = 150.0f;
};

class Scene {
public:
    SceneSettings& Settings() { return m_settings; }
    const SceneSettings& Settings() const { return m_settings; }

    const std::vector<SceneObject>& Objects() const { return m_objects; }
    std::vector<SceneObject>& Objects() { return m_objects; }

    // Creates an empty object with a fresh, never-reused id.
    SceneObject& CreateObject(const std::string& name);
    // Inserts an object carrying an explicit id (loading, undo). Fails if
    // the id is invalid or already present.
    bool InsertObject(const SceneObject& object);
    bool DestroyObject(SceneObjectId id);
    SceneObject* Find(SceneObjectId id);
    const SceneObject* Find(SceneObjectId id) const;
    // Reorders `id` one slot earlier/later; order matters for gravity
    // region priority and is therefore authored data.
    bool MoveObject(SceneObjectId id, int delta);

    // The next id CreateObject would hand out; serialized so ids stay
    // unique across save/load even after deletions.
    SceneObjectId NextId() const { return m_nextId; }
    void SetNextId(SceneObjectId nextId);

    void Clear();

private:
    SceneSettings m_settings;
    std::vector<SceneObject> m_objects;
    SceneObjectId m_nextId = 1;
};

// Structural equality of authored state, used by tests and the editor's
// "unsaved changes" tracking. Floats compare exactly.
bool SceneObjectsEqual(const SceneObject& a, const SceneObject& b);
bool ScenesEqual(const Scene& a, const Scene& b);

// Effective bindings are resolved once per logical draw, shared by all passes.
MaterialSlot ResolveRenderMaterial(const SceneRenderComponent&,unsigned,const std::string& part);
bool ValidateAppearance(const SceneSettings&,std::string&);
std::string EncodeAppearanceState(const SceneSettings&);
bool DecodeAppearanceState(const std::string&,SceneSettings&,std::string&);
