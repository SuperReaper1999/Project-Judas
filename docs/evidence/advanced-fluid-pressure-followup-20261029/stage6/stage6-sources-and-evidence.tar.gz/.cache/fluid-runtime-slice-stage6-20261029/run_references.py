from pathlib import Path
import sys,subprocess,json,hashlib,datetime,time
root=Path.cwd();here=root/'.cache/fluid-runtime-slice-stage6-20261029';out=here/'final-references';out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as b
records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
metadata={'sourceParent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'timeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'engineSha256':sha(root/'build/libjudas_engine.a'),'engineIdentity':json.loads((root/'build/judas-build-info-Release.json').read_text()),'results':records}
for source,name,cases,extras in [
 (root/'.cache/fluid-runtime-slice-stage6-kernel/TetraPressureTests.cpp','mixed-matrix-unit',[([],0)],True),
 (here/'NativeRuntimeContact-active-equality-current-api.cpp','rejected-all-corners-active',[([],1)],True),
 (here/'NativeRuntimeTetra.cpp','runtime-tetra',[([],0)],True),
 (here/'NativeRuntimeContact.cpp','runtime-contact',[(['0'],0),(['axis-exact'],0),(['1.13'],1)],True),
 (here/'NativeRuntimeAle.cpp','runtime-ale',[(['120'],1),(['240','--incoming-current'],1)],True),
 (root/'.cache/fluid-coupling-stage5-20261029/NativeDisabledTrajectory.cpp','ordinary-current-trajectory',[([],0)],False)]:
 with (out/(name+'-build.log')).open('w') as log:
  obj=b.compile(source,'stage6-final-'+name)
  b.executable(obj,'stage6-final-'+name,b.out/'stage5-exact-volume-domain.o' if extras else None)
 executable=b.out/('stage6-final-'+name)
 for index,(args,expected) in enumerate(cases):
  log=out/f'{name}-{index}.log';start=time.monotonic()
  with log.open('w') as stream:run=subprocess.run([str(executable),*args],stdout=stream,stderr=subprocess.STDOUT,timeout=90)
  item={'name':name,'args':args,'exit':run.returncode,'expectedExit':expected,'expectedFailure':expected!=0,'expectationMet':run.returncode==expected,'seconds':time.monotonic()-start,'sourceSha256':sha(source),'binarySha256':sha(executable),'log':str(log.relative_to(here)),'logSha256':sha(log)}
  records.append(item);(here/'REFERENCE_RESULTS.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(item),flush=True)
  if run.returncode!=expected:raise RuntimeError('unexpected outcome '+name)
assert 'inconsistent dependent joint constraint' in (out/'rejected-all-corners-active-0.log').read_text()
reference=root/'docs/evidence/advanced-fluid-pressure-followup-20261029/stage5/final/ordinary-native-trajectory.log'
current=out/'ordinary-current-trajectory-0.log'
metadata['ordinaryTrajectoryByteIdentical']=reference.read_bytes()==current.read_bytes()
assert metadata['ordinaryTrajectoryByteIdentical'],'ordinary physical trajectory changed'
for case in (out/'runtime-ale-0.log',out/'runtime-ale-1.log'):
 text=case.read_text();assert 'actual_body_rows=0' in text and 'shadow_not_published=1' in text
 assert 'ledger_pose_error=0' in text and 'PUBLIC_NATIVE_PUBLICATIONS=1' in text
(here/'REFERENCE_RESULTS.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Bounded reference expectations met. Oblique oracle and moving-geometry cases remain failures, NOT fluid qualification.',flush=True)
