from pathlib import Path
import sys,subprocess
root=Path.cwd();here=root/'.cache/fluid-runtime-slice-stage6-20261029';base=here/'baseline-src'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as b
flags=b.compile_flags
for filename,name,old in [('RuntimeAleTrace.cpp','stage6-public-ale-trace',False),('BaselineAleTrace.cpp','stage6-baseline-ale-trace',True)]:
 b.compile_flags=(['-I'+str(base)]+flags) if old else flags
 obj=b.compile(here/filename,name)
 extras=[b.out/'stage5-exact-volume-domain.o']
 if old:
  sources=[base/'PhysicsWorld.cpp',base/'JointSolver.cpp',*sorted((base/'physics').glob('*.cpp'))]
  sources=[p for p in sources if p.name!='WorldMk2Solver.cpp']+[root/'.cache/fluid-coupling-stage5-20261029/WorldMk2Batch.cpp']
  extras=[b.out/('stage6-baseline-'+p.stem+'.o') for p in sources]+extras
 args=[str(obj) if x.endswith('/tests/ScriptTests.cpp.o') else x for x in b.link];args[args.index('-o')+1]=str(b.out/name);at=args.index(str(obj))+1;args[at:at]=[str(x) for x in extras]
 subprocess.run(args,cwd=b.build,check=True)
