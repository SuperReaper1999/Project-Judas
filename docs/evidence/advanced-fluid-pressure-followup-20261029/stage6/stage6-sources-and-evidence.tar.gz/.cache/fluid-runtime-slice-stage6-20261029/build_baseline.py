from pathlib import Path
import sys,subprocess
root=Path.cwd();here=root/'.cache/fluid-runtime-slice-stage6-20261029';base=here/'baseline-src'
sys.path.insert(0,str(root/'.cache/fluid-contact-repair'));import setup_probes as b
b.compile_flags=['-I'+str(base),*b.compile_flags]
modules=[base/'PhysicsWorld.cpp',base/'JointSolver.cpp',*sorted((base/'physics').glob('*.cpp'))]
# The retained private reference replaces only the old native Mk2 translation
# unit; all other baseline physics modules/headers are exact checkpoint bytes.
modules=[p for p in modules if p.name!='WorldMk2Solver.cpp']
modules.append(root/'.cache/fluid-coupling-stage5-20261029/WorldMk2Batch.cpp')
objects=[b.compile(p,'stage6-baseline-'+p.stem) for p in modules]
main=b.compile(root/'.cache/fluid-coupling-stage5-20261029/NativeAleBatch.cpp','stage6-baseline-private-ale')
args=[str(main) if x.endswith('/tests/ScriptTests.cpp.o') else x for x in b.link]
args[args.index('-o')+1]=str(b.out/'stage6-baseline-private-ale')
at=args.index(str(main))+1;args[at:at]=[str(p) for p in objects]+[str(b.out/'stage5-exact-volume-domain.o')]
subprocess.run(args,cwd=b.build,check=True)
