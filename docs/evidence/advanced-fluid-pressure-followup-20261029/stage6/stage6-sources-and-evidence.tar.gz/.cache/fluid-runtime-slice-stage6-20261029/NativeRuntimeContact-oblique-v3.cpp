#define main retained_tetra_main
#include "../fluid-runtime-slice-stage6-kernel/TetraPressureTests.cpp"
#undef main
#include "PhysicsWorld.h"
#include "PhysicsConstraintBatch.h"
#include "../fluid-coupling-stage5-20261029/NativeConstraintReduction.h"
#include <functional>
static unsigned checks=0;
void Check(bool yes,const char* what){++checks;if(!yes)throw std::runtime_error(what);}
void Run(float angle){
 Model fluid;BuildTetra(fluid,false,0,.25,true);
 const auto view=glm::angleAxis(angle,glm::normalize(glm::vec3(1,-2,3)));const glm::dquat turn=glm::normalize(glm::dquat(view));
 const V up=turn*V(0,1,0),side=turn*V(1,0,0);fluid.frame=glm::mat3_cast(turn);
 for(auto& row:fluid.rows){for(auto& g:row.points)g.gradient=turn*g.gradient;for(auto& g:row.bodies){g.linear=turn*g.linear;g.angular=turn*g.angular;}}
 const auto baseRows=fluid.rows;const auto flags=fluid.bilateral;
 PhysicsWorld world;world.Init();world.SetSleepingEnabled(false);
 world.CreateStaticBox(glm::vec3(turn*V(4.75,.125,.125)),view,{.5f,2,2},0,0);
 auto body=world.CreateDynamicBox(glm::vec3(turn*V(2.25,.125,.125)),{2,2,2},80,0,0);world.ResetBody(body,glm::vec3(turn*V(2.25,.125,.125)),view);
 const auto initial=world.GetTransform(body);
 unsigned intervals=0;double maxSpeed=0,maxResidual=0,maxEnergyIncrease=0,minimumSupport=INFINITY;
 V pressureImpulse(0),pressureTorque(0),contactImpulse(0),contactTorque(0);std::vector<double> times;
 std::vector<Point> pendingPoints;V pendingForce(0),pendingTorque(0),pendingContact(0),pendingContactTorque(0);unsigned published=0;
 SparseWorkspace workspace;
 PhysicsConstraintParticipant participant;participant.bodies={body};
 participant.propose=[&](const PhysicsConstraintBatch& batch,PhysicsConstraintProposal& proposal){
  const float h=batch.context.deltaTime;
  std::vector<RigidBody> state(batch.bodies.size());std::vector<Stage5Body> nativeBodies;
  for(unsigned i=0;i<batch.bodies.size();++i){const auto& b=batch.bodies[i];state[i].position=b.center;state[i].orientation=b.orientation;state[i].linearVelocity=b.linearVelocity;state[i].angularVelocity=b.angularVelocity;nativeBodies.push_back({&state[i],b.inverseMass,M(b.inverseInertia)});}
  const auto& nativeRows=batch.contacts;const auto& joints=batch.joints;
  proposal.linearImpulses.assign(batch.bodies.size(),V(0));proposal.angularImpulses.assign(batch.bodies.size(),V(0));proposal.contactImpulses.assign(batch.contacts.size(),0);proposal.jointImpulses.assign(batch.joints.size(),0);

  const auto begin=std::chrono::steady_clock::now();++intervals;
  Check(joints.empty()&&nativeRows.size()==4,"four actual native manifold points required");
  auto model=fluid;model.rows=baseRows;model.bilateral=flags;model.bodies.clear();
  unsigned owner=unsigned(nativeBodies.size());
  for(unsigned i=0;i<nativeBodies.size();++i){const auto& b=nativeBodies[i];model.bodies.push_back({V(b.state->linearVelocity),V(b.state->angularVelocity),b.inverseMass,b.inverseInertia});if(batch.bodies[i].handle.id==body.id&&batch.bodies[i].handle.world==body.world)owner=i;}
  Check(owner<nativeBodies.size(),"water-contact owner missing");
  for(auto& row:model.rows)for(auto& g:row.bodies)g.body=owner;
  for(const auto& cell:model.cells)model.points[cell.first].velocity-=up*(9.81*double(h));
  for(const auto& r:nativeRows){Row row;row.bodies.push_back({r.a,-V(r.normal),-V(glm::cross(r.armA,r.normal))});row.bodies.push_back({r.b,V(r.normal),V(glm::cross(r.armB,r.normal))});row.maximumRate=-r.minimumNormalSpeed;model.Add(row,false);}
  const auto original=model;auto encoded=model;
  const auto energy=[](const Model& m){double e=0;for(auto p:m.points)e+=.5*glm::dot(p.velocity,p.velocity)/p.inverseMass;for(auto b:m.bodies)if(b.inverseMass>0)e+=.5*glm::dot(b.velocity,b.velocity)/b.inverseMass+.5*glm::dot(b.angularVelocity,glm::inverse(b.inverseInertia)*b.angularVelocity);return e;};
  const double before=energy(original);const auto solved=ProjectFluidPressure(encoded,64,1e-10,&workspace);
  Check(solved.converged,"side-contact full 3D pressure did not converge");
  std::vector<double> reaction;
  for(unsigned i=0;i<nativeRows.size();++i)reaction.push_back(solved.pressureImpulse[baseRows.size()+i]);
  for(unsigned i=0;i<reaction.size();++i){minimumSupport=std::min(minimumSupport,reaction[i]);Check(reaction[i]>=0,"assumed active contact needs tensile reaction; must release instead of clamping");}
  maxEnergyIncrease=std::max(maxEnergyIncrease,energy(encoded)-before);
  pendingForce=V(0);pendingTorque=V(0);pendingContact=V(0);pendingContactTorque=V(0);
  for(unsigned i=0;i<baseRows.size();++i)for(auto g:original.rows[i].bodies){proposal.linearImpulses[g.body]-=g.linear*solved.pressureImpulse[i];proposal.angularImpulses[g.body]-=g.angular*solved.pressureImpulse[i];if(g.body==owner){pendingForce-=g.linear*solved.pressureImpulse[i];pendingTorque-=g.angular*solved.pressureImpulse[i];}}
  for(unsigned i=0;i<nativeRows.size();++i){proposal.contactImpulses[i]=float(reaction[i]);const auto& r=nativeRows[i];const V normal(r.normal);
   if(r.a==owner){pendingContact+=normal*reaction[i];pendingContactTorque+=glm::cross(V(r.armA),normal)*reaction[i];}
   if(r.b==owner){pendingContact-=normal*reaction[i];pendingContactTorque-=glm::cross(V(r.armB),normal)*reaction[i];}}
  pendingPoints=std::move(encoded.points);maxResidual=std::max(maxResidual,solved.maximumResidual);
  times.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count());return true;
 };
 participant.published=[&](const auto&) noexcept {fluid.points.swap(pendingPoints);pressureImpulse+=pendingForce;pressureTorque+=pendingTorque;contactImpulse+=pendingContact;contactTorque+=pendingContactTorque;++published;};
 auto coupling=PhysicsWorld::VelocityCoupling::ForEachSubstep(2,[](const auto&){},[&](const auto&){maxSpeed=std::max(maxSpeed,double(glm::length(world.GetLinearVelocity(body))+glm::length(world.GetAngularVelocity(body))));});
 coupling.physicalBatch=&participant;
 for(unsigned tick=0;tick<120;++tick)world.Step(1.f/60,&coupling);
 Check(published==480,"native/material publications match all intervals");
 const double expected=1000*9.81*.25*.25*.25*.5*120*double(1.f/60);
 std::vector<PhysicsWorld::BodyContactSample> contacts;
 Check(world.ReadBodyContactSample(body,contacts),"native support samples unavailable");
 V observed(0);for(const auto& c:contacts)observed+=V(c.normal)*double(c.normalImpulse);
 Check(intervals==480,"not every chronological pressure/contact boundary participated");
 Check(maxSpeed<1e-5&&glm::length(world.GetTransform(body).position-initial.position)<1e-5,"actual native endpoint moved");
 Check(std::abs(glm::dot(pressureImpulse,side)-expected)<1e-5&&std::abs(glm::dot(pressureImpulse,up))<1e-7,"side hydrostatic load is wrong or launches body vertically");
 Check(glm::length(pressureImpulse+contactImpulse)<1e-6&&glm::length(pressureTorque+contactTorque)<1e-6,"native contact reaction does not balance pressure wrench");
 Check(std::abs(glm::dot(observed,side)+expected/120)<1e-5,"completed native contact load does not match physical pressure");
 Check(maxEnergyIncrease<1e-8,"side contact pressure projection created energy");
 std::sort(times.begin(),times.end());
 std::printf("{\"kind\":\"actual-3D-side-contact\",\"intervals\":%u,\"tets\":%zu,\"actualMaximumSpeed\":%.17g,\"pressureX\":%.17g,\"pressureY\":%.17g,\"expectedPressureX\":%.17g,\"reactionWrenchResidual\":%.17g,\"minimumNativeContactImpulse\":%.17g,\"actualContactPoints\":%zu,\"actualLastContactImpulseX\":%.17g,\"pressureResidual\":%.17g,\"maximumEnergyIncrease\":%.17g,\"medianMilliseconds\":%.17g,\"p95Milliseconds\":%.17g,\"worstMilliseconds\":%.17g}\n",intervals,fluid.cells.size(),maxSpeed,pressureImpulse.x,pressureImpulse.y,expected,glm::length(pressureImpulse+contactImpulse)+glm::length(pressureTorque+contactTorque),minimumSupport,contacts.size(),observed.x,maxResidual,maxEnergyIncrease,times[times.size()/2],times[unsigned(std::ceil(.95*times.size()))-1],times.back());
 std::printf("FRAME angle=%.9g\n",angle);
}
int main(){try{Run(0);Run(1.13f);std::printf("SUMMARY checks=%u failures=0 scope=actual-native-3D-pressure-contact-patch\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks: %s\n",checks,e.what());return 1;}}
