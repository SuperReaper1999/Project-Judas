#pragma once
#include "LocalResponses.h"
#include "LoadSolver.h"
namespace compatible_flux_extended {
struct LoadRuntime {
 ResponseOperators responses;
 LoadConservativeSolver solver;
 KineticLoads loads;
 explicit LoadRuntime(MacroSystem input):responses(std::move(input)),solver(responses.operators.reference.coarse),loads(solver.MakeLoads(responses.operators.reference.coarse.predictor)){}
};
inline void RefreshLoadRuntime(LoadRuntime& runtime,const Vector& predictor){
 // All potentially failing computation precedes publication. A new source
 // never partly changes the body force, local field or retained-mode energy.
 auto staged=StageResponses(runtime.responses,predictor);
 auto loads=runtime.solver.MakeLoads(staged.source.coarse);
 runtime.loads.head.swap(loads.head);runtime.loads.fluid.swap(loads.fluid);runtime.loads.body.swap(loads.body);
 std::swap(runtime.loads.energy,loads.energy);std::swap(runtime.loads.owner,loads.owner);
 PublishResponses(runtime.responses,staged);
}
inline ProfileResult ProjectLoadRuntime(const LoadRuntime& runtime,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 const auto start=std::chrono::steady_clock::now();
 auto result=ReconstructResponses(runtime.responses,runtime.solver.Solve(runtime.loads,body),body);
 result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
}
