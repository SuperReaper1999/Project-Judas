#pragma once
#include "../fluid-compatible-flux-stage9-20261029/MacroCondensation.h"
namespace compatible_flux_extended {
struct ProfileResult:MacroResult {double localMs=0,rawFieldMs=0,pressureMs=0,finalChecksMs=0;};
inline ProfileResult ReconstructProfiled(const MacroSystem& sys,const ConservativeResult& solved,const Eigen::Matrix<Real,6,1>& body){
 const auto stepStart=std::chrono::steady_clock::now();ProfileResult result;static_cast<ConservativeResult&>(result)=solved;if(!result.accepted)return result;
 const auto& raw=sys.raw;Vector scaled=sys.trace*result.flux;Vector physicalPressure=Vector::Zero(raw.divergence.rows());unsigned pressureOffset=0;
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const Vector residual=local.predicted-local.Y*result.flux-local.Ybody*body;const Vector free=local.qr->solve(residual),dependent=-local.Cfree*free-local.Cboundary*result.flux-local.Cbody*body;
  for(unsigned j=0;j<local.pivotVariables.size();++j)scaled[local.inside[local.pivotVariables[j]]]=dependent[j];for(unsigned j=0;j<local.freeVariables.size();++j)scaled[local.inside[local.freeVariables[j]]]=free[j];
  for(auto r:local.remainingRows)physicalPressure[4*m+r]=result.pressure[pressureOffset++];
 }
 const auto timeLocal=std::chrono::steady_clock::now();result.localMs=std::chrono::duration<double,std::milli>(timeLocal-stepStart).count();
 const Vector actual=raw.fluid*scaled+raw.body*body,residual=raw.predictor-actual,gradient=raw.fluid.transpose()*residual;
 const auto timeRaw=std::chrono::steady_clock::now();result.rawFieldMs=std::chrono::duration<double,std::milli>(timeRaw-timeLocal).count();
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const unsigned rank=local.pivotVariables.size();Vector rhs(rank);for(unsigned j=0;j<rank;++j)rhs[j]=gradient[local.inside[local.pivotVariables[j]]];for(unsigned r=0;r<local.remainingRows.size();++r)rhs.noalias()-=local.remainingPivot.row(r).transpose()*physicalPressure[4*m+local.remainingRows[r]];if(rank){const Vector p=local.pivot.transpose().fullPivLu().solve(rhs);for(unsigned r=0;r<rank;++r)physicalPressure[4*m+local.pivotRows[r]]=p[r];}}
 const auto timePressure=std::chrono::steady_clock::now();result.pressureMs=std::chrono::duration<double,std::milli>(timePressure-timeRaw).count();
 const auto reaction=raw.body.transpose()*residual-raw.bodyDivergence.transpose()*physicalPressure;result.reactionError=(reaction-result.reaction).norm();result.reconstructedBalance=(raw.divergence*scaled+raw.bodyDivergence*body).lpNorm<Eigen::Infinity>();result.primaryFlux=scaled.cwiseProduct(raw.columnScale);result.fullEnergy=.5*actual.squaredNorm();
 if(result.reactionError>1e-8||result.reconstructedBalance>1e-10||std::abs(result.fullEnergy-(result.energyAfter+sys.retainedEnergy))>1e-9){result.accepted=false;result.error="macro reconstruction violates original work/balance";}result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-stepStart).count();result.finalChecksMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-timePressure).count();return result;
}

}
