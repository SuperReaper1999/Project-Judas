#pragma once
#include "RuntimeOperators.h"
namespace compatible_flux_extended {
template<class F>Vector MakePredictor(const System& sys,F velocity){
 Eigen::Matrix<Real,4,4> reference=Eigen::Matrix<Real,4,4>::Constant(1.L/20);
 reference.diagonal().array()+=1.L/20;
 const Eigen::Matrix<Real,4,4> root=reference.llt().matrixL();
 Vector predictor(sys.predictor.size());
 for(unsigned c=0;c<sys.cells.size();++c){
  const auto& cell=sys.cells[c];const RV origin=sys.positions[cell.vertices[0]];
  const R volume=Dot(Sub(sys.positions[cell.vertices[1]],origin),Cross(Sub(sys.positions[cell.vertices[2]],origin),Sub(sys.positions[cell.vertices[3]],origin)))/6;
  const Real massRoot=std::sqrt(1000.L*ToDouble(volume));
  for(unsigned axis=0;axis<3;++axis)for(unsigned k=0;k<4;++k){
   Real value=0;for(unsigned v=0;v<4;++v){const auto& p=sys.positions[cell.vertices[v]];const V physical(p[0].convert_to<double>(),p[1].convert_to<double>(),p[2].convert_to<double>());value+=massRoot*root(v,k)*velocity(physical)[axis];}
   predictor[c*12+axis*4+k]=value;
  }
 }
 return predictor;
}
}
