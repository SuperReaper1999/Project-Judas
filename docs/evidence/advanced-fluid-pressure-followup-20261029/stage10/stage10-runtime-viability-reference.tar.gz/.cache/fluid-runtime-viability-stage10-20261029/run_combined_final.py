import subprocess,json,hashlib,time,platform
from pathlib import Path
p=Path(__file__).resolve().parent
names=['ResponseRefreshTests','LoadSolverTests','LoadRefreshTests','NativeLoadTests','MaterialLoadTests','LoadBenchmarkTests']
results=[]
for name in names:
 start=time.time();log=p/(name+'-final.log')
 with log.open('w') as out: r=subprocess.run(['python3',str(p/'run_probe.py'),name],stdout=out,stderr=subprocess.STDOUT)
 row={'name':name,'sourceSha256':hashlib.sha256((p/(name+'.cpp')).read_bytes()).hexdigest(),'returncode':r.returncode,'wallSeconds':time.time()-start,'log':log.name,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(row)
 (p/'COMBINED_FINAL_RUNS.json').write_text(json.dumps({'cases':results},indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
