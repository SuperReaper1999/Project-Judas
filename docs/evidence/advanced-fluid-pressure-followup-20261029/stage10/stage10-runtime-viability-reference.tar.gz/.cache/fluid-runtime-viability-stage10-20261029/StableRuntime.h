#pragma once
#include "RuntimeOperators.h"
namespace compatible_flux_extended {
// Preserve original local arithmetic and QR order. Sparse divergence is used
// only for the independent balance check, never to construct physical flux.
inline ProfileResult ReconstructStable(const RuntimeOperators& operators,const ConservativeResult& solved,const Eigen::Matrix<Real,6,1>& body){
 const auto start=std::chrono::steady_clock::now();ProfileResult result;static_cast<ConservativeResult&>(result)=solved;if(!result.accepted)return result;
 const auto& sys=operators.reference;const auto& raw=sys.raw;
 Vector scaled=sys.trace*result.flux;
 Vector physicalPressure=Vector::Zero(raw.divergence.rows());unsigned pressureOffset=0;
 for(unsigned m=0;m<sys.local.size();++m){
  const auto& local=sys.local[m];
  const Vector residual=local.predicted-local.Y*result.flux-local.Ybody*body;
  const Vector free=local.qr->solve(residual);
  const Vector dependent=-local.Cfree*free-local.Cboundary*result.flux-local.Cbody*body;
  for(unsigned j=0;j<local.pivotVariables.size();++j)scaled[local.inside[local.pivotVariables[j]]]=dependent[j];
  for(unsigned j=0;j<local.freeVariables.size();++j)scaled[local.inside[local.freeVariables[j]]]=free[j];
  for(auto row:local.remainingRows)physicalPressure[4*m+row]=result.pressure[pressureOffset++];
 }
 const auto timeLocal=std::chrono::steady_clock::now();result.localMs=std::chrono::duration<double,std::milli>(timeLocal-start).count();
 const Vector actual=raw.fluid*scaled+raw.body*body;
 const Vector residual=raw.predictor-actual;
 const Vector gradient=raw.fluid.transpose()*residual;
 const auto timeRaw=std::chrono::steady_clock::now();result.rawFieldMs=std::chrono::duration<double,std::milli>(timeRaw-timeLocal).count();
 for(unsigned m=0;m<sys.local.size();++m){
  const auto& local=sys.local[m];const unsigned rank=local.pivotVariables.size();Vector rhs(rank);
  for(unsigned j=0;j<rank;++j)rhs[j]=gradient[local.inside[local.pivotVariables[j]]];
  for(unsigned row=0;row<local.remainingRows.size();++row)rhs.noalias()-=local.remainingPivot.row(row).transpose()*physicalPressure[4*m+local.remainingRows[row]];
  if(rank){const Vector pressure=local.pivot.transpose().fullPivLu().solve(rhs);for(unsigned row=0;row<rank;++row)physicalPressure[4*m+local.pivotRows[row]]=pressure[row];}
 }
 const auto timePressure=std::chrono::steady_clock::now();result.pressureMs=std::chrono::duration<double,std::milli>(timePressure-timeRaw).count();
 const auto reaction=raw.body.transpose()*residual-raw.bodyDivergence.transpose()*physicalPressure;
 result.reactionError=(reaction-result.reaction).norm();
 result.reconstructedBalance=(operators.divergence*scaled+raw.bodyDivergence*body).lpNorm<Eigen::Infinity>();
 result.primaryFlux=scaled.cwiseProduct(raw.columnScale);result.fullEnergy=.5*actual.squaredNorm();
 if(result.reactionError>1e-8||result.reconstructedBalance>1e-10||std::abs(result.fullEnergy-(result.energyAfter+sys.retainedEnergy))>1e-9){result.accepted=false;result.error="runtime reconstruction violates original work/balance";}
 result.finalChecksMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-timePressure).count();
 result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
inline ProfileResult ProjectStable(const RuntimeOperators& operators,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 const auto start=std::chrono::steady_clock::now();const auto& sys=operators.reference;
 auto result=ReconstructStable(operators,sys.prepared->Solve(sys.coarse.predictor,body),body);
 result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
}
