#include "PhysicalPredictor.h"
#include <cstdio>
int main(){using namespace compatible_flux_extended;unsigned checks=0;try{auto q=glm::angleAxis(.37,glm::normalize(V(1,2,-.3)));auto geometry=owned_cut::Prepare(1,V(.5),V(.2),q);RuntimeOperators cached(Condense(Build(std::move(geometry),{0,-9.81/240,0},1)));for(unsigned trial=0;trial<2;++trial){
 const auto velocity=[&](V point){return V(.01,-9.81/240,.02)+double(trial+1)*glm::cross(V(.01,.02,-.03),point-V(.5));};
 const Vector source=MakePredictor(cached.reference.raw,velocity);auto independentRaw=cached.reference.raw;independentRaw.predictor=source;const auto independent=Condense(std::move(independentRaw));RefreshPredictor(cached,source);
 ++checks;if(!(cached.reference.coarse.predictor.array()==independent.coarse.predictor.array()).all()||cached.reference.retainedEnergy!=independent.retainedEnergy)throw std::runtime_error("refreshed source differs from independent fresh condensation");
 const auto expected=ProjectMacro(independent);const auto actual=ProjectRuntime(cached);++checks;if(!expected.accepted||!actual.accepted||(expected.primaryFlux-actual.primaryFlux).lpNorm<Eigen::Infinity>()>1e-12||(expected.reaction-actual.reaction).norm()>1e-12||std::abs(expected.fullEnergy-actual.fullEnergy)>1e-12)throw std::runtime_error("source refresh changes physical solve");
 std::printf("SOURCE_REFRESH trial=%u exact_modal_source_match=1 flux_difference=%g energy_difference=%g retained_mode_energy=%g\n",trial,double((expected.primaryFlux-actual.primaryFlux).lpNorm<Eigen::Infinity>()),std::abs(expected.fullEnergy-actual.fullEnergy),cached.reference.retainedEnergy);
 }
 const auto before=cached.reference.raw.predictor;Vector invalid(before.size()-1);invalid.setZero();bool rejected=false;try{RefreshPredictor(cached,invalid);}catch(const std::invalid_argument&){rejected=true;}++checks;if(!rejected||!(cached.reference.raw.predictor.array()==before.array()).all())throw std::runtime_error("invalid source shape partly publishes state");
 std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
