#pragma once
#include "../fluid-compatible-flux-stage9-20261029/ConservativeElimination.h"
#include <atomic>
namespace compatible_flux_extended {
// Value-owned immutable operators. A changed geometry/mass/constraint matrix
// requires constructing a NEW instance. Only the predictor and prescribed
// boundary velocity vary between solves; no native handle/pose is cached here.
struct KineticLoads {Vector fluid,head;Eigen::Matrix<Real,6,1> body;double energy=0;std::uint64_t owner=0;};
class LoadConservativeSolver {
 Sparse fluid,reduced;
 Dense sourceBasis;
 Dense R,pivotHead,pivotTailBody,bodyHead,bodyTail,particularBody;
 std::uint64_t identity=0;
 Dense bodyMatrix,D,bodyD,C,lift,pivot;
 Vector scale;
 std::vector<unsigned> columns,rows;
 unsigned rank=0,variables=0;
 Eigen::FullPivLU<Dense> pivotFactor;
 Eigen::SparseQR<Sparse,Eigen::COLAMDOrdering<int>> qr;
public:
 double preparationMs=0;
 explicit LoadConservativeSolver(const System& sys):fluid(sys.fluid),bodyMatrix(sys.body),D(sys.divergence),bodyD(sys.bodyDivergence),scale(sys.columnScale),variables(sys.variables){
  static std::atomic<std::uint64_t> next{1};identity=next.fetch_add(1);
  const auto start=std::chrono::steady_clock::now();Eigen::FullPivLU<Dense> elimination(D);rank=elimination.rank();const auto order=elimination.permutationQ().indices();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverse=elimination.permutationP().inverse();for(unsigned j=0;j<variables;++j)columns.push_back(order[j]);for(unsigned i=0;i<rank;++i)rows.push_back(inverse.indices()[i]);
  pivot.resize(rank,rank);Dense remainder(rank,variables-rank);for(unsigned i=0;i<rank;++i){for(unsigned j=0;j<rank;++j)pivot(i,j)=D(rows[i],columns[j]);for(unsigned j=rank;j<variables;++j)remainder(i,j-rank)=D(rows[i],columns[j]);}
  pivotFactor.compute(pivot);if(unsigned(pivotFactor.rank())!=rank)throw std::runtime_error("prepared conservation pivot failure");C=pivotFactor.solve(remainder);lift=Dense::Zero(fluid.rows(),rank);std::set<unsigned> supported;
  for(unsigned k=0;k<rank;++k)for(Sparse::InnerIterator it(fluid,columns[k]);it;++it){lift(it.row(),k)=it.value();supported.insert(it.row());}
  std::vector<Eigen::Triplet<Real>> entries;for(unsigned j=rank;j<variables;++j){for(Sparse::InnerIterator it(fluid,columns[j]);it;++it)entries.emplace_back(it.row(),j-rank,it.value());for(auto row:supported){Real value=0;for(unsigned k=0;k<rank;++k)value+=lift(row,k)*C(k,j-rank);if(value!=0)entries.emplace_back(row,j-rank,-value);}}
  reduced.resize(fluid.rows(),variables-rank);reduced.setFromTriplets(entries.begin(),entries.end());reduced.makeCompressed();qr.compute(reduced);if(qr.info()!=Eigen::Success||unsigned(qr.rank())!=variables-rank)throw std::runtime_error("prepared compatible kinetic rank loss");
  const unsigned free=variables-rank;
  // Preserve the orthogonal source projection; do not reconstruct it through
  // R^-T A^T b, which squares conditioning in thin cuts.
  sourceBasis=qr.matrixQ()*Dense::Identity(fluid.rows(),free);
  const Eigen::SparseMatrix<Real,Eigen::RowMajor> sorted=qr.matrixR();
  const Sparse triangle=sorted.topLeftCorner(free,free);R=Dense(triangle);
  Dense selected(rank,6);for(unsigned i=0;i<rank;++i)selected.row(i)=-bodyD.row(rows[i]);
  particularBody=pivotFactor.solve(selected);
  const Dense liftedBody=bodyMatrix+lift*particularBody;
  const Dense rotatedBody=qr.matrixQ().adjoint()*liftedBody;
  const Dense rotatedPivot=qr.matrixQ().adjoint()*lift;
  bodyHead=rotatedBody.topRows(free);bodyTail=rotatedBody.bottomRows(fluid.rows()-free);
  pivotHead=rotatedPivot.topRows(free);
  pivotTailBody=rotatedPivot.bottomRows(fluid.rows()-free).transpose()*bodyTail;
  preparationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 }
 KineticLoads MakeLoads(const Vector& predictor)const{
  if(predictor.size()!=fluid.rows()||!predictor.allFinite())throw std::invalid_argument("invalid kinetic load predictor");
  KineticLoads result;result.head=sourceBasis.transpose()*predictor;result.fluid=fluid.transpose()*predictor;result.body=bodyMatrix.transpose()*predictor;result.energy=.5*predictor.squaredNorm();result.owner=identity;
  if(!result.head.allFinite()||!result.fluid.allFinite()||!result.body.allFinite()||!std::isfinite(result.energy))throw std::invalid_argument("kinetic loads exceed finite range");
  return result;
 }
 ConservativeResult Solve(const KineticLoads& source,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero())const{
  ConservativeResult result;try{
   const auto start=std::chrono::steady_clock::now();
   if(source.owner!=identity||source.head.size()!=variables-rank||!source.head.allFinite()||source.fluid.size()!=variables||!source.fluid.allFinite()||!source.body.allFinite()||!std::isfinite(source.energy)||!body.allFinite())throw std::invalid_argument("stale or invalid kinetic loads");
   const unsigned free=variables-rank;result.pressureRank=rank;result.rank=free;
   Vector gp(rank),gf(free);for(unsigned j=0;j<rank;++j)gp[j]=source.fluid[columns[j]];for(unsigned j=rank;j<variables;++j)gf[j-rank]=source.fluid[columns[j]];
   const Vector reducedLoad=gf-C.transpose()*gp;
   // SparseQR factors A*P = Q*R; both loads and free coordinates
   // must use that same column permutation.
   const Vector y=source.head-bodyHead*body;
   const Vector ordered=R.triangularView<Eigen::Upper>().solve(y);
   const Vector independent=qr.colsPermutation()*ordered;
   const Vector dependent=particularBody*body-C*independent;
   Vector z(variables);for(unsigned j=0;j<rank;++j)z[columns[j]]=dependent[j];for(unsigned j=rank;j<variables;++j)z[columns[j]]=independent[j-rank];
   const Vector kineticHead=R*ordered+bodyHead*body,kineticTail=bodyTail*body;
   const Vector actualPivot=pivotHead.transpose()*kineticHead+pivotTailBody*body;
   const Vector pivotGradient=gp-actualPivot;
   const Vector multipliers=pivot.transpose().fullPivLu().solve(pivotGradient);
   result.pressure=Vector::Zero(D.rows());for(unsigned i=0;i<rank;++i)result.pressure[rows[i]]=multipliers[i];
   const Vector freeGradient=gf-qr.colsPermutation()*(R.transpose()*kineticHead)-C.transpose()*actualPivot;
   Vector gradient(variables);for(unsigned j=0;j<rank;++j)gradient[columns[j]]=pivotGradient[j];for(unsigned j=rank;j<variables;++j)gradient[columns[j]]=freeGradient[j-rank];
   result.stationarity=(gradient-D.transpose()*result.pressure).lpNorm<Eigen::Infinity>();result.residual=(D*z+bodyD*body).lpNorm<Eigen::Infinity>();result.flux=z.cwiseProduct(scale);
   result.reaction=source.body-bodyHead.transpose()*kineticHead-bodyTail.transpose()*kineticTail+particularBody.transpose()*actualPivot-bodyD.transpose()*result.pressure;
   result.energyBefore=source.energy;result.energyAfter=.5*(kineticHead.squaredNorm()+kineticTail.squaredNorm());result.solveMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
   if(!z.allFinite()||!result.reaction.allFinite()||!result.pressure.allFinite()||result.stationarity>1e-10||result.residual>1e-10)throw std::runtime_error("load-space kinetic/work verification failed");
   if(body.norm()==0&&result.energyAfter>result.energyBefore+1e-9)throw std::runtime_error("load-space projection creates energy");
   result.accepted=true;
  }catch(const std::exception& e){result.error=e.what();}return result;
 }
};
}
