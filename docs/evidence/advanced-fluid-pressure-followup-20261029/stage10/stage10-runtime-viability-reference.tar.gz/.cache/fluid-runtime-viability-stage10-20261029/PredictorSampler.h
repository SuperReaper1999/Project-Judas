#pragma once
#include "PhysicalPredictor.h"
namespace compatible_flux_extended {
// Value-owned geometry epoch. Reconstruct this object after any geometry or
// density change. Velocity callbacks are pure samples in physical coordinates.
struct PredictorSampler {
 std::vector<std::array<V,4>> points;
 std::vector<Eigen::Matrix<Real,4,4>> weights;
 explicit PredictorSampler(const System& sys){
  Eigen::Matrix<Real,4,4> reference=Eigen::Matrix<Real,4,4>::Constant(1.L/20);
  reference.diagonal().array()+=1.L/20;
  const Eigen::Matrix<Real,4,4> root=reference.llt().matrixL();
  for(const auto& cell:sys.cells){
   const RV origin=sys.positions[cell.vertices[0]];
   const R volume=Dot(Sub(sys.positions[cell.vertices[1]],origin),Cross(Sub(sys.positions[cell.vertices[2]],origin),Sub(sys.positions[cell.vertices[3]],origin)))/6;
   const Real massRoot=std::sqrt(1000.L*ToDouble(volume));
   std::array<V,4> vertices;
   for(unsigned v=0;v<4;++v){const auto& p=sys.positions[cell.vertices[v]];vertices[v]=V(p[0].convert_to<double>(),p[1].convert_to<double>(),p[2].convert_to<double>());}
   points.push_back(vertices);weights.push_back(massRoot*root);
  }
 }
 template<class F>Vector Sample(F velocity)const{
  Vector result(12*points.size());
  for(unsigned c=0;c<points.size();++c){
   std::array<V,4> values;for(unsigned v=0;v<4;++v)values[v]=velocity(points[c][v]);
   for(unsigned axis=0;axis<3;++axis)for(unsigned k=0;k<4;++k){Real value=0;for(unsigned v=0;v<4;++v)value+=weights[c](v,k)*values[v][axis];result[c*12+axis*4+k]=value;}
  }
  if(!result.allFinite())throw std::invalid_argument("nonfinite sampled kinetic predictor");
  return result;
 }
};
}
