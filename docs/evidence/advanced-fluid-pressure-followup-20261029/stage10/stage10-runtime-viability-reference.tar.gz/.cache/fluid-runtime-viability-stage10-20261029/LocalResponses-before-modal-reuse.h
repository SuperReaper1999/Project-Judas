#pragma once
#include "RuntimeOperators.h"
namespace compatible_flux_extended {
struct LocalResponse {
 std::vector<unsigned> columns;
 Dense freeBoundary,freeBody,dependentBoundary,dependentBody;
 Vector freeSource,dependentSource;
};
struct ResponseOperators {
 RuntimeOperators operators;
 std::vector<LocalResponse> responses;
 double preparationMs=0;
 explicit ResponseOperators(MacroSystem input):operators(std::move(input)){
  const auto start=std::chrono::steady_clock::now();
  for(const auto& local:operators.reference.local){
   LocalResponse response;
   for(int c=0;c<local.Y.cols();++c)if((local.Y.col(c).array()!=0).any()||(local.Cboundary.col(c).array()!=0).any())response.columns.push_back(c);
   Dense boundary(local.Y.rows(),response.columns.size()),constraint(local.Cboundary.rows(),response.columns.size());
   for(unsigned c=0;c<response.columns.size();++c){boundary.col(c)=local.Y.col(response.columns[c]);constraint.col(c)=local.Cboundary.col(response.columns[c]);}
   response.freeBoundary=local.qr->solve(boundary);response.freeBody=local.qr->solve(local.Ybody);
   response.dependentBoundary=local.Cfree*response.freeBoundary-constraint;
   response.dependentBody=local.Cfree*response.freeBody-local.Cbody;
   response.freeSource=local.qr->solve(local.predicted);
   response.dependentSource=-local.Cfree*response.freeSource;
   responses.push_back(std::move(response));
  }
  preparationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 }
};
inline void RefreshResponses(ResponseOperators& operators,const Vector& predictor){
 auto staged=StagePredictor(operators.operators,predictor);
 std::vector<Vector> free,dependent;
 for(unsigned m=0;m<staged.local.size();++m){
  const auto& local=operators.operators.reference.local[m];
  Vector candidate=local.qr->solve(staged.local[m]);
  Vector constrained=-local.Cfree*candidate;
  if(!candidate.allFinite()||!constrained.allFinite())throw std::invalid_argument("local kinetic source exceeds finite range");
  free.push_back(std::move(candidate));dependent.push_back(std::move(constrained));
 }
 PublishPredictor(operators.operators,staged);
 for(unsigned m=0;m<free.size();++m){operators.responses[m].freeSource.swap(free[m]);operators.responses[m].dependentSource.swap(dependent[m]);}
}
inline ProfileResult ReconstructResponses(const ResponseOperators& operators,const ConservativeResult& solved,const Eigen::Matrix<Real,6,1>& body){
 const auto start=std::chrono::steady_clock::now();ProfileResult result;static_cast<ConservativeResult&>(result)=solved;if(!result.accepted)return result;
 const auto& runtime=operators.operators;const auto& sys=runtime.reference;const auto& raw=sys.raw;
 Vector scaled=runtime.trace*result.flux,physicalPressure=Vector::Zero(raw.divergence.rows());unsigned pressureOffset=0;
 for(unsigned m=0;m<sys.local.size();++m){
  const auto& local=sys.local[m];const auto& response=operators.responses[m];Vector boundary(response.columns.size());
  for(unsigned c=0;c<response.columns.size();++c)boundary[c]=result.flux[response.columns[c]];
  const Vector free=response.freeSource-response.freeBoundary*boundary-response.freeBody*body;
  const Vector dependent=response.dependentSource+response.dependentBoundary*boundary+response.dependentBody*body;
  for(unsigned j=0;j<local.pivotVariables.size();++j)scaled[local.inside[local.pivotVariables[j]]]=dependent[j];
  for(unsigned j=0;j<local.freeVariables.size();++j)scaled[local.inside[local.freeVariables[j]]]=free[j];
  for(auto row:local.remainingRows)physicalPressure[4*m+row]=result.pressure[pressureOffset++];
 }
 const auto timeLocal=std::chrono::steady_clock::now();result.localMs=std::chrono::duration<double,std::milli>(timeLocal-start).count();
 const Vector actual=raw.fluid*scaled+raw.body*body,residual=raw.predictor-actual,gradient=raw.fluid.transpose()*residual;
 const auto timeRaw=std::chrono::steady_clock::now();result.rawFieldMs=std::chrono::duration<double,std::milli>(timeRaw-timeLocal).count();
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const unsigned rank=local.pivotVariables.size();Vector rhs(rank);for(unsigned j=0;j<rank;++j)rhs[j]=gradient[local.inside[local.pivotVariables[j]]];for(unsigned row=0;row<local.remainingRows.size();++row)rhs.noalias()-=local.remainingPivot.row(row).transpose()*physicalPressure[4*m+local.remainingRows[row]];if(rank){const Vector pressure=local.pivot.transpose().fullPivLu().solve(rhs);for(unsigned row=0;row<rank;++row)physicalPressure[4*m+local.pivotRows[row]]=pressure[row];}}
 const auto timePressure=std::chrono::steady_clock::now();result.pressureMs=std::chrono::duration<double,std::milli>(timePressure-timeRaw).count();
 const auto reaction=raw.body.transpose()*residual-raw.bodyDivergence.transpose()*physicalPressure;
 result.reactionError=(reaction-result.reaction).norm();result.reconstructedBalance=(runtime.divergence*scaled+raw.bodyDivergence*body).lpNorm<Eigen::Infinity>();result.primaryFlux=scaled.cwiseProduct(raw.columnScale);result.fullEnergy=.5*actual.squaredNorm();
 if(result.reactionError>1e-8||result.reconstructedBalance>1e-10||std::abs(result.fullEnergy-(result.energyAfter+sys.retainedEnergy))>1e-9){result.accepted=false;result.error="prepared responses violate original work/balance";}
 result.finalChecksMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-timePressure).count();result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
inline ProfileResult ProjectResponses(const ResponseOperators& operators,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 const auto start=std::chrono::steady_clock::now();const auto& sys=operators.operators.reference;
 auto result=ReconstructResponses(operators,sys.prepared->Solve(sys.coarse.predictor,body),body);
 result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
}
