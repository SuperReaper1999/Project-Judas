#include "RefinedRuntime.h"
#include "HighPrecisionOracle.h"
#include <cstdio>
using namespace compatible_flux_extended;
unsigned checks=0;void Check(bool x,const char* message){++checks;if(!x)throw std::runtime_error(message);}
int main(){try{for(double angle:{0.,3.2137858346770188e-11,.37}){
 RefinedOperators runtime(Condense(Build(owned_cut::Prepare(1,V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))),V(0),1)));
 auto& sys=runtime.base.operators.reference;PredictorSampler sampler(sys.raw);
 for(unsigned trial=0;trial<3;++trial){
  auto velocity=[&](V p){if(trial==2)return V(0);return double(trial+1)*V(.03*std::sin(5*p.y),-.04+.01*std::cos(3*p.z),.02*std::sin(4*p.x));};
  RefreshResponses(runtime.base,sampler.Sample(velocity));Eigen::Matrix<Real,6,1> body=Eigen::Matrix<Real,6,1>::Zero();if(trial==1)body<<.01,-.02,.03,.02,-.01,.03;
  const auto result=ProjectRefined(runtime,body);std::printf("FULL angle=%.17g trial=%u accepted=%d balance=%g reaction=%g energy=%g solve_ms=%g error=%s\n",angle,trial,result.accepted,result.reconstructedBalance,result.reactionError,result.fullEnergy,result.fullStepMs,result.error.c_str());
  Check(result.accepted,"full refined reconstruction rejected");double maximum=0;
  for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const auto& patch=runtime.patches[m];Frozen f;f.local=m;f.matrix=patch.matrix;f.rhs=local.predicted-local.Y*result.flux-local.Ybody*body;const auto gold=Solve<160>(f);Vector free(gold.size());
   for(unsigned c=0;c<gold.size();++c){free[c]=gold[c].convert_to<Real>();const auto index=local.inside[local.freeVariables[c]];const Number<160> error=abs(Number<160>(result.primaryFlux[index])-Number<160>(sys.raw.columnScale[index])*gold[c]);maximum=std::max(maximum,error.convert_to<double>());}
   const Vector dependent=-local.Cfree*free-local.Cboundary*result.flux-local.Cbody*body;
   for(unsigned c=0;c<local.pivotVariables.size();++c){const auto index=local.inside[local.pivotVariables[c]];maximum=std::max(maximum,double(std::abs(result.primaryFlux[index]-sys.raw.columnScale[index]*dependent[c])));}
   Check(maximum<=1e-12,"full free/dependent physical flux differs from independent local oracle");
  }
  if(trial==2)Check(result.fullEnergy==0&&result.primaryFlux.norm()==0&&result.reaction.norm()==0,"zero source retained stale state");
  std::printf("QUALIFIED angle=%.17g trial=%u all_local_flux_error=%g\n",angle,trial,maximum);
 }
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
