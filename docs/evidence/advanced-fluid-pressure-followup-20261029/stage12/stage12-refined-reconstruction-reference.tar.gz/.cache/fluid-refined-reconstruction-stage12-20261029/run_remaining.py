from pathlib import Path
import subprocess,json,time
folder=Path('.cache/fluid-refined-reconstruction-stage12-20261029');results=[]
for name in ['RefreshRefinedTests','NativeRefinedTests','MaterialRefinedTests','RefinedBenchmark']:
 start=time.time();log=folder/(name+'-first.log')
 with log.open('w') as f:r=subprocess.run(['python3',str(folder/'run_probe.py'),name],stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'returnCode':r.returncode,'seconds':time.time()-start,'log':str(log)})
 (folder/'REMAINING_FIRST_RUNS.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
