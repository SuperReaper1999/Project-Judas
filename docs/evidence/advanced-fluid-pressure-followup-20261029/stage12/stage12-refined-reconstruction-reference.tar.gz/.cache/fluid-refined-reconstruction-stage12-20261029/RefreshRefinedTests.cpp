#include "RefinedRuntime.h"
#include "../fluid-runtime-viability-stage10-20261029/PredictorSampler.h"
#include <cstdio>
int main(){using namespace compatible_flux_extended;unsigned checks=0;try{auto q=glm::angleAxis(.37,glm::normalize(V(1,2,-.3)));auto geometry=owned_cut::Prepare(1,V(.5),V(.2),q);RefinedOperators runtime(Condense(Build(std::move(geometry),{0,-9.81/240,0},1)));auto& cached=runtime.base.operators;PredictorSampler sampler(cached.reference.raw);for(unsigned trial=0;trial<2;++trial){
 const auto velocity=[&](V point){return V(.01,-9.81/240,.02)+double(trial+1)*glm::cross(V(.01,.02,-.03),point-V(.5));};
 const Vector source=MakePredictor(cached.reference.raw,velocity);const Vector sampled=sampler.Sample(velocity);++checks;if(!(source.array()==sampled.array()).all())throw std::runtime_error("prepared sampling changes physical predictor");auto independentRaw=cached.reference.raw;independentRaw.predictor=source;const auto independent=Condense(std::move(independentRaw));RefreshResponses(runtime.base,source);
 ++checks;if(!(cached.reference.coarse.predictor.array()==independent.coarse.predictor.array()).all()||cached.reference.retainedEnergy!=independent.retainedEnergy)throw std::runtime_error("refreshed source differs from independent fresh condensation");
 const auto expected=ProjectMacro(independent);const auto actual=ProjectRefined(runtime);++checks;if(!expected.accepted||!actual.accepted||(expected.primaryFlux-actual.primaryFlux).lpNorm<Eigen::Infinity>()>1e-12||(expected.reaction-actual.reaction).norm()>1e-12||std::abs(expected.fullEnergy-actual.fullEnergy)>1e-12)throw std::runtime_error("source refresh changes physical solve");
 std::printf("SOURCE_REFRESH trial=%u exact_modal_source_match=1 flux_difference=%g energy_difference=%g retained_mode_energy=%g\n",trial,double((expected.primaryFlux-actual.primaryFlux).lpNorm<Eigen::Infinity>()),std::abs(expected.fullEnergy-actual.fullEnergy),cached.reference.retainedEnergy);
 }
 const auto before=cached.reference.raw.predictor;const auto beforeResult=ProjectRefined(runtime);const auto coarse=cached.reference.coarse.predictor;
 for(unsigned mode=0;mode<3;++mode){Vector invalid=before;if(mode==0)invalid.conservativeResize(before.size()-1);if(mode==1)invalid[0]=NAN;if(mode==2)invalid.setConstant(1e200L);bool rejected=false;try{RefreshResponses(runtime.base,invalid);}catch(const std::invalid_argument&){rejected=true;}const auto result=ProjectRefined(runtime);++checks;if(!rejected||!result.accepted||!(cached.reference.raw.predictor.array()==before.array()).all()||!(cached.reference.coarse.predictor.array()==coarse.array()).all()||!(result.primaryFlux.array()==beforeResult.primaryFlux.array()).all()||result.fullEnergy!=beforeResult.fullEnergy)throw std::runtime_error("invalid source partly publishes physical state");}
 
 // Refusal must be observable without publishing changed source/physical state.
 const auto predictor=cached.reference.raw.predictor;
 const auto last=ProjectRefined(runtime);
 auto& patch=runtime.patches[0];const auto& local=cached.reference.local[0];
 const Vector rhs=local.predicted-local.Y*last.flux;
 const Vector original=local.qr->solve(rhs);
 bool badInput=false;try{auto invalid=rhs;invalid[0]=NAN;RefineLocal(runtime,0,invalid,original);}catch(const std::invalid_argument&){badInput=true;}
 ++checks;if(!badInput)throw std::runtime_error("nonfinite local input not rejected");
 const Dense triangle=patch.triangle;patch.triangle*=2;bool broken=false;
 try{RefineLocal(runtime,0,rhs,original+Vector::Ones(original.size()));}catch(const std::runtime_error&){broken=true;}patch.triangle=triangle;
 ++checks;if(!broken)throw std::runtime_error("broken local preconditioner not detected");
 const int rounding=std::fegetround();std::fesetround(FE_DOWNWARD);bool roundingRefused=false;
 try{RefineLocal(runtime,0,rhs,original);}catch(const std::invalid_argument&){roundingRefused=true;}std::fesetround(rounding);
 ++checks;if(!roundingRefused)throw std::runtime_error("unsupported rounding not refused");
 const auto recovered=ProjectRefined(runtime);++checks;
 if(!recovered.accepted||!(predictor.array()==cached.reference.raw.predictor.array()).all()||!(last.primaryFlux.array()==recovered.primaryFlux.array()).all())throw std::runtime_error("failed local solve modified prior source or physical result");
 std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
