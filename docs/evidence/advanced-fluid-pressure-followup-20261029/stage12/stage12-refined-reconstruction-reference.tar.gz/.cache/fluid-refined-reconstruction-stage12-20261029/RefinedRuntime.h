#pragma once
#include "../fluid-runtime-viability-stage10-20261029/LocalResponses.h"
#include "../fluid-local-oracle-stage11-20261029/CompensatedGradient.h"
#include <cfenv>
namespace compatible_flux_extended {
struct RefinedPatch {
 Dense matrix,triangle;
 PreparedCompensatedGradient gradient;
 Vector physicalScale;
 RefinedPatch(Dense input,Dense upper,Vector scale):matrix(std::move(input)),triangle(std::move(upper)),gradient(matrix),physicalScale(std::move(scale)){}
};
struct RefinedOperators {
 ResponseOperators base;
 std::vector<RefinedPatch> patches;
 double preparationMs=0;
 explicit RefinedOperators(MacroSystem input):base(std::move(input)){
  if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("local refinement requires round-to-nearest");
  const auto start=std::chrono::steady_clock::now();const auto& sys=base.operators.reference;
  for(const auto& local:sys.local){
   const unsigned nr=local.rows.size(),rank=local.pivotVariables.size(),nf=local.freeVariables.size();Dense Ap(nr,rank),Af(nr,nf);Vector scale(nf);
   for(unsigned r=0;r<nr;++r){for(unsigned c=0;c<rank;++c)Ap(r,c)=sys.raw.fluid.coeff(local.rows[r],local.inside[local.pivotVariables[c]]);for(unsigned c=0;c<nf;++c)Af(r,c)=sys.raw.fluid.coeff(local.rows[r],local.inside[local.freeVariables[c]]);}
   for(unsigned c=0;c<nf;++c)scale[c]=sys.raw.columnScale[local.inside[local.freeVariables[c]]];
   const Dense reduced=Af-Ap*local.Cfree;
   patches.emplace_back(reduced,Dense(local.qr->matrixR().topLeftCorner(nf,nf).triangularView<Eigen::Upper>()),scale);
  }
  preparationMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 }
};
inline Vector RefineLocal(const RefinedOperators& prepared,unsigned m,const Vector& rhs,Vector x){
 if(std::fegetround()!=FE_TONEAREST)throw std::invalid_argument("local refinement requires round-to-nearest");
 const auto& patch=prepared.patches.at(m);const auto& local=prepared.base.operators.reference.local.at(m);
 if(rhs.size()!=patch.matrix.rows()||x.size()!=patch.matrix.cols()||!rhs.allFinite()||!x.allFinite())throw std::invalid_argument("invalid refined reconstruction input");
 if(x.size()==0)return x;
 Real correctionFlux=0;
 for(unsigned step=0;step<2;++step){
  const Vector gradient=patch.gradient.Evaluate(rhs,x);
  const Vector orderedGradient=local.qr->colsPermutation().transpose()*gradient;
  const Vector middle=patch.triangle.transpose().triangularView<Eigen::Lower>().solve(orderedGradient);
  const Vector ordered=patch.triangle.triangularView<Eigen::Upper>().solve(middle);
  const Vector correction=local.qr->colsPermutation()*ordered;
  x+=correction;correctionFlux=(patch.physicalScale.array()*correction.array()).abs().maxCoeff();
 }
 if(!x.allFinite()||!std::isfinite(correctionFlux)||correctionFlux>1e-12L)throw std::runtime_error("local refinement has not converged within qualified flux correction bound");
 return x;
}
inline ProfileResult ReconstructRefined(const RefinedOperators& prepared,const ConservativeResult& solved,const Eigen::Matrix<Real,6,1>& body){
 const auto start=std::chrono::steady_clock::now();ProfileResult result;static_cast<ConservativeResult&>(result)=solved;if(!result.accepted)return result;
 const auto& operators=prepared.base;const auto& runtime=operators.operators;const auto& sys=runtime.reference;const auto& raw=sys.raw;
 Vector scaled=runtime.trace*result.flux,physicalPressure=Vector::Zero(raw.divergence.rows());unsigned pressureOffset=0;
 for(unsigned m=0;m<sys.local.size();++m){
  const auto& local=sys.local[m];const auto& response=operators.responses[m];Vector boundary(response.columns.size());
  for(unsigned c=0;c<response.columns.size();++c)boundary[c]=result.flux[response.columns[c]];
  Vector free=response.freeSource-response.freeBoundary*boundary-response.freeBody*body;
  const Vector rhs=local.predicted-local.Y*result.flux-local.Ybody*body;
  free=RefineLocal(prepared,m,rhs,std::move(free));
  const Vector dependent=-local.Cfree*free-local.Cboundary*result.flux-local.Cbody*body;
  for(unsigned j=0;j<local.pivotVariables.size();++j)scaled[local.inside[local.pivotVariables[j]]]=dependent[j];
  for(unsigned j=0;j<local.freeVariables.size();++j)scaled[local.inside[local.freeVariables[j]]]=free[j];
  for(auto row:local.remainingRows)physicalPressure[4*m+row]=result.pressure[pressureOffset++];
 }
 const auto timeLocal=std::chrono::steady_clock::now();result.localMs=std::chrono::duration<double,std::milli>(timeLocal-start).count();
 const Vector actual=raw.fluid*scaled+raw.body*body,residual=raw.predictor-actual,gradient=raw.fluid.transpose()*residual;
 const auto timeRaw=std::chrono::steady_clock::now();result.rawFieldMs=std::chrono::duration<double,std::milli>(timeRaw-timeLocal).count();
 for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const unsigned rank=local.pivotVariables.size();Vector rhs(rank);for(unsigned j=0;j<rank;++j)rhs[j]=gradient[local.inside[local.pivotVariables[j]]];for(unsigned row=0;row<local.remainingRows.size();++row)rhs.noalias()-=local.remainingPivot.row(row).transpose()*physicalPressure[4*m+local.remainingRows[row]];if(rank){const Vector pressure=local.pivot.transpose().fullPivLu().solve(rhs);for(unsigned row=0;row<rank;++row)physicalPressure[4*m+local.pivotRows[row]]=pressure[row];}}
 const auto timePressure=std::chrono::steady_clock::now();result.pressureMs=std::chrono::duration<double,std::milli>(timePressure-timeRaw).count();
 const auto reaction=raw.body.transpose()*residual-raw.bodyDivergence.transpose()*physicalPressure;
 result.reactionError=(reaction-result.reaction).norm();result.reconstructedBalance=(runtime.divergence*scaled+raw.bodyDivergence*body).lpNorm<Eigen::Infinity>();result.primaryFlux=scaled.cwiseProduct(raw.columnScale);result.fullEnergy=.5*actual.squaredNorm();
 if(result.reactionError>1e-8||result.reconstructedBalance>1e-10||std::abs(result.fullEnergy-(result.energyAfter+sys.retainedEnergy))>1e-9){result.accepted=false;result.error="prepared responses violate original work/balance";}
 result.finalChecksMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-timePressure).count();result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}

inline ProfileResult ProjectRefined(const RefinedOperators& prepared,const Eigen::Matrix<Real,6,1>& body=Eigen::Matrix<Real,6,1>::Zero()){
 const auto start=std::chrono::steady_clock::now();const auto& sys=prepared.base.operators.reference;
 auto result=ReconstructRefined(prepared,sys.prepared->Solve(sys.coarse.predictor,body),body);
 result.fullStepMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();return result;
}
}
