#pragma once
#include "../fluid-runtime-viability-stage10-20261029/LocalResponses.h"
#include "../fluid-runtime-viability-stage10-20261029/PredictorSampler.h"
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <cstdio>
#include "../fluid-local-oracle-stage11-20261029/CompensatedGradient.h"
#include <cfenv>
#include <limits>
#include <fstream>
#include <iomanip>
using namespace compatible_flux_extended;
template<unsigned Bits>using Number=boost::multiprecision::number<boost::multiprecision::cpp_bin_float<Bits,boost::multiprecision::digit_base_2>>;
struct Frozen {
 Dense matrix,freeMatrix,pivotMatrix,constraint,Y;Vector predicted,boundary;Vector rhs,physicalScale,normalScale;unsigned local=0;
 Vector original,prepared;
};
template<unsigned Bits>std::vector<Number<Bits>> Solve(const Frozen& f,bool omitted=false,unsigned mode=0){
 using N=Number<Bits>;const unsigned n=f.matrix.cols();std::vector<N> gram(size_t(n)*n),rhs(n);
 // Independent normal equations are an ORACLE, not a proposed runtime solver.
 // Frozen Real coefficients convert exactly into both higher-precision formats.
 for(int row=0;row<f.matrix.rows();++row){std::vector<std::pair<unsigned,N>> active;for(unsigned c=0;c<n;++c){N coefficient(f.matrix(row,c));if(mode==2){coefficient=N(f.freeMatrix(row,c));for(int k=0;k<f.pivotMatrix.cols();++k)coefficient-=N(f.pivotMatrix(row,k))*N(f.constraint(k,c));}if(coefficient!=0)active.emplace_back(c,coefficient);}
  N localSource(f.rhs[row]);if(mode){localSource=N(f.predicted[row]);for(int c=0;c<f.Y.cols();++c)localSource-=N(f.Y(row,c))*N(f.boundary[c]);}
  for(unsigned a=0;a<active.size();++a){const auto i=active[a].first;rhs[i]+=active[a].second*localSource;for(unsigned b=a;b<active.size();++b)gram[size_t(i)*n+active[b].first]+=active[a].second*active[b].second;}
 }
 for(unsigned i=0;i<n;++i)for(unsigned j=0;j<i;++j)gram[size_t(i)*n+j]=gram[size_t(j)*n+i];
 const auto before=gram;const auto source=rhs;
 if(omitted)for(unsigned i=0;i<n;++i)for(unsigned j=0;j<n;++j)if(i!=j)gram[size_t(i)*n+j]=0;
 for(unsigned k=0;k<n;++k){unsigned pivot=k;for(unsigned r=k+1;r<n;++r)if(abs(gram[size_t(r)*n+k])>abs(gram[size_t(pivot)*n+k]))pivot=r;
  if(gram[size_t(pivot)*n+k]==0)throw std::runtime_error("high-precision oracle has an exact zero pivot");
  if(pivot!=k){for(unsigned c=0;c<n;++c)std::swap(gram[size_t(pivot)*n+c],gram[size_t(k)*n+c]);std::swap(rhs[pivot],rhs[k]);}
  for(unsigned r=k+1;r<n;++r){const N factor=gram[size_t(r)*n+k]/gram[size_t(k)*n+k];gram[size_t(r)*n+k]=0;for(unsigned c=k+1;c<n;++c)gram[size_t(r)*n+c]-=factor*gram[size_t(k)*n+c];rhs[r]-=factor*rhs[k];}
 }
 std::vector<N> x(n);for(int r=int(n)-1;r>=0;--r){N value=rhs[r];for(unsigned c=r+1;c<n;++c)value-=gram[size_t(r)*n+c]*x[c];x[r]=value/gram[size_t(r)*n+r];}
 N residual=0,scale=1;for(unsigned r=0;r<n;++r){N value=-source[r];for(unsigned c=0;c<n;++c)value+=before[size_t(r)*n+c]*x[c];residual=std::max(residual,N(abs(value)));scale=std::max(scale,N(abs(source[r])));}
 std::printf("ORACLE bits=%u omitted=%d mode=%u local=%u rows=%ld columns=%u normal_relative_residual=%.17g\n",Bits,omitted,mode,f.local,long(f.matrix.rows()),n,double(residual/scale));
 if(residual/scale>N("1e-28"))throw std::runtime_error("high-precision normal oracle did not converge to declared arithmetic residual");return x;
}
