#include "RefinedRuntime.h"
#include "CoarseOracle.h"
#include <cstdio>
using namespace compatible_flux_extended;
unsigned checks=0;void Check(bool x,const char* message){++checks;if(!x)throw std::runtime_error(message);}
int main(){try{for(double angle:{0.,3.2137858346770188e-11,.37}){
 RefinedOperators runtime(Condense(Build(owned_cut::Prepare(1,V(.5),V(.2),glm::angleAxis(angle,glm::normalize(V(1,2,-.3)))),V(0),1)));
 auto& sys=runtime.base.operators.reference;PredictorSampler sampler(sys.raw);
 for(unsigned trial=0;trial<3;++trial){
  auto velocity=[&](V p){if(trial==2)return V(0);return double(trial+1)*V(.03*std::sin(5*p.y),-.04+.01*std::cos(3*p.z),.02*std::sin(4*p.x));};
  RefreshResponses(runtime.base,sampler.Sample(velocity));Eigen::Matrix<Real,6,1> body=Eigen::Matrix<Real,6,1>::Zero();if(trial==1)body<<.01,-.02,.03,.02,-.01,.03;
  const auto result=ProjectRefined(runtime,body);std::printf("FULL angle=%.17g trial=%u accepted=%d balance=%g reaction=%g energy=%g solve_ms=%g error=%s\n",angle,trial,result.accepted,result.reconstructedBalance,result.reactionError,result.fullEnergy,result.fullStepMs,result.error.c_str());
  Check(result.accepted,"full refined reconstruction rejected");VerifyCoarse(sys.coarse,body,result);Check(true,"independent coarse physical solve matches");
  if(trial==0){auto broken=static_cast<ConservativeResult>(result);broken.flux[0]+=.001L;bool detected=false;try{VerifyCoarse(sys.coarse,body,broken);}catch(const std::runtime_error& e){detected=std::string(e.what())=="independent coarse saddle comparison failed";}Check(detected,"independent coarse oracle detects broken output");}
  double maximum=0;
  for(unsigned m=0;m<sys.local.size();++m){const auto& local=sys.local[m];const auto& patch=runtime.patches[m];Frozen f;f.local=m;f.matrix=patch.matrix;f.rhs=local.predicted-local.Y*result.flux-local.Ybody*body;const auto gold=Solve<160>(f);Vector free(gold.size());
   for(unsigned c=0;c<gold.size();++c){free[c]=gold[c].convert_to<Real>();const auto index=local.inside[local.freeVariables[c]];const Number<160> error=abs(Number<160>(result.primaryFlux[index])-Number<160>(sys.raw.columnScale[index])*gold[c]);maximum=std::max(maximum,error.convert_to<double>());}
   for(unsigned c=0;c<local.pivotVariables.size();++c){Number<160> dependent=0;for(unsigned j=0;j<gold.size();++j)dependent-=Number<160>(local.Cfree(c,j))*gold[j];for(int j=0;j<result.flux.size();++j)dependent-=Number<160>(local.Cboundary(c,j))*Number<160>(result.flux[j]);for(unsigned j=0;j<6;++j)dependent-=Number<160>(local.Cbody(c,j))*Number<160>(body[j]);const auto index=local.inside[local.pivotVariables[c]];const Number<160> error=abs(Number<160>(result.primaryFlux[index])-Number<160>(sys.raw.columnScale[index])*dependent);maximum=std::max(maximum,error.convert_to<double>());}
   Check(maximum<=1e-12,"full free/dependent physical flux differs from independent local oracle");
  }
  if(trial==2)Check(result.fullEnergy==0&&result.primaryFlux.norm()==0&&result.reaction.norm()==0,"zero source retained stale state");
  std::printf("QUALIFIED angle=%.17g trial=%u all_local_flux_error=%g\n",angle,trial,maximum);
 }
 }std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
