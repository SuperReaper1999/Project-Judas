#pragma once
#include "HighPrecisionOracle.h"
// Independent dense high-precision saddle system, not the runtime elimination/QR.
// Pivot-row selection is checked against ALL original conservation rows afterward.
struct CoarseGold {std::vector<Number<160>> flux;double balance=0,stationarity=0,fluxError=0;};
inline CoarseGold VerifyCoarse(const System& sys,const Eigen::Matrix<Real,6,1>& body,const ConservativeResult& actual){
 using N=Number<160>;const unsigned nf=sys.variables;
 Eigen::FullPivLU<Dense> rank(sys.divergence);const unsigned np=rank.rank();const Eigen::PermutationMatrix<Eigen::Dynamic,Eigen::Dynamic> inverse=rank.permutationP().inverse();const auto rows=inverse.indices();const unsigned n=nf+np;
 std::vector<N> matrix(size_t(n)*n),rhs(n);const Dense field(sys.fluid);
 for(int r=0;r<field.rows();++r){N b(sys.predictor[r]);for(unsigned a=0;a<6;++a)b-=N(sys.body(r,a))*N(body[a]);
  std::vector<std::pair<unsigned,N>> terms;for(unsigned c=0;c<nf;++c)if(field(r,c)!=0)terms.emplace_back(c,N(field(r,c)));
  for(const auto& [c,x]:terms){rhs[c]+=x*b;for(const auto& [d,y]:terms)matrix[size_t(c)*n+d]+=x*y;}}
 for(unsigned p=0;p<np;++p){const unsigned r=rows[p];for(unsigned c=0;c<nf;++c){matrix[size_t(c)*n+nf+p]=N(sys.divergence(r,c));matrix[size_t(nf+p)*n+c]=N(sys.divergence(r,c));}for(unsigned a=0;a<6;++a)rhs[nf+p]-=N(sys.bodyDivergence(r,a))*N(body[a]);}
 const auto source=rhs,original=matrix;
 for(unsigned k=0;k<n;++k){unsigned pivot=k;for(unsigned r=k+1;r<n;++r)if(abs(matrix[size_t(r)*n+k])>abs(matrix[size_t(pivot)*n+k]))pivot=r;
  if(matrix[size_t(pivot)*n+k]==0)throw std::runtime_error("independent coarse saddle system singular");
  if(pivot!=k){for(unsigned c=0;c<n;++c)std::swap(matrix[size_t(pivot)*n+c],matrix[size_t(k)*n+c]);std::swap(rhs[pivot],rhs[k]);}
  for(unsigned r=k+1;r<n;++r){const N factor=matrix[size_t(r)*n+k]/matrix[size_t(k)*n+k];matrix[size_t(r)*n+k]=0;for(unsigned c=k+1;c<n;++c)matrix[size_t(r)*n+c]-=factor*matrix[size_t(k)*n+c];rhs[r]-=factor*rhs[k];}}
 std::vector<N> x(n);for(int r=int(n)-1;r>=0;--r){N value=rhs[r];for(unsigned c=r+1;c<n;++c)value-=matrix[size_t(r)*n+c]*x[c];x[r]=value/matrix[size_t(r)*n+r];}
 N residual=0,balance=0,fluxError=0;
 for(unsigned r=0;r<n;++r){N value=-source[r];for(unsigned c=0;c<n;++c)value+=original[size_t(r)*n+c]*x[c];residual=std::max(residual,N(abs(value)));}
 for(int r=0;r<sys.divergence.rows();++r){N value=0;for(unsigned c=0;c<nf;++c)value+=N(sys.divergence(r,c))*x[c];for(unsigned a=0;a<6;++a)value+=N(sys.bodyDivergence(r,a))*N(body[a]);balance=std::max(balance,N(abs(value)));}
 for(unsigned c=0;c<nf;++c)fluxError=std::max(fluxError,N(abs(x[c]*N(sys.columnScale[c])-N(actual.flux[c]))));
 if(residual>N("1e-28")||balance>N("1e-12")||fluxError>N("1e-12"))throw std::runtime_error("independent coarse saddle comparison failed");
 std::printf("COARSE_ORACLE variables=%u independent_constraints=%u residual=%g all_row_balance=%g flux_error=%g\n",nf,np,residual.convert_to<double>(),balance.convert_to<double>(),fluxError.convert_to<double>());
 x.resize(nf);return {x,balance.convert_to<double>(),residual.convert_to<double>(),fluxError.convert_to<double>()};
}
