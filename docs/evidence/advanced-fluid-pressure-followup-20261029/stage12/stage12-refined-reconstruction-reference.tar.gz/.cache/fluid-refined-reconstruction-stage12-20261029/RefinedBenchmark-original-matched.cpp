#include "RefinedRuntime.h"
#include "../fluid-runtime-viability-stage10-20261029/StableRuntime.h"
#include "../fluid-runtime-viability-stage10-20261029/PredictorSampler.h"
#include "../fluid-runtime-viability-stage10-20261029/PhysicalPredictor.h"
#include <sys/resource.h>
#include <algorithm>
#include <cstdio>
using namespace compatible_flux_extended;using Clock=std::chrono::steady_clock;
double Ms(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
void Summary(const char* name,std::vector<double> x){std::sort(x.begin(),x.end());std::printf("TIMING name=%s count=%zu median_ms=%g p95_ms=%g worst_ms=%g\n",name,x.size(),x[x.size()/2],x[unsigned(std::ceil(.95*x.size()))-1],x.back());}
int main(){try{const auto start=Clock::now();const auto q=glm::angleAxis(3.2137858346770188e-11,glm::normalize(V(1,2,-.3)));auto geometry=owned_cut::Prepare(2,V(1),V(.5,.1,.5),q);const double geometryMs=Ms(start);auto raw=Build(std::move(geometry),V(0,-9.81/240,0),2);const double fieldMs=Ms(start)-geometryMs;auto macro=Condense(std::move(raw));const double macroMs=Ms(start)-geometryMs-fieldMs;RefinedOperators runtime(std::move(macro));auto& sys=runtime.base.operators.reference;PredictorSampler sampler(sys.raw);std::printf("COLD geometry_ms=%g field_ms=%g condensation_ms=%g response_ms=%g refinement_ms=%g total_ms=%g cells=%zu local_patches=%zu fine_variables=%u coarse_variables=%u\n",geometryMs,fieldMs,macroMs,runtime.base.preparationMs,runtime.preparationMs,Ms(start),sys.raw.cells.size(),sys.local.size(),sys.raw.variables,sys.coarse.variables);
 std::vector<double> baseline,candidate,baseRefresh,newRefresh,baseSampling,newSampling,baseAll,newAll,local;double maximumDelta=0,maximumBalance=0,maximumReaction=0,energyExcess=0;unsigned checks=0;
 for(unsigned sample=0;sample<24;++sample){const auto velocity=[&](V p){return V(.001*sample,-9.81/240,.002)+glm::cross(V(.002,.003,-.001),p-V(1));};Eigen::Matrix<Real,6,1> body=Eigen::Matrix<Real,6,1>::Zero();if(sample%3==2)body<<.01,-.02,.01,.02,0,-.01;
  ProfileResult before,after;double b0,b1,b2,c0,c1,c2;
  auto first=[&]{auto t=Clock::now();const auto source=sampler.Sample(velocity);b0=Ms(t);t=Clock::now();RefreshPredictor(runtime.base.operators,source);b1=Ms(t);t=Clock::now();before=ProjectStable(runtime.base.operators,body);b2=Ms(t);};
  auto second=[&]{auto t=Clock::now();const auto source=sampler.Sample(velocity);c0=Ms(t);t=Clock::now();RefreshResponses(runtime.base,source);c1=Ms(t);t=Clock::now();after=ProjectRefined(runtime,body);c2=Ms(t);};
  if(sample%2){second();first();}else{first();second();}++checks;if(!before.accepted||!after.accepted)throw std::runtime_error("matched reconstruction benchmark rejected");
  const double delta=(before.primaryFlux-after.primaryFlux).lpNorm<Eigen::Infinity>();maximumDelta=std::max(maximumDelta,delta);maximumBalance=std::max(maximumBalance,after.reconstructedBalance);maximumReaction=std::max(maximumReaction,after.reactionError);if(body.norm()==0){energyExcess=std::max(energyExcess,after.fullEnergy-.5*double(sys.raw.predictor.squaredNorm()));++checks;if(energyExcess>1e-9)throw std::runtime_error("refined whole field creates kinetic energy");}
  baseline.push_back(b2);candidate.push_back(c2);baseRefresh.push_back(b1);newRefresh.push_back(c1);baseSampling.push_back(b0);newSampling.push_back(c0);baseAll.push_back(b0+b1+b2);newAll.push_back(c0+c1+c2);local.push_back(after.localMs);
  std::printf("SAMPLE n=%u baseline_all_ms=%g refined_all_ms=%g baseline_solve_ms=%g refined_solve_ms=%g refined_local_ms=%g coarse_solve_ms=%g raw_field_ms=%g pressure_ms=%g checks_ms=%g legacy_flux_delta=%g balance=%g reaction_error=%g\n",sample,b0+b1+b2,c0+c1+c2,b2,c2,after.localMs,after.solveMs,after.rawFieldMs,after.pressureMs,after.finalChecksMs,delta,after.reconstructedBalance,after.reactionError);
 }
 Summary("baseline_all",baseAll);Summary("refined_all",newAll);Summary("baseline_solve",baseline);Summary("refined_solve",candidate);Summary("refined_local",local);Summary("baseline_refresh",baseRefresh);Summary("refined_refresh",newRefresh);Summary("baseline_sampling",baseSampling);Summary("refined_sampling",newSampling);struct rusage usage{};getrusage(RUSAGE_SELF,&usage);std::printf("SUMMARY checks=%u failures=0 maximum_legacy_delta=%g maximum_balance=%g maximum_reaction_error=%g energy_excess=%g peak_rss_kib=%ld\n",checks,maximumDelta,maximumBalance,maximumReaction,energyExcess,usage.ru_maxrss);return 0;
 }catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
