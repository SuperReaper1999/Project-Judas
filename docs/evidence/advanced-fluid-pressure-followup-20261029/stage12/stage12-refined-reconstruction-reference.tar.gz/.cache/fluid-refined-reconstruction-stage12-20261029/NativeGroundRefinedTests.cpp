#include "RefinedRuntime.h"
#include "PhysicsWorld.h"
#include "PhysicsConstraintBatch.h"
#include <cstdio>
using namespace compatible_flux_extended;
unsigned checks=0;void Check(bool value,const char* text){++checks;if(!value)throw std::runtime_error(text);}
void Run(bool fixed,double angle,bool omitted=false,double mass=80){
 const glm::vec3 half(.25f);
 PhysicsWorld world;world.Init();world.CreateStaticBox({.5f,-.25f,.5f},{2,.5f,2},0,0);const auto q=glm::angleAxis(float(angle),glm::normalize(glm::vec3(1,2,-.3)));
 const auto body=world.CreateShape(Shape::Box(half),{{.5f,.5f,.5f},q},true,float(mass),0,0);
 if(!fixed)world.SetLinearVelocity(body,{0,float(-9.81/240),0});
 if(fixed){JointSettings s;s.bodyA=body;s.anchorB={.5f,.5f,.5f};s.frameA=glm::inverse(q);Check(world.CreateJoint(s).IsValid(),"native fixed support authored");}
 PhysicsConstraintParticipant participant;participant.bodies={body};unsigned publications=0;V expectedV(0),expectedW(0);Vector staged,publishedFlux;double endpoint=0,energyBefore=0,energyAfter=0,bodyImpulse=0,materialEnergy=0,actualEnergy=0,physicalMass=mass;glm::dmat3 physicalInertia(0);bool negativeRejected=false;
 participant.propose=[&](const PhysicsConstraintBatch& batch,PhysicsConstraintProposal& proposal){
  // One finite coupled interaction. Subsequent native phases are deliberately
  // ordinary; no moving-fluid/remap continuation is implied by this fixture.
  if(publications)return false;
  Check(batch.contacts.size()==4,"actual four-point native floor manifold present");Check(batch.joints.empty(),"floor fixture has no bilateral substitute");for(const auto& contact:batch.contacts)Check(contact.minimumNormalSpeed==0,"exact-touch floor target is homogeneous");
  unsigned owner=unsigned(-1);for(unsigned i=0;i<batch.bodies.size();++i)if(batch.bodies[i].handle.id==body.id&&batch.bodies[i].handle.world==body.world)owner=i;Check(owner!=unsigned(-1),"owning native identity retained");
  const auto& native=batch.bodies[owner];physicalMass=1./native.inverseMass;physicalInertia=glm::inverse(glm::dmat3(native.inverseInertia));auto cut=owned_cut::Prepare(1,V(native.center),V(half),glm::dquat(native.orientation));auto raw=Build(std::move(cut),V(0,-9.81*batch.context.deltaTime,0),1);RefinedOperators runtime(Condense(std::move(raw)));const auto& macro=runtime.base.operators.reference;const auto& prepared=macro.coarse;const unsigned nf=prepared.variables,np=prepared.divergence.rows();
  std::vector<int> dynamic(batch.bodies.size(),-1);unsigned nb=0;for(unsigned i=0;i<batch.bodies.size();++i)if(batch.bodies[i].inverseMass>0)dynamic[i]=nb++;
  Check(nb==1,"bounded native fixture has one dynamic owner");
  System combined;combined.variables=nf+6*nb;combined.columnScale=Vector::Ones(combined.variables);const unsigned nr=prepared.fluid.rows();combined.predictor=Vector::Zero(nr+6*nb);combined.predictor.head(nr)=prepared.predictor;combined.body=Dense::Zero(nr+6*nb,6);combined.divergence=Dense::Zero(np+batch.joints.size(),combined.variables);combined.bodyDivergence=Dense::Zero(np+batch.joints.size(),6);
  Dense kinetic=Dense::Zero(nr+6*nb,combined.variables);kinetic.topLeftCorner(nr,nf)=Dense(prepared.fluid);kinetic.block(0,nf+6*dynamic[owner],nr,6)=prepared.body;combined.divergence.topLeftCorner(np,nf)=prepared.divergence;combined.divergence.block(0,nf+6*dynamic[owner],np,6)=prepared.bodyDivergence;
  for(unsigned b=0;b<batch.bodies.size();++b)if(dynamic[b]>=0){const auto& value=batch.bodies[b];Dense physical=Dense::Zero(6,6);for(unsigned a=0;a<3;++a)physical(a,a)=1/Real(value.inverseMass);Eigen::Matrix<Real,3,3> inverse;for(unsigned a=0;a<3;++a)for(unsigned k=0;k<3;++k)inverse(a,k)=value.inverseInertia[k][a];physical.bottomRightCorner(3,3)=inverse.inverse();Eigen::LLT<Dense> factor(physical);Check(factor.info()==Eigen::Success,"actual native mass/inertia positive");const Dense root=factor.matrixL();const unsigned r=nr+6*dynamic[b],c=nf+6*dynamic[b];kinetic.block(r,c,6,6)=root.transpose();Eigen::Matrix<Real,6,1> predictor;for(unsigned a=0;a<3;++a){predictor[a]=value.linearVelocity[a];predictor[3+a]=value.angularVelocity[a];}combined.predictor.segment(r,6)=root.transpose()*predictor;}
  for(unsigned j=0;j<batch.joints.size();++j){const auto& row=batch.joints[j];Check(row.bias==0,"native bilateral row has qualified homogeneous target");for(auto side:{false,true}){const unsigned b=side?row.b:row.a;const auto linear=side?row.linearB:row.linearA,angular=side?row.angularB:row.angularA;if(dynamic[b]<0){Check(batch.bodies[b].linearVelocity==glm::vec3(0)&&batch.bodies[b].angularVelocity==glm::vec3(0),"static anchor has zero prescribed velocity");continue;}for(unsigned a=0;a<3;++a){combined.divergence(np+j,nf+6*dynamic[b]+a)=linear[a];combined.divergence(np+j,nf+6*dynamic[b]+3+a)=angular[a];}}}
  combined.fluid=kinetic.sparseView();for(int j=0;j<combined.fluid.outerSize();++j){Real norm=0;for(Sparse::InnerIterator it(combined.fluid,j);it;++it)norm=std::hypot(norm,it.value());combined.columnScale[j]=1/norm;for(Sparse::InnerIterator it(combined.fluid,j);it;++it)it.valueRef()*=combined.columnScale[j];combined.divergence.col(j)*=combined.columnScale[j];}
  ConservativeResult solved;std::vector<float> normalImpulse(batch.contacts.size());bool feasible=false;unsigned chosen=0;
  // Exhaustive bounded FOUR-contact fixture, not a production active-set solver.
  // A contact may release; no tension is clamped into a supporting impulse.
  for(unsigned mask=0;mask<(1u<<batch.contacts.size());++mask){
   std::vector<unsigned> active;for(unsigned c=0;c<batch.contacts.size();++c)if(mask&(1u<<c))active.push_back(c);
   System trial=combined;trial.divergence.conservativeResize(np+active.size(),combined.variables);trial.bodyDivergence=Dense::Zero(np+active.size(),6);
   for(unsigned j=0;j<active.size();++j){const auto& contact=batch.contacts[active[j]];trial.divergence.row(np+j).setZero();
    for(bool side:{false,true}){const unsigned b=side?contact.b:contact.a;if(dynamic[b]<0)continue;const glm::vec3 linear=side?-contact.normal:contact.normal;const glm::vec3 angular=side?-glm::cross(contact.armB,contact.normal):glm::cross(contact.armA,contact.normal);
     for(unsigned a=0;a<3;++a){trial.divergence(np+j,nf+6*dynamic[b]+a)=linear[a]*trial.columnScale[nf+6*dynamic[b]+a];trial.divergence(np+j,nf+6*dynamic[b]+3+a)=angular[a]*trial.columnScale[nf+6*dynamic[b]+3+a];}}}
   const auto candidate=ProjectConservative(trial);if(!candidate.accepted)continue;std::vector<float> candidateNormals(batch.contacts.size());bool valid=true;
   for(unsigned j=0;j<active.size();++j){const Real reaction=-candidate.pressure[np+j];if(reaction<0){valid=false;break;}candidateNormals[active[j]]=float(reaction);}
   if(!valid)continue;
   for(unsigned c=0;c<batch.contacts.size();++c){const auto& contact=batch.contacts[c];Real speed=0;
    for(bool side:{false,true}){const unsigned b=side?contact.b:contact.a;if(dynamic[b]<0)continue;const auto linear=side?-contact.normal:contact.normal;const auto angular=side?-glm::cross(contact.armB,contact.normal):glm::cross(contact.armA,contact.normal);
     for(unsigned a=0;a<3;++a){speed+=linear[a]*candidate.flux[nf+6*dynamic[b]+a];speed+=angular[a]*candidate.flux[nf+6*dynamic[b]+3+a];}}
    if(speed < -1e-10L || (candidateNormals[c]>0 && std::abs(speed)>1e-10L)){valid=false;break;}}
   if(valid){solved=candidate;normalImpulse=std::move(candidateNormals);chosen=mask;feasible=true;break;}
  }
  Check(feasible,"simultaneous pressure/native unilateral floor solve is feasible");
  double contactTotal=0;for(float impulse:normalImpulse)contactTotal+=impulse;
  Check(mass>125?contactTotal>0:contactTotal==0,"heavy body supported and light body releases instead of tensile floor impulse");
  std::printf("FLOOR mass=%g active_mask=%u total_normal_impulse=%g\n",mass,chosen,contactTotal);
Eigen::Matrix<Real,6,1> bodyVelocity=solved.flux.segment(nf+6*dynamic[owner],6);ConservativeResult reduced=solved;reduced.flux=solved.flux.head(nf);reduced.pressure=solved.pressure.head(np);const Vector fluidVelocity=prepared.fluid*reduced.flux+prepared.body*bodyVelocity;reduced.reaction=prepared.body.transpose()*(prepared.predictor-fluidVelocity)-prepared.bodyDivergence.transpose()*reduced.pressure;reduced.energyAfter=.5*fluidVelocity.squaredNorm();reduced.energyBefore=.5*prepared.predictor.squaredNorm();const auto material=ReconstructRefined(runtime,reduced,bodyVelocity);Check(material.accepted,"full original flux/work reconstruction accepted");
  proposal.linearImpulses.assign(batch.bodies.size(),V(0));proposal.angularImpulses.assign(batch.bodies.size(),V(0));for(unsigned a=0;a<3;++a){proposal.linearImpulses[owner][a]=double(material.reaction[a]);proposal.angularImpulses[owner][a]=double(material.reaction[3+a]);expectedV[a]=double(bodyVelocity[a]);expectedW[a]=double(bodyVelocity[3+a]);}proposal.contactImpulses=normalImpulse;if(omitted)for(auto& impulse:proposal.contactImpulses)impulse=0;proposal.jointImpulses.resize(batch.joints.size());for(unsigned j=0;j<batch.joints.size();++j)proposal.jointImpulses[j]=omitted?0:float(-solved.pressure[np+j]);if(!fixed)Check(mass>125?std::abs(bodyVelocity[1])<1e-10:bodyVelocity[1]>0,"heavier body rests on floor and lighter body lifts off under the same gravity predictor");staged=material.primaryFlux;materialEnergy=material.fullEnergy;energyBefore=solved.energyBefore+macro.retainedEnergy;energyAfter=solved.energyAfter+macro.retainedEnergy;bodyImpulse=double(material.reaction[1]);Check(energyAfter<=energyBefore+1e-9,"whole fluid/native kinetic energy does not increase");if(fixed)Check(std::abs(bodyImpulse-(8*double(half.x)*half.y*half.z)*1000*9.81*batch.context.deltaTime)<1e-6,"supported native body receives independent buoyancy load");return true;
 };
 participant.published=[&](const auto&) noexcept{++publications;publishedFlux.swap(staged);};PhysicsWorld::VelocityCoupling coupling;coupling.physicalBatch=&participant;coupling.afterSubstep=[&](const auto& phase){if(phase.index==0){endpoint=glm::length(V(world.GetLinearVelocity(body))-expectedV)+glm::length(V(world.GetAngularVelocity(body))-expectedW);Check(endpoint<3e-7,"completed native endpoint agrees with compatible flux solve");const V v(world.GetLinearVelocity(body)),w(world.GetAngularVelocity(body));actualEnergy=materialEnergy+.5*physicalMass*glm::dot(v,v)+.5*glm::dot(w,physicalInertia*w);Check(actualEnergy<=energyBefore+1e-7,"actual completed native state preserves total kinetic bound");}};
 try{world.Step(1.f/60,&coupling);}catch(const std::runtime_error& e){if(!omitted)throw;Check(std::string(e.what()).find("proposal violates native normal complementarity")!=std::string::npos,"missing-reaction control rejected specifically by native normal complementarity validation");negativeRejected=true;}
 Check(omitted?(negativeRejected&&publications==0&&publishedFlux.size()==0):(publications==1&&publishedFlux.size()>0),"only accepted finite coupling publishes face state");
 std::printf("NATIVE_MACRO fixed=%d angle=%g mass=%g omitted=%d publications=%u endpoint_error=%g impulse_y=%.17g energy_before=%g energy_after=%g actual_combined_energy=%g rejected=%d\n",fixed,angle,mass,omitted,publications,endpoint,bodyImpulse,energyBefore,energyAfter,actualEnergy,negativeRejected);
}
int main(){try{Run(false,0,false,160);Run(false,0,false,20);Run(false,0,true,160);std::printf("SUMMARY checks=%u failures=0\n",checks);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL after %u checks %s\n",checks,e.what());return 1;}}
