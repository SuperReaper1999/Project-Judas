"""Reproduce serially in a scratch checkout; never overwrite original receipts."""
from pathlib import Path
import json,subprocess,time
folder=Path('.cache/fluid-refined-reconstruction-stage12-20261029')
output=folder/'reproduction-results'
output.mkdir(exist_ok=False)
runs=[]
commands=[(n,['python3',str(folder/'run_probe.py'),n]) for n in ['FullReconstructionTests','RefreshRefinedTests','NativeRefinedTests','NativeGroundRefinedTests','MaterialRefinedTests']]
commands += [('BenchmarkWide',['python3',str(folder/'run_probe.py'),'RefinedBenchmark','2']),('BenchmarkThin',['.cache/fluid-contact-repair/stage12-RefinedBenchmark','1'])]
for name,command in commands:
 start=time.monotonic();log=output/(name+'.log')
 with log.open('w') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'seconds':time.monotonic()-start,'returnCode':result.returncode,'log':str(log)};runs.append(record)
 (output/'RUNS.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(record),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
