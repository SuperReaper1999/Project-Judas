"""Archive private references/dependencies; no builds or research modifications."""
from pathlib import Path
import hashlib,json,tarfile,re,subprocess,datetime,io,gzip
root=Path.cwd();dest=root/'docs/evidence/advanced-fluid-angular-transport-20261030';dest.mkdir(exist_ok=True)
folders=['fluid-angular-transport-stage21-20261030','fluid-angular-transport-stage22-20261030']
paths=set()
for folder in folders:
 for p in (root/'.cache'/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.h','.cpp','.py','.txt','.log','.json'}:paths.add(p)
pending=list(paths);unresolved=set()
while pending:
 p=pending.pop()
 if p.suffix not in {'.cpp','.h'}:continue
 for name in re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',p.read_text(),re.M):
  found=next((q.resolve() for q in (p.parent/name,root/'src'/name) if q.is_file()),None)
  if found:
   if not found.is_relative_to(root):raise RuntimeError(str(found))
   if found not in paths:paths.add(found);pending.append(found)
  else:unresolved.add(name)
if unresolved:raise RuntimeError(sorted(unresolved))
archive=dest/'angular-momentum-reference.tar.gz';records={}
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in sorted(paths):
    data=p.read_bytes();name=str(p.relative_to(root));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));records[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(dest/'SOURCE_MANIFEST.json').write_text(json.dumps({'schema':1,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':records,'unresolvedQuotedIncludes':[]},indent=2)+'\n')
def receipt(p):
 data=(root/p).read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
provenance={'schema':1,'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'mainUnchanged':subprocess.check_output(['git','rev-parse','main'],text=True).strip(),'scope':'Private numerical reference only; no native engine link or runtime adoption','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'flags':['-std=c++17','-O3','-g0','-DNDEBUG'],'cpu':'AMD Ryzen 5 5600','ramKiB':next(s for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemTotal:')),'systemGLM':subprocess.check_output(['dpkg-query','-W','-f=${Version}','libglm-dev'],text=True),'externalHeaderArchives':{str(p.relative_to(root)):receipt(p.relative_to(root)) for p in (root/'.cache/fluid-reference-headers').glob('*.deb')},'finalBinaries':{str(p):receipt(p) for p in [Path('.cache/fluid-angular-transport-stage22-20261030/fast-reference'),Path('.cache/fluid-angular-transport-stage22-20261030/FastImplicitWeakTests.final'),Path('.cache/fluid-angular-transport-stage22-20261030/ApertureRangeTests.reproduced')]},'nativeArchiveUsed':False,'newPlatformOrHumanAcceptanceClaimed':False}
(dest/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(f'Archived {len(records)} exact source/log/dependency files, {archive.stat().st_size} bytes; no missing quoted includes')
