from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path(__file__).resolve().parent
boost=os.environ.get('BOOST_INCLUDE_DIR','.cache/fluid-reference-headers/boost/usr/include')
eigen=os.environ.get('EIGEN_INCLUDE_DIR','.cache/fluid-reference-headers/eigen/usr/include/eigen3')
records=[]
def record(command,log):
 start=time.time()
 with (root/log).open('w') as f: result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 entry={'command':command,'log':log,'returncode':result.returncode,'startedUnix':start,'elapsedSeconds':time.time()-start}
 records.append(entry);(root/'final-receipts.json').write_text(json.dumps(records,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
for name,args in [('FastImplicitWeakTests',[['implicit'],['implicit','rotated'],['cycle']]),('ApertureRangeTests',[[]])]:
 src=root/(name+'.cpp');exe=root/(name+'.final')
 record(['g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc','-I'+boost,'-I'+eigen,str(src),'-o',str(exe)],name+'-final-compile.log')
 for argv in args:record([str(exe),*argv],name+'-final-'+('-'.join(argv) or 'run')+'.log')
 records[-1]['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
 (root/'final-receipts.json').write_text(json.dumps(records,indent=2)+'\n')
