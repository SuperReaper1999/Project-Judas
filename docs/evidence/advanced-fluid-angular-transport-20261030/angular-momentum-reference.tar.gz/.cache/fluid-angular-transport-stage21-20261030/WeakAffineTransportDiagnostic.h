#pragma once
// PRIVATE fixed-geometry Galerkin transport reference. Shared primary normal
// fluxes transport affine velocity moments at actual physical face points.
// The symmetric volume stress cannot create an internal angular torque.
// Complementary VEM modes are retained, not claimed advected.
#include "PortMomentumTransport.h"
namespace weak_affine {
using namespace port_momentum;
using Mat4=Eigen::Matrix<Real,4,4>;
using Mat34=Eigen::Matrix<Real,3,4>;
using Mat3=Eigen::Matrix<Real,3,3>;
struct Rate {
 std::vector<Vector> raw;
 std::vector<vm::Affine> polynomial;
 std::vector<R> outflow,volumeChange;
 RV pairedImpulse{},pairedAngular{};
 Real energyDerivative=0,upwindDissipation=0,energyIdentity=0,polynomialEnergyDerivative=0,rootEnergyDerivative=0;
 unsigned packets=0;
};
struct Transport {
 const World& world;
 port_momentum::Transport faces;
 std::vector<Mat4> gram,inverseGram;
 std::vector<Matrix> kineticRoots;
 explicit Transport(const World& w):world(w),faces(w){kineticRoots.resize(w.cells.size());for(const auto& group:w.conservative)for(unsigned i=0;i<group.pieces.size();++i)kineticRoots[group.pieces[i].cell]=group.rawRoots[i];for(const auto& cell:w.cells){Mat4 g;for(unsigned i=0;i<4;++i)for(unsigned j=0;j<4;++j)g(i,j)=cell->op.geometry.volume[vm::ProductIndex(i,j)];gram.push_back(g);inverseGram.push_back(vm::PositiveInverse(g,"weak affine scalar mass is not positive"));}}
 // Exact degree-three triangle rule. The negative centroid weight is a
 // quadrature identity, not a negative physical transfer packet.
 template<class F> static void Quadrature(const Face& face,const std::array<RV,3>& p,F consume){
  const R area=abs(owned_metrics::Cross(vg::Sub(p[1],p[0]),vg::Sub(p[2],p[0]))[face.pivot])/2;
  RV center{};for(unsigned a=0;a<3;++a)for(const auto& v:p)center[a]+=v[a]/3;
  consume(center,-area*R(27)/48);
  for(unsigned v=0;v<3;++v){RV x{};for(unsigned a=0;a<3;++a)for(unsigned j=0;j<3;++j)x[a]+=p[j][a]*R(j==v?3:1)/5;consume(x,area*R(25)/48);}
 }
 template<class F> static void PositiveFace(const Face& face,const std::array<R,3>& coefficients,int sign,F consume){for(const auto& triangle:face.triangles){std::vector<RV> polygon;for(unsigned i=0;i<3;++i){const auto& a=triangle.points[i];const auto& b=triangle.points[(i+1)%3];const R va=sign*face.Value(a,coefficients),vb=sign*face.Value(b,coefficients);if(va>=0)polygon.push_back(a);if((va<0&&vb>0)||(va>0&&vb<0)){RV x;const R t=va/(va-vb);for(unsigned axis=0;axis<3;++axis)x[axis]=a[axis]+t*(b[axis]-a[axis]);polygon.push_back(x);}}for(unsigned i=1;i+1<polygon.size();++i)Quadrature(face,{polygon[0],polygon[i],polygon[i+1]},[&](const RV& x,const R& weight){consume(x,weight*R(sign*face.Value(x,coefficients)));});}}
 RV Evaluate(const std::vector<vm::Affine>& polynomials,unsigned c,const RV& point)const{RV result{};for(unsigned a=0;a<3;++a){result[a]=R(polynomials[c][4*a]);for(unsigned b=0;b<3;++b)result[a]+=R(polynomials[c][4*a+b+1])*(point[b]-world.cells[c]->cell.center[b]);}return result;}
 Rate EvaluateRate(const State& state)const{
  if(world.factor!=faces.generation||state.local.size()!=world.cells.size()||state.exactFaceMeans.size()!=world.cells.size())throw std::invalid_argument("weak affine transport invalid/stale state");
  Rate result;result.outflow.resize(world.cells.size());result.volumeChange.resize(world.cells.size());std::vector<vm::Affine> p;std::vector<Mat34> momentRate(world.cells.size(),Mat34::Zero());std::vector<std::array<std::array<R,4>,3>> exactSurface(world.cells.size());
  for(unsigned c=0;c<world.cells.size();++c){const auto& op=world.cells[c]->op;if(state.local[c].size()!=op.dimension||!state.local[c].allFinite()||state.exactFaceMeans[c].size()!=op.geometry.faces.size())throw std::invalid_argument("weak affine transport malformed kinetic field");if(op.Divergence(state.local[c]).cwiseAbs().maxCoeff()>1e-8L)throw std::invalid_argument("weak affine energy identity requires divergence-free advecting field");for(unsigned f=0;f<op.geometry.faces.size();++f)if(world.cells[c]->cell.faces[f].kind==Kind::Solid||world.Outer(world.cells[c]->cell.faces[f].key))for(unsigned a=0;a<3;++a)if(state.local[c][3*f+a]!=0)throw std::invalid_argument("weak affine fixed boundary received moving normal trace");p.push_back(op.Project(state.local[c]));Mat34 polynomial;for(unsigned a=0;a<3;++a)for(unsigned i=0;i<4;++i)polynomial(a,i)=p.back()[4*a+i];const Mat3 stress=polynomial*gram[c]*polynomial.transpose();momentRate[c].rightCols<3>()=stress;}
  for(const auto& face:faces.ports){const auto& first=state.local[face.a];const std::array<R,3> q={state.exactFaceMeans[face.a][face.fa],R(first[3*face.fa+1]),R(first[3*face.fa+2])};const auto coefficients=face.Coefficients(q);
   for(unsigned dir=0;dir<2;++dir){const unsigned donor=dir?face.b:face.a,receiver=dir?face.a:face.b;R amount=0;if(world.cells[donor]->op.geometry.density!=world.cells[receiver]->op.geometry.density)throw std::invalid_argument("weak affine reference does not mix densities");PositiveFace(face,coefficients,dir?-1:1,[&](const RV& x,const R& measure){amount+=measure;const auto u=Evaluate(p,donor,x),v=Evaluate(p,receiver,x);R jump=0;for(unsigned a=0;a<3;++a){jump+=(u[a]-v[a])*(u[a]-v[a]);const R flux=measure*u[a];for(unsigned i=0;i<4;++i){const R bd=i?x[i-1]-world.cells[donor]->cell.center[i-1]:R(1),br=i?x[i-1]-world.cells[receiver]->cell.center[i-1]:R(1);exactSurface[donor][a][i]-=flux*bd;exactSurface[receiver][a][i]+=flux*br;}}result.upwindDissipation+=(R(world.cells[donor]->op.geometry.density)*measure*jump/2).convert_to<Real>();});if(amount<0)throw std::runtime_error("negative exact directed volume");if(amount>0)++result.packets;result.outflow[donor]+=amount;result.volumeChange[donor]-=amount;result.volumeChange[receiver]+=amount;}
  }
  for(unsigned c=0;c<world.cells.size();++c){const auto& op=world.cells[c]->op;if(result.volumeChange[c]!=0)throw std::invalid_argument("weak affine transport requires exact per-cell geometric balance");for(unsigned a=0;a<3;++a)for(unsigned i=0;i<4;++i)momentRate[c](a,i)+=exactSurface[c][a][i].convert_to<Real>();const Mat34 coefficientRate=momentRate[c]*inverseGram[c];vm::Affine update;for(unsigned a=0;a<3;++a)for(unsigned i=0;i<4;++i)update[4*a+i]=coefficientRate(a,i);result.polynomial.push_back(update);result.raw.push_back(op.InterpolateAffineDOFs(update));result.energyDerivative+=state.local[c].dot(op.mass*result.raw.back());result.rootEnergyDerivative+=(kineticRoots[c]*state.local[c]).dot(kineticRoots[c]*result.raw.back());for(unsigned a=0;a<3;++a)for(unsigned i=0;i<4;++i)result.polynomialEnergyDerivative+=op.geometry.density*p[c][4*a+i]*momentRate[c](a,i);
   RV momentum{},angular{};for(unsigned a=0;a<3;++a)momentum[a]=exactSurface[c][a][0];for(unsigned a=0;a<3;++a){const unsigned b=(a+1)%3,d=(a+2)%3;angular[a]=exactSurface[c][d][b+1]-exactSurface[c][b][d+1];}const RV orbital=owned_metrics::Cross(world.cells[c]->cell.center,momentum);for(unsigned a=0;a<3;++a)angular[a]+=orbital[a];for(unsigned a=0;a<3;++a){result.pairedImpulse[a]+=momentum[a];result.pairedAngular[a]+=angular[a];}
  }
  if(result.pairedImpulse!=RV{}||result.pairedAngular!=RV{})throw std::runtime_error("weak affine face transport creates exact linear/angular impulse");result.energyIdentity=std::abs(result.energyDerivative+result.upwindDissipation);return result;
 }
 std::vector<Vector> Explicit(const State& state,const Rate& rate,const R& dt)const{
  if(dt<=0||rate.raw.size()!=world.cells.size())throw std::invalid_argument("weak affine invalid timestep/rate");std::vector<Vector> result=state.local;for(unsigned c=0;c<result.size();++c){if(dt*rate.outflow[c]>world.cells[c]->cell.exactVolume)throw std::invalid_argument("weak affine transport exceeds donor availability");result[c]+=dt.convert_to<Real>()*rate.raw[c];}return result;
 }
};
} // namespace weak_affine
