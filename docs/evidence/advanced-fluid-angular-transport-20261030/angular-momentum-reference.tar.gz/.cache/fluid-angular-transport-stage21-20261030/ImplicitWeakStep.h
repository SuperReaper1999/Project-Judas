#pragma once
#include "WeakAffineTransport.h"
namespace weak_affine {
struct ImplicitResult {
 State state;
 std::vector<Vector> transported;
 unsigned iterations=0;
 Real residual=0,energyDefect=0,energyBefore=0,energyAfter=0,temporalLoss=0,fluxLoss=0;
};
inline Real Energy(const World& world,const std::vector<Vector>& raw){Real e=0;if(raw.size()!=world.cells.size())throw std::invalid_argument("kinetic energy field dimension mismatch");for(const auto& group:world.conservative)for(unsigned i=0;i<group.pieces.size();++i)e+=(group.rawRoots[i]*raw[group.pieces[i].cell]).squaredNorm()/2;if(!std::isfinite(e))throw std::runtime_error("factored kinetic energy is not finite");return e;}
inline Real Distance(const World& world,const std::vector<Vector>& a,const std::vector<Vector>& b){std::vector<Vector> delta;for(unsigned c=0;c<a.size();++c)delta.push_back((a[c]-b[c]).eval());return std::sqrt(2*Energy(world,delta));}
// Fixed-step backward Euler, convection evaluated at the NEW divergence-free
// field. Pressure is solved inside each iterate, not appended after transport.
// No substeps, damping, energy repair or increasing iteration budget.
inline ImplicitResult Advance(const World& world,const Transport& transport,const State& old,const R& dt,unsigned maximumIterations=16){
 if(&world!=&transport.world||dt<=0||maximumIterations==0)throw std::invalid_argument("implicit weak step invalid time/iteration policy");
 ImplicitResult result;result.state=old;result.energyBefore=Energy(world,old.local);
 for(unsigned i=0;i<maximumIterations;++i){const auto rate=transport.EvaluateRate(result.state);result.transported=transport.Explicit(old,rate,dt);auto candidate=world.SolveRaw(result.transported);result.residual=Distance(world,candidate.local,result.state.local);result.state=std::move(candidate);result.iterations=i+1;
  if(result.residual<=1e-12L){
   const auto finalRate=transport.EvaluateRate(result.state);result.transported=transport.Explicit(old,finalRate,dt);const auto checked=world.SolveRaw(result.transported);result.residual=Distance(world,checked.local,result.state.local);
   if(result.residual>1e-12L)continue;
   result.energyAfter=Energy(world,result.state.local);const Real difference=Distance(world,result.state.local,old.local);result.temporalLoss=difference*difference/2;result.fluxLoss=dt.convert_to<Real>()*finalRate.upwindDissipation;
   result.energyDefect=std::abs(result.energyAfter-result.energyBefore+result.temporalLoss+result.fluxLoss);
   if(finalRate.energyIdentity>1e-10L||result.energyDefect>1e-10L||result.energyAfter>result.energyBefore+1e-12L)throw std::runtime_error("implicit weak physical energy acceptance failed");return result;
  }
 }
 throw std::runtime_error("implicit weak transport exceeded bounded fixed-point policy; no publication");
}
} // namespace weak_affine
