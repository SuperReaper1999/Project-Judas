#pragma once
// ISOLATED RESEARCH PROTOTYPE. No production/public pose ABI changes.
#include "RigidMotion.h"
#include "ContactGeometryInternal.h"
#include <cfenv>

namespace continuous_box_ccd {
using contact_geometry::Iv;

// The caller supplies a pure box with zero pivot. Exactly one source is set.
// A dynamic segment is its recorded anchor/generator, never a sampled float pose.
struct MotionView {
    const RigidMotionSegment *segment = nullptr;
    const RigidBody *staticBody = nullptr;
    glm::vec3 halfExtents{0};
};
struct PointResult {
    bool supported = false, strictlySeparated = false;
    glm::dvec3 worldAxis{0}; // A separating plane; A is on its positive side.
    double gapLower = 0;    // Certified Euclidean separation lower bound.
};
struct PrefixResult {
    bool supported = false, separated = false;
    unsigned leaves = 0, nodes = 0, maximumDepth = 0;
};

namespace detail {
using namespace contact_geometry;
constexpr unsigned MaximumDepth = 3;
struct Source {
    glm::vec3 position{0}, velocity{0}, omega{0};
    glm::quat orientation{1, 0, 0, 0};
    double begin = 0;
};
inline bool Finite(glm::vec3 value) {
    return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z);
}
inline bool Finite(Iv value) {
    return std::isfinite(value.lo) && std::isfinite(value.hi) && value.lo <= value.hi;
}
inline bool Read(const MotionView &view, double start, double finish, Source &out) {
    if (std::fegetround() != FE_TONEAREST || !std::isfinite(start) ||
        !std::isfinite(finish) || finish < start || !Finite(view.halfExtents) ||
        glm::any(glm::lessThanEqual(view.halfExtents, glm::vec3(0))) ||
        (view.segment == nullptr) == (view.staticBody == nullptr))
        return false;
    if (view.segment) {
        const auto &s = *view.segment;
        if (s.prescribed || !std::isfinite(s.begin) || !std::isfinite(s.end) ||
            start < s.begin || finish > s.end || !std::isfinite(s.inverseMass))
            return false;
        out.position = s.position;
        out.orientation = s.orientation;
        out.begin = s.begin;
        if (s.inverseMass > 0) {
            out.velocity = s.linearVelocity;
            out.omega = s.driftAngularVelocity;
        }
    } else {
        out.position = view.staticBody->position;
        out.orientation = view.staticBody->orientation;
    }
    const auto &q = out.orientation;
    const Iv norm = Iv(double(q.w))*Iv(double(q.w)) + Iv(double(q.x))*Iv(double(q.x)) +
                    Iv(double(q.y))*Iv(double(q.y)) + Iv(double(q.z))*Iv(double(q.z));
    return Finite(out.position) && Finite(out.velocity) && Finite(out.omega) &&
           Finite(norm) && norm.lo > 0;
}

template<class T> std::array<T, 4> Derivative(const Source &source) {
    const T w(double(source.orientation.w)), x(double(source.orientation.x)),
            y(double(source.orientation.y)), z(double(source.orientation.z));
    const T a(double(source.omega.x)), b(double(source.omega.y)), c(double(source.omega.z));
    return {-(a*x+b*y+c*z)*T(.5), (a*w+b*z-c*y)*T(.5),
            (-a*z+b*w+c*x)*T(.5), (a*y-b*x+c*w)*T(.5)};
}
template<class T> struct Frame { M<T> n; T d; };
template<class T> Frame<T> Rotation(const Source &source, const T &elapsed) {
    const auto dq = Derivative<T>(source);
    const std::array<T, 4> q{T(double(source.orientation.w))+dq[0]*elapsed,
                           T(double(source.orientation.x))+dq[1]*elapsed,
                           T(double(source.orientation.y))+dq[2]*elapsed,
                           T(double(source.orientation.z))+dq[3]*elapsed};
    const auto &w=q[0], &x=q[1], &y=q[2], &z=q[3];
    return {{V<T>{w*w+x*x-y*y-z*z,T(2)*(x*y+w*z),T(2)*(x*z-w*y)},
             V<T>{T(2)*(x*y-w*z),w*w-x*x+y*y-z*z,T(2)*(y*z+w*x)},
             V<T>{T(2)*(x*z+w*y),T(2)*(y*z-w*x),w*w-x*x-y*y+z*z}},
            w*w+x*x+y*y+z*z};
}
// Subtract the exact anchors before adding either local displacement. Large
// common world positions do not enter either projection or polynomial bound.
template<class T> V<T> Relative(const Source &a, const Source &b,
                                const T &elapsedA, const T &elapsedB) {
    V<T> result;
    for (unsigned k=0;k<3;++k)
        result[k] = T(double(a.position[k])) - T(double(b.position[k])) +
                    T(double(a.velocity[k]))*elapsedA - T(double(b.velocity[k]))*elapsedB;
    return result;
}
inline bool ValidAxis(glm::dvec3 n) {
    return std::isfinite(n.x) && std::isfinite(n.y) && std::isfinite(n.z) &&
           std::max({std::abs(n.x),std::abs(n.y),std::abs(n.z)}) > 0;
}
inline Iv PlaneGap(const Frame<Iv> &a, const Frame<Iv> &b, const V<Iv> &relative,
                   glm::vec3 ha, glm::vec3 hb, glm::dvec3 normal) {
    const V<Iv> n{Iv(normal.x),Iv(normal.y),Iv(normal.z)};
    Iv gap = Dot(relative,n);
    for (unsigned k=0;k<3;++k)
        gap = gap - Iv(double(ha[k]))*Abs(Dot(a.n[k],n))/a.d -
                    Iv(double(hb[k]))*Abs(Dot(b.n[k],n))/b.d;
    return gap / Sqrt(Dot(n,n));
}

// Degree <=5 power coefficients on the normalized interval x in [0,1].
// No truncation is permitted: overflowing the declared degree is unsupported.
struct Polynomial {
    std::array<Iv, 6> c{};
    unsigned degree = 0;
    Polynomial() = default;
    Polynomial(double value) { c[0]=Iv(value); }
    explicit Polynomial(Iv value) { c[0]=value; }
    Polynomial(Iv constant, Iv slope):degree(1) { c[0]=constant;c[1]=slope; }
};
inline Polynomial operator-(Polynomial a) {
    for (unsigned k=0;k<=a.degree;++k) a.c[k]=-a.c[k];
    return a;
}
inline Polynomial operator+(const Polynomial &a,const Polynomial &b) {
    Polynomial out;out.degree=std::max(a.degree,b.degree);
    for(unsigned k=0;k<=out.degree;++k)out.c[k]=a.c[k]+b.c[k];
    return out;
}
inline Polynomial operator-(const Polynomial &a,const Polynomial &b) { return a+-b; }
inline Polynomial operator*(const Polynomial &a,const Polynomial &b) {
    Polynomial out;out.degree=a.degree+b.degree;
    if(out.degree>5)throw ArithmeticFailure();
    for(unsigned i=0;i<=a.degree;++i)for(unsigned j=0;j<=b.degree;++j)
        out.c[i+j]=out.c[i+j]+a.c[i]*b.c[j];
    return out;
}
using Bernstein = std::array<Iv,6>;
inline Bernstein Convert(const Polynomial &p) {
    constexpr unsigned choose[6][6]={{1,0,0,0,0,0},{1,1,0,0,0,0},
        {1,2,1,0,0,0},{1,3,3,1,0,0},{1,4,6,4,1,0},{1,5,10,10,5,1}};
    Bernstein out{};
    for(unsigned k=0;k<6;++k)for(unsigned i=0;i<=k;++i)
        out[k]=out[k]+p.c[i]*(Iv(double(choose[k][i]))/Iv(double(choose[5][i])));
    return out;
}
inline bool FixedPlane(const MotionView &a,const MotionView &b,const Source &sa,
                       const Source &sb,double start,double finish,glm::dvec3 axis) {
    if(!ValidAxis(axis))return false;
    const Iv duration=Iv(finish)-Iv(start);
    const Polynomial ta(Iv(start)-Iv(sa.begin),duration),tb(Iv(start)-Iv(sb.begin),duration);
    const auto ra=Rotation<Polynomial>(sa,ta), rb=Rotation<Polynomial>(sb,tb);
    const V<Polynomial> n{Polynomial(axis.x),Polynomial(axis.y),Polynomial(axis.z)};
    const auto relative=Relative<Polynomial>(sa,sb,ta,tb);
    const auto common=Convert(Dot(relative,n)*(ra.d*rb.d));
    std::array<Bernstein,6> radii;
    for(unsigned k=0;k<3;++k) {
        radii[k]=Convert(Dot(ra.n[k],n)*rb.d*Polynomial(double(a.halfExtents[k])));
        radii[k+3]=Convert(Dot(rb.n[k],n)*ra.d*Polynomial(double(b.halfExtents[k])));
    }
    for(unsigned k=0;k<6;++k) {
        Iv lower=common[k];
        // This is exactly the coefficientwise minimum over all 8*8 choices
        // of box corners. Every corner polynomial must have positive bounds.
        for(const auto &radius:radii)lower=lower-Abs(radius[k]);
        if(!Finite(lower)||!(lower.lo>0))return false;
    }
    // q=q0+(.5*Omega*q0)*tau has |q|^2=|q0|^2*(1+.25*|Omega|^2*tau^2)>0.
    // Read already certified |q0|^2>0. Clearing these denominators preserves
    // the sign for the whole interval, not just sampled endpoint poses.
    return true;
}
} // namespace detail

inline PointResult Point(const MotionView &a,const MotionView &b,double time) {
    using namespace detail;
    PointResult result;Source sa,sb;
    if(!Read(a,time,time,sa)||!Read(b,time,time,sb))return result;
    result.supported=true;
    try {
        const auto ra=Rotation<double>(sa,time-sa.begin),rb=Rotation<double>(sb,time-sb.begin);
        const auto delta=Relative<double>(sa,sb,time-sa.begin,time-sb.begin);
        Pair<double> pair(ContactPose{},ContactPose{});
        pair.a.n=ra.n;pair.a.d=ra.d;pair.b.n=rb.n;pair.b.d=rb.d;
        pair.denominator=ra.d*rb.d;pair.delta=Mul(delta,pair.denominator);
        glm::dvec3 best(0);double bestGap=0;
        for(int index=0;index<15;++index) {
            const auto raw=Axis(pair,index);
            glm::dvec3 axis(raw[0],raw[1],raw[2]);
            const double length=glm::length(axis);
            if(!(length>0)||!std::isfinite(length))continue;
            const double gap=Sat(pair,a.halfExtents,b.halfExtents,index)/(pair.denominator*length);
            if(gap>bestGap) {
                if(Dot(delta,raw)<0)axis=-axis;
                best=axis/length;bestGap=gap;
            }
        }
        if(!ValidAxis(best))return result;
        const auto ia=Rotation<Iv>(sa,Iv(time)-Iv(sa.begin));
        const auto ib=Rotation<Iv>(sb,Iv(time)-Iv(sb.begin));
        const auto relative=Relative<Iv>(sa,sb,Iv(time)-Iv(sa.begin),Iv(time)-Iv(sb.begin));
        const Iv gap=PlaneGap(ia,ib,relative,a.halfExtents,b.halfExtents,best);
        if(Finite(gap)&&gap.lo>0) {
            result.strictlySeparated=true;result.worldAxis=best;result.gapLower=gap.lo;
        }
    } catch(const ArithmeticFailure &) { result.supported=false; }
    return result;
}

namespace detail {
inline bool Certify(const MotionView &a,const MotionView &b,const Source &sa,const Source &sb,
                    double start,double finish,glm::dvec3 axis,unsigned depth,PrefixResult &result) {
    ++result.nodes;result.maximumDepth=std::max(result.maximumDepth,depth);
    if(!ValidAxis(axis)) {
        const auto point=Point(a,b,start+(finish-start)*.5);
        if(!point.supported){result.supported=false;return false;}
        if(!point.strictlySeparated)return false;
        axis=point.worldAxis;
    }
    if(FixedPlane(a,b,sa,sb,start,finish,axis)) {++result.leaves;return true;}
    if(depth==MaximumDepth)return false;
    const double middle=start+(finish-start)*.5;
    if(!(middle>start&&middle<finish))return false;
    return Certify(a,b,sa,sb,start,middle,glm::dvec3(0),depth+1,result)&&
           Certify(a,b,sa,sb,middle,finish,glm::dvec3(0),depth+1,result);
}
} // namespace detail
inline PrefixResult SeparatedPrefix(const MotionView &a,const MotionView &b,
                                    double start,double finish,glm::dvec3 axis=glm::dvec3(0)) {
    PrefixResult result;detail::Source sa,sb;
    if(!detail::Read(a,start,finish,sa)||!detail::Read(b,start,finish,sb))return result;
    result.supported=true;
    try {result.separated=detail::Certify(a,b,sa,sb,start,finish,axis,0,result);}
    catch(const contact_geometry::ArithmeticFailure &){result.supported=false;result.separated=false;}
    return result;
}
} // namespace continuous_box_ccd
