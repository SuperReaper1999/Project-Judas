const {chromium}=require('../browser-tests/node_modules/playwright');
const {spawn}=require('child_process'),fs=require('fs'),path=require('path');
(async()=>{const server=spawn('python3',['tools/serve_browser.py','.cache/browser-node-fix/web','--port','8798']);let browser;
try{await new Promise((r,j)=>{server.stdout.once('data',r);server.once('exit',c=>j(Error('server '+c)));});
browser=await chromium.launch({headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--disable-dev-shm-usage']});
const page=await browser.newPage({viewport:{width:1280,height:1000}});await page.goto('http://127.0.0.1:8798');await page.locator('#play').getByText('Play',{exact:true}).waitFor({timeout:120000});await page.locator('#play').click();await page.waitForTimeout(2000);
const measure=()=>page.evaluate(()=>{const c=document.querySelector('canvas'),r=c.getBoundingClientRect();return{width:c.width,height:c.height,css:{width:r.width,height:r.height},fullscreen:!!document.querySelector('#fullscreen')};});
const before=await measure();await page.setViewportSize({width:700,height:1000});await page.waitForTimeout(1000);const after=await measure();fs.writeFileSync('.cache/browser-player/baseline.json',JSON.stringify({before,after},null,2));console.log({before,after});
}finally{if(browser)await browser.close();server.kill();}})().catch(e=>{console.error(e);process.exitCode=1});
