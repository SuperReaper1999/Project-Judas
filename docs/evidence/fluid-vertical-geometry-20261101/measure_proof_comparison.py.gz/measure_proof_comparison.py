from pathlib import Path
import subprocess,csv,json,hashlib,platform,time,statistics,resource
c=Path(__file__).resolve().parent;r=c.parents[1];out=c/'query-performance-proof-comparison';out.mkdir(exist_ok=True)
inputs={'wet':r/'.cache/fluid-body-support-integration-20261031/frozen-wet.txt','dry':r/'.cache/fluid-body-support-integration-20261031/frozen-dry.txt','layered':c/'frozen-layered.txt','cavity':c/'frozen-cavity.txt'}
rows=[]
for pair in range(3):
 for name,input in inputs.items():
  for arm in (['current','optimized'] if pair%2==0 else ['optimized','current']):
   command=[str(c/('query-'+arm)),str(input)];file=out/f'{name}-{pair}-{arm}.csv';start=time.monotonic()
   with file.open('w') as log:res=subprocess.run(command,stdout=log,stderr=subprocess.PIPE,text=True,timeout=120)
   assert res.returncode==0,(command,res.stderr)
   values=list(csv.reader(file.open()));rows.append({'pair':pair,'case':name,'arm':arm,'command':command,'wall_seconds':time.monotonic()-start,'samples':len(values),'input_sha256':hashlib.sha256(input.read_bytes()).hexdigest()})
summary={}
for name in inputs:
 summary[name]={}
 for arm in ['current','optimized']:
  data=[v for file in out.glob(f'{name}-*-{arm}.csv') for v in csv.reader(file.open())];cost=sorted(float(v[1]) for v in data)
  summary[name][arm]={'n':len(cost),'median_ms':statistics.median(cost),'p95_ms':cost[__import__('math').ceil(.95*len(cost))-1],'worst_ms':max(cost),'fractions':sorted(set(float(v[2]) for v in data)),'force_y':sorted(set(float(v[3]) for v in data))}
(out/'RUNS.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
