#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <glm/gtc/quaternion.hpp>
#include <iostream>
#include <cmath>
struct Uniform : GravityField {glm::vec3 g;explicit Uniform(glm::vec3 v):g(v){}glm::vec3 Sample(const glm::vec3&)const override{return g;}};
int main(){unsigned fail=0,n=0;auto near=[&](double v,double e,double t,const char* label){++n;if(std::abs(v-e)>t){++fail;std::cout<<"FAIL "<<label<<" "<<v<<" expected "<<e<<'\n';}};
for(bool turn:{false,true}){
 auto q=turn?glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3))):glm::quat(1,0,0,0);glm::vec3 shift=turn?glm::vec3(3,-2,4):glm::vec3(0);
 std::vector<FluidParticle> p;for(int x=-8;x<=8;++x)for(int z=-8;z<=8;++z)for(float y:{-.875f,-.625f,.625f,.875f}){auto pos=shift+q*glm::vec3(.25f*x,y,.25f*z);p.push_back({pos,pos,glm::vec3(0),15.625f,glm::vec3(0)});}FluidHydrostaticField f;f.Build(p,1000);
 for(bool physical:{false,true}){auto r=f.Query(shift,q*glm::vec3(0,1,0),.1f,1,q*glm::vec3(1,0,0),nullptr,physical);near(r.fraction,0,0,"dry gap");auto s=f.Query(shift,q*glm::vec3(0,1,0),.75f,1,q*glm::vec3(1,0,0),nullptr,physical);near(s.fraction,1./3.,2e-5,"two layers occupied length");}
 BodyTransform pose;pose.position=shift;pose.rotation=q;for(auto shape:{MakeBoxFluidVolume(glm::vec3(.1f)),MakeSphereFluidVolume(.1f)}){auto r=EvaluateFluidHydrostatics(f,shape,pose,Uniform(q*glm::vec3(0,-9.81f,0)));near(r.fraction,0,0,"dry solid");near(glm::length(r.buoyancyForce),0,0,"dry solid force");}
 }
 {
 std::vector<FluidParticle> p;for(int x=-8;x<=8;++x)for(int z=-8;z<=8;++z)for(int y=-4;y<=4;++y){if(std::abs(y)<2&&x<2)continue;glm::vec3 a(.25f*x,.25f*y,.25f*z);p.push_back({a,a,glm::vec3(0),15.625f,glm::vec3(0)});}FluidHydrostaticField f;f.Build(p,1000);auto shape=MakeBoxFluidVolume({1,.1f,.1f});BodyTransform pose;FluidSolidQuery solid{shape,pose};auto a=f.Query({-.5f,0,0},{0,1,0},.025f,shape.boundRadius,{1,0,0},&solid,true);near(a.fraction,0,0,"dry end cannot borrow across resolved vertical pocket");
 }
 std::cout<<n<<" checks "<<fail<<" failures\n";return fail?1:0;}
