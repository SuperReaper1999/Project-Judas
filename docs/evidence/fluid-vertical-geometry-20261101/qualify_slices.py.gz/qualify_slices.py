from pathlib import Path
import subprocess,json,time,os,hashlib
c=Path(__file__).resolve().parent;r=c.parents[1];b=r/'.cache/2d-stage1-build';out=c/'qualification';out.mkdir(exist_ok=True)
checks=[('vertical','judas_fluid_vertical_support_tests',[]),('hydro','judas_fluid_hydrostatics_tests',[]),('wet','judas_fluid_wet_support_tests',[]),('production','judas_production_fluid_tests',['--output',str(out/'production')]),('player','judas_player_fluid_integration_tests',['--output',str(out/'player')]),('containers','judas_fluid_container_integration_tests',['--supported-only','--output',str(out/'containers')]),('cavity','judas_fluid_cavity_impact_tests',[]),('demo-pool','judas_fluid_demo_integration_tests',['--scene','pool','--output',str(out/'demo-pool')]),('demo-planet','judas_fluid_demo_integration_tests',['--scene','planet','--output',str(out/'demo-planet')]),('lifecycle','judas_fluid_lifecycle_qualification_tests',[]),('basic-water','judas_project_water_tests',[])]
results=[]
for name,target,args in checks:
 start=time.monotonic();command=[str(b/target),*args]
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(command,cwd=r,env=dict(os.environ,JUDAS_ENGINE_ROOT=str(r)),stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((b/target).read_bytes()).hexdigest()});(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True)
