from pathlib import Path
import json,subprocess,time
R=Path.cwd();D=R/'.cache/prealpha-ccd-rethink/chronological-helper';rec=[]
plan=json.loads((R/'.cache/prealpha-ccd-rethink/correlated-cert/RUN_PLAN.json').read_text())['candidate']
def run(name,argv,cwd=R):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(list(map(str,argv)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=60).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec.append({'name':name,'argv':list(map(str,argv)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'RUNS.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,flush=True);return c
for name in ['ReacquisitionControls','CapturedSuffixProbe']:
 if run('compile-'+name,['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(D),'-I'+str(R/'src'),'-c',D/(name+'.cpp'),'-o',D/(name+'.o')]):continue
 link=plan[1]['argv'][:];link[1]=str(D/(name+'.o'));link[2]=str(R/'.cache/prealpha-ccd-rethink/forward-memo/CollisionGeometry.cpp.o');link[link.index('-o')+1]=str(D/name)
 if not run('link-'+name,link,Path(plan[1]['cwd'])):run('run-'+name,[D/name])
