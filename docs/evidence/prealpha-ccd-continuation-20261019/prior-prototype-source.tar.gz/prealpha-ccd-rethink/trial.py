from pathlib import Path
import subprocess,shlex,hashlib,json,time,sys,datetime
R=Path.cwd();B=R/'build';base=R/'.cache/prealpha-ccd-rethink';D=base/sys.argv[1];D.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rec={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':sha(B/'libjudas_engine.a'),'commands':[],'sources':{}}
def run(name,argv,cwd=R,timeout=100):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(list(map(str,argv)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec['commands'].append({'name':name,'argv':list(map(str,argv)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,round(time.monotonic()-t,3),flush=True);return c
args=[]
flags=(B/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines()
for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']:args+=shlex.split(next(x.split('=',1)[1] for x in flags if x.startswith(k+' =')))
objs=[];archive=D/'engine.a';archive.write_bytes((B/'libjudas_engine.a').read_bytes())
for name in ['WorldCCDSearch.cpp','WorldImpactEvents.cpp','CollisionGeometry.cpp']:
 p=D/name
 if not p.exists():continue
 rec['sources'][name]=sha(p);o=D/(name+'.o')
 if run('compile-'+name,['/usr/bin/c++',*args,'-I'+str(R/'src/physics'),'-c',p,'-o',o]):raise SystemExit(2)
 objs.append(str(o))
 if run('archive-'+name,['ar','d',archive,name+'.o']):raise SystemExit(2)
link=shlex.split((B/'CMakeFiles/judas_impact_mesh_cost_tests.dir/link.txt').read_text());link=[x for x in link if not x.startswith('-Wl,--dependency-file=')];link[1:1]=objs;link[link.index('libjudas_engine.a')]=str(archive);link[link.index('-o')+1]=str(D/'mesh')
if run('link-mesh',link,B):raise SystemExit(2)
rec['binary_sha256']=sha(D/'mesh')
probe=R/'docs/evidence/prealpha-pass4/ccd/probes/MinimalContinuationRepro.cpp';po=base/'minimal.o'
if not po.exists():
 if run('compile-minimal',['/usr/bin/c++','-std=c++17','-O3','-DNDEBUG','-I'+str(R/'src'),'-I'+str(R/'tests'),'-c',probe,'-o',po]):raise SystemExit(2)
mini=[x for x in link if not (x.endswith('.o') and 'judas_impact_mesh_cost_tests.dir' in x)];mini[1:1]=[str(po)];mini[mini.index('-o')+1]=str(D/'minimal')
if run('link-minimal',mini,B):raise SystemExit(2)
run('minimal',[D/'minimal'],timeout=40)
if '--minimal-only' in sys.argv:raise SystemExit(0)
run('curved',[D/'mesh','1','trough'],timeout=90)
run('entry',[D/'mesh','1','trough','1.2','entry'],timeout=90)
if '--full' in sys.argv:run('full',[D/'mesh','60','','1.2'],timeout=120)
