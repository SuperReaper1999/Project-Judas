// Same ragdoll workload as the original test. Only per-step observation and
// selection of one original scenario are added. Root owns all execution.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main

namespace {
Result Observe(const std::shared_ptr<CollisionAsset>& ground,bool curved,int steps,float throwSpeed){
    PhysicsWorld w;w.Init();
    if(ground)w.CreateShape(Shape::Cooked(ground,"impact cost sheet"),{},false,1,.6f,0);
    else w.CreateStaticBox({0,-.5f,0},{1.5f,.5f,1.5f},.6f,0);
    // Lay the standing pose face up along the trough (standing up -> +x, forward -> +y, arms across z).
    const glm::quat lie=glm::quat_cast(glm::mat3(glm::vec3(0,0,1),glm::vec3(1,0,0),glm::vec3(0,1,0)));const glm::vec3 offset{-.8f,.75f,-.5f};
    std::vector<BodyHandle> bodies;
    for(const auto& p:kParts){
        const glm::vec3 at=lie*p.position+offset;
        BodyHandle h=p.sphere?w.CreateDynamicSphere(at,p.half.x,p.mass,.6f,0):w.CreateDynamicBox(at,p.half,p.mass,.6f,0);
        w.ResetBody(h,at,lie);
        w.SetLinearVelocity(h,{0,-.5f,throwSpeed});w.SetAngularVelocity(h,{1.5f,0,.8f});bodies.push_back(h);
    }
    // Like WorldRagdoll without self-collision: bones never collide with each other.
    for(std::size_t a=0;a<bodies.size();++a)for(std::size_t b=a+1;b<bodies.size();++b)w.SetPairCollisionEnabled(bodies[a],bodies[b],false);
    for(const auto& j:kJoints){
        JointSettings s;s.type=JointType::Ball;s.bodyA=bodies[std::size_t(j.a)];s.bodyB=bodies[std::size_t(j.b)];
        // Anchors are body-local; every body starts with the same orientation `lie`.
        s.anchorA=glm::inverse(lie)*(j.at-kParts[std::size_t(j.a)].position);s.anchorB=glm::inverse(lie)*(j.at-kParts[std::size_t(j.b)].position);
        Check(w.CreateJoint(s).id!=0,"ragdoll joint created");
    }
    Result r;const float dt=1.f/60.f;ResetCollisionGeometryStats();
    for(int step=0;step<steps;++step){
        for(auto h:bodies)w.ApplyLinearAcceleration(h,{0,-9.81f,0},dt);
        const auto begin=std::chrono::steady_clock::now();w.Step(dt);
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        r.totalMs+=ms;r.worstMs=std::max(r.worstMs,ms);
        const auto& s=w.LastStepStats();
        r.impacts.impactQueries+=s.impactQueries;r.impacts.impactSearchIterations+=s.impactSearchIterations;r.impacts.impactSearchLimit+=s.impactSearchLimit;r.impacts.impactSearchStalls+=s.impactSearchStalls;
        r.impacts.impactSamplingFallbacks+=s.impactSamplingFallbacks;r.impacts.impactSamplingTests+=s.impactSamplingTests;r.impacts.impactEvents+=s.impactEvents;
        double deepest=0;for(std::size_t i=0;i<bodies.size();++i)deepest=std::max(deepest,Penetration(w.GetTransform(bodies[i]),kParts[i],curved));
        r.meanPenetration+=deepest/steps;if(deepest>r.maxPenetration){r.maxPenetration=deepest;r.deepestStep=step;}
        for(auto h:bodies){const auto t=w.GetTransform(h);const auto v=w.GetLinearVelocity(h),o=w.GetAngularVelocity(h);
            Mix(r.digest,&t.position,sizeof(t.position));Mix(r.digest,&t.rotation,sizeof(t.rotation));Mix(r.digest,&v,sizeof(v));Mix(r.digest,&o,sizeof(o));}
        std::cout<<"OBSERVE_STEP triangles="<<(ground?ground->faces.size():0)<<" step="<<step<<" ms="<<ms<<" digest="<<std::hex<<r.digest<<std::dec<<" queries="<<s.impactQueries<<" events="<<s.impactEvents<<" samples="<<s.impactSamplingTests<<'\n';
    }
    const auto g=GetCollisionGeometryStats();r.convexTests=g.convexTests;r.triangles=g.triangles;r.nodes=g.nodes;
    // Settled: nothing fell through or flew off.
    for(auto h:bodies){const auto p=w.GetTransform(h).position;Check(std::isfinite(p.x)&&p.y>-.3f&&p.y<3.f&&std::abs(p.x)<4&&std::abs(p.z)<4,"ragdoll stays on its support");}
    return r;
}

}

int main(int argc,char**argv){
    if(argc!=2){std::cerr<<"usage: matched-observer coarse|medium\n";return 2;}
    const std::string scenario=argv[1];
    int cellsX=0,cellsZ=0;
    if(scenario=="coarse"){cellsX=2;cellsZ=26;}
    else if(scenario=="medium"){cellsX=30;cellsZ=30;}
    else{std::cerr<<"unknown original scenario: "<<scenario<<'\n';return 2;}
    std::cout<<std::setprecision(17);
    const auto ground=Sheet(cellsX,cellsZ,true);
    const auto result=Observe(ground,true,60,1.2f);
    std::cout<<"OBSERVE_RESULT scenario="<<scenario<<" triangles="<<ground->faces.size()
             <<" steps=60 throwSpeed=1.2 totalMs="<<result.totalMs
             <<" worstStepMs="<<result.worstMs<<" maxPenetration="<<result.maxPenetration
             <<" meanPenetration="<<result.meanPenetration
             <<" queries="<<result.impacts.impactQueries<<" events="<<result.impacts.impactEvents
             <<" samples="<<result.impacts.impactSamplingTests
             <<" digest="<<std::hex<<result.digest<<std::dec
             <<" checks="<<checks<<" failures="<<failures<<'\n';
    return failures?1:0;
}
