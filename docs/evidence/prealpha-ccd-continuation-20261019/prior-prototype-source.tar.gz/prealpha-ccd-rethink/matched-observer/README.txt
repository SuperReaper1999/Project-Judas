Prepared only. No compile, link, execution or benchmark was run by the preparing agent.

MatchedObserver.cpp includes the original ImpactMeshCostTests.cpp with its main
renamed. Observe is an exact source copy of Run, with only its name changed and
one OBSERVE_STEP statement inserted after the existing per-step digest update.
The physics world, 13 bodies, 12 joints, input expressions, gravity, 1/60 timestep,
launch speed, profiling timer boundaries, support checks, digest update and
counter accumulation are unchanged. The new log is outside the existing Step
timer. It records original Step milliseconds, cumulative actual-state digest,
query count, event count and sampling count once per step.

The separate new main accepts exactly coarse or medium and runs the corresponding
original 2x26 or 30x30 curved sheet ragdoll once for 60 steps at launch speed 1.2.
It does not execute the original main, replay Run twice, run fast boxes or add a
new physical workload. OriginalRun.cpp.txt preserves the extracted function;
Run.diff shows every deliberate function change. SOURCE_IDENTITY.json records
that removing the one observation statement and undoing the rename reproduces
the source function byte for byte.

Root should compile this observer object once with src/tests include paths and
link the same object independently to the accepted baseline and rotation-world
archives using the existing original cost-test dependency list. Run matched
pairs sequentially. Per-step timings enable median/p95/worst summaries. Peak RSS
must come from the root-owned external process observer; this source does not
substitute an in-process memory metric. Report digest differences explicitly;
these timings cannot certify the currently failing lifetime adversary.
