from pathlib import Path
import subprocess,shlex,json,time
R=Path.cwd();B=R/'build';D=R/'.cache/prealpha-ccd-rethink/witness';rec=[]
def run(name,args,cwd=R):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=40).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec.append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'ALIGNMENT_RUNS.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,flush=True);return c
orig=shlex.split((B/'CMakeFiles/judas_collision_geometry_tests.dir/link.txt').read_text());orig=[x for x in orig if not x.startswith('-Wl,--dependency-file=') and not (x.endswith('.o') and 'judas_collision_geometry_tests.dir' in x)]
for test in ['WorldTipTorqueTests','HighSpinContinuationObserver']:
 o=D/(test+'.o')
 if run('compile-'+test,['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(R/'src'),'-I'+str(R/'tests'),'-c',str(D/(test+'.cpp')),'-o',str(o)]):continue
 for name,archive in [('alignment',R/'.cache/prealpha-ccd-rethink/witness-alignment/engine.a')]:
  link=orig[:];link[1:1]=[str(o)];link[link.index('libjudas_engine.a')]=str(archive)
  if name=='alignment':link[1:1]=[str(R/'.cache/prealpha-ccd-rethink/witness-alignment/CollisionGeometry.cpp.o')]
  exe=D/(test+'-'+name);link[link.index('-o')+1]=str(exe)
  if not run('link-'+test+'-'+name,link,B):run('run-'+test+'-'+name,[str(exe)])
