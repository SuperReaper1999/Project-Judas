Prepared certificate-only rotation-correlated native-edge variant. No build or test was run by the preparing agent.

Baseline headers are byte copies of projection-world/sources. Candidate differs
only in NativeSATContinuity.h. Existing projection-origin selection, normalized
axis handling, 1e-10 degeneracy cutoff, geometry, chronological policy and budgets
are unchanged. Original eight controls and captured suffix probe are unchanged.

EDGE PROOF
For the SAME actual represented double matrix R, local points x_i, shared native
center c, and native vertices p_i = fl(c + fl_dot3(R,x_i)), write u_i=R*x_i exactly
and e_offset_i = fl_dot3(R,x_i)-u_i. Then, over the reals,

 fl(p_to-p_from) = R*(x_to-x_from)
                   + e_offset_to - e_offset_from
                   + e_add_to - e_add_from + e_sub.

The first term is evaluated with interval matrix coefficients and exact-real
interval local-coordinate differences. Coordinates equal in both vertices
produce exact interval zero and therefore remove their shared rotation-column
width. The native errors in the operations whose common terms are cancelled
are retained explicitly: two original 3-product/2-addition offset dot envelopes,
two center-addition envelopes, and the native edge-subtraction envelope.
Every envelope uses the existing full-ULP binary64 error bound evaluated above an
outward operation-input magnitude. Nonfinite bounds fail closed. No matrix
orthogonality, exact inverse, or pre-rounded local edge vector is assumed.

NativeDotRoundingBound factors the identical native 3-product/2-addition envelope
already used by NativeShiftedProjection. NativeShiftedProjection's mathematical
enclosure is unchanged. Boxes and hulls preserve their original native local
vertices and use the same generalized edge helper.

This remains a sufficient-only interval certificate under the repository's
IEEE binary64 round-to-nearest, no-fast-math arithmetic contract. A narrower
certificate is not proof that any particular remaining world failure is closed;
root-owned unchanged local and physical controls must determine that.
