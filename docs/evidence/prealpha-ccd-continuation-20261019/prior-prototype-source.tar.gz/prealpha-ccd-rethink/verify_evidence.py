from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/"MANIFEST.json").read_text())
failed=[]
for item in manifest["files"]:
 p=root/item["path"]
 if not p.is_file() or p.stat().st_size!=item["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest()!=item["sha256"]:failed.append(item["path"])
print(json.dumps({"files_checked":len(manifest["files"]),"failures":failed},indent=2))
raise SystemExit(bool(failed))
