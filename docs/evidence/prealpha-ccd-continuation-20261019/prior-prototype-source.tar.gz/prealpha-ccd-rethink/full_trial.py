from pathlib import Path
import subprocess,shlex,json,time,hashlib,datetime,sys
R=Path.cwd();B=R/'build';D=R/'.cache/prealpha-ccd-rethink'/sys.argv[1];S=D/'sources';rec={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'archive_sha256':hashlib.sha256((B/'libjudas_engine.a').read_bytes()).hexdigest(),'sources':{str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*') if p.is_file()},'commands':[]}
def run(name,args,cwd=R,timeout=120):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(list(map(str,args)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec['commands'].append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'BUILD.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,round(time.monotonic()-t,3),flush=True);return c
args=['-I'+str(S),'-I'+str(S/'physics')];flags=(B/'CMakeFiles/judas_engine.dir/flags.make').read_text().splitlines()
for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']:args+=shlex.split(next(x.split('=',1)[1] for x in flags if x.startswith(k+' =')))
for n in ['UnifiedWorld.cpp','CollisionGeometry.cpp']:
 if '--reuse' not in sys.argv and not (n=='CollisionGeometry.cpp' and '--reuse-geometry' in sys.argv) and run('compile-'+n,['c++',*args,'-c',S/n,'-o',D/(n+'.o')],timeout=180):raise SystemExit(2)
archive=D/'engine.a';archive.write_bytes((B/'libjudas_engine.a').read_bytes());members=subprocess.check_output(['ar','t',archive],text=True).splitlines();names={'PhysicsWorld.cpp.o','CollisionGeometry.cpp.o'}|{f.name+'.o' for f in (S/'physics').glob('World*.cpp')};remove=[x for x in members if x in names];assert len(remove)==13 and remove.count('WorldPersistence.cpp.o')==2,remove
if run('archive-persistence',['ar','dN','2',archive,'WorldPersistence.cpp.o']):raise SystemExit(2)
if run('archive-world',['ar','d',archive,*[x for x in remove if x!='WorldPersistence.cpp.o']]):raise SystemExit(2)
link=shlex.split((B/'CMakeFiles/judas_impact_mesh_cost_tests.dir/link.txt').read_text());link=[x for x in link if not x.startswith('-Wl,--dependency-file=')];link[1:1]=[str(D/'UnifiedWorld.cpp.o'),str(D/'CollisionGeometry.cpp.o')];link[link.index('libjudas_engine.a')]=str(archive);link[link.index('-o')+1]=str(D/'mesh')
if run('link-mesh',link,B):raise SystemExit(2)
rec['binary_sha256']=hashlib.sha256((D/'mesh').read_bytes()).hexdigest()
run('curved',[D/'mesh','1','trough'],timeout=90)
if '--curved-only' in sys.argv:raise SystemExit(0)
run('entry',[D/'mesh','1','trough','1.2','entry'],timeout=90)
mini=[x for x in link if not (x.endswith('.o') and 'judas_impact_mesh_cost_tests.dir' in x)];mini[1:1]=[str(R/'.cache/prealpha-ccd-rethink/minimal.o')];mini[mini.index('-o')+1]=str(D/'minimal')
if not run('link-minimal',mini,B):run('minimal',[D/'minimal'],timeout=30)
helper=D/'ReacquisitionControls.cpp'
if helper.exists():
 if not run('compile-helper',['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(S),'-I'+str(R/'src'),'-c',helper,'-o',D/'helper.o']):
  hlink=mini[:];hlink[hlink.index(str(R/'.cache/prealpha-ccd-rethink/minimal.o'))]=str(D/'helper.o');hlink[hlink.index('-o')+1]=str(D/'helper')
  if not run('link-helper',hlink,B):run('helper',[D/'helper'],timeout=40)
if '--full' in sys.argv:run('full',[D/'mesh','60','','1.2'],timeout=120)
