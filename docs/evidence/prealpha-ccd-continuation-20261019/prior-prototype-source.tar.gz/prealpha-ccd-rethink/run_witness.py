from pathlib import Path
import subprocess,shlex,json,time,hashlib
R=Path.cwd();D=R/'.cache/prealpha-ccd-rethink/witness';B=R/'build';rec=[]
def run(name,args,cwd=R):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 rec.append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-t});(D/'RUNS.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,p.returncode,flush=True);return p.returncode
if run('compile-test',['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(R/'src'),'-c',str(D/'WitnessInvariantTests.cpp'),'-o',str(D/'test.o')]):raise SystemExit(1)
orig=shlex.split((B/'CMakeFiles/judas_collision_geometry_tests.dir/link.txt').read_text());orig=[x for x in orig if not x.startswith('-Wl,--dependency-file=') and not (x.endswith('.o') and 'judas_collision_geometry_tests.dir' in x)];orig[1:1]=[str(D/'test.o')]
for name,archive in [('baseline',B/'libjudas_engine.a'),('candidate',R/'.cache/prealpha-ccd-rethink/witness-only/engine.a')]:
 link=orig[:];link[link.index('libjudas_engine.a')]=str(archive)
 if name=='candidate':link[1:1]=[str(R/'.cache/prealpha-ccd-rethink/witness-only/CollisionGeometry.cpp.o')]
 link[link.index('-o')+1]=str(D/name)
 if run('link-'+name,link,B):raise SystemExit(1)
 run('test-'+name,[str(D/name)])
