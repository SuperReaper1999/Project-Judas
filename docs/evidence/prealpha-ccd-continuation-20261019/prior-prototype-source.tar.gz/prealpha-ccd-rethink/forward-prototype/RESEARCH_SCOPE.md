# Forward prototype source preparation

Cache only; no build or runtime result is claimed. This source set begins at the preserved, rejected Pass 5 union-v6 implementation and retains its research contact episodes, native endpoint equivalence gate, finite shared-edge propagation, target-directed backward ancestry and bounded ordinary front re-acquisition, per-feature penetration budgets, front-safe admission, experimental world publication/invalidation, and Boolean/full-response policy plumbing. Existing production-native null/unowned tiny-side reversal remains as in that source base.

This preparation makes one research-policy change: in ReacquireUnion, actual endpoint native front witnesses immediately acquire only their actual welded finite overlap components through MeshFiniteComponent. This refresh occurs before historical ancestry. An empty native witness set acquires no component. An unrelated overlapping patch is not an ownership grant.

The approved 4c141e9-to-146a0727 ImpactCandidateCache integration is also applied: the exact current header is snapshotted, the event pass owns one cache, and both actual-event island queries and dirty fat-bound queries use the original proxy-revision-aware adapter. It stores broadphase candidate IDs only.

All fixture values, 1024 interval budget, depth 40 bound and 32 witness-search iterations remain unchanged. The sibling correlated NativeSAT continuity overlay has not yet been applied. No forward memoization is included here.

## Coherent compilation requirement

Compile UnifiedWorld.cpp and CollisionGeometry.cpp using this sources directory and sources/physics before the production include directories. UnifiedWorld.cpp includes all eleven PhysicsWorld/private-world implementation units. Do not mix production private-world objects with this research Impl layout. When assembling an archive, preserve the first public world-save WorldPersistence.cpp.o and remove only the second physics-private WorldPersistence.cpp.o. All other replaced world objects and CollisionGeometry.cpp.o must also be removed.

## Retained readiness gaps

The source base is rejected research, and its three failed helper positive controls and original curved-fixture uncertainty remain historical failures until freshly measured. A fresh pass would still require proving finite departure/reentry ancestry, disconnected patch isolation, two-sided policy, sleep/wake and filter/resource/reset/destroy/slot identity handling, completed endpoint publication including position repair, bounded/pruned ownership, policy-aware geometry memoization, cold-process persistence/streaming and origin shifts, and practical matched performance. Throwing on bounded uncertainty inside the nontransactional world step remains research instrumentation. No save format or production ownership mechanism is added by this preparation.
