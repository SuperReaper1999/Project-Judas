Prepared certificate-only projection-recentering variant. No build or test was run by the preparing agent.

Baseline is a byte copy of chronological-world/sources headers. Candidate differs
only in NativeSATContinuity.h. Normal construction, edge construction, axis
normalization/degeneracy handling, contact policy, budgets and geometry remain
unchanged. The original eight helper controls and captured suffix source are
copied byte-for-byte beside the variants.

PROOF
For one actual represented pose let p_i be a native rounded poly vertex, n the
actual native normalized SAT axis, and b a single fixed native triangle vertex.
The original native projection is D_i = fl_dot3(p_i,n). Let e_i = D_i - dot(p_i,n)
where dot on the right is exact over the reals. Three native product rounding
errors and two native sum rounding errors give an outward bound |e_i| <= E_i.
Every operation's input magnitude is bounded outward, and the existing full-ULP
binary64 rounding bound is evaluated above that magnitude. Product and partial-sum
intervals retain the native rounded inputs needed for subsequent error bounds.
Overflow and uncertain arithmetic fail closed.

NativeShiftedProjection returns an enclosure of
    dot(p_i-b,n) + e_i = D_i - dot(b,n).
It uses outward shifted interval arithmetic, then adds [-E_i,E_i]. At every time
the scalar dot(b,n) is exactly the SAME for all body and triangle projections.
Subtracting it preserves every comparison of native support values and therefore
the sign of either SAT gap. The native subtraction producing a gap cannot turn a
nonpositive exact difference into a positive result under the existing IEEE
round-to-nearest contract. This is an added sufficient certificate, not a change
to the native collision calculation.

The common vertex is chosen as the static triangle vertex nearest the segment
midpoint primitive center. That selection is only a certificate-width heuristic;
any one fixed finite base would preserve the proof. The candidate does not
replace original native dot roundoff with shifted native arithmetic and does not
assume the fixed triangle rotation is an exact mathematical orthogonal matrix.

Axis intervals whose norm straddles the existing 1e-10 cutoff still fail closed.
This experiment therefore isolates common-origin projection dependency and makes
no claim to fix the separate near-zero-axis uncertainty.
