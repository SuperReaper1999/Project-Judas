// Preserve and expose the exact newly failing robustness trajectory. The
// original input, 90 steps, gravity and acceptance gates are unchanged.
#define main PreservedImpactRobustnessMain
#include "ImpactRobustnessTests.cpp"
#undef main
#include <iomanip>

int main() {
    std::cout<<std::setprecision(17);
    auto ground=Sheet(60);
    PhysicsWorld world;world.Init();
    world.CreateShape(Shape::Cooked(ground,"tilted sheet"),{},false,1,.6f,0);
    auto box=world.CreateDynamicBox({0,1.2f,0},{.02f,.01f,.03f},.2f,.4f,0);
    world.SetLinearVelocity(box,{0,-20,0});world.SetAngularVelocity(box,{45,0,27});
    PrimitivePose query,mesh;query.shape=Shape::Box({.02f,.01f,.03f});
    mesh.shape=Shape::Cooked(ground,"observer");
    double deepest=0,deepestCorner=0;bool sampledFailure=false,threw=false;
    const auto observe=[&](const BodyTransform& pose,const std::string& label) {
        query.parentPosition=pose.position;query.parentOrientation=pose.rotation;
        const auto manifold=ComputeContacts(query,mesh,0);
        double corner=-INFINITY;
        for(int c=0;c<8;++c) {
            const auto p=pose.position+pose.rotation*glm::vec3(c&1?.02f:-.02f,c&2?.01f:-.01f,c&4?.03f:-.03f);
            corner=std::max(corner,-double(p.y));
        }
        std::cout<<label<<" position="<<pose.position.x<<','<<pose.position.y<<','<<pose.position.z
                 <<" q="<<pose.rotation.w<<','<<pose.rotation.x<<','<<pose.rotation.y<<','<<pose.rotation.z
                 <<" center_side="<<pose.position.y<<" corner_depth="<<corner
                 <<" native_contacts="<<manifold.count;
        for(int k=0;k<manifold.count;++k)
            std::cout<<" contact"<<k<<"="<<manifold.points[k].signedSeparation
                     <<','<<manifold.points[k].preciseNormal.x<<','<<manifold.points[k].preciseNormal.y<<','<<manifold.points[k].preciseNormal.z;
        std::cout<<'\n';return corner;
    };
    try {
        for(int step=0;step<90;++step) {
            world.ApplyLinearAcceleration(box,{0,-9.81f,0},1.f/60.f);world.Step(1.f/60.f);
            const auto pose=world.GetTransform(box);const auto velocity=world.GetLinearVelocity(box);
            const auto angular=world.GetAngularVelocity(box);const auto stats=world.LastStepStats();
            const double corner=observe(pose,"HIGHSPIN step="+std::to_string(step));
            std::cout<<"HIGHSPIN_DYNAMICS step="<<step<<" v="<<velocity.x<<','<<velocity.y<<','<<velocity.z
                     <<" omega="<<angular.x<<','<<angular.y<<','<<angular.z
                     <<" queries="<<stats.impactQueries<<" events="<<stats.impactEvents
                     <<" sampling="<<stats.impactSamplingTests<<'\n';
            if(std::abs(pose.position.x)<=1.5f&&std::abs(pose.position.z)<=1.5f) {
                deepest=std::max(deepest,-double(pose.position.y));deepestCorner=std::max(deepestCorner,corner);
            }
            const auto segments=world.GetBodyMotionSegments(box);
            for(std::size_t s=0;s<segments.size();++s) {
                const auto& segment=segments[s];
                std::cout<<"HIGHSPIN_SEGMENT step="<<step<<" index="<<s
                         <<" begin="<<segment.begin<<" end="<<segment.end
                         <<" start_y="<<segment.start.position.y<<" end_y="<<segment.endPose.position.y
                         <<" v="<<segment.linearVelocity.x<<','<<segment.linearVelocity.y<<','<<segment.linearVelocity.z
                         <<" generator="<<segment.angularVelocity.x<<','<<segment.angularVelocity.y<<','<<segment.angularVelocity.z<<'\n';
            }
            if(!sampledFailure&&(pose.position.y<0||corner>.03)) {
                sampledFailure=true;
                for(std::size_t s=0;s<segments.size();++s)for(int k=0;k<=32;++k) {
                    const auto& segment=segments[s];const double time=segment.begin+(segment.end-segment.begin)*k/32.;
                    const auto sampled=PhysicsWorld::EvaluateBodyMotionSegment(segment,time);
                    observe(sampled,"HIGHSPIN_BOUNDARY step="+std::to_string(step)+" segment="+std::to_string(s)+" time="+std::to_string(time));
                }
            }
        }
    } catch(const std::exception& error) {threw=true;std::cerr<<"HIGHSPIN_THROW "<<error.what()<<'\n';}
    std::cout<<"HIGHSPIN_RESULT deepest="<<deepest<<" deepest_corner="<<deepestCorner<<" threw="<<threw<<'\n';
    return threw||deepest>.005||deepestCorner>.03?1:0;
}
