// Geometry-only adversary for triangle-vertex versus convex-face witnesses.
// This source exercises the public ComputeContacts dispatcher. Its geometric
// oracle is the authored triangle tip and the independently known lower face.
// It does not use SAT, the contact chooser, or another engine query as oracle.
#include "CollisionAsset.h"
#include "CollisionGeometry.h"
#include "MeshData.h"
#include "Narrowphase.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
int checks = 0, failures = 0;
constexpr double kTolerance = 2e-6;

void Check(bool ok, const std::string& label) {
    ++checks;
    if (!ok) {
        ++failures;
        std::cerr << "FAIL " << label << '\n';
    }
}

std::shared_ptr<CollisionAsset> Cook(const MeshData& source, bool convex) {
    auto asset = std::make_shared<CollisionAsset>();
    CollisionCookSettings settings;
    settings.convex = convex;
    std::string error;
    if (!CookCollision(source, settings, *asset, error))
        throw std::runtime_error("fixture cook: " + error);
    return asset;
}

MeshData TipTriangle() {
    MeshData result;
    // n = (-1,+1,-1)/sqrt(3); tip at the origin, with the rest below it.
    for (glm::vec3 p : {glm::vec3(0,0,0), glm::vec3(0,-1,-1), glm::vec3(-1,-1,0)}) {
        MeshVertex vertex;
        vertex.position = p;
        result.vertices.push_back(vertex);
    }
    result.indices = {0,1,2};
    return result;
}

MeshData CubeHull() {
    MeshData result;
    for (int z : {-1,1}) for (int y : {-1,1}) for (int x : {-1,1}) {
        MeshVertex vertex;
        vertex.position = glm::vec3(x,y,z) * .5f;
        result.vertices.push_back(vertex);
    }
    result.indices = {0,4,6,0,6,2,1,3,7,1,7,5,0,1,5,0,5,4,
                      2,6,7,2,7,3,0,2,3,0,3,1,4,5,7,4,7,6};
    return result;
}

glm::dvec3 WorldLocal(const PrimitivePose& pose, glm::dvec3 local) {
    return glm::dvec3(pose.parentPosition) + ContactRotation(pose.parentOrientation) * local;
}

void CheckPair(const PrimitivePose& query, const PrimitivePose& triangle,
               float margin, bool reverse, const std::string& label) {
    const auto manifold = reverse ? ComputeContacts(triangle, query, margin)
                                  : ComputeContacts(query, triangle, margin);
    Check(!manifold.uncertain, label + " resolved geometry");
    Check(manifold.count == 1, label + " exactly one admitted tip witness");
    const glm::dvec3 tip(triangle.parentPosition);
    const glm::dvec3 up = PrimitiveRotation(query)[1];
    // At this fixture the triangle tip projects into the interior of the
    // convex's lower face. The face center and normal give its plane directly.
    const glm::dvec3 lowerFaceCenter = PrimitiveCenter(query) - up * .5;
    const double expectedGap = glm::dot(up, lowerFaceCenter - tip);
    const glm::dvec3 expectedConvexWitness = tip + up * expectedGap;
    const glm::dvec3 expectedMidpoint = (expectedConvexWitness + tip) * .5;
    for (int i = 0; i < manifold.count; ++i) {
        const auto& contact = manifold.points[i];
        Check(contact.hasLocalAnchors, label + " precise physical witnesses");
        const auto& a = reverse ? triangle : query;
        const auto& b = reverse ? query : triangle;
        const glm::dvec3 wa = WorldLocal(a, contact.localWitnessA);
        const glm::dvec3 wb = WorldLocal(b, contact.localWitnessB);
        const glm::dvec3 qa = reverse ? wb : wa;
        const glm::dvec3 tb = reverse ? wa : wb;
        const glm::dvec3 normal = reverse ? -contact.preciseNormal : contact.preciseNormal;
        const glm::dvec3 anchorA = WorldLocal(a, contact.localAnchorA);
        const glm::dvec3 anchorB = WorldLocal(b, contact.localAnchorB);
        const double witnessGap = glm::dot(contact.preciseNormal, wa - wb);
        std::cout << "WITNESS " << label << " reverse=" << reverse
                  << " reported_gap=" << contact.signedSeparation
                  << " witness_gap=" << witnessGap
                  << " convex=" << qa.x << ',' << qa.y << ',' << qa.z
                  << " triangle=" << tb.x << ',' << tb.y << ',' << tb.z << '\n';
        Check(glm::length(normal-up) < kTolerance, label + " selected convex lower-face normal");
        Check(std::abs(contact.signedSeparation-expectedGap) < kTolerance,
              label + " signed gap agrees with independent lower-face plane");
        Check(std::abs(contact.signedSeparation-witnessGap) < kTolerance,
              label + " signed gap equals actual witness projection");
        Check(glm::length(tb-tip) < kTolerance, label + " mesh witness is authored tip");
        Check(glm::length(qa-expectedConvexWitness) < kTolerance,
              label + " convex witness is tip projection inside actual lower face");
        Check(glm::length(anchorA-expectedMidpoint) < kTolerance &&
              glm::length(anchorB-expectedMidpoint) < kTolerance,
              label + " solver anchors use physical witness midpoint");
        const glm::dvec3 actualMoment = glm::cross(anchorA-PrimitiveCenter(query), normal);
        const glm::dvec3 expectedMoment = glm::cross(expectedMidpoint-PrimitiveCenter(query), up);
        Check(glm::length(actualMoment-expectedMoment) < kTolerance,
              label + " unit normal impulse has correct moment arm");
    }
    Check(CookedHasContacts(query, triangle, margin) == (manifold.count > 0),
          label + " Boolean truth agrees with actual dispatcher");
}

void CheckNegatives(const Shape& shape, const Shape& triangleShape,
                    const glm::quat& frame, const std::string& label) {
    PrimitivePose triangle, query;
    triangle.shape = triangleShape;
    triangle.parentOrientation = frame;
    query.shape = shape;
    query.parentOrientation = frame;
    const auto rotation = ContactRotation(frame);
    // Mean behind the one-sided plane, while the body still straddles it.
    query.parentPosition = glm::vec3(rotation * glm::dvec3(0,-.1,0));
    Check(ComputeContacts(query,triangle,0).count == 0 &&
          ComputeContacts(triangle,query,0).count == 0 &&
          !CookedHasContacts(query,triangle,0), label + " rear-side straddling stays unblocked");
    // Front center and body straddling the infinite face plane y=x+z,
    // but separated from the finite triangle by at least 1.5 m in x/z.
    query.parentPosition = glm::vec3(rotation * glm::dvec3(2,4.1,2));
    for (float margin : {0.f,.1f}) {
        Check(ComputeContacts(query,triangle,margin).count == 0 &&
              ComputeContacts(triangle,query,margin).count == 0 &&
              !CookedHasContacts(query,triangle,margin), label + " finite triangle miss survives");
    }
}
} // namespace

int main() {
    try {
        std::cout << std::setprecision(17);
        const Shape triangleShape = Shape::Cooked(Cook(TipTriangle(),false), "tip adversary");
        const Shape hullShape = Shape::Cooked(Cook(CubeHull(),true), "cube hull adversary");
        const auto rotated = glm::angleAxis(.79f, glm::normalize(glm::vec3(1,2,-3)));
        for (bool hull : {false,true}) for (bool rotate : {false,true}) {
            const auto frame = rotate ? rotated : glm::quat(1,0,0,0);
            PrimitivePose query, triangle;
            query.shape = hull ? hullShape : Shape::Box({.5f,.5f,.5f});
            query.parentOrientation = frame;
            triangle.shape = triangleShape;
            triangle.parentOrientation = frame;
            const std::string label = std::string(hull ? "hull" : "box") + (rotate ? " rotated" : " identity");
            // Rotated touching uses a 1 micrometre observation margin to
            // include represented-position rounding; the physical oracle is
            // still the exact plane of these represented inputs.
            for (float centerHeight : {.5f,.49f,.51f}) {
                query.parentPosition = glm::vec3(ContactRotation(frame) * glm::dvec3(0,centerHeight,0));
                const float margin = centerHeight > .5f ? .02f : (rotate ? 1e-6f : 0.f);
                for (bool reverse : {false,true})
                    CheckPair(query,triangle,margin,reverse,label+" height="+std::to_string(centerHeight));
            }
            CheckNegatives(query.shape,triangleShape,frame,label);
        }
        std::cout << "checks " << checks << " failures " << failures << '\n';
        return failures ? 1 : 0;
    } catch (const std::exception& error) {
        std::cerr << "ERROR " << error.what() << '\n';
        return 2;
    }
}
