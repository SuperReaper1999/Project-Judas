// Build this as one geometry-plus-main translation unit, with no other
// CollisionGeometry replacement object. It directly observes the selected
// unmodified SAT result; it does not change any selection or expected values.
#ifndef WITNESS_GEOMETRY_SOURCE
#define WITNESS_GEOMETRY_SOURCE "CollisionGeometry.candidate.cpp"
#endif
#include WITNESS_GEOMETRY_SOURCE
#include "MeshData.h"
#include <iomanip>
#include <iostream>

namespace {
double AxisGap(const Poly& a,const Poly& b,V axis) {
    axis=unit(axis);double alo=INFINITY,ahi=-INFINITY,blo=INFINITY,bhi=-INFINITY;
    for(V p:a.points){const double value=glm::dot(p,axis);alo=std::min(alo,value);ahi=std::max(ahi,value);}
    for(V p:b.points){const double value=glm::dot(p,axis);blo=std::min(blo,value);bhi=std::max(bhi,value);}
    return std::max(alo-bhi,blo-ahi);
}
std::shared_ptr<CollisionAsset> CookFixture(bool hull) {
    MeshData source;
    if(hull) {
        for(int z:{-1,1})for(int y:{-1,1})for(int x:{-1,1}){MeshVertex vertex;vertex.position=glm::vec3(x,y,z)*.5f;source.vertices.push_back(vertex);}
        source.indices={0,4,6,0,6,2,1,3,7,1,7,5,0,1,5,0,5,4,2,6,7,2,7,3,0,2,3,0,3,1,4,5,7,4,7,6};
    } else {
        for(glm::vec3 p:{glm::vec3(0,0,0),glm::vec3(0,-1,-1),glm::vec3(-1,-1,0)}){MeshVertex vertex;vertex.position=p;source.vertices.push_back(vertex);}
        source.indices={0,1,2};
    }
    auto result=std::make_shared<CollisionAsset>();CollisionCookSettings settings;settings.convex=hull;std::string error;
    if(!CookCollision(source,settings,*result,error))throw std::runtime_error(error);return result;
}
}
int main() {
    std::cout<<std::setprecision(17);
    const auto triangle=CookFixture(false),hull=CookFixture(true);
    const auto frame=glm::angleAxis(.79f,glm::normalize(glm::vec3(1,2,-3)));
    for(bool useHull:{false,true})for(float x:{-.2f,0.f,.2f}) {
        PrimitivePose query,mesh;query.shape=useHull?Shape::Cooked(hull,"axis cube hull"):Shape::Box({.5f,.5f,.5f});
        query.parentOrientation=frame;query.parentPosition=glm::vec3(ContactRotation(frame)*glm::dvec3(x,.5,0));
        mesh.shape=Shape::Cooked(triangle,"axis tip triangle");mesh.parentOrientation=frame;
        Poly a,b;polyInto(a,query);triangleInto(b,*triangle,0,PrimitiveRotation(mesh),PrimitiveCenter(mesh));
        const auto selected=sat(a,b);
        std::cout<<"AXIS_SELECTED hull="<<useHull<<" x="<<x<<" edge="<<selected.edge
                 <<" gap="<<selected.gap<<" n="<<selected.normal.x<<','<<selected.normal.y<<','<<selected.normal.z<<'\n';
        for(std::size_t f=0;f<a.normals.size();++f)
            std::cout<<"AXIS_FACE index="<<f<<" gap="<<AxisGap(a,b,a.normals[f])
                     <<" alignment="<<glm::dot(a.normals[f],selected.normal)<<'\n';
        for(auto index:a.satEdges)for(auto i:b.satEdges) {
            const auto e=a.edges[index],f=b.edges[i];const V axis=glm::cross(a.points[e.second]-a.points[e.first],b.points[f.second]-b.points[f.first]);
            if(glm::length(axis)>eps)
                std::cout<<"AXIS_EDGE a="<<index<<" b="<<i<<" gap="<<AxisGap(a,b,axis)
                         <<" alignment="<<std::abs(glm::dot(unit(axis),selected.normal))<<'\n';
        }
        const auto manifold=CookedContacts(query,mesh,1e-6);
        for(int k=0;k<manifold.count;++k) {
            const auto& contact=manifold.points[k];
            const V wa=V(query.parentPosition)+ContactRotation(query.parentOrientation)*contact.localWitnessA;
            const V wb=V(mesh.parentPosition)+ContactRotation(mesh.parentOrientation)*contact.localWitnessB;
            std::cout<<"AXIS_WITNESS gap="<<contact.signedSeparation<<" projection="<<glm::dot(contact.preciseNormal,wa-wb)
                     <<" midpoint="<<contact.point.x<<','<<contact.point.y<<','<<contact.point.z<<'\n';
        }
    }
}
