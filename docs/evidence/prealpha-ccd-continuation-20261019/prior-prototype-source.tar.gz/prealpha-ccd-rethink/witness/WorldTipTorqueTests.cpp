// Independent physical impact oracle: frictionless downward contact at a
// triangle tip lying inside a cube's lower face. Gravity is absent in this
// isolated event; PhysicsWorld receives gravity only through explicit calls.
// This test is separate from the unchanged curved/high-spin acceptance tests.
#include "CollisionAsset.h"
#include "CollisionGeometry.h"
#include "MeshData.h"
#include "PhysicsWorld.h"

#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

namespace {
int checks=0, failures=0;
void Check(bool ok,const std::string& label) {
    ++checks;
    if(!ok){++failures;std::cerr<<"FAIL "<<label<<'\n';}
}
std::shared_ptr<CollisionAsset> Cook(const MeshData& source,bool convex=false) {
    auto asset=std::make_shared<CollisionAsset>();CollisionCookSettings settings;
    settings.convex=convex;std::string error;
    if(!CookCollision(source,settings,*asset,error))throw std::runtime_error(error);
    return asset;
}
MeshData TipTriangle() {
    MeshData source;
    for(glm::vec3 p:{glm::vec3(0,0,0),glm::vec3(0,-1,-1),glm::vec3(-1,-1,0)}) {
        MeshVertex vertex;vertex.position=p;source.vertices.push_back(vertex);
    }
    source.indices={0,1,2};return source;
}
MeshData CubeHull() {
    MeshData source;
    for(int z:{-1,1})for(int y:{-1,1})for(int x:{-1,1}) {
        MeshVertex vertex;vertex.position=glm::vec3(x,y,z)*.5f;source.vertices.push_back(vertex);
    }
    source.indices={0,4,6,0,6,2,1,3,7,1,7,5,0,1,5,0,5,4,
                    2,6,7,2,7,3,0,2,3,0,3,1,4,5,7,4,7,6};
    return source;
}
struct Trial {
    const char* name;
    glm::vec3 center,linear,angular;
};
void Run(const Shape& mesh,const Shape& cube,const Trial& trial,
         const glm::quat& frame,bool bodyFirst,const std::string& label) {
    constexpr float dt=1.f/60.f;
    constexpr double mass=1;
    // A unit cube of mass 1 has I=(1/6)Identity in every orientation.
    constexpr double inverseInertia=6;
    const auto rotation=ContactRotation(frame);
    const glm::vec3 center(rotation*glm::dvec3(trial.center));
    const glm::vec3 velocity(rotation*glm::dvec3(trial.linear));
    const glm::vec3 spin(rotation*glm::dvec3(trial.angular));
    PhysicsWorld world;world.Init();world.SetSleepingEnabled(false);
    BodyHandle body;
    const auto createBody=[&]{body=world.CreateShape(cube,{center,frame},true,1,0,0);};
    const auto createMesh=[&]{world.CreateShape(mesh,{{0,0,0},frame},false,1,0,0);};
    if(bodyFirst){createBody();createMesh();}else{createMesh();createBody();}
    world.SetLinearVelocity(body,velocity);world.SetAngularVelocity(body,spin);
    // Independent point impulse law at authored tip p=0. The normal is the
    // cube lower face's separating direction. Its normal offset caused by
    // float pose rounding does not change r cross n or the torque prediction.
    const glm::dvec3 normal=rotation[1],r=-glm::dvec3(center);
    const double vn=glm::dot(glm::dvec3(velocity)+glm::cross(glm::dvec3(spin),r),normal);
    const glm::dvec3 moment=glm::cross(r,normal);
    const double impulse=-vn/(1./mass+inverseInertia*glm::dot(moment,moment));
    const glm::dvec3 expectedLinear=glm::dvec3(velocity)+normal*(impulse/mass);
    const glm::dvec3 expectedAngular=glm::dvec3(spin)+inverseInertia*impulse*moment;
    world.Step(dt);
    const auto actualLinear=glm::dvec3(world.GetLinearVelocity(body));
    const auto actualAngular=glm::dvec3(world.GetAngularVelocity(body));
    const auto pose=world.GetTransform(body);
    std::cout<<"WORLD_TIP "<<label<<" body_first="<<bodyFirst
             <<" events="<<world.LastStepStats().impactEvents
             <<" impulse="<<impulse
             <<" linear="<<actualLinear.x<<','<<actualLinear.y<<','<<actualLinear.z
             <<" expected_linear="<<expectedLinear.x<<','<<expectedLinear.y<<','<<expectedLinear.z
             <<" angular="<<actualAngular.x<<','<<actualAngular.y<<','<<actualAngular.z
             <<" expected_angular="<<expectedAngular.x<<','<<expectedAngular.y<<','<<expectedAngular.z
             <<" position="<<pose.position.x<<','<<pose.position.y<<','<<pose.position.z<<'\n';
    Check(world.LastStepStats().impactEvents>0,label+" resolves an actual physical impact");
    Check(glm::length(actualLinear-expectedLinear)<2e-4,label+" linear velocity follows point impulse law");
    Check(glm::length(actualAngular-expectedAngular)<2e-4,label+" angular velocity follows physical moment arm");
    if(trial.center.x==0&&trial.center.z==0&&glm::length(trial.angular)==0)
        Check(glm::length(actualAngular)<2e-4,label+" centered zero-spin descent acquires no false spin");
    if(trial.linear.x!=0||trial.linear.z!=0) {
        const auto local=glm::transpose(rotation)*actualLinear;
        Check(std::abs(local.x-trial.linear.x)<2e-4&&std::abs(local.z-trial.linear.z)<2e-4,
              label+" frictionless tangential motion is retained");
    }
    if(trial.angular.y!=0) {
        const auto local=glm::transpose(rotation)*actualAngular;
        Check(std::abs(local.y-trial.angular.y)<2e-4,label+" preexisting yaw is retained");
    }
    if(trial.center.x!=0)
        Check(glm::length(actualAngular)>.5,label+" off-center physical contact retains real impact torque");
}
} // namespace
int main() {
    try {
        std::cout<<std::setprecision(17);
        const Shape mesh=Shape::Cooked(Cook(TipTriangle()),"physical tip witness");
        const Shape hull=Shape::Cooked(Cook(CubeHull(),true),"physical cube hull");
        const Trial trials[]={
            {"centered descent",{0,.5,0},{0,-1,0},{0,0,0}},
            {"tangential descent",{0,.5,0},{.2,-1,.3},{0,0,0}},
            {"yaw descent",{0,.5,0},{0,-1,0},{0,1,0}},
            {"positive offset",{.2,.5,0},{0,-1,0},{0,0,0}},
            {"negative offset",{-.2,.5,0},{0,-1,0},{0,0,0}}
        };
        const auto rotated=glm::angleAxis(.79f,glm::normalize(glm::vec3(1,2,-3)));
        for(bool useHull:{false,true})for(bool rotate:{false,true})for(bool bodyFirst:{false,true})
            for(const auto& trial:trials) {
                const auto frame=rotate?rotated:glm::quat(1,0,0,0);
                const std::string label=std::string(useHull?"hull ":"box ")+
                    (rotate?"rotated ":"identity ")+trial.name;
                Run(mesh,useHull?hull:Shape::Box({.5f,.5f,.5f}),trial,frame,bodyFirst,label);
            }
        std::cout<<"checks "<<checks<<" failures "<<failures<<'\n';return failures?1:0;
    } catch(const std::exception& error) {
        std::cerr<<"ERROR "<<error.what()<<'\n';return 2;
    }
}
