Isolated witness correction prepared at production HEAD 146a0727.

CollisionGeometry.baseline.cpp is a byte copy of src/CollisionGeometry.cpp.
CollisionGeometry.candidate.cpp changes one condition: allow the existing
convex-face reverse reference clipping branch when the other primitive is a
triangle. The finite SAT rejection, normal selection, active edge policy,
sidedness and manifold reduction are unchanged.

WitnessInvariantTests.cpp calls actual ComputeContacts and reconstructs the
returned physical witnesses and midpoint anchors. Its oracle is independent:
the authored triangle has a unique highest tip at the origin, touching the
interior of a convex lower face. The baseline is expected to report gap zero
using two nearest-edge witnesses whose normal projection is +0.25 m and whose
midpoint has a false torque arm. This expectation is hand-derived; the author
has not compiled or run it.

Coverage: axis-aligned and arbitrary common rotated frames; primitive box and
cooked cube hull; exact touch, 1 cm overlap and 1 cm positive gap with explicit
2 cm query margin; both argument orders; one-sided rear straddling and finite
triangle misses. Rotated touching uses an explicit 1 micrometre observation
margin to accommodate represented-position rounding in this independent test.
This does not alter the original fast-box fixture or any world acceptance gate.

Suggested parent execution: recover the exact CollisionGeometry compile flags
from the current build's compile_commands.json; compile baseline and candidate
as separate objects with -Isrc and the same dependency include directories.
Compile this test source once. Link it with each geometry object and the exact
current libjudas_engine.a and dependency libraries from the existing collision
geometry test link.txt. Place the replacement geometry object before the engine
archive so its original CollisionGeometry.cpp.o is not pulled from the archive.
Run both binaries, retaining exact commands, stdout, stderr and exit codes.

Follow with original unchanged ImpactMeshCostTests (full 90-step continuation
and independent entry), preserved 16-triangle MinimalContinuationRepro, and
existing CollisionGeometryTests including finite wall response cone controls.
The isolated witness pass cannot establish the root cause of curved CCD loss.
No compilation, linking, test or simulation was executed by this author.
