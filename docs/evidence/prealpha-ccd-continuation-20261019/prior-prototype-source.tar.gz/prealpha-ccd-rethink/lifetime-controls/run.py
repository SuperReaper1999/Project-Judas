from pathlib import Path
import subprocess,shlex,json,time
R=Path.cwd();D=R/'.cache/prealpha-ccd-rethink/lifetime-controls';B=R/'build';rec=[]
def run(name,args,cwd=R,timeout=100):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(list(map(str,args)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec.append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'RUNS.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,round(time.monotonic()-t,3),flush=True);return c
if run('compile',['c++','-std=c++17','-O3','-DNDEBUG','-I'+str(R/'src'),'-I'+str(R/'tests'),'-c',D/'UnrelatedFilterContinuationTests.cpp','-o',D/'probe.o']):raise SystemExit(2)
orig=shlex.split((B/'CMakeFiles/judas_impact_mesh_cost_tests.dir/link.txt').read_text());orig=[x for x in orig if not x.startswith('-Wl,--dependency-file=') and not (x.endswith('.o') and 'judas_impact_mesh_cost_tests.dir' in x)];orig[1:1]=[str(D/'probe.o')]
for mode in ['baseline','candidate']:
 link=orig[:]
 if mode=='candidate':
  V=R/'.cache/prealpha-ccd-rethink/rotation-world';link[1:1]=[str(V/'UnifiedWorld.cpp.o'),str(V/'CollisionGeometry.cpp.o')];link[link.index('libjudas_engine.a')]=str(V/'engine.a')
 link[link.index('-o')+1]=str(D/mode)
 if run('link-'+mode,link,B):continue
 for action in ['noop','far_disable','primary_disable']:run(mode+'-'+action,[D/mode,action,'-1','2','8','4'])
