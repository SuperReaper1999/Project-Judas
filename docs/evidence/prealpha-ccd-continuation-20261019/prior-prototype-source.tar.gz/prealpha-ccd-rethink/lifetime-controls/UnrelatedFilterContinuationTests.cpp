// An unrelated filter change may invalidate observations. It must not change
// an awake actor's physical continuation against its unchanged primary sheet.
// Includes the original source: geometry, 24 launches, dt, acceleration and
// actual-sheet crossing oracle are reused without edits.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main

#include <array>
#include <cstring>

namespace {
constexpr float kLifetimeDt=1.f/60.f;
struct LifeWorld {
    PhysicsWorld world;
    BodyHandle ground,actor,inert;
    LifeWorld(const std::shared_ptr<CollisionAsset>& asset,int index) {
        world.Init();
        // The test isolates invalidation from waking a sleeping island.
        // Both worlds use this identical diagnostic setting.
        world.SetSleepingEnabled(false);
        ground=world.CreateShape(Shape::Cooked(asset,"impact cost sheet"),{},false,1,.6f,0);
        const float along=-1.2f+.1f*float(index),grazing=float(index%6)*6.f;
        actor=world.CreateDynamicBox({along,1.2f,-1.f},{.02f,.01f,.03f},.2f,.4f,0);
        world.SetLinearVelocity(actor,{0,-40.f,grazing});
        // Present at the same handle/order in both worlds, and physically
        // separated by more than 1 km from the unchanged original launch.
        inert=world.CreateStaticBox({1000,1000,1000},{1,1,1},0,0);
    }
    void Step() {
        world.ApplyLinearAcceleration(actor,{0,-9.81f,0},kLifetimeDt);
        world.Step(kLifetimeDt);
    }
};
struct LifeState {
    BodyTransform pose;
    glm::vec3 linear,angular;
    bool sleeping=false;
};
LifeState State(const LifeWorld& value) {
    return {value.world.GetTransform(value.actor),value.world.GetLinearVelocity(value.actor),
            value.world.GetAngularVelocity(value.actor),value.world.IsSleeping(value.actor)};
}
std::array<float,13> Represented(const LifeState& s) {
    return {s.pose.position.x,s.pose.position.y,s.pose.position.z,
            s.pose.rotation.w,s.pose.rotation.x,s.pose.rotation.y,s.pose.rotation.z,
            s.linear.x,s.linear.y,s.linear.z,s.angular.x,s.angular.y,s.angular.z};
}
bool SameRepresented(const LifeState& a,const LifeState& b) {
    const auto first=Represented(a),second=Represented(b);
    return std::memcmp(first.data(),second.data(),sizeof(first))==0;
}
double RotationDelta(const LifeState& a,const LifeState& b) {
    const auto first=ContactRotation(a.pose.rotation),second=ContactRotation(b.pose.rotation);
    double result=0;
    for(int c=0;c<3;++c)for(int r=0;r<3;++r)result=std::max(result,std::abs(first[c][r]-second[c][r]));
    return result;
}
bool SamePhysical(const LifeState& a,const LifeState& b) {
    // No tolerance masks changed dynamics. Signed zero and quaternion sign
    // representations are allowed to differ only if the physical values do not.
    return a.pose.position==b.pose.position&&a.linear==b.linear&&a.angular==b.angular&&
           RotationDelta(a,b)==0&&a.sleeping==b.sleeping;
}
struct LifeObservation {
    bool readOk=false;
    unsigned primarySamples=0;
    int nativeContacts=0;
    double nativePenetration=0;
    std::size_t solvedRows=0,events=0,queries=0;
};
LifeObservation Observation(const LifeWorld& value,const std::shared_ptr<CollisionAsset>& asset) {
    LifeObservation result;
    std::vector<PhysicsWorld::BodyContactSample> samples;
    result.readOk=value.world.ReadBodyContactSample(value.actor,samples);
    for(const auto& sample:samples)if(sample.other.id==value.ground.id)++result.primarySamples;
    const auto state=State(value);
    PrimitivePose actor,mesh;
    actor.shape=Shape::Box({.02f,.01f,.03f});
    actor.parentPosition=state.pose.position;actor.parentOrientation=state.pose.rotation;
    mesh.shape=Shape::Cooked(asset,"independent stateless native observation");
    const auto manifold=ComputeContacts(actor,mesh,0);
    result.nativeContacts=manifold.count;
    for(int k=0;k<manifold.count;++k)
        result.nativePenetration=std::max(result.nativePenetration,-manifold.points[k].signedSeparation);
    result.solvedRows=value.world.LastStepContactCount();
    result.events=value.world.LastStepStats().impactEvents;
    result.queries=value.world.LastStepStats().impactQueries;
    return result;
}
void PrintState(const char* stage,const std::string& mode,int index,int prefix,int suffix,
                const LifeWorld& value,const std::shared_ptr<CollisionAsset>& asset) {
    const auto s=State(value);const auto observation=Observation(value,asset);
    const SheetOracle oracle(*asset);
    std::cout<<"LIFETIME_STATE stage="<<stage<<" mode="<<mode<<" box="<<index
             <<" prefix="<<prefix<<" suffix="<<suffix
             <<" position="<<s.pose.position.x<<','<<s.pose.position.y<<','<<s.pose.position.z
             <<" q="<<s.pose.rotation.w<<','<<s.pose.rotation.x<<','<<s.pose.rotation.y<<','<<s.pose.rotation.z
             <<" linear="<<s.linear.x<<','<<s.linear.y<<','<<s.linear.z
             <<" angular="<<s.angular.x<<','<<s.angular.y<<','<<s.angular.z
             <<" awake="<<!s.sleeping<<" original_depth="<<oracle.Depth(s.pose.position)
             <<" observation_ok="<<observation.readOk<<" primary_samples="<<observation.primarySamples
             <<" native_contacts="<<observation.nativeContacts<<" native_penetration="<<observation.nativePenetration
             <<" solved_rows="<<observation.solvedRows<<" events="<<observation.events<<" queries="<<observation.queries<<'\n';
}
bool ChangeFilter(LifeWorld& value,const std::string& mode) {
    if(mode=="far_disable")return value.world.SetPairCollisionEnabled(value.actor,value.inert,false);
    if(mode=="far_roundtrip") {
        const bool disabled=value.world.SetPairCollisionEnabled(value.actor,value.inert,false);
        const bool enabled=value.world.SetPairCollisionEnabled(value.actor,value.inert,true);
        return disabled&&enabled;
    }
    if(mode=="noop")return value.world.SetPairCollisionEnabled(value.actor,value.inert,true);
    if(mode=="primary_disable")return value.world.SetPairCollisionEnabled(value.actor,value.ground,false);
    throw std::invalid_argument("unknown mode");
}
} // namespace

int main(int argc,char** argv) {
    // All-box default covers prefixes 2..8 and four subsequent exact steps.
    // Optional filters make first diagnosis cheap without changing full mode:
    // mode, box (-1=all), first prefix, last prefix, suffix count.
    const std::string mode=argc>1?argv[1]:"far_disable";
    const int only=argc>2?std::atoi(argv[2]):-1;
    const int firstPrefix=argc>3?std::atoi(argv[3]):2;
    const int lastPrefix=argc>4?std::atoi(argv[4]):8;
    const int suffixCount=argc>5?std::atoi(argv[5]):4;
    if(only< -1||only>=24||firstPrefix<2||lastPrefix>8||firstPrefix>lastPrefix||suffixCount<1)
        throw std::invalid_argument("invalid diagnostic range");
    std::cout<<std::setprecision(17);
    const auto asset=Sheet(2,26,true);const SheetOracle oracle(*asset);
    int trials=0,physicalChanges=0,representedOnly=0,throws=0;
    int observationChanges=0,primaryActiveBefore=0,controlThrough=0,changedThrough=0;
    for(int prefix=firstPrefix;prefix<=lastPrefix;++prefix)for(int index=0;index<24;++index) {
        if(only>=0&&index!=only)continue;
        ++trials;
        LifeWorld control(asset,index),changed(asset,index);
        bool threw=false,prefixSame=true,physicalChanged=false,representationChanged=false;
        int firstChangedSuffix=-1;double maximumPosition=0,maximumRotation=0,maximumLinear=0,maximumAngular=0;
        try {
            for(int step=0;step<prefix;++step) {
                control.Step();changed.Step();
                prefixSame&=SamePhysical(State(control),State(changed));
            }
            Check(prefixSame,"paired original prefixes have identical physical fields");
            Check(!control.world.IsSleeping(control.actor)&&!changed.world.IsSleeping(changed.actor),
                  "both original actors are awake at unrelated filter boundary");
            const auto before=State(changed);
            const auto observationBefore=Observation(changed,asset);
            if(observationBefore.primarySamples||observationBefore.nativeContacts)++primaryActiveBefore;
            PrintState("before_control",mode,index,prefix,0,control,asset);
            PrintState("before_changed",mode,index,prefix,0,changed,asset);
            Check(ChangeFilter(changed,mode),"filter API accepts the intended live pair");
            const auto observationAfter=Observation(changed,asset);
            if(observationBefore.readOk!=observationAfter.readOk||
               observationBefore.primarySamples!=observationAfter.primarySamples)++observationChanges;
            Check(SamePhysical(before,State(changed)),"filter mutation itself does not teleport or rewrite velocities");
            PrintState("after_mutation",mode,index,prefix,0,changed,asset);
            for(int suffix=1;suffix<=suffixCount;++suffix) {
                control.Step();changed.Step();
                const auto a=State(control),b=State(changed);
                const bool same=SamePhysical(a,b);
                if(!same&&!physicalChanged)firstChangedSuffix=suffix;
                physicalChanged|=!same;
                representationChanged|=!SameRepresented(a,b);
                maximumPosition=std::max(maximumPosition,glm::length(glm::dvec3(a.pose.position)-glm::dvec3(b.pose.position)));
                maximumRotation=std::max(maximumRotation,RotationDelta(a,b));
                maximumLinear=std::max(maximumLinear,glm::length(glm::dvec3(a.linear)-glm::dvec3(b.linear)));
                maximumAngular=std::max(maximumAngular,glm::length(glm::dvec3(a.angular)-glm::dvec3(b.angular)));
                Check(!a.sleeping&&!b.sleeping,"both compared suffix actors remain awake");
                if(!same||suffix==suffixCount) {
                    PrintState("suffix_control",mode,index,prefix,suffix,control,asset);
                    PrintState("suffix_changed",mode,index,prefix,suffix,changed,asset);
                }
            }
        } catch(const std::exception& error) {
            threw=true;++throws;std::cerr<<"LIFETIME_THROW mode="<<mode<<" box="<<index<<" prefix="<<prefix<<" error="<<error.what()<<'\n';
        }
        Check(!threw,"paired lifetime trajectory does not throw");
        if(physicalChanged)++physicalChanges;
        if(representationChanged&&!physicalChanged)++representedOnly;
        if(oracle.Depth(State(control).pose.position)>.05)++controlThrough;
        if(oracle.Depth(State(changed).pose.position)>.05)++changedThrough;
        if(mode!="primary_disable")Check(!physicalChanged,"unrelated filter edit preserves primary physical trajectory");
        std::cout<<"LIFETIME_TRIAL mode="<<mode<<" box="<<index<<" prefix="<<prefix
                 <<" suffix_steps="<<suffixCount<<" prefix_same="<<prefixSame
                 <<" physical_changed="<<physicalChanged<<" first_changed_suffix="<<firstChangedSuffix
                 <<" represented_changed="<<representationChanged<<" max_position_delta="<<maximumPosition
                 <<" max_rotation_matrix_delta="<<maximumRotation<<" max_linear_delta="<<maximumLinear
                 <<" max_angular_delta="<<maximumAngular<<" threw="<<threw<<'\n';
    }
    // A relevant suppression is a positive control: over the complete original
    // launch matrix at least one actively supported trajectory must respond.
    if(mode=="primary_disable"&&only<0&&firstPrefix==2&&lastPrefix==8)
        Check(physicalChanges>0,"positive control: suppressing the actual sheet changes physical continuation");
    std::cout<<"LIFETIME_RESULT mode="<<mode<<" trials="<<trials<<" physical_changes="<<physicalChanges
             <<" represented_only="<<representedOnly<<" observation_changes="<<observationChanges
             <<" primary_active_before="<<primaryActiveBefore<<" control_endpoints_through="<<controlThrough
             <<" changed_endpoints_through="<<changedThrough<<" throws="<<throws
             <<" checks="<<checks<<" failures="<<failures<<'\n';
    return failures?1:0;
}
