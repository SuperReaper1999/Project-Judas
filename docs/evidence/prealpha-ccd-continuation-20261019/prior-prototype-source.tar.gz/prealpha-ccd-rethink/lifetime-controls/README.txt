Unrelated filter invalidation adversary, prepared without compilation/execution.

Compile UnrelatedFilterContinuationTests.cpp with the current engine test flags
and -Itests. It includes the original tests/ImpactMeshCostTests.cpp with main
renamed and reuses Sheet(2,26,true), all original 24 launches, thin box shape,
mass/material, gravity, 1.f/60.f and original actual-sheet 5 cm oracle.

Every trial contains two independently initialized worlds with the same sheet,
same original actor and a static box at (1000,1000,1000). Sleeping is disabled
identically in both to exclude the documented wake effect of filter changes.
After an identical prefix of 2..8 fixed steps, only one world receives the
selected API action. Four subsequent fixed steps are compared by default.

Modes (first command argument):
  far_disable  (default): disable actor versus inert distant static body.
  far_roundtrip: disable then reenable that same unrelated pair before stepping.
  noop: explicitly enable the already-enabled unrelated pair.
  primary_disable: suppress actor versus actual sheet, a positive physical control.

Additional optional arguments: box index (-1 for all24), first prefix, last
prefix, suffix count. Default is: far_disable -1 2 8 4.
Quick specific example: far_disable 0 2 2 4.
Full controls: run each mode with -1 2 8 4 against baseline and prototype.

Failure means a changed actual physical field, a prefix mismatch, sleeping,
an invalid API operation or a throw. No epsilon hides changed motion. Signed
zero and opposite quaternion signs are distinguished in a separate byte-level
diagnostic; only actual equal rotations can be physically equal. The original
5 cm oracle is reported for both endpoints but is not substituted for physical
trajectory comparison, since baseline itself has the known curved crossings.

ReadBodyContactSample observation validity/sample counts are reported before
and immediately after the action. Their change is NOT a physical failure.
Stateless native zero-margin contacts and penetration are reported separately
from completed physical rows and actual motion/velocity differences. A history-
aware prototype may physically support a pose whose stateless native manifold
is empty; the test does not equate those concepts or inspect private caches.

The actual mesh filter suppression is permitted to change physics. Over the
complete 168-trial matrix it must change at least one trajectory, making the
physical observer a positive control. Inert-pair and no-op modes require no
physical change. Neither engine source nor the original fixtures were edited.

This source does not claim a cold save/load test or restoration of all caches.
