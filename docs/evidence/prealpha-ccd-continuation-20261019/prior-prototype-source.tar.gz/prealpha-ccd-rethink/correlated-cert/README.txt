Certificate-only preparation; no build or test was run by the preparing agent.

Baseline headers are byte copies of docs/evidence/prealpha-pass5/ccd/research/union-v5/sources.
Candidate differs only in NativeSATContinuity.h. Geometry, ownership policy,
NativeOverlapThroughout axes, overlap acceptance, subdivision, depth and default
1,024-interval bound are otherwise unchanged.

Probe.preserved.cpp is the exact original native-acquisition-v1/Probe.cpp.
CapturedSuffixProbe.cpp uses the identical shape, mesh, segment, target,
32-step front-side bisection and suffix certification call. It removes only the
separate original-anchor run and its assertion that this old algorithm remains
uncertain. The five positive physical/suffix controls are retained unchanged.
The preserved baseline suffix result was Connected, 509 intervals, 255 certificates.

ROUNDING ARGUMENT
For one actual represented pose let c be the common native polyInto center,
u/v the native rotated local offsets, p=fl(c+u), q=fl(c+v), d=fl(q-p).
Then d=(v-u)+e_v-e_u+e_sub exactly over the reals. The existing interval
transforms enclose u,v,c and p,q with the same GLM double arithmetic. A native
addition error is bounded by a full binary64 ULP above an outward upper bound
on |c|+|u| (or |c|+|v|); subtraction uses |q|+|p|. The ULP is computed above the
bound using nextafter twice, with outward interval subtraction for its value.
This includes subnormal results. Nonfinite bounds fail closed.
NativeVertexDifference returns (V-U)+[-E,E] with outward E equal to the sum of
these three bounds, hence contains the actual native edge. It removes the two
uncorrelated copies of the center interval but retains all three native
rounding errors. Normal cross products and normalization still use the original
interval operations; no orthogonality or exact matrix identity is assumed.

The argument uses the repository's existing arithmetic contract: IEEE binary64,
round-to-nearest, no fast-math. It does not extend or alter that contract.

ROOT-OWNED EXECUTION
RUN_PLAN.json records independent baseline/candidate compile/link/run commands
adapted from the exact preserved native-acquisition build receipt. Run the two
probes sequentially. Compare the same NEW_ANCHOR result, interval count,
certificate count, and five positive controls. Do not interpret this local
certificate experiment as a world CCD repair or performance conclusion.
