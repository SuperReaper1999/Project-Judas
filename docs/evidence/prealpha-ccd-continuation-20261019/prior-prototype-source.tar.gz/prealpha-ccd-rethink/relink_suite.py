from pathlib import Path
import subprocess,shlex,json,time,sys
R=Path.cwd();B=R/'build';D=R/'.cache/prealpha-ccd-rethink'/sys.argv[1];rec=[]
for target in sys.argv[2:]:
 link=shlex.split((B/'CMakeFiles'/f'{target}.dir/link.txt').read_text());link=[x for x in link if not x.startswith('-Wl,--dependency-file=')]
 objs=[str(x) for x in D.glob('*.cpp.o')]
 if 'libjudas_engine.a' in link:link[link.index('libjudas_engine.a')]=str(D/'engine.a')
 else:
  private={'PhysicsWorld.cpp.o','CollisionGeometry.cpp.o'}|{p.name+'.o' for p in (R/'src/physics').glob('World*.cpp')}
  link=[x for x in link if not (x.endswith('.o') and Path(x).name in private)]
 link[1:1]=objs;exe=D/target;link[link.index('-o')+1]=str(exe)
 for name,args,cwd in [('link-'+target,link,B),('run-'+target,[str(exe)],R)]:
  t=time.monotonic()
  with (D/(name+'.log')).open('w') as f:
   try:c=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=180).returncode
   except subprocess.TimeoutExpired:c='timeout'
  rec.append({'name':name,'argv':args,'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'SUITES.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,round(time.monotonic()-t,3),flush=True)
  if name.startswith('link') and c:raise SystemExit(2)
