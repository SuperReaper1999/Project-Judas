#pragma once
#include <iostream>
#include "MeshContinuityProbe.h"
#include "NativeSATContinuity.h"

namespace episode_probe {
struct UnionMeasurement {
    Measurement measure;
    MeshContactEpisode selected;
    unsigned reacquisitionSearches=0,reacquisitionWitnesses=0;
};

inline double NativeMeshSide(const PrimitivePose&query,const PrimitivePose&mesh,unsigned feature){
    V center(0);const auto r=PrimitiveRotation(query);const auto c=PrimitiveCenter(query)-PrimitiveCenter(mesh);
    if(query.shape.type==ShapeType::Box){const V h(query.shape.halfExtents);for(int z:{-1,1})for(int y:{-1,1})for(int x:{-1,1})center+=c+r*V(x*h.x,y*h.y,z*h.z);center/=8.;}
    else{for(V point:query.shape.asset->vertices)center+=c+r*point;center/=double(query.shape.asset->vertices.size());}
    const auto fixed=PrimitiveRotation(mesh);const auto&face=mesh.shape.asset->faces[feature];
    return glm::dot(fixed*face.normal,center-fixed*mesh.shape.asset->vertices[face.vertices[0]]);
}
inline std::vector<uint32_t> NativeFrontFeatures(const PrimitivePose&query,const PrimitivePose&mesh){
    auto result=MeshContactFeatures(query,mesh,nullptr);
    result.erase(std::remove_if(result.begin(),result.end(),[&](auto f){return NativeMeshSide(query,mesh,f)<0;}),result.end());
    return result;
}

// This is an independent forward-only helper. Each invocation owns its derived
// checkpoints; it does not mutate the physical world or a durable episode.
struct ForwardCheckpoint { double time=0;unsigned topology=0;MeshContactEpisode selected; };
struct ForwardMeasurement {
    UnionMeasurement value;
    std::vector<ForwardCheckpoint> checkpoints;
};

inline void ForwardMerge(std::vector<uint32_t>&to,const std::vector<uint32_t>&from){
    to.insert(to.end(),from.begin(),from.end());std::sort(to.begin(),to.end());
    to.erase(std::unique(to.begin(),to.end()),to.end());
}

// Static welded components limit possible ownership transfer. Two disconnected
// components can be advanced independently, including when one is persistently
// touching and another has a genuine finite departure. This is an exclusion
// partition only; membership never grants ownership inside a component.
inline std::vector<unsigned> ForwardTopology(const CollisionAsset&asset){
    std::vector<unsigned> labels(asset.faces.size(),UINT32_MAX);unsigned label=0;
    for(unsigned seed=0;seed<labels.size();++seed)if(labels[seed]==UINT32_MAX){
        std::vector<unsigned> pending{seed};labels[seed]=label;
        for(std::size_t at=0;at<pending.size();++at)for(auto next:asset.faces[pending[at]].adjacent)
            if(next>=0&&labels[unsigned(next)]==UINT32_MAX){labels[unsigned(next)]=label;pending.push_back(unsigned(next));}
        ++label;
    }
    return labels;
}

// Encloses the actual native represented vertex mean and all native candidate
// bounds on one dynamic Cayley segment. The box mean uses exact opposite-offset
// symmetry, not an assumption that floating vertex accumulation equals the COM.
struct ForwardMeanBound { IV mean;std::vector<uint32_t> candidates; };
inline std::optional<ForwardMeanBound> ForwardNativeMeanBound(const PrimitivePose&query,
    const PrimitivePose&mesh,const RigidMotionSegment&segment,double first,double last){
    if(segment.prescribed||(query.shape.type!=ShapeType::Box&&query.shape.type!=ShapeType::ConvexHull))return std::nullopt;
    try{
        const auto from=segment.EvaluateGeometry(first),to=segment.EvaluateGeometry(last);
        auto parent=rigid_motion_bounds::TryDynamicRotationInterval(segment,first,last);
        if(segment.driftAngularVelocity==glm::vec3(0)&&rigid_motion_bounds::SameQuat(from.orientation,to.orientation)){
            contact_geometry::M<Iv> exact;const auto r=ContactRotation(from.orientation);
            for(unsigned j=0;j<3;++j)for(unsigned k=0;k<3;++k)exact[j][k]=Iv(r[j][k]);parent=exact;
        }
        if(!parent)return std::nullopt;
        const auto child=ContactRotation(query.childRotation);contact_geometry::M<Iv> rotation;
        for(unsigned j=0;j<3;++j)for(unsigned k=0;k<3;++k){rotation[j][k]=Iv(0);for(unsigned l=0;l<3;++l)rotation[j][k]=rotation[j][k]+(*parent)[l][k]*Iv(child[j][l]);}
        const V origin=PrimitiveCenter(mesh);IV center=Times(*parent,V(query.parentLocalCenter));
        for(unsigned k=0;k<3;++k)center[k]=(Iv(double(std::min(from.position[k],to.position[k])),double(std::max(from.position[k],to.position[k])))+center[k])-Iv(origin[k]);
        std::vector<IV> offsets,points;
        if(query.shape.type==ShapeType::Box){
            const V h(query.shape.halfExtents);
            for(int z:{-1,1})for(int y:{-1,1})for(int x:{-1,1})offsets.push_back(Times(rotation,V(x*h.x,y*h.y,z*h.z)));
        }else for(V p:query.shape.asset->vertices)offsets.push_back(Times(rotation,p));
        if(offsets.empty())return std::nullopt;
        for(const auto&offset:offsets)points.push_back(Add(center,offset));
        ForwardMeanBound result;
        if(query.shape.type==ShapeType::Box){
            // GLM's same matrix/vector expression is odd under v -> -v in
            // IEEE round-to-nearest arithmetic. Its eight opposite offsets
            // therefore sum to zero over the reals, including signed zeros.
            for(unsigned k=0;k<3;++k){
                Iv additions(0),sumErrors(0),accumulatorMagnitude(0);
                for(unsigned i=0;i<points.size();++i){
                    const auto add=NativeDoubleRoundingBound(contact_geometry::Abs(center[k])+contact_geometry::Abs(offsets[i][k]));
                    const Iv nextMagnitude=accumulatorMagnitude+contact_geometry::Abs(points[i][k]);
                    const auto sum=NativeDoubleRoundingBound(nextMagnitude);
                    if(!add||!sum)return std::nullopt;
                    additions=additions+Iv(*add);sumErrors=sumErrors+Iv(*sum);
                    accumulatorMagnitude=nextMagnitude+Iv(*sum);
                }
                const auto divide=NativeDoubleRoundingBound(accumulatorMagnitude/Iv(8));
                if(!divide)return std::nullopt;
                const Iv error=(additions+sumErrors)/Iv(8)+Iv(*divide);
                result.mean[k]=center[k]+Iv(-error.hi,error.hi);
            }
        }else{
            // A hull's vertex mean can rotate away from its origin. Keep the
            // full native accumulation enclosure rather than invent symmetry.
            result.mean={Iv(0),Iv(0),Iv(0)};
            for(const auto&p:points)result.mean=Add(result.mean,p);
            for(auto&x:result.mean)x=x/Iv(double(points.size()));
        }
        // Match the native candidates() bound construction: vertices acquire
        // the mesh origin before the world AABB, then the common origin is
        // subtracted before the static transpose rotation. Retaining both
        // operations encloses the actual native roundoff at large origins.
        IV world{Iv(INFINITY,-INFINITY),Iv(INFINITY,-INFINITY),Iv(INFINITY,-INFINITY)};
        for(const auto&p:points)for(unsigned k=0;k<3;++k){const auto placed=p[k]+Iv(origin[k]);world[k].lo=std::min(world[k].lo,placed.lo);world[k].hi=std::max(world[k].hi,placed.hi);}
        const M inverse=glm::transpose(PrimitiveRotation(mesh));IV local{Iv(0),Iv(0),Iv(0)};
        for(unsigned k=0;k<3;++k)for(unsigned j=0;j<3;++j)local[k]=local[k]+Iv(inverse[j][k])*(world[j]-Iv(origin[j]));
        V lo,hi;for(unsigned k=0;k<3;++k){lo[k]=local[k].lo;hi[k]=local[k].hi;if(!std::isfinite(lo[k])||!std::isfinite(hi[k]))return std::nullopt;}
        mesh.shape.asset->Candidates(lo,hi,result.candidates);
        return result;
    }catch(const contact_geometry::ArithmeticFailure&){return std::nullopt;}
}

// Strictly outside even the native negative epsilon band. This proves absence
// of any ordinary-front reacquisition anywhere the native finite query could
// visit during this interval. It supplies no positive contact or ownership.
inline bool ForwardNoFrontThroughout(const PrimitivePose&query,const PrimitivePose&mesh,
    const RigidMotionSegment&segment,double first,double last,
    const std::vector<unsigned>&labels,unsigned label){
    const auto bound=ForwardNativeMeanBound(query,mesh,segment,first,last);if(!bound)return false;
    const M fixed=PrimitiveRotation(mesh);
    for(auto f:bound->candidates)if(labels[f]==label){
        const auto&face=mesh.shape.asset->faces[f];const V n=fixed*face.normal,p=fixed*mesh.shape.asset->vertices[face.vertices[0]];
        const Iv side=Dot(Point(n),Sub(bound->mean,Point(p)));
        if(!(side.hi< -1e-10))return false;
    }
    return true;
}

inline ForwardMeasurement ForwardEpisode(const PrimitivePose&query,const PrimitivePose&mesh,
    const MeshContactEpisode&old,const RigidMotionSegment&segment,double start,double finish,
    unsigned maximumIntervals=1024,std::optional<unsigned> onlyFeature=std::nullopt){
    ForwardMeasurement result;
    if(mesh.shape.type!=ShapeType::TriangleMesh||!mesh.shape.asset||mesh.shape.asset->twoSided||
       (query.shape.type!=ShapeType::Box&&query.shape.type!=ShapeType::ConvexHull)||
       segment.prescribed||!std::isfinite(start)||!std::isfinite(finish)||start>finish||
       start<segment.begin||finish>segment.end)return result;
    const auto labels=ForwardTopology(*mesh.shape.asset);
    if(onlyFeature&&*onlyFeature>=labels.size())return result;
    const auto beginning=At(query,segment,start),ending=At(query,segment,finish);
    auto initialSeeds=old.fronts;ForwardMerge(initialSeeds,NativeFrontFeatures(beginning,mesh));
    const auto initial=MeshFiniteComponent(beginning,mesh,initialSeeds);
    const auto endpoint=MeshFiniteComponent(ending,mesh,{},true);
    std::vector<unsigned> relevant;
    if(onlyFeature)relevant.push_back(labels[*onlyFeature]);
    else{for(auto f:initial)relevant.push_back(labels[f]);for(auto f:endpoint)relevant.push_back(labels[f]);std::sort(relevant.begin(),relevant.end());relevant.erase(std::unique(relevant.begin(),relevant.end()),relevant.end());}
    const auto filtered=[&](const std::vector<uint32_t>&faces,unsigned label){std::vector<uint32_t> out;for(auto f:faces)if(labels[f]==label)out.push_back(f);return out;};
    const auto checkpoint=[&](double time,unsigned label,const std::vector<uint32_t>&selected){result.checkpoints.push_back({time,label,MeshContactEpisode{selected}});};
    for(auto label:relevant){
        auto selected=filtered(initial,label);checkpoint(start,label,selected);
        const auto walk=[&](const auto&self,double first,double last,unsigned depth)->bool{
            if(++result.value.measure.intervals>maximumIntervals)return false;
            const auto to=At(query,segment,last);
            const auto actual=filtered(MeshFiniteComponent(to,mesh,{},true),label);
            if(actual.empty()){
                // The state at a real finite absence is empty regardless of
                // all earlier history. No other static component can bridge it.
                selected.clear();result.value.measure.separationTime=last;checkpoint(last,label,selected);return true;
            }
            const auto native=filtered(MeshFiniteComponent(to,mesh,NativeFrontFeatures(to,mesh)),label);
            if(Constant(segment,first,last)){
                auto seeds=selected;ForwardMerge(seeds,native);selected=filtered(MeshFiniteComponent(to,mesh,seeds),label);
                ++result.value.measure.constantCertificates;checkpoint(last,label,selected);return true;
            }
            auto next=native;std::vector<uint32_t> visited;bool unresolved=false;
            for(auto feature:actual){
                if(std::binary_search(visited.begin(),visited.end(),feature))continue;
                const auto component=filtered(MeshFiniteComponent(to,mesh,{feature}),label);ForwardMerge(visited,component);
                if(std::binary_search(next.begin(),next.end(),feature))continue;
                bool bridged=false;
                for(auto owned:selected)if(std::binary_search(component.begin(),component.end(),owned)&&
                    NativeOverlapThroughout(query,mesh,owned,segment,first,last)){
                    ++result.value.measure.pointCertificates;ForwardMerge(next,component);bridged=true;break;
                }
                if(!bridged)unresolved=true;
            }
            if(!unresolved){selected=std::move(next);checkpoint(last,label,selected);return true;}
            if(selected.empty()&&ForwardNoFrontThroughout(query,mesh,segment,first,last,labels,label)){
                selected.clear();checkpoint(last,label,selected);return true;
            }
            const double middle=(first+last)*.5;
            if(depth>=40||middle<=first||middle>=last){
                std::cerr.precision(17);std::cerr << "FORWARD_LEAF first=" << first << " last=" << last << " depth=" << depth << " topology=" << label << " selected=";
                for(auto f:selected)std::cerr << f << ",";
                std::cerr << " actual=";for(auto f:actual)std::cerr << f << ",";
                std::cerr << " native=";for(auto f:native)std::cerr << f << ",";
                std::cerr << " sides=";for(auto f:actual)std::cerr << f << ":" << NativeMeshSide(to,mesh,f) << ",";
                std::cerr << "\n";return false;
            }
            // selected is the state at first. A successful left child advances
            // that same state to middle; the right child consumes it directly.
            if(!self(self,first,middle,depth+1))return false;
            return self(self,middle,last,depth+1);
        };
        if(!walk(walk,start,finish,0)){result.value.selected.fronts.clear();return result;}
        ForwardMerge(result.value.selected.fronts,selected);
    }
    result.value.measure.result=Result::Connected;return result;
}

inline UnionMeasurement ReacquireUnion(const PrimitivePose&q,const PrimitivePose&m,
    const MeshContactEpisode&old,const RigidMotionSegment&s,double first,double last,unsigned maximumIntervals=1024){
    return ForwardEpisode(q,m,old,s,first,last,maximumIntervals).value;
}
inline UnionMeasurement ConnectedUnion(const PrimitivePose&q,const PrimitivePose&m,
    const MeshContactEpisode&old,const RigidMotionSegment&s,double first,double last,unsigned maximumIntervals=1024){
    auto result=ForwardEpisode(q,m,old,s,first,last,maximumIntervals).value;
    if(result.measure.result==Result::Connected&&result.selected.fronts.empty())result.measure.result=Result::Separated;
    return result;
}
inline UnionMeasurement TraceEndpoint(const PrimitivePose&q,const PrimitivePose&m,unsigned feature,
    const MeshContactEpisode&old,const RigidMotionSegment&s,double first,double last,unsigned maximumIntervals=1024){
    auto result=ForwardEpisode(q,m,old,s,first,last,maximumIntervals,feature).value;
    if(result.measure.result!=Result::Connected)return result;
    if(!std::binary_search(result.selected.fronts.begin(),result.selected.fronts.end(),feature)){
        result.measure.result=Result::Separated;result.selected.fronts.clear();return result;
    }
    result.selected.fronts=MeshFiniteComponent(At(q,s,last),m,{feature});return result;
}
} // namespace episode_probe
