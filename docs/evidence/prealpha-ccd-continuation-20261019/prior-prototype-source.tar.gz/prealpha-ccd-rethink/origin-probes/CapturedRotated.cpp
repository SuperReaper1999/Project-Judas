#include <iostream>
#include <iomanip>
#define main PreservedSuffixMain
#include "CapturedSuffixProbe.cpp"
#undef main
int main(){
 std::cout<<std::setprecision(17);
 PrimitivePose query,mesh;query.shape=Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(Sheet(),"exact preserved rotated failure");
 mesh.parentOrientation={0.92299658060073853f,0.10284432023763657f,0.20568864047527313f,-0.3085329532623291f};
 RigidMotionSegment segment;segment.inverseMass=5;segment.begin=0;segment.end=0.01666666753590107;
 segment.position={0.16116663813591003f,-0.096129342913627625f,-0.23353393375873566f};segment.orientation={-0.91512805223464966f,-0.075421541929244995f,0.12416847795248032f,0.37607762217521667f};
 segment.linearVelocity={3.1164867877960205f,-3.6316108703613281f,5.2548298835754395f};segment.driftAngularVelocity={-49.291244506835938f,-38.429805755615234f,-6.0474700927734375f};
 const double end=0.0162533884868084;
 auto result=episode_probe::ForwardEpisode(query,mesh,MeshContactEpisode{{46,50,51}},segment,0,end);
 std::cout<<"CAPTURE result="<<int(result.value.measure.result)<<" intervals="<<result.value.measure.intervals<<" certificates="<<result.value.measure.pointCertificates<<" end=";for(auto f:result.value.selected.fronts)std::cout<<f<<',';std::cout<<'\n';
 const double first=0.013626498062426766,last=0.013634434287273841,width=last-first;
 for(double factor:{1.,2.,4.,8.}){
  const double lo=first-width*(factor-1),hi=last+width*(factor-1);
#ifdef NATIVE_TRACE_PROBE
  episode_probe::nativeCertificateTrace=true;
#endif
  const bool certificate=episode_probe::NativeOverlapThroughout(query,mesh,50,segment,lo,hi);
  unsigned misses=0;for(unsigned i=0;i<=256;++i){auto p=episode_probe::At(query,segment,lo+(hi-lo)*double(i)/256);const auto actual=MeshFiniteComponent(p,mesh,{},true);if(!std::binary_search(actual.begin(),actual.end(),50))++misses;}
  std::cout<<"INTERVAL factor="<<factor<<" lo="<<lo<<" hi="<<hi<<" certified="<<certificate<<" actual_sample_misses="<<misses<<'\n';
  if(certificate&&misses)return 2;
 }
 return result.value.measure.result==episode_probe::Result::Uncertain?1:0;
}
