#pragma once
#include "MeshContinuityProbe.h"

namespace episode_probe {
using IV = std::array<Iv,3>;
inline IV Add(const IV&a,const IV&b){return {a[0]+b[0],a[1]+b[1],a[2]+b[2]};}
inline IV Sub(const IV&a,const IV&b){return {a[0]-b[0],a[1]-b[1],a[2]-b[2]};}
inline IV Cross(const IV&a,const IV&b){return {a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]};}
inline Iv Dot(const IV&a,const IV&b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
inline IV Point(V p){return {Iv(p[0]),Iv(p[1]),Iv(p[2])};}
inline IV Times(const contact_geometry::M<Iv>&r,V p){
 IV out{Iv(0),Iv(0),Iv(0)};for(unsigned k=0;k<3;++k)for(unsigned j=0;j<3;++j)out[k]=out[k]+r[j][k]*Iv(p[j]);return out;
}
inline std::optional<IV> Unit(IV v){
 const auto length=contact_geometry::Sqrt(Dot(v,v));if(!(length.lo>1e-10))return std::nullopt;
 for(auto&x:v)x=x/length;return v;
}

// A full binary64 ULP strictly above an outward bound on the exact result's
// magnitude encloses a round-to-nearest operation's absolute rounding error.
// This includes subnormals. Overflow is an uncertified interval, not a result.
inline std::optional<double> NativeDoubleRoundingBound(Iv magnitude){
 static_assert(std::numeric_limits<double>::is_iec559&&
               std::numeric_limits<double>::radix==2&&
               std::numeric_limits<double>::digits==53,
               "native edge certificate requires IEEE binary64");
 if(!(magnitude.hi>=0)||!std::isfinite(magnitude.hi))return std::nullopt;
 const double above=std::nextafter(magnitude.hi,INFINITY);
 const double successor=std::nextafter(above,INFINITY);
 if(!std::isfinite(above)||!std::isfinite(successor))return std::nullopt;
 return (Iv(successor)-Iv(above)).hi;
}

// Absolute error of the original native 3-product, 2-addition double dot.
// Its intervals enclose the original rounded product and partial-sum inputs.
inline std::optional<double> NativeDotRoundingBound(const IV&p,const IV&axis){
 std::array<Iv,3> products;Iv error(0);
 for(unsigned k=0;k<3;++k){
  products[k]=p[k]*axis[k];
  const auto rounding=NativeDoubleRoundingBound(contact_geometry::Abs(p[k])*contact_geometry::Abs(axis[k]));
  if(!rounding)return std::nullopt;error=error+Iv(*rounding);
 }
 const auto firstSum=NativeDoubleRoundingBound(contact_geometry::Abs(products[0])+contact_geometry::Abs(products[1]));
 if(!firstSum)return std::nullopt;
 const Iv partial=products[0]+products[1];
 const auto lastSum=NativeDoubleRoundingBound(contact_geometry::Abs(partial)+contact_geometry::Abs(products[2]));
 if(!lastSum)return std::nullopt;
 error=error+Iv(*firstSum)+Iv(*lastSum);
 if(!std::isfinite(error.hi))return std::nullopt;
 return error.hi;
}

// Native vertices are p_i=fl(c+fl_dot3(R,local_i)). Real linearity cancels
// the shared center AND any identical local-coordinate rotation terms:
//   fl(p_to-p_from) = R*(local_to-local_from)
//       + error_offset_to-error_offset_from
//       + error_add_to-error_add_from + error_sub.
// Every native dot, center addition and final subtraction keeps its own
// full-ULP envelope. The local-coordinate difference is an exact REAL
// interval subtraction; it is never first rounded to one double vector.
inline std::optional<IV> NativeVertexDifference(const contact_geometry::M<Iv>&rotation,
 const std::vector<V>&local,const IV&center,const std::vector<IV>&offsets,
 const std::vector<IV>&points,unsigned to,unsigned from){
 const IV delta=Sub(Point(local[to]),Point(local[from]));IV edge{Iv(0),Iv(0),Iv(0)};
 for(unsigned k=0;k<3;++k){
  for(unsigned j=0;j<3;++j)edge[k]=edge[k]+rotation[j][k]*delta[j];
  const IV row{rotation[0][k],rotation[1][k],rotation[2][k]};
  const auto offsetFrom=NativeDotRoundingBound(row,Point(local[from]));
  const auto offsetTo=NativeDotRoundingBound(row,Point(local[to]));
  const auto addFrom=NativeDoubleRoundingBound(contact_geometry::Abs(center[k])+contact_geometry::Abs(offsets[from][k]));
  const auto addTo=NativeDoubleRoundingBound(contact_geometry::Abs(center[k])+contact_geometry::Abs(offsets[to][k]));
  const auto subtract=NativeDoubleRoundingBound(contact_geometry::Abs(points[to][k])+contact_geometry::Abs(points[from][k]));
  if(!offsetFrom||!offsetTo||!addFrom||!addTo||!subtract)return std::nullopt;
  const Iv error=Iv(*offsetFrom)+Iv(*offsetTo)+Iv(*addFrom)+Iv(*addTo)+Iv(*subtract);
  if(!std::isfinite(error.hi))return std::nullopt;
  edge[k]=edge[k]+Iv(-error.hi,error.hi);
 }
 return edge;
}

// Subtract the SAME exact dot(base,axis) from the original native projection.
// Only the expression of the error helper is factored; its envelope is unchanged.
inline std::optional<Iv> NativeShiftedProjection(const IV&p,const IV&axis,V base){
 const auto error=NativeDotRoundingBound(p,axis);if(!error)return std::nullopt;
 return Dot(Sub(p,Point(base)),axis)+Iv(-*error,*error);
}

// All axes and vertices mirror visitCookedPolyContacts' actual represented
// Poly construction. No inverse-R approximation or fixed contact witness.
// This is sufficient-only overlap certification: uncertainty remains explicit.
inline bool NativeOverlapThroughout(const PrimitivePose&query,const PrimitivePose&mesh,
 unsigned feature,const RigidMotionSegment&segment,double first,double last){
 if(query.shape.type!=ShapeType::Box&&query.shape.type!=ShapeType::ConvexHull)return false;
 try{
  const auto from=segment.EvaluateGeometry(first),to=segment.EvaluateGeometry(last);
  auto parent=rigid_motion_bounds::TryDynamicRotationInterval(segment,first,last);
  if(segment.driftAngularVelocity==glm::vec3(0)&&rigid_motion_bounds::SameQuat(from.orientation,to.orientation)){
   contact_geometry::M<Iv> exact;const auto r=ContactRotation(from.orientation);
   for(unsigned j=0;j<3;++j)for(unsigned k=0;k<3;++k)exact[j][k]=Iv(r[j][k]);parent=exact;
  }
  if(!parent)return false;
  const auto child=ContactRotation(query.childRotation);
  contact_geometry::M<Iv> rotation;
  for(unsigned j=0;j<3;++j)for(unsigned k=0;k<3;++k){rotation[j][k]=Iv(0);for(unsigned l=0;l<3;++l)rotation[j][k]=rotation[j][k]+(*parent)[l][k]*Iv(child[j][l]);}
  IV center=Times(*parent,V(query.parentLocalCenter));const V origin=PrimitiveCenter(mesh);
  for(unsigned k=0;k<3;++k)center[k]=(Iv(double(std::min(from.position[k],to.position[k])),double(std::max(from.position[k],to.position[k])))+center[k])-Iv(origin[k]);
  std::vector<IV> a,b,offsets;std::vector<V> local;std::vector<IV> normals;std::vector<std::array<unsigned,2>> edges;
  if(query.shape.type==ShapeType::Box){
   const V h(query.shape.halfExtents);for(int z:{-1,1})for(int y:{-1,1})for(int x:{-1,1}){
    local.push_back(V(x*h.x,y*h.y,z*h.z));
    offsets.push_back(Times(rotation,local.back()));
    a.push_back(Add(center,offsets.back()));
   }
   static constexpr unsigned faces[6][4]={{0,4,6,2},{1,3,7,5},{0,1,5,4},{2,6,7,3},{0,2,3,1},{4,5,7,6}};
   for(const auto&face:faces){
    const auto first=NativeVertexDifference(rotation,local,center,offsets,a,face[1],face[0]);
    const auto second=NativeVertexDifference(rotation,local,center,offsets,a,face[2],face[0]);
    if(!first||!second)return false;
    auto n=Unit(Cross(*first,*second));if(!n)return false;normals.push_back(*n);
   }
   edges={{{0,1}},{{0,2}},{{0,4}}};
  }else{
   for(V p:query.shape.asset->vertices){
    local.push_back(p);offsets.push_back(Times(rotation,p));a.push_back(Add(center,offsets.back()));
   }
   for(const auto&face:query.shape.asset->polygons)normals.push_back(Times(rotation,face.normal));
   for(auto e:query.shape.asset->satEdges)edges.push_back(query.shape.asset->edges[e]);
   if(edges.empty())edges=query.shape.asset->edges;
  }
  const auto fixed=PrimitiveRotation(mesh);const auto&face=mesh.shape.asset->faces[feature];
  for(auto index:face.vertices)b.push_back(Point(fixed*mesh.shape.asset->vertices[index]));
  // One static native triangle vertex is shared by every support projection.
  // Choosing the nearest one is only a width heuristic, never a contact test.
  const auto middle=At(query,segment,(first+last)*.5);
  const V middleCenter=PrimitiveCenter(middle)-origin;
  V projectionOrigin=fixed*mesh.shape.asset->vertices[face.vertices[0]];
  double nearest=glm::dot(projectionOrigin-middleCenter,projectionOrigin-middleCenter);
  for(auto index:face.vertices){const V candidate=fixed*mesh.shape.asset->vertices[index];
   const double distance=glm::dot(candidate-middleCenter,candidate-middleCenter);
   if(distance<nearest){nearest=distance;projectionOrigin=candidate;}
  }
  normals.push_back(Point(fixed*face.normal));
  const auto overlaps=[&](IV axis){
   const auto length=contact_geometry::Sqrt(Dot(axis,axis));
   if(length.hi<1e-10)return true;
   if(!(length.lo>=1e-10))return false;
   for(auto&x:axis)x=x/length;
   double minA=INFINITY,maxA=-INFINITY,minB=INFINITY,maxB=-INFINITY;
   for(const auto&p:a){const auto value=NativeShiftedProjection(p,axis,projectionOrigin);if(!value)return false;minA=std::min(minA,value->hi);maxA=std::max(maxA,value->lo);}
   for(const auto&p:b){const auto value=NativeShiftedProjection(p,axis,projectionOrigin);if(!value)return false;minB=std::min(minB,value->hi);maxB=std::max(maxB,value->lo);}
   return minA<=maxB&&minB<=maxA;
  };
  for(const auto&normal:normals)if(!overlaps(normal))return false;
  static constexpr std::array<std::array<unsigned,2>,3> triangleEdges={{{{0,1}},{{1,2}},{{0,2}}}};
  for(auto e:edges){
   const auto direction=NativeVertexDifference(rotation,local,center,offsets,a,e[1],e[0]);
   if(!direction)return false;
   for(auto t:triangleEdges)if(!overlaps(Cross(*direction,Sub(b[t[1]],b[t[0]]))))return false;
  }
  return true;
 }catch(const contact_geometry::ArithmeticFailure&){return false;}
}
} // namespace episode_probe
