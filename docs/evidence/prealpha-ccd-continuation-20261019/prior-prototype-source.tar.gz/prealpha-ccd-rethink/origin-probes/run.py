from pathlib import Path
import json,subprocess,shutil,time,sys
R=Path.cwd();D=R/'.cache/prealpha-ccd-rethink/origin-probes';S=R/'.cache/prealpha-ccd-rethink/projection-world/sources';rec=[]
def run(name,args,cwd=R):
 t=time.monotonic()
 with (D/(name+'.log')).open('w') as f:
  try:c=subprocess.run(list(map(str,args)),cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=60).returncode
  except subprocess.TimeoutExpired:c='timeout'
 rec.append({'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'exit':c,'seconds':time.monotonic()-t});(D/'RUNS.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,c,flush=True);return c
base=(S/'NativeSATContinuity.h').read_text();marker='''  normals.push_back(Point(fixed*face.normal));'''
plan=json.loads((R/'.cache/prealpha-ccd-rethink/correlated-cert/RUN_PLAN.json').read_text())['candidate'][1]
for mode in (sys.argv[1:] or ['vertex','center','nearest']):
 P=D/mode;P.mkdir(exist_ok=True)
 for n in ['MeshContinuityProbe.h','MeshUnionContinuity.h','CollisionGeometry.h']:shutil.copyfile(S/n,P/n)
 s=(R/'.cache/prealpha-ccd-rethink/projection-trace/sources/NativeSATContinuity.h').read_text() if mode=='trace' else base
 if mode=='rotation':s=(R/'.cache/prealpha-ccd-rethink/rotation-correlated-edges/candidate/NativeSATContinuity.h').read_text()
 if mode=='center':s=s.replace(marker,'  projectionOrigin=middleCenter;\n'+marker)
 if mode=='nearest':s=s.replace(marker,'  const auto nearestPoint=SegmentGeometry(middleCenter+origin,middleCenter+origin,0,mesh,INFINITY,true,feature);\n  if(nearestPoint.valid)projectionOrigin=nearestPoint.point-origin;\n'+marker)
 (P/'NativeSATContinuity.h').write_text(s)
 if run('compile-'+mode,['c++','-std=c++17','-O3','-DNDEBUG',*(['-DNATIVE_TRACE_PROBE'] if mode=='trace' else []),'-I'+str(P),'-I'+str(R/'.cache/prealpha-ccd-rethink/correlated-cert'),'-I'+str(R/'src'),'-c',D/'CapturedRotated.cpp','-o',P/'probe.o']):continue
 link=plan['argv'][:];link[1]=str(P/'probe.o');link[2]=str(R/'.cache/prealpha-ccd-rethink/projection-world/CollisionGeometry.cpp.o');link[link.index('-o')+1]=str(P/'probe')
 if not run('link-'+mode,link,Path(plan['cwd'])):run('probe-'+mode,[P/'probe'])
