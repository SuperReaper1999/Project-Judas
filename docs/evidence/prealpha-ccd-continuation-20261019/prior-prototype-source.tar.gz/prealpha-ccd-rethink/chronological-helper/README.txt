Prepared independent chronological helper; no builds or tests were run by the preparing agent.

MeshUnionContinuity.h replaces backward TraceEndpoint ancestry with ForwardEpisode.
All wrappers retain the original call signatures. NativeSATContinuity.h is the
already corrected correlated-edge header from forward-prototype/sources.
ReacquisitionControls.cpp is a byte copy of the original eight controls.
CapturedSuffixProbe.cpp is the same five-positive-control captured suffix probe
used for the measured correlated certificate experiment; capture and 1024 budget
are unchanged. The helper retains the original 1024 node and depth-40 bounds.

TRANSITIONS
Static welded topology labels are used only to exclude impossible transfer and
to recognize actual absence of a whole independent mesh component. They never
grant contact. Every positive transfer still uses actual finite shared-edge
components at the queried represented pose.
At each range endpoint native front seeds acquire their actual finite component.
A remaining endpoint component survives only through an owned-at-left member
certified to overlap throughout that range. Otherwise the range is split LEFT
first, with the resulting state passed into the right child. Successful endpoint
states are recorded with time and topology label in ForwardMeasurement.checkpoints.
An actual absence clears that topology component regardless of unrelated contact.

NEGATIVE CERTIFICATE
When a component's owned state is empty, the helper can prove it stays unowned if
all native candidate faces of that topology have native side strictly below
-1e-10 throughout the range. An interval enclosure follows native vertex mean
construction, candidate-bound arithmetic, fixed triangle rotation and side dot
products. Unproved cases return Uncertain under the original bounds.
For boxes, each local vertex has an exact opposite. The same IEEE round-to-nearest
GLM matrix/vector expression maps opposite operands to exact opposite offsets
as real values (signed zeros have real value zero). Thus offset sum is exactly
zero before center additions. The native represented mean differs from the shared
center by the eight vertex-addition errors, eight accumulation errors, and final
division error. Each is bounded with the corrected header's full binary64 ULP
above an outward magnitude bound. The interval retains those errors rather than
substituting a COM-side predicate. Hulls use the direct outward enclosure of their
native transformed vertex accumulation; no symmetry is asserted for hulls.
The model is scoped to dynamic Cayley segments, one-sided static mesh poses, and
boxes/hulls under the existing IEEE round-to-nearest/no-fast-math contract.

RESULT SEMANTICS
ReacquireUnion returns Connected for a successfully evaluated endpoint policy,
including a proved empty ownership set. TraceEndpoint returns Separated when the
queried endpoint face has no owned state; ConnectedUnion likewise returns
Separated for a proved empty endpoint set. Uncertain is never converted into a
positive or negative conclusion. No native solver/geometry behavior was edited.

This is a helper prototype. Topology labels are currently derived per call and
component queries allocate vectors. A world integration should cache immutable
asset topology and derived segment checkpoints rather than copy those costs
blindly. No persistence or world implementation is included here.
