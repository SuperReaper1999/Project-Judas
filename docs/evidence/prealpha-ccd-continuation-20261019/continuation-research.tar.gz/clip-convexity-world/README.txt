ACTUAL NATIVE CLIP CONVEXITY REPRO/REPAIR -- PREPARED, UNEXECUTED

Base minimal-native-growth-world/sources, copied unchanged except one kernel
branch in CollisionGeometry.cpp. Original source and patch preserved separately.
No frozen stage or production file changed.

clipInto classifies d<=eps yet intersects d=0. For endpoints d=.5eps and1.5eps,
classification differs while both are positive. Its true plane0 intersection has
t=-.5 or1.5 and invents a point outside the incident segment. With y endpoints0,1,
that point has y=-.5, so native face-witness depth against front+y can be .5m even
though EVERY source vertex's frontdepth is<=0. Near .999eps/1.001eps the effect is
hundreds of times the source segment length. This disproves an unconditional
queryvertex-frontdepth bound for the exact current kernel.

NativeClipConvexityTests.cpp includes the ACTUAL chosen CollisionGeometry.cpp
through the source include path. It directly invokes that private native clip
kernel, not a copied formula. Compile with original/minimal includes for baseline,
or this sources dir first for candidate; do not ALSO link CollisionGeometry.o.
Its exported geometry methods can use ordinary engine archive dependencies.
This is a kernel-level actual-source repro; no full ComputeContacts mesh fixture
or measured build/test outcome is claimed yet.

Correction bounds t to[0,1] via endpoint returns, preserving exact source endpoints
when the old formula would extrapolate. For every genuine opposite-sign plane
crossing, t is already in[0,1] and the same previous+(current-previous)*t expression
is retained. The existing eps-inclusive vertex classification and inside/outside
policy remain unchanged. Exact t0/t1 expression cases are also retained.
No eps, threshold, margin, native normal guard, SAT, or contact budget is changed.
A simple std::clamp(t) multiply is mathematically equivalent, but endpoint returns
also avoid a new rounded subtraction/addition when selecting a source endpoint.

Before relying on the conditional frontdepth certificate, root must execute the
kernel negative proof baseline/candidate and unchanged native/world regressions.
The finite-face normal, two-sided choice, floating projection guards, complete
swept candidate set and anchored represented motion still need their own bound.
This fix alone is NOT a certificate, growth advancement or performance result.
