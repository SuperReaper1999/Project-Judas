#pragma once
#include "Narrowphase.h"
#include <limits>
#include <memory>

// Shared double-precision geometric evaluator. Distances are nearest-surface
// for points; convex containment is explicit. Meshes have no invented inside.
struct GeometryDistance {
    bool valid=false,contains=false;
    double gap=std::numeric_limits<double>::infinity();
    glm::dvec3 point{0},queryPoint{0},normal{0};
    uint32_t feature=UINT32_MAX;
    bool normalUnique=true;
};
struct CollisionGeometryStats {uint64_t nodes=0,triangles=0,convexTests=0;};
CollisionGeometryStats GetCollisionGeometryStats();
void ResetCollisionGeometryStats();
void CountCollisionQuery(uint64_t nodes,uint64_t triangles);
glm::dmat3 PrimitiveRotation(const PrimitivePose&);
glm::dvec3 PrimitiveCenter(const PrimitivePose&);
GeometryDistance SegmentGeometry(glm::dvec3 a,glm::dvec3 b,double radius,const PrimitivePose& target,double range=std::numeric_limits<double>::infinity(),bool nearestSurface=false,uint32_t feature=UINT32_MAX);
GeometryDistance PointGeometry(glm::dvec3 point,const PrimitivePose& target,double range=std::numeric_limits<double>::infinity());
ContactManifold CookedContacts(const PrimitivePose&,const PrimitivePose&,double margin);
// Exact accepted-contact existence; full manifolds remain authoritative for response.
bool CookedHasContacts(const PrimitivePose&,const PrimitivePose&,double margin);
// Exact deep-contact existence for continuous penetration searches.
bool CookedHasPenetrationBeyond(const PrimitivePose&,const PrimitivePose&,double threshold);
GeometryDistance PolyGeometry(const PrimitivePose& query,const PrimitivePose& target,double range=std::numeric_limits<double>::infinity(),uint32_t feature=UINT32_MAX);
struct MeshContactEpisode;
// Earliest possible overlap of a moving convex polyhedron and a stationary
// triangle union. Each finite patch retains its own SAT bounds; no selected
// local response plane is treated as a plane separating the entire mesh.
// The angular generator's magnitude bounds the anchored rotation rate.
double MeshSeparationAdvance(const PrimitivePose& query,const PrimitivePose& mesh,
                             glm::dvec3 velocity,glm::dvec3 angularGenerator,
                             double rotationRadius,double duration,const std::vector<uint32_t>* excluded=nullptr,const MeshContactEpisode* episode=nullptr);
struct CollisionMassProperties {double volume=0;glm::dvec3 center{0};glm::dmat3 inertia{0};};
CollisionMassProperties ShapeMassProperties(const Shape&);

// Internal physical front-contact episode: stateless queries pass no episode.
struct MeshContactEpisode { std::vector<uint32_t> fronts; };
ContactManifold EpisodeCookedContacts(const PrimitivePose&,const PrimitivePose&,double,const MeshContactEpisode*);
std::vector<uint32_t> MeshContactFeatures(const PrimitivePose&,const PrimitivePose&,const MeshContactEpisode*);
bool MeshEpisodeHasContacts(const PrimitivePose&,const PrimitivePose&,const MeshContactEpisode*,const std::vector<uint32_t>* excluded=nullptr);
bool MeshEpisodeHasPenetrationBeyond(const PrimitivePose&,const PrimitivePose&,double,const MeshContactEpisode*);

struct MeshFeatureBudget { std::vector<std::pair<uint32_t,double>> limits; };
MeshFeatureBudget BuildMeshFeatureBudget(const PrimitivePose&,const PrimitivePose&,double,glm::dvec3,glm::dvec3,double,double,const MeshContactEpisode*);
bool MeshFeatureBudgetExceeded(const PrimitivePose&,const PrimitivePose&,const MeshFeatureBudget&,const MeshContactEpisode*);

// Side-independent finite geometric overlap, for physical episode expiry only.
std::vector<uint32_t> MeshFiniteComponent(const PrimitivePose&,const PrimitivePose&,const std::vector<uint32_t>&,bool allCandidates=false);
bool MeshFiniteHasOverlap(const PrimitivePose&,const PrimitivePose&);

// Immutable topology derived from, and owning, one immutable collision asset.
// Callers may retain this with that asset; no process-global pointer cache exists.
class MeshTopologyPreparation {
public:
    explicit MeshTopologyPreparation(std::shared_ptr<const CollisionAsset>);
    bool Matches(const std::shared_ptr<const CollisionAsset>&) const;
    const std::vector<unsigned>& Labels() const { return labels; }
private:
    std::shared_ptr<const CollisionAsset> owner;
    std::vector<unsigned> labels;
};

// One represented-pose query owns its native polytope and all derived data.
// Component and native-front requests reuse pure predicates; there are no
// borrowed scratch pointers, episode pointers or cross-pose mutable entries.
class MeshFiniteQuery {
public:
    MeshFiniteQuery(const PrimitivePose&,const PrimitivePose&);
    ~MeshFiniteQuery();
    MeshFiniteQuery(MeshFiniteQuery&&) noexcept;
    MeshFiniteQuery& operator=(MeshFiniteQuery&&) noexcept;
    MeshFiniteQuery(const MeshFiniteQuery&)=delete;
    MeshFiniteQuery& operator=(const MeshFiniteQuery&)=delete;
    const std::vector<uint32_t>& FiniteFaces();
    const std::vector<uint32_t>& NativeFrontFeatures();
    // Exact zero-margin legacy selection and accepted-feature queries. The
    // returned features own their storage; no episode pointer is retained.
    bool UsesNativeSelection();
    std::vector<uint32_t> ContactFeatures(const MeshContactEpisode* episode=nullptr);
    std::vector<uint32_t> Component(const std::vector<uint32_t>& seeds);
    double NativeSide(uint32_t feature);
private:
    struct Impl;
    std::unique_ptr<Impl> impl;
};

// One-sided physical history cannot affect front-only finite endpoint truth.
bool MeshEndpointUsesNativeSelection(const PrimitivePose&,const PrimitivePose&);
