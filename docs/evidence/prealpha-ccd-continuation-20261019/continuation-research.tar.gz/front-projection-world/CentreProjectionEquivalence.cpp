// Prepared only. Root owns compilation/execution. This compares exact returned
// interval bits against the unchanged primary RigidMotionBounds implementation.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main
#include "PreparedCentreProjection.h"
#include <cstring>

namespace {
bool SameIv(const std::optional<rigid_motion_bounds::Iv>&a,const std::optional<rigid_motion_bounds::Iv>&b){
    return bool(a)==bool(b)&&(!a||(std::memcmp(&a->lo,&b->lo,sizeof(double))==0&&std::memcmp(&a->hi,&b->hi,sizeof(double))==0));
}
void CompareProjection(const RigidMotionSegment*a,const RigidMotionSegment*b,const RigidBody&fromA,const RigidBody&fromB,
                       double start,double finish,const std::vector<glm::dvec3>&axes){
    const auto prepared=front_projection_preparation::Prepare(a,b,fromA,fromB,start,finish);
    for(const auto&axis:axes){
        const auto reference=rigid_motion_bounds::TryRelativeCentreProjection(a,b,fromA,fromB,start,finish,axis);
        const auto candidate=prepared?prepared->Project(axis):std::nullopt;
        Check(SameIv(reference,candidate),"prepared centre projection matches optional truth and interval endpoint bits");
    }
}
}
int main(){
    std::vector<glm::dvec3> axes{{0,0,0},{1,0,0},{0,1,0},{0,0,1},{-1,2,-3},{-0.,0.,-0.}};
    for(const auto&asset:{Sheet(2,26,true),Sheet(30,30,true)})
        for(const auto&frame:{glm::dmat3(1),ContactRotation(glm::angleAxis(.79f,glm::normalize(glm::vec3(1,2,-3))))})
            for(const auto&face:asset->faces)axes.push_back(frame*face.normal);
    axes.push_back({std::numeric_limits<double>::infinity(),0,0});
    axes.push_back({0,std::numeric_limits<double>::quiet_NaN(),0});
    RigidBody fromA,fromB;fromA.position={.11f,.008f,-.17f};fromB.position={-.2f,-.3f,.4f};
    RigidMotionSegment first,second;first.begin=second.begin=0;first.end=second.end=1./60;
    first.inverseMass=second.inverseMass=1;first.position=fromA.position;second.position=fromB.position;
    first.linearVelocity={-.2403434f,5.0112495f,8.518133f};second.linearVelocity={.2f,-.7f,.3f};
    for(unsigned mode=0;mode<4;++mode)for(const auto&range:{std::pair<double,double>{0,1./60},{.003,.009},{.009,.009}})
        CompareProjection(mode&1?&first:nullptr,mode&2?&second:nullptr,fromA,fromB,range.first,range.second,axes);
    for(float origin:{0.f,1024.f,1000000.f}){
        first.position=fromA.position+glm::vec3(origin,-origin,origin);second.position=fromB.position+glm::vec3(origin,-origin,origin);
        auto a=fromA,b=fromB;a.position=first.position;b.position=second.position;
        CompareProjection(&first,&second,a,b,0,first.end,axes);
    }
    first.position={-0.f,0.f,-0.f};first.linearVelocity={std::numeric_limits<float>::denorm_min(),-0.f,0.f};
    CompareProjection(&first,nullptr,fromA,fromB,0,first.end,axes);
    first.inverseMass=0;CompareProjection(&first,nullptr,fromA,fromB,0,first.end,axes);
    first.prescribed=true;CompareProjection(&first,nullptr,fromA,fromB,0,first.end,axes);
    CompareProjection(&first,nullptr,fromA,fromB,-.1,first.end,axes);
    CompareProjection(&first,nullptr,fromA,fromB,first.end,0,axes);
    CompareProjection(nullptr,nullptr,fromA,fromB,std::numeric_limits<double>::quiet_NaN(),0,axes);
    std::cout<<"CENTRE_PROJECTION_EQUIVALENCE checks="<<checks<<" failures="<<failures<<'\n';
    return failures?1:0;
}
