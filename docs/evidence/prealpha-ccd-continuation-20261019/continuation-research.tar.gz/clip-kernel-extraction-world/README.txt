COHESIVE INTERNAL NATIVE CLIP KERNEL EXTRACTION -- PREPARED, UNEXECUTED

Base: clip-convexity-world/sources (already validated clamp candidate, per root
validation logs). This NEW stage only extracts the actual corrected clipInto
body into ClipPolygon.h, naming it JudasCollisionDetail::ClipPolygonInto.
CollisionGeometry calls that exact inline kernel at both clipping sites.
Its existing eps alias now points to the same header constant1e-10; all other
SAT/normal decisions still see exactly the same value. No interpolation,
classification, floating operation order or branch changed in this extraction.

ClipPolygonTests.cpp includes only the real header. It exercises the same15
existing kernel assertions without including CollisionGeometry.cpp, exporting
geometry symbols, linking duplicate objects or maintaining a second test copy
of the clipping algorithm. It needs GLM include paths and a compiler only; it
can also link with the normal engine test helper. Kernel test input source is
unchanged apart from include/name and aliases. This stage is not yet executed.

Production suggestion (root owns actual integration):
- Install internal src/ClipPolygon.h and mechanical Geometry extraction.
- Add tests/ClipPolygonTests.cpp using the normal engine-test target helper,
  OR a small standalone target including src and the existing GLM dependency.
  Do not expose a new public gameplay/physics API.
- Keep NativeFeatureGrowthTests and unchanged original world/native regressions
  as separate gates: clipping correction and CCD correction are distinct.

Observed ROOT validation (not executed here): prior direct-actual-cpp kernel
baseline15checks/6fail; corrected15checks/0fail, logs under
../clip-convexity-world/validation/{baseline,corrected}.log. Those results belong
to the older include.cpp fixture and do not claim this extraction was compiled.
