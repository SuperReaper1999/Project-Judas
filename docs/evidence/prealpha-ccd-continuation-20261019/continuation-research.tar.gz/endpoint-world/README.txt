Completed endpoint ownership research patch; prepared without build/test execution.

Owned changes:
  sources/PhysicsWorld.cpp
  sources/MeshEndpointPublication.h (new)
  sources/ContactSolver.h and ContactSolver.cpp (authorized narrow callback hook)
  EndpointTranslationControls.cpp (new)

The sources directory was copied from rotation-world. Its WorldInternal.h is a
snapshot and MUST be combined with event_audit's completed lifetime-world header
and mutation changes before building. Required interface:
  Impl::MeshEpisodeRecordValid(a,b,pa,pb,const EpisodeRecord&)
  Impl::SetMeshEpisode(a,b,pa,pb,asset,MeshContactEpisode,time)
  EpisodeRecord lifetime token; live records remain available while staging.
No WorldInternal.h changes were made by this agent.

Order: finish physical drift episode selection at dt; copy selected records into
pending state; observe each actual ContactSolver translation in original order;
run coupling finish; validate live ownership lifetime plus actual final poses;
publish zero-margin finite accepted selections at the completed endpoint.
Settle has no position/orientation writes in the inspected source.

The original SolvePositions(int) signature remains. Its overload carries a
function pointer plus context. Original correction expressions and order remain;
after each actual A += correction*inverseMass or B -= correction*inverseMass,
the callback receives the prior position, preserved orientation and exact float
delta. The observer never writes physical positions or velocities.

Each correction uses a translation-only RigidMotionSegment with normalized
parameter u in [0,1]. Its arithmetic must reproduce both actual endpoint poses
exactly, or it returns Uncertain. The existing finite ReacquireUnion helper
certifies every represented intermediate pose under the unchanged 1024 interval
and depth40 bounds. Empty ownership is carried across later corrections so a
hidden finite exit followed by rear reentry cannot revive it.

Coupling finish is not inferred as continuous motion from endpoints. Transform
API changes must retire the live lifetime. Pending state is discarded when that
lifetime is gone, including reset/filter roundtrips. If a preserved lifetime's
actual pose changes outside the observed correction path, final publication
throws explicit uncertainty. Coordinate shifts inside finish need an explicit
tracked/equivalence interface; they are not silently treated as a translation.

Limits requiring root integration/review:
  * Only drift-owned mesh pairs are staged. Corrections that encounter a wholly
    new mesh pair are not discovered by this helper; native front acquisition
    remains at the next ordinary boundary. The current source does not claim
    general correction-induced collision handling for new pairs.
  * Uncertainty throws after an actual solver translation. Universal Step
    rollback remains required for strong failed-boundary atomicity; this patch
    alone does not provide it.
  * The live drift records are still present while final work runs, by design,
    so mutation APIs can retire their tokens. Only successful final commit
    replaces their selected features. No externally callable final save should
    consume an in-progress Step's transient drift records.
  * Exact float adapter checks can reject unusual represented arithmetic, such
    as quaternion signed-zero normalization. Rejection remains explicit.

EndpointTranslationControls.cpp uses actual ContactSolver rows from authored
box/box geometry, not fabricated impulses or forced expected results. Controls:
  behind-center finite straddling retained through actual downward correction;
  full departure retires drift-owned state;
  correction exits finite footprint then returns from rear with no ownership;
  endpoint-adapter mismatch returns uncertainty.
Compile with -Isources -Isrc using the merged isolated header tree. Recompile
all ContactSolver callers/objects coherently as directed by root; link with the
candidate geometry/world engine archive and normal test dependencies.

Original mesh, entry, geometry, robustness, lifecycle and persistence gates
remain unchanged. No production source or original fixture was edited.
