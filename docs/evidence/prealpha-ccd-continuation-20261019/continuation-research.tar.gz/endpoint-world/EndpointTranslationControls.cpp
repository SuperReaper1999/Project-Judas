#include "MeshEndpointPublication.h"
#include "ContactSolver.h"
#include "CollisionAsset.h"
#include "MeshData.h"
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace {
int checks=0,failures=0;
void Check(bool ok,const char* label){++checks;if(!ok){++failures;std::cerr<<"FAIL "<<label<<'\n';}}
std::shared_ptr<CollisionAsset> Sheet() {
    MeshData source;
    for(glm::vec3 p:{glm::vec3(-.25f,0,-.25f),glm::vec3(0,0,.25f),glm::vec3(.25f,0,-.25f)}) {
        MeshVertex v;v.position=p;source.vertices.push_back(v);
    }
    source.indices={0,1,2};auto asset=std::make_shared<CollisionAsset>();
    CollisionCookSettings settings;std::string error;
    if(!CookCollision(source,settings,*asset,error))throw std::runtime_error(error);return asset;
}
struct Trace {
    PrimitivePose query,mesh;
    MeshContactEpisode selected;
    unsigned corrections=0,uncertain=0;
    static void Observe(void* context,RigidBody& body,const glm::vec3& previous,
                        const glm::quat& orientation,const glm::vec3& delta) {
        auto& self=*static_cast<Trace*>(context);++self.corrections;
        Check(mesh_endpoint_publication::SamePosition(self.query.parentPosition,previous),
              "observer consumes each actual prior correction endpoint");
        Check(mesh_endpoint_publication::SameOrientation(self.query.parentOrientation,orientation),
              "positional solver preserves the actual orientation");
        const auto result=mesh_endpoint_publication::TraceTranslation(self.query,self.mesh,self.selected,
                                                                     delta,body.position,body.orientation);
        if(result.measure.result==episode_probe::Result::Uncertain) {
            ++self.uncertain;throw std::runtime_error("positive correction control became uncertified");
        }
        self.selected=result.selected;
        self.query.parentPosition=body.position;self.query.parentOrientation=body.orientation;
        std::cout<<"ENDPOINT_CORRECTION index="<<self.corrections
                 <<" from="<<previous.x<<','<<previous.y<<','<<previous.z
                 <<" delta="<<delta.x<<','<<delta.y<<','<<delta.z
                 <<" actual="<<body.position.x<<','<<body.position.y<<','<<body.position.z
                 <<" owned="<<self.selected.fronts.size()<<" intervals="<<result.measure.intervals<<'\n';
    }
};
struct Actor {
    Shape shape=Shape::Box({.1f,.1f,.1f});
    RigidBody body;
    Trace trace;
    explicit Actor(const std::shared_ptr<CollisionAsset>& asset) {
        body.position={0,.05f,0};body.inverseMass=1;
        body.inverseInertiaLocal=SolidBoxInverseInertia(1,shape.halfExtents);
        trace.query=PrimitiveAt(shape,body,0);
        trace.mesh.shape=Shape::Cooked(asset,"finite positional translation sheet");
        trace.selected.fronts=MeshContactFeatures(trace.query,trace.mesh,nullptr);
        Check(trace.selected.fronts.size()==1,"ownership starts at actual finite native front contact");
    }
    void Push(glm::vec3 center,glm::vec3 half) {
        const auto pusherShape=Shape::Box(half);RigidBody pusher;pusher.position=center;
        const auto contacts=ComputeContacts(shape,body,pusherShape,pusher,0);
        Check(contacts.count>0,"authored physical pusher supplies actual contact constraints");
        ContactSolver solver;
        for(int i=0;i<contacts.count;++i)solver.AddContact(body,pusher,contacts.points[i],0,0);
        solver.Prepare(0);
        const auto linear=body.linearVelocity,angular=body.angularVelocity;
        solver.SolvePositions(ContactSolver::kPositionIterations,&Trace::Observe,&trace);
        Check(body.linearVelocity==linear&&body.angularVelocity==angular,"positional correction creates no velocity");
        Check(mesh_endpoint_publication::SamePosition(trace.query.parentPosition,body.position),
              "last observed endpoint is actual ContactSolver endpoint");
    }
};
}
int main() {
    try {
        std::cout<<std::setprecision(17);const auto asset=Sheet();
        {
            Actor actor(asset);
            // An actual overlapping block above the body translates its COM
            // behind the one-sided sheet while it remains finitely straddling.
            actor.Push({0,.13f,0},{.5f,.1f,.5f});
            Check(actor.trace.corrections>0,"positive control observes actual correction work");
            Check(actor.body.position.y<0&&actor.body.position.y>-.1f,"positive control ends behind but straddling");
            Check(CookedContacts(actor.trace.query,actor.trace.mesh,0).count==0,
                  "native instantaneous side rule alone cannot represent the completed endpoint");
            Check(!actor.trace.selected.fronts.empty()&&
                  EpisodeCookedContacts(actor.trace.query,actor.trace.mesh,0,&actor.trace.selected).count>0,
                  "certified correction path preserves actual behind-center ownership");
        }
        {
            Actor actor(asset);const auto driftOwned=actor.trace.selected;
            actor.Push({0,.2f,0},{.5f,.5f,.5f});
            Check(actor.body.position.y<-.1f,"negative control actually leaves the entire finite sheet plane");
            Check(actor.trace.selected.fronts.empty(),"completed endpoint retires ownership after full finite departure");
            Check(!driftOwned.fronts.empty(),"old drift-end publication would retain stale selected features");
        }
        {
            Actor actor(asset);
            actor.Push({0,.13f,0},{.5f,.1f,.5f});
            Check(!actor.trace.selected.fronts.empty(),"exit/reentry control starts with certified behind-center ownership");
            const float y=actor.body.position.y;
            actor.Push({.2f,y,0},{.5f,.5f,.5f});
            Check(actor.body.position.x<-.35f,"middle correction really exits the finite footprint");
            Check(actor.trace.selected.fronts.empty(),"finite footprint exit expires ownership before next correction");
            actor.Push({-.6f,y,0},{.5f,.5f,.5f});
            Check(std::abs(actor.body.position.x)<.1f&&actor.body.position.y<0,
                  "later correction returns into finite footprint from the rear");
            Check(!MeshFiniteComponent(actor.trace.query,actor.trace.mesh,{},true).empty(),
                  "rear-return endpoint really overlaps finite authored triangles");
            Check(actor.trace.selected.fronts.empty(),"rear return cannot inherit ownership across the actual finite exit");
        }
        {
            Actor actor(asset);
            const auto uncertain=mesh_endpoint_publication::TraceTranslation(actor.trace.query,actor.trace.mesh,
                actor.trace.selected,{.01f,0,0},actor.body.position,actor.body.orientation);
            Check(uncertain.measure.result==episode_probe::Result::Uncertain,
                  "mismatched observed endpoint fails explicitly instead of proximity acquisition");
        }
        std::cout<<"checks "<<checks<<" failures "<<failures<<'\n';return failures?1:0;
    } catch(const std::exception& error){std::cerr<<"ERROR "<<error.what()<<'\n';return 2;}
}
