CURRENT REACHABLE HISTORY SELECTOR -- PREPARED, NOT EXECUTED

Purpose
The old exact box17/prefix6 writer remains byte-untouched. After strict new-facet
amount, its regenerated native0/history-nonempty precondition is no longer true.
The preserved older physical snapshot can still show meaningful current-reader
history dependence, but does not establish a newly reachable current checkpoint.
This selector searches only unchanged original launch fixtures for that evidence.

Build
Compile OriginalHistorySelector.cpp with the SAME flags/includes/link archive as
final-research-world's original ImpactMeshCostTests executable. Add -I tests so the
source includes the original ImpactMeshCostTests.cpp with its main renamed.
Use candidate PhysicsWorld/CollisionGeometry/ContactSolver consistently. Do not
link a second compiled original ImpactMeshCostTests translation unit.
No additional production code or testing hooks are required.

Run as separate processes (paths are new output files):
  <selector-executable> select <new-directory>/current-original-history.bin
  <selector-executable> restorefile <new-directory>/current-original-history.bin
The defaults are original trough2x26, all24 launches, both ORIGINAL frames,
prefixes2..8 and four suffix steps. Optional:
  <selector-executable> select <new-directory>/all-history.bin 8 all
adds the original flat6x6, flat60x60, trough30x30 and trough60x60 identity cases.
  <selector-executable> select <new-directory>/long-history.bin 86 coarse
extends prefixes to86, retaining the original90-step maximum horizon.

Fixtures are reused through the original test source, unedited: same cook,
geometry, start, dimensions, materials, velocity, frame, gravity, dt and normal
sleep policy; no inert body. Each original source launch runs once to maxPrefix+4.
The default inspects all prefix checkpoints2..8, even when history is mixed with
other actual native contacts. Native0 is preferred, never required to be tested.
All candidate outcomes and source-vs-fresh reference deltas are reported.

Influence oracle
A checkpoint is eligible only when actual canonical PersistMeshContacts captures
nonempty records. The engine omits endpoints fully reconstructible by ordinary
native selection; record presence is stronger than nonempty byte-string length.
The two new worlds begin from identical represented pose/v/w and also restore
identical ordinary sleep, accumulated forces, touches and completed observations.
Only one receives mesh history. Exact initial equality and canonical byte recapture
are checked. Actual native ComputeContacts uses the represented actor/sheet poses.
Four unchanged subsequent steps compare physical position, orientation matrices,
linear/angular velocity and the ORIGINAL inverse-frame finite-sheet depth oracle.

A selectable case requires source and restored branches to retain the original
.05m gate. Omission must cross that same gate OR produce at least .001m position
difference OR .01rad orientation difference within those4steps. These separate
predeclared fallback evidence thresholds do not relax the crossing contract.
Every source/restored/omitted pose and velocity must remain finite. Invalid
nonfinite motion cannot qualify as physical influence. Tiny exact-bit differences
alone cannot qualify. Crossing is strongest, followed
by native0, then exact source suffix. All meaningful cases remain in stdout.
The selected record includes original source reference endpoints and exact bytes.
restorefile requires a distinct process ID and re-cooks/reconstructs new bodies.

Limits
The public completed-observation serializer does NOT serialize solver warm cache.
Thus source-vs-fresh differences are explicitly printed and are not falsely
attributed to history. Restored-vs-omitted remains the isolated history comparison:
both fresh worlds share the same ordinary state/cache construction. Do not claim
bit-exact uninterrupted continuation unless the printed exact_source_suffix is1.
This is a source selector, not an alteration of old acceptance fixtures. No match
is a failing search result; do not substitute tiny numerical drift as evidence.
No build or runtime result is claimed by this preparation.
