// Source selector for ACTUALLY influential ownership after the strict
// new-facet amount correction. The old box17/prefix6 source is untouched.
// Add the repository tests directory to the include path.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main
#include "SaveArchive.h"
#include <array>
#include <fstream>
#include <limits>
#ifdef _WIN32
#include <process.h>
#else
#include <unistd.h>
#endif

namespace {
constexpr float kDt=1.f/60.f;
constexpr unsigned kSuffix=4;
// Evidence thresholds, declared before execution. They do not replace or
// weaken the original .05m crossing gate. Exact-bit-only changes do not qualify.
constexpr double kMeaningfulPosition=.001; // 1mm over four original steps
constexpr double kMeaningfulAngle=.01;     // .01rad actual orientation
constexpr uint64_t kGroundId=100,kActorId=200;
uint64_t Pid(){
#ifdef _WIN32
    return uint64_t(_getpid());
#else
    return uint64_t(getpid());
#endif
}
struct Motion {
    BodyTransform ground,actor;glm::vec3 linear{0},angular{0};
    void Save(SaveArchive& a){a(ground.position,ground.rotation,actor.position,actor.rotation,linear,angular);}
};
double Angle(glm::quat a,glm::quat b){
    const auto aa=ContactRotation(a),bb=ContactRotation(b);
    double trace=0;for(unsigned c=0;c<3;++c)trace+=glm::dot(aa[c],bb[c]);
    return std::acos(std::clamp((trace-1)*.5,-1.,1.));
}
bool Same(const Motion& a,const Motion& b){
    return a.ground.position==b.ground.position&&a.actor.position==b.actor.position&&
           ContactRotation(a.ground.rotation)==ContactRotation(b.ground.rotation)&&
           ContactRotation(a.actor.rotation)==ContactRotation(b.actor.rotation)&&
           a.linear==b.linear&&a.angular==b.angular;
}
bool Finite(const Motion& s){
    const auto v=[](glm::vec3 p){return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z);};
    const auto q=[](glm::quat p){return std::isfinite(p.w)&&std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z);};
    return v(s.ground.position)&&q(s.ground.rotation)&&v(s.actor.position)&&q(s.actor.rotation)&&v(s.linear)&&v(s.angular);
}
struct LaunchWorld {
    PhysicsWorld world;std::shared_ptr<CollisionAsset> asset;BodyHandle ground,actor;glm::quat frame;
    LaunchWorld(std::shared_ptr<CollisionAsset> mesh,unsigned index,glm::quat rotation,
                const Motion* state=nullptr):asset(std::move(mesh)),frame(rotation){
        // Keep the original default sleep policy and exact two-body setup.
        world.Init();BodyTransform gp;gp.rotation=frame;if(state)gp=state->ground;
        ground=world.CreateShape(Shape::Cooked(asset,"impact cost sheet"),gp,false,1,.6f,0);
        const float along=-1.2f+.1f*float(index),grazing=float(index%6)*6.f;
        const glm::vec3 start=frame*glm::vec3(along,1.2f,-1.f);
        actor=world.CreateDynamicBox(state?state->actor.position:start,{.02f,.01f,.03f},.2f,.4f,0);
        if(state)world.ResetBody(actor,state->actor.position,state->actor.rotation);
        else if(frame!=glm::quat(1,0,0,0))world.ResetBody(actor,start,frame);
        world.SetLinearVelocity(actor,state?state->linear:frame*glm::vec3(0,-40.f,grazing));
        if(state)world.SetAngularVelocity(actor,state->angular);
    }
    uint64_t Id(BodyHandle h)const{return h.id==ground.id?kGroundId:h.id==actor.id?kActorId:0;}
    BodyHandle Resolve(uint64_t id)const{return id==kGroundId?ground:id==kActorId?actor:BodyHandle{};}
    Motion State()const{return {world.GetTransform(ground),world.GetTransform(actor),world.GetLinearVelocity(actor),world.GetAngularVelocity(actor)};}
    void Step(){world.ApplyLinearAcceleration(actor,frame*glm::vec3(0,-9.81f,0),kDt);world.Step(kDt);}
    void Ordinary(SaveArchive& a){
        for(auto h:{ground,actor}){world.PersistSleep(a,h);world.PersistBodyForces(a,h);}
        world.PersistTouches(a,[&](BodyHandle h){return Id(h);},[&](uint64_t id){return Resolve(id);});
        world.PersistCompletedContactObservations(a,[&](BodyHandle h){return Id(h);},[&](uint64_t id){return Resolve(id);});
    }
    std::string CaptureOrdinary(){SaveArchive a;Ordinary(a);return a.bytes;}
    void RestoreOrdinary(const std::string& bytes){SaveArchive a(bytes);Ordinary(a);a.Finish();}
    std::string CaptureMesh(){SaveArchive a;world.PersistMeshContacts(a,[&](BodyHandle h){return Id(h);},[&](uint64_t id){return Resolve(id);});return a.bytes;}
    bool RestoreMesh(const std::string& bytes){SaveArchive a(bytes);const auto result=world.PersistMeshContacts(a,{},[&](uint64_t id){return Resolve(id);});a.Finish();return result;}
    int Native()const{
        PrimitivePose query,mesh;query.shape=Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(asset,"stateless endpoint observation");
        const auto p=State();query.parentPosition=p.actor.position;query.parentOrientation=p.actor.rotation;
        mesh.parentPosition=p.ground.position;mesh.parentOrientation=p.ground.rotation;
        return ComputeContacts(query,mesh,0).count;
    }
};
unsigned MeshCount(const std::string& bytes){SaveArchive a(bytes);uint32_t version=0,count=0;a(version,count);a.Require(version==1&&count<=8192,"invalid selector mesh header");return count;}
struct Scenario {const char* name;int cellsX,cellsZ;bool curved;};
const std::array<Scenario,5> kScenarios={{{"trough 2x26 coarse",2,26,true},{"flat sheet 6x6",6,6,false},{"flat sheet 60x60",60,60,false},{"trough 30x30",30,30,true},{"trough 60x60 dense",60,60,true}}};
glm::quat Frame(unsigned rotated){return rotated?glm::angleAxis(.79f,glm::normalize(glm::vec3(1,2,-3))):glm::quat(1,0,0,0);}
struct Endpoint {Motion state;double depth=0;void Save(SaveArchive& a){state.Save(a);a(depth);}};
struct Saved {
    uint64_t pid=0;unsigned scenario=0,rotated=0,index=0,prefix=0;int native=0;
    Motion state;std::string ordinary,mesh;std::vector<Endpoint> reference;
    void Save(SaveArchive& a){
        std::string magic="Judas.OriginalHistorySelector.1";uint32_t suffix=kSuffix;
        a(magic,suffix,pid,scenario,rotated,index,prefix,native);
        a.Require(magic=="Judas.OriginalHistorySelector.1"&&suffix==kSuffix&&pid&&scenario<kScenarios.size()&&rotated<=1&&(!rotated||scenario==0)&&index<24&&prefix>=2&&prefix<=86,"invalid original selector fixture");
        state.Save(a);a(ordinary,mesh,reference);a.Require(reference.size()==kSuffix,"selector requires four unchanged suffix endpoints");
    }
};
struct Effect {
    bool meaningful=false,crossed=false,restoredSafe=true,referenceSafe=true,exactReference=true,finite=true;
    double position=0,angle=0,linear=0,angular=0,referencePosition=0,referenceAngle=0,referenceLinear=0,referenceAngular=0;
    double restoredDepth=-INFINITY,omittedDepth=-INFINITY;
};
Effect Compare(const Saved& saved,const std::shared_ptr<CollisionAsset>& asset,bool details){
    const SheetOracle oracle(*asset);const auto frame=Frame(saved.rotated);
    LaunchWorld restored(asset,saved.index,frame,&saved.state),omitted(asset,saved.index,frame,&saved.state);
    restored.RestoreOrdinary(saved.ordinary);omitted.RestoreOrdinary(saved.ordinary);
    Check(Same(restored.State(),omitted.State()),"fresh branches have exactly the same physical state");
    Check(MeshCount(restored.CaptureMesh())==0&&MeshCount(omitted.CaptureMesh())==0,"both fresh branches initially omit historical ownership");
    Check(restored.Native()==saved.native&&omitted.Native()==saved.native,"actual native contact count survives reconstruction");
    Check(restored.RestoreMesh(saved.mesh),"canonical participant restores nonempty actual ownership");
    Check(Same(restored.State(),omitted.State()),"restoring only history leaves all physical fields equal");
    Check(restored.CaptureMesh()==saved.mesh,"restored history recaptures canonical bytes exactly");
    Effect e;
    for(unsigned i=0;i<kSuffix;++i){
        restored.Step();omitted.Step();const auto r=restored.State(),o=omitted.State();const auto& ref=saved.reference[i];
        e.finite&=Finite(r)&&Finite(o)&&Finite(ref.state);
        Check(e.finite,"source and both fresh suffix branches retain finite pose/velocity");
        const double rd=oracle.Depth(glm::inverse(frame)*r.actor.position),od=oracle.Depth(glm::inverse(frame)*o.actor.position);
        e.position=std::max(e.position,glm::length(glm::dvec3(r.actor.position)-glm::dvec3(o.actor.position)));
        e.angle=std::max(e.angle,Angle(r.actor.rotation,o.actor.rotation));
        e.linear=std::max(e.linear,glm::length(glm::dvec3(r.linear)-glm::dvec3(o.linear)));
        e.angular=std::max(e.angular,glm::length(glm::dvec3(r.angular)-glm::dvec3(o.angular)));
        e.referencePosition=std::max(e.referencePosition,glm::length(glm::dvec3(r.actor.position)-glm::dvec3(ref.state.actor.position)));
        e.referenceAngle=std::max(e.referenceAngle,Angle(r.actor.rotation,ref.state.actor.rotation));
        e.referenceLinear=std::max(e.referenceLinear,glm::length(glm::dvec3(r.linear)-glm::dvec3(ref.state.linear)));
        e.referenceAngular=std::max(e.referenceAngular,glm::length(glm::dvec3(r.angular)-glm::dvec3(ref.state.angular)));
        e.exactReference&=Same(r,ref.state);e.restoredSafe&=std::isfinite(rd)&&rd<=.05;e.referenceSafe&=std::isfinite(ref.depth)&&ref.depth<=.05;
        e.crossed|=!std::isfinite(od)||od>.05;e.restoredDepth=std::max(e.restoredDepth,rd);e.omittedDepth=std::max(e.omittedDepth,od);
        if(details)std::cout<<"SELECTOR_SUFFIX step="<<i+1<<" restored_depth="<<rd<<" omitted_depth="<<od<<" reference_depth="<<ref.depth
            <<" restored_position="<<r.actor.position.x<<','<<r.actor.position.y<<','<<r.actor.position.z
            <<" omitted_position="<<o.actor.position.x<<','<<o.actor.position.y<<','<<o.actor.position.z<<'\n';
    }
    e.meaningful=e.finite&&e.restoredSafe&&e.referenceSafe&&(e.crossed||e.position>=kMeaningfulPosition||e.angle>=kMeaningfulAngle);
    return e;
}
void Report(const Saved& s,const Effect& e,const char* label){
    std::cout<<label<<" scenario=\""<<kScenarios[s.scenario].name<<"\" rotated="<<s.rotated<<" box="<<s.index<<" prefix="<<s.prefix
        <<" native="<<s.native<<" records="<<MeshCount(s.mesh)<<" meaningful="<<e.meaningful<<" omitted_cross="<<e.crossed
        <<" restored_safe="<<e.restoredSafe<<" original_safe="<<e.referenceSafe<<" finite="<<e.finite<<" exact_source_suffix="<<e.exactReference
        <<" position_delta="<<e.position<<" angle_delta="<<e.angle<<" linear_delta="<<e.linear<<" angular_delta="<<e.angular
        <<" restored_max_depth="<<e.restoredDepth<<" omitted_max_depth="<<e.omittedDepth
        <<" source_position_delta="<<e.referencePosition<<" source_angle_delta="<<e.referenceAngle
        <<" source_linear_delta="<<e.referenceLinear<<" source_angular_delta="<<e.referenceAngular<<'\n';
}
std::string ReadFile(const std::string& path){
    std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("cannot open selector fixture");
    const auto n=f.tellg();if(n<0||uint64_t(n)>SaveArchive::Limit)throw std::runtime_error("invalid selector fixture size");
    f.seekg(0);std::string bytes(std::size_t(n),'\0');if(!bytes.empty()&&!f.read(bytes.data(),std::streamsize(bytes.size())))throw std::runtime_error("cannot read selector fixture");return bytes;
}
void WriteFile(const std::string& path,Saved& s){SaveArchive a;s.Save(a);std::ofstream f(path,std::ios::binary|std::ios::trunc);if(!f||!f.write(a.bytes.data(),std::streamsize(a.bytes.size())))throw std::runtime_error("cannot write selector fixture");f.close();if(!f)throw std::runtime_error("cannot complete selector fixture");}
int Select(const std::string& path,unsigned maxPrefix,bool all){
    Check(maxPrefix>=2&&maxPrefix<=86,"prefix search stays within original90-step horizon");if(failures)return 1;
    Saved best;Effect bestEffect;int bestRank=-1;unsigned histories=0,zeroNative=0,meaningful=0,examined=0;
    for(unsigned scenario=0;scenario<(all?kScenarios.size():1);++scenario){
        const auto& spec=kScenarios[scenario];const auto asset=Sheet(spec.cellsX,spec.cellsZ,spec.curved);const SheetOracle oracle(*asset);
        for(unsigned rotated=0;rotated<(scenario==0?2u:1u);++rotated)for(unsigned index=0;index<24;++index){
            LaunchWorld source(asset,index,Frame(rotated));std::vector<Saved> checkpoints(maxPrefix+1);std::vector<Endpoint> endpoints(maxPrefix+kSuffix+1);
            bool crossed=false;
            for(unsigned prefix=1;prefix<=maxPrefix+kSuffix&&!crossed;++prefix){
                source.Step();const auto state=source.State();const double depth=oracle.Depth(glm::inverse(Frame(rotated))*state.actor.position);
                endpoints[prefix]={state,depth};crossed=!std::isfinite(depth)||depth>.05;
                if(prefix>=2&&prefix<=maxPrefix&&!crossed){
                    auto& s=checkpoints[prefix];s.pid=Pid();s.scenario=scenario;s.rotated=rotated;s.index=index;s.prefix=prefix;s.state=state;
                    s.mesh=source.CaptureMesh();s.native=source.Native();
                    if(MeshCount(s.mesh)){s.ordinary=source.CaptureOrdinary();++histories;zeroNative+=s.native==0;}
                }
            }
            Check(!crossed,"unchanged source launch respects original actual-sheet5cm gate in inspected prefix/suffix");
            if(crossed)continue;
            for(unsigned prefix=2;prefix<=maxPrefix;++prefix){
                auto s=checkpoints[prefix];if(s.mesh.empty()||!MeshCount(s.mesh))continue;
                for(unsigned j=1;j<=kSuffix;++j)s.reference.push_back(endpoints[prefix+j]);
                const auto e=Compare(s,asset,false);++examined;meaningful+=e.meaningful;Report(s,e,"SELECTOR_CANDIDATE");
                if(!e.meaningful)continue;
                // Prefer the original crossing gate, then zero native contacts,
                // then exact source suffix. All qualifying cases are logged.
                const int rank=100*int(e.crossed)+10*int(s.native==0)+int(e.exactReference);
                if(rank>bestRank){bestRank=rank;best=s;bestEffect=e;}
            }
            std::cout<<"SELECTOR_LAUNCH_COMPLETE scenario="<<scenario<<" rotated="<<rotated<<" box="<<index<<'\n'<<std::flush;
        }
    }
    std::cout<<"SELECTOR_SUMMARY history_endpoints="<<histories<<" history_native0="<<zeroNative<<" paired_suffixes="<<examined<<" meaningful="<<meaningful<<'\n';
    Check(bestRank>=0,"at least one canonical history has a substantive measured four-step physical effect");
    if(bestRank>=0&&!failures){Report(best,bestEffect,"SELECTOR_SELECTED");WriteFile(path,best);std::cout<<"SELECTOR_WRITE pid="<<best.pid<<" file="<<path<<'\n';}
    return failures?1:0;
}
void Restore(const std::string& path){
    SaveArchive a(ReadFile(path));Saved s;s.Save(a);a.Finish();Check(s.pid!=Pid(),"selected writer and reader are distinct processes");
    const auto& spec=kScenarios[s.scenario];const auto asset=Sheet(spec.cellsX,spec.cellsZ,spec.curved);
    const auto e=Compare(s,asset,true);Report(s,e,"SELECTOR_COLD_RESTORE");
    Check(e.meaningful,"selected influence survives actual fresh-process geometry/world reconstruction");
    Check(e.restoredSafe&&e.referenceSafe,"restored and source suffixes retain unchanged5cm gate");
}
}
int main(int argc,char** argv){
    std::cout<<std::setprecision(17);
    try{
        if(argc<3)throw std::runtime_error("usage: OriginalHistorySelector select <new-file> [max-prefix2..86=8] [coarse|all=coarse] | restorefile <file>");
        const std::string mode=argv[1];if(mode=="select")Select(argv[2],argc>3?unsigned(std::stoul(argv[3])):8,argc>4&&std::string(argv[4])=="all");
        else if(mode=="restorefile")Restore(argv[2]);else throw std::runtime_error("unknown selector mode");
    }catch(const std::exception& e){++failures;std::cerr<<"FAIL selector exception: "<<e.what()<<'\n';}
    std::cout<<"checks "<<checks<<" failures "<<failures<<'\n';return failures?1:0;
}
