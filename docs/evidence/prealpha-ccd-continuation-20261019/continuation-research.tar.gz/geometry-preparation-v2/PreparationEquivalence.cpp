// Prepared only; root owns compilation and execution.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main
#include "MeshUnionContinuity.h"
#include "MeshUnionContinuity.reference.h"
#include <cstring>

namespace {
unsigned equalityChecks=0,equalityFailures=0;
void EqCheck(bool pass,const char*label){++equalityChecks;if(!pass){++equalityFailures;std::cerr<<"PREPARATION_FAIL "<<label<<'\n';}}
bool SameDouble(double a,double b){return std::memcmp(&a,&b,sizeof(a))==0;}
std::vector<uint32_t> ReferenceFronts(const PrimitivePose&q,const PrimitivePose&m){
    auto result=MeshContactFeatures(q,m,nullptr);
    result.erase(std::remove_if(result.begin(),result.end(),[&](auto f){return episode_probe::NativeMeshSide(q,m,f)<0;}),result.end());
    return result;
}
void ComparePose(const PrimitivePose&q,const PrimitivePose&m){
    const auto finite=MeshFiniteComponent(q,m,{},true),front=ReferenceFronts(q,m);
    MeshFiniteQuery prepared(q,m),reverse(q,m);
    const auto unowned=MeshContactFeatures(q,m,nullptr);
    EqCheck(prepared.UsesNativeSelection()==MeshEndpointUsesNativeSelection(q,m),"finite behind native-selection policy matches");
    EqCheck(prepared.ContactFeatures()==unowned,"zero-margin unowned native contact features match");
    auto callerOwned=prepared.ContactFeatures();callerOwned.clear();
    EqCheck(prepared.ContactFeatures()==unowned,"returned feature storage is independent of query cache");
    const MeshContactEpisode empty;
    EqCheck(reverse.ContactFeatures(&empty)==unowned,"empty episode preserves native reversal/epsilon policy");
    EqCheck(prepared.FiniteFaces()==finite,"finite faces match native SAT traversal");
    EqCheck(prepared.NativeFrontFeatures()==front,"native front witnesses and sides match");
    EqCheck(reverse.NativeFrontFeatures()==front&&reverse.FiniteFaces()==finite,"cache population order preserves truth");
    std::vector<std::vector<uint32_t>> seeds{{},finite,front};
    if(!finite.empty()){
        seeds.push_back({finite.front(),finite.front()});
        auto reversed=finite;std::reverse(reversed.begin(),reversed.end());seeds.push_back(reversed);
    }
    for(auto f:finite)seeds.push_back({f});
    for(const auto&s:seeds){
        EqCheck(prepared.Component(s)==MeshFiniteComponent(q,m,s),"directed finite edge components match");
        const MeshContactEpisode episode{s};const auto expected=MeshContactFeatures(q,m,&episode);
        EqCheck(prepared.ContactFeatures(&episode)==expected,"episode accepted witnesses and finite edge ownership match");
        EqCheck(reverse.ContactFeatures(&episode)==expected,"contact cache population order preserves episode truth");
        EqCheck(prepared.ContactFeatures()==unowned,"episode pointers do not contaminate unowned result");
    }
    EqCheck(reverse.UsesNativeSelection()==MeshEndpointUsesNativeSelection(q,m),"native selection remains independent of episode history");
    std::vector<uint32_t> sides=finite;
    if(!m.shape.asset->faces.empty()){sides.push_back(0);sides.push_back(uint32_t(m.shape.asset->faces.size()-1));}
    for(auto f:sides)EqCheck(SameDouble(prepared.NativeSide(f),episode_probe::NativeMeshSide(q,m,f)),"represented vertex mean side is bit identical");
    EqCheck(prepared.FiniteFaces()==finite&&prepared.NativeFrontFeatures()==front,"later component requests preserve cached vectors");
}
template<class A,class B>void CompareValue(const A&a,const B&b){
    EqCheck(a.measure.result==b.measure.result,"helper result unchanged");
    EqCheck(a.measure.intervals==b.measure.intervals,"interval budget visitation unchanged");
    EqCheck(a.measure.pointCertificates==b.measure.pointCertificates&&a.measure.constantCertificates==b.measure.constantCertificates,"certificate decisions and order unchanged");
    EqCheck(SameDouble(a.measure.separationTime,b.measure.separationTime),"finite expiry time unchanged");
    EqCheck(a.selected.fronts==b.selected.fronts,"owned endpoint faces unchanged");
    EqCheck(a.reacquisitionSearches==b.reacquisitionSearches&&a.reacquisitionWitnesses==b.reacquisitionWitnesses,"acquisition work policy unchanged");
}
void CompareForward(const PrimitivePose&q,const PrimitivePose&m,const MeshContactEpisode&old,
                    const RigidMotionSegment&s,double first,double last){
    MeshTopologyPreparation topology(m.shape.asset);
    const auto a=reference_episode_probe::ForwardEpisode(q,m,old,s,first,last);
    const auto b=episode_probe::ForwardEpisode(q,m,old,s,first,last,1024,std::nullopt,&topology);
    CompareValue(a.value,b.value);
    bool checkpoints=a.checkpoints.size()==b.checkpoints.size();
    if(checkpoints)for(std::size_t i=0;i<a.checkpoints.size();++i)checkpoints &=
        SameDouble(a.checkpoints[i].time,b.checkpoints[i].time)&&a.checkpoints[i].topology==b.checkpoints[i].topology&&a.checkpoints[i].selected.fronts==b.checkpoints[i].selected.fronts;
    EqCheck(checkpoints,"all chronological checkpoints unchanged");
    const auto fallback=episode_probe::ForwardEpisode(q,m,old,s,first,last);
    CompareValue(a.value,fallback.value);
    for(auto f:MeshFiniteComponent(episode_probe::At(q,s,last),m,{},true))
        CompareValue(reference_episode_probe::TraceEndpoint(q,m,f,old,s,first,last),episode_probe::TraceEndpoint(q,m,f,old,s,first,last,1024,&topology));
}
std::shared_ptr<CollisionAsset> CookProbe(const std::vector<glm::vec3>&points,const std::vector<uint32_t>&indices,bool convex=false,bool twoSided=false){
    MeshData data;for(auto p:points){MeshVertex v;v.position=p;data.vertices.push_back(v);}data.indices=indices;
    auto asset=std::make_shared<CollisionAsset>();CollisionCookSettings settings;settings.convex=convex;settings.twoSided=twoSided;std::string error;
    if(!CookCollision(data,settings,*asset,error))throw std::runtime_error(error);return asset;
}
}
int main(){
    const auto coarse=Sheet(2,26,true),medium=Sheet(30,30,true),flat=Sheet(6,6,false);
    const auto joined=CookProbe({{-1,0,-1},{0,0,1},{0,0,-1},{1,0,-1}},{0,1,2,2,1,3});
    const auto disconnected=CookProbe({{-.02,0,-.02},{0,0,.02},{.02,0,-.02},{.149,0,-.001},{.15,0,.001},{.151,0,-.001}},{0,1,2,3,4,5});
    const auto hull=CookProbe({{-.02f,-.01f,-.03f},{.02f,-.01f,-.03f},{-.02f,.01f,-.03f},{.02f,.01f,-.03f},{-.02f,-.01f,.03f},{.02f,-.01f,.03f},{-.02f,.01f,.03f},{.02f,.01f,.03f}},
        {0,4,6,0,6,2,1,3,7,1,7,5,0,1,5,0,5,4,2,6,7,2,7,3,0,2,3,0,3,1,4,5,7,4,7,6},true);
    const auto coarseTwoSided=std::make_shared<CollisionAsset>(*coarse),joinedTwoSided=std::make_shared<CollisionAsset>(*joined);
    coarseTwoSided->twoSided=true;joinedTwoSided->twoSided=true;
    for(const auto&asset:{coarse,medium,flat,joined,disconnected,coarseTwoSided,joinedTwoSided}){
        MeshTopologyPreparation topology(asset);
        EqCheck(topology.Labels()==episode_probe::ForwardTopology(*asset),"immutable topology labels match original order");
        EqCheck(topology.Matches(asset),"topology retains exact asset identity");
        EqCheck(!topology.Matches(std::make_shared<CollisionAsset>(*asset)),"equal-content replacement does not alias preparation");
        for(const auto frame:{glm::quat(1,0,0,0),glm::angleAxis(.79f,glm::normalize(glm::vec3(1,2,-3)))})
        for(unsigned kind=0;kind<2;++kind)for(unsigned i=0;i<18;++i){
            PrimitivePose query,mesh;query.shape=kind?Shape::Cooked(hull,"equivalence hull"):Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(asset,"equivalence mesh");
            mesh.parentOrientation=frame;mesh.parentPosition={.25f,-.5f,.75f};
            const float x=i%3==0?1.5f:(i%3==1?0.f:-1.2f),z=-1.f+.12f*float(i);
            query.parentPosition=mesh.parentPosition+frame*glm::vec3(x,(int(i%6)-3)*.007f,z);
            query.parentOrientation=frame*glm::angleAxis(.19f*float(i),glm::normalize(glm::vec3(2,-1,3)));
            if(i%5==0){query.parentLocalCenter={.011f,-.003f,.007f};query.childRotation=glm::angleAxis(.31f,glm::normalize(glm::vec3(-1,3,2)));}
            ComparePose(query,mesh);
        }
    }
    // Explicit front/rear epsilon-band, finite-edge and two-sided controls.
    // A zero mesh placement keeps these tiny represented offsets observable.
    const auto bandOne=CookProbe({{-1,0,-1},{0,0,1},{1,0,-1}},{0,1,2});
    const auto bandTwo=CookProbe({{-1,0,-1},{0,0,1},{1,0,-1}},{0,1,2},false,true);
    for(const auto&asset:{bandOne,bandTwo})for(unsigned kind=0;kind<2;++kind)
    for(const float height:{0.f,-5e-11f,-2e-10f,5e-11f,2e-10f,-.02f,.05f})
    for(const float x:{0.f,.995f,1.1f}){
        PrimitivePose q,m;q.shape=kind?Shape::Cooked(hull,"band hull"):Shape::Box({.02f,.01f,.03f});
        m.shape=Shape::Cooked(asset,"epsilon band");q.parentPosition={x,height,0};ComparePose(q,m);
    }
    PrimitivePose query,mesh;query.shape=Shape::Box({.05,.1,.05});mesh.shape=Shape::Cooked(joined,"welded");
    RigidMotionSegment segment;segment.inverseMass=1;segment.end=1./60;segment.position={-.3,-.02,0};segment.linearVelocity={36,0,0};
    CompareForward(query,mesh,MeshContactEpisode{{0}},segment,0,segment.end);
    query.shape=Shape::Box({.3,.005,.05});mesh.shape=Shape::Cooked(disconnected,"finite exit");segment.position={.15,-.002,0};segment.linearVelocity={};segment.driftAngularVelocity={0,0,24000};
    CompareForward(query,mesh,MeshContactEpisode{{0,1}},segment,0,segment.end);
    query.shape=Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(coarse,"captured suffix");
    segment.begin=0.010362875706079655;segment.end=0.01666666753590107;
    segment.position={-0.72217696905136108,0.22075329720973969,0.80937790870666504};segment.orientation={0.77646172046661377,-0.1877262145280838,0.5829806923866272,-0.14832216501235962};
    segment.linearVelocity={-0.24034340679645538,5.0112495422363281,8.5181331634521484};segment.driftAngularVelocity={-20.477052688598633,6.0451889038085938,-9.4317626953125};
    CompareForward(query,mesh,MeshContactEpisode{{76,81}},segment,0.012135176570080453,0.013023191524169427);
    auto owned=std::make_shared<CollisionAsset>(*joined);std::weak_ptr<const CollisionAsset> weak=owned;
    auto topology=std::make_unique<MeshTopologyPreparation>(owned);owned.reset();EqCheck(!weak.expired(),"immutable topology owns its asset");topology.reset();EqCheck(weak.expired(),"topology lifetime releases its asset");
    std::cout<<"PREPARATION_EQUIVALENCE checks="<<equalityChecks<<" failures="<<equalityFailures<<" original_fixture_failures="<<failures<<'\n';
    return equalityFailures||failures?1:0;
}
