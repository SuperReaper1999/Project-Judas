#include "WorldInternal.h"
#include "FingerprintDigest.h"

using namespace JudasPhysicsDetail;

namespace {

// Asset names and optional importer fingerprints do not identify programmatic
// cooks. Triangle ownership requires the ordered represented geometry, including
// finite adjacency, sidedness, candidate order and the native convex SAT data.
std::string MeshGeometryIdentity(const std::shared_ptr<const CollisionAsset> &asset) {
    if (!asset)
        return {};
    SaveArchive archive;
    auto field = [&](auto value) { archive(value); };
    field(asset->convex);
    field(asset->twoSided);
    field(asset->vertices);
    field(asset->minimum);
    field(asset->maximum);
    auto count = [&](std::size_t size, unsigned limit) {
        archive.Require(size <= limit, "mesh continuation geometry limit");
        uint32_t n = uint32_t(size);
        archive(n);
    };
    count(asset->faces.size(), 65536);
    for (const auto &face : asset->faces) {
        for (auto v : face.vertices)
            field(v);
        for (auto v : face.adjacent)
            field(v);
        for (auto v : face.active)
            field(v);
        field(face.normal);
    }
    count(asset->polygons.size(), 65536);
    for (const auto &polygon : asset->polygons) {
        field(polygon.vertices);
        field(polygon.normal);
    }
    count(asset->edges.size(), 196608);
    for (const auto &edge : asset->edges) {
        field(edge[0]);
        field(edge[1]);
    }
    field(asset->satEdges);
    field(asset->order);
    count(asset->nodes.size(), 131072);
    for (const auto &node : asset->nodes) {
        field(node.minimum);
        field(node.maximum);
        field(node.first);
        field(node.count);
        field(node.left);
        field(node.right);
    }
    JudasFingerprintDetail::FingerprintDigest digest;
    digest.Append(archive.bytes.data(), archive.bytes.size());
    return digest.Finish();
}

} // namespace

std::vector<std::pair<BodyHandle, BodyHandle>> PhysicsWorld::MeshContactOwners() const {
    std::vector<std::pair<BodyHandle, BodyHandle>> result;
    for (const auto &[key, record] : m_impl->meshEpisodes)
        if (!record.episode.fronts.empty() &&
            m_impl->Episode(key[0], key[1], key[2], key[3])) {
            const auto pair = std::make_pair(m_impl->MakeHandle(key[0]),
                                             m_impl->MakeHandle(key[1]));
            if (result.empty() || result.back().first.id != pair.first.id ||
                result.back().second.id != pair.second.id)
                result.push_back(pair);
        }
    return result;
}

bool PhysicsWorld::PersistMeshContacts(
    SaveArchive &archive, const std::function<uint64_t(BodyHandle)> &identity,
    const std::function<BodyHandle(uint64_t)> &resolve,
    const std::function<bool(BodyHandle)> &include, bool merge,
    glm::dvec3 capturedOriginDelta) {
    RequireValidContinuation("finite-mesh continuation persistence");
    auto &world = *m_impl;
    archive.Require(!world.stepping && !world.coupledStep,
                    "finite-mesh continuation requires an outer fixed boundary");
    archive.Require(!archive.reading || archive.bytes.size()<=8*1024*1024,
                    "saved finite-mesh continuation byte limit");
    uint32_t version = 1;
    archive(version);
    archive.Require(version == 1, "newer finite-mesh continuation format");

    struct Capture {
        std::array<unsigned,4> key;
        uint64_t first, second;
    };
    std::vector<Capture> live;
    if (!archive.reading) {
        // Stable iteration even if a caller violates the nonmutating resolver
        // contract; a stale record is diagnosed before it can be serialized.
        const auto records=world.meshEpisodes;
        for (const auto &[key, record] : records) {
            if (record.episode.fronts.empty() ||
                !world.Episode(key[0], key[1], key[2], key[3]))
                continue;
            const auto first = PrimitiveAt(world.bodies[key[0]].shape,
                                            world.bodies[key[0]].rigidBody, key[2]);
            const auto second = PrimitiveAt(world.bodies[key[1]].shape,
                                             world.bodies[key[1]].rigidBody, key[3]);
            const bool firstMesh = first.shape.type == ShapeType::TriangleMesh;
            // Ordinary front ownership is reproducible from this actual pose.
            // Only genuinely history-sensitive state needs a durable record.
            if (MeshEndpointUsesNativeSelection(firstMesh ? second : first,
                                                firstMesh ? first : second))
                continue;
            const auto a = world.MakeHandle(key[0]), b = world.MakeHandle(key[1]);
            const bool captureA = !include || include(a), captureB = !include || include(b);
            if (!captureA && !captureB)
                continue;
            archive.Require(captureA && captureB,
                            "finite-mesh continuation crosses excluded physical ownership");
            auto ordered=key;
            uint64_t firstId=identity(a), secondId=identity(b);
            archive.Require(firstId && secondId && firstId!=secondId,
                            "finite-mesh continuation has unowned required body");
            archive.Require(world.MeshEpisodeRecordValid(key[0],key[1],int(key[2]),int(key[3]),record),
                            "finite-mesh ownership changed during capture resolution");
            if(firstId>secondId){std::swap(firstId,secondId);std::swap(ordered[0],ordered[1]);std::swap(ordered[2],ordered[3]);}
            live.push_back({ordered,firstId,secondId});
        }
    }

    std::sort(live.begin(),live.end(),[](const auto& a,const auto& b){
        return std::tie(a.first,a.second,a.key[2],a.key[3])<
               std::tie(b.first,b.second,b.key[2],b.key[3]);
    });
    std::size_t capturedFeatures=0;
    for(const auto& record:live){
        const auto& key=record.key;
        const auto* selected=world.Episode(key[0],key[1],int(key[2]),int(key[3]));
        archive.Require(selected!=nullptr,"finite-mesh ownership changed during capture");
        capturedFeatures+=selected->fronts.size();
    }
    archive.Require(capturedFeatures<=65536,"saved finite-mesh feature-state limit");
    uint32_t count = uint32_t(live.size());
    archive(count);
    archive.Require(count <= 8192, "saved finite-mesh contact-pair limit");

    struct Pending {
        std::array<unsigned, 4> key;
        const CollisionAsset *asset;
        MeshContactEpisode selected;
    };
    std::vector<Pending> pending;
    pending.reserve(count);
    std::set<std::array<unsigned, 4>> seen;
    std::map<const CollisionAsset *, std::string> geometry;
    auto bodyContext = [&](const auto &body) {
        auto normalized = body;
        // Position is archived separately so regional origin translations can
        // be validated using exactly the represented restoration operation.
        normalized.rigidBody.position = glm::vec3(0);
        auto context = world.ContinuationBodyContext(normalized);
        auto assetContext = [&](const auto &asset) {
            auto [it, inserted] = geometry.try_emplace(asset.get());
            if (inserted)
                it->second = MeshGeometryIdentity(asset);
            context += it->second;
        };
        assetContext(body.shape.asset);
        for (const auto &child : body.shape.boxes)
            assetContext(child.asset);
        return context;
    };
    for (uint32_t i = 0; i < count; ++i) {
        uint64_t firstId = 0, secondId = 0;
        int partA = 0, partB = 0;
        glm::vec3 positionA{0}, positionB{0};
        std::string contextA, contextB;
        MeshContactEpisode selected;
        if (!archive.reading) {
            const auto &key = live[i].key;
            firstId = live[i].first;
            secondId = live[i].second;
            partA = int(key[2]);
            partB = int(key[3]);
            positionA = world.bodies[key[0]].rigidBody.position;
            positionB = world.bodies[key[1]].rigidBody.position;
            contextA = bodyContext(world.bodies[key[0]]);
            contextB = bodyContext(world.bodies[key[1]]);
            const auto* record=world.Episode(key[0],key[1],int(key[2]),int(key[3]));
            archive.Require(record!=nullptr,"finite-mesh continuation changed during capture");
            selected=*record;
        }
        archive(firstId, secondId, partA, partB, positionA, positionB, contextA, contextB,
                selected.fronts);
        archive.Require(firstId && secondId && firstId != secondId &&
                            !selected.fronts.empty() &&
                            std::is_sorted(selected.fronts.begin(), selected.fronts.end()) &&
                            std::adjacent_find(selected.fronts.begin(), selected.fronts.end()) ==
                                selected.fronts.end(),
                        "invalid finite-mesh continuation record");
        if (!archive.reading)
            continue;
        const auto ha = resolve(firstId), hb = resolve(secondId);
        const auto *bodyA = world.Get(ha), *bodyB = world.Get(hb);
        archive.Require(bodyA && bodyB, "finite-mesh continuation body unavailable");
        archive.Require(!include || (include(ha) && include(hb)),
                        "finite-mesh continuation restores excluded physical ownership");
        unsigned a = ha.id & Impl::kSlotMask, b = hb.id & Impl::kSlotMask;
        archive.Require(partA >= 0 && partA < PrimitiveCount(bodyA->shape) && partB >= 0 &&
                            partB < PrimitiveCount(bodyB->shape),
                        "finite-mesh continuation primitive unavailable");
        archive.Require(contextA == bodyContext(*bodyA) && contextB == bodyContext(*bodyB) &&
                            glm::vec3(glm::dvec3(positionA) - capturedOriginDelta) ==
                                bodyA->rigidBody.position &&
                            glm::vec3(glm::dvec3(positionB) - capturedOriginDelta) ==
                                bodyB->rigidBody.position,
                        "finite-mesh continuation physical context differs");
        if (a > b) {
            std::swap(a, b);
            std::swap(partA, partB);
        }
        archive.Require(world.MeshEpisodePermitted(a, b, partA, partB),
                        "finite-mesh continuation collision ownership differs");
        const std::array<unsigned, 4> key{a, b, unsigned(partA), unsigned(partB)};
        archive.Require(seen.insert(key).second && (!merge || !world.meshEpisodes.count(key)),
                        "duplicate finite-mesh continuation pair");
        const auto first = PrimitiveAt(world.bodies[a].shape, world.bodies[a].rigidBody, partA);
        const auto second = PrimitiveAt(world.bodies[b].shape, world.bodies[b].rigidBody, partB);
        const bool firstMesh = first.shape.type == ShapeType::TriangleMesh;
        const auto &query = firstMesh ? second : first, &mesh = firstMesh ? first : second;
        archive.Require(selected.fronts.back() < mesh.shape.asset->faces.size(),
                        "finite-mesh continuation feature unavailable");
        archive.Require(MeshFiniteComponent(query, mesh, selected.fronts) == selected.fronts,
                        "finite-mesh continuation no longer has its finite geometry");
        pending.push_back({key, mesh.shape.asset.get(), std::move(selected)});
    }
    archive.Require(archive.bytes.size()<=8*1024*1024,
                    "saved finite-mesh continuation byte limit");
    if (archive.reading) {
        // Validate the complete participant before publishing any physical state.
        // A standalone participant is required; callers cannot hide trailing data.
        archive.Finish();
        using Records=decltype(world.meshEpisodes);
        Records prepared=merge?world.meshEpisodes:Records{};
        uint64_t lifetime=world.nextMeshEpisodeLifetime;
        archive.Require(prepared.size()+pending.size()<=8192,
                        "restored finite-mesh contact-pair limit");
        std::size_t features=0;
        for(const auto& entry:prepared)features+=entry.second.episode.fronts.size();
        archive.Require(features<=65536,"restored finite-mesh feature-state limit");
        for(auto& value:pending){
            features+=value.selected.fronts.size();
            archive.Require(features<=65536,"restored finite-mesh feature-state limit");
            archive.Require(lifetime!=std::numeric_limits<uint64_t>::max(),
                            "finite-mesh lifetime identity exhausted");
            const auto& key=value.key;
            prepared.emplace(key,Impl::EpisodeRecord{
                ContactKey{key[0],key[1],world.bodies[key[0]].generation,
                           world.bodies[key[1]].generation,int(key[2]),int(key[3])},
                world.bodies[key[0]].meshOwnershipRevision,
                world.bodies[key[1]].meshOwnershipRevision,value.asset,
                std::move(value.selected),0,++lifetime});
        }
        // Both maps/counters are fully prepared. Allocation or validation above
        // cannot clear or partially replace the live physical ownership.
        world.meshEpisodes.swap(prepared);
        world.nextMeshEpisodeLifetime=lifetime;
        world.episodeDerived.clear();
        world.meshFrontCertificates.clear();
    }
    return count != 0;
}
