#pragma once
// Exact source excerpts; no test main is included or macro-renamed.
#include "CollisionAsset.h"
#include "CollisionGeometry.h"
#include "MeshData.h"
#include "PhysicsWorld.h"
#include "SaveArchive.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <tuple>
#include <vector>

namespace {
int checks=0,failures=0;
void Check(bool ok,const std::string& label){++checks;if(!ok){++failures;std::cerr<<"FAIL "<<label<<'\n';}}

// Open sheet over x,z in [-1.5,1.5] with cellsX by cellsZ quads. curved: circular trough
// across z (radius 1.6 m, bottom at y=0), like a skate half-pipe; otherwise flat at y=0.
std::shared_ptr<CollisionAsset> Sheet(int cellsX,int cellsZ,bool curved){
    MeshData m;const float half=1.5f,radius=1.6f;
    for(int j=0;j<=cellsZ;++j)for(int i=0;i<=cellsX;++i){
        MeshVertex v;const float x=-half+2*half*float(i)/float(cellsX),z=-half+2*half*float(j)/float(cellsZ);
        v.position={x,curved?radius-std::sqrt(radius*radius-z*z):0.f,z};m.vertices.push_back(v);
    }
    const auto at=[&](int i,int j){return std::uint32_t(j*(cellsX+1)+i);};
    for(int j=0;j<cellsZ;++j)for(int i=0;i<cellsX;++i){
        // Upward winding (+y normal on the flat sheet).
        m.indices.insert(m.indices.end(),{at(i,j),at(i,j+1),at(i+1,j+1),at(i,j),at(i+1,j+1),at(i+1,j)});
    }
    CollisionCookSettings settings;auto asset=std::make_shared<CollisionAsset>();std::string error;
    Check(CookCollision(m,settings,*asset,error),"sheet cooks: "+error);
    return asset;
}

struct SheetOracle {
    std::vector<std::pair<double,double>> rows;
    explicit SheetOracle(const CollisionAsset& ground){
        for(auto p:ground.vertices)rows.emplace_back(p.z,p.y);
        std::sort(rows.begin(),rows.end());
        rows.erase(std::unique(rows.begin(),rows.end()),rows.end());
    }
    double Depth(glm::vec3 p)const{
        if(std::abs(p.x)>1.5f||p.z<rows.front().first||p.z>rows.back().first)return 0;
        auto hi=std::lower_bound(rows.begin(),rows.end(),double(p.z),[](const auto& row,double z){return row.first<z;});
        if(hi==rows.begin())++hi;
        if(hi==rows.end())--hi;
        const auto lo=hi-1;
        const double height=lo->second+(hi->second-lo->second)*(double(p.z)-lo->first)/(hi->first-lo->first);
        const double slope=(hi->second-lo->second)/(hi->first-lo->first);
        return (height-p.y)/std::sqrt(1+slope*slope);
    }
};

constexpr float kColdDt=1.f/60.f;
constexpr uint64_t kGround=100,kActor=200,kInert=300;
struct ColdState { BodyTransform ground,actor;glm::vec3 linear{0},angular{0}; };
struct ColdWorld {
    PhysicsWorld world;
    std::shared_ptr<CollisionAsset> asset;
    BodyHandle ground,actor,inert;
    ColdWorld(std::shared_ptr<CollisionAsset> mesh,const ColdState* state=nullptr,
              bool reversed=false,glm::dvec3 delta={0,0,0}):asset(std::move(mesh)) {
        world.Init();world.SetSleepingEnabled(false);
        const auto shifted=[&](BodyTransform p){p.position=glm::vec3(glm::dvec3(p.position)-delta);return p;};
        const BodyTransform gp=state?shifted(state->ground):BodyTransform{};
        BodyTransform ap;ap.position={.5f,1.2f,-1.f};if(state)ap=shifted(state->actor);
        auto makeGround=[&]{ground=world.CreateShape(Shape::Cooked(asset,"impact cost sheet"),gp,false,1,.6f,0);};
        auto makeActor=[&]{actor=world.CreateDynamicBox(ap.position,{.02f,.01f,.03f},.2f,.4f,0);
            if(state)world.ResetBody(actor,ap.position,ap.rotation);};
        if(reversed){makeActor();makeGround();}else{makeGround();makeActor();}
        inert=world.CreateStaticBox(glm::vec3(glm::dvec3(1000)-delta),{1,1,1},0,0);
        world.SetLinearVelocity(actor,state?state->linear:glm::vec3(0,-40.f,30.f));
        if(state)world.SetAngularVelocity(actor,state->angular);
    }
    uint64_t Identity(BodyHandle h)const {
        if(h.id==ground.id)return kGround;if(h.id==actor.id)return kActor;if(h.id==inert.id)return kInert;return 0;
    }
    BodyHandle Resolve(uint64_t id)const {
        return id==kGround?ground:id==kActor?actor:id==kInert?inert:BodyHandle{};
    }
    ColdState State()const{return {world.GetTransform(ground),world.GetTransform(actor),world.GetLinearVelocity(actor),world.GetAngularVelocity(actor)};}
    void Step(){world.ApplyLinearAcceleration(actor,{0,-9.81f,0},kColdDt);world.Step(kColdDt);}
    std::string Capture(const std::function<bool(BodyHandle)>& include={}) {
        SaveArchive archive;world.PersistMeshContacts(archive,[&](BodyHandle h){return Identity(h);},
            [&](uint64_t id){return Resolve(id);},include);return archive.bytes;
    }
    bool Restore(const std::string& bytes,bool merge=false,glm::dvec3 delta={0,0,0},
                 const std::function<bool(BodyHandle)>& include={},
                 const std::function<BodyHandle(uint64_t)>& resolver={}) {
        SaveArchive archive(bytes);const bool any=world.PersistMeshContacts(archive,{},
            resolver?resolver:std::function<BodyHandle(uint64_t)>([&](uint64_t id){return Resolve(id);}),
            include,merge,delta);archive.Finish();return any;
    }
    std::vector<std::pair<uint64_t,uint64_t>> Owners()const {
        std::vector<std::pair<uint64_t,uint64_t>> result;
        for(const auto& p:world.MeshContactOwners()){auto a=Identity(p.first),b=Identity(p.second);if(a>b)std::swap(a,b);result.push_back({a,b});}
        std::sort(result.begin(),result.end());return result;
    }
    int ActualNativeContacts()const {
        PrimitivePose query,mesh;query.shape=Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(asset,"stateless endpoint observation");
        const auto qp=world.GetTransform(actor),mp=world.GetTransform(ground);
        query.parentPosition=qp.position;query.parentOrientation=qp.rotation;
        mesh.parentPosition=mp.position;mesh.parentOrientation=mp.rotation;
        return ComputeContacts(query,mesh,0).count;
    }
};
struct MeshRecord {
    uint64_t first=0,second=0;int partA=0,partB=0;
    glm::vec3 positionA{0},positionB{0};std::string contextA,contextB;
    std::vector<uint32_t> features;
    void Save(SaveArchive& a){a(first,second,partA,partB,positionA,positionB,contextA,contextB,features);}
};
struct MeshBlob {uint32_t version=1;std::vector<MeshRecord> records;};
MeshBlob Decode(const std::string& bytes) {
    SaveArchive archive(bytes);MeshBlob out;uint32_t count=0;archive(out.version,count);
    archive.Require(count<=8192,"test record count limit");out.records.resize(count);
    for(auto& record:out.records)record.Save(archive);archive.Finish();return out;
}
std::string Encode(MeshBlob value) {
    SaveArchive archive;uint32_t count=uint32_t(value.records.size());archive(value.version,count);
    for(auto& record:value.records)record.Save(archive);return archive.bytes;
}
auto Selected(const MeshBlob& value) {
    std::map<std::tuple<uint64_t,uint64_t,int,int>,std::vector<uint32_t>> result;
    for(auto record:value.records){if(record.first>record.second){std::swap(record.first,record.second);std::swap(record.partA,record.partB);}
        result.emplace(std::make_tuple(record.first,record.second,record.partA,record.partB),record.features);}
    return result;
}
bool SameMotion(const ColdState& a,const ColdState& b) {
    return a.ground.position==b.ground.position&&a.ground.rotation==b.ground.rotation&&
           a.actor.position==b.actor.position&&a.actor.rotation==b.actor.rotation&&a.linear==b.linear&&a.angular==b.angular;
}

std::shared_ptr<CollisionAsset> ChangedGeometry(const CollisionAsset& base) {
    MeshData data;for(auto p:base.vertices){MeshVertex vertex;vertex.position=glm::vec3(p);data.vertices.push_back(vertex);}
    for(const auto& face:base.faces)data.indices.insert(data.indices.end(),face.vertices.begin(),face.vertices.end());
    data.vertices[0].position.y+=.0001f;
    auto changed=std::make_shared<CollisionAsset>();CollisionCookSettings settings;std::string error;
    Check(CookCollision(data,settings,*changed,error),"changed finite mesh cooks: "+error);
    // Both programmatic cooks deliberately lack importer fingerprints. The
    // actual geometry digest, not a changed label, must reject this restore.
    Check(changed->sourceFingerprint==base.sourceFingerprint&&changed->settingsFingerprint==base.settingsFingerprint,
          "changed-geometry control shares optional importer metadata");return changed;
}

} // namespace
