#pragma once
#include "ColdMeshFixture.h"
#include "Project.h"
#include "AssetDatabase.h"
#include "SceneSerialization.h"
#include "RuntimeWorld.h"
#include "ResourceManager.h"
#include "WorldPersistence.h"
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <thread>
#include <unistd.h>
namespace {
void Need(bool value,const std::string& message){Check(value,message);if(!value)throw std::runtime_error(message);}
Scene PublicScene(const std::string& collision,bool actor=true,bool ground=true){
    Scene scene;
    if(ground){SceneObject object;object.id=kGround;object.name="curved finite sheet";object.body=SceneBodyComponent{};
        object.body->shape=SceneShape::TriangleMesh;object.body->collisionAsset=collision;
        object.body->friction=.6f;object.body->restitution=0;scene.Objects().push_back(object);}
    if(actor){SceneObject object;object.id=kActor;object.name="original box17";object.transform.position={.5f,1.2f,-1.f};
        object.body=SceneBodyComponent{};object.body->motion=SceneBodyMotion::Dynamic;
        object.body->halfExtents={.02f,.01f,.03f};object.body->mass=.2f;object.body->friction=.4f;
        object.body->restitution=0;object.body->initialLinearVelocity={0,-40,30};scene.Objects().push_back(object);}
    SceneObject inert;inert.id=kInert;inert.name="unrelated far box";inert.transform.position=glm::vec3(1000);
    inert.body=SceneBodyComponent{};inert.body->halfExtents=glm::vec3(1);inert.body->friction=0;inert.body->restitution=0;
    scene.Objects().push_back(inert);scene.SetNextId(400);return scene;
}
std::string CreatePublicProject(const std::filesystem::path& root){
    Project project;std::string error;Need(Project::CreateNew(root.string(),"cold-mesh-public",project,error),"create disposable public project: "+error);
    project.Settings().legacyGameplay=false;project.Settings().startupScene="Scenes/main.judas";
    // This fixed value is local to the per-run XDG data sandbox chosen by main.
    project.Settings().saveIdentity=std::string(64,'c');
    Need(project.Save(error),"save modern project settings: "+error);
    auto asset=Sheet(2,26,true);const auto path=(root/"Assets/curve.judascollision").string();
    Need(SaveCollisionAsset(path,*asset,error),"write actual freshly cooked curved collision: "+error);
    AssetDatabase assets;assets.Scan(project.RootDir(),project.AssetsDir());AssetRecord record;
    Need(assets.Track(path,record,error),"register immutable collision identity: "+error);
    Need(SaveSceneToFile(PublicScene(record.id),(root/"Scenes/main.judas").string(),error),"write original mapped entity fixture: "+error);
    Need(SaveSceneToFile(PublicScene(record.id,true,false),(root/"Scenes/actor.judas").string(),error),"write regional actor source: "+error);
    Need(SaveSceneToFile(PublicScene(record.id,false,true),(root/"Scenes/ground.judas").string(),error),"write regional ground source: "+error);
    return project.ProjectFile();
}
void PublicStep(RuntimeWorld& world,EntityId actor=kActor){auto body=world.RuntimeBody(actor);world.Physics().ApplyLinearAcceleration(body,{0,-9.81f,0},kColdDt);world.Physics().Step(kColdDt);}
void PublicPrefix(RuntimeWorld& world,EntityId actor=kActor){world.Physics().SetSleepingEnabled(false);for(unsigned i=0;i<6;++i)PublicStep(world,actor);}
std::string PublicMesh(RuntimeWorld& world){SaveArchive archive;world.Physics().PersistMeshContacts(archive,[&](BodyHandle h){return world.EntityIdOfBody(h);},[&](uint64_t id){return world.RuntimeBody(id);});return archive.bytes;}
ColdState ActualState(RuntimeWorld& world,EntityId ground=kGround,EntityId actor=kActor){const auto a=world.RuntimeBody(actor),g=world.RuntimeBody(ground);return {world.Physics().GetTransform(g),world.Physics().GetTransform(a),world.Physics().GetLinearVelocity(a),world.Physics().GetAngularVelocity(a)};}
bool PumpResources(ResourceManager& resources,const std::string& asset,std::string& error){for(unsigned i=0;i<5000;++i){resources.Pump();if(resources.GetCollision(asset,error))return true;std::this_thread::sleep_for(std::chrono::milliseconds(1));}return false;}
}
