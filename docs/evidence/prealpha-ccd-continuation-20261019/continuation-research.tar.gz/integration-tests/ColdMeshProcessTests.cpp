// Run writefile and restorefile as separate OS processes. Only represented body
// state and the public mesh ownership participant cross that process boundary.
#include "ColdMeshFixture.h"
#include <fstream>
#include <iterator>
#ifdef _WIN32
#include <process.h>
#else
#include <unistd.h>
#endif

namespace {
uint64_t ProcessId(){
#ifdef _WIN32
    return uint64_t(_getpid());
#else
    return uint64_t(getpid());
#endif
}
void StateField(SaveArchive& archive,ColdState& state){
    archive(state.ground.position,state.ground.rotation,state.actor.position,state.actor.rotation,state.linear,state.angular);
}
struct ReferenceEndpoint {
    ColdState state;double depth=0;
    void Save(SaveArchive& archive){StateField(archive,state);archive(depth);}
};
struct ProcessState {
    uint64_t writerPid=0;
    ColdState state;
    std::string mesh;
    std::vector<ReferenceEndpoint> uninterrupted;
    void Save(SaveArchive& archive){
        std::string magic="Judas.ColdMeshProcess.1";uint32_t prefix=6,suffix=4;
        archive(magic,prefix,suffix,writerPid);
        archive.Require(magic=="Judas.ColdMeshProcess.1"&&prefix==6&&suffix==4&&writerPid,
                        "invalid cold mesh process fixture header");
        StateField(archive,state);archive(mesh,uninterrupted);
        archive.Require(uninterrupted.size()==4,"cold mesh process needs four uninterrupted reference endpoints");
    }
};
std::string ReadFile(const std::string& path){
    std::ifstream input(path,std::ios::binary|std::ios::ate);
    if(!input)throw std::runtime_error("cannot open process fixture: "+path);
    const auto size=input.tellg();
    if(size<0||uint64_t(size)>SaveArchive::Limit)throw std::runtime_error("invalid process fixture size");
    input.seekg(0);std::string bytes(std::size_t(size),'\0');
    if(!bytes.empty()&&!input.read(bytes.data(),std::streamsize(bytes.size())))throw std::runtime_error("truncated process fixture read");
    return bytes;
}
void WriteFile(const std::string& path,const std::string& bytes){
    std::ofstream output(path,std::ios::binary|std::ios::trunc);
    if(!output||!output.write(bytes.data(),std::streamsize(bytes.size())))throw std::runtime_error("cannot write process fixture: "+path);
    output.close();if(!output)throw std::runtime_error("cannot complete process fixture: "+path);
}
ProcessState ReadState(const std::string& path){
    SaveArchive archive(ReadFile(path));ProcessState out;out.Save(archive);archive.Finish();return out;
}
double RotationDifference(const glm::quat& a,const glm::quat& b){
    const auto first=ContactRotation(a),second=ContactRotation(b);double result=0;
    for(unsigned c=0;c<3;++c)for(unsigned r=0;r<3;++r)result=std::max(result,std::abs(first[c][r]-second[c][r]));
    return result;
}
void WriteMode(const std::string& path){
    const auto asset=Sheet(2,26,true);const SheetOracle oracle(*asset);
    ColdWorld source(asset);for(int step=0;step<6;++step)source.Step();
    ProcessState saved;saved.writerPid=ProcessId();saved.state=source.State();saved.mesh=source.Capture();
    const auto parsed=Decode(saved.mesh);
    Check(source.ActualNativeContacts()==0,"write: original box17/prefix6 has no stateless native contacts");
    Check(parsed.records.size()==1&&!parsed.records.front().features.empty(),"write: actual influential finite ownership is captured");
    Check(source.Owners()==std::vector<std::pair<uint64_t,uint64_t>>{{kGround,kActor}},"write: actual owners identify original sheet contact");
    for(int step=1;step<=4;++step){source.Step();const auto state=source.State();const double depth=oracle.Depth(state.actor.position);
        saved.uninterrupted.push_back({state,depth});
        Check(depth<=.05,"write: uninterrupted reference respects original 5 cm actual-sheet gate");
        std::cout<<"COLD_PROCESS_REFERENCE step="<<step<<" depth="<<depth<<" position="<<state.actor.position.x<<','<<state.actor.position.y<<','<<state.actor.position.z<<'\n';
    }
    if(failures)throw std::runtime_error("refusing to write failed original influential fixture");
    SaveArchive archive;saved.Save(archive);WriteFile(path,archive.bytes);
    std::cout<<"COLD_PROCESS_WRITE pid="<<saved.writerPid<<" file="<<path<<" bytes="<<archive.bytes.size()
             <<" mesh_bytes="<<saved.mesh.size()<<" features="<<parsed.records.front().features.size()<<'\n';
}
void RestoreMode(const std::string& path){
    const auto saved=ReadState(path);Check(saved.writerPid!=ProcessId(),"restore: writer and reader are distinct OS processes");
    // Re-cook in this process. No source-process asset/query/cache pointer exists.
    const auto asset=Sheet(2,26,true);const SheetOracle oracle(*asset);
    ColdWorld restored(asset,&saved.state,true),omitted(asset,&saved.state,true);
    const auto before=restored.State();
    Check(restored.Owners().empty()&&omitted.Owners().empty(),"restore: both new worlds begin without historical ownership");
    Check(restored.ActualNativeContacts()==0,"restore: actual reconstructed endpoint still has no stateless native contacts");
    Check(restored.Restore(saved.mesh),"restore: public participant restores influential finite history");
    Check(SameMotion(before,restored.State()),"restore: participant changes neither represented pose nor velocity");
    const auto recaptured=restored.Capture();
    Check(recaptured==saved.mesh,"restore: freshly cooked reversed-slot world recaptures canonical bytes exactly");
    Check(Selected(Decode(recaptured))==Selected(Decode(saved.mesh)),"restore: exact stored finite features survive the cold process boundary");
    bool different=false;double maximumRestored=-INFINITY,maximumOmitted=-INFINITY;
    double referencePosition=0,referenceRotation=0,referenceLinear=0,referenceAngular=0;
    for(int step=1;step<=4;++step){restored.Step();omitted.Step();
        const auto r=restored.State(),o=omitted.State();const auto& reference=saved.uninterrupted[std::size_t(step-1)];
        const double rd=oracle.Depth(r.actor.position),od=oracle.Depth(o.actor.position);
        maximumRestored=std::max(maximumRestored,rd);maximumOmitted=std::max(maximumOmitted,od);
        const double position=glm::length(glm::dvec3(r.actor.position)-glm::dvec3(reference.state.actor.position));
        const double rotation=RotationDifference(r.actor.rotation,reference.state.actor.rotation);
        const double linear=glm::length(glm::dvec3(r.linear)-glm::dvec3(reference.state.linear));
        const double angular=glm::length(glm::dvec3(r.angular)-glm::dvec3(reference.state.angular));
        referencePosition=std::max(referencePosition,position);referenceRotation=std::max(referenceRotation,rotation);
        referenceLinear=std::max(referenceLinear,linear);referenceAngular=std::max(referenceAngular,angular);
        different|=r.actor.position!=o.actor.position||RotationDifference(r.actor.rotation,o.actor.rotation)!=0||r.linear!=o.linear||r.angular!=o.angular;
        Check(rd<=.05,"restore: actual restored endpoint respects original 5 cm sheet gate");
        std::cout<<"COLD_PROCESS_SUFFIX pid="<<ProcessId()<<" writer_pid="<<saved.writerPid<<" step="<<step
                 <<" restored_depth="<<rd<<" omitted_depth="<<od<<" uninterrupted_depth="<<reference.depth
                 <<" restored_position="<<r.actor.position.x<<','<<r.actor.position.y<<','<<r.actor.position.z
                 <<" omitted_position="<<o.actor.position.x<<','<<o.actor.position.y<<','<<o.actor.position.z
                 <<" reference_position_delta="<<position<<" reference_rotation_matrix_delta="<<rotation
                 <<" reference_linear_delta="<<linear<<" reference_angular_delta="<<angular<<'\n';
    }
    Check(different,"restore: omitted-history cold control changes actual physical continuation");
    Check(maximumOmitted>.05,"restore: omitted-history positive control crosses original actual-sheet gate");
    // Restoring only ownership omits solver warm impulses. Reference differences
    // are observations, never a fabricated bitwise continuation acceptance gate.
    std::cout<<"COLD_PROCESS_COMPARISON pid="<<ProcessId()<<" writer_pid="<<saved.writerPid
             <<" restored_max_depth="<<maximumRestored<<" omitted_max_depth="<<maximumOmitted
             <<" max_uninterrupted_position_delta="<<referencePosition<<" max_uninterrupted_rotation_matrix_delta="<<referenceRotation
             <<" max_uninterrupted_linear_delta="<<referenceLinear<<" max_uninterrupted_angular_delta="<<referenceAngular<<'\n';
}
void RejectMode(const std::string& path,bool geometry){
    const auto saved=ReadState(path);Check(saved.writerPid!=ProcessId(),"reject: reader is a new OS process");
    const auto original=Sheet(2,26,true);const auto asset=geometry?ChangedGeometry(*original):original;
    ColdWorld target(asset,&saved.state,true);const auto before=target.State();const auto bytes=target.Capture();
    auto participant=saved.mesh;if(!geometry){if(participant.empty())throw std::runtime_error("missing fixture participant");participant.pop_back();}
    bool rejected=false;
    try{target.Restore(participant);}catch(const std::exception& error){rejected=true;std::cout<<"COLD_PROCESS_REJECT mode="<<(geometry?"changed_geometry":"truncated_participant")<<" reason="<<error.what()<<'\n';}
    Check(rejected,geometry?"reject: changed freshly cooked geometry is rejected":"reject: truncated cold ownership participant is rejected");
    Check(target.Owners().empty()&&target.Capture()==bytes&&SameMotion(before,target.State()),"reject: invalid cold restore publishes no partial ownership or body change");
}
}

int main(int argc,char** argv){
    std::cout<<std::setprecision(17);
    if(argc!=3){std::cerr<<"usage: ColdMeshProcessTests writefile|restorefile|rejectgeometry|rejecttruncated PATH\n";return 2;}
    const std::string mode=argv[1],path=argv[2];
    try{
        if(mode=="writefile")WriteMode(path);
        else if(mode=="restorefile")RestoreMode(path);
        else if(mode=="rejectgeometry")RejectMode(path,true);
        else if(mode=="rejecttruncated")RejectMode(path,false);
        else throw std::invalid_argument("unknown cold process mode");
    }catch(const std::exception& error){std::cerr<<"COLD_PROCESS_UNEXPECTED mode="<<mode<<" pid="<<ProcessId()<<" error="<<error.what()<<'\n';Check(false,"cold process mode completes without unexpected exception");}
    std::cout<<"COLD_PROCESS_RESULT mode="<<mode<<" pid="<<ProcessId()<<" checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
