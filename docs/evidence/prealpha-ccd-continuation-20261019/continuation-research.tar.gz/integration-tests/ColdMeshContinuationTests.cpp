// Isolated public-API cold ownership test. Link the exact coherent integration
// implementation. No completed observations, warm impulses or motion ledgers are
// restored: the two cold worlds differ ONLY by PersistMeshContacts history.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main
#include "SaveArchive.h"
#include <functional>
#include <map>
#include <tuple>

namespace {
constexpr float kColdDt=1.f/60.f;
constexpr uint64_t kGround=100,kActor=200,kInert=300;
struct ColdState { BodyTransform ground,actor;glm::vec3 linear{0},angular{0}; };
struct ColdWorld {
    PhysicsWorld world;
    std::shared_ptr<CollisionAsset> asset;
    BodyHandle ground,actor,inert;
    ColdWorld(std::shared_ptr<CollisionAsset> mesh,const ColdState* state=nullptr,
              bool reversed=false,glm::dvec3 delta={0,0,0}):asset(std::move(mesh)) {
        world.Init();world.SetSleepingEnabled(false);
        const auto shifted=[&](BodyTransform p){p.position=glm::vec3(glm::dvec3(p.position)-delta);return p;};
        const BodyTransform gp=state?shifted(state->ground):BodyTransform{};
        BodyTransform ap;ap.position={.5f,1.2f,-1.f};if(state)ap=shifted(state->actor);
        auto makeGround=[&]{ground=world.CreateShape(Shape::Cooked(asset,"impact cost sheet"),gp,false,1,.6f,0);};
        auto makeActor=[&]{actor=world.CreateDynamicBox(ap.position,{.02f,.01f,.03f},.2f,.4f,0);
            if(state)world.ResetBody(actor,ap.position,ap.rotation);};
        if(reversed){makeActor();makeGround();}else{makeGround();makeActor();}
        inert=world.CreateStaticBox(glm::vec3(glm::dvec3(1000)-delta),{1,1,1},0,0);
        world.SetLinearVelocity(actor,state?state->linear:glm::vec3(0,-40.f,30.f));
        if(state)world.SetAngularVelocity(actor,state->angular);
    }
    uint64_t Identity(BodyHandle h)const {
        if(h.id==ground.id)return kGround;if(h.id==actor.id)return kActor;if(h.id==inert.id)return kInert;return 0;
    }
    BodyHandle Resolve(uint64_t id)const {
        return id==kGround?ground:id==kActor?actor:id==kInert?inert:BodyHandle{};
    }
    ColdState State()const{return {world.GetTransform(ground),world.GetTransform(actor),world.GetLinearVelocity(actor),world.GetAngularVelocity(actor)};}
    void Step(){world.ApplyLinearAcceleration(actor,{0,-9.81f,0},kColdDt);world.Step(kColdDt);}
    std::string Capture(const std::function<bool(BodyHandle)>& include={}) {
        SaveArchive archive;world.PersistMeshContacts(archive,[&](BodyHandle h){return Identity(h);},
            [&](uint64_t id){return Resolve(id);},include);return archive.bytes;
    }
    bool Restore(const std::string& bytes,bool merge=false,glm::dvec3 delta={0,0,0},
                 const std::function<bool(BodyHandle)>& include={},
                 const std::function<BodyHandle(uint64_t)>& resolver={}) {
        SaveArchive archive(bytes);const bool any=world.PersistMeshContacts(archive,{},
            resolver?resolver:std::function<BodyHandle(uint64_t)>([&](uint64_t id){return Resolve(id);}),
            include,merge,delta);archive.Finish();return any;
    }
    std::vector<std::pair<uint64_t,uint64_t>> Owners()const {
        std::vector<std::pair<uint64_t,uint64_t>> result;
        for(const auto& p:world.MeshContactOwners()){auto a=Identity(p.first),b=Identity(p.second);if(a>b)std::swap(a,b);result.push_back({a,b});}
        std::sort(result.begin(),result.end());return result;
    }
    int ActualNativeContacts()const {
        PrimitivePose query,mesh;query.shape=Shape::Box({.02f,.01f,.03f});mesh.shape=Shape::Cooked(asset,"stateless endpoint observation");
        const auto qp=world.GetTransform(actor),mp=world.GetTransform(ground);
        query.parentPosition=qp.position;query.parentOrientation=qp.rotation;
        mesh.parentPosition=mp.position;mesh.parentOrientation=mp.rotation;
        return ComputeContacts(query,mesh,0).count;
    }
};
struct MeshRecord {
    uint64_t first=0,second=0;int partA=0,partB=0;
    glm::vec3 positionA{0},positionB{0};std::string contextA,contextB;
    std::vector<uint32_t> features;
    void Save(SaveArchive& a){a(first,second,partA,partB,positionA,positionB,contextA,contextB,features);}
};
struct MeshBlob {uint32_t version=1;std::vector<MeshRecord> records;};
MeshBlob Decode(const std::string& bytes) {
    SaveArchive archive(bytes);MeshBlob out;uint32_t count=0;archive(out.version,count);
    archive.Require(count<=8192,"test record count limit");out.records.resize(count);
    for(auto& record:out.records)record.Save(archive);archive.Finish();return out;
}
std::string Encode(MeshBlob value) {
    SaveArchive archive;uint32_t count=uint32_t(value.records.size());archive(value.version,count);
    for(auto& record:value.records)record.Save(archive);return archive.bytes;
}
auto Selected(const MeshBlob& value) {
    std::map<std::tuple<uint64_t,uint64_t,int,int>,std::vector<uint32_t>> result;
    for(auto record:value.records){if(record.first>record.second){std::swap(record.first,record.second);std::swap(record.partA,record.partB);}
        result.emplace(std::make_tuple(record.first,record.second,record.partA,record.partB),record.features);}
    return result;
}
bool SameMotion(const ColdState& a,const ColdState& b) {
    return a.ground.position==b.ground.position&&a.ground.rotation==b.ground.rotation&&
           a.actor.position==b.actor.position&&a.actor.rotation==b.actor.rotation&&a.linear==b.linear&&a.angular==b.angular;
}
template<class Function>void RejectUnchanged(ColdWorld& value,const char* name,Function action) {
    const auto before=value.Capture();const auto owners=value.Owners();const auto state=value.State();bool rejected=false;
    try{action();}catch(const std::exception& e){rejected=true;std::cout<<"COLD_REJECT case="<<name<<" reason="<<e.what()<<'\n';}
    Check(rejected,std::string(name)+": invalid restore/capture is rejected");
    Check(value.Capture()==before&&value.Owners()==owners&&SameMotion(value.State(),state),
          std::string(name)+": rejection changes neither ownership nor actual body state");
}
std::shared_ptr<CollisionAsset> ChangedGeometry(const CollisionAsset& base) {
    MeshData data;for(auto p:base.vertices){MeshVertex vertex;vertex.position=glm::vec3(p);data.vertices.push_back(vertex);}
    for(const auto& face:base.faces)data.indices.insert(data.indices.end(),face.vertices.begin(),face.vertices.end());
    data.vertices[0].position.y+=.0001f;
    auto changed=std::make_shared<CollisionAsset>();CollisionCookSettings settings;std::string error;
    Check(CookCollision(data,settings,*changed,error),"changed finite mesh cooks: "+error);
    // Both programmatic cooks deliberately lack importer fingerprints. The
    // actual geometry digest, not a changed label, must reject this restore.
    Check(changed->sourceFingerprint==base.sourceFingerprint&&changed->settingsFingerprint==base.settingsFingerprint,
          "changed-geometry control shares optional importer metadata");return changed;
}
void CheckSuffix(ColdWorld& restored,ColdWorld& omitted,const SheetOracle& oracle,const char* name) {
    bool differ=false;double restoredMax=-INFINITY,omittedMax=-INFINITY;
    for(int step=1;step<=4;++step){restored.Step();omitted.Step();
        const auto r=restored.State(),o=omitted.State();differ|=!SameMotion(r,o);
        const double rd=oracle.Depth(r.actor.position),od=oracle.Depth(o.actor.position);
        restoredMax=std::max(restoredMax,rd);omittedMax=std::max(omittedMax,od);
        Check(rd<=.05,std::string(name)+": restored actual endpoint respects original 5 cm sheet gate");
        std::cout<<"COLD_SUFFIX case="<<name<<" step="<<step<<" restored_depth="<<rd<<" omitted_depth="<<od
                 <<" restored_position="<<r.actor.position.x<<','<<r.actor.position.y<<','<<r.actor.position.z
                 <<" omitted_position="<<o.actor.position.x<<','<<o.actor.position.y<<','<<o.actor.position.z<<'\n';
    }
    Check(differ,std::string(name)+": omitted history changes actual cold continuation");
    Check(omittedMax>.05,std::string(name)+": omitted-history positive control crosses original sheet gate");
    std::cout<<"COLD_SUFFIX_RESULT case="<<name<<" restored_max_depth="<<restoredMax<<" omitted_max_depth="<<omittedMax
             <<" physical_difference="<<differ<<'\n';
}
}

int main(){
    std::cout<<std::setprecision(17);
    try{
        const auto asset=Sheet(2,26,true);const SheetOracle oracle(*asset);
        ColdWorld source(asset);for(int step=0;step<6;++step)source.Step();
        const auto state=source.State();const auto bytes=source.Capture();const auto parsed=Decode(bytes);
        Check(source.ActualNativeContacts()==0,"original box17/prefix6 has no stateless native endpoint contacts");
        Check(parsed.records.size()==1&&!parsed.records.front().features.empty(),
              "actual original influential finite ownership is serialized");
        Check(source.Owners()==std::vector<std::pair<uint64_t,uint64_t>>{{kGround,kActor}},"public owners identify the influential pair");
        if(parsed.records.empty())throw std::runtime_error("influential fixture has no durable ownership");
        std::cout<<"COLD_CAPTURE bytes="<<bytes.size()<<" records="<<parsed.records.size()<<" features="<<parsed.records.front().features.size()
                 <<" native_contacts="<<source.ActualNativeContacts()<<" original_depth="<<oracle.Depth(state.actor.position)<<'\n';

        for(bool reversed:{false,true}){
            ColdWorld restored(asset,&state,reversed),omitted(asset,&state,reversed);
            Check(restored.Capture()==Encode(MeshBlob{}),"fresh cold world owns no historical state");
            const auto before=restored.State();Check(restored.Restore(bytes),"cold restore reports influential ownership");
            Check(SameMotion(before,restored.State()),"ownership restore preserves exact actual pose and velocity");
            const auto recaptured=restored.Capture();
            Check(recaptured==bytes,"cold recapture is byte-identical despite runtime handle/slot remapping");
            Check(Selected(Decode(recaptured))==Selected(parsed),"cold recapture retains exact stored finite features");
            CheckSuffix(restored,omitted,oracle,reversed?"reversed_slots":"same_slots");
        }

        // Rejection tests run against both empty ownership and existing valid
        // ownership. A valid first pending record followed by a duplicate must
        // not clear or partially replace the existing participant.
        for(bool preowned:{false,true}){
            ColdWorld target(asset,&state,true);if(preowned)target.Restore(bytes);
            MeshBlob corrupt=parsed;corrupt.records.front().contextA.back()^=1;
            RejectUnchanged(target,"corrupt_context",[&]{target.Restore(Encode(corrupt));});
            corrupt=parsed;corrupt.records.front().features.back()=UINT32_MAX;
            RejectUnchanged(target,"unavailable_feature",[&]{target.Restore(Encode(corrupt));});
            corrupt=parsed;corrupt.records.push_back(corrupt.records.front());
            RejectUnchanged(target,"duplicate_pending_record",[&]{target.Restore(Encode(corrupt));});
            RejectUnchanged(target,"truncated_last_field",[&]{target.Restore(bytes.substr(0,bytes.size()-1));});
            RejectUnchanged(target,"truncated_context",[&]{target.Restore(bytes.substr(0,bytes.size()/2));});
            RejectUnchanged(target,"trailing_bytes",[&]{target.Restore(bytes+std::string(1,'x'));});
            SaveArchive oversized;uint32_t format=1,tooMany=8193;oversized(format,tooMany);
            RejectUnchanged(target,"pair_admission_limit",[&]{target.Restore(oversized.bytes);});
            RejectUnchanged(target,"excluded_restore_owner",[&]{target.Restore(bytes,false,{0,0,0},[&](BodyHandle h){return h.id==target.actor.id;});});
            RejectUnchanged(target,"unavailable_owner",[&]{target.Restore(bytes,false,{0,0,0},{},[&](uint64_t id){return id==kGround?BodyHandle{}:target.Resolve(id);});});
            RejectUnchanged(target,"owner_alias",[&]{target.Restore(bytes,false,{0,0,0},{},[&](uint64_t){return target.actor;});});
        }
        RejectUnchanged(source,"excluded_ground_capture",[&]{source.Capture([&](BodyHandle h){return h.id==source.actor.id;});});
        RejectUnchanged(source,"excluded_actor_capture",[&]{source.Capture([&](BodyHandle h){return h.id==source.ground.id;});});
        Check(Decode(source.Capture([](BodyHandle){return false;})).records.empty(),"wholly excluded separate group captures no record");

        const auto changed=ChangedGeometry(*asset);ColdWorld changedTarget(changed,&state);
        RejectUnchanged(changedTarget,"changed_programmatic_geometry",[&]{changedTarget.Restore(bytes);});

        ColdWorld merged(asset,&state);merged.Restore(bytes);
        RejectUnchanged(merged,"merge_existing_duplicate",[&]{merged.Restore(bytes,true);});
        Check(!merged.Restore(Encode(MeshBlob{}),true)&&merged.Capture()==bytes,"empty merge preserves existing exact ownership");
        Check(!merged.Restore(Encode(MeshBlob{}),false)&&merged.Owners().empty(),"empty replacement deliberately clears the participant");

        // Nonzero origin delta chosen from the actor's represented x. The ground
        // x is zero: translated actor x=0 and mesh x=-oldActorX, so the exact
        // double relative centre used by native finite SAT remains unchanged.
        const glm::dvec3 delta(double(state.actor.position.x),0,0);
        Check(delta.x!=0,"origin control uses a nonzero translation");
        ColdWorld translated(asset,&state,true,delta);
        Check(glm::dvec3(translated.State().actor.position)-glm::dvec3(translated.State().ground.position)==
              glm::dvec3(state.actor.position)-glm::dvec3(state.ground.position),"origin control preserves exact represented relative centre");
        Check(translated.Restore(bytes,false,delta),"translated cold restore accepts exact actual geometry");
        auto translatedBlob=Decode(translated.Capture());
        Check(Selected(translatedBlob)==Selected(parsed),"translated restore retains same finite features");
        for(auto& r:translatedBlob.records){r.positionA=glm::vec3(glm::dvec3(r.positionA)+delta);r.positionB=glm::vec3(glm::dvec3(r.positionB)+delta);}
        Check(Encode(translatedBlob)==bytes,"translated recapture normalizes to identical original serialized bytes");

        ColdWorld staged(asset,&state,true,delta);
        for(auto h:{staged.ground,staged.actor}){Check(staged.world.SetBodyEnabled(h,false),"staging disable accepted");Check(staged.world.SetBodySimulationSuspended(h,true),"staging suspend accepted");}
        RejectUnchanged(staged,"restore_before_activation",[&]{staged.Restore(bytes,false,delta);});
        for(auto h:{staged.ground,staged.actor}){Check(staged.world.SetBodySimulationSuspended(h,false),"staging resume accepted");Check(staged.world.SetBodyEnabled(h,true),"staging activate accepted");}
        Check(staged.Restore(bytes,false,delta)&&Selected(Decode(staged.Capture()))==Selected(parsed),
              "translated suspended region restores ownership only after both endpoints activate");
    }catch(const std::exception& error){std::cerr<<"COLD_UNEXPECTED error="<<error.what()<<'\n';Check(false,"cold continuation test completes without unexpected exception");}
    std::cout<<"COLD_RESULT checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
