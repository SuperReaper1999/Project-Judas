// Actual Application + SceneSession + SaveService + durable SaveStorage pipeline.
// Default mode creates one disposable project and runs writer/readers in separate
// processes. Each Application uses a zero frame clock; six/four native physical
// steps are explicit so the original ImpactMeshCost fixture is byte unchanged.
#include "ColdMeshPublicFixture.h"
#include "Application.h"
#include "EngineHost.h"
#include "InteractivePlay.h"
#include "SceneSession.h"
#include "SaveService.h"
#include "SaveEvolution.h"
#include "SceneFingerprint.h"
#include <SDL2/SDL.h>
#include <sys/wait.h>
#include <cstdio>
namespace {
void QuitApplication(){SDL_Event event{};event.type=SDL_QUIT;SDL_PushEvent(&event);}
void StorageControls(SaveStorage& storage,const GameSnapshot& captured,RuntimeWorld& world){
    std::string error;auto value=captured;value.participants.erase("mesh-contacts");
    Need(storage.Write("missing-modern",value,error),"store modern missing-history negative control: "+error);
    value.gameVersion=1;Need(storage.Write("legacy-ambiguous",value,error),"store explicit old ambiguous negative control: "+error);
    value=captured;value.participants["unknown-probe"]={1,""};Need(storage.Write("unknown-participant",value,error),"store unknown-participant negative control: "+error);
    value=captured;Need(!value.participants.at("mesh-contacts").data.empty(),"history payload exists before truncation");
    value.participants.at("mesh-contacts").data.pop_back();Need(storage.Write("truncated-history",value,error),"store checksum-valid truncated participant control: "+error);
    const std::vector<std::string> known={"entities","motors","animation","articulation","navigation","audio","liquid","contacts","scripts","session","streaming","sleep","mesh-contacts","weather","planets","deformables","kinematic-motion","wheels","powertrains","physical-animation","physical-balance","animation-observations","runtime-terrain","view-projection"};
    value=captured;for(const auto& name:known)value.participants[name]={1,""};
    GameSnapshot decoded;Need(value.participants.size()==24&&DecodeGameSnapshot(EncodeGameSnapshot(value),decoded,error)&&decoded.participants.size()==24,"storage bound accepts every currently known participant name together");
    value.participants["one-too-many"]={1,""};bool rejected=false;try{(void)EncodeGameSnapshot(value);}catch(const std::exception&){rejected=true;}Need(rejected,"storage rejects 25 participants without a larger arbitrary grant");Need(!storage.Write("oversized-participants",value,error),"public durable storage rejects oversized participant set before publication");
    // Capture actual unambiguous native geometry for the legacy positive control.
    world.Physics().ResetBody(world.RuntimeBody(kActor),{.5f,1.2f,-1.f},{1,0,0,0});
    world.Physics().SetLinearVelocity(world.RuntimeBody(kActor),{0,0,0});
    std::map<std::string,SaveChunk> front;Need(WorldPersistence::Capture(world,front,error),"capture actual ordinary front legacy control: "+error);
    value=captured;for(auto& [name,chunk]:front)value.participants[name]=std::move(chunk);
    value.gameVersion=1;value.participants.erase("mesh-contacts");
    Need(storage.Write("legacy-front",value,error),"store supported front-complete legacy control: "+error);
}
int RunApplication(const std::string& project,const std::string& mode){
    const bool writing=mode=="write",accept=mode=="read"||mode=="legacy-front";
    const std::string slot=mode=="read"?"curved-prefix":mode;std::string error;
    unsigned frames=0;uint64_t request=0;RuntimeWorld* initial=nullptr;bool done=false;GameSnapshot expected;
    glm::vec3 initialPosition{0};ApplicationControl control;control.hidden=true;
    control.frameSeconds=[](float){return 0.f;};
    control.hostReady=[](EngineHost& host){host.GetWindow().SetTestInputMode(true);SDL_GL_SetSwapInterval(0);std::string e;host.Audio().Init(e,true);};
    control.worldReady=[&](EngineHost&,RuntimeWorld& world,InteractivePlay&){initial=&world;world.Physics().SetSleepingEnabled(false);initialPosition=world.Physics().GetTransform(world.RuntimeBody(kActor)).position;if(writing)PublicPrefix(world);};
    control.beforeFrame=[&](EngineHost&,RuntimeWorld& world,InteractivePlay&){
        if(&world==initial||done)return;Need(accept,"a rejected detached snapshot never replaces the live RuntimeWorld");
        done=true;
        if(mode=="read"){
            const auto captured=PublicMesh(world);Need(captured==expected.participants.at("mesh-contacts").data,"cold public envelope restores exact canonical finite history before resumed physics");
            Need(!Decode(captured).records.empty(),"actual restored endpoint has influential finite ownership");
            const auto state=ActualState(world);auto fresh=Sheet(2,26,true);ColdWorld omitted(fresh,&state,true);SheetOracle oracle(*fresh);
            double restored=0,missing=0;
            for(unsigned i=0;i<4;++i){PublicStep(world);omitted.Step();restored=std::max(restored,oracle.Depth(world.Physics().GetTransform(world.RuntimeBody(kActor)).position));missing=std::max(missing,oracle.Depth(omitted.world.GetTransform(omitted.actor).position));}
            Need(restored<=.05,"actual cold SaveService continuation satisfies original 5 cm no-cross gate");
            Need(missing>.05,"fresh actual endpoint without ancestry crosses original gate (positive sensitivity control)");
            std::printf("PUBLIC_SUFFIX restored_depth=%.17g omitted_depth=%.17g\n",restored,missing);
        }else{
            Need(world.Physics().GetTransform(world.RuntimeBody(kActor)).position==glm::vec3(.5f,1.2f,-1.f),"ordinary legacy front save restores actual saved position");
            Need(Decode(PublicMesh(world)).records.empty(),"ordinary legacy front save requires no invented history");
        }
        QuitApplication();
    };
    control.afterFrame=[&](EngineHost& host,RuntimeWorld& world,InteractivePlay&){
        ++frames;Need(frames<=1200,"bounded public save/load frame count");if(done)return;auto* service=world.SceneControl()->Saves(host.Resources());
        if(!request){
            if(!WorldPersistence::Prepare(world,error)){Need(error=="loading","public world prepares: "+error);return;}
            if(writing){Need(!Decode(PublicMesh(world)).records.empty(),"original actual six-step fixture has history at save boundary");request=service->Request("save","curved-prefix","curved prefix",std::string("{\"writerPid\":")+std::to_string(getpid())+"}",error);}
            else{SaveStorage storage(service->Root());bool recovered=false;Need(storage.Read(slot,expected,recovered,error)&&!recovered,"cold process reads exact selected detached slot: "+error);long long writer=0;Need(std::sscanf(expected.metadata.c_str(),"{\"writerPid\":%lld}",&writer)==1&&writer!=static_cast<long long>(getpid()),"reader process differs from writer process");request=service->Request("load",slot,"","{}",error);}
            Need(request!=0,"ordinary public SaveService request accepted: "+error);
        }
        const auto* status=service->Status(request);
        if(status&&status->state=="failed"){
            Need(!writing&&!accept,"supported public request succeeds: "+status->error);
            Need(&world==initial&&world.Physics().GetTransform(world.RuntimeBody(kActor)).position==initialPosition&&world.Physics().MeshContactOwners().empty(),"invalid public envelope leaves original owner/actual geometry untouched");
            Need(!status->error.empty(),"rejected public load explains unsupported boundary");std::printf("EXPECTED_REJECTION mode=%s error=%s\n",mode.c_str(),status->error.c_str());done=true;QuitApplication();
        }else if(status&&status->state=="completed"&&writing){
            SaveStorage storage(service->Root());GameSnapshot captured;bool recovered=false;Need(storage.Read("curved-prefix",captured,recovered,error)&&!recovered,"ordinary public save is durably readable: "+error);
            Need(captured.gameVersion==2&&captured.participants.count("mesh-contacts"),"new public schema explicitly requires finite-mesh participant");
            auto listed=storage.List(captured.project,captured.content,error);bool compatible=false;for(const auto& row:listed)if(row.id=="curved-prefix")compatible=row.status=="compatible";Need(compatible,"new schema is listed compatible by public storage");
            StorageControls(storage,captured,world);done=true;QuitApplication();
        }
        if(frames>1200){Need(false,"bounded public save/load completes");QuitApplication();}
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    };
    Application app;char name[]="judas";std::string path=project;char* args[]={name,path.data()};
    Need(app.Run(2,args,&control)==0&&done,"actual Application completes selected cold save/load mode");std::printf("PUBLIC_MODE_SUMMARY mode=%s checks=%d failures=%d\n",mode.c_str(),checks,failures);return failures?1:0;
}
int Child(const std::string& executable,const std::string& project,const char* mode){
    const auto pid=fork();Need(pid>=0,"create genuinely cold application process");
    if(!pid){execl(executable.c_str(),executable.c_str(),project.c_str(),mode,static_cast<char*>(nullptr));_exit(127);}
    int status=0;Need(waitpid(pid,&status,0)==pid,"collect cold application process");return WIFEXITED(status)?WEXITSTATUS(status):128;
}
}
int main(int argc,char** argv){try{
    if(argc==3)return RunApplication(argv[1],argv[2]);
    Need(argc==1,"usage: test [project.judasproj write|read|missing-modern|legacy-ambiguous|legacy-front|unknown-participant|truncated-history]");
    const auto root=std::filesystem::absolute(std::filesystem::path(".cache/prealpha-ccd-continuation/integration-tests")/("public-run-"+std::to_string(getpid())));
    std::filesystem::create_directories(root);const auto data=(root/"data").string();setenv("XDG_DATA_HOME",data.c_str(),1);
    const auto project=CreatePublicProject(root/"project");const auto executable=std::filesystem::absolute(argv[0]).string();
    for(const char* mode:{"write","read","missing-modern","legacy-ambiguous","legacy-front","unknown-participant","truncated-history"})Need(Child(executable,project,mode)==0,std::string("cold public process mode ")+mode);
    std::printf("SUMMARY %d checks %d failures\n",checks,failures);return failures?1:0;
}catch(const std::exception& e){std::fprintf(stderr,"PUBLIC_TEST_EXCEPTION %s\n",e.what());return 1;}}
