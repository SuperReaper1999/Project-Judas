from pathlib import Path
import datetime, hashlib, io, json, re, shutil, subprocess, tarfile
R=Path.cwd();N=R/'.cache/prealpha-ccd-continuation';D=R/'docs/evidence/prealpha-ccd-continuation-20261019';Q=N/'production-qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(name,value):(D/name).write_text(json.dumps(value,indent=2)+'\n')
def dig(p):return re.findall(r'SCENARIO "([^"]+)".* digest ([^\s]+)',p.read_text())
parent=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
gate=load(Q/'gate/RESULTS.json');native=load(Q/'NATIVE_RUNS.json')
qualification=[x for x in native if x['name'].startswith(('judas_','cold-'))]
assert gate['passed'] and len(qualification)==12 and all(x['exit']==0 for x in qualification)
assert dig(Q/'gate/impact-mesh-continuation.log')==dig(N/'qualified-native-world/full.log')
write('FINAL_RESULTS.json',{'schema':1,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':parent,'platform':'Native Linux; package graphics smoke uses llvmpipe, not hardware GPU qualification','build':load(Q/'FINAL_BUILD.json'),'compiler_warning_count':len(re.findall('warning:',(Q/'final-build.log').read_text())),'focused_gate':gate,'normal_native_and_cold_runs':native,'qualified_native_and_cold_count':len(qualification),'platform_smoke':load(Q/'PLATFORM_SMOKE.json'),'relocated_run':load(Q/'MOVED_RUN.json'),'six_final_normal_scenario_digests_equal_isolated':True,'native_point_parity':{'cases':8192,'all_rows_equal':True,'fingerprint':'0166274568e9538b'},'windows_android':'Not rerun; nonblocking','human_accepted':False,'full_production_suite':'Not rerun','setup_failures_preserved':['New target unavailable until explicit configure; build then passed.','Old application missing arguments gave usage exit2.','Unisolated application save storage was busy; owned XDG_DATA_HOME write/read passed.','Unsupported --judas-build-info: runtime usage exit1, editor timeout; corrected --build-info-json probes both exit0.','Initial package rename crossed filesystems (EXDEV); copy/hash verification/original-path removal followed by relocated launch passed.']})
shutil.copyfile(N/'qualified-native-world/measurements/point-matched/MEASUREMENTS.json',D/'MATCHED_PERFORMANCE.json')
write('FINDING_DISPOSITIONS.json',{'parent_register':'docs/evidence/prealpha-pass5/AUDIT_DISPOSITION.md','scope':'Deltas only; every unrelated disposition retained, not whole-engine certification','findings':[{'id':'CCD-MESH-CONTINUATION','status':'Corrected original four contracts; ordinary focused gate','limits':'Bounded sampling, native rear selection, deep initial overlap; corrected mesh costs more than parent'},{'id':'CLIP-CONVEXITY','status':'Corrected','before':'15/6','after':'15/0'},{'id':'STREAM-ORIGIN-PRECISION','status':'Corrected','before':'Same portable test 67/7','after':'67/0; real cold native endpoints'},{'id':'DENSE-CCD-TAIL','status':'Open, not rebenchmarked here'},{'id':'FLU-001','status':'Deferred unchanged'},{'id':'LEGACY-CONTINUATION','status':'Missing original historical state unchanged'},{'id':'LIQUID-ORIGIN-GRID-QUERY','status':'Unchanged, not investigated here'}]})
(D/'REPRODUCE.md').write_text('''# Reproduction

Use a separate checkout of parent `146a0727eab63d9555c732bf73e6093be5bc489d`
for BEFORE. Its engine source matches the recorded prebuilt baseline. Preserve
its failures; do not overwrite the final candidate. Existing Linux dependencies
and build setup apply; no new dependency is needed.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DJUDAS_ENABLE_VALIDATION=ON
cmake --build build --parallel 2 --target judas_impact_mesh_cost_tests
build/judas_impact_mesh_cost_tests 60 "" 1.2
```

Parent: 372 checks / four failures. Final: same 372 checks / zero failures.
Original source, launches, 90-step horizon, independent oracle and thresholds
are unchanged. The repeated-search-only ablation also fails four.

```sh
cmake --build build --parallel 2 --target judas_native_mesh_growth_tests judas_clip_polygon_tests judas_stream_origin_precision_tests
python3 scripts/prealpha_validate.py --build-dir build --output /tmp/judas-ccd-review --test native-mesh-growth --test clip-polygon --test stream-origin-precision --test impact-mesh-continuation
```

Use a new output directory. Gate provenance requires reconfiguration/rebuild after
source/checkpoint changes. Recorded pre-commit binaries embed their actual dirty
parent identity; per-file fingerprints bind their engine source to the candidate,
not an invented later commit identity. The same portable precision test linked
against the parent fails seven strict checks and against the correction passes.

The existing public application/cold-save test requires project, mode and output:

```sh
XDG_DATA_HOME=/tmp/judas-ccd-saves SDL_AUDIODRIVER=dummy build/judas_save_streaming_tests projects/streamed_range/streamed_range.judasproj write /tmp/judas-ccd-save-results
XDG_DATA_HOME=/tmp/judas-ccd-saves SDL_AUDIODRIVER=dummy build/judas_save_streaming_tests projects/streamed_range/streamed_range.judasproj read /tmp/judas-ccd-save-results
```

Research archives preserve exact sources, failed/positive controls, raw three-pair
timings, actual receipts, private-bound probes and the 8,192-row comparison.
Their raw commands retain original host paths. Isolated replay needs a rebuilt
parent archive and adapted root paths; compiled objects/executables are excluded.
The normal CMake gates above need no archived binaries.

The ordinary Physics Stress Lab package was exported, every relocated file hash
verified, its original export path made unavailable, and runtime launched for 60
fixed frames from unrelated /tmp. This is an application/export smoke, not a
visual curved-trough oracle. Windows/Android and fresh manual editor Play/Stop
were not claimed; editor/runtime Release builds and identity probes passed.
''')
(D/'NUMERICS.md').write_text('''# Native depth bound

For selected native triangle front n and actual points v, take H=max(dot(n,v))
and L=min(dot(n,p)) over query vertices p. D=max(0,H-L) bounds front penetration.
The allowed SAT axes include normalized n, so ordinary selected depth is bounded
by D/|n|. The rear-cone guard explicitly selects that front. Triangle face witnesses
use q=p-n*h and gap=dot(responseNormal,p-q), bounded by |n|*D provided clipping
retains the incident convex hull. All three triangle projections are enclosed,
including winding reversal and represented rotation.

The original epsilon-classification/zero-plane interpolation could extrapolate.
Retaining the incident endpoint when t lies outside [0,1] corrects this separate
numerical defect. Genuine crossings keep exactly the original expression.

Bounds do not assume exactly unit represented normals. They use max(|n|,1/|n|),
a normalization envelope and conservative 8*gamma(128)*M arithmetic padding,
gamma(k)=k*epsilon/(1-k*epsilon), M at least one and the largest mesh-relative
coordinate magnitude. This covers three bounded clipping stages, vertex/dot/
projection/subtraction operations. Padding only makes rejection harder; it never
changes actual contact tolerances. Nonfinite/unsupported cases fall back.

The interval certificate uses existing represented Cayley rotation intervals and
monotone binary32 centre endpoint bounds on one real trajectory segment. A
conservative swept enclosure selects every potential finite triangle. It checks
both fronts when native selection is uncertain, including the one-sided epsilon
strip. Only a certified whole interval is omitted. Hulls, compounds, pivots and
unsupported prescribed rotations retain full search. The point bound uses actual
native vertices after actual side selection and only affects the budget Boolean
predicate; response manifolds/ordinary contact queries retain their original path.

A direct adversary keeps unguarded SAT gap near .001 m while native accepted depth
grows from approximately .159 to .169 m. A SAT-gap-only shortcut would be wrong.
Dense-time controls falsify implementation errors; they do not replace the bound.
All 8,192 point-query rows and 120 corrected physical step digests match the
unoptimized corrected version. These claims do not make temporal sampling
universally continuous or resolve arbitrary deep initial overlap.
''')
old=R/'.cache/prealpha-curved-ccd-20261018-source-evidence.tar.gz';assert sha(old)=='6897b1f77ea220eaeba61cbf05e4e5a9c9c4138198ae7881ac71fa34944b10d8';shutil.copyfile(old,D/'prior-prototype-source.tar.gz')
baseline={}
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',parent,'src'])),mode='r:') as base:
 for entry in base:
  if entry.isfile():
   with base.extractfile(entry) as stream:baseline[entry.name[4:]]=hashlib.sha256(stream.read()).hexdigest()
selected=[];inherited=[]
for p in sorted(N.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(N)
 if any(part.startswith('ordinary-box') or part in {'lab-package-original-unavailable','cold-user-data','isolated-user-data','package-user-data'} for part in rel.parts):continue
 if p.suffix.lower() not in {'.cpp','.h','.py','.json','.log','.txt','.patch','.md','.snapshot'}:continue
 parts=rel.parts
 if 'sources' in parts:
  original='/'.join(parts[parts.index('sources')+1:])
  if baseline.get(original)==sha(p):
   inherited.append({'path':rel.as_posix(),'baseline_path':'src/'+original,'sha256':sha(p)});continue
 selected.append(p)
manifest={'schema':1,'parent':parent,'selection':'Research text, copied source, raw receipts and explicit numerical snapshot; no executable/object/archive/package assets or user-data saves','inherited_baseline_files':inherited,'files':[{'path':p.relative_to(N).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected]};payload=(json.dumps(manifest,indent=2)+'\n').encode();archive=D/'continuation-research.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in selected:tar.add(p,arcname=p.relative_to(N).as_posix(),recursive=False)
 info=tarfile.TarInfo('RESEARCH_MANIFEST.json');info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
with tarfile.open(archive,'r:gz') as tar:
 for row in manifest['files']:
  with tar.extractfile(row['path']) as stream:assert hashlib.sha256(stream.read()).hexdigest()==row['sha256']
write('RESEARCH_ARCHIVES.json',{'archives':[{'path':'prior-prototype-source.tar.gz','sha256':sha(D/'prior-prototype-source.tar.gz'),'bytes':old.stat().st_size,'scope':'Exact original unshipped prototype archive'},{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'payload_files':len(selected),'inherited_baseline_files':len(inherited),'payload_bytes':sum(p.stat().st_size for p in selected),'all_payload_hashes_verified':True,'manifest_sha256':hashlib.sha256(payload).hexdigest()}]})
print('research archive',len(selected),'files',archive.stat().st_size,'bytes',flush=True)
