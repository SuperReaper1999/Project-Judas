#pragma once

#include "MeshUnionContinuity.h"
#include <map>
#include <sstream>
#include <unordered_map>

namespace mesh_endpoint_publication {
inline bool SamePosition(glm::vec3 a,glm::vec3 b) {
    for(unsigned k=0;k<3;++k)if(std::memcmp(&a[k],&b[k],sizeof(float)))return false;
    return true;
}
inline bool SameOrientation(const glm::quat& a,const glm::quat& b) {
    return rigid_motion_bounds::SameQuat(a,b);
}

// A position constraint applies one binary32 addition of its exact computed
// delta. Parameterize that actual operation by elapsed float u in [0,1]. The
// existing finite native certificate then covers every represented interior
// point, with the same 1024-interval/depth-40 policy used for physical drift.
// An adapter arithmetic mismatch is uncertainty, never an endpoint grant.
inline episode_probe::UnionMeasurement TraceTranslation(
    const PrimitivePose& before,const PrimitivePose& mesh,const MeshContactEpisode& old,
    glm::vec3 appliedDelta,const glm::vec3& actualPosition,const glm::quat& actualOrientation) {
    episode_probe::UnionMeasurement uncertain;
    if((before.shape.type!=ShapeType::Box&&before.shape.type!=ShapeType::ConvexHull)||
       mesh.shape.type!=ShapeType::TriangleMesh||!mesh.shape.asset||mesh.shape.asset->twoSided||
       !SameOrientation(before.parentOrientation,actualOrientation))return uncertain;
    RigidMotionSegment segment;
    segment.begin=0;segment.end=1;segment.inverseMass=1;
    segment.position=before.parentPosition;segment.orientation=before.parentOrientation;
    segment.linearVelocity=appliedDelta;segment.angularVelocity=glm::vec3(0);
    segment.driftAngularVelocity=glm::vec3(0);segment.prescribed=false;
    const auto beginning=segment.EvaluateGeometry(0),ending=segment.EvaluateGeometry(1);
    if(!SamePosition(beginning.position,before.parentPosition)||
       !SameOrientation(beginning.orientation,before.parentOrientation)||
       !SamePosition(ending.position,actualPosition)||
       !SameOrientation(ending.orientation,actualOrientation))return uncertain;
    segment.endPosition=actualPosition;segment.endOrientation=actualOrientation;
    // A native-complete endpoint needs no historical side selection: every
    // finite overlap there is front-facing, or no finite overlap exists. This
    // is the same independent endpoint acquisition used by EpisodeForTime.
    // A single native witness is insufficient; the all-finite test must pass.
    auto endpoint=before;
    endpoint.parentPosition=actualPosition;endpoint.parentOrientation=actualOrientation;
    MeshFiniteQuery prepared(endpoint,mesh);
    if(prepared.UsesNativeSelection()){
        episode_probe::UnionMeasurement complete;
        complete.measure.result=episode_probe::Result::Connected;
        complete.selected.fronts=prepared.ContactFeatures(nullptr);
        return complete;
    }
    // Any behind finite overlap retains the original chronological proof,
    // including finite absence, rear return and disconnected-component expiry.
    return episode_probe::ReacquireUnion(before,mesh,old,segment,0,1);
}

// The live drift-end records remain present while the pending copy advances.
// Mutation APIs may retire them during coupling finish. A record token check
// prevents the pending copy from resurrecting a retired/reacquired lifetime.
template<class World>
class Pending {
    using Key=std::array<unsigned,4>;
    using Record=typename World::EpisodeRecord;
    struct Entry {Record record;PrimitivePose first,second;bool valid=true;};
    World& world;
    std::map<Key,Entry> pending;
    std::unordered_map<RigidBody*,std::vector<Key>> byBody;
    unsigned translations=0;
public:
    explicit Pending(World& value):world(value) {
        for(const auto& item:world.meshEpisodes) {
            const auto& key=item.first;
            if(!world.MeshEpisodeRecordValid(key[0],key[1],int(key[2]),int(key[3]),item.second))continue;
            auto first=PrimitiveAt(world.bodies[key[0]].shape,world.bodies[key[0]].rigidBody,int(key[2]));
            auto second=PrimitiveAt(world.bodies[key[1]].shape,world.bodies[key[1]].rigidBody,int(key[3]));
            pending.emplace(key,Entry{item.second,std::move(first),std::move(second),true});
            byBody[&world.bodies[key[0]].rigidBody].push_back(key);
            byBody[&world.bodies[key[1]].rigidBody].push_back(key);
        }
    }
    bool Empty()const{return pending.empty();}
    static void Observe(void* context,RigidBody& body,const glm::vec3& previous,
                        const glm::quat& orientation,const glm::vec3& delta) {
        static_cast<Pending*>(context)->Translation(body,previous,orientation,delta);
    }
    void Translation(RigidBody& body,const glm::vec3& previous,
                     const glm::quat& orientation,const glm::vec3& delta) {
        ++translations;
        const auto incident=byBody.find(&body);if(incident==byBody.end())return;
        for(const auto& key:incident->second) {
            auto& entry=pending.at(key);
            if(!entry.valid)continue;
            if(!world.MeshEpisodeRecordValid(key[0],key[1],int(key[2]),int(key[3]),entry.record)) {
                entry.valid=false;continue;
            }
            const bool firstMesh=entry.first.shape.type==ShapeType::TriangleMesh;
            const auto actor=firstMesh?key[1]:key[0];
            // The certified helper handles a moving convex and a stationary
            // mesh. Dynamic concave bodies cannot enter this interface.
            if(&world.bodies[actor].rigidBody!=&body)
                throw std::runtime_error("mesh endpoint static boundary moved during positional solve");
            auto& query=firstMesh?entry.second:entry.first;
            const auto& mesh=firstMesh?entry.first:entry.second;
            if(!SamePosition(query.parentPosition,previous)||!SameOrientation(query.parentOrientation,orientation))
                throw std::runtime_error("mesh endpoint correction path lost its actual anchor");
            const auto result=TraceTranslation(query,mesh,entry.record.episode,delta,body.position,body.orientation);
            ++world.unionQueries;world.unionIntervals+=result.measure.intervals;
            world.unionCertificates+=result.measure.pointCertificates+result.measure.constantCertificates;
            world.unionReacquisitionSearches+=result.reacquisitionSearches;
            world.unionReacquisitionWitnesses+=result.reacquisitionWitnesses;
            if(result.measure.result==episode_probe::Result::Uncertain) {
                ++world.unionUncertain;
                std::ostringstream message;
                message<<"mesh endpoint translation uncertified within bounded policy: pair="
                       <<key[0]<<','<<key[1]<<" correction="<<translations
                       <<" intervals="<<result.measure.intervals;
                throw std::runtime_error(message.str());
            }
            // Keep an empty selected state so a later actual correction can
            // reacquire an ordinary finite front witness. It cannot inherit
            // ownership through a finite exit/rear reentry between corrections.
            entry.record.episode=result.selected;
            query.parentPosition=body.position;query.parentOrientation=body.orientation;
        }
    }
    void Commit() {
        // Validate every pending endpoint before publishing any of them.
        // Transform API changes must retire ownership through the lifecycle
        // interface. A preserved lifetime with unobserved motion is explicit
        // uncertainty; aggregate pre/post motion is not invented here.
        std::map<Key,MeshContactEpisode> ready;
        for(const auto& item:pending) {
            const auto& key=item.first;const auto& entry=item.second;
            if(!entry.valid||!world.MeshEpisodeRecordValid(key[0],key[1],int(key[2]),int(key[3]),entry.record))continue;
            const auto first=PrimitiveAt(world.bodies[key[0]].shape,world.bodies[key[0]].rigidBody,int(key[2]));
            const auto second=PrimitiveAt(world.bodies[key[1]].shape,world.bodies[key[1]].rigidBody,int(key[3]));
            if(!SamePosition(first.parentPosition,entry.first.parentPosition)||
               !SameOrientation(first.parentOrientation,entry.first.parentOrientation)||
               !SamePosition(second.parentPosition,entry.second.parentPosition)||
               !SameOrientation(second.parentOrientation,entry.second.parentOrientation))
                throw std::runtime_error("mesh completed endpoint changed outside certified correction path");
            const bool firstMesh=first.shape.type==ShapeType::TriangleMesh;
            auto actual=MeshContactFeatures(firstMesh?second:first,firstMesh?first:second,&entry.record.episode);
            ready.emplace(key,MeshContactEpisode{std::move(actual)});
        }
        for(auto& item:ready) {
            const auto& key=item.first;
            world.SetMeshEpisode(key[0],key[1],int(key[2]),int(key[3]),pending.at(key).record.asset,
                                 std::move(item.second),0);
        }
        world.episodeDerived.clear();world.meshFrontCertificates.clear();
    }
};
} // namespace mesh_endpoint_publication
