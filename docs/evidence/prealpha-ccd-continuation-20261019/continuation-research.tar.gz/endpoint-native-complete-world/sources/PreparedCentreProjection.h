#pragma once
// Exact factorization of RigidMotionBounds::TryRelativeCentreProjection.
// One call owns the axis-independent rounded delta intervals; no external
// pointer, trajectory, asset or policy is retained.
#include "RigidMotionBounds.h"
#include <array>
namespace front_projection_preparation {
using rigid_motion_bounds::Iv;
struct Prepared {
    std::array<Iv,3> delta{};
    std::optional<Iv> Project(const glm::dvec3&axis) const {
        for(int k=0;k<3;++k)if(!std::isfinite(axis[k]))return std::nullopt;
        try{
            Iv projected(0);
            for(int k=0;k<3;++k)projected=projected+delta[k]*Iv(axis[k]);
            if(!std::isfinite(projected.lo)||!std::isfinite(projected.hi))return std::nullopt;
            return projected;
        }catch(const contact_geometry::ArithmeticFailure&){return std::nullopt;}
    }
};
inline std::optional<Prepared> Prepare(const RigidMotionSegment* a,const RigidMotionSegment* b,
        const RigidBody& fromA,const RigidBody& fromB,double start,double finish){
    using rigid_motion_bounds::Finite3;using rigid_motion_bounds::FloatRoundingBound;
    if(!std::isfinite(start)||!std::isfinite(finish)||start>finish)return std::nullopt;
    for(const auto* segment:{a,b})if(segment&&(start<segment->begin||finish>segment->end||
        !std::isfinite(segment->begin)||!std::isfinite(segment->end)||!Finite3(segment->position)||
        !Finite3(segment->linearVelocity)||(!segment->prescribed&&!(segment->inverseMass>0))))return std::nullopt;
    try{
        const Iv span=Iv(finish)-Iv(start);Prepared result;
        for(int k=0;k<3;++k){
            struct Drift {Iv base,velocity,error;};
            auto drift=[&](const RigidMotionSegment* segment,const RigidBody& from){
                if(!segment)return Drift{Iv(double(from.position[k])),Iv(0),Iv(0)};
                const double velocity=segment->linearVelocity[k];
                const Iv elapsed=Iv(start)-Iv(segment->begin);
                const double maximumElapsed=std::max(std::abs(start-segment->begin),std::abs(finish-segment->begin));
                const double doubleMagnitude=std::max({std::abs(start),std::abs(finish),std::abs(segment->begin)});
                const double doubleError=std::nextafter(doubleMagnitude,std::numeric_limits<double>::infinity())-doubleMagnitude;
                const Iv timeError=Iv(doubleError)+Iv(FloatRoundingBound(maximumElapsed+doubleError));
                const double roundedElapsed=double(std::nextafter(float(maximumElapsed+doubleError),std::numeric_limits<float>::infinity()));
                const double product=std::abs(velocity)*roundedElapsed;
                const Iv error=Iv(std::abs(velocity))*timeError+Iv(FloatRoundingBound(product))+
                    Iv(FloatRoundingBound(std::abs(double(segment->position[k]))+product));
                return Drift{Iv(double(segment->position[k]))+Iv(velocity)*elapsed,Iv(velocity),error};
            };
            const auto first=drift(a,fromA),second=drift(b,fromB);
            const Iv error=first.error+second.error;
            result.delta[k]=first.base-second.base+(first.velocity-second.velocity)*Iv(0,span.hi)+Iv(-error.hi,error.hi);
        }
        return result;
    }catch(const contact_geometry::ArithmeticFailure&){return std::nullopt;}
}
}
