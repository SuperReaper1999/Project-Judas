#include "WorldInternal.h"
#include "PreparedCentreProjection.h"

using namespace JudasPhysicsDetail;

const MeshTopologyPreparation *PhysicsWorld::Impl::MeshTopology(
    const std::shared_ptr<const CollisionAsset> &asset) {
    if (!meshTopologyPreparation || !meshTopologyPreparation->Matches(asset))
        meshTopologyPreparation = std::make_unique<MeshTopologyPreparation>(asset);
    return meshTopologyPreparation.get();
}

bool PhysicsWorld::Impl::MeshPair(unsigned a, unsigned b, int pa, int pb) const {
    if (a == b || a >= bodies.size() || b >= bodies.size() || !bodies[a].alive ||
        !bodies[b].alive || pa < 0 || pb < 0 || pa >= PrimitiveCount(bodies[a].shape) ||
        pb >= PrimitiveCount(bodies[b].shape))
        return false;
    const auto type = [](const Shape &shape, int part) {
        return shape.type == ShapeType::CompoundBoxes ? shape.boxes[std::size_t(part)].type
                                                     : shape.type;
    };
    const auto first = type(bodies[a].shape, pa), second = type(bodies[b].shape, pb);
    const auto poly = [](ShapeType t) {
        return t == ShapeType::Box || t == ShapeType::ConvexHull;
    };
    const auto asset = [](const Shape &shape, int part) {
        return shape.type == ShapeType::CompoundBoxes ? shape.boxes[std::size_t(part)].asset.get()
                                                     : shape.asset.get();
    };
    return (first == ShapeType::TriangleMesh && !bodies[a].HasMotion() &&
            asset(bodies[a].shape, pa) && !asset(bodies[a].shape, pa)->twoSided && poly(second)) ||
           (second == ShapeType::TriangleMesh && !bodies[b].HasMotion() &&
            asset(bodies[b].shape, pb) && !asset(bodies[b].shape, pb)->twoSided && poly(first));
}

bool PhysicsWorld::Impl::MeshEpisodePermitted(unsigned a, unsigned b, int pa, int pb) const {
    // Sleeping suppresses solver work, never physical side ownership.
    return MeshPair(a, b, pa, pb) && CanCollide(a, b) && !bodies[a].sensor && !bodies[b].sensor &&
           !bodies[a].queryOnly && !bodies[b].queryOnly;
}

bool PhysicsWorld::Impl::RawMeshFrontSafe(unsigned a, unsigned b, int pa, int pb, double start,
                                          double finish) {
        if(!MeshPair(a,b,pa,pb))return false;
        const auto& aa=ImpactPoseAt(a,start);const auto& bb=ImpactPoseAt(b,start);
        const auto first=PrimitiveAt(bodies[a].shape,aa.pose,pa,&*aa.orientation),second=PrimitiveAt(bodies[b].shape,bb.pose,pb,&*bb.orientation);
        const bool firstMesh=first.shape.type==ShapeType::TriangleMesh;const auto& mesh=firstMesh?first:second;
        const auto moving=firstMesh?b:a,stationary=firstMesh?a:b;const auto& body=bodies[moving];
        if(body.shape.type!=ShapeType::Box||body.shape.pivotOffset!=glm::vec3(0)||mesh.shape.asset->twoSided)return false;
        const auto& from=ImpactPoseAt(moving,start).pose;const auto& fixed=ImpactPoseAt(stationary,start).pose;
        const RigidMotionSegment* segment=nullptr;
        for(const auto& entry:body.motion.Segments())if(entry.begin<=start&&entry.end>=finish)segment=&entry;
        if(body.HasMotion()&&!segment)return false;
        const auto& bound=RemainingImpactBound(moving,start,finish);const auto rotation=PrimitiveRotation(mesh),inverse=glm::transpose(rotation);const auto origin=PrimitiveCenter(mesh);
        glm::dvec3 lo(INFINITY),hi(-INFINITY);
        for(unsigned corner=0;corner<8;++corner){const glm::dvec3 world(corner&1?bound.max.x:bound.min.x,corner&2?bound.max.y:bound.min.y,corner&4?bound.max.z:bound.min.z);const auto local=inverse*(world-origin);lo=glm::min(lo,local);hi=glm::max(hi,local);}
        for(unsigned k=0;k<3;++k){lo[k]=std::nextafter(lo[k],-INFINITY);hi[k]=std::nextafter(hi[k],INFINITY);}
        std::vector<uint32_t> candidates;mesh.shape.asset->Candidates(lo,hi,candidates);
        const auto offset=origin-glm::dvec3(fixed.position);
        using contact_geometry::Iv;
        // Empty candidates retain the original vacuous proof, including when
        // a centre bound would be unavailable. Otherwise prepare the exact
        // same axis-independent rounded centre intervals once for this call.
        if(candidates.empty())return true;
        const auto centre=front_projection_preparation::Prepare(segment,nullptr,from,fixed,start,finish);if(!centre)return false;
        const double centreDistance=glm::length(glm::dvec3(from.position)-glm::dvec3(fixed.position));
        for(const auto feature:candidates){const auto& face=mesh.shape.asset->faces[feature];const auto normal=rotation*face.normal;
            const auto center=centre->Project(normal);if(!center)return false;
            const auto vertex=offset+rotation*mesh.shape.asset->vertices[face.vertices[0]];Iv plane(0);for(unsigned k=0;k<3;++k)plane=plane+Iv(vertex[k])*Iv(normal[k]);
            const double guard=1e-10*(1+glm::length(vertex)+centreDistance);
            if(center->lo-plane.hi<=guard)return false;
        }
        return true;
    }

bool PhysicsWorld::Impl::MeshEpisodeRecordValid(unsigned a, unsigned b, int pa, int pb,
                                                const EpisodeRecord &e) const {
    if (a > b) {
        std::swap(a, b);
        std::swap(pa, pb);
    }
    if (!MeshEpisodePermitted(a, b, pa, pb) || !e.lifetime)
        return false;
    const auto live = meshEpisodes.find({a, b, unsigned(pa), unsigned(pb)});
    if (live == meshEpisodes.end() || live->second.lifetime != e.lifetime)
        return false;
    const auto first = PrimitiveAt(bodies[a].shape, bodies[a].rigidBody, pa),
               second = PrimitiveAt(bodies[b].shape, bodies[b].rigidBody, pb);
    const auto asset = first.shape.type == ShapeType::TriangleMesh ? first.shape.asset.get()
                                                                 : second.shape.asset.get();
    return e.key.SameBodies(ContactKey{a, b, bodies[a].generation, bodies[b].generation, pa, pb}) &&
           e.ownershipRevisionA == bodies[a].meshOwnershipRevision &&
           e.ownershipRevisionB == bodies[b].meshOwnershipRevision && e.asset == asset;
}

void PhysicsWorld::Impl::SetMeshEpisode(unsigned a, unsigned b, int pa, int pb,
                                       const CollisionAsset *asset, MeshContactEpisode episode,
                                       double time) {
    if (a > b) {
        std::swap(a, b);
        std::swap(pa, pb);
    }
    const std::array<unsigned, 4> key{a, b, unsigned(pa), unsigned(pb)};
    if (episode.fronts.empty() || !MeshEpisodePermitted(a, b, pa, pb)) {
        meshEpisodes.erase(key);
        InvalidateMeshEpisodePairProofs(a, b);
        return;
    }
    const auto found = meshEpisodes.find(key);
    uint64_t lifetime = found != meshEpisodes.end() &&
                                MeshEpisodeRecordValid(a, b, pa, pb, found->second)
                            ? found->second.lifetime
                            : 0;
    if (!lifetime) {
        if (nextMeshEpisodeLifetime == std::numeric_limits<uint64_t>::max())
            throw std::overflow_error("finite-mesh lifetime identity exhausted");
        lifetime = ++nextMeshEpisodeLifetime;
    }
    meshEpisodes[key] = {ContactKey{a, b, bodies[a].generation, bodies[b].generation, pa, pb},
                         bodies[a].meshOwnershipRevision, bodies[b].meshOwnershipRevision, asset,
                         std::move(episode), time, lifetime};
    InvalidateMeshEpisodePairProofs(a, b);
}

const MeshContactEpisode *PhysicsWorld::Impl::Episode(unsigned a, unsigned b, int pa,
                                                       int pb) const {
    if (a > b) {
        std::swap(a, b);
        std::swap(pa, pb);
    }
    const auto it = meshEpisodes.find({a, b, unsigned(pa), unsigned(pb)});
    return it != meshEpisodes.end() && MeshEpisodeRecordValid(a, b, pa, pb, it->second)
               ? &it->second.episode
               : nullptr;
}

void PhysicsWorld::Impl::PublishEpisode(unsigned a, unsigned b, int pa, int pb, double time) {
    if (a > b) {
        std::swap(a, b);
        std::swap(pa, pb);
    }
    if (!MeshEpisodePermitted(a, b, pa, pb))
        return;
    const auto &aa = ImpactPoseAt(a, time);
    const auto &bb = ImpactPoseAt(b, time);
    const auto first = PrimitiveAt(bodies[a].shape, aa.pose, pa, &*aa.orientation),
               second = PrimitiveAt(bodies[b].shape, bb.pose, pb, &*bb.orientation);
    const auto &mesh = first.shape.type == ShapeType::TriangleMesh ? first : second;
    const auto &query = first.shape.type == ShapeType::TriangleMesh ? second : first;
    MeshFiniteQuery prepared(query, mesh);
    const auto old = EpisodeForTime(a, b, pa, pb, time, &prepared);
    auto features = prepared.ContactFeatures(old);
    SetMeshEpisode(a, b, pa, pb, mesh.shape.asset.get(), MeshContactEpisode{std::move(features)},
                   time);
    episodeDerived.clear();
}

ContactManifold PhysicsWorld::Impl::EpisodeContacts(
    unsigned a, unsigned b, int pa, int pb, const PrimitivePose &first, const PrimitivePose &second,
    float margin, const ContactPreparedOrientation *aa, const ContactPreparedOrientation *bb,
    double time) {
    return MeshPair(a, b, pa, pb)
               ? EpisodeCookedContacts(first, second, margin,
                                       time < 0 ? Episode(a, b, pa, pb)
                                                : EpisodeForTime(a, b, pa, pb, time))
               : ComputeContacts(first, second, margin, aa, bb);
}

void PhysicsWorld::Impl::InvalidateMeshEpisodeProofs(unsigned slot) {
    for (auto it = episodeDerived.begin(); it != episodeDerived.end();)
        if (std::get<0>(it->first) == slot || std::get<1>(it->first) == slot)
            it = episodeDerived.erase(it);
        else
            ++it;
    for (auto it = meshFrontCertificates.begin(); it != meshFrontCertificates.end();)
        if (it->first[0] == slot || it->first[1] == slot)
            it = meshFrontCertificates.erase(it);
        else
            ++it;
}

void PhysicsWorld::Impl::RetireMeshEpisodes(unsigned slot) {
    if (slot >= bodies.size())
        return;
    ++bodies[slot].meshOwnershipRevision;
    for (auto it = meshEpisodes.begin(); it != meshEpisodes.end();)
        if (it->first[0] == slot || it->first[1] == slot)
            it = meshEpisodes.erase(it);
        else
            ++it;
    InvalidateMeshEpisodeProofs(slot);
}

void PhysicsWorld::Impl::RetireMeshEpisodePair(unsigned a, unsigned b) {
    if (a > b)
        std::swap(a, b);
    for (auto it = meshEpisodes.begin(); it != meshEpisodes.end();)
        if (it->first[0] == a && it->first[1] == b)
            it = meshEpisodes.erase(it);
        else
            ++it;
    InvalidateMeshEpisodePairProofs(a, b);
}

void PhysicsWorld::Impl::InvalidateMeshEpisodePairProofs(unsigned a, unsigned b) {
    if (a > b)
        std::swap(a, b);
    for (auto it = episodeDerived.begin(); it != episodeDerived.end();)
        if (std::get<0>(it->first) == a && std::get<1>(it->first) == b)
            it = episodeDerived.erase(it);
        else
            ++it;
    for (auto it = meshFrontCertificates.begin(); it != meshFrontCertificates.end();)
        if (it->first[0] == a && it->first[1] == b)
            it = meshFrontCertificates.erase(it);
        else
            ++it;
}

void PhysicsWorld::Impl::RetireDisallowedMeshEpisodes(unsigned slot) {
    for (auto it = meshEpisodes.begin(); it != meshEpisodes.end();) {
        const auto &k = it->first;
        if ((k[0] == slot || k[1] == slot) &&
            !MeshEpisodeRecordValid(k[0], k[1], int(k[2]), int(k[3]), it->second))
            it = meshEpisodes.erase(it);
        else
            ++it;
    }
    InvalidateMeshEpisodeProofs(slot);
}

bool PhysicsWorld::Impl::MeshFrontSafe(unsigned a, unsigned b, int pa, int pb, double start,
                                       double finish) {
    const std::array<unsigned, 4> key{a, b, unsigned(pa), unsigned(pb)};
    const auto found = meshFrontCertificates.find(key);
    if (found != meshFrontCertificates.end() &&
        found->second.first == std::make_pair(start, finish))
        return found->second.second;
    const bool safe = RawMeshFrontSafe(a, b, pa, pb, start, finish);
    meshFrontCertificates[key] = {{start, finish}, safe};
    return safe;
}

const MeshContactEpisode *PhysicsWorld::Impl::EpisodeForTime(unsigned a, unsigned b, int pa, int pb,
                                                            double time,
                                                            MeshFiniteQuery *sameEndpoint) {
    if (a > b) {
        std::swap(a, b);
        std::swap(pa, pb);
    }
    const auto front = meshFrontCertificates.find({a, b, unsigned(pa), unsigned(pb)});
    if (front != meshFrontCertificates.end() && front->second.second &&
        front->second.first.first <= time && front->second.first.second >= time)
        return nullptr;
    const auto *previous = Episode(a, b, pa, pb);
    if (!previous || previous->fronts.empty())
        return nullptr;
    const auto identity = std::make_tuple(a, b, pa, pb, time);
    const auto cached = episodeDerived.find(identity);
    // Existing pose/trajectory/publication invalidation also invalidates
    // nativeOnly. A repeated query can use the exact same endpoint decision
    // without rebuilding its native completeness/feature geometry.
    if (cached != episodeDerived.end())
        return cached->second.Sideband();
    const auto &endpointA = ImpactPoseAt(a, time);
    const auto &endpointB = ImpactPoseAt(b, time);
    const auto endpointFirst =
                   PrimitiveAt(bodies[a].shape, endpointA.pose, pa, &*endpointA.orientation),
               endpointSecond =
                   PrimitiveAt(bodies[b].shape, endpointB.pose, pb, &*endpointB.orientation);
    const bool endpointFirstMesh = endpointFirst.shape.type == ShapeType::TriangleMesh;
    // A caller may lend preparation only for these exact represented
    // primitives. The object is never retained in a derived checkpoint.
    std::optional<MeshFiniteQuery> localEndpoint;
    if (!sameEndpoint) {
        localEndpoint.emplace(endpointFirstMesh ? endpointSecond : endpointFirst,
                              endpointFirstMesh ? endpointFirst : endpointSecond);
        sameEndpoint = &*localEndpoint;
    }
    if (sameEndpoint->UsesNativeSelection()) {
        // This actual endpoint needs no historical side: all its finite
        // contacts use the ordinary front rule. It is an independent
        // complete checkpoint for later queries of this anchored path.
        episodeDerived.emplace(
            identity, MeshEpisodeCheckpoint{
                          MeshContactEpisode{sameEndpoint->ContactFeatures(nullptr)}, true});
        return nullptr;
    }
    const auto foundRecord = meshEpisodes.find({a, b, unsigned(pa), unsigned(pb)});
    if (foundRecord == meshEpisodes.end())
        throw std::runtime_error("finite-mesh canonical episode record absent");
    const auto &record = foundRecord->second;
    MeshContactEpisode selected = *previous;
    const auto first = PrimitiveAt(bodies[a].shape, bodies[a].rigidBody, pa),
               second = PrimitiveAt(bodies[b].shape, bodies[b].rigidBody, pb);
    const bool fm = first.shape.type == ShapeType::TriangleMesh;
    const unsigned moving = fm ? b : a;
    const auto &query = fm ? second : first;
    const auto &mesh = fm ? first : second;
    double covered = record.anchorTime;
    // Read only an earlier checkpoint of this same pair and the current
    // still-valid trajectories. Existing publication/invalidation clears
    // the whole derived map whenever an accepted impulse changes a path.
    auto checkpoint = episodeDerived.upper_bound(identity);
    if (checkpoint != episodeDerived.begin()) {
        --checkpoint;
        if (std::get<0>(checkpoint->first) == a && std::get<1>(checkpoint->first) == b &&
            std::get<2>(checkpoint->first) == pa && std::get<3>(checkpoint->first) == pb &&
            std::get<4>(checkpoint->first) >= covered && std::get<4>(checkpoint->first) <= time) {
            selected = checkpoint->second.selected;
            covered = std::get<4>(checkpoint->first);
        }
    }
    if (time < covered)
        throw std::runtime_error("finite-mesh episode query precedes causal anchor");
    for (const auto &segment : bodies[moving].motion.Segments()) {
        if (segment.end <= covered || segment.begin > time)
            continue;
        if (segment.begin > covered)
            throw std::runtime_error("finite-mesh episode trajectory gap");
        const double finish = std::min(time, segment.end);
        if (finish <= covered)
            continue;
        auto result = episode_probe::ReacquireUnion(query, mesh, selected, segment, covered, finish,
                                                    1024, MeshTopology(mesh.shape.asset));
        ++unionQueries;
        unionIntervals += result.measure.intervals;
        unionReacquisitionSearches += result.reacquisitionSearches;
        unionReacquisitionWitnesses += result.reacquisitionWitnesses;
        unionCertificates += result.measure.pointCertificates + result.measure.constantCertificates;
        if (result.measure.result == episode_probe::Result::Uncertain) {
            ++unionUncertain;
            std::ostringstream message;
            message
                << "finite-mesh episode continuity uncertified within bounded policy: pair=" << a
                    << "," << b << " anchor=" << record.anchorTime << " start=" << covered
                    << " finish=" << finish << " intervals=" << result.measure.intervals
                    << " certificates="
                    << (result.measure.pointCertificates + result.measure.constantCertificates)
                    << " features=" << selected.fronts.size();
            throw std::runtime_error(message.str());
        }
        if (result.measure.result == episode_probe::Result::Separated) {
            selected.fronts.clear();
            covered = time;
            break;
        }
        selected = std::move(result.selected);
        covered = finish;
        if (covered == time)
            break;
    }
    if (covered < time && bodies[moving].HasMotion())
        throw std::runtime_error("finite-mesh episode trajectory incomplete");
    auto entry =
        episodeDerived.emplace(identity, MeshEpisodeCheckpoint{std::move(selected), false}).first;
    return entry->second.Sideband();
}

void PhysicsWorld::Impl::BeginMeshEpisodes() {
    episodeDerived.clear();
    meshFrontCertificates.clear();
    for (const auto &pair : candidatePairs)
        for (int pa = 0; pa < PrimitiveCount(bodies[pair.first].shape); ++pa)
            for (int pb = 0; pb < PrimitiveCount(bodies[pair.second].shape); ++pb)
                if (CanRespond(pair.first, pair.second) &&
                    MeshPair(pair.first, pair.second, pa, pb)) {
                    const auto &a = bodies[pair.first];
                    const auto &b = bodies[pair.second];
                    auto first = PrimitiveAt(a.shape, a.rigidBody, pa),
                         second = PrimitiveAt(b.shape, b.rigidBody, pb);
                    const bool fm = first.shape.type == ShapeType::TriangleMesh;
                    MeshFiniteQuery prepared(fm ? second : first, fm ? first : second);
                    auto features =
                        prepared.ContactFeatures(Episode(pair.first, pair.second, pa, pb));
                    SetMeshEpisode(pair.first, pair.second, pa, pb,
                                   (fm ? first : second).shape.asset.get(),
                                   MeshContactEpisode{std::move(features)}, 0);
                }
}

void PhysicsWorld::Impl::FinishMeshEpisodes(double dt) {
    std::vector<std::array<unsigned, 4>> keys;
    for (const auto &e : meshEpisodes)
        keys.push_back(e.first);
    for (const auto &key : keys) {
        if (!MeshEpisodeRecordValid(key[0], key[1], int(key[2]), int(key[3]),
                                    meshEpisodes.at(key))) {
            meshEpisodes.erase(key);
            continue;
        }
        const auto first = PrimitiveAt(bodies[key[0]].shape, bodies[key[0]].rigidBody, key[2]),
                   second = PrimitiveAt(bodies[key[1]].shape, bodies[key[1]].rigidBody, key[3]);
        const bool fm = first.shape.type == ShapeType::TriangleMesh;
        MeshFiniteQuery prepared(fm ? second : first, fm ? first : second);
        const auto &sampledA = ImpactPoseAt(key[0], dt);
        const auto &sampledB = ImpactPoseAt(key[1], dt);
        // The ledger and current rigid pose are distinct authorities after
        // any correction. Share only when both represented parent poses
        // match exactly; never substitute one endpoint for the other.
        const bool same = SamePosition(sampledA.pose.position, bodies[key[0]].rigidBody.position) &&
                          SameRotation(sampledA.pose.orientation,
                                       bodies[key[0]].rigidBody.orientation) &&
                          SamePosition(sampledB.pose.position, bodies[key[1]].rigidBody.position) &&
                          SameRotation(sampledB.pose.orientation,
                                       bodies[key[1]].rigidBody.orientation);
        auto episode =
            EpisodeForTime(key[0], key[1], key[2], key[3], dt, same ? &prepared : nullptr);
        auto features = prepared.ContactFeatures(episode);
        if (features.empty())
            meshEpisodes.erase(key);
        else {
            auto &e = meshEpisodes.at(key);
            e.episode.fronts = std::move(features);
            e.anchorTime = 0;
        }
    }
    episodeDerived.clear();
    meshFrontCertificates.clear();
}
