// Prepared only. Root owns compile/execution. The original 193 checks below are
// included byte-for-byte and run before added native-completeness controls.
#define main OriginalEndpointTranslationControlsMain
#include "support/OriginalEndpointTranslationControlsStandalone.cpp"
#undef main

namespace {
std::shared_ptr<CollisionAsset> TwoPlanes(){
    MeshData source;
    for(float y:{0.f,.04f})for(glm::vec3 p:{glm::vec3(-.25f,y,-.25f),glm::vec3(0,y,.25f),glm::vec3(.25f,y,-.25f)}){
        MeshVertex v;v.position=p;source.vertices.push_back(v);
    }
    source.indices={0,1,2,3,4,5};auto asset=std::make_shared<CollisionAsset>();
    CollisionCookSettings settings;std::string error;
    if(!CookCollision(source,settings,*asset,error))throw std::runtime_error(error);return asset;
}
episode_probe::UnionMeasurement Move(PrimitivePose&query,const PrimitivePose&mesh,
                                    MeshContactEpisode old,glm::vec3 delta){
    const auto end=query.parentPosition+delta;
    const auto result=mesh_endpoint_publication::TraceTranslation(query,mesh,old,delta,end,query.parentOrientation);
    query.parentPosition=end;return result;
}
}
int main(){
    const int original=OriginalEndpointTranslationControlsMain();
    Check(original==0,"unchanged original endpoint controls pass");
    try{
        const auto asset=Sheet();PrimitivePose mesh;mesh.shape=Shape::Cooked(asset,"native complete endpoint");
        PrimitivePose q;q.shape=Shape::Box({.1f,.1f,.1f});q.parentPosition={0,.05f,0};
        const auto old=MeshContactFeatures(q,mesh,nullptr);
        auto result=Move(q,mesh,MeshContactEpisode{}, {.01f,0,0});
        Check(result.measure.result==episode_probe::Result::Connected&&result.measure.intervals==0,
              "all-front finite endpoint acquires independently with no interval ancestry");
        Check(result.selected.fronts==MeshContactFeatures(q,mesh,nullptr)&&!result.selected.fronts.empty(),
              "independent endpoint selection equals actual native accepted witnesses");
        result=Move(q,mesh,MeshContactEpisode{old},{0,.3f,0});
        Check(result.measure.result==episode_probe::Result::Connected&&result.measure.intervals==0&&result.selected.fronts.empty(),
              "native-complete empty endpoint retires selected state");
        q.parentPosition={0,-.02f,0};result=Move(q,mesh,MeshContactEpisode{{0}},{1,0,0});
        Check(result.measure.intervals==0&&result.selected.fronts.empty(),
              "actual finite exit retires prior behind selection through empty endpoint fastpath");
        result=Move(q,mesh,result.selected,{-1,0,0});
        Check(!MeshFiniteComponent(q,mesh,{},true).empty()&&!MeshFiniteQuery(q,mesh).UsesNativeSelection(),
              "rear-return endpoint has genuine behind finite overlap and is not native-complete");
        Check(result.measure.result==episode_probe::Result::Connected&&result.measure.intervals>0&&result.selected.fronts.empty(),
              "rear return uses chronological fallback and cannot resurrect ownership after finite gap");
        PrimitivePose mixed;mixed.shape=Shape::Cooked(TwoPlanes(),"mixed front and behind finite components");
        q.parentPosition={0,.02f,0};
        Check(!MeshContactFeatures(q,mixed,nullptr).empty(),"mixed control really has a native front witness");
        Check(MeshFiniteComponent(q,mixed,{},true).size()==2&&!MeshFiniteQuery(q,mixed).UsesNativeSelection(),
              "native front witness cannot hide another behind finite overlap");
        result=Move(q,mixed,MeshContactEpisode{},{});
        Check(result.measure.result==episode_probe::Result::Connected&&result.measure.intervals>0&&result.selected.fronts==std::vector<uint32_t>{0},
              "mixed endpoint retains per-component chronological fallback and no rear acquisition");
        q.parentPosition={0,.05f,0};
        const auto malformed=mesh_endpoint_publication::TraceTranslation(q,mesh,MeshContactEpisode{old},{.01f,0,0},q.parentPosition,q.parentOrientation);
        Check(malformed.measure.result==episode_probe::Result::Uncertain,
              "front-complete actual endpoint cannot bypass adapter arithmetic mismatch");
        const auto rotated=mesh_endpoint_publication::TraceTranslation(q,mesh,MeshContactEpisode{old},{},q.parentPosition,glm::angleAxis(.1f,glm::vec3(0,1,0)));
        Check(rotated.measure.result==episode_probe::Result::Uncertain,
              "front-complete endpoint cannot bypass unsupported rotation in translation adapter");
    }catch(const std::exception&e){std::cerr<<"NATIVE_ENDPOINT_ERROR "<<e.what()<<'\n';Check(false,"native endpoint controls complete");}
    std::cout<<"NATIVE_ENDPOINT_CONTROLS checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
