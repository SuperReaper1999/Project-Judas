// Prepared only. Root owns compilation/execution. Compile with -fno-access-control
// against this EXACT private Impl snapshot. These source controls do not replace
// unchanged full physical/lifecycle/trajectory gates.
#define main PreservedImpactMeshCostMain
#include "ImpactMeshCostTests.cpp"
#undef main
#include "physics/WorldInternal.h"

namespace {
struct FrontFixture {
    PhysicsWorld world;std::shared_ptr<CollisionAsset> asset=Sheet(6,6,false);BodyHandle ground,actor;
    std::array<unsigned,4> key{};double end=1./60;
    FrontFixture(){
        world.Init();world.SetSleepingEnabled(false);
        ground=world.CreateShape(Shape::Cooked(asset,"front certificate control"),{},false,1,.6f,0);
        actor=world.CreateDynamicBox({.11f,.008f,-.17f},{.02f,.01f,.03f},.2f,.4f,0);
        key={ground.id&PhysicsWorld::Impl::kSlotMask,actor.id&PhysicsWorld::Impl::kSlotMask,0,0};
        Anchor();
    }
    PhysicsWorld::Impl&Impl(){return *world.m_impl;}
    unsigned ActorSlot(){return actor.id&PhysicsWorld::Impl::kSlotMask;}
    void Anchor(){auto&w=Impl();w.bodies[ActorSlot()].motion.Begin(actor.id,w.bodies[ActorSlot()].rigidBody,end);w.InvalidateImpactPose(ActorSlot());}
    bool Safe(double first,double last){return Impl().MeshFrontSafe(key[0],key[1],0,0,first,last);}
    bool Raw(double first,double last){return Impl().RawMeshFrontSafe(key[0],key[1],0,0,first,last);}
    void Positive(){Check(Raw(0,end)&&Safe(0,end),"front interval is actually positively certified");Check(!Impl().meshFrontCertificates.empty(),"positive proof stored");}
    void Empty(){Check(Impl().meshFrontCertificates.empty(),"real context change invalidates front proof");}
};
template<class Function>void Case(const char*name,Function function){
    try{FrontFixture f;function(f);}catch(const std::exception&e){std::cerr<<"FRONT_CERT_THROW case="<<name<<" error="<<e.what()<<'\n';Check(false,"front certificate control completes");}
}
}
int main(){
    Case("positive_restriction",[](FrontFixture&f){
        f.Positive();const auto before=f.Impl().meshFrontCertificates.at(f.key);
        Check(f.Raw(.003,.009),"uncached contained interval is also front safe");
        Check(f.Safe(.003,.009),"positive outer proof serves contained interval");
        Check(f.Impl().meshFrontCertificates.at(f.key)==before,"restriction preserves enclosing interval instead of replacing it");
        Check(f.Safe(.009,.009),"positive proof serves contained point interval");
    });
    Case("negative_not_restricted",[](FrontFixture&f){
        f.world.SetLinearVelocity(f.actor,{0,-1,0});f.Anchor();
        Check(!f.Raw(0,f.end)&&!f.Safe(0,f.end),"whole interval cannot prove a path whose centre crosses behind");
        Check(f.Raw(0,.001),"front prefix has its own positive proof");
        Check(f.Safe(0,.001),"negative enclosing result does not suppress positive subinterval search");
        Check(f.Impl().meshFrontCertificates.at(f.key).second,"new positive prefix replaces unsuccessful broad proof");
    });
    Case("velocity",[](FrontFixture&f){f.Positive();f.world.SetLinearVelocity(f.actor,{0,-1,0});f.Empty();f.Anchor();Check(!f.Safe(0,f.end),"new crossing velocity cannot reuse old positive path proof");});
    Case("angular_velocity",[](FrontFixture&f){f.Positive();f.world.SetAngularVelocity(f.actor,{0,0,900});f.Empty();f.Anchor();Check(f.Safe(0,f.end)==f.Raw(0,f.end),"new angular path is independently certified");});
    Case("pose",[](FrontFixture&f){f.Positive();f.world.ResetBody(f.actor,{.11f,-.008f,-.17f},{1,0,0,0});f.Empty();f.Anchor();Check(!f.Safe(0,f.end),"new rear centre cannot reuse front pose proof");});
    Case("mesh_pose",[](FrontFixture&f){f.Positive();f.world.ResetBody(f.ground,{0,.01f,0},{1,0,0,0});f.Empty();f.Anchor();Check(!f.Safe(0,f.end),"translated mesh plane cannot reuse prior proof");});
    Case("filter",[](FrontFixture&f){f.Positive();Check(f.world.SetCollisionFilter(f.actor,0,0),"filter mutation accepted");f.Empty();Check(!f.Impl().CanCollide(f.key[0],f.key[1]),"disallowed pair remains rejected by current policy");});
    Case("pair_filter",[](FrontFixture&f){f.Positive();Check(f.world.SetPairCollisionEnabled(f.actor,f.ground,false),"pair suppression accepted");f.Empty();Check(!f.Impl().CanCollide(f.key[0],f.key[1]),"suppressed pair remains rejected by current policy");});
    Case("origin",[](FrontFixture&f){f.Positive();f.world.ShiftOrigin({.125,.5,-.25});f.Empty();Check(f.Safe(0,f.end)==f.Raw(0,f.end),"origin-shifted native arithmetic receives a fresh proof");});
    Case("asset",[](FrontFixture&f){f.Positive();Check(f.world.ReplaceStaticCollision(f.ground,Sheet(2,26,true)),"mesh asset replacement accepted");f.Empty();Check(f.Safe(0,f.end)==f.Raw(0,f.end),"new finite mesh topology receives a fresh proof");});
    std::cout<<"FRONT_CERTIFICATE_CONTROLS checks="<<checks<<" failures="<<failures<<'\n';return failures?1:0;
}
