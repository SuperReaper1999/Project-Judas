#include "PhysicsWorld.h"
#include "SaveArchive.h"
#include <cstdio>
#include <functional>
#include <stdexcept>
#include <string>

namespace {
int checks=0,failures=0;
void Check(bool value,const char* label){++checks;failures+=!value;std::printf("%s %s\n",value?"PASS":"FAIL",label);}
bool Throws(const std::function<void()>& call){try{call();return false;}catch(...){return true;}}
BodyHandle Actor(PhysicsWorld& world){world.Init();world.SetSleepingEnabled(false);auto actor=world.CreateDynamicBox({0,2,0},{.1f,.1f,.1f},1,.5f,0);world.SetLinearVelocity(actor,{1,-2,0});return actor;}
}
int main(){
    constexpr float dt=1.f/60;
    {
        PhysicsWorld world;const auto actor=Actor(world);
        PhysicsWorld::VelocityCoupling invalid;invalid.iterations=0;
        Check(Throws([&]{world.Step(dt,&invalid);})&&!world.HasFailedStep(),"invalid coupling rejected before mutation does not poison");
        Check(Throws([&]{world.StepCoupled(dt,0,{},{});})&&!world.HasFailedStep(),"invalid macro interval rejected before mutation does not poison");
        Check(!Throws([&]{world.Step(dt);})&&!world.HasFailedStep()&&world.GetTransform(actor).position.x>0,"preflight rejection permits one normal step");
    }
    {
        PhysicsWorld world;const auto actor=Actor(world);const auto start=world.GetTransform(actor).position;
        world.ApplyForce(actor,{2,3,4});world.ApplyTorque(actor,{.2f,.3f,.4f});
        PhysicsWorld::VelocityCoupling coupling;int begins=0,solves=0,finishes=0;bool moved=false;
        coupling.begin=[&](float){++begins;};coupling.solve=[&](float,unsigned){++solves;};
        coupling.finish=[&](float){++finishes;moved=world.GetTransform(actor).position!=start;throw std::runtime_error("intentional native finish failure after drift");};
        Check(Throws([&]{world.Step(dt,&coupling);})&&moved&&begins==1&&solves>0&&finishes==1,"real coupling finish throws after actual physical drift");
        Check(world.HasFailedStep()&&world.StepFailureMessage()=="intentional native finish failure after drift","sticky poison retains original failure cause");
        Check(world.GetTransform(actor).position!=start,"containment honestly retains partial physical mutation");
        std::vector<PhysicsWorld::BodyContactSample> samples;
        Check(!world.ReadBodyContactSample(actor,samples),"completed contact samples unavailable on poisoned world");
        const int before=begins;const auto frozen=world.GetTransform(actor).position;
        Check(Throws([&]{world.Step(dt,&coupling);})&&begins==before&&world.GetTransform(actor).position==frozen,"future Step rejects before callbacks or another drift");
        int beforeCalls=0;Check(Throws([&]{world.StepCoupled(dt,1,[&](float,unsigned){++beforeCalls;},{});})&&beforeCalls==0,"future macro call rejects before beforeInterval");
        SaveArchive output;output.bytes="retained caller bytes";
        Check(Throws([&]{world.PersistBodyForces(output,actor);})&&output.bytes=="retained caller bytes","direct force persistence rejects before touching output");
        Check(Throws([&]{world.PersistSleep(output,actor);})&&output.bytes=="retained caller bytes","direct sleep persistence rejects before touching output");
#ifdef JUDAS_TEST_HAS_MESH_CONTACT_PERSISTENCE
        Check(Throws([&]{world.PersistMeshContacts(output,[](BodyHandle h){return uint64_t(h.id);},[](uint64_t){return BodyHandle{};});})&&output.bytes=="retained caller bytes","direct mesh ownership persistence rejects before touching output");
#endif
        world.ResetBody(actor,{10,10,10},{1,0,0,0});world.SetSleepingEnabled(false);
        Check(world.HasFailedStep()&&Throws([&]{world.Step(dt);}),"same-world pose reset and sleep changes do not heal poison");
        world.Shutdown();world.Init();const auto cold=world.CreateDynamicBox({0,2,0},{.1f,.1f,.1f},1,.5f,0);
        world.SetLinearVelocity(cold,{1,0,0});
        Check(!world.HasFailedStep()&&!Throws([&]{world.Step(dt);})&&world.GetTransform(cold).position.x>0,"fresh Impl after complete shutdown/init can step");
    }
    for(unsigned intervals:{1u,3u}){
        PhysicsWorld world;const auto actor=Actor(world);const auto start=world.GetTransform(actor).position;
        unsigned before=0,after=0;
        Check(Throws([&]{world.StepCoupled(dt,intervals,[&](float,unsigned){++before;},[&](float,unsigned i){++after;if(i==intervals-1)throw std::runtime_error("intentional macro publication failure");});}),"afterInterval failure escapes single/multiple interval macro");
        Check(world.HasFailedStep()&&world.GetTransform(actor).position!=start&&before==intervals&&after==intervals,"whole macro is poisoned after real earlier interval work");
        Check(world.StepFailureMessage()=="intentional macro publication failure","outer macro retains original callback cause");
    }
    {
        PhysicsWorld world;const auto actor=Actor(world);
        Check(Throws([&]{world.StepCoupled(dt,1,[&](float,unsigned){world.ApplyForce(actor,{1,0,0});throw std::runtime_error("intentional before failure");},{});})&&world.HasFailedStep(),"single interval before callback is covered by outer failure guard");
    }
    std::printf("SUMMARY %d checks %d failures\n",checks,failures);return failures?1:0;
}
