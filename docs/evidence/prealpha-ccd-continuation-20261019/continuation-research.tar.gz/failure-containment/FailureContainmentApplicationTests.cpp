// Link with -Wl,--wrap=_ZN12PhysicsWorld4StepEf. Injection uses a genuine native
// finish callback after drift. Only a disposable copy of events.js is replaced
// to provide observable per-phase counters; original assets/physics are intact.
#include "Application.h"
#include "EngineHost.h"
#include "InteractivePlay.h"
#include "RuntimeWorld.h"
#include "SceneSession.h"
#include "WorldPersistence.h"
#include "WorldState.h"
#include "SaveArchive.h"
#include "../third_party/nlohmann/json.hpp"
#include <SDL2/SDL.h>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>

namespace {
using J=nlohmann::json;
int checks=0,failures=0;bool inject=false,moved=false;BodyHandle actor;PhysicsWorld* physics=nullptr;
void Check(bool value,const char* label){++checks;failures+=!value;std::printf("%s %s\n",value?"PASS":"FAIL",label);}
J Counts(RuntimeWorld& world){
    J result;
    if(world.Scripts())for(const auto& r:world.Scripts()->Capture())if(r.entity==4){
        auto value=J::parse(r.json);
        if(value.value("containmentFixture",false))return value;
    }
    return result;
}
int Count(const J& value,const char* field){return value.is_object()?value.value(field,-1000000):-1000000;}
void DirectPhases(RuntimeWorld& world,InputSystem& input){
    world.UpdateScripts(&input,.1f);world.FixedScripts(&input,.1f);
    world.UpdateUIScripts(&input,.1f);world.PresentationScripts(&input,.1f,.5f);
    world.DispatchFractureEvents();
    auto& scripts=world.PrepareScriptTools();
    scripts.Frame(&input,.1f);scripts.Fixed(&input,.1f);scripts.UIFrame(&input,.1f);
    scripts.Presentation(&input,.1f,.5f);
    scripts.FractureEvent(4,1,{"explicit-interface"},{0});
    PhysicsWorld::TouchEvent event;event.a=world.RuntimeBody(4);event.b=world.RuntimeBody(1);
    event.phase=PhysicsWorld::TouchPhase::Enter;event.sensor=false;
    scripts.PhysicsEvent(4,1,event,false);
    scripts.ShiftOrigin({0,0,0});
    scripts.DrainSignals(&input,.1f,false);
}
const char* counterSource=R"JS(import {signals} from 'judas';
export const properties={speed:{type:'number',default:0},patrol:{type:'boolean',default:false}};
export default class {
 constructor({entity}){this.entity=entity;this.state={containmentFixture:true,start:0,update:0,fixed:0,ui:0,presentation:0,fracture:0,collision:0,origin:0,signal:0};}
 start(){this.state.start++;this.subscription=signals.subscribe('containment-probe');}
 update(){this.state.update++;signals.emit('containment-probe');}
 fixedUpdate(){this.state.fixed++;}
 uiUpdate(){this.state.ui++;}
 presentationUpdate(){this.state.presentation++;}
 onFracture(){this.state.fracture++;}
 onCollisionEnter(){this.state.collision++;}
 onOriginShift(){this.state.origin++;}
 onSignal(){this.state.signal++;}
}
)JS";
}
extern "C" void __real__ZN12PhysicsWorld4StepEf(PhysicsWorld*,float);
extern "C" void __wrap__ZN12PhysicsWorld4StepEf(PhysicsWorld* self,float dt){
    if(!inject||self!=physics){__real__ZN12PhysicsWorld4StepEf(self,dt);return;}
    inject=false;const auto start=self->GetTransform(actor).position;
    PhysicsWorld::VelocityCoupling coupling;
    coupling.finish=[&](float){moved=self->GetTransform(actor).position!=start;throw std::runtime_error("application native finish failure after physical drift");};
    self->Step(dt,&coupling);
}
int main(){
    namespace fs=std::filesystem;
    const auto fixture=fs::absolute(".cache/prealpha-ccd-continuation/failure-containment/app-fixture");
    fs::remove_all(fixture);fs::copy("projects/scene_demo",fixture,fs::copy_options::recursive);
    std::ofstream(fixture/"Assets/scripts/events.js")<<counterSource;
    std::string project=(fixture/"scene_demo.judasproj").string();
    ApplicationControl control;control.hidden=true;control.frameSeconds=[](float){return 1.f/60;};
    control.hostReady=[](EngineHost& host){std::string error;host.Audio().Init(error,true);};
    unsigned frames=0,observed=0;bool requested=false,recovered=false;
    const RuntimeWorld* failedWorld=nullptr;J heldState,beforeFailure;double completedTime=0;
    control.worldReady=[&](EngineHost&,RuntimeWorld& world,InteractivePlay&){
        physics=&world.Physics();actor=physics->CreateDynamicBox({20,20,20},{.1f,.1f,.1f},1,.5f,0);
        physics->SetLinearVelocity(actor,{1,-2,0});
    };
    // Application installs its diagnostics observer after worldReady.
    control.beforeFrame=[&](EngineHost&,RuntimeWorld& world,InteractivePlay& play){
        play.SetFixedStepObserver([&](const FixedStepMeasurements&,double){++observed;});
        if(frames==1)beforeFailure=Counts(world);
    };
    control.afterFrame=[&](EngineHost& host,RuntimeWorld& world,InteractivePlay& play){
        ++frames;std::string error;
        if(frames==1){
            const auto first=Counts(world);
            Check(first.is_object()&&Count(first,"start")>0&&Count(first,"update")>0&&Count(first,"fixed")>0&&Count(first,"ui")>0&&Count(first,"presentation")>0,"healthy actual Application executes nonempty phase-sensitive counter fixture");
            DirectPhases(world,host.GetWindow().Input());const auto direct=Counts(world);
            bool everyPhase=true;for(auto field:{"update","fixed","ui","presentation","fracture","collision","origin","signal"})everyPhase&=Count(direct,field)>Count(first,field);
            Check(first.is_object()&&direct.is_object()&&everyPhase,"healthy direct controls prove every challenged callback really executes");
            Check(world.Scripts()&&world.Scripts()->Diagnostics().empty(),"counter script controls have no runtime faults");
            Check(!world.SimulationFailed()&&play.FixedStepsSinceReset()==1&&observed==1,"healthy first frame produces one completed physics step");
            completedTime=world.SimulationTimeSeconds();inject=true;
        }else if(frames==2){
            failedWorld=&world;heldState=Counts(world);
            Check(!inject&&moved&&world.SimulationFailed(),"actual Simulation Step failure is caught after physical movement");
            Check(heldState.is_object()&&Count(heldState,"fixed")>Count(beforeFailure,"fixed")&&Count(heldState,"presentation")==Count(beforeFailure,"presentation"),"pre-physics fixed callback ran but post-physics presentation callback did not");
            Check(world.SimulationTimeSeconds()==completedTime&&play.FixedStepsSinceReset()==1&&observed==1,"failed attempt skips simulation clock and successful fixed counters/observer");
            Check(play.IsPaused()&&!host.GetWindow().IsMouseCaptured(),"native failure mode halts and releases mouse for recovery");
            Check(world.SimulationFailureMessage()=="application native finish failure after physical drift","owner exposes useful original physics diagnostic");
        }else if(!requested){
            Check(heldState.is_object()&& &world==failedWorld&&world.SimulationFailed()&&Counts(world)==heldState,"later outer frame preserves nonempty quarantined phase counters");
            Check(play.FixedStepsSinceReset()==1&&observed==1&&world.SimulationTimeSeconds()==completedTime,"halted frames do not retry or publish a completed step");
            DirectPhases(world,host.GetWindow().Input());
            Check(heldState.is_object()&&Counts(world)==heldState,"all direct runtime and VM phase controls remain frozen after poison");
            Check(!world.PrepareScriptTools().Reload(true,error)&&world.SimulationFailed(),"M94 script reload rejects and cannot heal physical poison");
            std::map<std::string,SaveChunk> chunks;chunks["sentinel"]={1,"retained"};
            Check(!WorldPersistence::Capture(world,chunks,error)&&error.find("physics failed")!=std::string::npos&&chunks.size()==1&&chunks.at("sentinel").data=="retained","modern save rejects poison while preserving prior output");
            Check(!CanCaptureLegacyWorldState(world,error)&&error.find("physics failed")!=std::string::npos,"legacy save preflight rejects poisoned world");
            bool direct=false;try{(void)CaptureWorldState(world);}catch(...){direct=true;}Check(direct,"direct legacy capture also rejects");
            if(frames==5){requested=world.SceneControl()->Reload(error);Check(requested,"true native fresh-scene reload remains available");}
        }else{
            Check(&world!=failedWorld&&!world.SimulationFailed(),"ordinary SceneSession Apply replaced poisoned RuntimeWorld with a fresh world");
            Check(play.FixedStepsSinceReset()==1&&observed==2&&world.SimulationTimeSeconds()>0,"fresh world completes exactly one normal step without failed-input replay");
            const auto fresh=Counts(world);Check(fresh.is_object()&&Count(fresh,"fixed")==1&&Count(fresh,"fracture")==0,"cold reload reconstructs fresh script counters and authored intent");
            recovered=true;SDL_Event event{};event.type=SDL_QUIT;SDL_PushEvent(&event);
        }
        if(frames>9){Check(false,"failure containment/reload makes bounded application progress");SDL_Event event{};event.type=SDL_QUIT;SDL_PushEvent(&event);}
    };
    char name[]="judas";char* args[]={name,project.data()};Application app;
    Check(app.Run(2,args,&control)==0&&recovered,"ordinary hidden Application remains usable and recovers by real scene reload");
    std::printf("SUMMARY %d checks %d failures\n",checks,failures);return failures?1:0;
}
