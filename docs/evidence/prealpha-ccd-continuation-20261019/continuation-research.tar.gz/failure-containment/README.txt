ISOLATED STICKY FAILURE CONTAINMENT CANDIDATE
Prepared 2026-10-18. No builds/tests executed by this agent. Production untouched.

Base: lifetime-world sources plus endpoint-world PhysicsWorld.cpp,
ContactSolver.h/.cpp and MeshEndpointPublication.h. Other application sources
were copied from production. originals/ preserves this layered base exactly;
sources/ is the containment candidate. FAILURE_CONTAINMENT.patch contains ONLY
containment changes relative to that base, with src/ paths for manual integration.
SOURCE_IDENTITY.json records original/candidate hashes for each changed file.

This is explicit invalidation, NOT rollback. An escaping mutating Step exception
leaves partial physical/coupled state in place and permanently marks that Impl
unfit for simulation or persistence. Raw inspection remains possible. A fresh
world is required; successful ordinary calculations retain their operation order.

IMPLEMENTED BOUNDARIES

- PhysicsWorld public Step and StepCoupled preserve their first exception_ptr,
  set sticky failure, and invalidate completed observations. The noexcept RAII
  guard also marks failure during unwinding; its destructor does not allocate.
  Pure coupling-quality/macro-dt/count/recursion validation happens before the
  failure region. Macro before/after callbacks, including the intervals==1 path,
  are covered by an outer guard. Later calls reject before any callback/write.
- HasFailedStep, StepFailureMessage, RequireValidContinuation expose the status.
  ReadBodyContactSample returns unavailable. Existing low-level physical archive
  entry points reject before bytes are written. Root must apply the same guard
  to the new mesh ownership persistence added in its integration snapshot.
- Simulation entry rejects a previously failed world before pre-step scripts or
  force producers. The interactive owner catches a newly poisoned physics call
  before successful counters/observer/publication. An escaping failure already
  skips Simulation's post-physics work and NetworkAfterFixed. Dedicated owner
  retains its process-level failure exit, with no false completed-step count.
- A native failure frame branches before project input/UI/network work, releases
  pointer capture, clears catch-up input, stops network/audio publication, and
  shows the original diagnostic with native Reload scene and Stop/Quit controls.
  It draws a plain diagnostic screen, never a newly synchronized partial world.
  Healthy Frame behavior is unchanged apart from the initial boolean check.
- Runtime script phase entry points and direct ScriptSystem phase methods are
  gated. Direct ScriptSystem FractureEvent, PhysicsEvent and ShiftOrigin also
  need explicit guards because those paths call JS directly outside Callback.
  RuntimeWorld DispatchFractureEvents refuses before consuming committed events.
  ScriptSystem Callback also suppresses destroy callbacks while disposing
  a poisoned world, while ordinary VM/native cleanup remains. M94 script Reload
  rejects a poisoned world; it does not reconstruct PhysicsWorld.
- Shared SceneSession streaming advance and direct WorldStreaming Advance/Persist
  are gated, covering runtime and editor outer owners. A paused flag alone would
  still install/unload composed regions, which is why this explicit gate exists.
- Modern Prepare/Capture and direct wheel/powertrain/animation/kinematic capture,
  legacy preflight/direct capture, direct physical persistence and region archive
  reject. Same-world world-save restoration rejects. Existing SaveService sees a
  prompt capture failure; previously dispatched immutable valid saves may finish.
- Network Host/Join/Pump/AfterFixed reject or stop on failure. The native owner
  closes the session, making actual SceneSession Reload available. Per-frame
  ordinary telemetry skips poisoned worlds.
- Real SceneSession Reload creates a fresh candidate RuntimeWorld before owner
  replacement. Same-world RestoreAuthoredState rejects; ResetBody/sleep/cache
  changes and script reload cannot clear the sticky flag. Shutdown/Init creates
  a fresh Impl for raw native use.

TEST SOURCES (ROOT RUNS ALL CPU WORK)

1. PhysicsFailureContainmentTests.cpp
   Link as an ordinary native physics test against the exact copied unified
   world/ContactSolver candidate, with the same dependencies as existing minimal
   physics executables. Compile with -I<failure-containment>/sources -Isrc and
   ordinary third-party flags; all objects that see WorldInternal must agree on
   this header layout. Tests use a genuine finish callback throw after movement,
   macro before/after throws, caller byte preservation, continued-call rejection,
   raw fresh reconstruction, and healthy invalid-preflight controls.
   When linked against the parent's new mesh persistence interface, also define
       -DJUDAS_TEST_HAS_MESH_CONTACT_PERSISTENCE
   to require direct PersistMeshContacts rejection with unchanged caller bytes.
   This method is intentionally absent from the unmerged base sources here;
   root WorldMeshPersistence must guard its actual public entry point.

2. FailureContainmentApplicationTests.cpp
   Link as an ordinary SceneTransitionTests-style application executable against
   the rebuilt candidate application/engine objects. Add the exact GNU linker
   option:
       -Wl,--wrap=_ZN12PhysicsWorld4StepEf
   This wraps the normal Step(float) call from Simulation.cpp. The wrapper calls
   the real Step(float,VelocityCoupling*) overload with a native finish callback
   that observes actual drift then throws. It does not change fixture bytes,
   geometry thresholds, total dt, certificate budgets or the production API.
   Run from repository root with ordinary assets (use the same Xvfb/SDL/audio
   environment as existing application tests). A disposable scene_demo copy is created under this cache's app-fixture/;
   only its copied events.js is replaced with explicit counters for start,
   update, fixed, UI, presentation, fracture, collision, origin and signal
   callbacks. Original project files and physical fixtures remain untouched.
   One healthy frame and direct controls prove the counters actually execute.
   Injection occurs on frame 2; subsequent automatic and direct phase attempts
   must leave nonempty counters fixed. Actual SceneSession Reload then builds a
   distinct healthy world with fresh counters and one successful fixed step.

   No wrapping flag means the injection will not occur: the first assertion
   deliberately fails. No relink of Simulation's Step reference means the same.
   Do not reinterpret an uninjected run as a containment pass.

BUILD / ODR NOTES

Rebuild UnifiedWorld and every source reading WorldInternal against the same
candidate header. Endpoint's added ContactSolver observer requires rebuilding
ContactSolver.cpp as well. Rebuild PhysicsWorld.h consumers for the new methods.
For application controls override: InteractivePlay, NetworkSession, RuntimeWorld,
RuntimeDiagnostics, SceneSession, ScriptSystem (its copied developer-method inc
must resolve locally), Simulation, WorldScripts, WorldState, WorldStreaming and
WorldPersistence. Do not mix original ScriptSystem.cpp with the candidate inc
and claim M94 reload/destructor quarantine was tested. Parent save integration
must merge guards rather than replace its new mesh participant with this base.

EXPLICIT LIMITATIONS / UNSAFE BYPASSES

- Not a universal sandbox for every public mutator or read. Raw ResetBody,
  ApplyForce, resource setters and direct subsystem APIs can still mutate a
  poisoned world when a native caller bypasses the owner. They cannot clear its
  failure or make future Step/canonical saves valid. Diagnostic reads can expose
  partial state and must be labeled as failed-attempt inspection.
- The supported shipping runtime/editor callback paths are quarantined; arbitrary
  ApplicationControl hooks and native callers are trusted test/developer code.
  They can deliberately bypass owner gates. No claim of isolation from them.
- Pre-physics scripts/network-before/material callbacks may already have external
  effects. Containment does not undo them. It suppresses downstream successful
  publication and future execution. Arbitrary external callbacks cannot be
  transactionally undone by this mechanism.
- This does not catch process termination, memory corruption, or a second throw
  from an existing destructor during exception unwinding. No allocation-failure
  or full platform/UI validation has been performed. Recovery screen formatting
  and native resource cleanup may still fail under severe allocation exhaustion.
- Low-level weather/terrain/deformable subsystem-specific direct capture APIs are
  not all individually poisoned. Canonical world saves and streaming snapshot
  entry paths are blocked; callers bypassing those boundaries remain responsible.
- Active transport closure and disposal are native cleanup. If cleanup itself
  fails, the sticky world remains invalid and Stop/Quit is still the fallback;
  there is no claim of reconstructing or continuing that partial state.
- A visible rare physics halt is a material gameplay limitation. This patch does
  not prove uncertainty cannot occur, provide bounded successful progress for
  every geometry, or turn a failed physical fixture into a pass.

No production changes, commits, pushes, builds or test executions were performed
by this agent. Original endpoint/lifetime/analysis artifacts remain preserved.

SIMPLIFICATION REVIEW (SECOND INDEPENDENT SOURCE PASS)

Removed redundant RequireValidContinuation calls from 13 private WorldPersistence
participant helpers: canonical CapturePrepared/Prepare/Restore and the public
CaptureWheel/Powertrain/Animation/Kinematic entry points already gate them. Kept
all directly public PhysicsWorld persistence guards, including the parent-owned
mesh entry obligation. This reduces repeated normal-path checks without losing
the declared save boundary.

The remaining file count reflects separate actual entry paths, not a transaction
framework. Removing the Frame failure branch would execute UI/presentation while
paused; removing direct VM gates would miss Fracture/Physics/Origin JS_Call paths;
removing WorldFracture's gate would consume events despite suppressing JS; removing
shared/direct streaming gates would permit installs or region persistence; and
removing modern/legacy capture gates would allow bypassing a hotkey wrapper.
The normal Step path adds one status check, exception scope and small guard.
No deep copy, per-body journal, changed impulse arithmetic or new event budget
is introduced. Several owner/direct-entry checks are defensive duplicates, but
keep the actual public boundaries readable; folding methods into another file
would lower file count without reducing behavior or implementation complexity.

This review did not audit every public mutator or subsystem serializer and makes
no universal native-code isolation claim. It closes the declared callback/save/
stream paths, with root's new mesh persistence guard still required at merge.
