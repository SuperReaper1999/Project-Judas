#pragma once
// PRIVATE algebra experiment. Physical cells, volume simplices, faces and
// their three P1 coordinates are unchanged. Only shared-port classification
// and condensation groups change. No cells are geometrically merged.
#include "VoxelPorts.h"
#include "ConservativeCondensedNetwork.h"
namespace regional_cochains {
using namespace stage17_network;
struct Compiler:convex_ports::Compiler {
    std::vector<std::pair<unsigned,unsigned>> originalPhysicalOwners;
    unsigned regions=0;
    struct Owners{unsigned first=~0u,second=~0u;};
    void Build(const convex_ports::Compiler& source) {
        if(grid||!cells.empty())throw std::invalid_argument("regional compiler cannot be reused");
        grid=source.grid;box=source.box;cells=source.cells;
        std::map<PortKey,Owners> ports;std::vector<unsigned> parent(cells.size());std::iota(parent.begin(),parent.end(),0);
        const auto find=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};
        for(unsigned c=0;c<cells.size();++c){originalPhysicalOwners.emplace_back(cells[c].seed,cells[c].piece);for(const auto& face:cells[c].faces)if(face.kind!=Kind::Solid){auto& owners=ports[face.key];if(owners.first==~0u)owners.first=c;else if(owners.second==~0u)owners.second=c;else throw std::invalid_argument("regional port has more than two owners");}}
        for(const auto& [key,owners]:ports){if(owners.second!=~0u){parent[find(owners.second)]=find(owners.first);continue;}bool outer=false;if(key.kind==Kind::Background)for(unsigned axis=0;axis<3;++axis){bool low=true,high=true;for(const auto& p:key.background){low&=p[axis]==0;high&=p[axis]==int(grid);}outer|=low||high;}if(!outer)throw std::invalid_argument("regional interior port lacks its physical opposite owner");}
        std::map<unsigned,unsigned> groups;
        for(unsigned c=0;c<cells.size();++c){const auto [at,inserted]=groups.emplace(find(c),groups.size());cells[c].seed=at->second;for(auto& face:cells[c].faces)if(face.kind==Kind::Background&&ports.at(face.key).second!=~0u){face.kind=Kind::Internal;face.key.kind=Kind::Internal;}}
        regions=groups.size();
    }
};
struct Epoch:stage17_conservative_network::Epoch {
    static stage17_condensed::LocalCondensedNetwork Prepare(unsigned n,const Box& box,const vg::R& scale,bool regional){voxel_ports::Compiler g;g.Build(n,box);if(regional){Compiler region;region.Build(g);Network physical(region,scale);return stage17_condensed::LocalCondensedNetwork(physical);}Network physical(g,scale);return stage17_condensed::LocalCondensedNetwork(physical);}
    Epoch(unsigned n,const Box& box,const vg::R& scale,bool regional=true):stage17_conservative_network::Epoch(Prepare(n,box,scale,regional)){}
};
} // namespace regional_cochains
