#pragma once

// PRIVATE Stage17 geometry candidate. Physical cells are the at-most-six
// convex outside pieces of sequential subtraction. Artificial cut caps are
// partitioned into actual pairwise fluid ports and wetted solid patches.
// All classification and ownership use native exact plane predicates.
#include "../fluid-runtime-candidates-stage16-20261029/geometry/BoundaryCompiler.h"

namespace convex_ports {

using R=stage16_geometry::R;
using RV=stage16_geometry::RV;
using Box=std::array<fluid_exact::Plane,6>;
using Lattice=motion_mesh::Lattice;
using BoundaryTriangle=stage16_geometry::BoundaryTriangle;
using VolumeSimplex=stage16_boundary::VolumeSimplex;
using Polyhedron=motion_mesh::Polyhedron;
using Polygon=motion_mesh::Face;
using stage16_geometry::Sub;

enum class Kind { Background,Internal,Solid };

struct PortKey {
    Kind kind=Kind::Background;
    std::array<Lattice,3> background{};
    unsigned exclusion=~0u,seed=~0u,first=~0u,second=~0u;
    bool operator<(const PortKey& b) const {
        return std::tie(kind,background,exclusion,seed,first,second)
             <std::tie(b.kind,b.background,b.exclusion,b.seed,b.first,b.second);
    }
    bool operator==(const PortKey& b) const { return !(*this<b) && !(b<*this); }
};
using Key=PortKey;

struct Face {
    Kind kind=Kind::Background;
    PortKey key;
    unsigned plane=~0u;
    int solid=-1;
    std::vector<BoundaryTriangle> triangles; // original unscaled lattice frame
};

struct Cell {
    unsigned seed=~0u,piece=~0u;
    RV center{}; // exact bounding-box midpoint, NOT a volume centroid
    R volume=0;
    std::vector<Face> faces;
    std::vector<VolumeSimplex> integration;
};

struct Compiler {
    unsigned grid=0;
    Box box;
    std::vector<Cell> cells;

    struct Piece {
        unsigned cut=~0u,cell=~0u;
        Polyhedron poly;
        std::vector<std::pair<unsigned,int>> inside;
    };

    static std::vector<std::pair<unsigned,int>> Halfspaces(stage16_boundary::Compiler& g,const Polyhedron& poly) {
        std::vector<std::pair<unsigned,int>> result;
        for(const auto& face:poly.faces) {
            int sign=0;
            for(const auto& other:poly.faces) {
                for(unsigned v:other.vertices) if((sign=g.mesh.Side(v,face.plane))!=0) break;
                if(sign) break;
            }
            if(!sign) throw std::runtime_error("convex port piece lacks positive three-dimensional interior");
            result.emplace_back(face.plane,sign);
        }
        return result;
    }

    static bool Contains(stage16_boundary::Compiler& g,const Piece& piece,const Polygon& patch) {
        for(const auto& halfspace:piece.inside)
            for(unsigned v:patch.vertices)
                if(halfspace.second*g.mesh.Side(v,halfspace.first)<0) return false;
        return true;
    }

    static std::vector<BoundaryTriangle> Triangles(stage16_boundary::Compiler& g,const Polygon& polygon,bool reverse) {
        const auto start=g.boundary.size();
        g.AppendBoundary(polygon,reverse);
        std::vector<BoundaryTriangle> result(g.boundary.begin()+start,g.boundary.end());
        g.boundary.resize(start);
        if(result.empty()) throw std::runtime_error("positive convex port has no positive-area boundary triangles");
        return result;
    }

    static RV Area(const std::vector<BoundaryTriangle>& triangles) {
        RV result{};
        for(const auto& triangle:triangles)
            for(unsigned a=0;a<3;++a) result[a]+=triangle.areaVector[a];
        return result;
    }

    void AddFace(stage16_boundary::Compiler& g,unsigned cell,const Polygon& polygon,
                 Kind kind,PortKey key,int solid=-1,bool reverse=false) {
        if(!g.PositiveFace(polygon)) throw std::runtime_error("attempt to publish a zero-area convex port");
        Face face;
        face.kind=kind;face.key=std::move(key);face.key.kind=kind;
        face.plane=polygon.plane;face.solid=solid;
        face.triangles=Triangles(g,polygon,reverse);
        cells.at(cell).faces.push_back(std::move(face));
    }

    unsigned NewCell(stage16_boundary::Compiler& g,unsigned seed,const Piece& piece) {
        Cell cell;
        cell.seed=seed;cell.piece=piece.cut;
        const auto start=g.integration.size();
        const R before=g.volume;
        g.AddIntegration(piece.poly);
        cell.integration.assign(g.integration.begin()+start,g.integration.end());
        cell.volume=g.volume-before;
        if(cell.volume<=0 || cell.integration.empty()) throw std::runtime_error("convex port cell has no positive volume");
        RV low=cell.integration[0].points[0],high=low;
        for(const auto& simplex:cell.integration)for(const auto& p:simplex.points)
            for(unsigned a=0;a<3;++a) {low[a]=std::min(low[a],p[a]);high[a]=std::max(high[a],p[a]);}
        for(unsigned a=0;a<3;++a) cell.center[a]=(low[a]+high[a])/2;
        const unsigned id=cells.size();cells.push_back(std::move(cell));return id;
    }

    // Partition an ORIGINAL background triangle, not the individual piece
    // facets. This gives both adjacent seeds identical aperture subdivisions.
    // On a coincident cutting plane all face points have side==0: that plane
    // does NOT count as the first strictly excluding cut. The eventual port
    // key can therefore differ from the owning volume piece's exclusion cut.
    void Background(stage16_boundary::Compiler& g,const Polygon& original,
                    const std::array<Lattice,3>& background,std::vector<Piece>& pieces,unsigned seedId) {
        auto remaining=original;
        std::vector<std::pair<unsigned,Polygon>> patches;
        for(unsigned cut=0;cut<6 && g.PositiveFace(remaining);++cut) {
            const unsigned plane=g.mesh.bodyPlanes[cut];
            bool outside=false;
            for(unsigned vertex:remaining.vertices) outside|=g.mesh.Side(vertex,plane)>0;
            if(outside) {
                auto patch=g.ClipFace(remaining,plane,-1);
                if(g.PositiveFace(patch)) patches.emplace_back(cut,std::move(patch));
            }
            remaining=g.ClipFace(remaining,plane,1);
        }
        if(g.PositiveFace(remaining)) patches.emplace_back(6,std::move(remaining));
        for(auto& [cut,patch]:patches) {
            unsigned owner=~0u;
            for(unsigned p=0;p<pieces.size();++p) if(Contains(g,pieces[p],patch)) {
                if(owner!=~0u) throw std::runtime_error("background port has two positive-volume owners in one seed");
                owner=p;
            }
            if(owner==~0u) {
                if(cut<6) throw std::runtime_error("open background port has no physical fluid owner");
                continue; // solid footprint with no fluid on this seed side
            }
            const auto& piece=pieces[owner];
            if(cut<6) {
                PortKey key;key.background=background;key.exclusion=cut;
                AddFace(g,piece.cell,patch,Kind::Background,key);
            } else {
                const RV area=Area(Triangles(g,patch,false));
                unsigned contact=~0u;
                for(unsigned plane=0;plane<6;++plane) {
                    const unsigned id=g.mesh.bodyPlanes[plane];
                    bool coincident=true;
                    for(unsigned v:patch.vertices) coincident&=g.mesh.Side(v,id)==0;
                    if(!coincident) continue;
                    const auto& source=g.mesh.planes[id];
                    const RV normal={R(source.normal[0]),R(source.normal[1]),R(source.normal[2])};
                    if(owned_metrics::Dot(area,normal)<0) {contact=plane;break;}
                }
                if(contact==~0u) throw std::runtime_error("owned solid background footprint has no opposing exact body plane");
                patch.plane=g.mesh.bodyPlanes[contact];
                PortKey key;key.seed=seedId;key.first=piece.cut;key.second=contact;
                AddFace(g,piece.cell,patch,Kind::Solid,key,int(contact));
            }
        }
    }

    void BuildSeed(unsigned n,unsigned seedId,const Box& definition) {
        stage16_boundary::Compiler g;
        for(const auto& plane:definition)
            g.mesh.bodyPlanes.push_back(g.mesh.AddPlane({plane.normal[0],plane.normal[1],plane.normal[2]},plane.coordinate));
        constexpr unsigned ids[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
        const unsigned voxel=seedId/6,x=voxel%n,y=(voxel/n)%n,z=voxel/(n*n);
        std::array<Lattice,8> corners;
        for(unsigned i=0;i<8;++i) corners[i]={int(x+(i&1)),int(y+((i>>1)&1)),int(z+((i>>2)&1))};
        const auto v=ids[seedId%6];
        g.seed=g.mesh.Seed({corners[v[0]],corners[v[1]],corners[v[2]],corners[v[3]]});
        g.seed.seed=seedId;g.seed.voxel=voxel;
        g.solid=g.seed;
        std::vector<Piece> pieces;
        for(unsigned cut=0;cut<6 && !g.solid.faces.empty();++cut) {
            auto exterior=g.mesh.Clip(g.solid,g.mesh.bodyPlanes[cut],-1);
            if(!exterior.faces.empty()) {
                Piece piece;piece.cut=cut;piece.poly=std::move(exterior);
                piece.inside=Halfspaces(g,piece.poly);
                piece.cell=NewCell(g,seedId,piece);
                pieces.push_back(std::move(piece));
            }
            g.solid=g.mesh.Clip(g.solid,g.mesh.bodyPlanes[cut],1);
        }
        if(pieces.empty()) return;

        // Pairwise ports use a later piece's inherited earlier-cut face. By
        // sequential convex subtraction this polygon is exactly a subset of
        // the earlier piece's cap. Its area is not extended to the whole cap.
        for(unsigned i=0;i<pieces.size();++i)for(unsigned j=i+1;j<pieces.size();++j) {
            const auto& earlier=pieces[i];const auto& later=pieces[j];
            for(const auto& face:later.poly.faces)
                if(face.plane==g.mesh.bodyPlanes[earlier.cut] && g.PositiveFace(face)) {
                    PortKey key;key.seed=seedId;key.first=earlier.cut;key.second=later.cut;
                    AddFace(g,later.cell,face,Kind::Internal,key,-1,false);
                    AddFace(g,earlier.cell,face,Kind::Internal,key,-1,true);
                }
        }
        for(const auto& face:g.solid.faces) {
            auto at=std::find(g.mesh.bodyPlanes.begin(),g.mesh.bodyPlanes.end(),face.plane);
            if(at==g.mesh.bodyPlanes.end() || !g.PositiveFace(face)) continue;
            const unsigned plane=at-g.mesh.bodyPlanes.begin();
            auto owner=std::find_if(pieces.begin(),pieces.end(),[&](const Piece& p){return p.cut==plane;});
            if(owner==pieces.end()) throw std::runtime_error("wetted solid patch lost its convex fluid owner");
            PortKey key;key.seed=seedId;key.first=owner->cut;key.second=plane;
            AddFace(g,owner->cell,face,Kind::Solid,key,int(plane),true);
        }
        for(const auto& face:g.seed.faces) {
            bool found=false;
            for(const auto& [key,plane]:g.mesh.backgroundFaces) if(plane==face.plane) {
                Background(g,face,key,pieces,seedId);found=true;break;
            }
            if(!found) throw std::runtime_error("original convex seed face has no background identity");
        }
        // Every published cell must close geometrically. This catches missing
        // cap partitions, overlap, orientation errors and a body patch silently
        // mistaken for a fluid interface without any numerical tolerance.
        for(const auto& piece:pieces) {
            const auto& cell=cells[piece.cell];RV sum{};R enclosed=0;
            for(const auto& face:cell.faces)for(const auto& triangle:face.triangles) {
                for(unsigned a=0;a<3;++a) sum[a]+=triangle.areaVector[a];
                enclosed+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
            }
            if(sum!=RV{} || enclosed!=cell.volume)
                throw std::runtime_error("convex cell port partition does not exactly enclose its physical volume");
        }
    }

    void BuildSelected(unsigned n,const Box& definition,const std::vector<unsigned>& seeds) {
        if(grid || !cells.empty() || !n || n>8) throw std::invalid_argument("invalid/reused convex port compiler");
        grid=n;box=definition;std::set<unsigned> seen;
        for(unsigned seed:seeds) {
            if(seed>=6*n*n*n || !seen.insert(seed).second) throw std::invalid_argument("invalid/duplicate convex port seed");
            BuildSeed(n,seed,definition);
        }
    }
    void Build(unsigned n,const Box& definition) {
        if(grid || !cells.empty() || !n || n>8) throw std::invalid_argument("invalid/reused convex port compiler");
        std::vector<unsigned> seeds(6*n*n*n);std::iota(seeds.begin(),seeds.end(),0);
        BuildSelected(n,definition,seeds);
    }
};

} // namespace convex_ports
