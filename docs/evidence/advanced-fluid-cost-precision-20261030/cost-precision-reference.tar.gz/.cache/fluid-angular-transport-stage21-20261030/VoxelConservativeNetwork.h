#pragma once

// Thin PRIVATE adapter: original voxel IDs already carry the exact locality
// required by the existing generic port and conservative condensation code.
// No new pressure algorithm, merging or transport architecture is introduced.
#include "VoxelNetwork.h"
#include "ConservativeCondensedNetwork.h"

namespace stage17_voxel_conservative {
using namespace stage17_network;
using Baseline=stage17_condensed::LocalCondensedNetwork;
struct Epoch : stage17_conservative_network::Epoch {
    static Baseline Prepare(const voxel_ports::Compiler& geometry,const vg::R& scale,Boundary boundary) {
        stage17_voxel::Epoch physical(geometry,scale,boundary);
        return Baseline(physical);
    }
    static voxel_ports::Compiler Geometry(unsigned grid,const Box& box) {
        voxel_ports::Compiler geometry;geometry.Build(grid,box);return geometry;
    }
    Epoch(unsigned grid,const Box& box,const vg::R& scale=1,Boundary boundary=Boundary::Sealed)
        :Epoch(Geometry(grid,box),scale,boundary) {}
    Epoch(const voxel_ports::Compiler& geometry,const vg::R& scale=1,Boundary boundary=Boundary::Sealed)
        :stage17_conservative_network::Epoch(Prepare(geometry,scale,boundary)) {}
    explicit Epoch(const Baseline& baseline):stage17_conservative_network::Epoch(baseline) {}
};
} // namespace stage17_voxel_conservative
