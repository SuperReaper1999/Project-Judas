#pragma once

// Isolated representation experiment: the authored background physical cell is
// a VOXEL CUBE. The six tetrahedra used by prior integration references are not
// pressure-cell boundaries. Geometry and collision ownership are unchanged;
// triangulation below is positive-volume integration only.
#include "ConvexPorts.h"

namespace voxel_ports {
using R=convex_ports::R;using RV=convex_ports::RV;using Box=convex_ports::Box;
using Lattice=convex_ports::Lattice;using Cell=convex_ports::Cell;
using Piece=convex_ports::Compiler::Piece;using Polygon=convex_ports::Polygon;
using PortKey=convex_ports::PortKey;using Kind=convex_ports::Kind;

struct Compiler : convex_ports::Compiler {
    static motion_mesh::Polyhedron Cube(stage16_boundary::Compiler& g,unsigned n,unsigned voxel) {
        const unsigned xyz[3]={voxel%n,(voxel/n)%n,voxel/(n*n)};
        std::array<std::array<unsigned,2>,3> planes;
        for(unsigned axis=0;axis<3;++axis)for(unsigned side=0;side<2;++side) {
            const unsigned u=(axis+1)%3,v=(axis+2)%3;
            Lattice ll={int(xyz[0]),int(xyz[1]),int(xyz[2])};ll[axis]+=side;
            auto hl=ll,lh=ll;++hl[u];++lh[v];
            // Three canonical corners IDENTIFY the whole axis-aligned unit
            // SQUARE. This is not a triangular aperture. Its four-corner
            // polygon and exact clipped triangles below own the actual area.
            planes[axis][side]=g.mesh.BackgroundPlane({ll,hl,lh});
        }
        std::array<unsigned,8> corners;
        for(unsigned mask=0;mask<8;++mask)
            corners[mask]=g.mesh.Intersection({planes[0][mask&1],planes[1][(mask>>1)&1],planes[2][(mask>>2)&1]});
        motion_mesh::Polyhedron cube;cube.seed=voxel;cube.voxel=voxel;
        for(unsigned axis=0;axis<3;++axis)for(unsigned side=0;side<2;++side) {
            const unsigned u=(axis+1)%3,v=(axis+2)%3,base=side<<axis;
            Polygon face{planes[axis][side],{corners[base],corners[base|(1u<<u)],corners[base|(1u<<u)|(1u<<v)],corners[base|(1u<<v)]}};
            if(!side)std::reverse(face.vertices.begin(),face.vertices.end());
            cube.faces.push_back(std::move(face));
        }
        return cube;
    }

    void BuildVoxel(unsigned n,unsigned voxel,const Box& definition) {
        stage16_boundary::Compiler g;
        for(const auto& plane:definition)
            g.mesh.bodyPlanes.push_back(g.mesh.AddPlane({plane.normal[0],plane.normal[1],plane.normal[2]},plane.coordinate));
        g.seed=Cube(g,n,voxel);g.solid=g.seed;
        std::vector<Piece> pieces;
        for(unsigned cut=0;cut<6 && !g.solid.faces.empty();++cut) {
            auto exterior=g.mesh.Clip(g.solid,g.mesh.bodyPlanes[cut],-1);
            if(!exterior.faces.empty()) {
                Piece piece;piece.cut=cut;piece.poly=std::move(exterior);
                piece.inside=Halfspaces(g,piece.poly);piece.cell=NewCell(g,voxel,piece);
                pieces.push_back(std::move(piece));
            }
            g.solid=g.mesh.Clip(g.solid,g.mesh.bodyPlanes[cut],1);
        }
        if(pieces.empty())return;
        for(unsigned i=0;i<pieces.size();++i)for(unsigned j=i+1;j<pieces.size();++j) {
            const auto& earlier=pieces[i];const auto& later=pieces[j];
            for(const auto& face:later.poly.faces)
                if(face.plane==g.mesh.bodyPlanes[earlier.cut] && g.PositiveFace(face)) {
                    PortKey key;key.seed=voxel;key.first=earlier.cut;key.second=later.cut;
                    AddFace(g,later.cell,face,Kind::Internal,key,-1,false);
                    AddFace(g,earlier.cell,face,Kind::Internal,key,-1,true);
                }
        }
        for(const auto& face:g.solid.faces) {
            auto at=std::find(g.mesh.bodyPlanes.begin(),g.mesh.bodyPlanes.end(),face.plane);
            if(at==g.mesh.bodyPlanes.end() || !g.PositiveFace(face))continue;
            const unsigned plane=at-g.mesh.bodyPlanes.begin();
            const auto owner=std::find_if(pieces.begin(),pieces.end(),[&](const Piece& p){return p.cut==plane;});
            if(owner==pieces.end())throw std::runtime_error("voxel wetted solid patch lost its physical fluid owner");
            PortKey key;key.seed=voxel;key.first=owner->cut;key.second=plane;
            AddFace(g,owner->cell,face,Kind::Solid,key,int(plane),true);
        }
        for(const auto& face:g.seed.faces) {
            bool found=false;
            for(const auto& [key,plane]:g.mesh.backgroundFaces)if(plane==face.plane) {
                Background(g,face,key,pieces,voxel);found=true;break;
            }
            if(!found)throw std::runtime_error("voxel background quad lacks its exact square identifier");
        }
        for(const auto& piece:pieces) {
            const auto& cell=cells[piece.cell];RV area{};R enclosed=0;
            for(const auto& face:cell.faces)for(const auto& triangle:face.triangles) {
                for(unsigned a=0;a<3;++a)area[a]+=triangle.areaVector[a];
                enclosed+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
            }
            if(area!=RV{} || enclosed!=cell.volume)
                throw std::runtime_error("voxel convex ports fail exact physical volume closure");
        }
    }
    void BuildSelected(unsigned n,const Box& definition,const std::vector<unsigned>& selected) {
        if(grid || !cells.empty() || !n || n>8)throw std::invalid_argument("invalid/reused voxel port compiler");
        grid=n;box=definition;std::set<unsigned> seen;
        for(unsigned voxel:selected) {
            if(voxel>=n*n*n || !seen.insert(voxel).second)throw std::invalid_argument("invalid/duplicate voxel identifier");
            BuildVoxel(n,voxel,definition);
        }
    }
    void Build(unsigned n,const Box& definition) {
        if(grid || !cells.empty() || !n || n>8)throw std::invalid_argument("invalid/reused voxel port compiler");
        std::vector<unsigned> selected(n*n*n);std::iota(selected.begin(),selected.end(),0);
        BuildSelected(n,definition,selected);
    }
};
} // namespace voxel_ports
