#pragma once

// Isolated rational convex clipping. Exact coordinate equality is the only
// vertex identity; plane coefficients may be exact differences of native
// binary64 planes. No approximate bisector coefficient or proximity weld is
// introduced. This is not part of the production engine.
#include "../fluid-compatible-flux-stage9-kernel/OwnedMetrics.h"
#include <algorithm>
#include <map>
#include <set>

namespace exact_convex {
using R=owned_metrics::R;using RV=owned_metrics::RV;
inline RV Sub(RV a,const RV& b){for(unsigned i=0;i<3;++i)a[i]-=b[i];return a;}
inline RV Add(RV a,const RV& b){for(unsigned i=0;i<3;++i)a[i]+=b[i];return a;}
inline RV Mul(RV a,const R& s){for(auto& x:a)x*=s;return a;}
struct Plane {RV normal{};R coordinate=0;};
struct Face {unsigned plane=~0u;std::vector<RV> vertices;};
struct Polyhedron {std::vector<Face> faces;};
struct Triangle {std::array<RV,3> points;RV areaVector;unsigned plane=~0u;};
struct Simplex {std::array<RV,4> points;R volume=0;};
inline R Evaluate(const RV& point,const Plane& plane){return owned_metrics::Dot(point,plane.normal)-plane.coordinate;}
inline int Side(const RV& point,const Plane& plane){const R v=Evaluate(point,plane);return v>0?1:(v<0?-1:0);}
inline RV Intersection(const RV& a,const RV& b,const Plane& plane){const R sa=Evaluate(a,plane),sb=Evaluate(b,plane);if(sa==sb)throw std::runtime_error("parallel rational clip edge");return Add(a,Mul(Sub(b,a),sa/(sa-sb)));}
inline RV AreaVector(const Face& face){RV result{};if(face.vertices.size()<3)return result;const RV a=face.vertices[0];for(unsigned i=1;i+1<face.vertices.size();++i){const RV area=owned_metrics::Cross(Sub(face.vertices[i],a),Sub(face.vertices[i+1],a));for(unsigned j=0;j<3;++j)result[j]+=area[j]/2;}return result;}
inline bool PositiveArea(const Face& face){return AreaVector(face)!=RV{};}

inline Polyhedron Clip(const Polyhedron& original,const std::vector<Plane>& planes,unsigned planeId,int keep){
    if(keep!=1 && keep!=-1)throw std::invalid_argument("rational clip keep sign must be one");
    if(original.faces.empty())return {};
    const auto& plane=planes.at(planeId);
    if(plane.normal==RV{})throw std::invalid_argument("rational clip plane has zero normal");
    bool positive=false,negative=false;
    for(const auto& face:original.faces)for(const auto& point:face.vertices){const int side=keep*Side(point,plane);positive|=side>0;negative|=side<0;}
    if(!positive)return original;
    if(!negative)return {};
    Polyhedron result;std::map<RV,RV> capEdges;
    for(const auto& face:original.faces){Face clipped{face.plane,{}};
        for(unsigned i=0;i<face.vertices.size();++i){const RV& a=face.vertices[i];const RV& b=face.vertices[(i+1)%face.vertices.size()];const int sa=keep*Side(a,plane),sb=keep*Side(b,plane);if(sa<=0)clipped.vertices.push_back(a);if((sa<0&&sb>0)||(sa>0&&sb<0))clipped.vertices.push_back(Intersection(a,b,plane));}
        clipped.vertices.erase(std::unique(clipped.vertices.begin(),clipped.vertices.end()),clipped.vertices.end());
        if(clipped.vertices.size()>1&&clipped.vertices.front()==clipped.vertices.back())clipped.vertices.pop_back();
        if(!PositiveArea(clipped))continue;
        for(unsigned i=0;i<clipped.vertices.size();++i){const RV& a=clipped.vertices[i];const RV& b=clipped.vertices[(i+1)%clipped.vertices.size()];if(a!=b&&Side(a,plane)==0&&Side(b,plane)==0){const auto [at,inserted]=capEdges.emplace(b,a);if(!inserted&&at->second!=a)throw std::runtime_error("branched rational convex cap");}}
        result.faces.push_back(std::move(clipped));
    }
    if(capEdges.size()<3)throw std::runtime_error("rational convex cut lost its closed cap");
    Face cap{planeId,{}};const RV start=capEdges.begin()->first;RV at=start;
    do{cap.vertices.push_back(at);const auto next=capEdges.find(at);if(next==capEdges.end())throw std::runtime_error("open rational cut cap");at=next->second;if(cap.vertices.size()>capEdges.size())throw std::runtime_error("rational cap repeats an edge");}while(at!=start);
    if(cap.vertices.size()!=capEdges.size() || !PositiveArea(cap))throw std::runtime_error("rational convex cap is disconnected or degenerate");
    result.faces.push_back(std::move(cap));return result;
}

inline std::vector<Triangle> Triangulate(const Face& face){std::vector<Triangle> result;if(face.vertices.size()<3)return result;const RV a=face.vertices[0];for(unsigned i=1;i+1<face.vertices.size();++i){const RV area=Mul(owned_metrics::Cross(Sub(face.vertices[i],a),Sub(face.vertices[i+1],a)),R(1)/2);if(area!=RV{})result.push_back({{a,face.vertices[i],face.vertices[i+1]},area,face.plane});}return result;}
inline std::vector<Simplex> PositiveCones(const Polyhedron& poly){std::vector<Simplex> result;if(poly.faces.empty())return result;std::set<RV> unique;for(const auto& face:poly.faces)unique.insert(face.vertices.begin(),face.vertices.end());if(unique.size()<4)throw std::runtime_error("rational convex piece lacks 3D volume");const RV a=*unique.begin();for(const auto& face:poly.faces)for(const auto& t:Triangulate(face)){const R volume=owned_metrics::Dot(Sub(t.points[0],a),owned_metrics::Cross(Sub(t.points[1],a),Sub(t.points[2],a)))/6;if(volume<0)throw std::runtime_error("rational convex cone orientation is negative");if(volume>0)result.push_back({{a,t.points[0],t.points[1],t.points[2]},volume});}if(result.empty())throw std::runtime_error("rational convex piece lost positive volume");return result;}
inline R Volume(const Polyhedron& poly){R total=0;for(const auto& simplex:PositiveCones(poly))total+=simplex.volume;return total;}
} // namespace exact_convex
