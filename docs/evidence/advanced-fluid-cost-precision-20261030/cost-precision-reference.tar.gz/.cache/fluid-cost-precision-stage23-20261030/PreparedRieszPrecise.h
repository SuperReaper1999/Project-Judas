#pragma once
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/eigen.hpp>
#include "KineticRiesz.h"
namespace prepared_riesz {
using namespace stage17_network;
using Q=boost::multiprecision::cpp_bin_float_quad;
using QM=Eigen::Matrix<Q,Eigen::Dynamic,Eigen::Dynamic>;
// Prepare the physical weak-load inverse from the existing positive ROOT.
// Higher precision is confined to preparation and a small 12-column map.
// No normal matrix, discarded mode, energy target or changed physical metric.
struct Factor {
 QM map;
 explicit Factor(const Matrix& root,const vm::LocalOperator& op){
  QM f=root.cast<Q>();Eigen::Matrix<Q,Eigen::Dynamic,1> scale(root.cols());
  for(unsigned i=0;i<scale.size();++i){const Q norm=f.col(i).norm();if(!(norm>0))throw std::runtime_error("prepared Riesz root column is zero");scale[i]=1/norm;}
  Eigen::HouseholderQR<QM> qr(f*scale.asDiagonal());
  QM upper=qr.matrixQR().topRows(root.cols()).template triangularView<Eigen::Upper>();
  for(unsigned i=0;i<scale.size();++i)if(upper(i,i)==0)throw std::runtime_error("prepared Riesz root is singular");
  QM load=Q(op.geometry.density)*op.projection.transpose().cast<Q>();
  QM rhs=scale.asDiagonal()*load;
  QM first=upper.transpose().template triangularView<Eigen::Lower>().solve(rhs);
  map=scale.asDiagonal()*upper.template triangularView<Eigen::Upper>().solve(first);
  // Independent root-form equation residual; relative to EACH actual load.
  QM residual=f.transpose()*(f*map)-load;
  if(residual.norm()>Q("1e-27")*std::max(Q(1),Q(load.norm())))throw std::runtime_error("prepared Riesz weak-load equation failed");
 }
 Vector ApplyPrecise(const Eigen::Matrix<Q,12,1>& moments)const {
  Vector result(map.rows());for(unsigned i=0;i<map.rows();++i){Q sum=0;for(unsigned j=0;j<12;++j)sum+=map(i,j)*moments[j];result[i]=sum.convert_to<Real>();}return result;
 }
 Vector Apply(const Vector& moments)const {
  if(moments.size()!=12||!moments.allFinite())throw std::invalid_argument("prepared Riesz requires twelve finite weak moments");
  Vector result(map.rows());
  for(unsigned i=0;i<map.rows();++i){Q sum=0;for(unsigned j=0;j<12;++j)sum+=map(i,j)*Q(moments[j]);result[i]=sum.convert_to<Real>();}
  return result;
 }
};
} // namespace prepared_riesz
