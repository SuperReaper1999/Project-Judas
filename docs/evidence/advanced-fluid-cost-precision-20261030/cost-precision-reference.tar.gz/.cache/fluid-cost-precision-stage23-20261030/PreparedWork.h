#pragma once
#include "PreparedRieszPrecise.h"
namespace prepared_work {
using namespace stage17_network;
using Q=prepared_riesz::Q;using QV=Eigen::Matrix<Q,Eigen::Dynamic,1>;using QA=Eigen::Matrix<Q,12,1>;
struct Evaluation {Vector raw;Q work=0,uncertainty=0;bool fullRootFallback=false;};
struct Factor {
 prepared_riesz::Factor solve;
 Matrix root,absoluteRoot;
 prepared_riesz::QM residualMap,preparationBound;
 explicit Factor(const Matrix& f,const vm::LocalOperator& op):solve(f,op),root(f),absoluteRoot(f.cwiseAbs()){
  const auto fq=f.cast<Q>().eval();const auto load=(Q(op.geometry.density)*op.projection.transpose().cast<Q>()).eval();
  residualMap=fq.transpose()*(fq*solve.map)-load;
  const Q u=std::numeric_limits<Q>::epsilon()/2;
  const Q n=Q(8*(f.rows()+f.cols())+32),gamma=n*u/(1-n*u);
  preparationBound=gamma*(fq.cwiseAbs().transpose()*(fq.cwiseAbs()*solve.map.cwiseAbs())+load.cwiseAbs());
 }
 Evaluation Apply(const Vector& state,const QA& polynomial,const QA& weak,Real density)const{
  Evaluation out;QV exact(solve.map.rows()),error(exact.size());out.raw.resize(exact.size());
  for(unsigned i=0;i<exact.size();++i){exact[i]=0;for(unsigned j=0;j<12;++j)exact[i]+=solve.map(i,j)*weak[j];out.raw[i]=exact[i].convert_to<Real>();error[i]=Q(out.raw[i])-exact[i];}
  const Vector fd=root*state,gradient=root.transpose()*fd;
  const Real u=std::numeric_limits<Real>::epsilon()/2;
  const auto gamma=[&](unsigned n){return Real(n)*u/(1-Real(n)*u);};
  const Vector firstError=gamma(root.cols())*(absoluteRoot*state.cwiseAbs());
  const Vector gradientError=gamma(root.rows())*(absoluteRoot.transpose()*fd.cwiseAbs())+(1+gamma(root.rows()))*(absoluteRoot.transpose()*firstError);
  Q correction=0;for(unsigned i=0;i<exact.size();++i){correction+=Q(gradient[i])*error[i];out.uncertainty+=Q(gradientError[i])*abs(error[i]);}
  const QV stateq=state.cast<Q>();
  out.work=Q(density)*polynomial.dot(weak)+stateq.dot(residualMap*weak)+correction;
  out.uncertainty+=stateq.cwiseAbs().dot(preparationBound*weak.cwiseAbs());
  // Numerical work-evaluation budget only; NEVER changes a physical state.
  // Large error bounds select the full root contraction, not a repaired energy.
  if(out.uncertainty>Q("1e-20")||!std::isfinite(gradient.norm())){
   const auto fq=root.cast<Q>().eval();out.work=(fq*stateq).dot(fq*out.raw.cast<Q>());out.fullRootFallback=true;
  }
  return out;
 }
};
} // namespace prepared_work
