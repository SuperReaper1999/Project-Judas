from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path(__file__).resolve().parent
boost=os.environ.get('BOOST_INCLUDE_DIR','.cache/fluid-reference-headers/boost/usr/include')
eigen=os.environ.get('EIGEN_INCLUDE_DIR','.cache/fluid-reference-headers/eigen/usr/include/eigen3')
rows=[]
for name in ('OptimizedQualification','OptimizedOracle','FinalControls'):
 src=root/(name+'.cpp');exe=root/(name+'.reproduced')
 cmd=['g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc','-I'+boost,'-I'+eigen,str(src),'-o',str(exe)]
 start=time.time()
 with (root/(name+'-reproduced-compile.log')).open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 row={'name':name,'compileCommand':cmd,'compileReturncode':code,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest()}
 if code==0:
  with (root/(name+'-reproduced.log')).open('w') as f:row['returncode']=subprocess.run([str(exe)],stdout=f,stderr=subprocess.STDOUT).returncode
  row['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
 row['elapsedSeconds']=time.time()-start;rows.append(row);(root/'reproduced-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code or row.get('returncode'):raise SystemExit(1)
