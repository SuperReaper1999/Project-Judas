"""Private references only. Run from repository root, one heavy job at a time."""
from pathlib import Path
import os,subprocess,sys,time,json,hashlib
root=Path(__file__).resolve().parent
source=root/sys.argv[1]
if source.parent!=root or source.suffix!='.cpp':raise SystemExit('choose a local C++ test')
boost=os.environ.get('BOOST_INCLUDE_DIR','.cache/fluid-reference-headers/boost/usr/include')
eigen=os.environ.get('EIGEN_INCLUDE_DIR','.cache/fluid-reference-headers/eigen/usr/include/eigen3')
exe=root/(source.stem+'.reproduced')
cmd=['g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc','-I'+boost,'-I'+eigen,str(source),'-o',str(exe)]
start=time.time();subprocess.run(cmd,check=True)
code=subprocess.run([str(exe),*sys.argv[2:]]).returncode
receipt={'source':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':cmd,'arguments':sys.argv[2:],'returncode':code,'elapsedSeconds':time.time()-start,'binarySha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
(root/(source.stem+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(code)
