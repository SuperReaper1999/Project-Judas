#pragma once
#include "../fluid-angular-transport-stage22-20261030/FastWeakAffineTransport.h"
namespace prepared_faces {
using namespace fast_affine;
struct Triangle {std::array<unsigned,3> vertex;R area;Real areaReal=0;std::array<vm::Vec3,3> x;};
struct Face {
 std::vector<std::array<R,3>> valuesFromMoments;
 std::vector<Triangle> triangles;
 RV anchor{};
 std::array<vm::Vec3,2> offset;
 explicit Face(const port_momentum::Face& f,const World& w):anchor(f.triangles.front().points.front()){
  std::array<std::array<R,3>,3> inverse;
  for(unsigned j=0;j<3;++j){std::array<R,3> q{};q[j]=1;const auto column=f.Coefficients(q);for(unsigned i=0;i<3;++i)inverse[i][j]=column[i];}
  std::map<RV,unsigned> vertices;
  for(const auto& input:f.triangles){Triangle t;t.area=abs(input.areaVector[f.pivot]);t.areaReal=t.area.convert_to<Real>();if(t.area>0&&!(t.areaReal>0))throw std::runtime_error("prepared aperture area is not representable");for(unsigned v=0;v<3;++v){const auto [at,inserted]=vertices.emplace(input.points[v],vertices.size());t.vertex[v]=at->second;if(inserted){const auto basis=port_momentum::Basis(f.geometry,input.points[v]);std::array<R,3> row{};for(unsigned j=0;j<3;++j)for(unsigned i=0;i<3;++i)row[j]+=basis[i]*inverse[i][j];valuesFromMoments.push_back(row);}for(unsigned a=0;a<3;++a)t.x[v][a]=(input.points[v][a]-anchor[a]).convert_to<Real>();}triangles.push_back(std::move(t));}
  for(unsigned side=0;side<2;++side)for(unsigned a=0;a<3;++a)offset[side][a]=(anchor[a]-w.cells[side?f.b: f.a]->cell.center[a]).convert_to<Real>();
 }
 std::vector<R> Values(const std::array<R,3>& moments)const{std::vector<R> result(valuesFromMoments.size());for(unsigned v=0;v<result.size();++v)for(unsigned j=0;j<3;++j)result[v]+=valuesFromMoments[v][j]*moments[j];return result;}
 template<class F>R Directed(const std::vector<R>& values,int sign,F consume)const{
  R total=0;for(const auto& triangle:triangles){std::array<R,3> q;std::array<Real,3> qr;for(unsigned i=0;i<3;++i){q[i]=sign*values[triangle.vertex[i]];qr[i]=q[i].convert_to<Real>();if(!std::isfinite(qr[i])||(q[i]!=0&&qr[i]==0))throw std::runtime_error("prepared directed flux is not representable");}const R amount=fast_affine::Transport::PositiveTotal(triangle.area,q);total+=amount;std::vector<fast_affine::Transport::CutPoint> polygon;for(unsigned i=0;i<3;++i){const unsigned j=(i+1)%3;if(q[i]>=0){fast_affine::Transport::CutPoint v;v.bary[i]=1;v.q=qr[i];polygon.push_back(v);}if((q[i]<0&&q[j]>0)||(q[i]>0&&q[j]<0)){const Real t=R(q[i]/(q[i]-q[j])).convert_to<Real>();if(!(t>0&&t<1))throw std::runtime_error("prepared positive intersection is not representable");fast_affine::Transport::CutPoint v;v.bary[i]=1-t;polygon.push_back(v);}}
   for(unsigned i=1;i+1<polygon.size();++i){const std::array<fast_affine::Transport::CutPoint,3> sub={polygon[0],polygon[i],polygon[i+1]};const auto& a=sub[0].bary;const auto& b=sub[1].bary;const auto& c=sub[2].bary;const Real fraction=std::abs((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]));if(amount>0&&!(fraction>0))throw std::runtime_error("prepared positive clipped area is not representable");auto point=[&](const std::array<Real,3>& weights,Real weight){std::array<Real,3> bary{};Real value=0;for(unsigned v=0;v<3;++v){value+=weights[v]*sub[v].q;for(unsigned j=0;j<3;++j)bary[j]+=weights[v]*sub[v].bary[j];}vm::Vec3 x=vm::Vec3::Zero();for(unsigned j=0;j<3;++j)x+=bary[j]*triangle.x[j];consume(x,triangle.areaReal*fraction*weight*value);};point({Real(1)/3,Real(1)/3,Real(1)/3},-Real(27)/48);for(unsigned v=0;v<3;++v){std::array<Real,3> weights={Real(1)/5,Real(1)/5,Real(1)/5};weights[v]=Real(3)/5;point(weights,Real(25)/48);}}
  }return total;
 }
};
} // namespace prepared_faces
