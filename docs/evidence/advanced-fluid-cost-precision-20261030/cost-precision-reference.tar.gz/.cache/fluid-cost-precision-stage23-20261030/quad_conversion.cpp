#include <boost/multiprecision/cpp_bin_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <iostream>
int main(){using Q=boost::multiprecision::cpp_bin_float_quad;using R=boost::multiprecision::cpp_rational;Q q=Q(1)/3;R r(q);Q back=r.convert_to<Q>();std::cout<<(back==q)<<' '<<r<<'\n';}
