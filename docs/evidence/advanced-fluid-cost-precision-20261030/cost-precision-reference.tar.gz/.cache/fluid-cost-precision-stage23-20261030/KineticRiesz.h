#pragma once
#include "../fluid-angular-transport-stage21-20261030/ConservativeInternalCoordinates.h"
namespace kinetic_riesz {
using namespace stage17_network;
// Solve F^T F x = f without materializing the rounded normal matrix.
// This is the weak-load Riesz map in the ALREADY CHOSEN kinetic metric.
// Affine interpolation is an exact-arithmetic shortcut only when all discrete
// reproduction identities are exact. No physical energy constraint is added.
struct Factor {
    Matrix root, upper;
    Vector scale;
    explicit Factor(const Matrix& source):root(source) {
        if(root.rows()<root.cols()||!root.allFinite())
            throw std::invalid_argument("invalid kinetic Riesz factor");
        scale.resize(root.cols());
        for(unsigned i=0;i<scale.size();++i){
            const Real norm=root.col(i).norm();
            if(!(norm>0))throw std::runtime_error("kinetic Riesz column is not positive");
            scale[i]=1/norm;
        }
        Eigen::HouseholderQR<Matrix> qr(root*scale.asDiagonal());
        upper=qr.matrixQR().topRows(root.cols()).template triangularView<Eigen::Upper>();
        for(unsigned i=0;i<scale.size();++i)
            if(upper(i,i)==0)throw std::runtime_error("kinetic Riesz factor is singular");
    }
    Vector Solve(const Vector& load)const {
        const Vector rhs=scale.asDiagonal()*load;
        const Vector y=upper.transpose().template triangularView<Eigen::Lower>().solve(rhs);
        return scale.asDiagonal()*upper.template triangularView<Eigen::Upper>().solve(y);
    }
};
} // namespace kinetic_riesz
