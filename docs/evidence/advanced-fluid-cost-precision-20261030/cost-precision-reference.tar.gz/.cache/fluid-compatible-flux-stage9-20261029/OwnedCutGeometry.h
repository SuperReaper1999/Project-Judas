#pragma once
#include "../fluid-compatible-flux-stage9-kernel/ConformingCutMesh.h"
#include <glm/gtc/quaternion.hpp>

namespace owned_cut {
using V=glm::dvec3;
// Subtract exact homogeneous coordinates BEFORE rounding local edge vectors.
// Rounded world-point subtraction can erase a real, thin cut dimension.
inline V Difference(const fluid_exact::Intersection& a,const fluid_exact::Intersection& b){
 V result;const auto denominator=fluid_exact::Product(a.denominator,b.denominator);
 for(unsigned axis=0;axis<3;++axis){const auto numerator=fluid_exact::Sum(
  fluid_exact::Product(a.numerator[axis],b.denominator),
  fluid_exact::Negate(fluid_exact::Product(b.numerator[axis],a.denominator)));
  result[axis]=fluid_exact::Estimate(numerator)/fluid_exact::Estimate(denominator);
  if(!std::isfinite(result[axis]))throw std::runtime_error("unrepresentable owned edge");
 }return result;
}
struct Boundary {unsigned cell;std::array<unsigned,3> vertices;int solidPlane=-1;V normal;};
struct Snapshot {
 fluid_mesh::Compiler mesh;
 std::vector<Boundary> boundaries;
 V solidCenter,solidHalf;
 glm::dquat solidRotation;
 double volume=0;
};
inline std::array<fluid_exact::Plane,6> BoxPlanes(V center,V half,glm::dquat q){
 if(glm::any(glm::lessThanEqual(half,V(0)))||!std::isfinite(glm::dot(q,q))||glm::dot(q,q)==0)
  throw std::invalid_argument("invalid owned solid transform");
 q=glm::normalize(q);std::array<fluid_exact::Plane,6> result;unsigned id=0;
 for(unsigned axis=0;axis<3;++axis)for(double sign:{-1.,1.}){
  V n(0);n[axis]=sign;n=q*n;
  result[id++]={{n.x,n.y,n.z},glm::dot(n,center)+half[axis]};
 }return result;
}
inline void Collect(Snapshot& result){
 struct Face {unsigned cell;std::array<unsigned,3> ids;unsigned occurrences=0;};
 std::map<std::array<unsigned,3>,Face> faces;
 constexpr unsigned tri[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,1,2}};
 double compensation=0;
 for(unsigned c=0;c<result.mesh.tetrahedra.size();++c){
  const auto& t=result.mesh.tetrahedra[c];const auto& a=result.mesh.vertices[t.vertices[0]].exact;
  const auto metrics=owned_metrics::Tetra({a,result.mesh.vertices[t.vertices[1]].exact,result.mesh.vertices[t.vertices[2]].exact,result.mesh.vertices[t.vertices[3]].exact});
  const double v=metrics.volume;
  const double add=v-compensation,next=result.volume+add;compensation=(next-result.volume)-add;result.volume=next;
  for(const auto& f:tri){std::array<unsigned,3> ids{t.vertices[f[0]],t.vertices[f[1]],t.vertices[f[2]]};auto key=ids;std::sort(key.begin(),key.end());auto& face=faces[key];face.cell=c;face.ids=ids;if(++face.occurrences>2)throw std::runtime_error("nonmanifold owned cut mesh");}
 }
 for(const auto& [key,face]:faces)if(face.occurrences==1){
  const auto& a=result.mesh.vertices[key[0]];
  const auto& tet=result.mesh.tetrahedra[face.cell];V centroid(0);for(auto p:tet.geometry)centroid+=p*.25;
  V normal=owned_metrics::Triangle({a.exact,result.mesh.vertices[key[1]].exact,result.mesh.vertices[key[2]].exact}).normal;if(glm::dot(normal,centroid-a.position)>0)normal=-normal;
  int solid=-1;bool inside=true;
  for(unsigned plane:result.mesh.bodyPlanes)for(unsigned v:key)inside&=result.mesh.Side(v,plane)<=0;
  if(inside)for(unsigned p=0;p<result.mesh.bodyPlanes.size();++p){
   const auto plane=result.mesh.bodyPlanes[p];bool on=true;for(auto v:key)on&=result.mesh.Side(v,plane)==0;
   if(on){solid=int(p);const auto& n=result.mesh.planes[plane].normal;normal=-glm::normalize(V(n[0],n[1],n[2]));break;}
  }
  if(!std::isfinite(glm::dot(normal,normal)))throw std::runtime_error("unrepresentable owned face normal");
  result.boundaries.push_back({face.cell,key,solid,normal});
 }
}
// One actual convex body; wet components are explicitly authored half-space
// regions, not an inferred scalar level. Existing compiler bounds apply.
inline Snapshot Prepare(unsigned grid,V center,V half,glm::dquat q,
 const std::vector<fluid_mesh::Compiler::WetCell>& wet={}){
 Snapshot staged;staged.solidCenter=center;staged.solidHalf=half;staged.solidRotation=glm::normalize(q);
 staged.mesh.BuildRegions(grid,BoxPlanes(center,half,q),wet);Collect(staged);return staged;
}
}
