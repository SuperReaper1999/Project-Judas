#pragma once
#include "VemLocal.h"

namespace JudasFluidVem {

struct CondensedSource {
    Vector rawLoad;
    Vector faceLoad;
    Vec3 angularOffset = Vec3::Zero();
    Real predictorEnergyConstant = 0;
    Real constant = 0;
};

// Exact algebraic elimination for the chosen local VEM metric, not a new
// fluid-mass approximation. Face fluxes remain primary globally. The three
// first-moment continuity equations determine mean velocity moments. The
// remaining integrated continuity equation is exposed as `closure` and must
// still be enforced by the global solve. Together these four equations imply
// div(v)=0 throughout the VEM cell.
struct CondensedCell {
    unsigned rawDimension = 0;
    unsigned faceDimension = 0;
    Matrix rawMass;
    Matrix Tface;
    Matrix Tangular;
    Mat3 angularMass = Mat3::Zero();
    Mat3 inverseAngularMass = Mat3::Zero();
    Matrix angularFromFace;
    Matrix faceMass;
    Eigen::Matrix<Real,1,Eigen::Dynamic> closure;

    explicit CondensedCell(const LocalOperator& local) {
        rawDimension=local.dimension;
        faceDimension=3*local.geometry.faces.size();
        rawMass=local.mass;
        Tface=Matrix::Zero(rawDimension,faceDimension);
        Tface.topRows(faceDimension).setIdentity();
        Tangular=Matrix::Zero(rawDimension,3);
        Tangular.bottomRows(3).setIdentity();
        closure=Matrix::Zero(1,faceDimension);
        for (unsigned f=0; f<local.geometry.faces.size(); ++f) {
            closure.template segment<3>(3*f)=local.faceNormalMoments[f].row(0);
            Tface.block(local.MeanOffset(),3*f,3,3)=local.faceNormalMoments[f].template middleRows<3>(1);
        }
        angularMass=Tangular.transpose()*rawMass*Tangular;
        inverseAngularMass=PositiveInverse(angularMass,"VEM internal angular metric is not positive/representable");
        const Matrix faceAngular=Tface.transpose()*rawMass*Tangular;
        angularFromFace=-inverseAngularMass*faceAngular.transpose();
        faceMass=Tface.transpose()*rawMass*Tface+faceAngular*angularFromFace;
        faceMass=(faceMass+faceMass.transpose()).eval()/2;
    }

    CondensedSource PrepareSource(const Vector& rawLoad, Real predictorEnergyConstant) const {
        if (rawLoad.size()!=rawDimension || !rawLoad.allFinite() || !std::isfinite(predictorEnergyConstant))
            throw std::runtime_error("VEM condensation source has invalid dimension or value");
        CondensedSource source;
        source.rawLoad=rawLoad;
        source.predictorEnergyConstant=predictorEnergyConstant;
        const Vec3 angularLoad=Tangular.transpose()*rawLoad;
        source.angularOffset=inverseAngularMass*angularLoad;
        source.faceLoad=Tface.transpose()*rawLoad
            -(Tface.transpose()*rawMass*Tangular)*source.angularOffset;
        // Preserve the exact eliminated predictor energy. Dropping this term
        // would retain velocities but falsify work/energy accounting.
        source.constant=predictorEnergyConstant-angularLoad.dot(source.angularOffset)/2;
        return source;
    }

    CondensedSource SourceFromPredictor(const Vector& rawPredictor) const {
        if (rawPredictor.size()!=rawDimension || !rawPredictor.allFinite())
            throw std::runtime_error("VEM raw predictor has invalid dimension or value");
        const Vector rawLoad=rawMass*rawPredictor;
        return PrepareSource(rawLoad,rawPredictor.dot(rawLoad)/2);
    }

    Vec3 ReconstructAngular(const Vector& faces, const CondensedSource& source) const {
        return source.angularOffset+angularFromFace*faces;
    }
    Vector Reconstruct(const Vector& faces, const CondensedSource& source) const {
        return Tface*faces+Tangular*ReconstructAngular(faces,source);
    }
    Matrix ReconstructionDerivative() const {
        return Tface+Tangular*angularFromFace;
    }
    Vector Gradient(const Vector& faces, const CondensedSource& source) const {
        return faceMass*faces-source.faceLoad;
    }
    // If faces=independentFaces+B*twist, B^T*Gradient is the exact derivative
    // of the reduced kinetic objective with respect to that physical twist.
    // Its negative is a reaction under the usual impulse residual convention.
    Vector PullbackGradient(const Matrix& B, const Vector& faces, const CondensedSource& source) const {
        return B.transpose()*Gradient(faces,source);
    }
    Real ReducedObjective(const Vector& faces, const CondensedSource& source) const {
        return faces.dot(faceMass*faces)/2-source.faceLoad.dot(faces)+source.constant;
    }
    Real FullObjective(const Vector& raw, const CondensedSource& source) const {
        return raw.dot(rawMass*raw)/2-source.rawLoad.dot(raw)+source.predictorEnergyConstant;
    }
};

} // namespace JudasFluidVem
