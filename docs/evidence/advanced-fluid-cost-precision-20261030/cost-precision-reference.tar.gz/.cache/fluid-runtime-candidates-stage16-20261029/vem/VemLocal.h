#pragma once

// Isolated Stage16 research candidate; not an engine implementation.
//
// H(div) k=1 virtual-element kinetic metric on one connected polyhedron.
// Primary face fluxes, not the affine L2 projection, define normal transport.
// The metric is exact on affine velocity fields. Its complementary metric is
// an explicit positive approximation to unresolved kinetic energy, not a claim
// to have recovered the unique continuum minimum-energy field.

#include <Eigen/Dense>
#include <array>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <vector>

namespace JudasFluidVem {

using Real = long double;
using Vec3 = Eigen::Matrix<Real, 3, 1>;
using Mat3 = Eigen::Matrix<Real, 3, 3>;
using Vector = Eigen::Matrix<Real, Eigen::Dynamic, 1>;
using Matrix = Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic>;
using Mat4 = Eigen::Matrix<Real, 4, 4>;
using Mat34 = Eigen::Matrix<Real, 3, 4>;
using Mat310 = Eigen::Matrix<Real, 3, 10>;
using Affine = Eigen::Matrix<Real, 12, 1>;

// Monomials in the physical cell-local frame r=x-cellCenter. The first four
// span P1, the first ten P2, and all twenty P3. Moments are unnormalized.
inline constexpr unsigned Powers[20][3] = {
    {0,0,0}, {1,0,0}, {0,1,0}, {0,0,1},
    {2,0,0}, {1,1,0}, {1,0,1}, {0,2,0}, {0,1,1}, {0,0,2},
    {3,0,0}, {2,1,0}, {2,0,1}, {1,2,0}, {1,1,1}, {1,0,2},
    {0,3,0}, {0,2,1}, {0,1,2}, {0,0,3}
};

inline unsigned MomentIndex(unsigned x, unsigned y, unsigned z) {
    for (unsigned i=0; i<20; ++i)
        if (Powers[i][0]==x && Powers[i][1]==y && Powers[i][2]==z) return i;
    throw std::runtime_error("VEM moment degree exceeds supplied P3 geometry");
}

inline unsigned ProductIndex(unsigned a, unsigned b) {
    return MomentIndex(Powers[a][0]+Powers[b][0],
                       Powers[a][1]+Powers[b][1],
                       Powers[a][2]+Powers[b][2]);
}

struct Moments {
    std::array<Real, 20> value{};
    Real& operator[](unsigned i) { return value.at(i); }
    Real operator[](unsigned i) const { return value.at(i); }
    Real At(unsigned x, unsigned y, unsigned z) const {
        return value[MomentIndex(x,y,z)];
    }
};

struct FaceGeometry {
    Vec3 normal = Vec3::Zero(); // outward unit fluid normal
    Moments area;
    // psi_i(r)=basis(i,0)+sum_a basis(i,a+1)*r_a. psi0=1.
    // Prefer centered/scaled tangential coordinates. Compute gram and mixed
    // before rounding exact geometry, not by subtracting large raw moments.
    Mat34 basis = Mat34::Zero();
    // Optional numerically anchored evaluation. A thin face far from the
    // cell center must not evaluate two huge affine terms and subtract them.
    // Geometry integration still uses the directly supplied Gram/mixed data.
    Vec3 evaluationOrigin = Vec3::Zero();
    Vec3 basisAtOrigin = Vec3::Zero();
    bool anchoredBasis = false;
    Mat3 gram = Mat3::Zero();       // integral psi_i psi_j dA
    Mat310 mixed = Mat310::Zero(); // integral psi_i r^alpha dA, |alpha|<=2
};

struct CellGeometry {
    Moments volume;
    std::vector<FaceGeometry> faces;
    Real density = 1000;
};

// Used only as a convenience for well-scaled test geometry. A cut-geometry
// collector should directly supply exactly integrated centered face data.
inline void FillFacePolynomialMoments(FaceGeometry& f) {
    f.gram.setZero();
    f.mixed.setZero();
    for (unsigned i=0; i<3; ++i) {
        for (unsigned m=0; m<10; ++m)
            for (unsigned a=0; a<4; ++a)
                f.mixed(i,m) += f.basis(i,a)*f.area[ProductIndex(a,m)];
        for (unsigned j=0; j<3; ++j)
            for (unsigned a=0; a<4; ++a)
                for (unsigned b=0; b<4; ++b)
                    f.gram(i,j) += f.basis(i,a)*f.basis(j,b)*f.area[ProductIndex(a,b)];
    }
}

// Diagonal equilibration removes units and extreme scalar measure. It does
// not delete a small face or turn a geometrically singular face into a valid
// one. Nonrepresentable positive geometry is rejected explicitly.
inline Matrix PositiveInverse(const Matrix& input, const char* description) {
    if (input.rows()!=input.cols() || !input.allFinite())
        throw std::runtime_error(description);
    Vector scale(input.rows());
    for (Eigen::Index i=0; i<input.rows(); ++i) {
        if (!(input(i,i)>0)) throw std::runtime_error(description);
        scale(i)=1/std::sqrt(input(i,i));
    }
    Matrix equilibrated=scale.asDiagonal()*input*scale.asDiagonal();
    equilibrated=(equilibrated+equilibrated.transpose()).eval()/2;
    Eigen::LLT<Matrix> factor(equilibrated);
    if (factor.info()!=Eigen::Success) throw std::runtime_error(description);
    Matrix inverse=scale.asDiagonal()*factor.solve(Matrix::Identity(input.rows(),input.cols()))*scale.asDiagonal();
    if (!inverse.allFinite()) throw std::runtime_error(description);
    return (inverse+inverse.transpose()).eval()/2;
}

struct LocalOperator {
    CellGeometry geometry;
    unsigned dimension = 0;
    Real lengthScale = 0;
    Matrix polynomialDofs; // N: raw DOFs from component-major affine coefficients
    Matrix momentOperator; // integral v_a*[1,rx,ry,rz], component major
    Matrix projection;    // L: affine L2 coefficient projection from raw DOFs
    Matrix divergence;    // coefficients of div(v) in [1,rx,ry,rz]
    Matrix divergenceMoments;
    Matrix polynomialGram; // unweighted integral vector-P1 dot vector-P1
    Matrix mass;           // physical kinetic metric: energy=.5*d^T mass*d
    Matrix stabilization;  // S, explicit unresolved kinetic model
    std::vector<Mat3> inverseFaceGram;
    // Rows map primary face DOFs to boundary monomial normal moments. These
    // operators remain authoritative even when projection has a different
    // boundary normal. In particular no postprojection overwrite is performed.
    std::vector<Eigen::Matrix<Real,10,3>> faceNormalMoments;
    Real polynomialReproductionError = 0;
    Real divergenceReproductionError = 0;

    unsigned MeanOffset() const { return 3*geometry.faces.size(); }
    unsigned AngularOffset() const { return MeanOffset()+3; }

    Vector InterpolateAffineDOFs(const Affine& coefficients) const {
        return polynomialDofs*coefficients;
    }
    Affine Project(const Vector& dofs) const { return projection*dofs; }
    Eigen::Matrix<Real,4,1> Divergence(const Vector& dofs) const {
        return divergence*dofs;
    }
    Vec3 FaceNormalCoefficients(unsigned face, const Vector& dofs) const {
        return inverseFaceGram.at(face)*dofs.template segment<3>(3*face);
    }
    Real EvaluateFaceNormal(unsigned face, const Vector& dofs, const Vec3& r) const {
        const auto& geometry= this->geometry.faces.at(face);
        if (geometry.anchoredBasis) {
            const Vec3 psi=geometry.basisAtOrigin+geometry.basis.template rightCols<3>()*(r-geometry.evaluationOrigin);
            return psi.dot(FaceNormalCoefficients(face,dofs));
        }
        Eigen::Matrix<Real,4,1> p;
        p << 1,r.x(),r.y(),r.z();
        return (geometry.basis*p).dot(FaceNormalCoefficients(face,dofs));
    }
    Eigen::Matrix<Real,10,1> FaceNormalMoments(unsigned face, const Vector& dofs) const {
        return faceNormalMoments.at(face)*dofs.template segment<3>(3*face);
    }
    Real Energy(const Vector& dofs) const { return dofs.dot(mass*dofs)/2; }
};

inline Vec3 EvaluateAffine(const Affine& coefficients, const Vec3& r) {
    Eigen::Matrix<Real,4,1> p;
    p << 1,r.x(),r.y(),r.z();
    Vec3 result;
    for (unsigned a=0; a<3; ++a) result(a)=coefficients.template segment<4>(4*a).dot(p);
    return result;
}

inline Affine RigidAffine(const Vec3& velocityAtCellCenter, const Vec3& omega) {
    Affine a=Affine::Zero();
    a.template segment<4>(0) << velocityAtCellCenter.x(),0,-omega.z(),omega.y();
    a.template segment<4>(4) << velocityAtCellCenter.y(),omega.z(),0,-omega.x();
    a.template segment<4>(8) << velocityAtCellCenter.z(),-omega.y(),omega.x(),0;
    return a;
}

inline LocalOperator Build(const CellGeometry& g) {
    LocalOperator op;
    op.geometry=g;
    const Real volume=g.volume[0];
    if (!(volume>0) || !std::isfinite(volume) || !(g.density>0) || !std::isfinite(g.density))
        throw std::runtime_error("VEM requires positive finite volume and density");
    if (g.faces.size()<4) throw std::runtime_error("VEM cell lacks closed polyhedral boundary");
    const unsigned d=3*g.faces.size()+6;
    op.dimension=d;
    op.lengthScale=std::cbrt(volume);
    op.polynomialDofs=Matrix::Zero(d,12);
    op.momentOperator=Matrix::Zero(12,d);
    op.divergenceMoments=Matrix::Zero(4,d);
    op.stabilization=Matrix::Zero(d,d);
    op.polynomialGram=Matrix::Zero(12,12);
    Matrix scalarGram(4,4);
    for (unsigned i=0; i<4; ++i)
        for (unsigned j=0; j<4; ++j)
            scalarGram(i,j)=g.volume[ProductIndex(i,j)];
    const Matrix inverseScalarGram=PositiveInverse(scalarGram,"VEM volume P1 Gram is not positive/representable");
    for (unsigned a=0; a<3; ++a) op.polynomialGram.block(4*a,4*a,4,4)=scalarGram;
    for (unsigned f=0; f<g.faces.size(); ++f) {
        const auto& face=g.faces[f];
        if (!(face.area[0]>0) || !face.normal.allFinite() || std::abs(face.normal.squaredNorm()-1)>1e-10L)
            throw std::runtime_error("VEM face requires positive area and outward unit normal");
        const Matrix inverseGram=PositiveInverse(face.gram,"VEM face P1 Gram is not positive/representable");
        op.inverseFaceGram.push_back(inverseGram);
        Eigen::Matrix<Real,10,3> boundary=face.mixed.transpose()*inverseGram;
        if(face.basis(0,0)!=1||face.basis.template block<1,3>(0,1).squaredNorm()!=0)
            throw std::runtime_error("VEM primary face moment must use psi0=1");
        // q0 IS the integrated normal flux by definition. Computing this
        // identity through a rounded Gram inverse would introduce a spurious
        // violation of the exact shared-face incidence/gauge identity.
        boundary.row(0)<<1,0,0;
        op.faceNormalMoments.push_back(boundary);
        for (unsigned a=0; a<3; ++a)
            for (unsigned j=0; j<4; ++j)
                op.polynomialDofs.block(3*f,4*a+j,3,1)=face.normal(a)*face.mixed.col(j);
        op.divergenceMoments.block(0,3*f,4,3)=boundary.topRows<4>();
        op.stabilization.block(3*f,3*f,3,3)=g.density*op.lengthScale*inverseGram;
    }
    const unsigned mean=op.MeanOffset(), angular=op.AngularOffset();
    for (unsigned a=0; a<3; ++a) {
        op.divergenceMoments(a+1,mean+a)=-1;
        op.momentOperator(4*a,mean+a)=1;
        for (unsigned j=0; j<4; ++j) op.polynomialDofs(mean+a,4*a+j)=g.volume[j];
    }
    // For v_a=s_j, integral (r cross v)_b=epsilon_bca integral r_c*s_j.
    for (unsigned b=0; b<3; ++b) {
        const unsigned c=(b+1)%3, a=(b+2)%3;
        for (unsigned j=0; j<4; ++j) {
            op.polynomialDofs(angular+b,4*a+j)=g.volume[ProductIndex(c+1,j)];
            op.polynomialDofs(angular+b,4*c+j)=-g.volume[ProductIndex(a+1,j)];
        }
    }
    op.divergence=inverseScalarGram*op.divergenceMoments;
    // Green's identity for quadratic q:
    // integral grad(q).v = boundary q*vn - integral q*div(v).
    // The six symmetric first velocity moments follow, while the three skew
    // moments are exactly the authored angular DOFs.
    for (unsigned a=0; a<3; ++a) {
        for (unsigned b=a; b<3; ++b) {
            const unsigned q=ProductIndex(a+1,b+1);
            Eigen::Matrix<Real,1,Eigen::Dynamic> sum=Matrix::Zero(1,d);
            for (unsigned f=0; f<g.faces.size(); ++f)
                sum.template segment<3>(3*f)=op.faceNormalMoments[f].row(q);
            Eigen::Matrix<Real,1,4> divMoment;
            for (unsigned j=0; j<4; ++j) divMoment(j)=g.volume[ProductIndex(q,j)];
            sum-=divMoment*op.divergence;
            if (a==b) {
                op.momentOperator.row(4*a+b+1)=sum/2;
            } else {
                // T_ab=integral r_b*v_a; T_ab+T_ba=sum. The signs
                // follow (r cross v)_0=T_21-T_12, etc.
                Eigen::Matrix<Real,1,Eigen::Dynamic> skew=Matrix::Zero(1,d);
                const unsigned remaining=3-a-b;
                const Real sign=((a+1)%3==b) ? -1 : 1;
                skew(angular+remaining)=sign;
                op.momentOperator.row(4*a+b+1)=(sum+skew)/2;
                op.momentOperator.row(4*b+a+1)=(sum-skew)/2;
            }
        }
    }
    op.projection=Matrix::Zero(12,d);
    for (unsigned a=0; a<3; ++a)
        op.projection.block(4*a,0,4,d)=inverseScalarGram*op.momentOperator.block(4*a,0,4,d);
    op.stabilization.block(mean,mean,3,3)=Mat3::Identity()*(g.density/volume);
    op.stabilization.block(angular,angular,3,3)=Mat3::Identity()*(g.density/(volume*op.lengthScale*op.lengthScale));
    const Matrix kernel=Matrix::Identity(d,d)-op.polynomialDofs*op.projection;
    op.mass=g.density*op.projection.transpose()*op.polynomialGram*op.projection
        +kernel.transpose()*op.stabilization*kernel;
    op.mass=(op.mass+op.mass.transpose()).eval()/2;
    op.polynomialReproductionError=(op.projection*op.polynomialDofs-Matrix::Identity(12,12)).cwiseAbs().maxCoeff();
    Matrix expectedDivergence=Matrix::Zero(4,12);
    for (unsigned a=0; a<3; ++a) expectedDivergence(0,4*a+a+1)=1;
    op.divergenceReproductionError=(op.divergence*op.polynomialDofs-expectedDivergence).cwiseAbs().maxCoeff();
    if (!op.mass.allFinite() || !op.projection.allFinite())
        throw std::runtime_error("VEM local operator is nonfinite");
    return op;
}

} // namespace JudasFluidVem
