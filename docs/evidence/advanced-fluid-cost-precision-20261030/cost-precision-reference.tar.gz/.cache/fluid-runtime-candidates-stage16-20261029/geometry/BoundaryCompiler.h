#pragma once

// Isolated Stage16 boundary-only subtractor. The native exact plane/vertex
// predicates remain authoritative. A convex six-plane solid is subtracted
// sequentially from one original background tetrahedron, producing at most
// six convex fluid pieces. No full plane arrangement or emitted cut mesh is
// built. Temporary positive simplices serve integration only, never physics
// DOFs or collision proxies.
#include "PolyhedralMoments.h"

namespace stage16_boundary {

using stage16_geometry::R;
using stage16_geometry::RV;
using stage16_geometry::Sub;
using stage16_geometry::BoundaryTriangle;
using Box = std::array<fluid_exact::Plane,6>;
using Polyhedron = motion_mesh::Polyhedron;

struct VolumeSimplex {
    std::array<RV,4> points;
    R volume=0;
};

struct Compiler {
    motion_mesh::Compiler mesh;
    Polyhedron seed,solid;
    std::vector<Polyhedron> outside;
    std::vector<unsigned> splitPlanes;
    std::vector<unsigned> component;
    std::vector<BoundaryTriangle> boundary;
    std::vector<VolumeSimplex> integration;
    R volume=0;
    RV center{};
    bool centerIsCentroid=false;
    unsigned components=0;
    unsigned seedId=0;
    // A separate local operator is necessary for every positive-volume
    // connected wet component. This initial bounded compiler detects that
    // topology and explicitly rejects multi-component seeds; it never joins
    // disconnected regions through a shared pressure or velocity unknown.
    bool rejectDisconnected=true;

    std::map<unsigned,RV> positions;

    const RV& Position(unsigned vertex) {
        auto found=positions.find(vertex);
        if(found!=positions.end()) return found->second;
        return positions.emplace(vertex,owned_metrics::Position(mesh.vertices.at(vertex).exact)).first->second;
    }

    bool PositiveFace(const motion_mesh::Face& face) {
        if(face.vertices.size()<3) return false;
        const auto& p=Position(face.vertices[0]);
        for(unsigned i=1;i+1<face.vertices.size();++i) {
            const RV area=owned_metrics::Cross(Sub(Position(face.vertices[i]),p),
                                               Sub(Position(face.vertices[i+1]),p));
            if(area[0]!=0 || area[1]!=0 || area[2]!=0) return true;
        }
        return false;
    }

    void AppendBoundary(const motion_mesh::Face& face,bool reverse) {
        if(face.vertices.size()<3) return;
        const auto& a=Position(face.vertices[0]);
        for(unsigned i=1;i+1<face.vertices.size();++i) {
            BoundaryTriangle triangle;
            triangle.points={a,Position(face.vertices[i]),Position(face.vertices[i+1])};
            triangle.areaVector=owned_metrics::Cross(Sub(triangle.points[1],a),Sub(triangle.points[2],a));
            if(triangle.areaVector[0]==0 && triangle.areaVector[1]==0 && triangle.areaVector[2]==0) continue;
            for(auto& value:triangle.areaVector) value/=2;
            if(reverse) {
                std::swap(triangle.points[1],triangle.points[2]);
                for(auto& value:triangle.areaVector) value=-value;
            }
            triangle.plane=face.plane;
            boundary.push_back(std::move(triangle));
        }
    }

    motion_mesh::Face ClipFace(const motion_mesh::Face& polygon,unsigned plane,int keep) {
        motion_mesh::Face result{polygon.plane,{}};
        if(polygon.vertices.empty()) return result;
        // A new edge belongs either to an original seed edge or to an earlier
        // cut plane. All candidates remain exactly owned; the native CutEdge
        // routine proves the independent three-plane intersection. A distance
        // or rounded-coordinate weld never invents an edge-plane identity.
        Polyhedron supports;
        for(unsigned p=0;p<mesh.planes.size();++p) supports.faces.push_back({p,{}});
        for(unsigned i=0;i<polygon.vertices.size();++i) {
            const unsigned a=polygon.vertices[i],b=polygon.vertices[(i+1)%polygon.vertices.size()];
            const int sa=keep*mesh.Side(a,plane),sb=keep*mesh.Side(b,plane);
            if(sa<=0) result.vertices.push_back(a);
            if((sa<0 && sb>0) || (sa>0 && sb<0))
                result.vertices.push_back(mesh.CutEdge(a,b,polygon.plane,plane,supports));
        }
        result.vertices.erase(std::unique(result.vertices.begin(),result.vertices.end()),result.vertices.end());
        if(result.vertices.size()>1 && result.vertices.front()==result.vertices.back()) result.vertices.pop_back();
        if(result.vertices.size()<3) result.vertices.clear();
        return result;
    }

    void AppendTouchCorrectedBackground(const motion_mesh::Face& background) {
        unsigned contactPlane=~0u;
        const RV origin=Position(background.vertices[0]);
        RV area{};
        for(unsigned i=1;i+1<background.vertices.size();++i) {
            area=owned_metrics::Cross(Sub(Position(background.vertices[i]),origin),
                                       Sub(Position(background.vertices[i+1]),origin));
            if(area[0]!=0 || area[1]!=0 || area[2]!=0) break;
        }
        for(unsigned plane:mesh.bodyPlanes) {
            bool coincident=true;
            for(unsigned vertex:background.vertices) coincident&=mesh.Side(vertex,plane)==0;
            if(!coincident) continue;
            const auto& definition=mesh.planes[plane];
            const RV normal={R(definition.normal[0]),R(definition.normal[1]),R(definition.normal[2])};
            if(owned_metrics::Dot(area,normal)<0) { contactPlane=plane;break; }
        }
        if(contactPlane==~0u) { AppendBoundary(background,false);return; }

        auto remaining=background;
        std::vector<motion_mesh::Face> exposed;
        for(unsigned plane:mesh.bodyPlanes) {
            bool outsideArea=false;
            for(unsigned vertex:remaining.vertices) outsideArea|=mesh.Side(vertex,plane)>0;
            if(outsideArea) {
                auto patch=ClipFace(remaining,plane,-1);
                if(PositiveFace(patch)) exposed.push_back(std::move(patch));
            }
            remaining=ClipFace(remaining,plane,1);
            if(!PositiveFace(remaining)) break;
        }
        if(!PositiveFace(remaining)) { AppendBoundary(background,false);return; }
        for(const auto& patch:exposed) AppendBoundary(patch,false);
        // A body may have zero volume INSIDE this fluid seed but still own a
        // positive-area wetted face at its boundary. Keep that exact footprint
        // as a body face, not as an open fluid interface into the solid. The
        // existing fluid-outward winding is correct and is NOT reversed here.
        remaining.plane=contactPlane;
        AppendBoundary(remaining,false);
    }

    void AddIntegration(const Polyhedron& piece) {
        std::set<unsigned> ids;
        for(const auto& face:piece.faces) ids.insert(face.vertices.begin(),face.vertices.end());
        if(ids.size()<4) throw std::runtime_error("boundary compiler convex piece lacks 3D interior");
        // A boundary anchor gives a positive pulling cone without manufacturing
        // a rational volume-centroid denominator or inserting a mesh vertex.
        unsigned anchor=*ids.begin();
        for(unsigned vertex:ids) if(Position(vertex)<Position(anchor)) anchor=vertex;
        const RV a=Position(anchor);
        for(const auto& face:piece.faces) {
            if(mesh.Side(anchor,face.plane)==0) continue;
            const RV b=Position(face.vertices[0]);
            for(unsigned i=1;i+1<face.vertices.size();++i) {
                const RV c=Position(face.vertices[i]),d=Position(face.vertices[i+1]);
                const R measure=owned_metrics::Dot(Sub(b,a),owned_metrics::Cross(Sub(c,a),Sub(d,a)))/6;
                if(measure==0) continue;
                if(measure<0) throw std::runtime_error("boundary compiler convex cone has negative orientation");
                integration.push_back({{a,b,c,d},measure});
                volume+=measure;
            }
        }
    }

    void ClassifyComponents() {
        component.resize(outside.size());
        std::iota(component.begin(),component.end(),0);
        const auto root=[&](unsigned p) { while(component[p]!=p) p=component[p];return p; };
        for(unsigned earlier=0;earlier<outside.size();++earlier) {
            const unsigned plane=splitPlanes[earlier];
            if(plane==~0u) continue;
            bool cap=false;
            for(const auto& face:outside[earlier].faces)
                if(face.plane==plane && PositiveFace(face)) { cap=true;break; }
            if(!cap) continue;
            for(unsigned later=earlier+1;later<outside.size();++later) {
                // Sequential subtraction gives outside[earlier] its cap on
                // plane k. Every later piece is a subset of the opposite
                // retained convex half; therefore its inherited plane-k face
                // is provably contained in that cap. Positive exact area is
                // both necessary and sufficient for this pair's hydraulic
                // adjacency. Edge/vertex contact alone does not join cells.
                for(const auto& face:outside[later].faces)
                    if(face.plane==plane && PositiveFace(face)) {
                        component[root(later)]=root(earlier);
                        break;
                    }
            }
        }
        std::set<unsigned> unique;
        for(unsigned i=0;i<component.size();++i) component[i]=root(i);
        for(unsigned c:component) unique.insert(c);
        components=unique.size();
        if(rejectDisconnected && components>1)
            throw std::runtime_error("boundary compiler requires separate local operators for disconnected wet pieces");
    }

    void Build(unsigned grid,unsigned selectedSeed,const Box& box) {
        if(!mesh.planes.empty() || !outside.empty() || !boundary.empty())
            throw std::invalid_argument("boundary compiler instance already owns geometry");
        if(!grid || grid>8 || selectedSeed>=6*grid*grid*grid)
            throw std::invalid_argument("boundary compiler seed outside bounded grid");
        seedId=selectedSeed;
        for(const auto& plane:box)
            mesh.bodyPlanes.push_back(mesh.AddPlane({plane.normal[0],plane.normal[1],plane.normal[2]},plane.coordinate));
        constexpr unsigned cubeTets[6][4]={{0,1,3,7},{0,3,2,7},{0,2,6,7},{0,6,4,7},{0,4,5,7},{0,5,1,7}};
        const unsigned voxel=selectedSeed/6,x=voxel%grid,y=(voxel/grid)%grid,z=voxel/(grid*grid);
        const auto indices=cubeTets[selectedSeed%6];
        std::array<motion_mesh::Lattice,8> corners;
        for(unsigned i=0;i<8;++i) corners[i]={int(x+(i&1)),int(y+((i>>1)&1)),int(z+((i>>2)&1))};
        seed=mesh.Seed({corners[indices[0]],corners[indices[1]],corners[indices[2]],corners[indices[3]]});
        seed.voxel=(y*grid+z)*grid+x;
        seed.seed=selectedSeed;
        solid=seed;
        for(unsigned cut=0;cut<6 && !solid.faces.empty();++cut) {
            const unsigned plane=mesh.bodyPlanes[cut];
            auto exterior=mesh.Clip(solid,plane,-1);
            if(!exterior.faces.empty()) {
                outside.push_back(std::move(exterior));
                splitPlanes.push_back(plane);
            }
            solid=mesh.Clip(solid,plane,1);
        }
        if(solid.faces.empty()) {
            // Exact empty intersection, including a mere tangent. Preserve
            // the uncut original fluid seed and avoid artificial partitions.
            outside={seed};
            splitPlanes={~0u};
        }
        ClassifyComponents();
        if(outside.empty()) return; // seed is wholly occupied by the solid

        std::set<unsigned> background;
        for(const auto& entry:mesh.backgroundFaces) background.insert(entry.second);
        for(const auto& piece:outside) {
            AddIntegration(piece);
            for(const auto& face:piece.faces)
                if(background.count(face.plane)) {
                    if(solid.faces.empty()) AppendTouchCorrectedBackground(face);
                    else AppendBoundary(face,false);
                }
        }
        // The solid's external face points into fluid, opposite to the
        // required outward normal of the fluid. Artificial outside-piece
        // partitions are never retained as fluid boundaries.
        std::set<unsigned> body(mesh.bodyPlanes.begin(),mesh.bodyPlanes.end());
        for(const auto& face:solid.faces)
            if(body.count(face.plane)) AppendBoundary(face,true);
        if(!(volume>0) || integration.empty() || boundary.empty())
            throw std::runtime_error("boundary compiler lost positive fluid geometry");
        RV low=integration[0].points[0],high=low;
        for(const auto& simplex:integration) for(const auto& point:simplex.points)
            for(unsigned a=0;a<3;++a) {
                low[a]=std::min(low[a],point[a]);
                high[a]=std::max(high[a],point[a]);
            }
        // Bounded exact reference, deliberately NOT the volume centroid.
        // All three first moments must be integrated and retained downstream.
        for(unsigned a=0;a<3;++a) center[a]=(low[a]+high[a])/2;
    }
};

} // namespace stage16_boundary
