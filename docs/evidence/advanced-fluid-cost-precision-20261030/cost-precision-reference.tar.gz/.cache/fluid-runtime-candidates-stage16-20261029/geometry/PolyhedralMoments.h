#pragma once
// Exact geometric integration for the Stage16 bounded H(div) candidate.
// Triangulation is an integration oracle only: it creates no velocity unknowns.
#include "../../fluid-moving-geometry-stage13-20261029/MotionCompiler.h"
#include "../vem/VemLocal.h"
#include <numeric>
#include <sstream>
namespace stage16_geometry {
using R=owned_metrics::R;
using RV=owned_metrics::RV;
namespace vem=JudasFluidVem;
using ExactMoments=std::array<R,20>;
inline RV Sub(RV a,const RV& b){for(unsigned i=0;i<3;++i)a[i]-=b[i];return a;}
inline R Power(R x,unsigned n){R y=1;while(n--){y*=x;}return y;}
inline unsigned Factorial(unsigned n){unsigned v=1;for(unsigned i=2;i<=n;++i)v*=i;return v;}
inline R TriangleAverage(const std::array<RV,3>& p,unsigned x,unsigned y,unsigned z){
    // Exact Dirichlet barycentric polynomial integration, degree at most three.
    std::vector<unsigned> axes;for(unsigned i=0;i<x;++i)axes.push_back(0);for(unsigned i=0;i<y;++i)axes.push_back(1);for(unsigned i=0;i<z;++i)axes.push_back(2);
    R result=0;std::array<unsigned,3> counts{};
    const auto visit=[&](auto&& self,unsigned depth,R product)->void {
        if(depth==axes.size()){unsigned w=2;for(unsigned c:counts)w*=Factorial(c);result+=product*R(w)/Factorial(axes.size()+2);return;}
        for(unsigned v=0;v<3;++v){++counts[v];self(self,depth+1,product*p[v][axes[depth]]);--counts[v];}
    };visit(visit,0,R(1));return result;
}
struct BoundaryTriangle {std::array<RV,3> points;RV areaVector;unsigned plane=0;};
struct Face {
    int solid=-1;
    std::array<motion_mesh::Lattice,3> background{};
    std::vector<BoundaryTriangle> triangles;
    ExactMoments projected{};
    unsigned pivot=0,u=0,v=0;
    R measure=0,meanU=0,meanV=0,varU=0,cov=0,varV=0;
};
struct Cell {
    RV center{};
    vem::CellGeometry geometry;
    std::vector<Face> faces;
    unsigned fineTets=0;
};
inline std::vector<BoundaryTriangle> Boundary(const motion_mesh::Compiler& mesh){
    struct Incidence {std::array<unsigned,3> vertices;unsigned opposite=0,count=0;};
    std::map<std::array<unsigned,3>,Incidence> records;
    std::vector<unsigned> parent(mesh.tetrahedra.size());std::iota(parent.begin(),parent.end(),0);
    std::map<std::array<unsigned,3>,unsigned> owner;
    const auto root=[&](unsigned c){while(parent[c]!=c)c=parent[c];return c;};
    constexpr unsigned corners[4][3]={{1,2,3},{0,2,3},{0,1,3},{0,2,1}};
    for(unsigned t=0;t<mesh.tetrahedra.size();++t){const auto& tet=mesh.tetrahedra[t];for(unsigned f=0;f<4;++f){std::array<unsigned,3> ids;for(unsigned j=0;j<3;++j)ids[j]=tet.vertices[corners[f][j]];auto key=ids;std::sort(key.begin(),key.end());auto& record=records[key];if(record.count==0){record.vertices=ids;record.opposite=tet.vertices[f];owner[key]=t;}else parent[root(t)]=root(owner.at(key));if(++record.count>2)throw std::runtime_error("nonmanifold exact integration mesh");}}
    std::set<unsigned> components;for(unsigned t=0;t<parent.size();++t)components.insert(root(t));
    if(components.size()>1)throw std::runtime_error("Stage16 requires separate operators for disconnected pieces within one seed");
    std::vector<BoundaryTriangle> result;
    for(const auto& [key,record]:records)if(record.count==1){BoundaryTriangle tri;for(unsigned j=0;j<3;++j)tri.points[j]=owned_metrics::Position(mesh.vertices[record.vertices[j]].exact);
        tri.areaVector=owned_metrics::Cross(Sub(tri.points[1],tri.points[0]),Sub(tri.points[2],tri.points[0]));for(auto& x:tri.areaVector)x/=2;
        const RV inwardVector=Sub(owned_metrics::Position(mesh.vertices[record.opposite].exact),tri.points[0]);
        if(owned_metrics::Dot(tri.areaVector,inwardVector)>0){std::swap(tri.points[1],tri.points[2]);for(auto& x:tri.areaVector)x=-x;}
        bool found=false,inside=true;
        for(unsigned p:mesh.bodyPlanes)for(unsigned v:record.vertices)inside&=mesh.Side(v,p)<=0;
        if(inside)for(unsigned p:mesh.bodyPlanes){bool on=true;for(unsigned v:record.vertices)on&=mesh.Side(v,p)==0;if(on){tri.plane=p;found=true;break;}}
        if(!found)for(const auto& [key,p]:mesh.backgroundFaces){bool on=true;for(unsigned v:record.vertices)on&=mesh.Side(v,p)==0;if(on){tri.plane=p;found=true;break;}}
        if(!found)throw std::runtime_error("boundary triangle has no exact supporting plane");
        result.push_back(std::move(tri));}
    return result;
}
inline Cell Collect(const motion_mesh::Compiler& mesh){
    Cell cell;cell.fineTets=mesh.tetrahedra.size();if(mesh.tetrahedra.empty())return cell;
    R volume=0;RV first{};
    for(const auto& tet:mesh.tetrahedra){std::array<RV,4> p;for(unsigned i=0;i<4;++i)p[i]=owned_metrics::Position(mesh.vertices[tet.vertices[i]].exact);const R w=owned_metrics::Dot(Sub(p[1],p[0]),owned_metrics::Cross(Sub(p[2],p[0]),Sub(p[3],p[0])))/6;if(w<=0)throw std::runtime_error("invalid exact tetrahedron");volume+=w;for(unsigned a=0;a<3;++a)for(unsigned i=0;i<4;++i)first[a]+=w*p[i][a]/4;}
    for(unsigned a=0;a<3;++a)cell.center[a]=first[a]/volume;
    auto boundary=Boundary(mesh);std::map<unsigned,unsigned> groups;
    for(auto tri:boundary){auto [at,inserted]=groups.emplace(tri.plane,cell.faces.size());if(inserted){Face face;bool identified=false;
        for(unsigned s=0;s<mesh.bodyPlanes.size();++s)if(tri.plane==mesh.bodyPlanes[s]){face.solid=int(s);identified=true;}
        if(!identified)for(const auto& [key,plane]:mesh.backgroundFaces)if(plane==tri.plane){face.background=key;identified=true;break;}
        if(!identified)throw std::runtime_error("unclassified owned boundary");
        cell.faces.push_back(std::move(face));}
        for(auto& p:tri.points)p=Sub(p,cell.center);
        cell.faces[at->second].triangles.push_back(std::move(tri));}
    ExactMoments vm{};
    for(auto& face:cell.faces){const auto area=face.triangles[0].areaVector;face.pivot=0;for(unsigned a=1;a<3;++a)if(abs(area[a])>abs(area[face.pivot]))face.pivot=a;
        if(area[face.pivot]==0)throw std::runtime_error("zero-area boundary");
        face.u=(face.pivot+1)%3;face.v=(face.pivot+2)%3;
        for(const auto& tri:face.triangles){const R projected=abs(tri.areaVector[face.pivot]);const R radial=owned_metrics::Dot(tri.points[0],tri.areaVector);
            for(unsigned m=0;m<20;++m){const auto& p=vem::Powers[m];const R average=TriangleAverage(tri.points,p[0],p[1],p[2]);face.projected[m]+=projected*average;vm[m]+=radial*average/(p[0]+p[1]+p[2]+3);}}
        face.measure=face.projected[0];if(face.measure<=0)throw std::runtime_error("zero exact face measure");
        const unsigned iu=1+face.u,iv=1+face.v;
        face.meanU=face.projected[iu]/face.measure;face.meanV=face.projected[iv]/face.measure;
        face.varU=face.projected[vem::ProductIndex(iu,iu)]/face.measure-face.meanU*face.meanU;
        face.cov=face.projected[vem::ProductIndex(iu,iv)]/face.measure-face.meanU*face.meanV;
        face.varV=face.projected[vem::ProductIndex(iv,iv)]/face.measure-face.meanV*face.meanV;
        const R conditional=face.varV-face.cov*face.cov/face.varU;
        if(face.varU<=0||conditional<=0)throw std::runtime_error("degenerate exact face covariance");
        const vem::Real su=sqrt(face.varU.convert_to<vem::Real>()),sv=sqrt(conditional.convert_to<vem::Real>()),k=(face.cov/face.varU).convert_to<vem::Real>();
        vem::FaceGeometry out;vem::Vec3 ratio;for(unsigned a=0;a<3;++a)ratio[a]=(area[a]/abs(area[face.pivot])).convert_to<vem::Real>();const auto metric=ratio.norm();out.normal=ratio/metric;
        for(unsigned m=0;m<20;++m)out.area[m]=face.projected[m].convert_to<vem::Real>()*metric;
        out.basis(0,0)=1;out.basis(1,iu)=1/su;out.basis(1,0)=-face.meanU.convert_to<vem::Real>()/su;
        out.basis(2,iv)=1/sv;out.basis(2,iu)=-k/sv;out.basis(2,0)=(-face.meanV+face.cov/face.varU*face.meanU).convert_to<vem::Real>()/sv;
        out.anchoredBasis=true;out.basisAtOrigin=vem::Vec3(1,0,0);
        out.evaluationOrigin[iu-1]=face.meanU.convert_to<vem::Real>();
        out.evaluationOrigin[iv-1]=face.meanV.convert_to<vem::Real>();
        out.gram=vem::Mat3::Identity()*out.area[0];
        for(unsigned m=0;m<10;++m){out.mixed(0,m)=out.area[m];const R cu=face.projected[vem::ProductIndex(iu,m)]-face.meanU*face.projected[m];const R cv=face.projected[vem::ProductIndex(iv,m)]-face.meanV*face.projected[m];out.mixed(1,m)=cu.convert_to<vem::Real>()*metric/su;out.mixed(2,m)=(cv-face.cov/face.varU*cu).convert_to<vem::Real>()*metric/sv;}
        cell.geometry.faces.push_back(std::move(out));
    }
    if(vm[0]!=volume)throw std::runtime_error("boundary/tetra exact volumes differ");
    for(unsigned m=0;m<20;++m)cell.geometry.volume[m]=vm[m].convert_to<vem::Real>();
    return cell;
}
} // namespace stage16_geometry
