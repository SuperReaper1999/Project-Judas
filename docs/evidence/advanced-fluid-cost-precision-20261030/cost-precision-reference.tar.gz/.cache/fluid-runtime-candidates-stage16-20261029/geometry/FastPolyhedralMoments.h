#pragma once

// Stage16 PRIVATE geometry-integration experiment. Exact topology, orientation,
// ownership, volume/centroid and face P2 metrics are retained. High-order kinetic
// moments use bounded-frame long-double simplex integration, not rational P3.
// This does not establish a dynamic-fluid or native-coupling acceptance claim.
#include "PolyhedralMoments.h"

namespace stage16_fast_geometry {

using stage16_geometry::R;
using stage16_geometry::RV;
using stage16_geometry::Cell;
using stage16_geometry::Face;
using stage16_geometry::BoundaryTriangle;
using stage16_geometry::Sub;
namespace vem=JudasFluidVem;
using Real=vem::Real;
using Point=std::array<Real,3>;

struct Sum {
    Real value=0, correction=0;
    void Add(Real x) {
        const Real next=value+x;
        if(std::abs(value)>=std::abs(x)) correction+=(value-next)+x;
        else correction+=(x-next)+value;
        value=next;
    }
    Real Get() const { return value+correction; }
};

// Uniform barycentric simplex averages of products of up to three affine
// functions, given each function's values at all N simplex vertices. This
// closed form includes repeated factors/coordinates without combinatorial
// rational expansions.
template<unsigned N>
inline Real ProductAverage(const std::array<std::array<Real,N>,3>& f,unsigned degree) {
    if(degree==0) return 1;
    std::array<Real,3> s{};
    for(unsigned i=0;i<degree;++i)
        for(unsigned vertex=0;vertex<N;++vertex) s[i]+=f[i][vertex];
    if(degree==1) return s[0]/N;
    Real q01=0;
    for(unsigned vertex=0;vertex<N;++vertex) q01+=f[0][vertex]*f[1][vertex];
    if(degree==2) return (s[0]*s[1]+q01)/(N*(N+1));
    if(degree!=3) throw std::runtime_error("fast simplex integrator supports P3 only");
    Real q02=0,q12=0,triple=0;
    for(unsigned vertex=0;vertex<N;++vertex) {
        q02+=f[0][vertex]*f[2][vertex];
        q12+=f[1][vertex]*f[2][vertex];
        triple+=f[0][vertex]*f[1][vertex]*f[2][vertex];
    }
    return (s[0]*s[1]*s[2]+q01*s[2]+q02*s[1]+q12*s[0]+2*triple)
           /(N*(N+1)*(N+2));
}

template<unsigned N>
inline Real MonomialAverage(const std::array<Point,N>& points,unsigned monomial) {
    std::array<std::array<Real,N>,3> factors{};
    unsigned degree=0;
    for(unsigned axis=0;axis<3;++axis)
        for(unsigned power=0;power<vem::Powers[monomial][axis];++power) {
            if(degree==3) throw std::runtime_error("fast monomial exceeds P3");
            for(unsigned vertex=0;vertex<N;++vertex)
                factors[degree][vertex]=points[vertex][axis];
            ++degree;
        }
    return ProductAverage<N>(factors,degree);
}

inline Real WeightedFaceAverage(const std::array<Point,3>& points,
                                const std::array<Real,3>& weight,unsigned monomial) {
    std::array<std::array<Real,3>,3> factors{};
    factors[0]=weight;
    unsigned degree=1;
    for(unsigned axis=0;axis<3;++axis)
        for(unsigned power=0;power<vem::Powers[monomial][axis];++power) {
            if(degree==3) throw std::runtime_error("mixed face moment exceeds P3");
            for(unsigned vertex=0;vertex<3;++vertex)
                factors[degree][vertex]=points[vertex][axis];
            ++degree;
        }
    return ProductAverage<3>(factors,degree);
}

inline Point Rounded(const RV& point) {
    return {point[0].convert_to<Real>(),point[1].convert_to<Real>(),point[2].convert_to<Real>()};
}

inline std::array<R,10> ExactTriangleP2(const std::array<RV,3>& points) {
    RV sum{};
    for(const auto& p:points)
        for(unsigned axis=0;axis<3;++axis) sum[axis]+=p[axis];
    std::array<R,10> average{};
    average[0]=1;
    for(unsigned axis=0;axis<3;++axis) average[axis+1]=sum[axis]/3;
    for(unsigned a=0;a<3;++a)
        for(unsigned b=a;b<3;++b) {
            R value=sum[a]*sum[b];
            for(const auto& p:points) value+=p[a]*p[b];
            average[vem::ProductIndex(a+1,b+1)]=value/12;
        }
    return average;
}

template<class Integration>
inline Cell CollectPrepared(const motion_mesh::Compiler& mesh,
                            const std::vector<BoundaryTriangle>& boundary,
                            const Integration& integration,
                            const R& volume,const RV& center,bool centerIsCentroid) {
    Cell cell;
    cell.fineTets=integration.size();
    if(integration.empty()) return cell;
    if(volume<=0) throw std::runtime_error("nonpositive prepared integration volume");
    cell.center=center;

    // Positive physical tetrahedral contributions avoid cancellation between
    // inward and outward boundary fans in thin/nonconvex wet pieces.
    std::array<Sum,20> volumeMoments;
    for(const auto& tet:integration) {
        std::array<Point,4> points;
        for(unsigned vertex=0;vertex<4;++vertex)
            points[vertex]=Rounded(Sub(tet.points[vertex],cell.center));
        const Real measure=tet.volume.template convert_to<Real>();
        if(!(measure>0) || !std::isfinite(measure))
            throw std::runtime_error("positive exact tetrahedron not representable in fast collector");
        for(unsigned m=0;m<20;++m)
            volumeMoments[m].Add(measure*MonomialAverage<4>(points,m));
    }
    for(unsigned m=0;m<20;++m) cell.geometry.volume[m]=volumeMoments[m].Get();
    cell.geometry.volume[0]=volume.convert_to<Real>();
    // These are exact identities of the exact chosen centroid, not repairs to
    // an approximate geometry or failed conservation solve.
    if(centerIsCentroid)
        for(unsigned axis=0;axis<3;++axis) cell.geometry.volume[axis+1]=0;

    std::map<unsigned,unsigned> groups;
    for(auto triangle:boundary) {
        auto [at,inserted]=groups.emplace(triangle.plane,cell.faces.size());
        if(inserted) {
            Face face;
            bool identified=false;
            for(unsigned solid=0;solid<mesh.bodyPlanes.size();++solid)
                if(triangle.plane==mesh.bodyPlanes[solid]) {
                    face.solid=int(solid);
                    identified=true;
                }
            if(!identified)
                for(const auto& [key,plane]:mesh.backgroundFaces)
                    if(plane==triangle.plane) {
                        face.background=key;
                        identified=true;
                        break;
                    }
            if(!identified) throw std::runtime_error("unclassified fast owned boundary");
            cell.faces.push_back(std::move(face));
        }
        for(auto& point:triangle.points) point=Sub(point,cell.center);
        cell.faces[at->second].triangles.push_back(std::move(triangle));
    }

    for(auto& face:cell.faces) {
        const auto areaVector=face.triangles[0].areaVector;
        for(unsigned axis=1;axis<3;++axis)
            if(abs(areaVector[axis])>abs(areaVector[face.pivot])) face.pivot=axis;
        if(areaVector[face.pivot]==0) throw std::runtime_error("zero fast boundary area");
        face.u=(face.pivot+1)%3;
        face.v=(face.pivot+2)%3;
        const unsigned iu=face.u+1,iv=face.v+1;

        // Only projected[0..9] are exact/populated in this fast collector.
        // Projected P3 slots remain zero/unavailable, never rounded quantities
        // falsely advertised as exact. Runtime P3 lives in geometry below.
        for(const auto& triangle:face.triangles) {
            const R measure=abs(triangle.areaVector[face.pivot]);
            const auto average=ExactTriangleP2(triangle.points);
            for(unsigned m=0;m<10;++m) face.projected[m]+=measure*average[m];
        }
        face.measure=face.projected[0];
        if(face.measure<=0) throw std::runtime_error("nonpositive fast exact face measure");
        RV faceCenter;
        for(unsigned axis=0;axis<3;++axis) faceCenter[axis]=face.projected[axis+1]/face.measure;
        face.meanU=faceCenter[face.u];
        face.meanV=faceCenter[face.v];
        face.varU=face.projected[vem::ProductIndex(iu,iu)]/face.measure-face.meanU*face.meanU;
        face.cov=face.projected[vem::ProductIndex(iu,iv)]/face.measure-face.meanU*face.meanV;
        face.varV=face.projected[vem::ProductIndex(iv,iv)]/face.measure-face.meanV*face.meanV;
        const R conditional=face.varV-face.cov*face.cov/face.varU;
        if(face.varU<=0 || conditional<=0)
            throw std::runtime_error("degenerate exact fast face covariance");
        const Real su=std::sqrt(face.varU.convert_to<Real>());
        const Real sv=std::sqrt(conditional.convert_to<Real>());
        const R exactK=face.cov/face.varU;
        const Real k=exactK.convert_to<Real>();
        if(!(su>0) || !(sv>0) || !std::isfinite(su) || !std::isfinite(sv))
            throw std::runtime_error("exact fast face scale not representable");

        vem::FaceGeometry out;
        vem::Vec3 ratio;
        for(unsigned axis=0;axis<3;++axis)
            ratio[axis]=(areaVector[axis]/abs(areaVector[face.pivot])).convert_to<Real>();
        const Real metric=ratio.norm();
        out.normal=ratio/metric;
        out.basis(0,0)=1;
        out.basis(1,iu)=1/su;
        out.basis(1,0)=-face.meanU.convert_to<Real>()/su;
        out.basis(2,iv)=1/sv;
        out.basis(2,iu)=-k/sv;
        out.basis(2,0)=(-face.meanV+exactK*face.meanU).convert_to<Real>()/sv;
        out.anchoredBasis=true;
        out.basisAtOrigin=vem::Vec3(1,0,0);
        for(unsigned axis=0;axis<3;++axis)
            out.evaluationOrigin[axis]=faceCenter[axis].convert_to<Real>();

        std::array<Sum,20> faceMoments;
        std::array<std::array<Sum,10>,3> mixed;
        for(const auto& triangle:face.triangles) {
            std::array<Point,3> points;
            std::array<std::array<Real,3>,3> psi;
            for(unsigned vertex=0;vertex<3;++vertex) {
                points[vertex]=Rounded(triangle.points[vertex]);
                const RV exactDelta=Sub(triangle.points[vertex],faceCenter);
                // The small centered differences and skew cancellation are
                // performed EXACTLY before converting the physical factors.
                const Real du=exactDelta[face.u].convert_to<Real>();
                psi[0][vertex]=1;
                psi[1][vertex]=du/su;
                psi[2][vertex]=(exactDelta[face.v]-exactK*exactDelta[face.u])
                                   .convert_to<Real>()/sv;
            }
            const Real measure=abs(triangle.areaVector[face.pivot]).convert_to<Real>()*metric;
            for(unsigned m=0;m<20;++m)
                faceMoments[m].Add(measure*MonomialAverage<3>(points,m));
            for(unsigned row=0;row<3;++row)
                for(unsigned m=0;m<10;++m)
                    mixed[row][m].Add(measure*WeightedFaceAverage(points,psi[row],m));
        }
        for(unsigned m=0;m<20;++m) out.area[m]=faceMoments[m].Get();
        for(unsigned m=0;m<10;++m)
            out.area[m]=face.projected[m].convert_to<Real>()*metric;
        out.gram=vem::Mat3::Identity()*out.area[0];
        for(unsigned m=0;m<10;++m) {
            out.mixed(0,m)=out.area[m];
            for(unsigned row=1;row<3;++row) out.mixed(row,m)=mixed[row][m].Get();
            // Low-degree mixed moments already exist exactly through P2.
            if(m<4) {
                const R cu=face.projected[vem::ProductIndex(iu,m)]-face.meanU*face.projected[m];
                const R cv=face.projected[vem::ProductIndex(iv,m)]-face.meanV*face.projected[m];
                out.mixed(1,m)=cu.convert_to<Real>()*metric/su;
                out.mixed(2,m)=(cv-exactK*cu).convert_to<Real>()*metric/sv;
            }
        }
        cell.geometry.faces.push_back(std::move(out));
    }
    return cell;
}

struct IntegrationTet {
    std::array<RV,4> points;
    R volume;
};

// Existing fine-tetra compiler adapter, retaining its exact physical centroid.
inline Cell Collect(const motion_mesh::Compiler& mesh) {
    if(mesh.tetrahedra.empty()) return {};
    std::vector<RV> positions;
    positions.reserve(mesh.vertices.size());
    for(const auto& vertex:mesh.vertices)
        positions.push_back(owned_metrics::Position(vertex.exact));
    std::vector<IntegrationTet> integration;
    integration.reserve(mesh.tetrahedra.size());
    R volume=0;
    RV first{};
    for(const auto& tet:mesh.tetrahedra) {
        IntegrationTet item;
        for(unsigned i=0;i<4;++i) item.points[i]=positions[tet.vertices[i]];
        const auto& p=item.points;
        item.volume=owned_metrics::Dot(Sub(p[1],p[0]),
                        owned_metrics::Cross(Sub(p[2],p[0]),Sub(p[3],p[0])))/6;
        if(item.volume<=0) throw std::runtime_error("invalid exact tetrahedron in fast collector");
        volume+=item.volume;
        for(unsigned axis=0;axis<3;++axis)
            first[axis]+=item.volume*(p[0][axis]+p[1][axis]+p[2][axis]+p[3][axis])/4;
        integration.push_back(std::move(item));
    }
    RV center;
    for(unsigned axis=0;axis<3;++axis) center[axis]=first[axis]/volume;
    return CollectPrepared(mesh,stage16_geometry::Boundary(mesh),integration,volume,center,true);
}

// Direct convex-piece boundary compiler adapter. Its bounded bbox frame is
// deliberately NOT a physical centroid; nonzero first moments must survive.
// This template avoids an include cycle with BoundaryCompiler.h.
template<class DirectCompiler>
inline Cell CollectPrepared(const DirectCompiler& direct) {
    if(direct.components>1)
        throw std::runtime_error("separate fluid operators required for disconnected direct pieces");
    return CollectPrepared(direct.mesh,direct.boundary,direct.integration,
                           direct.volume,direct.center,direct.centerIsCentroid);
}

} // namespace stage16_fast_geometry

namespace stage16_geometry {
inline Cell FastCollect(const motion_mesh::Compiler& mesh) {
    return stage16_fast_geometry::Collect(mesh);
}
template<class DirectCompiler>
inline Cell FastCollectPrepared(const DirectCompiler& direct) {
    return stage16_fast_geometry::CollectPrepared(direct);
}
} // namespace stage16_geometry
