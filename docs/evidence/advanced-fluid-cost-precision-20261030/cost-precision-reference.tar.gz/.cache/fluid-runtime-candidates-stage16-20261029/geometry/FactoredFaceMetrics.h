#pragma once

// PRIVATE Stage16 alternative: retain exact topology and point differences,
// avoid rational integrated covariance/P2 in the runtime metric collector.
// Used by the isolated Stage16 epoch/native probes only. It is not an engine
// fluid implementation and is not asserted dynamically qualified.
#include "FastPolyhedralMoments.h"
#include "BoundaryCompiler.h"

namespace stage16_factored {

using stage16_geometry::R;
using stage16_geometry::RV;
using stage16_geometry::Sub;
using stage16_geometry::BoundaryTriangle;
namespace fast=stage16_fast_geometry;
namespace vem=JudasFluidVem;
using Real=vem::Real;

struct CanonicalFrame {
    RV origin{},edge{},transverse{},cross{};
    R minU=0,maxU=0,minV=0,maxV=0;
    R spanU=0,spanV=0,midU=0,midV=0;
    unsigned pivot=0;

    std::array<Real,3> Factors(const RV& globalPoint) const {
        const RV delta=Sub(globalPoint,origin);
        // Dot products, subtraction and normalization are exact BEFORE cast.
        // In particular this does not form dot(roundedEdge,roundedDelta).
        return {1,((owned_metrics::Dot(edge,delta)-midU)/spanU).convert_to<Real>(),
                  ((owned_metrics::Dot(transverse,delta)-midV)/spanV).convert_to<Real>()};
    }

    std::array<std::array<R,4>,3> LocalBasis(const RV& cellCenter) const {
        std::array<std::array<R,4>,3> basis{};
        basis[0][0]=1;
        const RV offset=Sub(cellCenter,origin);
        basis[1][0]=(owned_metrics::Dot(edge,offset)-midU)/spanU;
        basis[2][0]=(owned_metrics::Dot(transverse,offset)-midV)/spanV;
        for(unsigned axis=0;axis<3;++axis) {
            basis[1][axis+1]=edge[axis]/spanU;
            basis[2][axis+1]=transverse[axis]/spanV;
        }
        return basis;
    }
};

inline CanonicalFrame BuildFrame(const std::vector<BoundaryTriangle>& triangles) {
    std::set<RV> vertices;
    for(const auto& triangle:triangles)
        vertices.insert(triangle.points.begin(),triangle.points.end());
    if(vertices.size()<3) throw std::runtime_error("factored face has fewer than three points");
    CanonicalFrame frame;
    frame.origin=*vertices.begin();
    R longest=0;
    for(const auto& point:vertices) {
        const RV delta=Sub(point,frame.origin);
        const R length=owned_metrics::Dot(delta,delta);
        // Ordered iteration supplies deterministic lexicographic tie-breaking.
        if(length>longest) { longest=length;frame.edge=delta; }
    }
    if(longest<=0) throw std::runtime_error("factored face edge is degenerate");
    R largestArea=0;
    for(const auto& point:vertices) {
        const RV candidate=owned_metrics::Cross(frame.edge,Sub(point,frame.origin));
        const R area=owned_metrics::Dot(candidate,candidate);
        if(area>largestArea) { largestArea=area;frame.cross=candidate; }
    }
    if(largestArea<=0) throw std::runtime_error("factored face is collinear");
    frame.transverse=owned_metrics::Cross(frame.cross,frame.edge);
    bool first=true;
    for(const auto& point:vertices) {
        const RV delta=Sub(point,frame.origin);
        const R u=owned_metrics::Dot(frame.edge,delta);
        const R v=owned_metrics::Dot(frame.transverse,delta);
        if(first) { frame.minU=frame.maxU=u;frame.minV=frame.maxV=v;first=false; }
        else {
            frame.minU=std::min(frame.minU,u);frame.maxU=std::max(frame.maxU,u);
            frame.minV=std::min(frame.minV,v);frame.maxV=std::max(frame.maxV,v);
        }
    }
    frame.spanU=frame.maxU-frame.minU;
    frame.spanV=frame.maxV-frame.minV;
    frame.midU=(frame.maxU+frame.minU)/2;
    frame.midV=(frame.maxV+frame.minV)/2;
    if(frame.spanU<=0 || frame.spanV<=0)
        throw std::runtime_error("factored face coordinates lack positive exact extents");
    for(unsigned axis=1;axis<3;++axis)
        if(abs(frame.cross[axis])>abs(frame.cross[frame.pivot])) frame.pivot=axis;

    // These choices depend only on the convex hull: a lexicographic minimum,
    // maximum strictly convex distance, maximum convex cross-distance followed
    // by lexicographic minimum, and extrema of linear forms. Adding interior or
    // collinear edge-subdivision vertices therefore cannot change this frame.
    // Orientation is deliberately NOT chosen from either fluid owner's normal.
    return frame;
}

struct Face {
    int solid=-1;
    std::array<motion_mesh::Lattice,3> background{};
    std::vector<BoundaryTriangle> triangles; // original bounded exact coordinates
    CanonicalFrame frame;
    R projectedMeasure=0; // exact P0 only, not approximate welding or covariance
};

struct Cell {
    RV center{};
    vem::CellGeometry geometry;
    std::vector<Face> faces;
    unsigned fineTets=0;
};

inline vem::FaceGeometry CollectFace(Face& face,const RV& cellCenter) {
    face.projectedMeasure=0;
    face.frame=BuildFrame(face.triangles);
    const auto& frame=face.frame;
    vem::FaceGeometry geometry;
    // The supporting-plane normal is exact. Frame orientation is shared,
    // while the actual outward fluid normal may differ between the two owners.
    const auto& areaVector=face.triangles.front().areaVector;
    vem::Vec3 ratio;
    for(unsigned axis=0;axis<3;++axis)
        ratio[axis]=(areaVector[axis]/abs(areaVector[frame.pivot])).convert_to<Real>();
    const Real metric=ratio.norm();
    geometry.normal=ratio/metric;
    const auto exactBasis=frame.LocalBasis(cellCenter);
    for(unsigned row=0;row<3;++row)
        for(unsigned col=0;col<4;++col)
            geometry.basis(row,col)=exactBasis[row][col].convert_to<Real>();

    // Numerically anchored evaluation is a convenience; primary face flux and
    // factored exact-point evaluation remain the meaningful trace quantities.
    RV anchor=frame.origin;
    const R edgeNorm=owned_metrics::Dot(frame.edge,frame.edge);
    const R transverseNorm=owned_metrics::Dot(frame.transverse,frame.transverse);
    for(unsigned axis=0;axis<3;++axis)
        anchor[axis]+=frame.edge[axis]*frame.midU/edgeNorm
                     +frame.transverse[axis]*frame.midV/transverseNorm;
    const auto localAnchor=Sub(anchor,cellCenter);
    geometry.anchoredBasis=true;
    geometry.basisAtOrigin=vem::Vec3(1,0,0);
    for(unsigned axis=0;axis<3;++axis)
        geometry.evaluationOrigin[axis]=localAnchor[axis].convert_to<Real>();

    std::array<fast::Sum,20> area;
    std::array<std::array<fast::Sum,3>,3> gram;
    std::array<std::array<fast::Sum,10>,3> mixed;
    for(const auto& triangle:face.triangles) {
        const R projected=abs(triangle.areaVector[frame.pivot]);
        if(projected<=0) throw std::runtime_error("factored triangle lacks exact positive area");
        face.projectedMeasure+=projected;
        const Real measure=projected.convert_to<Real>()*metric;
        std::array<fast::Point,3> points;
        std::array<std::array<Real,3>,3> psi{};
        for(unsigned vertex=0;vertex<3;++vertex) {
            points[vertex]=fast::Rounded(Sub(triangle.points[vertex],cellCenter));
            const auto factors=frame.Factors(triangle.points[vertex]);
            for(unsigned row=0;row<3;++row) psi[row][vertex]=factors[row];
        }
        for(unsigned m=0;m<20;++m)
            area[m].Add(measure*fast::MonomialAverage<3>(points,m));
        for(unsigned row=0;row<3;++row) {
            for(unsigned col=0;col<3;++col) {
                std::array<std::array<Real,3>,3> factors{};
                factors[0]=psi[row];factors[1]=psi[col];
                gram[row][col].Add(measure*fast::ProductAverage<3>(factors,2));
            }
            for(unsigned m=0;m<10;++m)
                mixed[row][m].Add(measure*fast::WeightedFaceAverage(points,psi[row],m));
        }
    }
    for(unsigned m=0;m<20;++m) geometry.area[m]=area[m].Get();
    geometry.area[0]=face.projectedMeasure.convert_to<Real>()*metric;
    for(unsigned row=0;row<3;++row) {
        for(unsigned col=0;col<3;++col) geometry.gram(row,col)=gram[row][col].Get();
        for(unsigned m=0;m<10;++m) geometry.mixed(row,m)=mixed[row][m].Get();
    }
    for(unsigned m=0;m<10;++m) geometry.mixed(0,m)=geometry.area[m];
    // No fitted covariance, raw-moment subtraction, negative-eigenvalue repair
    // or diagonal-only approximation: the full physical face Gram is retained.
    return geometry;
}

inline Cell Collect(const stage16_boundary::Compiler& direct) {
    if(direct.components>1)
        throw std::runtime_error("factored metrics require separate disconnected fluid operators");
    Cell cell;
    cell.center=direct.center;
    cell.fineTets=direct.integration.size();
    if(direct.integration.empty()) return cell;
    std::array<fast::Sum,20> volume;
    for(const auto& tet:direct.integration) {
        std::array<fast::Point,4> points;
        for(unsigned vertex=0;vertex<4;++vertex)
            points[vertex]=fast::Rounded(Sub(tet.points[vertex],cell.center));
        const Real measure=tet.volume.convert_to<Real>();
        if(!(measure>0) || !std::isfinite(measure))
            throw std::runtime_error("factored integration measure is not representable");
        for(unsigned m=0;m<20;++m)
            volume[m].Add(measure*fast::MonomialAverage<4>(points,m));
    }
    for(unsigned m=0;m<20;++m) cell.geometry.volume[m]=volume[m].Get();
    cell.geometry.volume[0]=direct.volume.convert_to<Real>();
    if(direct.centerIsCentroid)
        for(unsigned axis=0;axis<3;++axis) cell.geometry.volume[axis+1]=0;

    std::map<unsigned,unsigned> groups;
    for(const auto& triangle:direct.boundary) {
        auto [at,inserted]=groups.emplace(triangle.plane,cell.faces.size());
        if(inserted) {
            Face face;
            bool identified=false;
            for(unsigned solid=0;solid<direct.mesh.bodyPlanes.size();++solid)
                if(triangle.plane==direct.mesh.bodyPlanes[solid]) {
                    face.solid=int(solid);identified=true;
                }
            if(!identified)
                for(const auto& [key,plane]:direct.mesh.backgroundFaces)
                    if(plane==triangle.plane) {
                        face.background=key;identified=true;break;
                    }
            if(!identified) throw std::runtime_error("unclassified factored boundary owner");
            cell.faces.push_back(std::move(face));
        }
        cell.faces[at->second].triangles.push_back(triangle);
    }
    for(auto& face:cell.faces) cell.geometry.faces.push_back(CollectFace(face,cell.center));
    return cell;
}

} // namespace stage16_factored
