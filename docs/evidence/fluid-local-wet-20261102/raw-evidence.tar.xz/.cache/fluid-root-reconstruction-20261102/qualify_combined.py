from pathlib import Path
import subprocess,json,time,datetime,hashlib
r=Path.cwd();p=r/'.cache/fluid-root-reconstruction-20261102';o=p/'combined';o.mkdir(exist_ok=True);b=r/'.cache/2d-stage1-build';rows=[]
files=['src/FluidHydrostatics.cpp','src/FluidLocalWetSupport.h'];sources={f:hashlib.sha256((r/f).read_bytes()).hexdigest()for f in files};(o/'RUNTIME_SOURCES.json').write_text(json.dumps(sources,indent=2)+'\n')
commands=[([str(b/'judas_player_fluid_integration_tests'),'--output',str(o/'player')],0),([str(b/'judas_production_fluid_tests'),'--output',str(o/'production')],0),([str(b/'judas_fluid_known_geometry_tests'),'--output',str(o/'known.csv')],1)]
commands += [([str(b/t)],0)for t in ['judas_fluid_boundary_contact_tests','judas_fluid_cavity_impact_tests','judas_fluid_rigid_coupling_tests','judas_fluid_lifecycle_qualification_tests','judas_fluid_volume_drag_tests','judas_project_fluid_policy_tests','judas_project_water_tests']]
commands += [([str(b/'judas_fluid_container_integration_tests'),'--supported-only','--output',str(o/'containers')],0),([str(b/'judas_fluid_demo_integration_tests'),'--output',str(o/'demos')],0)]
for command,expected in commands:
 for f,h in sources.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
 log=o/(Path(command[0]).name+'.log');started=time.monotonic()
 with log.open('w')as f:q=subprocess.run(command,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 row={'command':command,'exit':q.returncode,'expectedExit':expected,'seconds':time.monotonic()-started,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log)};rows.append(row);(o/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if q.returncode!=expected:raise RuntimeError('Combined candidate failure: '+str(log))
