exec((__import__('pathlib').Path(__file__).parent/'local_hulls.py').read_text().split('results={}')[0])
def noncollinear(points):
 if len(points)<3:return False
 a=points[0];b=next((b for b in points[1:]if abs(a[0]-b[0])+abs(a[1]-b[1])>1e-12),a)
 return any(abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))>1e-12 for c in points[1:])
def sample2(particles,s,w):
 x,y,z,H=s['px'],s['py'],s['pz'],s['half'];near=[]
 for p in particles:
  dx,dz=(p['x']-x)/w,(p['z']-z)/w
  if dx*dx+dz*dz<4:near.append((dx-.5,dx+.5,dz-.5,dz+.5,p['y']-w/2,p['y']+w/2,dx,dz))
 rects=near[:];bridges=[]
 for i,a in enumerate(near):
  for b in near[i+1:]:
   lox,hix=max(a[0],b[0]),min(a[1],b[1]);loz,hiz=max(a[2],b[2]),min(a[3],b[3]);lo,hi=(a[5],b[4])if a[5]<b[4]else(b[5],a[4])
   if lox<=hix and loz<=hiz and 0<hi-lo<=w+1e-12:bridges.append((lox,hix,loz,hiz,lo,hi,(lox+hix)/2,(loz+hiz)/2))
 rects+=bridges;cuts=sorted(set([y-H,y+H]+[v for a in rects for v in a[4:6]if y-H<v<y+H]));out={'raw-three':0,'bridge-any':0,'bridge-three':0}
 counts={'rawTwoCentreOnlyWetBands':0,'bridges':len(bridges),'rawThreeRejectedLength':0}
 for lo,hi in zip(cuts,cuts[1:]):
  mid=(lo+hi)/2;raw=[a for a in near if a[4]<=mid<=a[5]];both=[a for a in rects if a[4]<=mid<=a[5]]
  for mode in out:
   active=raw if mode=='raw-three'else both
   direct=any(a[0]<=0<=a[1] and a[2]<=0<=a[3] for a in active)
   points=[(a[6],a[7])for a in active];enough=noncollinear(points)
   corners=[(xx,zz)for a in active for xx in a[:2]for zz in a[2:4]]
   hullwet=inside(corners)
   if mode=='raw-three' and hullwet and not(direct or enough):counts['rawTwoCentreOnlyWetBands']+=1;counts['rawThreeRejectedLength']+=(hi-lo)/(2*H)
   if direct or(hullwet and(mode=='bridge-any'or enough)):out[mode]+=(hi-lo)/(2*H)
 return out|counts
results={}
for kind in ['neutral','swim']:
 for spacing in ['20','25']:
  w=float('.'+spacing)
  p=src/f'final/player/density-{spacing}-1000-warmup-particles.csv'if kind=='neutral'else src/f'bounded-halo/swim-trace-run/swim-jump-gaps.csv.particles-0.{spacing}0000.csv'
  s=src/f'bounded-halo/actual-only-{kind}-{spacing}-samples.csv';pp,ss=rows(p),rows(s);details=[sample2(pp,a,w)for a in ss];volume=sum(a['volume']for a in ss);out={mode:sum(a[mode]*q['volume']for a,q in zip(details,ss))/volume for mode in ['raw-three','bridge-any','bridge-three']};out.update(details=details)
  results[f'{kind}-{spacing}']=out;print(kind,spacing,{k:out[k]for k in ['raw-three','bridge-any','bridge-three']},flush=True)
(o/'BRIDGED_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
