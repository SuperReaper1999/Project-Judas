from pathlib import Path
import csv, json, math, hashlib
r=Path.cwd();src=r/'.cache/fluid-support-continuation-20261102';o=r/'.cache/fluid-root-reconstruction-20261102/fixture-analysis'
def rows(p):return [{k:float(v) for k,v in a.items()}for a in csv.DictReader(p.open())]
def hull(v):
 v=sorted(set(v))
 if len(v)<3:return []
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 a=[]
 for p in v:
  while len(a)>1 and cross(a[-2],a[-1],p)<=0:a.pop()
  a.append(p)
 b=[]
 for p in reversed(v):
  while len(b)>1 and cross(b[-2],b[-1],p)<=0:b.pop()
  b.append(p)
 return a[:-1]+b[:-1]
def inside(v):
 v=hull(v)
 return len(v)>=3 and all((b[0]-a[0])*(-a[1])-(b[1]-a[1])*(-a[0])>=-1e-13 for a,b in zip(v,v[1:]+v[:1]))
def close(spans,w):
 spans=sorted(spans);out=[]
 for lo,hi in spans:
  if out and lo-out[-1][1]<=w+1e-12:out[-1]=(out[-1][0],max(out[-1][1],hi))
  else:out.append((lo,hi))
 return out
def sample(particles,s,w,mode):
 x,y,z,H=s['px'],s['py'],s['pz'],s['half'];near=[]
 for p in particles:
  dx,dz=p['x']-x,p['z']-z
  if dx*dx+dz*dz<4*w*w:near.append((dx/w,dz/w,p['y']-w/2,p['y']+w/2))
 cuts=sorted(set([y-H,y+H]+[a for p in near for a in p[2:] if y-H<a<y+H]))
 intervals=[]
 for lo,hi in zip(cuts,cuts[1:]):
  mid=(lo+hi)/2;active=[p for p in near if p[2]<=mid<=p[3]]
  if mode=='direct':wet=any(abs(p[0])<=.5 and abs(p[1])<=.5 for p in active)
  else:wet=inside([(p[0]+dx,p[1]+dz)for p in active for dx in [-.5,.5]for dz in [-.5,.5]])
  if wet:intervals.append((lo,hi))
 before=intervals[:]
 if mode.endswith('closed'):intervals=close(intervals,w)
 return sum(hi-lo for lo,hi in intervals)/(2*H),len(near),len(cuts)-1,[(b[0]-a[1])/w for a,b in zip(close(before,0),close(before,0)[1:])]
results={}
for kind in ['neutral','swim']:
 for spacing in ['20','25']:
  w=float('.'+spacing)
  p=src/f'final/player/density-{spacing}-1000-warmup-particles.csv' if kind=='neutral' else src/f'bounded-halo/swim-trace-run/swim-jump-gaps.csv.particles-0.{spacing}0000.csv'
  s=src/f'bounded-halo/actual-only-{kind}-{spacing}-samples.csv';pp,ss=rows(p),rows(s);detail=[]
  for row in ss:
   entry={'sample':int(row['sample']),'oldActualFraction':row['fraction'],'px':row['px'],'py':row['py'],'pz':row['pz'],'half':row['half']}
   for mode in ['direct','hull','hull-closed']:
    value,neighbours,bands,gaps=sample(pp,row,w,mode);entry[mode]=value
    if mode=='hull':entry.update(neighbours=neighbours,bands=bands,gapsInSpacings=gaps)
   detail.append(entry)
  volume=sum(v['volume']for v in ss);out={mode:sum(d[mode]*v['volume']for d,v in zip(detail,ss))/volume for mode in ['direct','hull','hull-closed']};out.update(oldActual=sum(v['fraction']*v['volume']for v in ss)/volume,particles=len(pp),samples=len(ss),sources={str(t.relative_to(r)):hashlib.sha256(t.read_bytes()).hexdigest()for t in [p,s]},details=detail)
  results[f'{kind}-{spacing}']=out;print(kind,spacing,{k:out[k]for k in ['oldActual','direct','hull','hull-closed']},flush=True)
(o/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
