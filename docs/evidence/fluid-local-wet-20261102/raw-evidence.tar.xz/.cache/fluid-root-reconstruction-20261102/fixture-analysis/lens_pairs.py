from pathlib import Path
from itertools import product
from collections import defaultdict
import csv,json,math,time,hashlib
r=Path.cwd();src=r/'.cache/fluid-support-continuation-20261102';o=r/'.cache/fluid-root-reconstruction-20261102/fixture-analysis';started=time.monotonic()
def rows(p):return [{k:float(v)for k,v in a.items()}for a in csv.DictReader(p.open())]
def preparation(particles,w):
 points=[(p['x'],p['y'],p['z'],w/2)for p in particles];cells=defaultdict(list);cellwidth=2*w;pairs=[]
 for i,p in enumerate(points):
  cell=tuple(math.floor(c/cellwidth)for c in p[:3])
  for delta in product([-1,0,1],repeat=3):
   for j in cells.get(tuple(a+b for a,b in zip(cell,delta)),[]):
    q=points[j];limit=p[3]+q[3]+min(2*p[3],2*q[3]);distance=sum((p[k]-q[k])**2 for k in range(3))
    if distance<=limit*limit:pairs.append((j,i))
  cells[cell].append(i)
 return points,pairs

def feasible_t(p,q,x,z):
 lo,hi=0.,1.;dh=q[3]-p[3]
 for axis,at in [(0,x),(2,z)]:
  c=p[axis]-at;dc=q[axis]-p[axis]
  for av,bv in [(c-p[3],dc-dh),(-c-p[3],-dc-dh)]:
   if bv==0:
    if av>0:return None
   elif bv>0:hi=min(hi,-av/bv)
   else:lo=max(lo,-av/bv)
   if lo>hi:return None
 return lo,hi

def intervals_at(points,pairs,x,y,z,H):
 lower,upper=y-H,y+H;raw=[]
 for p in points:
  if abs(p[0]-x)<=p[3] and abs(p[2]-z)<=p[3]:
   a,b=max(lower,p[1]-p[3]),min(upper,p[1]+p[3])
   if a<=b:raw.append((a,b))
 intervals=raw[:];tested=0;admitted=0
 for i,j in pairs:
  p,q=points[i],points[j]
  if x<min(p[0]-p[3],q[0]-q[3])or x>max(p[0]+p[3],q[0]+q[3])or z<min(p[2]-p[3],q[2]-q[3])or z>max(p[2]+p[3],q[2]+q[3])or lower>max(p[1]+p[3],q[1]+q[3])or upper<min(p[1]-p[3],q[1]-q[3]):continue
  tested+=1;t=feasible_t(p,q,x,z)
  if t is None:continue
  dy=q[1]-p[1];dh=q[3]-p[3];a=max(lower,min(p[1]-p[3]+t[0]*(dy-dh),p[1]-p[3]+t[1]*(dy-dh)));b=min(upper,max(p[1]+p[3]+t[0]*(dy+dh),p[1]+p[3]+t[1]*(dy+dh)))
  for point,other in [(p,q),(q,p)]:
   radius=point[3]+min(2*point[3],2*other[3])*.5
   horizontal=(point[0]-x)**2+(point[2]-z)**2
   if horizontal>radius*radius:a,b=1.,0.;break
   extent=math.sqrt(max(0.,radius*radius-horizontal))
   a=max(a,point[1]-extent);b=min(b,point[1]+extent)
  if a<=b:intervals.append((a,b));admitted+=1
 def measure(a):
  a=sorted(a);merged=[]
  for lo,hi in a:
   if merged and lo<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],hi))
   else:merged.append((lo,hi))
  return (sum(hi-lo for lo,hi in merged)/(2*H)if H>0 else float(any(lo<=y<=hi for lo,hi in merged))),merged
 rf,ri=measure(raw);f,fi=measure(intervals)
 return {'direct':rf,'pair':f,'rawIntervals':ri,'pairIntervals':fi,'testedPairs':tested,'admittedPairs':admitted}

results={}
for kind in ['neutral','swim']:
 for spacing in ['20','25']:
  w=float('.'+spacing);p=src/f'final/player/density-{spacing}-1000-warmup-particles.csv'if kind=='neutral'else src/f'bounded-halo/swim-trace-run/swim-jump-gaps.csv.particles-0.{spacing}0000.csv';s=src/f'bounded-halo/actual-only-{kind}-{spacing}-samples.csv';pp,ss=rows(p),rows(s);points,pairs=preparation(pp,w);details=[]
  for row in ss:details.append(intervals_at(points,pairs,row['px'],row['py'],row['pz'],row['half']))
  volume=sum(v['volume']for v in ss);out={mode:sum(d[mode]*v['volume']for d,v in zip(details,ss))/volume for mode in ['direct','pair']};out.update(particleCount=len(points),eligiblePairCount=len(pairs),partialSamples=[i for i,d in enumerate(details)if d['pair']<1-1e-12],details=details,sourceHashes={str(t.relative_to(r)):hashlib.sha256(t.read_bytes()).hexdigest()for t in [p,s]});results[f'{kind}-{spacing}']=out;print(kind,spacing,{k:out[k]for k in ['direct','pair','eligiblePairCount','partialSamples']},flush=True)
synthetics=[]
def fixture(name,coords,w,query,H,expected):
 pp=[dict(zip(['x','y','z'],p))for p in coords];points,pairs=preparation(pp,w);out=intervals_at(points,pairs,*query,H);out.update(name=name,spacing=w,point=query,halfHeight=H,expected=expected,error=abs(out['pair']-expected),eligiblePairCount=len(pairs));synthetics.append(out);print(name,'pair',out['pair'],'expected',expected,flush=True)
w=.0625
for H in [0,.01]:
 fixture('resolved-root-gap',[(0,-.125,0),(0,.125,0),(w,0,0)],w,(0,0,0),H,0)
 fixture('unresolved-short-gap',[(0,-.046875,0),(0,.046875,0),(w,0,0)],w,(0,0,0),H,1)
 fixture('actual-local-water',[(0,-.125,0),(0,.125,0),(w,0,0),(0,0,0)],w,(0,0,0),H,1)
for x in [.18,.3,-.1]:
 for H in [0,.025]:fixture('missing-nominal-bin',[(-2,-.5,0),(.1,-.5,0)],.25,(x,-.5,0),H,1 if x==.18 else 0)
coords=[(-1+(x+.5)*w,-(y+.5)*w,-1+(z+.5)*w)for x in range(32)for y in range(32)for z in range(32)if not(abs(-1+(x+.5)*w)<.3 and abs(-(y+.5)*w+.75)<.3 and abs(-1+(z+.5)*w)<.3)]
fixture('fine-cavity-nearwall',coords,w,(.2625,-.75,0),.0375,0)
for count,rad in [(8,2.),(12,1.9)]:
 ring=[(rad*w*math.cos(2*math.pi*i/count),0,rad*w*math.sin(2*math.pi*i/count))for i in range(count)]
 fixture(f'ring-{count}-radius-{rad}',ring,w,(0,0,0),.5*w,0)
fixture('horizontal-pair-point',[(-.9*w,0,0),(.9*w,0,0)],w,(0,0,0),0,1)
fixture('horizontal-pair-finite',[(-.9*w,0,0),(.9*w,0,0)],w,(0,0,0),.5*w,2*math.sqrt(1-.9*.9))
ns={}
exec((o/'compact_3d_pairs.py').read_text().split('results={}')[0],ns)
separation=[]
for ratio in [1.9,1.99,1.9999,1.999999,2.,2.000001]:
 coords=[dict(x=-ratio*w/2,y=0,z=0),dict(x=ratio*w/2,y=0,z=0)]
 pp,pr=preparation(coords,w);a=ns['intervals_at'](pp,pr,0,0,0,.5*w);b=intervals_at(pp,pr,0,0,0,.5*w)
 separation.append({'separationInSpacings':ratio,'hard':a['pair'],'lens':b['pair'],'analyticLens':min(1.,2*math.sqrt(max(0.,1-(ratio/2)**2)))if ratio<=2 else 0.})
results['hardCutNegativeControl']=separation
print('hardCutNegativeControl',separation,flush=True)

results['synthetics']=synthetics;results['_seconds']=time.monotonic()-started
(o/'LENS_PAIR_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
