exec((__import__('pathlib').Path(__file__).parent/'local_hulls.py').read_text().split('results={}')[0])
from itertools import combinations
import time
started=time.monotonic()
def corners(rects):return [(x,z) for a in rects for x in a[:2]for z in a[2:4]]
def paircontains(a,b):
 lo,hi=0.,1.
 # An interpolated rectangle must contain origin: four affine inequalities.
 for av,bv in [(a[0],b[0]),(-a[1],-b[1]),(a[2],b[2]),(-a[3],-b[3])]:
  delta=bv-av
  if delta==0:
   if av>1e-13:return False
  elif delta>0:hi=min(hi,(-av+1e-13)/delta)
  else:lo=max(lo,(-av+1e-13)/delta)
  if lo>hi:return False
 return lo<=hi

def shortcover(active):
 if any(a[0]<=0<=a[1]and a[2]<=0<=a[3]for a in active):return True,True,True,0
 if not inside(corners(active)):return False,False,False,0
 edges={}
 for i,j in combinations(range(len(active)),2):
  a,b=active[i],active[j];d=(a[6]-b[6])**2+(a[7]-b[7])**2
  if d<=4+1e-13:
   edges[i,j]=True
   if paircontains(a,b):return False,True,True,0
 checked=0
 for i,j,k in combinations(range(len(active)),3):
  if(i,j)not in edges or(i,k)not in edges or(j,k)not in edges:continue
  checked+=1
  if inside(corners([active[i],active[j],active[k]])):return False,False,True,checked
 return False,False,False,checked

def sample3(particles,s,w):
 x,y,z,H=s['px'],s['py'],s['pz'],s['half'];near=[]
 for p in particles:
  dx,dz=(p['x']-x)/w,(p['z']-z)/w
  if dx*dx+dz*dz<4:near.append((dx-.5,dx+.5,dz-.5,dz+.5,p['y']-w/2,p['y']+w/2,dx,dz))
 rects=near[:];bridges=[]
 for i,a in enumerate(near):
  for b in near[i+1:]:
   lox,hix=max(a[0],b[0]),min(a[1],b[1]);loz,hiz=max(a[2],b[2]),min(a[3],b[3]);lo,hi=(a[5],b[4])if a[5]<b[4]else(b[5],a[4])
   if lox<=hix and loz<=hiz and 0<hi-lo<=w+1e-12:bridges.append((lox,hix,loz,hiz,lo,hi,(lox+hix)/2,(loz+hiz)/2))
 rects+=bridges;cuts=sorted(set([y-H,y+H]+[v for a in rects for v in a[4:6]if y-H<v<y+H]));out={'direct':0.,'pair':0.,'simplex':0.};extra={'rawRectangles':len(near),'bridgeRectangles':len(bridges),'heightBands':len(cuts)-1,'tripleOnlyBands':0,'tripleOnlyFraction':0.,'triplesChecked':0,'maxActive':0}
 for lo,hi in zip(cuts,cuts[1:]):
  mid=(lo+hi)/2;active=[a for a in rects if a[4]<=mid<=a[5]];direct,pair,simplex,checked=shortcover(active);width=(hi-lo)/(2*H)
  out['direct']+=direct*width;out['pair']+=pair*width;out['simplex']+=simplex*width
  extra['triplesChecked']+=checked;extra['maxActive']=max(extra['maxActive'],len(active))
  if simplex and not pair:extra['tripleOnlyBands']+=1;extra['tripleOnlyFraction']+=width
 return out|extra
results={}
for kind in ['neutral','swim']:
 for spacing in ['20','25']:
  w=float('.'+spacing)
  p=src/f'final/player/density-{spacing}-1000-warmup-particles.csv'if kind=='neutral'else src/f'bounded-halo/swim-trace-run/swim-jump-gaps.csv.particles-0.{spacing}0000.csv'
  s=src/f'bounded-halo/actual-only-{kind}-{spacing}-samples.csv';pp,ss=rows(p),rows(s);details=[sample3(pp,a,w)for a in ss];volume=sum(a['volume']for a in ss);out={mode:sum(a[mode]*q['volume']for a,q in zip(details,ss))/volume for mode in ['direct','pair','simplex']};out.update(details=details,triplesChecked=sum(a['triplesChecked']for a in details),tripleOnlyBands=sum(a['tripleOnlyBands']for a in details),maxActive=max(a['maxActive']for a in details),sourceHashes={str(t.relative_to(r)):hashlib.sha256(t.read_bytes()).hexdigest()for t in [p,s]})
  results[f'{kind}-{spacing}']=out;print(kind,spacing,{k:out[k]for k in ['direct','pair','simplex','tripleOnlyBands','maxActive']},flush=True)
results['_seconds']=time.monotonic()-started
(o/'SHORT_SIMPLEX_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
