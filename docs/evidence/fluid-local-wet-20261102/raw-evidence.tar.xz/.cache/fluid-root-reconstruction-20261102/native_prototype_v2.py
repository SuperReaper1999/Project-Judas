from pathlib import Path
import subprocess,shlex,json,time,hashlib,shutil
r=Path.cwd();p=r/'.cache/fluid-root-reconstruction-20261102';src=p/'prototype';o=p/'native-v2';o.mkdir(exist_ok=True);b=r/'.cache/2d-stage1-build';commands=[];results={}
for f in ['FluidHydrostatics.cpp','FluidLocalWetSupport.h']:shutil.copy2(src/f,o/f)
def record():
 (o/'BUILD.json').write_text(json.dumps({'commands':commands,'results':results,'sources':{f:hashlib.sha256((o/f).read_bytes()).hexdigest()for f in ['FluidHydrostatics.cpp','FluidLocalWetSupport.h']}},indent=2)+'\n')
def build(c,log,cwd=r):
 commands.append({'command':c,'cwd':str(cwd),'log':str(log)});record()
 with log.open('w')as f:q=subprocess.run(c,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 if q.returncode:raise RuntimeError(str(log))
def flags(target):
 d={}
 for line in (b/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_')and' = 'in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((d[k]for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
def link(target,name,driver=None):
 c=[v for v in shlex.split((b/f'CMakeFiles/{target}.dir/link.txt').read_text())if not v.startswith('-Wl,--dependency-file=')]
 if driver is not None:c=[str(driver)if v.endswith('/tests/PlayerFluidIntegrationTests.cpp.o')else v for v in c]
 c[c.index('-o')+1]=str(o/name);c.insert(c.index('libjudas_engine.a'),str(o/'hydro.o'));build(c,o/(name+'-link.log'),b)
def run(name,c):
 start=time.monotonic()
 with (o/(name+'.log')).open('w')as f:q=subprocess.run(c,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 results[name]={'command':c,'exit':q.returncode,'seconds':time.monotonic()-start,'log':str(o/(name+'.log'))};record();print(name,q.returncode,flush=True)
build(flags('judas_engine')+['-I',str(o),'-c',str(o/'FluidHydrostatics.cpp'),'-o',str(o/'hydro.o')],o/'hydro-compile.log')
for target,name in [('judas_fluid_root_admission_diagnostics','root'),('judas_fluid_hydrostatics_tests','hydrostatics'),('judas_fluid_wet_support_tests','wet'),('judas_fluid_vertical_support_tests','vertical')]:
 link(target,name);run(name,[str(o/name)])
link('judas_player_fluid_integration_tests','player')
for spacing,name in [('.25','neutral25'),('.2','neutral20')]:run(name,[str(o/'player'),'--smoke','--smoke-spacing',spacing,'--output',str(o/name)])
swimsrc=r/'.cache/fluid-support-continuation-20261102/bounded-halo/SwimOnly.cpp';shutil.copy2(swimsrc,o/'SwimOnly.cpp');build(flags('judas_player_fluid_integration_tests')+['-I',str(r/'tests'),'-c',str(o/'SwimOnly.cpp'),'-o',str(o/'swim.o')],o/'swim-compile.log');link('judas_player_fluid_integration_tests','swim',o/'swim.o');run('swim',[str(o/'swim'),'--output',str(o/'swim-run')])
