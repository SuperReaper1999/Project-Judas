from pathlib import Path
import subprocess,json,shlex,hashlib,statistics,math,time,datetime
r=Path.cwd();p=r/'.cache/fluid-root-reconstruction-20261102';o=p/'benchmark';b=r/'.cache/2d-stage1-build';commands=[]
def build(cmd,log,cwd=r):
 commands.append({'command':cmd,'cwd':str(cwd),'log':str(log)});(o/'BUILD.json').write_text(json.dumps(commands,indent=2)+'\n')
 with log.open('w')as f:q=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 if q.returncode:raise RuntimeError(str(log))
def flags(target):
 d={}
 for line in (b/f'CMakeFiles/{target}.dir/flags.make').read_text().splitlines():
  if line.startswith('CXX_')and' = 'in line:k,v=line.split(' = ',1);d[k]=shlex.split(v)
 return ['/usr/bin/c++']+sum((d[k]for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']),[])
(o/'BaselineHydrostatics.cpp').write_text(subprocess.check_output(['git','show','941832fe:src/FluidHydrostatics.cpp'],text=True))
build(flags('judas_engine')+['-c',str(o/'BaselineHydrostatics.cpp'),'-o',str(o/'baseline-hydro.o')],o/'baseline-compile.log')
build(flags('judas_engine')+['-I',str(r),'-c',str(o/'QueryBench.cpp'),'-o',str(o/'bench.o')],o/'bench-compile.log')
for name in ['baseline','candidate']:
 cmd=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());cmd=[c for c in cmd if not c.startswith('-Wl,--dependency-file=')];cmd=[str(o/'bench.o')if c.endswith('/tests/ProductionFluidTests.cpp.o')else c for c in cmd];cmd[cmd.index('-o')+1]=str(o/name)
 if name=='baseline':cmd.insert(cmd.index('libjudas_engine.a'),str(o/'baseline-hydro.o'))
 build(cmd,o/(name+'-link.log'),b)
# Re-run unchanged root driver with actual baseline implementation as negative control.
cmd=shlex.split((b/'CMakeFiles/judas_fluid_root_admission_diagnostics.dir/link.txt').read_text());cmd=[c for c in cmd if not c.startswith('-Wl,--dependency-file=')];cmd[cmd.index('-o')+1]=str(o/'baseline-root');cmd.insert(cmd.index('libjudas_engine.a'),str(o/'baseline-hydro.o'));build(cmd,o/'baseline-root-link.log',b)
with(o/'baseline-root.log').open('w')as f:q=subprocess.run([str(o/'baseline-root')],stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==1
measurements=[]
for pair in range(7):
 order=['baseline','candidate']if pair%2==0 else['candidate','baseline']
 for name in order:
  path=o/f'timing-{pair}-{name}.json';cmd=[str(o/name),str(o/'frozen-fields.json'),'16'];start=time.monotonic()
  with path.open('w')as f:subprocess.run(cmd,stdout=f,check=True)
  data=json.loads(path.read_text());rows=data['rows'];measurements.append({'pair':pair,'name':name,'order':order,'seconds':time.monotonic()-start,'command':cmd,'path':str(path),'rows':rows,'checksum':data['checksum']})
 (o/'RAW_MEASUREMENTS.json').write_text(json.dumps(measurements,indent=2)+'\n')
def stats(values):
 a=sorted(values);return{'count':len(a),'meanMs':statistics.mean(a),'medianMs':statistics.median(a),'p95Ms':a[math.ceil(.95*len(a))-1],'worstMs':max(a)}
summary={}
for name in ['baseline','candidate']:
 rows=[row for m in measurements if m['name']==name for row in m['rows']];summary[name]={'overall':stats([x['milliseconds']for x in rows]),'fields':{label:{'timing':stats([x['milliseconds']for x in rows if x['label']==label]),'fraction':next(x['fraction']for x in rows if x['label']==label)}for label in ['neutral-20','neutral-25','swim-20','swim-25']}}
(o/'TIMING_SUMMARY.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'CPU sampling of frozen64-query player volumes,4 exact fields,7 alternating-order pairs,16passes perfield/run. Excludes particle solve,rigid solve,rendering. No task-owned concurrent builds/tests. Outputs intentionally change: this measures functional reconstruction overhead,not behavior-preserving optimization. Shared host, no generalFPSclaim.','results':summary},indent=2)+'\n');print(json.dumps(summary,indent=2))
