#include "FluidHydrostatics.h"
#include "third_party/nlohmann/json.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
using Json=nlohmann::json;
using Clock=std::chrono::steady_clock;
struct Sample { glm::vec3 position; float half,volume; };
struct Fixture { std::string label; FluidHydrostaticField field; glm::vec3 tangent; std::vector<Sample> samples; };
glm::vec3 ReadVector(const Json& j){return {j[0].get<float>(),j[1].get<float>(),j[2].get<float>()};}
int main(int argc,char**argv){
 if(argc!=3)return 2;
 Json input;std::ifstream file(argv[1]);file>>input;const int loops=std::stoi(argv[2]);std::vector<Fixture> fields;
 for(const auto& fixture:input["frames"]){
  Fixture f;f.label=fixture["label"].get<std::string>();std::vector<FluidParticle> particles;
  for(const auto& row:fixture["particles"]){FluidParticle p;p.position=ReadVector(row["position"]);p.previousPosition=p.position;p.velocity=ReadVector(row["velocity"]);p.acceleration=ReadVector(row["acceleration"]);p.mass=row["mass"].get<float>();particles.push_back(p);}
  f.field.Build(particles,1000);f.tangent=f.field.ReconstructionTangent({0,1,0},{1,0,0});
  for(const auto& row:fixture["samples"])f.samples.push_back({ReadVector(row["point"]),row["half"].get<float>(),row["volume"].get<float>()});
  fields.push_back(std::move(f));
 }
 const float radius=glm::length(glm::vec3(.3f,.9f,.3f));volatile double checksum=0;Json results=Json::array();
 for(int pass=-3;pass<loops;++pass)for(const auto& f:fields){
  const auto began=Clock::now();double wet=0,volume=0;
  for(const auto& s:f.samples){const auto q=f.field.Query(s.position,{0,1,0},s.half,radius,f.tangent,nullptr,true);wet+=q.fraction*s.volume;volume+=s.volume;}
  const auto seconds=std::chrono::duration<double>(Clock::now()-began).count();checksum+=wet;
  if(pass>=0)results.push_back({{"label",f.label},{"pass",pass},{"milliseconds",1000*seconds},{"fraction",wet/volume}});
 }
 std::cout<<Json{{"loops",loops},{"queriesPerVolume",64},{"rows",results},{"checksum",checksum}}.dump(2)<<'\n';
}
