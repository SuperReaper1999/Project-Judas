#include "FluidHydrostatics.h"
#include "GravityField.h"
#include <iostream>
struct Uniform:GravityField { glm::vec3 Sample(const glm::vec3&)const override{return {0,-9.81f,0};} };
int main(){Uniform gravity;const auto box=MakeBoxFluidVolume({.5,.5,.5});
 for(float spacing:{.125f,.25f,.5f}) {
  std::vector<FluidParticle> particles;
  for(int z=0;z<int(4/spacing);++z)for(int y=0;y<int(3/spacing);++y)for(int x=0;x<int(4/spacing);++x){
   glm::vec3 p(-2+(x+.5f)*spacing,-(y+.5f)*spacing,-2+(z+.5f)*spacing);
   if(std::abs(p.x)<.5f&&std::abs(p.z)<.5f&&p.y> -1.5f)continue;
   particles.push_back({p,p,{},1000*spacing*spacing*spacing,{}});
  }
  FluidHydrostaticField field;field.Build(particles,1000);BodyTransform pose;pose.position={0,-.75f,0};
  auto load=EvaluateFluidHydrostatics(field,box,pose,gravity);
  std::cout<<"spacing="<<spacing<<" particles="<<particles.size()<<" fraction="<<load.fraction<<" force="<<load.buoyancyForce.y<<" neutral_net_force="<<load.buoyancyForce.y-9810<<'\n';
 }
}
