#include "SceneSerialization.h"
#include "Project.h"
#include "RuntimeWorld.h"
#include "GameSession.h"
#include "Window.h"
#include "Simulation.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <fstream>
#include "ProductionFluidCoupling.h"

int main(int argc, char** argv) {
    const bool quiet=argc>1;
    const float quietMass=quiet?std::stof(argv[1]):1000;
    Scene scene;
    std::string error;
    if (!LoadSceneFromFile("projects/fluid_comparison/Scenes/rectangular_pool.judas", scene, error))
        throw std::runtime_error(error);
    for (auto& object : scene.Objects()) { object.scripts.clear(); object.ui.reset(); }
    if(quiet)for(auto& object:scene.Objects())if(object.name.find("Neutral blue")!=std::string::npos) {
        object.transform.position={3.5f,1.f,-1.5f};
        object.body->mass=quietMass;
    }
    ProjectSettings settings;
    settings.advancedFluidDynamics = true;
    RuntimeWorld world;
    world.ConfigureProject(settings);
    GameSession session;
    Window window;
    window.SetTestInputMode(true);
    if (!world.Build(scene, nullptr, error) || !session.Begin(world, error))
        throw std::runtime_error(error);
    auto mass = [&]() { double sum = 0; for (const auto& p : world.Fluid().Particles()) sum += p.mass; return sum; };
    const auto count = world.Fluid().Particles().size();
    const auto initialMass = mass();
    bool finite = true;
    float maxImmersion = 0;
    int step = 0;
    std::ofstream csv(quiet?std::string(".cache/fluid-pool-impact-20261102/neutral/quiet-")+argv[1]+".csv":".cache/fluid-pool-impact-20261102/neutral/exact.csv");
    csv << "step,body,x,y,z,vx,vy,vz,fraction,volume,buoyancy_y,drag_y,fluid_executed,ax,ay,az,qw,qx,qy,qz\n";
    auto tick = [&](int frames) {
        for (int i = 0; i < frames; ++i) {
            session.HandleFrameInput(window, false, false, false, false, false);
            StepPlayedWorld(session, window, 1.f / 60);
            maxImmersion = std::max(maxImmersion, session.Player().GetFluidSample().immersion);
            const auto& m=world.FluidCoupling().Measurements();
            for(std::size_t b=0;b<world.DynamicBodies().size();++b) {
                auto handle=world.DynamicBodies()[b].Handle();
                auto pose=world.Physics().GetTransform(handle);
                auto velocity=world.Physics().GetLinearVelocity(handle);
                auto sample=world.FluidCoupling().SampleField(pose.position,{0,1,0},.5f,.8660254f,{1,0,0});
                for(const auto& body:m.bodies)if(body.body.id==handle.id)
                    csv<<step<<','<<b<<','<<pose.position.x<<','<<pose.position.y<<','<<pose.position.z<<','
                       <<velocity.x<<','<<velocity.y<<','<<velocity.z<<','<<body.fraction<<','<<body.displacedVolume<<','
                       <<body.buoyancyForce.y<<','<<body.dragForce.y<<','<<m.executed<<','
                       <<sample.acceleration.x<<','<<sample.acceleration.y<<','<<sample.acceleration.z<<','
                       <<pose.rotation.w<<','<<pose.rotation.x<<','<<pose.rotation.y<<','<<pose.rotation.z<<'\n';
            }
            ++step;
            for (const auto& p : world.Fluid().Particles())
                for (int axis = 0; axis < 3; ++axis)
                    finite &= std::isfinite(p.position[axis]) && std::isfinite(p.velocity[axis]);
        }
        int escapes = 0;
        for (const auto& p : world.Fluid().Particles())
            escapes += std::abs(p.position.x) > 6.25f || std::abs(p.position.z) > 4.25f || p.position.y < 0;
        std::cout << "phase_end frames=" << frames << " outside=" << escapes << '\n';
    };
    if(quiet) {
        tick(300);
        auto handle=world.DynamicBodies()[2].Handle();
        auto pose=world.Physics().GetTransform(handle);
        std::cout<<"quiet mass="<<quietMass<<" y="<<pose.position.y<<" vy="<<world.Physics().GetLinearVelocity(handle).y<<'\n';
        std::ofstream particles(std::string(".cache/fluid-pool-impact-20261102/neutral/quiet-")+argv[1]+"-particles.csv");
        particles<<"x,y,z,vy,mass\n";
        for(const auto& p:world.Fluid().Particles())particles<<p.position.x<<','<<p.position.y<<','<<p.position.z<<','<<p.velocity.y<<','<<p.mass<<'\n';
        return !finite;
    }
    tick(60);
    const float dry = session.Player().GetFluidSample().immersion;
    window.SetTestActionState(Action::MoveForward, true);
    tick(120);
    window.SetTestActionState(Action::MoveForward, false);
    window.RequestTestJump();
    tick(45);
    const auto entered = session.Player().GetPosition();
    window.SetTestActionState(Action::MoveBackward, true);
    tick(150);
    window.SetTestActionState(Action::MoveBackward, false);
    tick(30);
    const auto exited = session.Player().GetPosition();
    const auto exitImmersion = session.Player().GetFluidSample().immersion;
    const bool exitGrounded = session.Player().IsGrounded();
    for (auto& body : world.DynamicBodies()) {
        ObjectManipulation hand({body.Handle()});
        if (!hand.TryPickUp(body.Handle(), world.Physics())) throw std::runtime_error("prop pickup failed");
        hand.Throw(world.Physics(), glm::normalize(glm::vec3(0, .4f, -1)), 8);
    }
    tick(240);
    int outside = 0;
    for (const auto& p : world.Fluid().Particles())
        if (std::abs(p.position.x) > 6.25f || std::abs(p.position.z) > 4.25f || p.position.y < 0) {
            ++outside;
            std::cout << "outside_particle " << p.position.x << ' ' << p.position.y << ' ' << p.position.z << '\n';
        }
    for (const auto& body : world.DynamicBodies()) {
        const auto pose = world.Physics().GetTransform(body.Handle());
        std::cout << "prop " << pose.position.x << ' ' << pose.position.y << ' ' << pose.position.z << '\n';
    }
    std::cout << "count=" << count << " final_count=" << world.Fluid().Particles().size()
              << " initial_mass=" << initialMass << " final_mass=" << mass()
              << " finite=" << finite << " outside=" << outside
              << " initial_dry=" << dry << " maximum_immersion=" << maxImmersion
              << " entered_z=" << entered.z << " exit=" << exited.x << ',' << exited.y << ',' << exited.z
              << " exit_immersion=" << exitImmersion << " exit_grounded=" << exitGrounded << '\n';
    return !(count == 1440 && world.Fluid().Particles().size() == count && mass() == initialMass && finite &&
             dry == 0 && maxImmersion > .5f && entered.z < 0 && exited.z > 4.5f && exited.z < 7.5f &&
             exitImmersion == 0 && exitGrounded && outside == 0);
}
