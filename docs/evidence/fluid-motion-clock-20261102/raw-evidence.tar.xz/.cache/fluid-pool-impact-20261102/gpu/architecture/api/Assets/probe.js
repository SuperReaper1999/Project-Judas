import {entity} from 'judas';
 export default class {constructor(){this.state={};}start(){const l=entity('1');
  const copy=l.light;copy.intensity=99;this.state.copy=l.light.intensity===1;
  try{l.setLight({banana:1});this.state.unknown=false;}catch{this.state.unknown=true;}
  try{l.setLight({intensity:-1});this.state.negative=false;}catch{this.state.negative=true;}
  try{l.setLight({enabled:1});this.state.flag=false;}catch{this.state.flag=true;}
  l.setLight({kind:'spot',enabled:true,intensity:3,color:{x:1,y:.5,z:.25},castsShadow:true});this.state.applied=l.light.intensity===3&&l.light.kind==='spot';
  const other=entity('2');this.state.absent=other.light===null;try{other.setLight({enabled:false});this.state.absentError=false;}catch{this.state.absentError=true;}
  l.destroy();try{l.setLight({enabled:true});this.state.stale=false;}catch{this.state.stale=true;}
 }}