from pathlib import Path
c=Path(__file__).resolve().parent;r=c.parents[1];s=(r/'tests/ProductionFluidTests.cpp').read_text()
needle="<<'\\n';return result;"
assert s.count(needle)==1
extra='''<<'\\n';
 // Supplemental observation AFTER all unchanged four-second assertions. This
 // cannot change the original result or convert its failed endpoint to a pass.
 std::ofstream continuation(out/(name+"_continuation.csv"));
 continuation<<std::setprecision(17)<<"step,time,y,vy,fraction,body_ke,fluid_ke,fluid_mass\\n";
 for(int extra=240;extra<720;++extra) {
  StepPlayedWorld(session,window,dt);++totalSteps;
  const auto transform=world.Physics().GetTransform(handle);
  const auto v=world.Physics().GetLinearVelocity(handle),w=world.Physics().GetAngularVelocity(handle);
  const auto local=glm::conjugate(q)*transform.position,localV=glm::conjugate(q)*v;
  const auto liquid=world.Fluid().GetDiagnostics();const auto& measure=world.FluidCoupling().Measurements();
  const auto diagnostic=std::find_if(measure.bodies.begin(),measure.bodies.end(),[&](const auto& b){return b.body.id==handle.id;});
  const double bodyKe=.5*actualMass*glm::dot(v,v)+.5*glm::dot(w,world.Physics().GetInertiaWorld(handle)*w);
  continuation<<extra<<','<<(extra+1)/60.0<<','<<local.y<<','<<localV.y<<','<<diagnostic->fraction<<','<<bodyKe<<','<<liquid.kineticEnergy<<','<<liquid.totalMass<<'\\n';
 }
 return result;'''
s=s.replace(needle,extra);(c/'ContinuedOriginalGates.cpp').write_text(s)
