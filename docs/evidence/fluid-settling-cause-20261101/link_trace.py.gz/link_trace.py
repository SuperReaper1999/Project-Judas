from pathlib import Path
import subprocess,shlex
c=Path(__file__).resolve().parent;r=c.parents[1];b=r/'.cache/2d-stage1-build'
args=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text())
for arm,objects in [('current',[c/'trace-coupling.o']),('baseline',[c/'trace-coupling.o',r/'.cache/fluid-vertical-support-20261101/baseline-hydro.o'])]:
 command=args.copy();command[command.index('-o')+1]=str(c/('trace-'+arm));i=command.index('libjudas_engine.a');command[i:i]=list(map(str,objects));subprocess.run(command,cwd=b,check=True)
