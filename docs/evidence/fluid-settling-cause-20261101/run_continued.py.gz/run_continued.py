from pathlib import Path
import subprocess,os,time,json
c=Path(__file__).resolve().parent;r=c.parents[1];results=[]
for arm in ['current','baseline']:
 for case in ['half_020','half_025','light_80kg']:
  dest=c/('continued-'+arm+'-'+case);command=[str(c/('continued-'+arm)),'--case',case,'--output',str(dest)];env=dict(os.environ,JUDAS_FLUID_FORCE_TRACE=str(c/('continued-'+arm+'-'+case+'-forces.csv')));start=time.monotonic()
  with (c/('continued-'+arm+'-'+case+'.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
  results.append({'arm':arm,'case':case,'command':command,'exit_code':code,'seconds':time.monotonic()-start});(c/'CONTINUATION_RUNS.json').write_text(json.dumps(results,indent=2)+'\n');print(arm,case,code,flush=True)
