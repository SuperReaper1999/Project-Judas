from pathlib import Path
import csv,json,math
c=Path(__file__).resolve().parent;result={}
for arm in ['baseline','current']:
 for case in ['half_020','half_025','light_80kg']:
  p=c/f'continued-{arm}-{case}';original=list(csv.DictReader((p/(case+'.csv')).open()));before=list(csv.DictReader((c/f'{arm}-{case}'/(case+'.csv')).open()));keys=[k for k in original[0] if 'ms' not in k];same=all(all(a[k]==b[k] for k in keys) for a,b in zip(original,before));assert same
  more=list(csv.DictReader((p/(case+'_continuation.csv')).open()));allrows=original+more;windows={}
  for lo,hi in [(0,1),(1,2),(2,3),(3,4),(7,8),(8,10),(10,12),(11,12)]:
   rows=allrows[lo*60:hi*60];v=[float(r['vy']) for r in rows];y=[float(r['y']) for r in rows];f=[float(r.get('fraction',r.get('immersion'))) for r in rows];windows[f'{lo}-{hi}']={'rms_v':math.sqrt(sum(a*a for a in v)/len(v)),'max_abs_v':max(abs(a) for a in v),'y_range':max(y)-min(y),'mean_fraction':sum(f)/len(f)}
  force=list(csv.DictReader((c/f'continued-{arm}-{case}-forces.csv').open()));result[arm+'-'+case]={'original_240_physical_rows_exact':same,'continued_rows':len(more),'windows':windows,'positive_relative_drag_work_steps':sum(float(row['relative_drag_work'])>1e-8 for row in force),'maximum_relative_drag_work_J':max(float(row['relative_drag_work']) for row in force)}
(c/'CONTINUATION_ANALYSIS.json').write_text(json.dumps(result,indent=2)+'\n')
for name,v in result.items():print(name, 'rms3-4',v['windows']['3-4']['rms_v'],'rms10-12',v['windows']['10-12']['rms_v'],'peak10-12',v['windows']['10-12']['max_abs_v'],'range10-12',v['windows']['10-12']['y_range'],'fraction10-12',v['windows']['10-12']['mean_fraction'])
