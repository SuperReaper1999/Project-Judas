from pathlib import Path
c=Path(__file__).resolve().parent;r=c.parents[1]
s=(r/'src/ProductionFluidCoupling.cpp').read_text().replace('#include <stdexcept>','#include <stdexcept>\n#include <fstream>\n#include <iomanip>\n#include <cstdlib>')
needle='''    s.measured.totalMilliseconds=Milliseconds(started);'''
# Insert at the end of the per-body loop, before the original phase timing.
insert='''        if(const char* path=std::getenv("JUDAS_FLUID_FORCE_TRACE")) {
            static std::ofstream trace(path);
            static bool header=false;
            if(!header){trace<<"row,body,dt,pending,mass,x,y,z,vx,vy,vz,wx,wy,wz,cx,cy,cz,gx,gy,gz,fraction,fvx,fvy,fvz,fax,fay,faz,predvx,predvy,predvz,bfx,bfy,bfz,btx,bty,btz,dfx,dfy,dfz,dtx,dty,dtz,rx,ry,rz,relative_drag_work\\n";header=true;trace<<std::setprecision(17);}
            static unsigned row=0;
            const float mass=p.GetMass(body.handle);
            const auto v=p.GetLinearVelocity(body.handle),omega=p.GetAngularVelocity(body.handle);
            const auto arm=hydro.submergedCentroid-pose.position;
            const auto gravity=world.Gravity().Sample(pose.position);
            const auto invI=glm::inverse(p.GetInertiaWorld(body.handle));
            const auto liquid=hydro.fluidVelocity+hydro.fluidAcceleration*float(s.pending+dt);
            const auto relative=v+hydro.buoyancyForce*(dt/mass)+glm::cross(omega+invI*hydro.buoyancyTorque*dt,arm)-liquid;
            const auto cross=CrossMatrix(arm);const auto invM=glm::mat3(1.f/mass)-cross*invI*cross;
            const auto impulse=diagnostic.dragForce*dt;const auto dragTorque=glm::cross(arm,diagnostic.dragForce);
            const double work=glm::dot(glm::dvec3(impulse),glm::dvec3(relative))+.5*glm::dot(glm::dvec3(impulse),glm::dmat3(invM)*glm::dvec3(impulse));
            trace<<row++<<','<<body.handle.id<<','<<dt<<','<<s.pending<<','<<mass;
            const auto vector=[&](glm::vec3 a){trace<<','<<a.x<<','<<a.y<<','<<a.z;};
            vector(pose.position);vector(v);vector(omega);vector(arm);vector(gravity);trace<<','<<hydro.fraction;
            vector(hydro.fluidVelocity);vector(hydro.fluidAcceleration);vector(liquid);vector(hydro.buoyancyForce);vector(hydro.buoyancyTorque);vector(diagnostic.dragForce);vector(dragTorque);vector(relative);trace<<','<<work<<'\\n';
        }
'''
loc=s.index(needle);before=s[:loc];assert before.rstrip().endswith('}');idx=before.rfind('    }');s=s[:idx]+insert+s[idx:];(c/'TraceCoupling.cpp').write_text(s)
