from pathlib import Path
import os,subprocess,json,time
c=Path(__file__).resolve().parent;r=c.parents[1];results=[]
for arm in ['baseline','current']:
 for case in ['half_020','half_025','light_80kg']:
  dest=c/(arm+'-'+case);command=[str(c/('trace-'+arm)),'--case',case,'--output',str(dest)];trace=c/(arm+'-'+case+'-forces.csv');start=time.monotonic()
  with (c/(arm+'-'+case+'.log')).open('w') as log:res=subprocess.run(command,cwd=r,env=dict(os.environ,JUDAS_FLUID_FORCE_TRACE=str(trace)),stdout=log,stderr=subprocess.STDOUT,timeout=120)
  results.append({'arm':arm,'case':case,'command':command,'exit_code':res.returncode,'seconds':time.monotonic()-start});(c/'TRACE_RUNS.json').write_text(json.dumps(results,indent=2)+'\n');print(arm,case,res.returncode,flush=True)
