from pathlib import Path
import csv,json,math
c=Path(__file__).resolve().parent;r=c.parents[1]
results={}
for arm in ['baseline','current']:
 for case in ['half_020','half_025','light_80kg']:
  trace=list(csv.DictReader((c/f'{arm}-{case}-forces.csv').open()));physics=list(csv.DictReader((c/f'{arm}-{case}/{case}.csv').open()));assert len(trace)==len(physics)==240
  original=(r/'.cache/fluid-vertical-support-20261101/final-cases'/case/(case+'.csv') if arm=='current' else r/'.cache/fluid-body-support-integration-20261031/phase11/production-final'/(case+'.csv'))
  equivalent=None
  if original.exists():
   before=list(csv.DictReader(original.open()));keys=[k for k in before[0] if 'ms' not in k];equivalent=all(all(a[k]==b[k] for k in keys) for a,b in zip(before,physics));assert equivalent,(arm,case)
  residual=[];work=[]
  for a,b in zip(trace,physics):
   dt=float(a['dt']);mass=float(a['mass']);pred=float(a['vy'])+(float(a['bfy'])+float(a['dfy']))*dt/mass;residual.append(abs(pred-float(b['vy'])));work.append(float(a['relative_drag_work']))
  tail=trace[-60:]
  vec=lambda p,a:math.sqrt(sum(float(p[a+k])**2 for k in ['x','y','z']))
  results[arm+'-'+case]={'rows':len(trace),'trace_physics_exact':equivalent,'end_velocity':float(physics[-1]['vy']),'max_force_velocity_residual_mps':max(residual),'maximum_relative_drag_work_J':max(work),'positive_relative_drag_work_steps':sum(w>1e-8 for w in work),'sum_relative_drag_work_J':sum(work),'last_second_max_fluid_speed_mps':max(vec(t,'fv') for t in tail),'last_second_max_predicted_fluid_speed_mps':max(vec(t,'predv') for t in tail),'last_second_max_fluid_acceleration_mps2':max(vec(t,'fa') for t in tail),'last_second_rms_body_speed_mps':math.sqrt(sum(float(t['vy'])**2 for t in tail)/len(tail))}
(c/'TRACE_ANALYSIS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
