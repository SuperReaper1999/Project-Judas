#include "PhysicsWorld.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
struct Parameters {std::string name;double hx,hy,hz,y0,mass,g,surface;};
struct State {double y,v,loss;};
double Fraction(const Parameters& p,double y){return std::clamp((p.surface-y+p.hy)/(2*p.hy),0.,1.);}
double Potential(const Parameters& p,double y){
    const double area=4*p.hx*p.hz,k=1000*p.g*area;
    const double equilibrium=p.surface+p.hy-p.mass/(1000*area),low=p.surface-p.hy,high=p.surface+p.hy;
    const auto partial=[&](double a){return .5*k*(a-equilibrium)*(a-equilibrium);};
    if(y<low)return partial(low)+(p.mass*p.g-1000*p.g*8*p.hx*p.hy*p.hz)*(y-low);
    if(y>high)return partial(high)+p.mass*p.g*(y-high);
    return partial(y);
}
State Rhs(const Parameters& p,State s){const double f=Fraction(p,s.y),b=1000*p.g*8*p.hx*p.hy*p.hz*f;return {s.v,-p.g+b/p.mass-2*f*s.v,2*p.mass*f*s.v*s.v};}
State Plus(State a,State b,double h){return {a.y+h*b.y,a.v+h*b.v,a.loss+h*b.loss};}
void Continuous(const Parameters& p,int steps){
    const double h=4./steps;State s{p.y0,0,0};const double initial=Potential(p,s.y);
    double maxEnergyIncrease=0,previous=initial;
    for(int i=0;i<steps;++i){auto a=Rhs(p,s),b=Rhs(p,Plus(s,a,h*.5)),c=Rhs(p,Plus(s,b,h*.5)),d=Rhs(p,Plus(s,c,h));s.y+=h*(a.y+2*b.y+2*c.y+d.y)/6;s.v+=h*(a.v+2*b.v+2*c.v+d.v)/6;s.loss+=h*(a.loss+2*b.loss+2*c.loss+d.loss)/6;double energy=.5*p.mass*s.v*s.v+Potential(p,s.y);maxEnergyIncrease=std::max(maxEnergyIncrease,energy-previous);previous=energy;}
    std::cout<<p.name<<",continuous,"<<steps<<','<<h<<','<<s.y<<','<<s.v<<','<<previous<<','<<s.loss<<','<<previous+s.loss-initial<<','<<maxEnergyIncrease<<",0\n";
}
void Native(const Parameters& p,int hz){
    PhysicsWorld physics;physics.Init();const float dt=1.f/hz;const auto body=physics.CreateDynamicBox({0,float(p.y0),0},{float(p.hx),float(p.hy),float(p.hz)},float(p.mass),0,0);
    const float mass=physics.GetMass(body);const double volume=8*p.hx*p.hy*p.hz;double residual=0;
    for(int i=0;i<4*hz;++i){const double y=physics.GetTransform(body).position.y;const float f=float(Fraction(p,y));physics.ApplyLinearAcceleration(body,{0,-float(p.g),0},dt);const float buoyancy=float(1000*p.g*volume*f);const float relative=physics.GetLinearVelocity(body).y+buoyancy*(dt/mass);const float alpha=-std::expm1(-2*f*dt);const float drag=-alpha*mass*relative/dt;const float expected=physics.GetLinearVelocity(body).y+(buoyancy+drag)*(dt/mass);physics.ApplyForce(body,{0,buoyancy+drag,0});physics.Step(dt);residual=std::max(residual,double(std::abs(expected-physics.GetLinearVelocity(body).y)));}
    const double y=physics.GetTransform(body).position.y,v=physics.GetLinearVelocity(body).y;
    std::cout<<p.name<<",native,"<<4*hz<<','<<dt<<','<<y<<','<<v<<','<<.5*p.mass*v*v+Potential(p,y)<<",0,0,0,"<<residual<<'\n';
}
int main(int argc,char** argv){if(argc!=2)return 2;std::ifstream in(argv[1]);Parameters p;std::cout<<std::setprecision(17)<<"case,kind,steps,dt,y4,v4,energy4,drag_loss,work_residual,max_energy_increase,velocity_kick_residual\n";while(in>>p.name>>p.hx>>p.hy>>p.hz>>p.y0>>p.mass>>p.g>>p.surface){for(int n:{960,3840,15360,61440})Continuous(p,n);for(int hz:{60,120,240,960})Native(p,hz);}return 0;}
