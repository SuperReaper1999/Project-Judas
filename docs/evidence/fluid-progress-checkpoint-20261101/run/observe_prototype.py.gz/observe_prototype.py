from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-checkpoint-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),'-I'+str(r/'tests'),*get('CXX_FLAGS')]
subprocess.run([*base,str(r/'tests/FluidSurfaceObservationTests.cpp'),'-o',str(c/'surface-tests')],check=True)
with (c/'surface-rotated-controls.log').open('w') as log:subprocess.run([str(c/'surface-tests')],stdout=log,check=True)
s=(r/'tests/ProductionFluidTests.cpp').read_text().replace('#include "FluidSettlingContract.h"','#include "FluidSettlingContract.h"\n#include "FluidSurfaceObservation.h"')
needle='  if(originalMean){mean+=';assert needle in s
s=s.replace(needle,'''  if((originalMean||lateSample) && densityRatio==.5f && g>0 && !freefall && !observationalScale) {
   const auto localSurface=FluidTest::ObservePoolSurface(world.Fluid().Particles(),q,pose,half,spacing,nx);
   std::cout<<"SURFACE "<<name<<" step="<<step<<" old="<<observedFraction.value_or(-1)<<" local="<<(localSurface?localSurface->fraction:-1)<<" columns="<<(localSurface?localSurface->columns:0)<<" rms="<<(localSurface?localSurface->fitRms:-1)<<'\\n';
   observedFraction=localSurface?std::optional<double>(localSurface->fraction):std::nullopt;
  }
''' +needle)
(c/'LocalObservedProduction.cpp').write_text(s);subprocess.run([*base,'-c',str(c/'LocalObservedProduction.cpp'),'-o',str(c/'local-main.o')],check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'local-main.o') if x.endswith('ProductionFluidTests.cpp.o') else str(c/'local-observed') if x=='judas_production_fluid_tests' else x for x in a];i=a.index('libjudas_engine.a');a[i:i]=[str(c/'hydro.o'),str(c/'coupling.o')];subprocess.run(a,cwd=b,check=True)
command=[str(c/'local-observed'),'--case','half_025','--output',str(c/'local-observed-coarse')]
with (c/'local-observed-coarse.log').open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
(c/'ORACLE_PROTOTYPE_COMMAND.json').write_text(json.dumps({'command':command,'exit_code':code,'scope':'Predeclared local affine stencil; unchanged +/-0.10 acceptance, all raw remote-plane observations retained.'},indent=2));print('Local observer prototype exit',code)
