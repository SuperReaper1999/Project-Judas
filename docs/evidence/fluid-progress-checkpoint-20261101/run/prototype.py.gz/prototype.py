from pathlib import Path
import subprocess,shlex,json
r=Path.cwd();c=r/'.cache/fluid-checkpoint-20261101';b=r/'.cache/2d-stage1-build';f=(b/'CMakeFiles/judas_production_fluid_tests.dir/flags.make').read_text();get=lambda k:shlex.split(next(x.split(' = ',1)[1] for x in f.splitlines() if x.startswith(k+' = ')));base=['c++',*get('CXX_DEFINES'),*get('CXX_INCLUDES'),*get('CXX_FLAGS')]
subprocess.run([*base,str(r/'tests/FluidVolumeDragTests.cpp'),'-o',str(c/'drag-tests')],check=True)
with (c/'drag-tests.log').open('w') as log:subprocess.run([str(c/'drag-tests')],stdout=log,check=True)
s=(r/'src/ProductionFluidCoupling.cpp').read_text().replace('#include "FluidHydrostatics.h"','#include "FluidHydrostatics.h"\n#include "FluidVolumeDrag.h"')
start=s.index('            const float mass=p.GetMass(body.handle);',s.index('void ProductionFluidCoupling::PrepareRigidStep'));end=s.index('\n        }',start)
s=s[:start]+'''            const double mass=p.GetMass(body.handle);
            const glm::dmat3 inertia(p.GetInertiaWorld(body.handle));
            const auto velocity=glm::dvec3(p.GetLinearVelocity(body.handle))+glm::dvec3(hydro.buoyancyForce)*(dt/mass);
            const auto omega=glm::dvec3(p.GetAngularVelocity(body.handle))+glm::inverse(inertia)*glm::dvec3(hydro.buoyancyTorque)*double(dt);
            const auto drag=EvaluateFluidVolumeDrag(hydro,mass,inertia,velocity,omega,
                world.FluidSettingsUsed().hydrostaticDragRate,dt,s.pending+dt);
            diagnostic.dragForce=glm::vec3(drag.linear/double(dt));
            p.ApplyForce(body.handle,diagnostic.dragForce);
            p.ApplyTorque(body.handle,glm::vec3(drag.angular/double(dt)));'''+s[end:]
s=s.replace('glm::mat3 CrossMatrix(const glm::vec3& r) {\n    return glm::mat3(0,r.z,-r.y,-r.z,0,r.x,r.y,-r.x,0);\n}\n','');(c/'DistributedCoupling.cpp').write_text(s)
for source,obj in [(r/'src/FluidHydrostatics.cpp',c/'hydro.o'),(c/'DistributedCoupling.cpp',c/'coupling.o')]:subprocess.run([*base,'-c',str(source),'-o',str(obj)],check=True)
a=shlex.split((b/'CMakeFiles/judas_production_fluid_tests.dir/link.txt').read_text());a=[str(c/'distributed') if x=='judas_production_fluid_tests' else x for x in a];a[a.index('libjudas_engine.a'):a.index('libjudas_engine.a')]=[str(c/'hydro.o'),str(c/'coupling.o')];subprocess.run(a,cwd=b,check=True)
command=[str(c/'distributed'),'--case','half_025','--output',str(c/'distributed-coarse')]
with (c/'distributed-coarse.log').open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
(c/'PROTOTYPE_COMMAND.json').write_text(json.dumps({'command':command,'exit_code':code,'status':'Distributed same-coefficient viscous loading prototype; no acceptance changes'},indent=2));print('Prototype exit',code)
