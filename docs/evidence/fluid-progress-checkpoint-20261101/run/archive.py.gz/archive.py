from pathlib import Path
import subprocess,hashlib,json,gzip,shutil,datetime
r=Path.cwd();c=r/'.cache/fluid-checkpoint-20261101';e=r/'docs/evidence/fluid-progress-checkpoint-20261101';e.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,d):
 d.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix=='.json':shutil.copyfile(p,d)
 else:d.with_name(d.name+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for folder in ['final','post-cleanup','before','rejected-oracle-src']:
 for p in (c/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.cpp','.h','.log','.json','.csv','.judas'}:copy(p,e/'run'/p.relative_to(c))
for p in c.iterdir():
 if p.is_file() and p.suffix in {'.cpp','.h','.py','.log','.json','.csv'}:copy(p,e/'run'/p.name)
for step in [503,504,505,506,507,508,509,510,511,512]:
 for p in (c/'coarse').glob(f'half_025_before{step}_*.csv'):copy(p,e/'run/coarse'/p.name)
files=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidColumnLayers.h','src/FluidWetFootprint.h','src/FluidVolumeDrag.h','src/ProductionFluidCoupling.cpp','tests/FluidHydrostaticsTests.cpp','tests/FluidVerticalSupportTests.cpp','tests/FluidVolumeDragTests.cpp','tests/ProductionFluidTests.cpp','tests/FluidSettlingContract.h','tests/FluidSettlingContractTests.cpp','tests/FluidSettlingReferenceTests.cpp','CMakeLists.txt','tools/validation/suites.json','docs/FLUID_PROGRESS_CHECKPOINT.md']
for f in files:copy(r/f,e/'source'/f)
assert (r/'tests/ProductionFluidTests.cpp').read_bytes()==(c/'before/tests/ProductionFluidTests.cpp').read_bytes()
post=json.loads((c/'post-cleanup/RESULTS.json').read_text());assert post['coarse_720_rows_physically_exact']
for x in post['checks']:
 if '--case' not in x['command']:assert x['exit_code']==0,x
checks=json.loads((c/'final/RESULTS.json').read_text());assert all(x['exit_code']==0 for x in checks if x['name'] not in ['production','legacy'])
prov={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'main':subprocess.check_output(['git','rev-parse','main'],text=True).strip(),'scope':'Verified engine corrections; NOT a full fluid unlock. One existing production immersion assertion remains failed. Tests/limits unchanged.','source_sha256':{n:sha(r/n) for n in files},'post_cleanup_binary_sha256':{n:sha(r/'.cache/2d-stage1-build'/n) for n in ['judas_production_fluid_tests','judas_fluid_volume_drag_tests','judas_fluid_vertical_support_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests']},'pre_cleanup_full_qualification':'run/final/RESULTS.json','post_cleanup_validation':'run/post-cleanup/RESULTS.json','provenance_note':'Binaries built from explicitly fingerprinted dirty Experimental sources before checkpoint commit. Source identity is verified against commit after checkpointing.'}
(e/'FINAL_PROVENANCE.json').write_text(json.dumps(prov,indent=2)+'\n')
(e/'README.txt').write_text('Experimental fluid engineering checkpoint, 2026-11-01\n\nRead ../../FLUID_PROGRESS_CHECKPOINT.md.\nrun/final retains full combined production/legacy, focused controls and flat/planet demo evidence.\nrun/post-cleanup shows exact 720-row physical replay after the behavior-preserving iterator cleanup and fresh focused tests.\nrun/before preserves source before this continuation.\nrun/DistributedCoupling.cpp.gz and prototype scripts show the bounded drag experiment.\nrun/rejected-oracle-src retains the non-adopted affine observer and its manufactured tests.\nIt passed 92 manufactured controls but failed on actual pool data; do not substitute it into acceptance.\nSurface boundary-failure output/source is retained separately.\nThe first oracle test setup used an invalid zero quaternion; that setup error was corrected before its claimed controls.\nCoarse force traces and selected before-step captures retain the physical peak investigation.\nsource contains exact final candidate files.\nNo binaries, builds, independent research or unrelated project assets are bundled.\nAll non-JSON text is gzip with mtime=0; JSON is uncompressed.\nFINAL_PROVENANCE.json gives source/binary fingerprints.\nSHA256SUMS.json covers all files except itself.\nOne mandatory original 3-4 s remote-plane immersion assertion remains failed.\nAlpha fluids remain locked; main and published releases are unchanged.\n')
m={str(p.relative_to(e)):sha(p) for p in sorted(e.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'};(e/'SHA256SUMS.json').write_text(json.dumps(m,indent=2)+'\n')
for n,h in m.items():assert sha(e/n)==h,n
print(len(m),'files verified;',sum(p.stat().st_size for p in e.rglob('*') if p.is_file()),'bytes')
