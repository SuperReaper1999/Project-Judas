#pragma once
#include "FluidWorld.h"
#include "PhysicsWorld.h"
#include <glm/gtc/quaternion.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <optional>
#include <vector>

namespace FluidTest {
struct SurfaceObservation { double fraction=0, fitRms=0;std::size_t columns=0; };
inline double Turn(glm::dvec2 a,glm::dvec2 b,glm::dvec2 c){auto u=b-a,v=c-a;return u.x*v.y-u.y*v.x;}
inline std::vector<glm::dvec2> ProjectedHull(const BodyTransform& pose,glm::vec3 half,glm::quat sceneFrame) {
    std::vector<glm::dvec2> points,hull;
    const auto local=glm::inverse(glm::dquat(sceneFrame));
    for(int x:{-1,1})for(int y:{-1,1})for(int z:{-1,1}) {
        auto p=local*(glm::dvec3(pose.position)+glm::dquat(pose.rotation)*(glm::dvec3(half)*glm::dvec3(x,y,z)));
        points.emplace_back(p.x,p.z);
    }
    std::sort(points.begin(),points.end(),[](auto a,auto b){return a.x<b.x || (a.x==b.x && a.y<b.y);});
    points.erase(std::unique(points.begin(),points.end()),points.end());
    for(auto p:points){while(hull.size()>1 && Turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
    const auto lower=hull.size();
    for(auto i=points.size()-1;i-->0;){auto p=points[i];while(hull.size()>lower && Turn(hull[hull.size()-2],hull.back(),p)<=0)hull.pop_back();hull.push_back(p);}
    if(!hull.empty())hull.pop_back();
    return hull;
}
// Independent fixture oracle: an exterior, local affine free-surface fit in the
// authored reservoir frame. It does not call the engine wet sampler, reuse its
// columns, or infer expected immersion from the body's mass/force. Supported
// scope is a connected single-surface pool, not overhangs or layered liquids.
inline std::optional<SurfaceObservation> ObservePoolSurface(
    const std::vector<FluidParticle>& particles,glm::quat frame,const BodyTransform& pose,
    glm::vec3 half,double spacing,int nx) {
    for(int i=0;i<3;++i)if(!std::isfinite(pose.position[i]) || !std::isfinite(half[i]) || half[i]<=0)return {};
    for(int i=0;i<4;++i)if(!std::isfinite(frame[i]) || !std::isfinite(pose.rotation[i]))return {};
    if(!(glm::dot(frame,frame)>0) || !(glm::dot(pose.rotation,pose.rotation)>0))return {};
    if(!(spacing>0) || !std::isfinite(spacing) || nx<1 || nx>4096)return {};
    auto hull=ProjectedHull(pose,half,frame);if(hull.size()<3)return {};
    const auto inverse=glm::inverse(glm::dquat(frame));const auto center=inverse*glm::dvec3(pose.position);
    std::vector<glm::dvec3> tops(std::size_t(nx)*nx,glm::dvec3(0,-std::numeric_limits<double>::infinity(),0));
    for(const auto& particle:particles) {
        auto p=inverse*glm::dvec3(particle.position);
        if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))return {};
        glm::dvec2 point(p.x,p.z);bool inside=true;
        // Source positions/poses are binary32. Points on the projected solid
        // boundary must not alternate inside/outside with row-height roundoff
        // after a rigid frame rotation; that would mistake buried rows for tops.
        const double tolerance=16*std::numeric_limits<float>::epsilon()*
            (1+glm::length(p)+glm::length(glm::dvec3(pose.position))+glm::length(glm::dvec3(half)));
        for(std::size_t i=0;i<hull.size();++i)inside &= Turn(hull[i],hull[(i+1)%hull.size()],point)>=
            -tolerance*glm::length(hull[(i+1)%hull.size()]-hull[i]);
        if(inside)continue;
        const int x=int(std::floor((p.x+1)/spacing)),z=int(std::floor((p.z+1)/spacing));
        if(x<0 || z<0 || x>=nx || z>=nx)continue;
        auto& top=tops[std::size_t(z)*nx+x];p.y+=.5*spacing;if(p.y>top.y)top=p;
    }
    struct Datum {glm::dvec3 basis;double height,weight;};std::vector<Datum> data;
    double a[3][4]{};const double radius=2*spacing;
    for(auto p:tops) {
        if(!std::isfinite(p.y))continue;
        glm::dvec2 point(p.x,p.z);double distance2=std::numeric_limits<double>::infinity();
        for(std::size_t i=0;i<hull.size();++i){auto v=hull[(i+1)%hull.size()]-hull[i];auto d=point-hull[i];double t=std::clamp(glm::dot(d,v)/glm::dot(v,v),0.,1.);distance2=std::min(distance2,glm::dot(d-t*v,d-t*v));}
        if(distance2>=radius*radius)continue;
        const double kernel=1-distance2/(radius*radius),weight=kernel*kernel;
        const glm::dvec3 basis(1,p.x-center.x,p.z-center.z);data.push_back({basis,p.y-center.y,weight});
        for(int i=0;i<3;++i){for(int j=0;j<3;++j)a[i][j]+=weight*basis[i]*basis[j];a[i][3]+=weight*basis[i]*(p.y-center.y);}
    }
    if(data.size()<3)return {};
    double scale=0;for(int i=0;i<3;++i)for(int j=0;j<3;++j)scale=std::max(scale,std::abs(a[i][j]));
    for(int col=0;col<3;++col){int pivot=col;for(int row=col+1;row<3;++row)if(std::abs(a[row][col])>std::abs(a[pivot][col]))pivot=row;
        if(std::abs(a[pivot][col])<=128*std::numeric_limits<double>::epsilon()*scale)return {};
        for(int j=col;j<4;++j)std::swap(a[col][j],a[pivot][j]);
        double v=a[col][col];for(int j=col;j<4;++j)a[col][j]/=v;
        for(int row=0;row<3;++row)if(row!=col){v=a[row][col];for(int j=col;j<4;++j)a[row][j]-=v*a[col][j];}}
    const glm::dvec3 plane(a[0][3],a[1][3],a[2][3]);double error=0,weight=0;
    for(const auto& p:data){double e=glm::dot(p.basis,plane)-p.height;error+=p.weight*e*e;weight+=p.weight;}
    unsigned wet=0;constexpr int n=32;
    for(int z=0;z<n;++z)for(int y=0;y<n;++y)for(int x=0;x<n;++x){
        const auto offset=glm::dvec3(half)*(glm::dvec3(2*x+1,2*y+1,2*z+1)/double(n)-1.);
        const auto p=inverse*(glm::dvec3(pose.position)+glm::dquat(pose.rotation)*offset);
        const double surface=center.y+glm::dot(glm::dvec3(1,p.x-center.x,p.z-center.z),plane);
        wet+=p.x>=-1 && p.x<=1 && p.z>=-1 && p.z<=1 && p.y<surface;
    }
    return SurfaceObservation{double(wet)/(n*n*n),std::sqrt(error/weight),data.size()};
}
}
