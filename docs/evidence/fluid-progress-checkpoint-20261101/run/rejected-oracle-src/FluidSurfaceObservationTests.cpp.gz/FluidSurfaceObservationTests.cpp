#include "FluidSurfaceObservation.h"
#include <iostream>
unsigned checks=0,failures=0;
void Check(bool value,const char* label){++checks;if(!value){++failures;std::cout<<"FAIL "<<label<<'\n';}}
int main(){
    for(double spacing:{.1,.2,.25})for(double slope:{-.4,0.,.4})for(float angle:{0.f,.7f}) {
        const float half=.2f;BodyTransform pose;pose.position={.45f,1.5f,0};pose.rotation=glm::angleAxis(angle,glm::normalize(glm::vec3(1,2,3)));
        std::vector<FluidParticle> cloud;
        const int nx=int(std::lround(2/spacing));
        for(int z=0;z<nx;++z)for(int x=0;x<nx;++x){double px=(x+.5)*spacing-1,pz=(z+.5)*spacing-1;double height=1.5+slope*(px-pose.position.x);
            for(int y=0;y<8;++y){FluidParticle p;p.position={px,height-(y+.5)*spacing,pz};p.mass=1000*spacing*spacing*spacing;cloud.push_back(p);}}
        auto observation=FluidTest::ObservePoolSurface(cloud,glm::quat(1,0,0,0),pose,glm::vec3(half),spacing,nx);
        Check(observation.has_value(),"affine exterior patch is observable");
        if(observation){Check(std::abs(observation->fraction-.5)<.006,"known sloped half-volume remains half submerged");Check(observation->fitRms<2e-6,"affine patch residual stays at representation error");}
        auto turn=glm::angleAxis(.83f,glm::normalize(glm::vec3(1,-2,3)));
        auto rotatedCloud=cloud;for(auto& particle:rotatedCloud)particle.position=turn*particle.position;
        auto rotatedPose=pose;rotatedPose.position=turn*pose.position;rotatedPose.rotation=turn*pose.rotation;
        auto covariant=FluidTest::ObservePoolSurface(rotatedCloud,turn,rotatedPose,glm::vec3(half),spacing,nx);
        if(!covariant || !observation || std::abs(covariant->fraction-observation->fraction)>=.003)
            std::cout<<"ROTATION spacing="<<spacing<<" slope="<<slope<<" angle="<<angle<<" before="<<(observation?observation->fraction:-1)<<" after="<<(covariant?covariant->fraction:-1)<<" rms="<<(covariant?covariant->fitRms:-1)<<'\n';
        Check(covariant && observation && std::abs(covariant->fraction-observation->fraction)<.003,
              "rotated gravity preserves the independent volume observation");
        auto shifted=pose;shifted.position.y+=.15f;auto wrong=FluidTest::ObservePoolSurface(cloud,glm::quat(1,0,0,0),shifted,glm::vec3(half),spacing,nx);
        Check(wrong && wrong->fraction<.30,"independent observer detects incorrect floating height");
    }
    std::vector<FluidParticle> empty;BodyTransform pose;pose.position={0,1.5f,0};
    Check(!FluidTest::ObservePoolSurface(empty,glm::quat(1,0,0,0),pose,glm::vec3(.2f),.2,10),"missing exterior data cannot pass as zero immersion");
    Check(!FluidTest::ObservePoolSurface(empty,glm::quat(1,0,0,0),pose,glm::vec3(.2f),0,10),"invalid resolution rejected");
    std::cout<<"Fluid surface observation: "<<checks<<" checks, "<<failures<<" failures\n";return failures?1:0;
}
