from pathlib import Path
import subprocess,json,hashlib,time
r=Path.cwd();c=r/'.cache/fluid-checkpoint-20261101';b=r/'.cache/2d-stage1-build';out=c/'final';out.mkdir(exist_ok=True);results=[]
names=['src/FluidHydrostatics.cpp','src/FluidHydrostatics.h','src/FluidVolumeDrag.h','src/ProductionFluidCoupling.cpp','tests/ProductionFluidTests.cpp','tests/FluidVolumeDragTests.cpp','tests/FluidVerticalSupportTests.cpp'];source={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names};(out/'SOURCE_BEFORE.json').write_text(json.dumps(source,indent=2))
checks=[('drag','judas_fluid_volume_drag_tests',[]),('vertical','judas_fluid_vertical_support_tests',[]),('hydro','judas_fluid_hydrostatics_tests',[]),('lateral','judas_fluid_wet_support_tests',[]),('contract','judas_fluid_settling_contract_tests',[]),('reference','judas_fluid_settling_reference_tests',[]),('swimming','judas_player_swimming_tests',[]),('policy','judas_project_fluid_policy_tests',[]),('lifecycle','judas_fluid_lifecycle_qualification_tests',[]),('production','judas_production_fluid_tests',['--output',str(out/'production')]),('legacy','judas_production_fluid_tests',['--legacy-four-second','--output',str(out/'legacy')]),('pool','judas_fluid_demo_integration_tests',['--scene','pool','--output',str(out/'demo-pool')]),('planet','judas_fluid_demo_integration_tests',['--scene','planet','--output',str(out/'demo-planet')])]
for name,target,args in checks:
 command=[str(b/target),*args];start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'command':command,'exit_code':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256((b/target).read_bytes()).hexdigest()});(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(name,code,flush=True)
for n,h in source.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
(out/'SOURCE_UNCHANGED.json').write_text(json.dumps(source,indent=2))
