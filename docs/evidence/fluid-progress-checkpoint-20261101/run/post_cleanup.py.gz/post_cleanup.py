from pathlib import Path
import subprocess,json,csv,time,hashlib
r=Path.cwd();c=r/'.cache/fluid-checkpoint-20261101';b=r/'.cache/2d-stage1-build';d=c/'post-cleanup';d.mkdir(exist_ok=True);o=[]
for n in ['judas_fluid_vertical_support_tests','judas_fluid_hydrostatics_tests','judas_fluid_wet_support_tests','judas_fluid_volume_drag_tests','judas_production_fluid_tests']:
 cmd=[str(b/n)];args=[] if n!='judas_production_fluid_tests' else ['--case','half_025','--output',str(d/'coarse')];cmd+=args;t=time.monotonic()
 with (d/(n+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 o.append({'command':cmd,'exit_code':code,'seconds':time.monotonic()-t,'binary_sha256':hashlib.sha256((b/n).read_bytes()).hexdigest()})
a=list(csv.DictReader((c/'final/production/half_025.csv').open()));z=list(csv.DictReader((d/'coarse/half_025.csv').open()));keys=[k for k in a[0] if k not in ['fluid_step_ms','total_coupling_ms']];assert len(a)==len(z)==720 and all(all(x[k]==y[k] for k in keys) for x,y in zip(a,z));print('All 720 physical rows unchanged after the one-interval/iterator cleanup')
(d/'RESULTS.json').write_text(json.dumps({'checks':o,'coarse_720_rows_physically_exact':True,'excluded_columns':['fluid_step_ms','total_coupling_ms']},indent=2)+'\n')
