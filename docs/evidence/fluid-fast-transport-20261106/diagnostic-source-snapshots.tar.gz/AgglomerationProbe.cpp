#include "BasinFixture.h"
#include "CutLocalPressure.h"
#include "CutRectangularOwners.h"
#include <chrono>
#include <iomanip>
#include <iostream>
using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;
int main(int argc,char**){
 (void)argc;
 std::cout<<std::setprecision(17);int failed=0;
 for(bool rotated:{false,true}){
  auto fixture=Fixture::Authored(rotated);CutRegionChart chart;CutRegionGeometry geometry;std::string error;
  if(!PrepareCutRegionChart(fixture.layout,fixture.Walls(),fixture.InitialBox(),{-.005,-.015,-.005},{.005,.025,.005},chart,error)||!BuildCutRegionGeometry(chart,{},geometry,error)){std::cerr<<error;return 2;}
  CutDynamicState source;SeedImport import;
  if(!WaterByRegion(fixture,chart,geometry,rotated,source.water,import,error)){std::cerr<<error;return 2;}
  std::vector<double> gas;for(std::size_t i=0;i<source.water.size();++i){gas.push_back(geometry.startCapacity[i]-source.water[i]);source.gasMass.push_back(1.2*gas.back());}
  CutConnectedOwners owners;if(!BuildCutConnectedOwners(chart,geometry,.125,owners,error)){std::cerr<<error;return 2;}
  std::vector<CutRegionWaterPlane> planes;if(!ReconstructCutRegionPhasePlanes(chart,geometry,1,source.water,gas,{},planes,error)){std::cerr<<error;return 2;}
  auto vent=FullCutRegionGasVent(chart,1,1);std::vector<CutPhaseBoundary> ports;
  for(std::size_t i=0;i<chart.regions.size();++i)if(MeasureCutRegionGasVent(chart.regions[i],geometry.motion,vent,planes[i]).mean>0.)ports.push_back({i,1,1,0.,0.,true});
  CutSpatialField field;std::vector<double> zero(geometry.faces.size());auto buildStart=std::chrono::steady_clock::now();
  if(!BuildCutSpatialField(chart,geometry,owners,source,zero,ports,field,error,false)){std::cerr<<error;return 2;}
  std::cout<<"BUILD rotated="<<rotated<<" cells="<<field.parent.size()<<" faces="<<field.flux.size()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-buildStart).count()<<std::endl;
  CutRectangularOwners merged;
  auto t=std::chrono::steady_clock::now();
  bool ok=BuildCutRectangularOwners(field.chart,field.geometry,.125,merged,error);
  std::cout<<"LOCAL_AGGLOMERATION rotated="<<rotated<<" admitted="<<ok<<" from="<<field.parent.size()<<" to="<<merged.chart.regions.size()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count()<<" error="<<error<<std::endl;
  failed+=!ok;

 }
 return failed?1:0;
}
