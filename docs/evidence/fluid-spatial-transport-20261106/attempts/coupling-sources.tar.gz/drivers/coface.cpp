#include "CutSpatialTransport.h"
#include <iostream>
#include <iomanip>
using namespace judas::volume_grid;
int main(){
 CutRegionChart chart;chart.layout={{2,1,2},1.};double thin=1e-6;
 chart.regions={{{0.,0.,0.},{1.,1.,thin},0},{{0.,0.,thin},{.5,1.,1.+thin},1},{{.5,0.,thin},{1.,1.,1.+thin},2}};
 chart.faces={{0,1,2,{0.,0.,thin},{.5,1.,thin},.5,.5,.5,0.,.5},{0,2,2,{.5,0.,thin},{1.,1.,thin},.5,.5,.5,0.,.5}};
 CutRegionGeometry geometry;std::string error;BuildCutRegionGeometry(chart,{},geometry,error);
 CutConnectedOwners owners;owners.owner={0,0,0};owners.members={{0,1,2}};owners.capacity={1.+thin};owners.lo={{0.,0.,0.}};owners.hi={{1.,1.,1.+thin}};
 CutDynamicState source;source.water={0.,geometry.startCapacity[1],0.};source.gasMass={1.2*thin,0.,1.2*geometry.startCapacity[2]};
 CutSpatialField field;
 if(!BuildCutSpatialField(chart,geometry,owners,source,{-1.,1.},{{1,2,1,-1.,1.,false},{2,2,1,1.,0.,false}},field,error)){std::cout<<error;return 1;}
 for(double h:{1e-8,1e-7,1e-6,.01,1.}){
 CutSpatialResult out;
 bool ok=AdvanceCutSpatial(field,owners,{1.2},h,out,error);double left=0.,right=0.;
 if(ok)for(std::size_t i=0;i<field.parent.size();++i)if(field.parent[i]==0){if(field.chart.regions[i].hi[0]<=.5)left+=out.water[i];else right+=out.water[i];}
 std::cout<<std::setprecision(17)<<"h="<<h<<" ok="<<ok<<" left="<<left<<" right="<<right<<" iterations="<<out.iterations<<" reason="<<error<<'\n';
 }
}
