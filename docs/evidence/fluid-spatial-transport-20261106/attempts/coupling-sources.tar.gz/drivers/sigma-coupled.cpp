#include "BasinFixture.h"
#include "CutOwnedProjection.h"
#include "CutSpatialTransport.h"
#include <chrono>
#include <iostream>
#include <iomanip>
#include <limits>
using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;
int main(){
 int failed=0;
 std::cout<<std::setprecision(17);
 for(bool rotated:{false,true}){
  auto fixture=Fixture::Authored(rotated);CutRegionChart chart;CutRegionGeometry geometry;std::string error;
  if(!PrepareCutRegionChart(fixture.layout,fixture.Walls(),fixture.InitialBox(),{-.005,-.015,-.005},{.005,.025,.005},chart,error)||!BuildCutRegionGeometry(chart,{},geometry,error)){std::cerr<<error;return 2;}
  CutDynamicState source;SeedImport imp;
  if(!WaterByRegion(fixture,chart,geometry,rotated,source.water,imp,error)){std::cerr<<error;return 2;}
  for(std::size_t i=0;i<source.water.size();++i)source.gasMass.push_back(1.2*(geometry.startCapacity[i]-source.water[i]));
  CutConnectedOwners owners;
  if(!BuildCutConnectedOwners(chart,geometry,.125,owners,error)){std::cerr<<error;return 2;}
  double min=std::numeric_limits<double>::infinity();std::size_t largest=0;
  for(std::size_t i=0;i<owners.members.size();++i){if(owners.capacity[i]>0.)min=std::min(min,owners.capacity[i]);largest=std::max(largest,owners.members[i].size());}
  std::cout<<"OWNERS rotated="<<rotated<<" fragments="<<chart.regions.size()<<" owners="<<owners.members.size()<<" minCapacity="<<min<<" maxMembers="<<largest<<std::endl;
  CutDynamicSettings settings;settings.dt=double(tick);settings.gravity={0.,-double(gravity),0.};
  CutOwnedProjection result;result.water={-7.};CutOwnedProjection trial; CutHydroacousticGraphFailure diagnostic;
  auto start=std::chrono::steady_clock::now();
  bool ok=ProjectCutOwnedMaterial(chart,geometry,owners,source,settings,{FullCutRegionGasVent(chart,1,1)},result,error,&diagnostic,&trial);
  failed+=!ok;
  std::cout<<"PROJECTION rotated="<<rotated<<" admitted="<<ok<<" unchanged="<<(result.water==std::vector<double>{-7.})<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" reason="<<error<<std::endl;
  if(!trial.pressure.empty()){
   std::vector<double> fragmentGas(source.water.size()),rho(owners.members.size());
   for(std::size_t i=0;i<fragmentGas.size();++i)fragmentGas[i]=source.gasMass[i]/1.2;
   std::vector<CutRegionWaterPlane> planes;
   if(!ReconstructCutRegionPhasePlanes(chart,geometry,1,source.water,fragmentGas,{},planes,error)){std::cerr<<error;return 2;}
   std::vector<double> mobility(geometry.faces.size()),predictor(mobility.size());
   for(std::size_t f=0;f<mobility.size();++f){auto& face=geometry.faces[f];if(face.meanArea==0.)continue;
    auto a=MeasureCutRegionFaceInertiaVolumes(face,geometry.motion,chart.regions[face.left],true,planes[face.left]);
    auto b=MeasureCutRegionFaceInertiaVolumes(face,geometry.motion,chart.regions[face.right],false,planes[face.right]);
    double mass=1000.*(a[0]+b[0])+1.2*(a[1]+b[1]);
    mobility[f]=face.meanArea*face.meanArea/mass;
    predictor[f]=settings.dt*face.meanArea*settings.dt*settings.gravity[face.axis];
   }
   for(std::size_t i=0;i<rho.size();++i)rho[i]=1.2+trial.pressure[i]/(343.*343.);
   std::vector<CutPhaseBoundary> boundaries;
   for(auto& v:trial.ventVolume)boundaries.push_back({v.fragment,1,1,v.volume,0.,true});
   if(!rotated){
    CutOwnedFlux field;std::string why;
    if(!ReconstructCutOwnedFlux(chart,geometry,owners,trial.faceVolume,trial.ventVolume,fragmentGas,predictor,mobility,field,why)){std::cout<<"FIELD "<<why<<std::endl;}
    else {
     const std::size_t cell=2844;const auto& r=chart.regions[cell];
     std::cout<<"FILM fragment="<<cell<<" owner="<<owners.owner[cell]<<" members="<<owners.members[owners.owner[cell]].size()<<" bounds="<<r.lo[0]<<","<<r.hi[0]<<";"<<r.lo[1]<<","<<r.hi[1]<<";"<<r.lo[2]<<","<<r.hi[2]<<" water="<<source.water[cell]<<" gas="<<fragmentGas[cell]<<std::endl;
     for(std::size_t f=0;f<geometry.faces.size();++f){auto& face=geometry.faces[f];if(face.left!=cell&&face.right!=cell)continue;
      auto phase=MeasureCutRegionFacePhase(face,geometry.motion,planes[face.left],planes[face.right]);double q=field.faceVolume[f];
      std::cout<<"FILM_FACE index="<<f<<" left="<<face.left<<" right="<<face.right<<" axis="<<face.axis<<" q="<<q<<" donorWet="<<phase.wet[q>=0.?0:1].mean/face.meanArea<<" sameOwner="<<(owners.owner[face.left]==owners.owner[face.right])<<std::endl;
     }
    }
   }
   CutSpatialField field;CutSpatialResult spatial;
   auto startSpatial=std::chrono::steady_clock::now();
   CutOwnedFlux full;bool lifted=ReconstructCutOwnedFlux(chart,geometry,owners,trial.faceVolume,trial.ventVolume,fragmentGas,predictor,mobility,full,error);
   bool built=lifted&&BuildCutSpatialField(chart,geometry,owners,source,full.faceVolume,boundaries,field,error);
   std::cout<<"SPATIAL_BUILD rotated="<<rotated<<" ok="<<built<<" cells="<<field.parent.size()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-startSpatial).count()<<" reason="<<error<<std::endl;
   if(built){auto begin=std::chrono::steady_clock::now();bool ok=AdvanceCutSpatial(field,owners,rho,1.,spatial,error);
   std::cout<<"SPATIAL_TRANSPORT rotated="<<rotated<<" ok="<<ok<<" iterations="<<spatial.iterations<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count()<<" reason="<<error<<std::endl;}
   CutOwnedTransport evaluator=[&](const std::vector<double>& p,const std::vector<double>& q,const std::vector<CutBoundaryTransfer>& vv,std::vector<double>& w,std::vector<double>& m,bool& admissible,std::string& why){
    double pdiff=0.;for(std::size_t i=0;i<p.size();++i)pdiff=std::max(pdiff,std::abs(p[i]-trial.pressure[i]));std::cout<<"PRESSURE_DIFF "<<pdiff<<std::endl;
    std::vector<double> rhoNow(p.size());for(std::size_t o=0;o<p.size();++o)rhoNow[o]=1.2+p[o]/(343.*343.);
    CutOwnedFlux liftedField;
    liftedField.faceVolume=q;
    std::vector<CutPhaseBoundary> bb;for(auto& v:vv)bb.push_back({v.fragment,1,1,v.volume,0.,true});
    CutSpatialField fine;
    if(!BuildCutSpatialField(chart,geometry,owners,source,liftedField.faceVolume,bb,fine,why))return false;
    CutSpatialResult accepted,candidate;
    for(int local=0;local<8;++local){
     admissible=AdvanceCutSpatial(fine,owners,rhoNow,1.,accepted,why,&candidate);
     if(candidate.ownerWater.empty())return false;
     std::vector<double> div(fine.parent.size()),r(div.size()),sums(fine.fragments.members.size()),weight(sums.size()),vf=fine.flux,vm=fine.mobility,sigma(fine.flux.size(),1.);
     for(std::size_t f=0;f<fine.flux.size();++f){auto face=fine.geometry.faces[f];if(fine.fragments.owner[face.left]==fine.fragments.owner[face.right]){
      auto donor=fine.flux[f]>=0.?face.left:face.right;auto owner=owners.owner[fine.parent[donor]];
      sigma[f]=(candidate.water[donor]+candidate.gasMass[donor]/rhoNow[owner])/fine.geometry.startCapacity[donor];vf[f]*=sigma[f];vm[f]*=sigma[f];
     }div[face.left]+=vf[f];div[face.right]-=vf[f];}
     for(auto& v:fine.boundaries)div[v.fragment]+=v.volume;
     double maxR=0.;
     for(std::size_t i=0;i<div.size();++i){auto owner=owners.owner[fine.parent[i]],group=fine.fragments.owner[i];r[i]=candidate.water[i]+candidate.gasMass[i]/rhoNow[owner]-fine.geometry.startCapacity[i];sums[group]+=r[i];weight[group]+=fine.gas[i];maxR=std::max(maxR,std::abs(r[i])/fine.geometry.startCapacity[i]);}
     std::cout<<"LOCAL "<<local<<" residual="<<maxR<<" maxAlpha="<<candidate.maximumFraction<<std::endl;
     if(maxR<1e-9)break;
     for(std::size_t i=0;i<div.size();++i){auto group=fine.fragments.owner[i];double w=weight[group]>0.?fine.gas[i]/weight[group]:fine.geometry.startCapacity[i]/fine.fragments.capacity[group];div[i]+=r[i]-w*sums[group];}
     std::vector<CutBoundaryTransfer> vents;for(auto& v:fine.boundaries)vents.push_back({v.fragment,v.volume});
     CutOwnedFlux liftedFine;
     if(!ReconstructCutOwnedFlux(fine.chart,fine.geometry,fine.fragments,vf,vents,fine.gas,vf,vm,liftedFine,why,1e-10,false,nullptr,&div))return false;
     for(std::size_t f=0;f<vf.size();++f)fine.flux[f]+=(liftedFine.faceVolume[f]-vf[f])/sigma[f];
    }
    if(candidate.ownerWater.empty())return false;
    std::cout<<"ITER rotated="<<rotated<<" maxFraction="<<candidate.maximumFraction<<" linear="<<candidate.iterations<<" admitted="<<admissible<<std::endl;
    w=candidate.ownerWater;m=candidate.ownerGasMass;return true;
   };
   settings.iterationLimit=40;CutOwnedProjection coupled;
   auto coupledStart=std::chrono::steady_clock::now();
   bool coupledOK=ProjectCutOwnedMaterial(chart,geometry,owners,source,settings,{FullCutRegionGasVent(chart,1,1)},coupled,error,nullptr,nullptr,evaluator);
   std::cout<<"COUPLED rotated="<<rotated<<" ok="<<coupledOK<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-coupledStart).count()<<" reason="<<error<<std::endl;


  }
  if(diagnostic.tolerance>0.){
   std::cout<<"ROW rotated="<<rotated<<" iterations="<<diagnostic.iterations<<" owner="<<diagnostic.row<<" normalized="<<diagnostic.normalizedResidual<<std::hexfloat
    <<" storage="<<diagnostic.storage<<" rhs="<<diagnostic.source<<" tolerance="<<diagnostic.tolerance<<" pressure="<<diagnostic.pressure<<" residual="<<diagnostic.residual<<std::defaultfloat<<std::endl;
   for(const auto& neighbor:diagnostic.neighbors)std::cout<<"EDGE rotated="<<rotated<<std::hexfloat<<" g="<<neighbor.conductance<<" p="<<neighbor.pressure<<std::defaultfloat<<std::endl;
  }

 }
 return failed ? 1 : 0;
}
