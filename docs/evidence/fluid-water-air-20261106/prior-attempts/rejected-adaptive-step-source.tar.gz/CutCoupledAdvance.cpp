#include "CutCoupledAdvance.h"
#include <chrono>
#include <functional>
#include <iostream>
namespace judas::volume_grid {
bool AdvanceCutCoupledAdaptive(const CutSpatialField& field,const CutVelocityDual& dual,
 const CutDynamicSettings& settings,const CutCoupledSettings& coupled,const CutCoupledAdvanceSettings& options,
 CutCoupledState& output,CutCoupledAdvanceStats& stats,std::string& error,const CutCoupledState* previous){
 if(previous==&output||options.maximumDepth<0||options.maximumDepth>20||options.maximumAttempts<1||options.trialIterations<1){error="invalid adaptive coupled work budget or alias";return false;}
 auto began=std::chrono::steady_clock::now();CutCoupledAdvanceStats work;
 std::function<bool(double,int,const CutCoupledState*,CutCoupledState&)> advance;
 advance=[&](double dt,int depth,const CutCoupledState* source,CutCoupledState& result){
  if(work.attempts>=options.maximumAttempts){error="adaptive coupled attempt budget exhausted";return false;}
  ++work.attempts;work.maximumDepth=std::max(work.maximumDepth,depth);auto step=settings;step.dt=dt;
  auto controls=coupled;controls.iterationLimit=std::min(coupled.iterationLimit,options.trialIterations);
  CutCoupledState candidate;
  if(AdvanceCutCoupledPressure(field,dual,step,controls,candidate,error,source)){
   ++work.acceptedSubsteps;std::cout<<"SUBSTEP accepted=1 dt="<<dt<<" depth="<<depth<<" iterations="<<candidate.nonlinearIterations<<std::endl;
   result=std::move(candidate);return true;
  }
  std::cout<<"SUBSTEP accepted=0 dt="<<dt<<" depth="<<depth<<" reason="<<error<<std::endl;
  if(depth==options.maximumDepth)return false;
  CutCoupledState first,second;
  if(!advance(dt*.5,depth+1,source,first)||!advance(dt*.5,depth+1,&first,second))return false;
  second.material.externalWater=second.material.externalWater+first.material.externalWater;
  second.material.externalGasMass=second.material.externalGasMass+first.material.externalGasMass;
  result=std::move(second);return true;
 };
 CutCoupledState next;bool ok=advance(settings.dt,0,previous,next);
 work.elapsedMilliseconds=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-began).count();stats=work;
 if(!ok)return false;
 // material.dt intentionally remains the final physical child's dt, not the
 // enclosing frame dt: its stored flux is the child's actual volume transfer.
 next.elapsedMilliseconds=work.elapsedMilliseconds;output=std::move(next);error.clear();return true;
}
}
