#pragma once
#include "CutCoupledPressure.h"
namespace judas::volume_grid {
struct CutCoupledAdvanceStats {int attempts=0,acceptedSubsteps=0,maximumDepth=0;double elapsedMilliseconds=0.;};
struct CutCoupledAdvanceSettings {int maximumDepth=12,maximumAttempts=96,trialIterations=8;};
// Transactional physical integration: each accepted child advances real time
// from the preceding admitted state. A failed parent is discarded, not blended
// into the state. No partial frame, omitted interval or changed tolerance.
bool AdvanceCutCoupledAdaptive(const CutSpatialField&,const CutVelocityDual&,
 const CutDynamicSettings&,const CutCoupledSettings&,const CutCoupledAdvanceSettings&,
 CutCoupledState&,CutCoupledAdvanceStats&,std::string&,const CutCoupledState* previous=nullptr);
}
