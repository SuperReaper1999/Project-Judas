#include "WaterPressureFactor.h"
#include "CutCondensedPressure.h"
#include <cmath>
#include <map>
namespace judas::volume_grid {
bool WaterPressureFactor::Build(const std::vector<double>& storage,
    const std::vector<CutHydroacousticGraphLink>& links,std::string& error){
    auto n=storage.size();WaterPressureFactor next;
    std::vector<CutCompensated> diagonal(storage.begin(),storage.end());
    std::vector<std::map<std::size_t,CutCompensated>> rows(n);
    for(double v:storage)if(!(v>=0.&&std::isfinite(v))){error="invalid liquid accelerator storage";return false;}
    for(auto e:links){
        if(e.left>=n||e.right>=n||e.left==e.right||!(e.conductance>0.&&std::isfinite(e.conductance))){error="invalid liquid accelerator edge";return false;}
        auto i=std::max(e.left,e.right),j=std::min(e.left,e.right);
        rows[i][j]=rows[i][j]-CutCompensated(e.conductance);
        diagonal[i]=diagonal[i]+CutCompensated(e.conductance);diagonal[j]=diagonal[j]+CutCompensated(e.conductance);
    }
    next.scale_.resize(n);next.diagonal_.resize(n);next.lower_.resize(n);
    for(std::size_t i=0;i<n;++i){
        if(!(diagonal[i].Value()>0.&&std::isfinite(diagonal[i].Value()))){error="liquid accelerator component lacks storage or a pressure gauge";return false;}
        next.scale_[i]=std::sqrt(diagonal[i].Value());
    }
    for(std::size_t i=0;i<n;++i){
        CutCompensated pivot(1.);
        for(auto entry:rows[i]){
            auto j=entry.first;CutCompensated v=entry.second/(CutCompensated(next.scale_[i])*CutCompensated(next.scale_[j]));
            const auto& earlier=next.lower_[j];std::size_t a=0,b=0;
            while(a<next.lower_[i].size()&&b<earlier.size()){
                auto left=next.lower_[i][a],right=earlier[b];
                if(left.first==right.first){v=v-CutCompensated(left.second)*CutCompensated(right.second);++a;++b;}
                else if(left.first<right.first)++a;else ++b;
            }
            double value=v.Value()/next.diagonal_[j];next.lower_[i].push_back({j,value});pivot=pivot-CutCompensated(value)*CutCompensated(value);
        }
        if(!(pivot.Value()>0.&&std::isfinite(pivot.Value()))){error="liquid accelerator incomplete factor lost positive definiteness";return false;}
        next.diagonal_[i]=std::sqrt(pivot.Value());
    }
    *this=std::move(next);error.clear();return true;
}
bool WaterPressureFactor::Apply(const std::vector<double>& rhs,std::vector<double>& output,std::string& error)const{
    auto n=scale_.size();if(rhs.size()!=n){error="liquid accelerator RHS size mismatch";return false;}
    std::vector<double> x(n);
    for(std::size_t i=0;i<n;++i){double value=rhs[i]/scale_[i];for(auto e:lower_[i])value-=e.second*x[e.first];x[i]=value/diagonal_[i];}
    for(std::size_t i=n;i-->0;){x[i]/=diagonal_[i];for(auto e:lower_[i])x[e.first]-=e.second*x[i];}
    for(std::size_t i=0;i<n;++i){x[i]/=scale_[i];if(!std::isfinite(x[i])){error="nonfinite liquid accelerator result";return false;}}
    output=std::move(x);error.clear();return true;
}
}
