#pragma once
#include "CutHydroacousticGraph.h"
namespace judas::volume_grid {
// Frozen IC(0) accelerator for a positive graph approximation. Its result is
// only a search direction: unchanged liquid/gas rows decide admission.
class WaterPressureFactor {
public:
    bool Build(const std::vector<double>& storage,
               const std::vector<CutHydroacousticGraphLink>&, std::string&);
    bool Apply(const std::vector<double>& rhs, std::vector<double>&, std::string&) const;
private:
    std::vector<double> scale_, diagonal_;
    std::vector<std::vector<std::pair<std::size_t,double>>> lower_;
};
}
