#include "BasinFixture.h"
#include "WaterGasGeometry.h"
#include "CutOrthogonalField.h"
#include "CutTransparentGrid.h"
#include <chrono>
#include <iomanip>
#include <iostream>
using namespace judas::volume_grid;
using namespace judas::volume_grid::basin_probe;
using Real=CutCompensated;
bool BuildFixture(bool rotated, CutSpatialField& field, std::string& error) {
    const auto fixture = Fixture::Authored(rotated);
    CutRegionChart chart;
    CutRegionGeometry geometry;
    if (!PrepareCutRegionChart(fixture.layout, fixture.Walls(), fixture.InitialBox(),
        {-.005,-.015,-.005}, {.005,.025,.005}, chart, error) ||
        !BuildCutRegionGeometry(chart, {}, geometry, error)) return false;
    CutDynamicState source;
    SeedImport imported;
    if (!WaterByRegion(fixture, chart, geometry, rotated, source.water, imported, error)) return false;
    std::vector<double> gas;
    for (std::size_t i = 0; i < source.water.size(); ++i) {
        gas.push_back(geometry.startCapacity[i] - source.water[i]);
        source.gasMass.push_back(1.2 * gas.back());
    }
    CutConnectedOwners owners;
    if (!BuildCutConnectedOwners(chart, geometry, .125, owners, error)) return false;
    std::vector<CutRegionWaterPlane> planes;
    if (!ReconstructCutRegionPhasePlanes(chart, geometry, 1, source.water, gas, {}, planes, error)) return false;
    auto vent = FullCutRegionGasVent(chart, 1, 1);
    std::vector<CutPhaseBoundary> ports;
    for (std::size_t i = 0; i < chart.regions.size(); ++i)
        if (MeasureCutRegionGasVent(chart.regions[i], geometry.motion, vent, planes[i]).mean > 0.)
            ports.push_back({i,1,1,0.,0.,true});
    return BuildCutSpatialField(chart, geometry, owners, source,
        std::vector<double>(geometry.faces.size()), ports, field, error, false);
}

int main(){
 std::cout<<std::setprecision(17);
 for(bool rotated:{false,true}){
  CutSpatialField original,orthogonal,field;CutOrthogonalRemap remap;CutTransparentGridReport compact;std::string e;
  if(!BuildFixture(rotated,original,e)||!BuildCutOrthogonalField(original,orthogonal,remap,e)||!CoarsenCutTransparentGrid(orthogonal,field,compact,e)){std::cerr<<e;return 2;}
  std::vector<CutRegionWaterPlane> planes;if(!ReconstructCutRegionPhasePlanes(field.chart,field.geometry,1,field.water,field.gas,{},planes,e)){std::cerr<<e;return 2;}
  WaterGasSettings settings;WaterGasGeometry gas;auto started=std::chrono::steady_clock::now();
  if(!PrepareWaterGasGeometry(field,planes,settings,1.8e-5,gas,e)){std::cerr<<e;return 3;}
  std::cout<<"GAS_GEOMETRY rotated="<<rotated<<" nodes="<<gas.nodeCell.size()<<" links="<<gas.links.size()<<" vents="<<gas.vents.size()<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count()<<std::endl;
  auto mass=gas.mass;auto endVolume=gas.volume;for(auto& v:endVolume)v=v*Real(.99);Real external,cold;for(auto m:mass)cold=cold+m;
  for(int step=0;step<3;++step){WaterGasResult result;started=std::chrono::steady_clock::now();bool ok=AdvanceWaterGasPockets(mass,endVolume,gas.links,gas.vents,settings,result,e);
   double maxp=0.;for(auto p:result.pressure)maxp=std::max(maxp,std::abs(p.Value()));
   std::cout<<"GAS_STEP rotated="<<rotated<<" step="<<step+1<<" accepted="<<ok<<" ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-started).count()<<" residual="<<result.maximumNormalizedResidual<<" pressure="<<maxp<<" reason="<<e<<std::endl;
   if(!ok)return 1;
   external=external+result.externalMass;Real total=external;for(auto m:result.mass)total=total+m;
   if(std::abs((total-cold).Value())>settings.massTolerance)return 4;
   mass=std::move(result.mass);
  }
 }
}
