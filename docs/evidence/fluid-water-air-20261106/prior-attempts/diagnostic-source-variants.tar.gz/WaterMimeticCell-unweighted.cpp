#include "WaterMimeticCell.h"
#include "CutCondensedPressure.h"
#include <algorithm>
#include <cmath>
namespace judas::volume_grid {
namespace {
using Real=CutCompensated;
bool Fail(std::string& e,const char* why){e=why;return false;}
}
bool PrepareWaterMimeticCell(double volume,double density,double dt,const GridVec& gravity,
    const std::vector<WaterCellPatch>& faces,WaterCellProjection& output,std::string& error){
    if(!(volume>0.&&std::isfinite(volume)&&density>0.&&std::isfinite(density)&&dt>0.&&std::isfinite(dt))||faces.empty()||faces.size()>32)
        return Fail(error,"invalid liquid mimetic cell");
    std::array<Real,3> closure;std::array<std::array<Real,3>,3> moment;
    std::array<double,3> count{},areaSum{};
    for(auto f:faces){
        if(f.axis<0||f.axis>2||(f.sign!=1&&f.sign!=-1)||!(f.area>0.&&std::isfinite(f.area)))return Fail(error,"invalid liquid boundary patch");
        for(auto x:f.offset)if(!std::isfinite(x))return Fail(error,"nonfinite local liquid geometry");
        count[f.axis]+=1.;areaSum[f.axis]+=f.area;closure[f.axis]=closure[f.axis]+Real(f.sign)*Real(f.area);
        for(int a=0;a<3;++a)moment[f.axis][a]=moment[f.axis][a]+Real(f.sign)*Real(f.area)*Real(f.offset[a]);
    }
    for(int a=0;a<3;++a){
        if(!(count[a]>0.)||std::abs(closure[a].Value())>1e-12*areaSum[a])return Fail(error,"liquid patches do not enclose a volume");
        if(!std::isfinite(gravity[a]))return Fail(error,"nonfinite liquid gravity");
        for(int b=0;b<3;++b)if(std::abs((moment[a][b]-Real(a==b?volume:0.)).Value())>1e-12*volume)return Fail(error,"liquid boundary moments disagree with owned volume");
    }
    const auto n=faces.size();std::vector<double> mass(n*n),projector(n*n),stabilization(n);
    for(std::size_t i=0;i<n;++i){stabilization[i]=density*volume*faces[i].area/(3.*areaSum[faces[i].axis]);
        for(std::size_t j=0;j<n;++j){double dot=0.;for(int a=0;a<3;++a)dot+=faces[i].offset[a]*faces[j].offset[a];
            mass[i*n+j]=density/volume*faces[i].area*faces[j].area*dot;
            projector[i*n+j]=(i==j?1.:0.)-(faces[i].axis==faces[j].axis?double(faces[i].sign*faces[j].sign)/count[faces[i].axis]:0.);
        }
    }
    for(std::size_t i=0;i<n;++i)for(std::size_t j=0;j<n;++j)for(std::size_t k=0;k<n;++k)
        mass[i*n+j]+=projector[i*n+k]*stabilization[k]*projector[j*n+k];
    WaterCellProjection next;
    for(std::size_t i=0;i<n;++i)if(!faces[i].fixed)next.free.push_back(i);
    const auto m=next.free.size();
    if(!m){output=std::move(next);error.clear();return true;}
    std::vector<double> scale(m),factor(m*m);
    for(std::size_t i=0;i<m;++i){scale[i]=std::sqrt(mass[next.free[i]*n+next.free[i]]);if(!(scale[i]>0.&&std::isfinite(scale[i])))return Fail(error,"unrepresentable liquid mass scale");}
    for(std::size_t i=0;i<m;++i)for(std::size_t j=0;j<=i;++j){
        double v=mass[next.free[i]*n+next.free[j]]/(scale[i]*scale[j]);
        for(std::size_t k=0;k<j;++k)v-=factor[i*m+k]*factor[j*m+k];
        if(i==j){if(!(v>0.&&std::isfinite(v)))return Fail(error,"liquid mimetic mass is not positive definite");factor[i*m+j]=std::sqrt(v);}
        else factor[i*m+j]=v/factor[j*m+j];
    }
    next.inverseMass.assign(m*m,0.);
    for(std::size_t column=0;column<m;++column){std::vector<double> x(m);
        for(std::size_t i=0;i<m;++i){double v=i==column?1./scale[column]:0.;for(std::size_t j=0;j<i;++j)v-=factor[i*m+j]*x[j];x[i]=v/factor[i*m+i];}
        for(std::size_t i=m;i-->0;){double v=x[i];for(std::size_t j=i+1;j<m;++j)v-=factor[j*m+i]*x[j];x[i]=v/factor[i*m+i];}
        for(std::size_t i=0;i<m;++i)next.inverseMass[i*m+column]=x[i]/scale[i];
    }
    std::vector<double> raw(m*m),weights(m);double sum=0.;
    for(std::size_t i=0;i<m;++i)for(std::size_t j=0;j<m;++j){
        auto a=faces[next.free[i]],b=faces[next.free[j]];raw[i*m+j]=a.area*next.inverseMass[i*m+j]*b.area;
        weights[i]+=raw[i*m+j];
    }
    for(std::size_t i=0;i<m;++i)sum+=weights[i];
    if(!(sum>0.&&std::isfinite(sum)))return Fail(error,"liquid pressure has no geometric owner");
    next.mobility.resize(m*m);next.predictor.assign(m,0.);next.gravityHead.resize(m);next.pressureWeights=weights;next.pressureDenominator=sum;
    for(std::size_t i=0;i<m;++i){for(int a=0;a<3;++a)next.gravityHead[i]+=density*gravity[a]*faces[next.free[i]].offset[a];
        for(std::size_t j=0;j<m;++j)next.mobility[i*m+j]=raw[i*m+j]-weights[i]*weights[j]/sum;}
    output=std::move(next);error.clear();return true;
}
}
