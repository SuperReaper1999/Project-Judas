#include "RegionalCochains.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace regional_cochains;
unsigned checks=0;
void Check(bool ok,const char* why){++checks;if(!ok)throw std::runtime_error(why);}
template<class F> void Reject(F f,const char* expected){bool rejected=false;try{f();}catch(const std::invalid_argument& e){rejected=std::string(e.what()).find(expected)!=std::string::npos;}Check(rejected,expected);}
void GeometryUnchanged(const voxel_ports::Compiler& source,const Compiler& region){
 Check(source.cells.size()==region.cells.size(),"regional elimination changed physical cell count");
 for(unsigned c=0;c<source.cells.size();++c){const auto& a=source.cells[c];const auto& b=region.cells[c];Check(a.volume==b.volume&&a.center==b.center&&a.integration.size()==b.integration.size(),"physical measure changed");Check(region.originalPhysicalOwners[c]==std::make_pair(a.seed,a.piece),"physical ownership lost");Check(a.faces.size()==b.faces.size(),"physical port removed");for(unsigned f=0;f<a.faces.size();++f){const auto& x=a.faces[f];const auto& y=b.faces[f];Check(x.solid==y.solid&&x.triangles.size()==y.triangles.size(),"solid boundary changed");for(unsigned t=0;t<x.triangles.size();++t)Check(x.triangles[t].points==y.triangles[t].points&&x.triangles[t].areaVector==y.triangles[t].areaVector,"physical aperture changed");}}
}
int main(){try{
 using V=glm::dvec3;
 const auto box=owned_cut::BoxPlanes(V(1),V(.4),glm::dquat(1,0,0,0));
 voxel_ports::Compiler g;g.Build(2,box);Compiler regional;regional.Build(g);Check(regional.regions==1,"connected cavity split into artificial regions");GeometryUnchanged(g,regional);
 Network original(g,vg::R(1)/2),condensed(regional,vg::R(1)/2);
 stage17_conservative_network::Epoch local{stage17_condensed::LocalCondensedNetwork(original)},whole{stage17_condensed::LocalCondensedNetwork(condensed)};
 auto source=local.Constant(vm::Vec3::Zero());
 for(unsigned c=0;c<local.cells.size();++c){vm::Vec3 center;for(unsigned a=0;a<3;++a)center[a]=local.cells[c]->cell.center[a].convert_to<Real>()-.5L;const vm::Vec3 omega(.12,.09,-.17);source[c]=vm::RigidAffine(omega.cross(center),omega);}
 const auto a=local.Solve(source),b=whole.Solve(source);Real fieldError=0;for(unsigned c=0;c<a.local.size();++c)fieldError=std::max(fieldError,(a.local[c]-b.local[c]).cwiseAbs().maxCoeff());Check(a.energy>1e-5L,"equivalence positive control must contain genuine flow");Check(fieldError<1e-10L,"regional parameterization changed solved physical field");Check(std::abs(a.energy-b.energy)<1e-10L,"regional parameterization changed physical energy");
 unsigned ownerCell=~0u,ownerFace=~0u;
 std::map<PortKey,std::vector<std::pair<unsigned,unsigned>>> owners;for(unsigned c=0;c<g.cells.size();++c)for(unsigned f=0;f<g.cells[c].faces.size();++f)if(g.cells[c].faces[f].kind!=Kind::Solid)owners[g.cells[c].faces[f].key].emplace_back(c,f);
 for(const auto& entry:owners)if(entry.second.size()==2){ownerCell=entry.second[0].first;ownerFace=entry.second[0].second;break;}
 Check(ownerCell!=~0u,"negative controls require an actual shared aperture");
 auto missing=g;missing.cells[ownerCell].faces.erase(missing.cells[ownerCell].faces.begin()+ownerFace);Reject([&]{Compiler bad;bad.Build(missing);},"lacks its physical opposite owner");
 auto third=g;third.cells.push_back(g.cells[ownerCell]);Reject([&]{Compiler bad;bad.Build(third);},"more than two owners");
 Reject([&]{regional.Build(g);},"cannot be reused");
 // A solid slab fully separates the two fluid cavities. No fictitious global
 // connection may appear simply because both cavities share a pressure solve.
 const auto slab=owned_cut::BoxPlanes(V(1),V(3,.2,3),glm::dquat(1,0,0,0));voxel_ports::Compiler split;split.Build(2,slab);Compiler two;two.Build(split);Check(two.regions==2,"impermeable slab must retain two disconnected regions");GeometryUnchanged(split,two);
 Network isolated(two,vg::R(1)/2);stage17_conservative_network::Epoch separated{stage17_condensed::LocalCondensedNetwork(isolated)};auto input=separated.Constant(vm::Vec3::Zero());for(unsigned c=0;c<separated.cells.size();++c)if(two.cells[c].seed==0)input[c]=vm::RigidAffine(vm::Vec3(.3,0,.1),vm::Vec3(0,.2,0));const auto result=separated.Solve(input);Real quiet=0,active=0;for(unsigned c=0;c<result.local.size();++c){if(two.cells[c].seed==1)quiet=std::max(quiet,result.local[c].cwiseAbs().maxCoeff());else active=std::max(active,result.local[c].cwiseAbs().maxCoeff());}Check(active>1e-5L,"disconnected positive control must retain nonzero motion");Check(quiet==0,"pressure solve teleported motion through a solid slab");
 printf("REGIONAL_CONTRACTS checks=%u failures=0 field_error=%Lg energy_error=%Lg disconnected_quiet=%Lg active=%Lg\n",checks,fieldError,std::abs(a.energy-b.energy),quiet,active);return 0;
 }catch(const std::exception& e){fprintf(stderr,"FAIL after%uchecks %s\n",checks,e.what());return 1;}}
