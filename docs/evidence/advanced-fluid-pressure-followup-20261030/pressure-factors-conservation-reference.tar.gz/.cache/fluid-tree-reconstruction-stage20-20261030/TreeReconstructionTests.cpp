#include "RegionalCochains.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>
using namespace regional_cochains;
unsigned checks=0;
void Check(bool ok,const char* why){++checks;if(!ok)throw std::runtime_error(why);}
int main(){try{
 const auto box=owned_cut::BoxPlanes(glm::dvec3(1),glm::dvec3(.4),glm::dquat(1,0,0,0));regional_cochains::Epoch world(2,box,vg::R(1)/2);
 for(const auto& coordinates:world.conservative){Vector free(coordinates.freeVariables),boundary(coordinates.externalVariables);
 for(unsigned trial=0;trial<32;++trial){for(unsigned i=0;i<free.size();++i)free[i]=Real(int((i*13+trial*7)%61)-30)/256;for(unsigned i=0;i<boundary.size();++i)boundary[i]=Real(int((i*17+trial*11)%43)-21)/128;const auto a=coordinates.EvaluateExactDense(free,boundary),b=coordinates.EvaluateExact(free,boundary);Check(a.internal==b.internal,"linear tree recurrence changed exact primary coordinates");Check(a.faceMeans==b.faceMeans&&a.cellSums==b.cellSums,"linear tree recurrence changed physical aperture flow");Check(a.rootSum==b.rootSum&&a.externalSum==b.externalSum,"linear tree recurrence changed cavity closure");}
 Real sink=0;const unsigned repeats=100;auto start=Clock::now();for(unsigned i=0;i<repeats;++i)sink+=coordinates.EvaluateExactDense(free,boundary).internal.front().convert_to<Real>();const double dense=Milliseconds(start);start=Clock::now();for(unsigned i=0;i<repeats;++i)sink+=coordinates.EvaluateExact(free,boundary).internal.front().convert_to<Real>();const double tree=Milliseconds(start);Check(std::isfinite(sink),"benchmark must consume actual finite reconstructed results");printf("TREE_RECONSTRUCTION checks=%u failures=0 cells=%zu free=%u repetitions=%u dense_ms=%g tree_ms=%g ratio=%g\n",checks,coordinates.cells.size(),coordinates.freeVariables,repeats,dense,tree,dense/tree);
 }
 return 0;}catch(const std::exception& e){fprintf(stderr,"FAIL after%uchecks %s\n",checks,e.what());return 1;}}
