from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path(__file__).resolve().parent
rows=[]
for name in ('RegionalContractsTests','RegionalMomentumTests'):
 src=root/(name+'.cpp');exe=root/(name+'.exe');start=time.time()
 command=['g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc','-I'+os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'),'-I'+os.environ.get('EIGEN_INCLUDE_DIR','/tmp/judas-fluid-reference-eigen/extracted/usr/include/eigen3'),str(src),'-o',str(exe)]
 with (root/(name+'-compile.log')).open('w') as log: code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 row={'name':name,'compileCommand':command,'compileReturncode':code,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest()}
 if code==0:
  with (root/(name+'.log')).open('w') as log: row['returncode']=subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT).returncode
  row['binarySha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
 row['elapsedSeconds']=time.time()-start;rows.append(row)
 (root/'qualification.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code or row.get('returncode'):raise SystemExit(1)
