#pragma once
#include <Eigen/Eigenvalues>
#include <Eigen/QR>
#include <fstream>
#include <iomanip>
#include <cstdio>

// PRIVATE Stage17 coordinate prototype. Mean-flux constraints are eliminated
// BEFORE kinetic minimization. Derived tree fluxes are exact expressions in
// primary free/boundary coordinates; the exact state, not a rounded face slot,
// is authoritative for transport and continuity.
#include "LocalCondensedNetwork.h"
#include <queue>

namespace stage17_conservative {
using namespace stage17_network;
using Exact=vg::R;
using ExactRow=std::vector<Exact>;
using ExactMatrix=std::vector<ExactRow>;

inline ExactMatrix Zeros(unsigned rows,unsigned columns) {
    return ExactMatrix(rows,ExactRow(columns,Exact(0)));
}
inline Matrix Rounded(const ExactMatrix& input,unsigned columns) {
    Matrix out(input.size(),columns);
    for(unsigned row=0;row<input.size();++row)
        for(unsigned column=0;column<columns;++column)
            out(row,column)=input[row][column].convert_to<Real>();
    return out;
}
inline ExactRow ExactValues(const Vector& values) {
    ExactRow result(values.size());
    for(unsigned i=0;i<result.size();++i) {
        if(!std::isfinite(values[i])) throw std::invalid_argument("nonfinite primary conservative coordinate");
        result[i]=Exact(values[i]);
    }
    return result;
}
inline Exact Dot(const ExactRow& a,const ExactRow& b) {
    if(a.size()!=b.size()) throw std::invalid_argument("exact conservative dot size mismatch");
    Exact result=0;
    for(unsigned i=0;i<a.size();++i) result+=a[i]*b[i];
    return result;
}
inline std::array<Exact,6> RigidMeanFlux(const PhysicalFace& face,const vg::RV& center) {
    std::array<Exact,6> result{};
    for(const auto& triangle:face.triangles) {
        vg::RV point{};
        for(unsigned axis=0;axis<3;++axis) {
            for(unsigned vertex=0;vertex<3;++vertex) point[axis]+=triangle.points[vertex][axis]/3;
            point[axis]+=center[axis];
        }
        const auto angular=owned_metrics::Cross(point,triangle.areaVector);
        for(unsigned axis=0;axis<3;++axis) {
            result[axis]+=triangle.areaVector[axis];
            result[axis+3]+=angular[axis];
        }
    }
    return result;
}

struct ExactState {
    ExactRow internal;
    std::vector<ExactRow> faceMeans;
    ExactRow cellSums;
    Exact rootSum=0,externalSum=0;
};
struct PieceBinding {
    unsigned cell=0;
    std::shared_ptr<const Local> physical;
    Matrix originalInternal,freeFaces,boundaryFaces;
    std::vector<ExactRow> faceExternalMeans;
};
struct Source {
    std::vector<vm::CondensedSource> pieces;
    Vector freeLoad,boundaryLoad,freeOffset,reducedLoad,rootTail;
    std::vector<Vector> angularOffsets,pieceRootLoads,rootPredictors;
    Real predictorEnergy=0,constant=0;
};
struct State {
    Vector free;
    std::vector<Vector> faces,roundedKineticLocal;
    ExactState conservative;
    Real objective=0,reducedObjective=0,energy=0;
    Vector boundaryGradient;
};
struct Coordinates {
    unsigned seed=0,root=0,freeVariables=0,externalVariables=0,internalVariables=0;
    std::vector<unsigned> cells,parent,parentEdge,order;
    std::vector<int> parentSign;
    std::vector<bool> tree;
    std::vector<PortKey> internalKeys,boundaryKeys;
    std::vector<std::pair<unsigned,unsigned>> endpoints;
    ExactMatrix internalFromFree,internalFromExternal,externalMeans;
    ExactRow macroClosure;
    std::vector<PieceBinding> pieces;
    Matrix freeMass,freeBoundary,boundaryMass,reducedMass,freeFromBoundary;
    Vector freeScale;
    Matrix rootA,rootB,tailB,rootR;
    std::vector<Matrix> pieceRoots,rawRoots,angularRs,angularMaps;
    std::vector<Vector> angularScales;
    std::vector<std::shared_ptr<Eigen::HouseholderQR<Matrix>>> angularQrs;
    Eigen::HouseholderQR<Matrix> rootQr;
    Eigen::LLT<Matrix> freeFactor;
    Real maximumBodyMeanCoefficientChange=0;

    explicit Coordinates(const stage17_condensed::LocalCondensedNetwork& network,unsigned domainIndex) {
        if(domainIndex>=network.subdomains.size()) throw std::invalid_argument("conservative domain index is invalid");
        const auto& domain=network.subdomains[domainIndex];
        seed=domain.seed;cells=domain.cells;internalKeys=domain.internalKeys;boundaryKeys=domain.boundaryKeys;
        internalVariables=3*internalKeys.size();externalVariables=3*boundaryKeys.size()+6;
        if(cells.empty()) throw std::runtime_error("conservative internal domain is empty");
        std::map<unsigned,unsigned> localCell;
        for(unsigned i=0;i<cells.size();++i) localCell.emplace(cells[i],i);
        std::map<PortKey,unsigned> externalPort;
        for(unsigned i=0;i<boundaryKeys.size();++i) externalPort.emplace(boundaryKeys[i],i);
        root=0;
        for(unsigned i=1;i<cells.size();++i) {
            const auto& a=network.cells[cells[i]]->cell;
            const auto& b=network.cells[cells[root]]->cell;
            if(a.exactVolume>b.exactVolume || (a.exactVolume==b.exactVolume&&a.piece<b.piece)) root=i;
        }
        struct Adjacency {unsigned edge,other;};
        std::vector<std::vector<Adjacency>> graph(cells.size());
        for(unsigned edge=0;edge<internalKeys.size();++edge) {
            const auto& port=network.allPorts.at(internalKeys[edge]);
            const unsigned a=localCell.at(port.firstCell),b=localCell.at(port.secondCell);
            endpoints.emplace_back(a,b);
            graph[a].push_back({edge,b});graph[b].push_back({edge,a});
        }
        // SAME exact admissible space; choose its tree by actual aperture
        // area rather than arbitrary key order. Never discard a small port.
        std::vector<Exact> weights(internalKeys.size());
        std::vector<unsigned> sortedEdges(internalKeys.size()),dsu(cells.size());
        std::iota(sortedEdges.begin(),sortedEdges.end(),0);std::iota(dsu.begin(),dsu.end(),0);
        for(unsigned e=0;e<internalKeys.size();++e){const auto& port=network.allPorts.at(internalKeys[e]);vg::RV area{};for(const auto& triangle:network.cells[port.firstCell]->cell.faces[port.firstFace].triangles)for(unsigned a=0;a<3;++a)area[a]+=triangle.areaVector[a];weights[e]=owned_metrics::Dot(area,area);}
        std::sort(sortedEdges.begin(),sortedEdges.end(),[&](unsigned a,unsigned b){return weights[a]!=weights[b]?weights[a]>weights[b]:a<b;});
        const auto find=[&](unsigned x){while(dsu[x]!=x)x=dsu[x];return x;};
        std::vector<bool> selectedTree(internalKeys.size(),false);
        for(unsigned e:sortedEdges){const unsigned a=find(endpoints[e].first),b=find(endpoints[e].second);if(a!=b){dsu[b]=a;selectedTree[e]=true;}}
        parent.assign(cells.size(),~0u);parentEdge.assign(cells.size(),~0u);parentSign.assign(cells.size(),0);
        tree.assign(internalKeys.size(),false);std::queue<unsigned> pending;
        parent[root]=root;pending.push(root);
        while(!pending.empty()) {
            const unsigned cell=pending.front();pending.pop();order.push_back(cell);
            // Edges were inserted in sorted PortKey order: deterministic BFS.
            for(const auto& adjacent:graph[cell]) if(selectedTree[adjacent.edge] && parent[adjacent.other]==~0u) {
                parent[adjacent.other]=cell;parentEdge[adjacent.other]=adjacent.edge;
                parentSign[adjacent.other]=endpoints[adjacent.edge].first==adjacent.other?1:-1;
                tree[adjacent.edge]=true;pending.push(adjacent.other);
            }
        }
        if(order.size()!=cells.size()) throw std::runtime_error("conservative domain internal graph is disconnected");
        for(unsigned edge=0;edge<internalKeys.size();++edge) freeVariables+=tree[edge]?2:3;
        internalFromFree=Zeros(internalVariables,freeVariables);
        internalFromExternal=Zeros(internalVariables,externalVariables);
        unsigned next=0;
        for(unsigned edge=0;edge<internalKeys.size();++edge)
            for(unsigned component=0;component<3;++component)
                if(component||!tree[edge]) internalFromFree[3*edge+component][next++]=1;
        externalMeans=Zeros(cells.size(),externalVariables);
        for(unsigned piece=0;piece<cells.size();++piece) {
            PieceBinding binding;binding.cell=cells[piece];binding.physical=network.cells[cells[piece]];
            binding.originalInternal=domain.maps[piece].internal;
            binding.boundaryFaces=domain.maps[piece].boundary;
            const auto& physical=*binding.physical;
            binding.faceExternalMeans=Zeros(physical.cell.faces.size(),externalVariables);
            for(unsigned face=0;face<physical.cell.faces.size();++face) {
                const auto& patch=physical.cell.faces[face];auto& mean=binding.faceExternalMeans[face];
                if(patch.kind==Kind::Solid) {
                    const auto exact=RigidMeanFlux(patch,physical.cell.center);
                    for(unsigned degree=0;degree<6;++degree) {
                        mean[externalVariables-6+degree]=exact[degree];
                        const Real rounded=exact[degree].convert_to<Real>();
                        maximumBodyMeanCoefficientChange=std::max(maximumBodyMeanCoefficientChange,
                            std::abs(rounded-binding.boundaryFaces(3*face,externalVariables-6+degree)));
                        binding.boundaryFaces(3*face,externalVariables-6+degree)=rounded;
                    }
                } else if(patch.kind==Kind::Background) {
                    auto port=externalPort.find(patch.key);
                    if(port!=externalPort.end()) mean[3*port->second]=1;
                }
                for(unsigned coefficient=0;coefficient<externalVariables;++coefficient)
                    externalMeans[piece][coefficient]+=mean[coefficient];
            }
            pieces.push_back(std::move(binding));
        }
        for(unsigned reverse=order.size();reverse>0;--reverse) {
            const unsigned cell=order[reverse-1];if(cell==root) continue;
            const unsigned edge=parentEdge[cell];const int sign=parentSign[cell];
            ExactRow free(freeVariables,0),external=externalMeans[cell];
            for(const auto& adjacent:graph[cell]) if(adjacent.edge!=edge) {
                const int outward=endpoints[adjacent.edge].first==cell?1:-1;
                for(unsigned c=0;c<freeVariables;++c) free[c]+=outward*internalFromFree[3*adjacent.edge][c];
                for(unsigned c=0;c<externalVariables;++c) external[c]+=outward*internalFromExternal[3*adjacent.edge][c];
            }
            for(unsigned c=0;c<freeVariables;++c) internalFromFree[3*edge][c]=-sign*free[c];
            for(unsigned c=0;c<externalVariables;++c) internalFromExternal[3*edge][c]=-sign*external[c];
        }
        macroClosure.assign(externalVariables,0);
        for(const auto& row:externalMeans)
            for(unsigned c=0;c<externalVariables;++c) macroClosure[c]+=row[c];
        CheckExactClosure();
        BuildKinetic();
    }

    void CheckExactClosure() const {
        for(unsigned piece=0;piece<cells.size();++piece) {
            ExactRow free(freeVariables,0),external=externalMeans[piece];
            for(unsigned edge=0;edge<endpoints.size();++edge) {
                int sign=0;if(endpoints[edge].first==piece) sign=1;
                if(endpoints[edge].second==piece) sign=-1;
                if(!sign) continue;
                for(unsigned c=0;c<freeVariables;++c) free[c]+=sign*internalFromFree[3*edge][c];
                for(unsigned c=0;c<externalVariables;++c) external[c]+=sign*internalFromExternal[3*edge][c];
            }
            for(const auto& coefficient:free) if(coefficient!=0)
                throw std::runtime_error("conservative free coordinates violate exact cell closure");
            for(unsigned c=0;c<externalVariables;++c)
                if(external[c]!=(piece==root?macroClosure[c]:Exact(0)))
                    throw std::runtime_error("conservative boundary coordinates violate exact cell closure");
        }
    }

    Matrix InverseColumns(const Matrix& input) const {
        if(!freeVariables) return Matrix::Zero(0,input.cols());
        const Matrix scaled=freeScale.asDiagonal()*input;
        const Matrix intermediate=rootR.transpose().template triangularView<Eigen::Lower>().solve(scaled);
        const Matrix result=freeScale.asDiagonal()*rootR.template triangularView<Eigen::Upper>().solve(intermediate);
        if(!result.allFinite()) throw std::runtime_error("rooted free inverse is nonfinite");
        return result;
    }
    Vector Inverse(const Vector& input) const {
        if(!freeVariables) return Vector(0);
        return InverseColumns(input).col(0);
    }
    static void TraceMetric(const std::string& name,const Matrix& input) {
        Matrix scaled=input;Real lo=INFINITY,hi=0;
        for(int i=0;i<input.rows();++i){lo=std::min(lo,input(i,i));hi=std::max(hi,input(i,i));}
        if(lo>0){Vector d=input.diagonal().array().sqrt().inverse();scaled=d.asDiagonal()*input*d.asDiagonal();}
        Eigen::SelfAdjointEigenSolver<Matrix> spectrum((scaled+scaled.transpose()).eval()/2);
        printf("KINETIC_STAGE name=%s n=%ld diagonal_min=%Lg max=%Lg scaled_min_eigen=%Lg scaled_max_eigen=%Lg asymmetry=%Lg\n",name.c_str(),long(input.rows()),lo,hi,spectrum.eigenvalues()[0],spectrum.eigenvalues().tail(1)[0],(scaled-scaled.transpose()).norm());
        std::ofstream out(".cache/fluid-kinetic-root-stage18-20261030/diagnostics/"+name+".txt");
        out<<std::setprecision(std::numeric_limits<Real>::max_digits10)<<input.rows()<<"\n"<<input<<"\n";
    }
    static Matrix PositiveRoot(const Matrix& mass) {
        Vector d(mass.rows());for(int i=0;i<mass.rows();++i){if(!(mass(i,i)>0))throw std::runtime_error("defining kinetic factor has nonpositive diagonal");d[i]=1/std::sqrt(mass(i,i));}
        Eigen::LLT<Matrix> factor(d.asDiagonal()*mass*d.asDiagonal());
        if(factor.info()!=Eigen::Success)throw std::runtime_error("defining polynomial/stabilization metric is not representable");
        return Matrix(factor.matrixL()).transpose()*d.cwiseInverse().asDiagonal();
    }
    void BuildKinetic() {
        const Matrix ti=Rounded(internalFromFree,freeVariables),tz=Rounded(internalFromExternal,externalVariables);
        unsigned rows=0;for(const auto& piece:pieces)rows+=piece.physical->op.dimension+12-3;
        rootA=Matrix::Zero(rows,freeVariables);rootB=Matrix::Zero(rows,externalVariables);unsigned offset=0;
        for(auto& piece:pieces){
            piece.freeFaces=piece.originalInternal*ti;piece.boundaryFaces+=piece.originalInternal*tz;
            const auto& op=piece.physical->op;
            Matrix rawRoot(op.dimension+12,op.dimension);
            rawRoot.topRows(12)=std::sqrt(op.geometry.density)*PositiveRoot(op.polynomialGram)*op.projection;
            rawRoot.bottomRows(op.dimension)=PositiveRoot(op.stabilization)*(Matrix::Identity(op.dimension,op.dimension)-op.polynomialDofs*op.projection);
            const auto& condensed=piece.physical->condensed;
            const Matrix a=rawRoot*condensed.Tangular,b=rawRoot*condensed.Tface;
            Vector angularScale(3);for(unsigned k=0;k<3;++k)angularScale[k]=1/a.col(k).norm();
            auto qr=std::make_shared<Eigen::HouseholderQR<Matrix>>(a*angularScale.asDiagonal());
            const Matrix r=qr->matrixQR().topRows(3).template triangularView<Eigen::Upper>();
            const Matrix qb=qr->householderQ().adjoint()*b;
            const Matrix root=qb.bottomRows(rawRoot.rows()-3);
            angularMaps.push_back(-(angularScale.asDiagonal()*r.template triangularView<Eigen::Upper>().solve(qb.topRows(3))));
            rawRoots.push_back(rawRoot);angularRs.push_back(r);angularScales.push_back(angularScale);angularQrs.push_back(qr);
            pieceRoots.push_back(root);rootA.middleRows(offset,root.rows())=root*piece.freeFaces;rootB.middleRows(offset,root.rows())=root*piece.boundaryFaces;offset+=root.rows();
        }
        freeScale.resize(freeVariables);for(unsigned c=0;c<freeVariables;++c){const Real norm=rootA.col(c).norm();if(!(norm>0))throw std::runtime_error("rooted free coordinate vanished");freeScale[c]=1/norm;}
        if(freeVariables){rootQr.compute(rootA*freeScale.asDiagonal());rootR=rootQr.matrixQR().topRows(freeVariables).template triangularView<Eigen::Upper>();const Matrix transformed=rootQr.householderQ().adjoint()*rootB;tailB=transformed.bottomRows(rows-freeVariables);freeFromBoundary=-(freeScale.asDiagonal()*rootR.template triangularView<Eigen::Upper>().solve(transformed.topRows(freeVariables)));printf("ROOTED_FREE rows=%u columns=%u min_R=%Lg max_R=%Lg\n",rows,freeVariables,rootR.diagonal().cwiseAbs().minCoeff(),rootR.diagonal().cwiseAbs().maxCoeff());}
        else{tailB=rootB;freeFromBoundary=Matrix::Zero(0,externalVariables);}
        reducedMass=tailB.transpose()*tailB;
    }
    Source Prepare(const std::vector<Vector>& predictors) const {
        Source source;source.freeLoad=Vector::Zero(freeVariables);
        source.boundaryLoad=Vector::Zero(externalVariables);
        Real constant=0;
        for(const auto& piece:pieces) {
            if(piece.cell>=predictors.size()) throw std::invalid_argument("conservative predictor count is invalid");
            auto local=piece.physical->condensed.SourceFromPredictor(predictors[piece.cell]);
            source.freeLoad+=piece.freeFaces.transpose()*local.faceLoad;
            source.boundaryLoad+=piece.boundaryFaces.transpose()*local.faceLoad;
            source.predictorEnergy+=local.predictorEnergyConstant;constant+=local.constant;
            source.pieces.push_back(std::move(local));
        }
        Vector b(rootA.rows());unsigned offset=0;constant=0;source.predictorEnergy=0;
        for(unsigned i=0;i<pieces.size();++i){const auto& root=pieceRoots[i];const Vector rawPrediction=rawRoots[i]*predictors[pieces[i].cell];source.rootPredictors.push_back(rawPrediction);source.predictorEnergy+=rawPrediction.squaredNorm()/2;const Vector transformed=angularQrs[i]->householderQ().adjoint()*rawPrediction;const Vector tail=transformed.tail(root.rows());b.segment(offset,root.rows())=tail;offset+=root.rows();constant+=tail.squaredNorm()/2;source.pieceRootLoads.push_back(tail);source.angularOffsets.push_back(angularScales[i].asDiagonal()*angularRs[i].template triangularView<Eigen::Upper>().solve(transformed.head(3)));}
        if(freeVariables){const Vector transformed=rootQr.householderQ().adjoint()*b;source.freeOffset=freeScale.asDiagonal()*rootR.template triangularView<Eigen::Upper>().solve(transformed.head(freeVariables));source.rootTail=transformed.tail(b.size()-freeVariables);source.constant=constant-transformed.head(freeVariables).squaredNorm()/2;}
        else{source.freeOffset=Vector(0);source.rootTail=b;source.constant=constant;}
        source.reducedLoad=tailB.transpose()*source.rootTail;
        return source;
    }

    ExactState EvaluateExact(const Vector& free,const Vector& boundary) const {
        if(free.size()!=freeVariables||boundary.size()!=externalVariables)
            throw std::invalid_argument("conservative primary coordinate dimension mismatch");
        const auto f=ExactValues(free),z=ExactValues(boundary);
        ExactState result;result.internal.resize(internalVariables);
        for(unsigned row=0;row<internalVariables;++row)
            result.internal[row]=Dot(internalFromFree[row],f)+Dot(internalFromExternal[row],z);
        result.faceMeans.resize(pieces.size());result.cellSums.assign(pieces.size(),0);
        std::map<PortKey,unsigned> edges;
        for(unsigned edge=0;edge<internalKeys.size();++edge) edges.emplace(internalKeys[edge],edge);
        for(unsigned piece=0;piece<pieces.size();++piece) {
            const auto& binding=pieces[piece];result.faceMeans[piece].resize(binding.physical->cell.faces.size());
            for(unsigned face=0;face<binding.physical->cell.faces.size();++face) {
                const auto& patch=binding.physical->cell.faces[face];Exact mean=0;
                if(patch.kind==Kind::Internal) {
                    const unsigned edge=edges.at(patch.key);
                    const int sign=endpoints[edge].first==piece?1:-1;
                    mean=sign*result.internal[3*edge];
                } else mean=Dot(binding.faceExternalMeans[face],z);
                result.faceMeans[piece][face]=mean;result.cellSums[piece]+=mean;
            }
        }
        result.rootSum=result.cellSums[root];result.externalSum=Dot(macroClosure,z);
        for(unsigned piece=0;piece<pieces.size();++piece)
            if(result.cellSums[piece]!=(piece==root?result.externalSum:Exact(0)))
                throw std::runtime_error("exact primary conservative state violates its graph identity");
        return result;
    }
    State Reconstruct(const Source& source,const Vector& boundary) const {
        if(boundary.size()!=externalVariables||!boundary.allFinite())
            throw std::invalid_argument("conservative boundary state is invalid");
        State state;state.free=source.freeOffset+freeFromBoundary*boundary;
        state.conservative=EvaluateExact(state.free,boundary);
        state.boundaryGradient=tailB.transpose()*(tailB*boundary-source.rootTail);
        for(unsigned piece=0;piece<pieces.size();++piece) {
            const auto& binding=pieces[piece];
            // Rounded kinetic evaluation is NOT authoritative primary mean
            // flux storage and must never be used for transport/continuity.
            Vector faces=binding.freeFaces*state.free+binding.boundaryFaces*boundary;
            const auto& reduced=binding.physical->condensed;
            Vector raw=reduced.Tface*faces+reduced.Tangular*(source.angularOffsets[piece]+angularMaps[piece]*faces);
            const Vector kinetic=rawRoots[piece]*raw;state.energy+=kinetic.squaredNorm()/2;
            state.objective+=(kinetic-source.rootPredictors[piece]).squaredNorm()/2;
            state.faces.push_back(std::move(faces));state.roundedKineticLocal.push_back(std::move(raw));
        }
        state.reducedObjective=boundary.dot(reducedMass*boundary)/2-source.reducedLoad.dot(boundary)+source.constant;
        return state;
    }
};
} // namespace stage17_conservative
