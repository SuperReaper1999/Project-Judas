"""Private numerical runner; from repository root, one compile/run at a time."""
from pathlib import Path
import subprocess,sys,os,runpy
root=Path(__file__).resolve().parent
src=root/sys.argv[1]
if src.parent!=root or src.suffix!='.cpp':raise SystemExit('choose one local C++ source')
exe=root/(src.stem+'.reproduced')
incs=['-I'+os.environ.get('BOOST_INCLUDE_DIR','/tmp/judas-fluid-reference-boost/extracted/usr/include'),'-I'+os.environ.get('EIGEN_INCLUDE_DIR','/tmp/judas-fluid-reference-eigen/extracted/usr/include/eigen3')]
if 'NativePressureTests' in src.name:
 helpers=runpy.run_path('.cache/fluid-contact-repair/setup_probes.py')
 obj=root/(src.stem+'.reproduced.o')
 subprocess.run(['/usr/bin/c++',*helpers['compile_flags'],*incs,'-c',str(src),'-o',str(obj)],check=True)
 override=Path('.cache/fluid-contact-repair/stage5-exact-volume-domain.o').resolve()
 if not override.exists():raise SystemExit('rebuild archived Stage5 VolumeDomain.cpp override with setup_probes.compile first')
 helpers['executable'](obj,src.stem+'.reproduced',override)
 exe=Path('.cache/fluid-contact-repair')/(src.stem+'.reproduced')
else:subprocess.run(['/usr/bin/g++','-std=c++17','-O3','-g0','-DNDEBUG','-Isrc',*incs,str(src),'-o',str(exe)],check=True)
raise SystemExit(subprocess.run([str(exe),*sys.argv[2:]]).returncode)
