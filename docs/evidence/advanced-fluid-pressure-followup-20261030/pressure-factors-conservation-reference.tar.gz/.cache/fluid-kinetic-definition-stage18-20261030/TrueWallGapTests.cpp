#include "SymmetricVoxelPorts.h"
#include "ConvexAgglomeration.h"
#include "ConservativeCondensedNetwork.h"
#include "../fluid-compatible-flux-stage9-20261029/OwnedCutGeometry.h"
#include <cstdio>

namespace ag=convex_agglomeration;
namespace net=stage17_network;
namespace lc=stage17_condensed;
namespace cn=stage17_conservative_network;
unsigned checks=0;
void Check(bool condition,const char* what) {
    ++checks;if(!condition)throw std::runtime_error(what);
}
using TriangleKey=std::pair<std::array<ag::RV,3>,ag::RV>;
std::multiset<TriangleKey> WettedTriangles(const convex_ports::Compiler& source) {
    std::multiset<TriangleKey> result;
    for(const auto& cell:source.cells)for(const auto& face:cell.faces)
        if(face.kind==convex_ports::Kind::Solid)for(const auto& triangle:face.triangles) {
            auto p=triangle.points;std::sort(p.begin(),p.end());result.emplace(p,triangle.areaVector);
        }
    return result;
}
ag::R Displacement(const convex_ports::Box& box) {
    std::array<ag::RV,3> n;ag::RV width;
    for(unsigned a=0;a<3;++a) {
        for(unsigned b=0;b<3;++b)n[a][b]=ag::R(box[2*a+1].normal[b]);
        width[a]=ag::R(box[2*a].coordinate)+ag::R(box[2*a+1].coordinate);
    }
    return width[0]*width[1]*width[2]/abs(owned_metrics::Dot(n[0],owned_metrics::Cross(n[1],n[2])));
}
int main() {
    setvbuf(stdout,nullptr,_IOLBF,0);
    try {
        using V=glm::dvec3;
        constexpr unsigned grid=1;
        constexpr double angle=3.2137858346770188e-11;
        const auto box=owned_cut::BoxPlanes(V(.2+std::ldexp(1.,-40),.5,.5),V(.2),glm::dquat(1,0,0,0));
        symmetric_voxel_ports::Compiler original;original.Build(grid,box);
        const auto start=net::Clock::now();ag::Compiler merged;merged.Build(original);
        const double geometryMs=net::Milliseconds(start);
        Check(merged.inputVolume==merged.outputVolume,"symmetric agglomeration changes exact wet quantity");
        Check(WettedTriangles(original)==WettedTriangles(merged),"symmetric agglomeration changes a native solid patch");
        Check(merged.minCompactnessAfter>=merged.minCompactnessBefore,"symmetric merge worsens minimum geometric regularity");
        for(const auto& receipt:merged.merges)
            Check(receipt.after>receipt.worseBefore,"symmetric merge did not use unchanged exact shape policy");
        for(const auto& cell:merged.cells) {
            const auto vertices=ag::Vertices(cell);ag::RV area{};ag::R volume=0;
            for(const auto& face:cell.faces)for(const auto& triangle:face.triangles) {
                for(unsigned a=0;a<3;++a)area[a]+=triangle.areaVector[a];
                volume+=owned_metrics::Dot(triangle.points[0],triangle.areaVector)/3;
                for(const auto& point:vertices)
                    Check(owned_metrics::Dot(ag::Sub(point,triangle.points[0]),triangle.areaVector)<=0,
                          "symmetric merged cell is not exactly convex");
            }
            Check(area==ag::RV{}&&volume==cell.volume,"symmetric merged exterior is not exactly closed");
        }
        printf("SYMMETRIC_AGGLOMERATION_GEOMETRY cells_before=%u cells_after=%zu merges=%zu input_volume=%Lg min_quality_before=%Lg min_quality_after=%Lg geometry_ms=%g\n",
            merged.inputCells,merged.cells.size(),merged.merges.size(),merged.inputVolume.convert_to<net::Real>(),
            merged.minCompactnessBefore.convert_to<net::Real>(),merged.minCompactnessAfter.convert_to<net::Real>(),geometryMs);
        net::Network physical(merged,net::vg::R(1)/grid);
        lc::Epoch condensed(physical);cn::Epoch world(condensed);
        const net::Real displaced=(Displacement(box)/ag::R(grid*grid*grid)).convert_to<net::Real>();
        for(unsigned scenario=0;scenario<3;++scenario) {
            const net::vm::Vec3 source=scenario==0?net::vm::Vec3(0,-.04L,0):
                (scenario==2?net::vm::Vec3(.02L,-.035L,.01L):net::vm::Vec3::Zero());
            net::Twist body=net::Twist::Zero();if(scenario==1)body<<.01L,-.02L,.03L,.02L,.03L,-.01L;
            const auto result=world.Solve(world.Constant(source),body);
            net::Real normalized=0,pointDiv=0,calm=0,rms=0,trace=0;
            for(unsigned c=0;c<world.cells.size();++c) {
                const auto& local=*world.cells[c];const auto& raw=result.local[c];
                const auto moment=(local.op.divergenceMoments*raw).eval();
                normalized=std::max(normalized,moment.cwiseAbs().maxCoeff()/local.op.geometry.volume[0]);
                const auto div=local.op.Divergence(raw);const auto projected=local.op.Project(raw);
                if(scenario!=1)rms=std::max(rms,std::sqrt(2*local.op.Energy(raw)/(1000*local.op.geometry.volume[0])));
                for(unsigned f=0;f<local.cell.faces.size();++f)
                    for(const auto& triangle:local.cell.faces[f].triangles)
                        for(const auto& point:triangle.points) {
                            net::vm::Vec3 r,origin;
                            for(unsigned a=0;a<3;++a){r[a]=point[a].convert_to<net::Real>();origin[a]=local.cell.center[a].convert_to<net::Real>();}
                            Eigen::Matrix<net::Real,4,1> p;p<<1,r.x(),r.y(),r.z();
                            pointDiv=std::max(pointDiv,std::abs(div.dot(p)));
                            if(scenario!=1)calm=std::max(calm,net::vm::EvaluateAffine(projected,r).norm());
                            if(local.cell.faces[f].kind==net::Kind::Solid) {
                                const auto rigid=(body.head<3>()+body.tail<3>().cross(origin+r)).eval();
                                trace=std::max(trace,std::abs(local.op.EvaluateFaceNormal(f,raw,r)-local.op.geometry.faces[f].normal.dot(rigid)));
                            }
                        }
            }
            const auto force=(result.reaction.head<3>()+1000*displaced*source).norm();
            printf("SYMMETRIC_AGGLOMERATION_PHYSICAL scenario=%u cells=%zu variables=%ld energy=%Lg force_error=%Lg normalized_div=%Lg point_div=%Lg trace=%Lg calm=%Lg rms=%Lg exact_total_mean=%u root_mean_div=%Lg work=%Lg solve_ms=%g\n",
                scenario,world.cells.size(),long(world.mass.rows()),result.energy,force,normalized,pointDiv,trace,calm,rms,
                unsigned(result.exactTotalMean==0),result.maximumRootMeanDivergence,result.energyIdentity,result.solveMs);
            Check(result.exactTotalMean==0&&result.maximumRootMeanDivergence<1e-12L,"symmetric agglomeration loses exact quantity/mean continuity");
            for(const auto& [key,port]:world.allPorts)if(port.secondCell!=~0u)
                Check(result.exactFaceMeans[port.firstCell][port.firstFace]+result.exactFaceMeans[port.secondCell][port.secondFace]==0,
                      "symmetric physical ports do not exchange exactly opposite mean flux");
            Check(normalized<1e-8L&&pointDiv<1e-8L&&trace<1e-8L,"symmetric agglomerated physical divergence/trace fails");
            Check(result.energyIdentity<1e-10L&&result.stationarity<1e-10L,"symmetric agglomerated physical work/stationarity fails");
            if(scenario!=1) {
                Check(force<1e-10L,"symmetric agglomeration gives incorrect hydrostatic native load");
                Check(result.energy<1e-18L&&calm<1e-8L&&rms<1e-8L,"symmetric agglomeration is not locally calm");
            }
        }
        printf("SYMMETRIC_AGGLOMERATION_SUMMARY checks=%u failures=0\n",checks);return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"FAIL after %u checks %s\n",checks,error.what());return 1;
    }
}
