#pragma once
#include "SymmetricVoxelPorts.h"
#include "ConvexAgglomeration.h"
#include "ConservativeCondensedNetwork.h"
namespace rooted_epoch {
using namespace stage17_network;
struct Epoch:stage17_conservative_network::Epoch {
 static stage17_condensed::LocalCondensedNetwork Prepare(unsigned n,const Box& box){symmetric_voxel_ports::Compiler g;g.Build(n,box);convex_agglomeration::Compiler a;a.Build(g);Network physical(a);return stage17_condensed::LocalCondensedNetwork(physical);}
 Epoch(unsigned n,const Box& box):stage17_conservative_network::Epoch(Prepare(n,box)){}
};
}
