#include "WaterMaterialOwners.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <numeric>
#include <tuple>
namespace judas::volume_grid {
namespace {
using R=CutCompensated;
R Min(R a,R b){return (a-b).Value()<0.?a:b;}
R Max(R a,R b){return (a-b).Value()>0.?a:b;}
R FaceArea(const WaterMaterialFace& f){R area(1.);for(int a=0;a<3;++a)if(a!=f.axis)area=area*(f.hi[a]-f.lo[a]);return area;}
R LargestFace(const WaterCoordinate& lo,const WaterCoordinate& hi){R result;for(int axis=0;axis<3;++axis){R area=(hi[(axis+1)%3]-lo[(axis+1)%3])*(hi[(axis+2)%3]-lo[(axis+2)%3]);result=Max(result,area);}return result;}
}
bool BuildWaterMaterialOwners(const CutSpatialField& field,const WaterMaterialState& state,
    const std::vector<WaterMaterialFace>& faces,std::vector<std::size_t>& output,
    std::string& error,double minimumFraction){
    const auto n=state.fragments.size();
    if(!(minimumFraction>0.&&minimumFraction<=1.)||!field.chart.layout.CheckedCellCount()){error="invalid local material pressure scale";return false;}
    std::vector<std::size_t> parent(n);std::iota(parent.begin(),parent.end(),0);
    auto root=[&](std::size_t i){while(parent[i]!=i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
    for(const auto& f:faces){if(f.left>=n||f.right>=n||f.axis<0||f.axis>2){error="invalid material pressure seam";return false;}
        const auto& a=state.fragments[f.left];const auto& b=state.fragments[f.right];
        if(a.water==b.water&&a.cell==b.cell&&(a.water||a.carrier==b.carrier)){auto i=root(f.left),j=root(f.right);if(i!=j)parent[i]=j;}
    }
    std::vector<R> volume(n);std::vector<WaterCoordinate> lo(n),hi(n);std::vector<bool> initialized(n);
    for(std::size_t i=0;i<n;++i){const auto& p=state.fragments[i];if(p.cell>=field.chart.regions.size()){error="material pressure owner has no containing geometry";return false;}
        auto r=root(i);volume[r]=volume[r]+MaterialVolume(p);WaterCoordinate lower,upper;
        for(int a=0;a<3;++a){lower[a]=R(field.chart.regions[p.cell].lo[a])+p.lo[a];upper[a]=R(field.chart.regions[p.cell].lo[a])+p.hi[a];}
        if(!initialized[r]){lo[r]=lower;hi[r]=upper;initialized[r]=true;}
        else for(int a=0;a<3;++a){lo[r][a]=Min(lo[r][a],lower[a]);hi[r][a]=Max(hi[r][a],upper[a]);}
    }
    const double h=field.chart.layout.h,target=minimumFraction*h*h*h;
    bool changed=true;
    while(changed){changed=false;
        using Key=std::tuple<std::size_t,std::size_t,int,double,double>;
        std::map<Key,R> seams;
        for(const auto& f:faces){auto i=root(f.left),j=root(f.right);if(i==j||state.fragments[f.left].water!=state.fragments[f.right].water)continue;
            R plane=R(field.chart.regions[state.fragments[f.left].cell].lo[f.axis])+f.lo[f.axis];
            auto key=std::make_tuple(i,j,f.axis,plane.hi,plane.lo);seams[key]=seams[key]+FaceArea(f);
        }
        for(const auto& entry:seams){const auto [left,right,axis,high,low]=entry.first;(void)axis;(void)high;(void)low;
            auto i=root(left),j=root(right);if(i!=left||j!=right||i==j||(volume[i].Value()>=target&&volume[j].Value()>=target))continue;
            WaterCoordinate lower,upper;bool local=true;
            for(int a=0;a<3;++a){lower[a]=Min(lo[i][a],lo[j][a]);upper[a]=Max(hi[i][a],hi[j][a]);local &= (upper[a]-lower[a]).Value()<=2.*h;}
            R aperture=entry.second,wide=Min(LargestFace(lo[i],hi[i]),LargestFace(lo[j],hi[j]))*R(.5);
            if(!local||(aperture-wide).Value()<0.)continue;
            parent[i]=j;volume[j]=volume[j]+volume[i];lo[j]=lower;hi[j]=upper;changed=true;
        }
    }
    std::vector<std::size_t> result(n);for(std::size_t i=0;i<n;++i)result[i]=root(i);
    output=std::move(result);error.clear();return true;
}
}
