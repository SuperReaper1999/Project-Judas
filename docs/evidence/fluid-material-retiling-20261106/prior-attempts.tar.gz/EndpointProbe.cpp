#include "WaterInterfaceEvents.h"
#include <cmath>
#include <iostream>
#include <random>
using namespace judas::volume_grid;
using R=CutCompensated;
WaterMaterialFragment Box(R low,R high,bool water,std::size_t carrier){WaterMaterialFragment p;p.lo={low,0.,0.};p.hi={high,1.,1.};p.water=water;p.carrier=carrier;if(!water)p.gasMass=R(1.2)*MaterialVolume(p);return p;}
int main(){std::mt19937_64 random(0x593a41);int failed=0,rejected=0;double maximum=0.;
 CutSpatialField field;field.chart.layout={{1,1,1},1.};field.chart.regions={{{0.,0.,0.},{1.,1.,1.},0}};field.geometry.startCapacity=field.geometry.endCapacity={1.};
 for(int sample=0;sample<512;++sample){R lo(.1234567890123),hi(.1234567891123);lo.lo=std::ldexp(double(int(random()%2000000)-1000000),-82);hi.lo=std::ldexp(double(int(random()%2000000)-1000000),-82);
  WaterMaterialState state,after;state.fragments={Box(0.,lo,false,0),Box(lo,hi,true,1),Box(hi,.5,false,2),Box(.5,.7,true,3),Box(.7,1.,false,4)};
  std::vector<R> mass;for(auto p:state.fragments)mass.push_back(p.gasMass);R amount=MaterialVolume(state.fragments[1]);
  WaterInterfaceSweep recession,growth;recession.face={1,0,0,0,-1,{lo,0.,0.},{lo,1.,1.}};recession.volume=R()-amount;growth.face={3,4,0,0,1,{R(.7),0.,0.},{R(.7),1.,1.}};growth.volume=amount;
  WaterInterfaceEventReport report;std::string error;if(!ApplyWaterInterfaceEvents(field,state,{recession,growth},mass,after,report,error)){++rejected;continue;}
  R remnant;for(auto p:after.fragments)if(p.water&&p.carrier==1)remnant=remnant+MaterialVolume(p);if(remnant.Value()>0.){++failed;maximum=std::max(maximum,remnant.Value());}
 }
 std::cout<<"samples=512 remnants="<<failed<<" rejected="<<rejected<<" maximum="<<maximum<<"\n";return failed||rejected?1:0;
}
