#pragma once
#include "WaterMaterialFragments.h"
namespace judas::volume_grid {
// Bounded local pressure controls over actual phase geometry. Integration
// pieces retain their positions. The policy matches CutConnectedOwners:
// absorb small controls only through wide physical seams, with span <=2h.
// Neither volume nor inertia is floored; narrow throats never trigger a union.
bool BuildWaterMaterialOwners(const CutSpatialField&,const WaterMaterialState&,
    const std::vector<WaterMaterialFace>&,std::vector<std::size_t>&,
    std::string&,double minimumFraction=.125);
}
