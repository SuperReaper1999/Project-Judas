#!/usr/bin/env python3
"""Run preserved serial offscreen benchmarks against an explicit binary set."""
import argparse
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
CASES = {
    "fresh-2d": ("judas", "fresh-2d/Fresh_2D_Workflow.judasproj", 300),
    "lunar-island": ("judas", "lunar-island/lunar_island.judasproj", 300),
    "rendering-lab": ("judas_rendering_lab_performance", "rendering-lab/rendering_lab.judasproj", 360),
    "rendering-harness": ("judas", "rendering-lab/rendering_lab.judasproj", 50),
    "physics-live": ("judas", "physics-lab/Scenes/room1024.judas", 330),
    "physics-fixed": ("judas_physics_stress_live_benchmark", "physics-lab/Scenes/room1024.judas", 240),
}


def sha256(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def stats(values):
    ordered = sorted(values)
    if not ordered:
        return None
    return {
        "n": len(ordered), "median": statistics.median(ordered),
        "p95": ordered[math.ceil(.95 * len(ordered)) - 1], "worst": ordered[-1],
    }


def profile_summary(data, warmup=0):
    startup = data["startup"]
    frames = [f for f in data["frames"] if f["mode"] in ("standalone", "scripted application frame")
              and not f["startup"] and f["interval_ns"]]
    frames = frames[warmup:]
    by_pass = {}
    counters = {}
    tracked = {
        "World render submission", "Resource completion and budget", "Fixed step",
        "Rigid physics", "Shadow pass submission", "World culling and opaque submission",
        "Script lifecycle callback", "Swap present wait",
    }
    by_scope = {scope: [] for scope in tracked}
    steps = []
    for f in frames:
        for g in f["gpu"]["passes"]:
            if not g["pending"]:
                by_pass.setdefault(g["pass"], []).append(g["milliseconds"])
        for c in f["counters"]:
            counters.setdefault(c["name"], []).append(c["value"])
        for name in tracked:
            work = [s["inclusive_ns"] / 1e6 for s in f["scopes"]
                    if s["name"] == name and s["thread"] == f["main_thread"]]
            if work:
                by_scope[name].append(sum(work))
        steps.extend((s["end_ns"] - s["start_ns"]) / 1e6 for s in f["fixed"]["steps"])
    return {
        "retained_application_frames": len(frames),
        "startup_work_ms": (startup["end_ns"] - startup["start_ns"]) / 1e6 if startup else None,
        "interval_ms": stats([f["interval_ns"] / 1e6 for f in frames]),
        "outer_work_ms": stats([(f["end_ns"] - f["start_ns"]) / 1e6 for f in frames]),
        "per_fixed_step_ms": stats(steps),
        "frames_with_fixed_cap": sum(f["fixed"]["cap_reached"] for f in frames),
        "discarded_simulation_seconds": sum(f["fixed"]["discarded_seconds"] for f in frames),
        "peak_recorded_rss_bytes": max((f["memory"]["linux_resident_bytes"] for f in frames), default=0),
        "diagnostics": data["diagnostics"],
        "owner_thread_scope_ms": {k: stats(v) for k, v in sorted(by_scope.items()) if v},
        "software_gl_elapsed_pass_ms": {k: stats(v) for k, v in sorted(by_pass.items())},
        "counter_observations": {k: stats(v) for k, v in sorted(counters.items()) if
                                 any(tag in k for tag in ("Physics", "draw", "Stress Lab", "Resource"))},
        "last_fixed_step_id": max((s["id"] for f in frames for s in f["fixed"]["steps"]), default=None),
    }


def summarize_csv(out):
    result = {}
    frames = out / "frames.csv"
    if frames.exists():
        with frames.open() as src:
            parsed = list(csv.DictReader(src))
        rows = [row for row in parsed if all(value is not None for value in row.values())]
        result.setdefault("dropped_partial_csv_rows", 0)
        result["dropped_partial_csv_rows"] += len(parsed) - len(rows)
        warm = rows[30:]
        keys = ("submission_ms", "interval_ms", "process_cpu_ms", "work_before_swap_ms",
                "draws", "draw_calls", "fixed_steps", "awake")
        result["all_application_frames"] = len(rows)
        result["warm_application_frame_metrics"] = {
            k: stats([float(row[k]) for row in warm]) for k in keys if warm and k in warm[0]
        }
    steps = out / "steps.csv"
    if steps.exists():
        with steps.open() as src:
            parsed = list(csv.DictReader(src))
        rows = [row for row in parsed if all(value is not None for value in row.values())]
        result.setdefault("dropped_partial_csv_rows", 0)
        result["dropped_partial_csv_rows"] += len(parsed) - len(rows)
        warm = rows[30:]
        keys = ("fixed_ms", "total_physics_ms", "narrowphase_ms", "solver_ms", "impact_events",
                "impact_queries", "awake", "sleeping")
        result["all_fixed_steps"] = len(rows)
        result["warm_fixed_step_metrics"] = {k: stats([float(r[k]) for r in warm]) for k in keys}
        result["nonfinite_fields"] = sum(int(r["nonfinite_fields"]) for r in rows)
        result["trajectory_digest_sha256"] = hashlib.sha256(
            "".join(row["trajectory_digest"] + "\n" for row in rows).encode()).hexdigest()
    quality = out / "quality.json"
    if quality.exists():
        result["quality"] = json.loads(quality.read_text())
    return result


def run_case(case, bin_dir, dest, repeat, repo):
    name, fixture, expected = CASES[case]
    exe = bin_dir / name
    target = ROOT / "fixtures" / fixture
    out = (dest / f"{case}-{repeat}").resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    for key in tuple(env):
        if key.startswith(("JUDAS_", "SDL_", "MESA_", "GALLIUM_")) or key in ("DISPLAY", "WAYLAND_DISPLAY"):
            env.pop(key)
    settings = {
        "SDL_VIDEODRIVER": "offscreen", "LIBGL_ALWAYS_SOFTWARE": "1", "LP_NUM_THREADS": "2",
        "SDL_AUDIODRIVER": "dummy", "XDG_DATA_HOME": str(out / "data"),
        "XDG_CACHE_HOME": str(out / "cache"), "XDG_CONFIG_HOME": str(out / "config"),
        "JUDAS_WORLD_STATE": "none", "JUDAS_WINDOW_SIZE": "640x360", "JUDAS_PROFILE": "1",
        "JUDAS_PROFILE_OUTPUT": str(out / "profile.json"),
    }
    if name == "judas":
        route = out / "as-run.test"
        route.write_text((ROOT / "routes" / f"{case}.test").read_text().replace("@RUN@", str(out)))
        settings["JUDAS_TEST_SCRIPT"] = str(route)
        args = [str(exe), str(target)]
    elif case == "rendering-lab":
        args = [str(exe), str(out), str(target)]
    else:
        args = [str(exe), str(target), str(out), "180", str(expected), "0", "1", "1",
                "0.016666667", "1", "0", "1"]
    env.update(settings)
    command = ["/usr/bin/time", "-v", "-o", str(out / "rusage.txt"), "timeout", "--kill-after=3", "120", *args]
    receipt = {
        "case": case, "executable_sha256": sha256(exe), "runtime_build_info":
        json.loads(subprocess.check_output([str(bin_dir / "judas"), "--build-info-json"], text=True)),
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "host": platform.platform(),
        "environment": settings, "cwd": str(repo), "command": command,
        "expected_frames": expected,
    }
    with (out / "console.log").open("wb") as log:
        receipt["exit_code"] = subprocess.run(command, env=env, cwd=repo, stdout=log, stderr=log).returncode
    receipt["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    console = (out / "console.log").read_text(errors="replace")
    receipt["graphics"] = next((x.removeprefix("Graphics: ") for x in console.splitlines()
                                if x.startswith("Graphics: ")), None)
    receipt["backend_verified_software"] = bool(receipt["graphics"] and "llvmpipe" in receipt["graphics"])
    receipt["harness_messages"] = [line for line in console.splitlines() if line.startswith("[TestHarness]")]
    for profile in sorted(out.glob("profile*.json")):
        if profile.name in ("profile.json", "profile-final.json"):
            receipt["profile_summary"] = profile_summary(json.loads(profile.read_text()), 10 if case == "rendering-harness" else 0)
        with profile.open("rb") as source, gzip.open(str(profile) + ".gz", "wb", compresslevel=6) as zipped:
            while block := source.read(1024 * 1024):
                zipped.write(block)
        receipt.setdefault("profile_raw_sha256", {})[profile.name] = sha256(profile)
        profile.unlink()
    receipt.update(summarize_csv(out))
    if (out / "rusage.txt").exists():
        match = re.search(r"Maximum resident set size \(kbytes\): (\d+)", (out / "rusage.txt").read_text())
        if match:
            receipt["peak_process_rss_kib"] = int(match.group(1))
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"{case}-{repeat} exit={receipt['exit_code']} graphics={receipt['graphics']}", flush=True)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bin", type=lambda p: Path(p).resolve(), required=True)
    parser.add_argument("--out", type=lambda p: Path(p).resolve(), required=True)
    parser.add_argument("--case", choices=CASES, action="append")
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--repo", type=lambda p: Path(p).resolve(), default=REPO)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    receipts = [run_case(case, args.bin, args.out, repeat, args.repo)
                for repeat in range(1, args.repeat + 1) for case in args.case or (c for c in CASES if c != "rendering-harness")]
    (args.out / "results.json").write_text(json.dumps(receipts, indent=2) + "\n")
    return any(r["exit_code"] or not r["backend_verified_software"] for r in receipts)


if __name__ == "__main__":
    raise SystemExit(main())
