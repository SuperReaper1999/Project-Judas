# Portable evidence and replay

This packet preserves existing observations. It has no build outputs or
copies of the three tracked project trees. The authored fresh 2D fixture is
small and included exactly. For a replay, use the exact Linux Experimental
baseline and the corresponding build configuration in the receipts.

1. Extract into a fresh directory. From `runtime-baseline/`, verify packet
   integrity with `sha256sum -c SHA256SUMS`.
2. Restore the other fixtures from the named Judas checkout. Write to the
   extracted packet's fixture copies only.

   ```sh
   repo=/absolute/path/to/Project-Judas
   cp -a "$repo/projects/lunar_island" fixtures/lunar-island
   cp -a "$repo/projects/rendering_lab" fixtures/rendering-lab
   cp -a "$repo/projects/physics_stress_lab" fixtures/physics-lab
   sha256sum -c FIXTURE_SHA256SUMS
   ```

3. Supply the directory with `judas`, `judas_rendering_lab_performance` and
   `judas_physics_stress_live_benchmark`. The baseline executable hashes and
   configuration/build logs were captured alongside the original runs.
   Separate the intentionally bounded rendering attempt from passing routes.

   ```sh
   bin=/absolute/path/to/baseline-bin
   python3 measure.py --repo "$repo" --bin "$bin" --out replay \
     --case fresh-2d --case lunar-island --case rendering-harness \
     --case physics-live --case physics-fixed
   python3 measure.py --repo "$repo" --bin "$bin" --out long-render-replay \
     --case rendering-lab
   ```

   The original long render run timed out at its documented 120-second limit.
   A faster software backend may finish it. Workload assets, timings and
   platform claims should remain separately scoped.

The stock input harness needs a path without spaces. The receipt JSON contains
the run's exact command, environment, output signatures and profiler limits.
